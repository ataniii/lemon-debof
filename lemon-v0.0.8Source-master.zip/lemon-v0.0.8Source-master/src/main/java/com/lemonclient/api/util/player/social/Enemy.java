package com.lemonclient.api.util.player.social;

public class Enemy {
   private final String name;

   public Enemy(String name) {
      this.name = name;
   }

   public String getName() {
      return this.name;
   }
}
