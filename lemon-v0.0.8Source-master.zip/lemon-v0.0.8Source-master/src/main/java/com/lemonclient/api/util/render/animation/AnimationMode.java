package com.lemonclient.api.util.render.animation;

public enum AnimationMode {
   LINEAR,
   EXPONENTIAL;
}
