package com.lemonclient.api.event.events;

import com.lemonclient.api.event.LemonClientEvent;

public class WaterPushEvent extends LemonClientEvent {
}
