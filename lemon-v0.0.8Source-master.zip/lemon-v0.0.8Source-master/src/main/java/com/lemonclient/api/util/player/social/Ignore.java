package com.lemonclient.api.util.player.social;

public class Ignore {
   private final String name;

   public Ignore(String name) {
      this.name = name;
   }

   public String getName() {
      return this.name;
   }
}
