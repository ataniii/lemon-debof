package com.lemonclient.api.util.chat.notification;

public enum NotificationType {
   INFO,
   WARNING,
   WELCOME,
   LOAD,
   ERROR;
}
