package com.lemonclient.api.event;

public enum Phase {
   PRE,
   BY,
   POST;
}
