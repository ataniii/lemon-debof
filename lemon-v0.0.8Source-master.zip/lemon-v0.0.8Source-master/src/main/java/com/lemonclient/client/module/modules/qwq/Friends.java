package com.lemonclient.client.module.modules.qwq;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;

@Module.Declaration(
   name = "Friends",
   category = Category.qwq,
   enabled = true,
   drawn = false
)
public class Friends extends Module {
}
