package com.lemonclient.client.module.modules.render;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;

@Module.Declaration(
   name = "NoFallingBlocks",
   category = Category.Render
)
public class NoFallingBlocks extends Module {
}
