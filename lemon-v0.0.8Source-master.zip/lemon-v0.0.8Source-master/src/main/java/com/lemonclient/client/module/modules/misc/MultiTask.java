package com.lemonclient.client.module.modules.misc;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;

@Module.Declaration(
   name = "MultiTask",
   category = Category.Misc
)
public class MultiTask extends Module {
}
