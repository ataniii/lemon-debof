package com.lemonclient.client.module;

public enum Category {
   Combat,
   Dev,
   Exploits,
   GUI,
   HUD,
   Misc,
   Movement,
   qwq,
   Render;
}
