package com.lemonclient.client.module.modules.render;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;

@Module.Declaration(
   name = "Cape",
   category = Category.Render,
   enabled = true
)
public class Cape extends Module {
}
