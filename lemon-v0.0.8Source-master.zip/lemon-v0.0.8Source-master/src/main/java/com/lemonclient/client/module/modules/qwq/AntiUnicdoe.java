package com.lemonclient.client.module.modules.qwq;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;

@Module.Declaration(
   name = "AntiUnicode",
   category = Category.qwq
)
public class AntiUnicdoe extends Module {
}
