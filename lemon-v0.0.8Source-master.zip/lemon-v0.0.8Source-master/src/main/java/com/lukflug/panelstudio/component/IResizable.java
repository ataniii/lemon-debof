package com.lukflug.panelstudio.component;

import java.awt.Dimension;

public interface IResizable {
   Dimension getSize();

   void setSize(Dimension var1);
}
