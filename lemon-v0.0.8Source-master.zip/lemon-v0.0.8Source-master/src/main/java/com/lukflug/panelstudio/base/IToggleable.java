package com.lukflug.panelstudio.base;

public interface IToggleable extends IBoolean {
   void toggle();
}
