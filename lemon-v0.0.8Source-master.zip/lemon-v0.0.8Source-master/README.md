# lemon-v0.0.8Source-notreal

Create build.gradle and gradle.properties by yourself
