/*    */ package com.lukflug.panelstudio.container;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.theme.IContainerRenderer;
/*    */ import java.awt.Point;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VerticalContainer
/*    */   extends Container<IComponent>
/*    */ {
/*    */   public VerticalContainer(ILabeled label, IContainerRenderer renderer) {
/* 22 */     super(label, renderer);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doContextSensitiveLoop(Context context, Container.ContextSensitiveConsumer<IComponent> function) {
/* 27 */     AtomicInteger posy = new AtomicInteger(this.renderer.getTop());
/* 28 */     doContextlessLoop(component -> {
/*    */           Context subContext = getSubContext(context, posy.get()); function.accept(subContext, component); if (subContext.focusReleased()) {
/*    */             context.releaseFocus();
/*    */           } else if (subContext.foucsRequested()) {
/*    */             context.requestFocus();
/*    */           }  posy.addAndGet((subContext.getSize()).height + this.renderer.getBorder());
/*    */         });
/* 35 */     context.setHeight(posy.get() - this.renderer.getBorder() + this.renderer.getBottom());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Context getSubContext(Context context, int posy) {
/* 45 */     return new Context(context, (context.getSize()).width - this.renderer.getLeft() - this.renderer.getRight(), new Point(this.renderer.getLeft(), posy), hasFocus(context), true);
/*    */   }
/*    */   
/*    */   protected boolean hasFocus(Context context) {
/* 49 */     return context.hasFocus();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\VerticalContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */