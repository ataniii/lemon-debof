/*     */ package com.lukflug.panelstudio.container;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.config.IConfigList;
/*     */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*     */ import com.lukflug.panelstudio.theme.IDescriptionRenderer;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GUI
/*     */   implements IContainer<IFixedComponent>
/*     */ {
/*     */   protected FixedContainer container;
/*     */   protected IInterface inter;
/*     */   protected IDescriptionRenderer descriptionRenderer;
/*     */   protected IPopupPositioner descriptionPosition;
/*     */   
/*     */   public GUI(IInterface inter, IDescriptionRenderer descriptionRenderer, IPopupPositioner descriptionPosition) {
/*  43 */     this.inter = inter;
/*  44 */     this.descriptionRenderer = descriptionRenderer;
/*  45 */     this.descriptionPosition = descriptionPosition;
/*  46 */     this.container = new FixedContainer(() -> "GUI", null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addComponent(IFixedComponent component) {
/*  51 */     return this.container.addComponent(component);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addComponent(IFixedComponent component, IBoolean visible) {
/*  56 */     return this.container.addComponent(component, visible);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeComponent(IFixedComponent component) {
/*  61 */     return this.container.removeComponent(component);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/*  68 */     Context context = getContext();
/*  69 */     this.container.render(context);
/*  70 */     if (context.getDescription() != null) {
/*  71 */       Point pos = this.descriptionPosition.getPosition(this.inter, null, context.getDescription().getComponentPos(), context.getDescription().getPanelPos());
/*  72 */       this.descriptionRenderer.renderDescription(this.inter, pos, context.getDescription().getContent());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleButton(int button) {
/*  83 */     this.container.handleButton(getContext(), button);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleKey(int scancode) {
/*  91 */     this.container.handleKey(getContext(), scancode);
/*     */   }
/*     */   
/*     */   public void handleChar(char character) {
/*  95 */     this.container.handleChar(getContext(), character);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleScroll(int diff) {
/* 103 */     this.container.handleScroll(getContext(), diff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enter() {
/* 110 */     this.container.enter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exit() {
/* 117 */     this.container.exit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveConfig(IConfigList config) {
/* 125 */     this.container.saveConfig(this.inter, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadConfig(IConfigList config) {
/* 133 */     this.container.loadConfig(this.inter, config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Context getContext() {
/* 141 */     return new Context(this.inter, 0, new Point(0, 0), true, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\GUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */