/*    */ package com.lukflug.panelstudio.container;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.component.IHorizontalComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.theme.IContainerRenderer;
/*    */ import java.awt.Point;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HorizontalContainer
/*    */   extends Container<IHorizontalComponent>
/*    */ {
/*    */   public HorizontalContainer(ILabeled label, IContainerRenderer renderer) {
/* 22 */     super(label, renderer);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doContextSensitiveLoop(Context context, Container.ContextSensitiveConsumer<IHorizontalComponent> function) {
/* 27 */     AtomicInteger availableWidth = new AtomicInteger((context.getSize()).width - this.renderer.getLeft() - this.renderer.getRight() + this.renderer.getBorder());
/* 28 */     AtomicInteger totalWeight = new AtomicInteger(0);
/* 29 */     doContextlessLoop(component -> {
/*    */           availableWidth.addAndGet(-component.getWidth(context.getInterface()) - this.renderer.getBorder());
/*    */           totalWeight.addAndGet(component.getWeight());
/*    */         });
/* 33 */     double weightFactor = availableWidth.get() / totalWeight.get();
/* 34 */     AtomicInteger x = new AtomicInteger(this.renderer.getLeft());
/* 35 */     AtomicInteger spentWeight = new AtomicInteger(0);
/* 36 */     AtomicInteger height = new AtomicInteger(0);
/* 37 */     doContextlessLoop(component -> {
/*    */           int start = (int)Math.round(spentWeight.get() * weightFactor); int end = (int)Math.round((spentWeight.get() + component.getWeight()) * weightFactor); int componentWidth = component.getWidth(context.getInterface()) + end - start; int componentPosition = x.get() + start; Context subContext = getSubContext(context, componentPosition, componentWidth);
/*    */           function.accept(subContext, component);
/*    */           if (subContext.focusReleased()) {
/*    */             context.releaseFocus();
/*    */           } else if (subContext.foucsRequested()) {
/*    */             context.requestFocus();
/*    */           } 
/*    */           x.addAndGet(component.getWidth(context.getInterface()) + this.renderer.getBorder());
/*    */           spentWeight.addAndGet(component.getWeight());
/*    */           if ((subContext.getSize()).height > height.get())
/*    */             height.set((subContext.getSize()).height); 
/*    */         });
/* 50 */     context.setHeight(height.get());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Context getSubContext(Context context, int posx, int width) {
/* 61 */     return new Context(context, width, new Point(posx, this.renderer.getTop()), context.hasFocus(), true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\HorizontalContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */