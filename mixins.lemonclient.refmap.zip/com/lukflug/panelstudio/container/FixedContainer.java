/*     */ package com.lukflug.panelstudio.container;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.Description;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.base.IToggleable;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.config.IConfigList;
/*     */ import com.lukflug.panelstudio.config.IPanelConfig;
/*     */ import com.lukflug.panelstudio.popup.IPopup;
/*     */ import com.lukflug.panelstudio.popup.IPopupDisplayer;
/*     */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.theme.IContainerRenderer;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedContainer
/*     */   extends Container<IFixedComponent>
/*     */   implements IPopupDisplayer
/*     */ {
/*     */   protected boolean clip;
/*  32 */   protected List<PopupPair> popups = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FixedContainer(ILabeled label, IContainerRenderer renderer, boolean clip) {
/*  41 */     super(label, renderer);
/*  42 */     this.clip = clip;
/*     */   }
/*     */ 
/*     */   
/*     */   public void displayPopup(IPopup popup, Rectangle rect, IToggleable visible, IPopupPositioner positioner) {
/*  47 */     this.popups.add(new PopupPair(popup, rect, visible, positioner));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Context context) {
/*  53 */     context.setHeight(getHeight());
/*     */     
/*  55 */     if (this.clip) context.getInterface().window(context.getRect()); 
/*  56 */     if (this.renderer != null) this.renderer.renderBackground(context, context.hasFocus());
/*     */     
/*  58 */     AtomicReference<IFixedComponent> highest = new AtomicReference<>(null);
/*  59 */     AtomicReference<IFixedComponent> first = new AtomicReference<>(null);
/*  60 */     doContextlessLoop(component -> {
/*     */           if (first.get() == null)
/*     */             first.set(component);  Context subContext = getSubContext(context, component, true, true);
/*     */           component.getHeight(subContext);
/*     */           if (subContext.isHovered() && highest.get() == null)
/*     */             highest.set(component); 
/*     */         });
/*  67 */     AtomicBoolean highestReached = new AtomicBoolean(false);
/*  68 */     if (highest.get() == null) highestReached.set(true); 
/*  69 */     AtomicReference<IFixedComponent> focusComponent = new AtomicReference<>(null);
/*  70 */     super.doContextlessLoop(component -> {
/*     */           if (component == highest.get()) {
/*     */             highestReached.set(true);
/*     */           }
/*     */           Context subContext = getSubContext(context, component, (component == first.get()), highestReached.get());
/*     */           component.render(subContext);
/*     */           if (subContext.focusReleased()) {
/*     */             context.releaseFocus();
/*     */           } else if (subContext.foucsRequested()) {
/*     */             focusComponent.set(component);
/*     */             context.requestFocus();
/*     */           } 
/*     */           if (subContext.isHovered() && subContext.getDescription() != null)
/*     */             context.setDescription(new Description(subContext.getDescription(), subContext.getRect())); 
/*     */           for (PopupPair popup : this.popups) {
/*     */             popup.popup.setPosition(context.getInterface(), popup.rect, subContext.getRect(), popup.positioner);
/*     */             if (!popup.visible.isOn())
/*     */               popup.visible.toggle(); 
/*     */             if (popup.popup instanceof IFixedComponent)
/*     */               focusComponent.set((IFixedComponent)popup.popup); 
/*     */           } 
/*     */           this.popups.clear();
/*     */         });
/*  93 */     if (focusComponent.get() != null && 
/*  94 */       removeComponent((IFixedComponent)focusComponent.get())) addComponent((IFixedComponent)focusComponent.get());
/*     */ 
/*     */     
/*  97 */     if (context.getDescription() == null && this.label.getDescription() != null) context.setDescription(new Description(context.getRect(), this.label.getDescription()));
/*     */     
/*  99 */     if (this.clip) context.getInterface().restore();
/*     */   
/*     */   }
/*     */   
/*     */   protected void doContextlessLoop(Consumer<IFixedComponent> function) {
/* 104 */     List<Container<IFixedComponent>.ComponentState> components = new ArrayList<>();
/* 105 */     for (Container<IFixedComponent>.ComponentState state : this.components) components.add(state); 
/* 106 */     for (Container<IFixedComponent>.ComponentState state : components) state.update(); 
/* 107 */     for (int i = components.size() - 1; i >= 0; i--) {
/* 108 */       Container<IFixedComponent>.ComponentState state = components.get(i);
/* 109 */       if (state.lastVisible()) function.accept((IFixedComponent)state.component);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doContextSensitiveLoop(Context context, Container.ContextSensitiveConsumer<IFixedComponent> function) {
/* 116 */     context.setHeight(getHeight());
/*     */     
/* 118 */     AtomicBoolean highest = new AtomicBoolean(true);
/* 119 */     AtomicBoolean first = new AtomicBoolean(true);
/* 120 */     AtomicReference<IFixedComponent> focusComponent = new AtomicReference<>(null);
/* 121 */     doContextlessLoop(component -> {
/*     */           Context subContext = getSubContext(context, component, first.get(), highest.get());
/*     */           first.set(false);
/*     */           function.accept(subContext, component);
/*     */           if (subContext.focusReleased()) {
/*     */             context.releaseFocus();
/*     */           } else if (subContext.foucsRequested()) {
/*     */             focusComponent.set(component);
/*     */             context.requestFocus();
/*     */           } 
/*     */           if (subContext.isHovered()) {
/*     */             highest.set(false);
/*     */           }
/*     */           for (PopupPair popup : this.popups) {
/*     */             popup.popup.setPosition(context.getInterface(), popup.rect, subContext.getRect(), popup.positioner);
/*     */             if (!popup.visible.isOn())
/*     */               popup.visible.toggle(); 
/*     */             if (popup.popup instanceof IFixedComponent)
/*     */               focusComponent.set((IFixedComponent)popup.popup); 
/*     */           } 
/*     */           this.popups.clear();
/*     */         });
/* 143 */     if (focusComponent.get() != null) {
/* 144 */       Container<IFixedComponent>.ComponentState focusState = this.components.stream().filter(state -> (state.component == focusComponent.get())).findFirst().orElse(null);
/* 145 */       if (focusState != null) {
/* 146 */         this.components.remove(focusState);
/* 147 */         this.components.add(focusState);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Context getSubContext(Context context, IFixedComponent component, boolean focus, boolean highest) {
/* 160 */     Context subContext = new Context(context, component.getWidth(context.getInterface()), component.getPosition(context.getInterface()), (context.hasFocus() && focus), highest);
/* 161 */     subContext.setPopupDisplayer(this);
/* 162 */     return subContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveConfig(IInterface inter, IConfigList config) {
/* 171 */     config.begin(false);
/* 172 */     for (Container<IFixedComponent>.ComponentState state : this.components) {
/* 173 */       if (((IFixedComponent)state.component).savesState()) {
/* 174 */         IPanelConfig cf = config.addPanel(((IFixedComponent)state.component).getConfigName());
/* 175 */         if (cf != null) ((IFixedComponent)state.component).saveConfig(inter, cf); 
/*     */       } 
/*     */     } 
/* 178 */     config.end(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadConfig(IInterface inter, IConfigList config) {
/* 187 */     config.begin(true);
/* 188 */     for (Container<IFixedComponent>.ComponentState state : this.components) {
/* 189 */       if (((IFixedComponent)state.component).savesState()) {
/* 190 */         IPanelConfig cf = config.getPanel(((IFixedComponent)state.component).getConfigName());
/* 191 */         if (cf != null) ((IFixedComponent)state.component).loadConfig(inter, cf); 
/*     */       } 
/*     */     } 
/* 194 */     config.end(true);
/*     */   }
/*     */   
/*     */   protected final class PopupPair
/*     */   {
/*     */     public final IPopup popup;
/*     */     public final Rectangle rect;
/*     */     public final IToggleable visible;
/*     */     public final IPopupPositioner positioner;
/*     */     
/*     */     public PopupPair(IPopup popup, Rectangle rect, IToggleable visible, IPopupPositioner positioner) {
/* 205 */       this.popup = popup;
/* 206 */       this.rect = rect;
/* 207 */       this.visible = visible;
/* 208 */       this.positioner = positioner;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\FixedContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */