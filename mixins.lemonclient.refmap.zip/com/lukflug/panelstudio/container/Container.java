/*     */ package com.lukflug.panelstudio.container;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.Description;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.component.ComponentBase;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.theme.IContainerRenderer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Container<T extends IComponent>
/*     */   extends ComponentBase
/*     */   implements IContainer<T>
/*     */ {
/*  24 */   protected List<ComponentState> components = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IContainerRenderer renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean visible;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container(ILabeled label, IContainerRenderer renderer) {
/*  40 */     super(label);
/*  41 */     this.renderer = renderer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addComponent(T component) {
/*  46 */     if (getComponentState(component) == null) {
/*  47 */       this.components.add(new ComponentState(component, getDefaultVisibility()));
/*  48 */       return true;
/*     */     } 
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addComponent(T component, IBoolean visible) {
/*  55 */     if (getComponentState(component) == null) {
/*  56 */       this.components.add(new ComponentState(component, visible));
/*  57 */       return true;
/*     */     } 
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeComponent(T component) {
/*  64 */     ComponentState state = getComponentState(component);
/*  65 */     if (state != null) {
/*  66 */       this.components.remove(state);
/*  67 */       if (state.lastVisible) state.component.exit(); 
/*  68 */       return true;
/*     */     } 
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(Context context) {
/*  75 */     getHeight(context);
/*  76 */     if (this.renderer != null) this.renderer.renderBackground(context, context.hasFocus()); 
/*  77 */     doContextSensitiveLoop(context, (subContext, component) -> {
/*     */           component.render(subContext); if (subContext.isHovered() && subContext.getDescription() != null)
/*     */             context.setDescription(new Description(subContext.getDescription(), subContext.getRect())); 
/*     */         });
/*  81 */     if (context.getDescription() == null && this.label.getDescription() != null) context.setDescription(new Description(context.getRect(), this.label.getDescription()));
/*     */   
/*     */   }
/*     */   
/*     */   public void handleButton(Context context, int button) {
/*  86 */     doContextSensitiveLoop(context, (subContext, component) -> component.handleButton(subContext, button));
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleKey(Context context, int scancode) {
/*  91 */     doContextSensitiveLoop(context, (subContext, component) -> component.handleKey(subContext, scancode));
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleChar(Context context, char character) {
/*  96 */     doContextSensitiveLoop(context, (subContext, component) -> component.handleChar(subContext, character));
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleScroll(Context context, int diff) {
/* 101 */     doContextSensitiveLoop(context, (subContext, component) -> component.handleScroll(subContext, diff));
/*     */   }
/*     */ 
/*     */   
/*     */   public void getHeight(Context context) {
/* 106 */     doContextSensitiveLoop(context, (subContext, component) -> component.getHeight(subContext));
/*     */   }
/*     */ 
/*     */   
/*     */   public void enter() {
/* 111 */     this.visible = true;
/* 112 */     doContextlessLoop(component -> {
/*     */         
/*     */         });
/*     */   }
/*     */   public void exit() {
/* 117 */     this.visible = false;
/* 118 */     doContextlessLoop(component -> {
/*     */         
/*     */         });
/*     */   }
/*     */   public void releaseFocus() {
/* 123 */     doContextlessLoop(IComponent::releaseFocus);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getHeight() {
/* 128 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ComponentState getComponentState(T component) {
/* 137 */     for (ComponentState state : this.components) {
/* 138 */       if (state.component == component) return state; 
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doContextlessLoop(Consumer<T> function) {
/* 148 */     List<ComponentState> components = new ArrayList<>();
/* 149 */     for (ComponentState state : this.components) components.add(state); 
/* 150 */     for (ComponentState state : components) state.update(); 
/* 151 */     for (ComponentState state : components) {
/* 152 */       if (state.lastVisible()) function.accept(state.component);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IBoolean getDefaultVisibility() {
/* 168 */     return () -> true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doContextSensitiveLoop(Context paramContext, ContextSensitiveConsumer<T> paramContextSensitiveConsumer);
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   protected static interface ContextSensitiveConsumer<T extends IComponent>
/*     */   {
/*     */     void accept(Context param1Context, T param1T);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final class ComponentState
/*     */   {
/*     */     public final T component;
/*     */ 
/*     */     
/*     */     public final IBoolean externalVisibility;
/*     */     
/*     */     private boolean lastVisible = false;
/*     */ 
/*     */     
/*     */     public ComponentState(T component, IBoolean externalVisibility) {
/* 196 */       this.component = component;
/* 197 */       this.externalVisibility = externalVisibility;
/* 198 */       update();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update() {
/* 205 */       if (((this.component.isVisible() && this.externalVisibility.isOn() && Container.this.visible)) != this.lastVisible) {
/* 206 */         if (this.lastVisible) {
/* 207 */           this.lastVisible = false;
/* 208 */           this.component.exit();
/*     */         } else {
/* 210 */           this.lastVisible = true;
/* 211 */           this.component.enter();
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean lastVisible() {
/* 221 */       return this.lastVisible;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\Container.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */