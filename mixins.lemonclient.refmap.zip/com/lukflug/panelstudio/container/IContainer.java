package com.lukflug.panelstudio.container;

import com.lukflug.panelstudio.base.IBoolean;

public interface IContainer<T extends com.lukflug.panelstudio.component.IComponent> {
  boolean addComponent(T paramT);
  
  boolean addComponent(T paramT, IBoolean paramIBoolean);
  
  boolean removeComponent(T paramT);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\container\IContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */