package com.lukflug.panelstudio.config;

import java.awt.Dimension;
import java.awt.Point;

public interface IPanelConfig {
  void savePositon(Point paramPoint);
  
  void saveSize(Dimension paramDimension);
  
  Point loadPosition();
  
  Dimension loadSize();
  
  void saveState(boolean paramBoolean);
  
  boolean loadState();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\config\IPanelConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */