package com.lukflug.panelstudio.config;

public interface IConfigList {
  void begin(boolean paramBoolean);
  
  void end(boolean paramBoolean);
  
  IPanelConfig addPanel(String paramString);
  
  IPanelConfig getPanel(String paramString);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\config\IConfigList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */