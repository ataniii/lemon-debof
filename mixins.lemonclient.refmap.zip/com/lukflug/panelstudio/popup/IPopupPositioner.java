package com.lukflug.panelstudio.popup;

import com.lukflug.panelstudio.base.IInterface;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

@FunctionalInterface
public interface IPopupPositioner {
  Point getPosition(IInterface paramIInterface, Dimension paramDimension, Rectangle paramRectangle1, Rectangle paramRectangle2);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\popup\IPopupPositioner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */