package com.lukflug.panelstudio.popup;

import com.lukflug.panelstudio.base.IToggleable;
import java.awt.Rectangle;

public interface IPopupDisplayer {
  void displayPopup(IPopup paramIPopup, Rectangle paramRectangle, IToggleable paramIToggleable, IPopupPositioner paramIPopupPositioner);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\popup\IPopupDisplayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */