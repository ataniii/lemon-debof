package com.lukflug.panelstudio.popup;

import com.lukflug.panelstudio.base.IInterface;
import java.awt.Rectangle;

@FunctionalInterface
public interface IPopup {
  void setPosition(IInterface paramIInterface, Rectangle paramRectangle1, Rectangle paramRectangle2, IPopupPositioner paramIPopupPositioner);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\popup\IPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */