/*    */ package com.lukflug.panelstudio.popup;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedPositioner
/*    */   implements IPopupPositioner
/*    */ {
/*    */   protected Point pos;
/*    */   
/*    */   public FixedPositioner(Point pos) {
/* 24 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   
/*    */   public Point getPosition(IInterface inter, Dimension popup, Rectangle component, Rectangle panel) {
/* 29 */     return new Point(this.pos);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\popup\FixedPositioner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */