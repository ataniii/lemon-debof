/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.config.IPanelConfig;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedComponent<T extends IComponent>
/*    */   extends ComponentProxy<T>
/*    */   implements IFixedComponent
/*    */ {
/*    */   protected Point position;
/*    */   protected int width;
/*    */   protected IToggleable state;
/*    */   protected boolean savesState;
/*    */   protected String configName;
/*    */   
/*    */   public FixedComponent(T component, Point position, int width, IToggleable state, boolean savesState, String configName) {
/* 41 */     super(component);
/* 42 */     this.position = position;
/* 43 */     this.width = width;
/* 44 */     this.state = state;
/* 45 */     this.savesState = savesState;
/* 46 */     this.configName = configName;
/*    */   }
/*    */ 
/*    */   
/*    */   public Point getPosition(IInterface inter) {
/* 51 */     return new Point(this.position);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPosition(IInterface inter, Point position) {
/* 56 */     this.position = new Point(position);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getWidth(IInterface inter) {
/* 61 */     return this.width;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean savesState() {
/* 66 */     return this.savesState;
/*    */   }
/*    */ 
/*    */   
/*    */   public void saveConfig(IInterface inter, IPanelConfig config) {
/* 71 */     config.savePositon(this.position);
/* 72 */     if (this.state != null) config.saveState(this.state.isOn());
/*    */   
/*    */   }
/*    */   
/*    */   public void loadConfig(IInterface inter, IPanelConfig config) {
/* 77 */     this.position = config.loadPosition();
/* 78 */     if (this.state != null && 
/* 79 */       this.state.isOn() != config.loadState()) this.state.toggle();
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConfigName() {
/* 85 */     return this.configName;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\FixedComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */