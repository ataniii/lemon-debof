/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.config.IPanelConfig;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DraggableComponent<T extends IFixedComponent>
/*    */   implements IComponentProxy<T>, IFixedComponent
/*    */ {
/*    */   protected boolean dragging = false;
/*    */   protected Point attachPoint;
/*    */   
/*    */   public Point getPosition(IInterface inter) {
/* 25 */     Point point = ((IFixedComponent)getComponent()).getPosition(inter);
/* 26 */     if (this.dragging) point.translate((inter.getMouse()).x - this.attachPoint.x, (inter.getMouse()).y - this.attachPoint.y); 
/* 27 */     return point;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPosition(IInterface inter, Point position) {
/* 32 */     ((IFixedComponent)getComponent()).setPosition(inter, position);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getWidth(IInterface inter) {
/* 37 */     return ((IFixedComponent)getComponent()).getWidth(inter);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean savesState() {
/* 42 */     return ((IFixedComponent)getComponent()).savesState();
/*    */   }
/*    */ 
/*    */   
/*    */   public void saveConfig(IInterface inter, IPanelConfig config) {
/* 47 */     ((IFixedComponent)getComponent()).saveConfig(inter, config);
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadConfig(IInterface inter, IPanelConfig config) {
/* 52 */     ((IFixedComponent)getComponent()).loadConfig(inter, config);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConfigName() {
/* 57 */     return ((IFixedComponent)getComponent()).getConfigName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <S extends IComponent> ComponentProxy<S> getWrappedDragComponent(S dragComponent) {
/* 65 */     return new ComponentProxy<S>((IComponent)dragComponent)
/*    */       {
/*    */         public void handleButton(Context context, int button) {
/* 68 */           super.handleButton(context, button);
/* 69 */           if (context.isClicked(button) && button == 0) {
/* 70 */             DraggableComponent.this.dragging = true;
/* 71 */             DraggableComponent.this.attachPoint = context.getInterface().getMouse();
/* 72 */           } else if (!context.getInterface().getButton(0) && DraggableComponent.this.dragging) {
/* 73 */             Point mouse = context.getInterface().getMouse();
/* 74 */             DraggableComponent.this.dragging = false;
/* 75 */             Point p = ((IFixedComponent)DraggableComponent.this.getComponent()).getPosition(context.getInterface());
/* 76 */             p.translate(mouse.x - DraggableComponent.this.attachPoint.x, mouse.y - DraggableComponent.this.attachPoint.y);
/* 77 */             ((IFixedComponent)DraggableComponent.this.getComponent()).setPosition(context.getInterface(), p);
/*    */           } 
/*    */         }
/*    */ 
/*    */         
/*    */         public void exit() {
/* 83 */           DraggableComponent.this.dragging = false;
/* 84 */           super.exit();
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\DraggableComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */