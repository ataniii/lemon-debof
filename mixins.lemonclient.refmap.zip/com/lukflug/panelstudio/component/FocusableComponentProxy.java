/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FocusableComponentProxy<T extends IComponent>
/*    */   implements IComponentProxy<T>
/*    */ {
/*    */   private final boolean initFocus;
/*    */   private boolean focus;
/*    */   private boolean requestFocus = false;
/*    */   
/*    */   public FocusableComponentProxy(boolean focus) {
/* 16 */     this.initFocus = focus;
/* 17 */     this.focus = focus;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleButton(Context context, int button) {
/* 22 */     super.handleButton(context, button);
/* 23 */     if (context.getInterface().getButton(button)) {
/* 24 */       this.focus = context.isHovered();
/* 25 */       if (this.focus) context.requestFocus();
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   public Context doOperation(Context context, Consumer<Context> operation) {
/* 31 */     if (this.requestFocus) { context.requestFocus(); }
/* 32 */     else if (!context.hasFocus()) { this.focus = false; }
/* 33 */      this.requestFocus = false;
/* 34 */     return super.doOperation(context, operation);
/*    */   }
/*    */ 
/*    */   
/*    */   public void releaseFocus() {
/* 39 */     this.focus = false;
/* 40 */     super.releaseFocus();
/*    */   }
/*    */ 
/*    */   
/*    */   public void enter() {
/* 45 */     this.focus = this.initFocus;
/* 46 */     if (this.focus) this.requestFocus = true; 
/* 47 */     super.enter();
/*    */   }
/*    */ 
/*    */   
/*    */   public void exit() {
/* 52 */     this.focus = this.initFocus;
/* 53 */     super.exit();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasFocus(Context context) {
/* 62 */     return (context.hasFocus() && this.focus);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\FocusableComponentProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */