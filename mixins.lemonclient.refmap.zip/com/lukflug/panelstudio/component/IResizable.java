package com.lukflug.panelstudio.component;

import java.awt.Dimension;

public interface IResizable {
  Dimension getSize();
  
  void setSize(Dimension paramDimension);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IResizable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */