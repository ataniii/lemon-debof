/*     */ package com.lukflug.panelstudio.component;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ScrollableComponent<T extends IComponent>
/*     */   implements IComponentProxy<T>, IScrollSize
/*     */ {
/*     */   private Context tempContext;
/*  19 */   protected Point scrollPos = new Point(0, 0);
/*     */ 
/*     */ 
/*     */   
/*  23 */   protected Point nextScrollPos = null;
/*     */ 
/*     */ 
/*     */   
/*  27 */   protected Dimension contentSize = new Dimension(0, 0);
/*     */ 
/*     */ 
/*     */   
/*  31 */   protected Dimension scrollSize = new Dimension(0, 0);
/*     */ 
/*     */   
/*     */   public void render(Context context) {
/*  35 */     doOperation(context, subContext -> {
/*     */           context.getInterface().window(context.getRect());
/*     */           getComponent().render(subContext);
/*     */           Rectangle a = context.getRect();
/*     */           Rectangle b = subContext.getRect();
/*     */           if (b.width < a.width) {
/*     */             fillEmptySpace(context, new Rectangle(a.x + b.width, a.y, a.width - b.width, b.height));
/*     */           }
/*     */           if (b.height < a.height) {
/*     */             fillEmptySpace(context, new Rectangle(a.x, a.y + b.height, b.width, a.height - b.height));
/*     */           }
/*     */           if (b.width < a.width && b.height < a.height) {
/*     */             fillEmptySpace(context, new Rectangle(a.x + b.width, a.y + b.height, a.width - b.width, a.height - b.height));
/*     */           }
/*     */           context.getInterface().restore();
/*     */         });
/*     */   }
/*     */   
/*     */   public void handleScroll(Context context, int diff) {
/*  54 */     Context sContext = doOperation(context, subContext -> getComponent().handleScroll(subContext, diff));
/*  55 */     if (context.isHovered()) {
/*  56 */       if (isScrollingY()) { this.scrollPos.translate(0, diff); }
/*  57 */       else if (isScrollingX()) { this.scrollPos.translate(diff, 0); }
/*  58 */        clampScrollPos(context.getSize(), sContext.getSize());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Context doOperation(Context context, Consumer<Context> operation) {
/*  64 */     this.tempContext = context;
/*  65 */     Context subContext = super.doOperation(context, operation);
/*  66 */     if (this.nextScrollPos != null) {
/*  67 */       this.scrollPos = this.nextScrollPos;
/*  68 */       this.nextScrollPos = null;
/*     */     } 
/*  70 */     clampScrollPos(context.getSize(), subContext.getSize());
/*  71 */     this.contentSize = subContext.getSize();
/*  72 */     this.scrollSize = context.getSize();
/*  73 */     return subContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context getContext(Context context) {
/*  78 */     Context subContext = new Context(context, (context.getSize()).width, new Point(-this.scrollPos.x, -this.scrollPos.y), true, true);
/*  79 */     getComponent().getHeight(subContext);
/*  80 */     int height = getScrollHeight(context, (subContext.getSize()).height);
/*  81 */     context.setHeight(height);
/*  82 */     return new Context(context, getComponentWidth(context), new Point(-this.scrollPos.x, -this.scrollPos.y), true, context.isHovered());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getScrollPos() {
/*  90 */     return new Point(this.scrollPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScrollPosX(int scrollPos) {
/*  98 */     if (this.nextScrollPos == null) { this.nextScrollPos = new Point(scrollPos, this.scrollPos.y); }
/*  99 */     else { this.nextScrollPos.x = scrollPos; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScrollPosY(int scrollPos) {
/* 107 */     if (this.nextScrollPos == null) { this.nextScrollPos = new Point(this.scrollPos.x, scrollPos); }
/* 108 */     else { this.nextScrollPos.y = scrollPos; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getContentSize() {
/* 116 */     return this.contentSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getScrollSize() {
/* 124 */     return this.scrollSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isScrollingX() {
/* 132 */     return (this.contentSize.width > this.scrollSize.width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isScrollingY() {
/* 140 */     return (this.contentSize.height > this.scrollSize.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clampScrollPos(Dimension scrollSize, Dimension contentSize) {
/* 149 */     if (this.scrollPos.x > contentSize.width - scrollSize.width) this.scrollPos.x = contentSize.width - scrollSize.width; 
/* 150 */     if (this.scrollPos.x < 0) this.scrollPos.x = 0; 
/* 151 */     if (this.scrollPos.y > contentSize.height - scrollSize.height) this.scrollPos.y = contentSize.height - scrollSize.height; 
/* 152 */     if (this.scrollPos.y < 0) this.scrollPos.y = 0;
/*     */   
/*     */   }
/*     */   
/*     */   public final int getHeight(int height) {
/* 157 */     return getScrollHeight(this.tempContext, height);
/*     */   }
/*     */   
/*     */   public abstract void fillEmptySpace(Context paramContext, Rectangle paramRectangle);
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\ScrollableComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */