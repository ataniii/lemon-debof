/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.Description;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComponentBase
/*    */   implements IComponent
/*    */ {
/*    */   protected final ILabeled label;
/*    */   
/*    */   public ComponentBase(ILabeled label) {
/* 22 */     this.label = label;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTitle() {
/* 27 */     return this.label.getDisplayName();
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(Context context) {
/* 32 */     getHeight(context);
/* 33 */     if (context.isHovered() && this.label.getDescription() != null) context.setDescription(new Description(context.getRect(), this.label.getDescription()));
/*    */   
/*    */   }
/*    */   
/*    */   public void handleButton(Context context, int button) {
/* 38 */     getHeight(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleKey(Context context, int scancode) {
/* 43 */     getHeight(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleChar(Context context, char character) {
/* 48 */     getHeight(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleScroll(Context context, int diff) {
/* 53 */     getHeight(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void getHeight(Context context) {
/* 58 */     context.setHeight(getHeight());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void enter() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void exit() {}
/*    */ 
/*    */   
/*    */   public boolean isVisible() {
/* 71 */     return this.label.isVisible().isOn();
/*    */   }
/*    */   
/*    */   protected abstract int getHeight();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\ComponentBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */