package com.lukflug.panelstudio.component;

import com.lukflug.panelstudio.base.IInterface;

public interface IHorizontalComponent extends IComponent {
  int getWidth(IInterface paramIInterface);
  
  int getWeight();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IHorizontalComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */