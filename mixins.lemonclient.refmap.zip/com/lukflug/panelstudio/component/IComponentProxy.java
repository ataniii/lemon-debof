/*     */ package com.lukflug.panelstudio.component;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface IComponentProxy<T extends IComponent>
/*     */   extends IComponent
/*     */ {
/*     */   default String getTitle() {
/*  15 */     return getComponent().getTitle();
/*     */   }
/*     */ 
/*     */   
/*     */   default void render(Context context) {
/*  20 */     doOperation(context, getComponent()::render);
/*     */   }
/*     */ 
/*     */   
/*     */   default void handleButton(Context context, int button) {
/*  25 */     doOperation(context, subContext -> getComponent().handleButton(subContext, button));
/*     */   }
/*     */ 
/*     */   
/*     */   default void handleKey(Context context, int scancode) {
/*  30 */     doOperation(context, subContext -> getComponent().handleKey(subContext, scancode));
/*     */   }
/*     */ 
/*     */   
/*     */   default void handleChar(Context context, char character) {
/*  35 */     doOperation(context, subContext -> getComponent().handleChar(subContext, character));
/*     */   }
/*     */ 
/*     */   
/*     */   default void handleScroll(Context context, int diff) {
/*  40 */     doOperation(context, subContext -> getComponent().handleScroll(subContext, diff));
/*     */   }
/*     */ 
/*     */   
/*     */   default void getHeight(Context context) {
/*  45 */     doOperation(context, getComponent()::getHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   default void enter() {
/*  50 */     getComponent().enter();
/*     */   }
/*     */ 
/*     */   
/*     */   default void exit() {
/*  55 */     getComponent().exit();
/*     */   }
/*     */ 
/*     */   
/*     */   default void releaseFocus() {
/*  60 */     getComponent().releaseFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean isVisible() {
/*  65 */     return getComponent().isVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context doOperation(Context context, Consumer<Context> operation) {
/*  80 */     Context subContext = getContext(context);
/*  81 */     operation.accept(subContext);
/*  82 */     if (subContext != context) {
/*  83 */       if (subContext.focusReleased()) { context.releaseFocus(); }
/*  84 */       else if (subContext.foucsRequested()) { context.requestFocus(); }
/*  85 */        context.setHeight(getHeight((subContext.getSize()).height));
/*  86 */       if (subContext.getDescription() != null) context.setDescription(subContext.getDescription()); 
/*     */     } 
/*  88 */     return subContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getHeight(int height) {
/*  97 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Context getContext(Context context) {
/* 106 */     return context;
/*     */   }
/*     */   
/*     */   T getComponent();
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IComponentProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */