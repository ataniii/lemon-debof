/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.popup.IPopup;
/*    */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class PopupComponent<T extends IComponent>
/*    */   extends FixedComponent<T> implements IPopup {
/*    */   protected Rectangle component;
/*    */   
/*    */   public PopupComponent(T component, int width) {
/* 16 */     super(component, new Point(0, 0), width, (IToggleable)null, false, "");
/*    */   }
/*    */   protected Rectangle panel; protected IPopupPositioner positioner;
/*    */   
/*    */   public Point getPosition(IInterface inter) {
/* 21 */     Context temp = new Context(inter, this.width, this.position, true, true);
/* 22 */     getHeight(temp);
/* 23 */     return this.positioner.getPosition(inter, temp.getSize(), this.component, this.panel);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPosition(IInterface inter, Rectangle component, Rectangle panel, IPopupPositioner positioner) {
/* 28 */     this.component = component;
/* 29 */     this.panel = panel;
/* 30 */     this.positioner = positioner;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\PopupComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */