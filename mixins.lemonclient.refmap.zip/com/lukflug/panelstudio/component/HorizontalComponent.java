/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HorizontalComponent<T extends IComponent>
/*    */   extends ComponentProxy<T>
/*    */   implements IHorizontalComponent
/*    */ {
/*    */   protected int width;
/*    */   protected int weight;
/*    */   
/*    */   public HorizontalComponent(T component, int width, int weight) {
/* 26 */     super(component);
/* 27 */     this.width = width;
/* 28 */     this.weight = weight;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getWidth(IInterface inter) {
/* 33 */     return this.width;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getWeight() {
/* 38 */     return this.weight;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\HorizontalComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */