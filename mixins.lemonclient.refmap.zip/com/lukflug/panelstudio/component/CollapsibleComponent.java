/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CollapsibleComponent<T extends IComponent>
/*    */   implements IComponentProxy<T>
/*    */ {
/*    */   protected AnimatedToggleable toggle;
/*    */   
/*    */   public CollapsibleComponent(IToggleable toggle, Animation animation) {
/* 26 */     this.toggle = new AnimatedToggleable(toggle, animation);
/*    */   }
/*    */   
/*    */   public CollapsibleComponent(AnimatedToggleable toggle) {
/* 30 */     this.toggle = toggle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(Context context) {
/* 35 */     doOperation(context, subContext -> {
/*    */           context.getInterface().window(context.getRect());
/*    */           getComponent().render(subContext);
/*    */           context.getInterface().restore();
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVisible() {
/* 44 */     return (getComponent().isVisible() && this.toggle.getValue() != 0.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public Context getContext(Context context) {
/* 49 */     Context subContext = new Context(context, (context.getSize()).width, new Point(0, 0), true, true);
/* 50 */     getComponent().getHeight(subContext);
/* 51 */     int height = getHeight((subContext.getSize()).height);
/* 52 */     int offset = height - (subContext.getSize()).height;
/* 53 */     context.setHeight(height);
/* 54 */     return new Context(context, (context.getSize()).width, new Point(0, offset), true, context.isHovered());
/*    */   }
/*    */ 
/*    */   
/*    */   public int getHeight(int height) {
/* 59 */     return (int)(this.toggle.getValue() * height);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AnimatedToggleable getToggle() {
/* 67 */     return this.toggle;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\CollapsibleComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */