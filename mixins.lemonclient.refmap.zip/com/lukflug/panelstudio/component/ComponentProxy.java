/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ public class ComponentProxy<T extends IComponent> implements IComponentProxy<T> {
/*    */   protected final T component;
/*    */   
/*    */   public ComponentProxy(T component) {
/*  7 */     this.component = component;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getComponent() {
/* 12 */     return this.component;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\ComponentProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */