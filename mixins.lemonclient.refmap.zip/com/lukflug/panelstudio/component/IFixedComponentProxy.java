/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.config.IPanelConfig;
/*    */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface IFixedComponentProxy<T extends IFixedComponent>
/*    */   extends IComponentProxy<T>, IFixedComponent
/*    */ {
/*    */   default Point getPosition(IInterface inter) {
/* 14 */     return ((IFixedComponent)getComponent()).getPosition(inter);
/*    */   }
/*    */ 
/*    */   
/*    */   default void setPosition(IInterface inter, Point position) {
/* 19 */     ((IFixedComponent)getComponent()).setPosition(inter, position);
/*    */   }
/*    */ 
/*    */   
/*    */   default void setPosition(IInterface inter, Rectangle component, Rectangle panel, IPopupPositioner positioner) {
/* 24 */     ((IFixedComponent)getComponent()).setPosition(inter, component, panel, positioner);
/*    */   }
/*    */ 
/*    */   
/*    */   default int getWidth(IInterface inter) {
/* 29 */     return ((IFixedComponent)getComponent()).getWidth(inter);
/*    */   }
/*    */ 
/*    */   
/*    */   default boolean savesState() {
/* 34 */     return ((IFixedComponent)getComponent()).savesState();
/*    */   }
/*    */ 
/*    */   
/*    */   default void saveConfig(IInterface inter, IPanelConfig config) {
/* 39 */     ((IFixedComponent)getComponent()).saveConfig(inter, config);
/*    */   }
/*    */ 
/*    */   
/*    */   default void loadConfig(IInterface inter, IPanelConfig config) {
/* 44 */     ((IFixedComponent)getComponent()).loadConfig(inter, config);
/*    */   }
/*    */ 
/*    */   
/*    */   default String getConfigName() {
/* 49 */     return ((IFixedComponent)getComponent()).getConfigName();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IFixedComponentProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */