/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.config.IPanelConfig;
/*    */ import com.lukflug.panelstudio.popup.IPopup;
/*    */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IFixedComponent
/*    */   extends IComponent, IPopup
/*    */ {
/*    */   Point getPosition(IInterface paramIInterface);
/*    */   
/*    */   void setPosition(IInterface paramIInterface, Point paramPoint);
/*    */   
/*    */   default void setPosition(IInterface inter, Rectangle component, Rectangle panel, IPopupPositioner positioner) {
/* 35 */     setPosition(inter, positioner.getPosition(inter, null, component, panel));
/*    */   }
/*    */   
/*    */   int getWidth(IInterface paramIInterface);
/*    */   
/*    */   boolean savesState();
/*    */   
/*    */   void saveConfig(IInterface paramIInterface, IPanelConfig paramIPanelConfig);
/*    */   
/*    */   void loadConfig(IInterface paramIInterface, IPanelConfig paramIPanelConfig);
/*    */   
/*    */   String getConfigName();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IFixedComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */