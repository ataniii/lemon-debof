/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FocusableComponent
/*    */   extends ComponentBase
/*    */ {
/*    */   private boolean focus = false;
/*    */   
/*    */   public FocusableComponent(ILabeled label) {
/* 21 */     super(label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleButton(Context context, int button) {
/* 26 */     super.handleButton(context, button);
/* 27 */     updateFocus(context, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public void releaseFocus() {
/* 32 */     this.focus = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void exit() {
/* 37 */     this.focus = false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasFocus(Context context) {
/* 46 */     if (!context.hasFocus()) this.focus = false; 
/* 47 */     return this.focus;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void updateFocus(Context context, int button) {
/* 58 */     if (context.getInterface().getButton(button)) {
/* 59 */       this.focus = context.isHovered();
/* 60 */       if (this.focus) context.requestFocus(); 
/* 61 */       handleFocus(context, (this.focus && context.hasFocus()));
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void handleFocus(Context context, boolean focus) {}
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\FocusableComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */