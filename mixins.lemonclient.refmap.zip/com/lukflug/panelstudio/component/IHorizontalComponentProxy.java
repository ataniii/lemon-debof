/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface IHorizontalComponentProxy<T extends IHorizontalComponent>
/*    */   extends IComponentProxy<T>, IHorizontalComponent {
/*    */   default int getWidth(IInterface inter) {
/*  9 */     return ((IHorizontalComponent)getComponent()).getWidth(inter);
/*    */   }
/*    */ 
/*    */   
/*    */   default int getWeight() {
/* 14 */     return ((IHorizontalComponent)getComponent()).getWeight();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IHorizontalComponentProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */