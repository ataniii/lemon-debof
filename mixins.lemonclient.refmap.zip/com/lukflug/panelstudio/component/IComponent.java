package com.lukflug.panelstudio.component;

import com.lukflug.panelstudio.base.Context;

public interface IComponent {
  String getTitle();
  
  void render(Context paramContext);
  
  void handleButton(Context paramContext, int paramInt);
  
  void handleKey(Context paramContext, int paramInt);
  
  void handleChar(Context paramContext, char paramChar);
  
  void handleScroll(Context paramContext, int paramInt);
  
  void getHeight(Context paramContext);
  
  void enter();
  
  void exit();
  
  void releaseFocus();
  
  boolean isVisible();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */