/*    */ package com.lukflug.panelstudio.component;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ 
/*    */ public interface IScrollSize {
/*    */   default int getScrollHeight(Context context, int componentHeight) {
/*  7 */     return componentHeight;
/*    */   }
/*    */   
/*    */   default int getComponentWidth(Context context) {
/* 11 */     return (context.getSize()).width;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\component\IScrollSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */