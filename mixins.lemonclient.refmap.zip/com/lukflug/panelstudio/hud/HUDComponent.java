/*     */ package com.lukflug.panelstudio.hud;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.Description;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.config.IPanelConfig;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ 
/*     */ public abstract class HUDComponent
/*     */   implements IFixedComponent {
/*     */   protected String title;
/*     */   protected IBoolean visible;
/*     */   protected String description;
/*     */   protected Point position;
/*     */   protected String configName;
/*     */   
/*     */   public HUDComponent(ILabeled label, Point position, String configName) {
/*  22 */     this.title = label.getDisplayName();
/*  23 */     this.position = position;
/*  24 */     this.description = label.getDescription();
/*  25 */     this.configName = configName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTitle() {
/*  30 */     return this.title;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(Context context) {
/*  35 */     context.setHeight((getSize(context.getInterface())).height);
/*  36 */     if (this.description != null) context.setDescription(new Description(context.getRect(), this.description));
/*     */   
/*     */   }
/*     */   
/*     */   public void handleButton(Context context, int button) {
/*  41 */     context.setHeight((getSize(context.getInterface())).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleKey(Context context, int scancode) {
/*  46 */     context.setHeight((getSize(context.getInterface())).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleChar(Context context, char character) {
/*  51 */     context.setHeight((getSize(context.getInterface())).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleScroll(Context context, int diff) {
/*  56 */     context.setHeight((getSize(context.getInterface())).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getHeight(Context context) {
/*  61 */     context.setHeight((getSize(context.getInterface())).height);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enter() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void exit() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseFocus() {}
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  78 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getPosition(IInterface inter) {
/*  83 */     return new Point(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPosition(IInterface inter, Point position) {
/*  88 */     this.position = new Point(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth(IInterface inter) {
/*  93 */     return (getSize(inter)).width;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean savesState() {
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveConfig(IInterface inter, IPanelConfig config) {
/* 103 */     config.savePositon(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadConfig(IInterface inter, IPanelConfig config) {
/* 108 */     this.position = config.loadPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getConfigName() {
/* 113 */     return this.configName;
/*     */   }
/*     */   
/*     */   public abstract Dimension getSize(IInterface paramIInterface);
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\hud\HUDComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */