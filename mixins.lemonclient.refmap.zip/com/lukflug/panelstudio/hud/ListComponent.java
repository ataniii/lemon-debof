/*    */ package com.lukflug.panelstudio.hud;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.config.IPanelConfig;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Point;
/*    */ 
/*    */ public class ListComponent extends HUDComponent {
/*    */   protected HUDList list;
/*    */   protected boolean lastUp = false;
/*    */   protected boolean lastRight = false;
/*    */   protected int height;
/*    */   protected int border;
/*    */   
/*    */   public ListComponent(ILabeled label, Point position, String configName, HUDList list, int height, int border) {
/* 18 */     super(label, position, configName);
/* 19 */     this.list = list;
/* 20 */     this.height = height;
/* 21 */     this.border = border;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(Context context) {
/* 26 */     super.render(context);
/* 27 */     for (int i = 0; i < this.list.getSize(); i++) {
/* 28 */       String s = this.list.getItem(i);
/* 29 */       Point p = context.getPos();
/* 30 */       if (this.list.sortUp()) {
/* 31 */         p.translate(0, (this.height + this.border) * (this.list.getSize() - 1 - i));
/*    */       } else {
/* 33 */         p.translate(0, i * (this.height + this.border));
/*    */       } 
/* 35 */       if (this.list.sortRight()) {
/* 36 */         p.translate(getWidth(context.getInterface()) - context.getInterface().getFontWidth(this.height, s), 0);
/*    */       }
/* 38 */       context.getInterface().drawString(p, this.height, s, this.list.getItemColor(i));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Point getPosition(IInterface inter) {
/* 44 */     Dimension size = getSize(inter);
/* 45 */     if (this.lastUp != this.list.sortUp()) {
/* 46 */       if (this.list.sortUp()) { this.position.translate(0, size.height); }
/* 47 */       else { this.position.translate(0, -size.height); }
/* 48 */        this.lastUp = this.list.sortUp();
/*    */     } 
/* 50 */     if (this.lastRight != this.list.sortRight()) {
/* 51 */       if (this.list.sortRight()) { this.position.translate(size.width, 0); }
/* 52 */       else { this.position.translate(-size.width, 0); }
/* 53 */        this.lastRight = this.list.sortRight();
/*    */     } 
/* 55 */     if (this.list.sortUp()) {
/* 56 */       if (this.list.sortRight()) return new Point(this.position.x - size.width, this.position.y - size.height); 
/* 57 */       return new Point(this.position.x, this.position.y - size.height);
/*    */     } 
/* 59 */     if (this.list.sortRight()) return new Point(new Point(this.position.x - size.width, this.position.y)); 
/* 60 */     return new Point(this.position);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPosition(IInterface inter, Point position) {
/* 66 */     Dimension size = getSize(inter);
/* 67 */     if (this.list.sortUp())
/* 68 */     { if (this.list.sortRight()) { this.position = new Point(position.x + size.width, position.y + size.height); }
/* 69 */       else { this.position = new Point(position.x, position.y + size.height); }
/*    */        }
/* 71 */     else if (this.list.sortRight()) { this.position = new Point(position.x + size.width, position.y); }
/* 72 */     else { this.position = new Point(position); }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadConfig(IInterface inter, IPanelConfig config) {
/* 78 */     super.loadConfig(inter, config);
/* 79 */     this.lastUp = this.list.sortUp();
/* 80 */     this.lastRight = this.list.sortRight();
/*    */   }
/*    */ 
/*    */   
/*    */   public Dimension getSize(IInterface inter) {
/* 85 */     int width = inter.getFontWidth(this.height, getTitle());
/* 86 */     for (int i = 0; i < this.list.getSize(); i++) {
/* 87 */       String s = this.list.getItem(i);
/* 88 */       width = Math.max(width, inter.getFontWidth(this.height, s));
/*    */     } 
/* 90 */     int height = (this.height + this.border) * this.list.getSize() - this.border;
/* 91 */     if (height < 0) height = 0; 
/* 92 */     return new Dimension(width + 2 * this.border, height);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\hud\ListComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */