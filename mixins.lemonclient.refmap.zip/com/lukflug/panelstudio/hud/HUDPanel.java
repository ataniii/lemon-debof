/*     */ package com.lukflug.panelstudio.hud;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*     */ import com.lukflug.panelstudio.base.Animation;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.base.IToggleable;
/*     */ import com.lukflug.panelstudio.component.ComponentProxy;
/*     */ import com.lukflug.panelstudio.component.DraggableComponent;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.component.IComponentProxy;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.config.IPanelConfig;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.Labeled;
/*     */ import com.lukflug.panelstudio.theme.IButtonRenderer;
/*     */ import com.lukflug.panelstudio.theme.IButtonRendererProxy;
/*     */ import com.lukflug.panelstudio.theme.IPanelRenderer;
/*     */ import com.lukflug.panelstudio.theme.IPanelRendererProxy;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import com.lukflug.panelstudio.widget.ClosableComponent;
/*     */ import com.lukflug.panelstudio.widget.ToggleButton;
/*     */ import java.awt.Point;
/*     */ 
/*     */ public class HUDPanel<T extends IFixedComponent>
/*     */   extends DraggableComponent<HUDPanel<T>.HUDPanelComponent> {
/*     */   protected T component;
/*     */   
/*     */   public HUDPanel(T component, IToggleable state, Animation animation, ITheme theme, IBoolean renderState, int border) {
/*  31 */     this.component = component;
/*  32 */     this.panel = new HUDPanelComponent(state, animation, theme, renderState, border);
/*  33 */     this.renderState = renderState;
/*     */   }
/*     */   protected HUDPanelComponent panel; protected IBoolean renderState;
/*     */   
/*     */   public HUDPanelComponent getComponent() {
/*  38 */     return this.panel;
/*     */   }
/*     */   
/*     */   public void handleButton(Context context, int button) {
/*  42 */     if (this.renderState.isOn()) { super.handleButton(context, button); }
/*  43 */     else { getHeight(context); }
/*     */   
/*     */   }
/*     */   public void handleScroll(Context context, int diff) {
/*  47 */     if (this.renderState.isOn()) { super.handleScroll(context, diff); }
/*  48 */     else { getHeight(context); }
/*     */   
/*     */   }
/*     */   
/*     */   protected class HUDPanelComponent implements IFixedComponent, IComponentProxy<ComponentProxy<ClosableComponent<ToggleButton, ComponentProxy<T>>>> {
/*     */     protected ComponentProxy<ClosableComponent<ToggleButton, ComponentProxy<T>>> closable;
/*     */     protected IButtonRenderer<Boolean> titleRenderer;
/*     */     protected IPanelRenderer<Boolean> panelRenderer;
/*     */     protected int border;
/*     */     
/*     */     public HUDPanelComponent(final IToggleable state, Animation animation, ITheme theme, final IBoolean renderState, final int border) {
/*  59 */       this.border = border;
/*  60 */       this.panelRenderer = theme.getPanelRenderer(Boolean.class, 0, 0);
/*  61 */       this.titleRenderer = theme.getButtonRenderer(Boolean.class, 0, 0, true);
/*  62 */       this.closable = HUDPanel.this.getWrappedDragComponent((IComponent)new ClosableComponent((IComponent)new ToggleButton((ILabeled)new Labeled(HUDPanel.this.component.getTitle(), null, () -> HUDPanel.this.component.isVisible()), new IToggleable()
/*     */               {
/*     */                 public boolean isOn() {
/*  65 */                   return state.isOn();
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/*     */                 public void toggle() {}
/*     */               },  (IButtonRenderer)new IButtonRendererProxy<Boolean>()
/*     */               {
/*     */                 public void renderButton(Context context, String title, boolean focus, Boolean state) {
/*  74 */                   if (renderState.isOn()) super.renderButton(context, title, focus, state);
/*     */                 
/*     */                 }
/*     */                 
/*     */                 public IButtonRenderer<Boolean> getRenderer() {
/*  79 */                   return HUDPanel.HUDPanelComponent.this.titleRenderer;
/*     */                 }
/*     */               }), (IComponent)new ComponentProxy<T>((IFixedComponent)HUDPanel.this.component)
/*     */             {
/*     */               public int getHeight(int height) {
/*  84 */                 return height + 2 * border;
/*     */               }
/*     */ 
/*     */               
/*     */               public Context getContext(Context context) {
/*  89 */                 return new Context(context, (context.getSize()).width - 2 * border, new Point(border, border), context.hasFocus(), context.onTop());
/*     */               }
/*     */             }() -> Boolean.valueOf(state.isOn()), new AnimatedToggleable(state, animation), (IPanelRenderer)new IPanelRendererProxy<Boolean>()
/*     */             {
/*     */               public void renderBackground(Context context, boolean focus) {
/*  94 */                 if (renderState.isOn()) super.renderBackground(context, focus);
/*     */               
/*     */               }
/*     */               
/*     */               public void renderPanelOverlay(Context context, boolean focus, Boolean state, boolean open) {
/*  99 */                 if (renderState.isOn()) super.renderPanelOverlay(context, focus, state, open);
/*     */               
/*     */               }
/*     */               
/*     */               public void renderTitleOverlay(Context context, boolean focus, Boolean state, boolean open) {
/* 104 */                 if (renderState.isOn()) super.renderTitleOverlay(context, focus, state, open);
/*     */               
/*     */               }
/*     */               
/*     */               public IPanelRenderer<Boolean> getRenderer() {
/* 109 */                 return HUDPanel.HUDPanelComponent.this.panelRenderer;
/*     */               }
/*     */             }false));
/*     */     }
/*     */ 
/*     */     
/*     */     public ComponentProxy<ClosableComponent<ToggleButton, ComponentProxy<T>>> getComponent() {
/* 116 */       return this.closable;
/*     */     }
/*     */ 
/*     */     
/*     */     public Point getPosition(IInterface inter) {
/* 121 */       Point pos = HUDPanel.this.component.getPosition(inter);
/* 122 */       pos.translate(-this.panelRenderer.getLeft() - this.border, -this.panelRenderer.getTop() - this.titleRenderer.getDefaultHeight() - this.panelRenderer.getBorder() - this.border);
/* 123 */       return pos;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPosition(IInterface inter, Point position) {
/* 128 */       position.translate(this.panelRenderer.getLeft() + this.border, this.panelRenderer.getTop() + this.titleRenderer.getDefaultHeight() + this.panelRenderer.getBorder() + this.border);
/* 129 */       HUDPanel.this.component.setPosition(inter, position);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getWidth(IInterface inter) {
/* 134 */       return HUDPanel.this.component.getWidth(inter) + this.panelRenderer.getLeft() + this.panelRenderer.getRight() + 2 * this.border;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean savesState() {
/* 139 */       return HUDPanel.this.component.savesState();
/*     */     }
/*     */ 
/*     */     
/*     */     public void saveConfig(IInterface inter, IPanelConfig config) {
/* 144 */       HUDPanel.this.component.saveConfig(inter, config);
/*     */     }
/*     */ 
/*     */     
/*     */     public void loadConfig(IInterface inter, IPanelConfig config) {
/* 149 */       HUDPanel.this.component.loadConfig(inter, config);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getConfigName() {
/* 154 */       return HUDPanel.this.component.getConfigName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\hud\HUDPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */