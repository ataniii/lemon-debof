package com.lukflug.panelstudio.hud;

import java.awt.Color;

public interface HUDList {
  int getSize();
  
  String getItem(int paramInt);
  
  Color getItemColor(int paramInt);
  
  boolean sortUp();
  
  boolean sortRight();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\hud\HUDList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */