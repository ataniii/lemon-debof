//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lukflug.panelstudio.mc12;
/*     */ 
/*     */ import com.lukflug.panelstudio.container.GUI;
/*     */ import java.awt.Point;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MinecraftGUI
/*     */   extends GuiScreen
/*     */ {
/*  22 */   private Point mouse = new Point();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lButton = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean rButton = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private long lastTime;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterGUI() {
/*  40 */     Minecraft.getMinecraft().displayGuiScreen(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exitGUI() {
/*  47 */     Minecraft.getMinecraft().displayGuiScreen(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderGUI() {
/*  54 */     this.lastTime = System.currentTimeMillis();
/*  55 */     getInterface().begin(true);
/*  56 */     getGUI().render();
/*  57 */     getInterface().end(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initGui() {
/*  62 */     getGUI().enter();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClosed() {
/*  67 */     getGUI().exit();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  72 */     this.mouse = getInterface().screenToGui(new Point(Mouse.getX(), Mouse.getY()));
/*  73 */     renderGUI();
/*  74 */     int scroll = Mouse.getDWheel();
/*  75 */     if (scroll != 0) {
/*  76 */       if (scroll > 0) { getGUI().handleScroll(-getScrollSpeed()); }
/*  77 */       else { getGUI().handleScroll(getScrollSpeed()); }
/*     */     
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int clickedButton) {
/*  83 */     this.mouse = getInterface().screenToGui(new Point(Mouse.getX(), Mouse.getY()));
/*  84 */     switch (clickedButton) {
/*     */       case 0:
/*  86 */         this.lButton = true;
/*     */         break;
/*     */       case 1:
/*  89 */         this.rButton = true;
/*     */         break;
/*     */     } 
/*  92 */     getGUI().handleButton(clickedButton);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
/*  97 */     this.mouse = getInterface().screenToGui(new Point(Mouse.getX(), Mouse.getY()));
/*  98 */     switch (releaseButton) {
/*     */       case 0:
/* 100 */         this.lButton = false;
/*     */         break;
/*     */       case 1:
/* 103 */         this.rButton = false;
/*     */         break;
/*     */     } 
/* 106 */     getGUI().handleButton(releaseButton);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void keyTyped(char typedChar, int keyCode) {
/* 111 */     if (keyCode == 1) { exitGUI(); }
/*     */     else
/* 113 */     { getGUI().handleKey(keyCode);
/* 114 */       getGUI().handleChar(typedChar); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesGuiPauseGame() {
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract GUI getGUI();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract GUIInterface getInterface();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getScrollSpeed();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class GUIInterface
/*     */     extends GLInterface
/*     */   {
/*     */     public GUIInterface(boolean clipX) {
/* 152 */       super(clipX);
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTime() {
/* 157 */       return MinecraftGUI.this.lastTime;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getButton(int button) {
/* 162 */       switch (button) {
/*     */         case 0:
/* 164 */           return MinecraftGUI.this.lButton;
/*     */         case 1:
/* 166 */           return MinecraftGUI.this.rButton;
/*     */       } 
/* 168 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Point getMouse() {
/* 173 */       return new Point(MinecraftGUI.this.mouse);
/*     */     }
/*     */ 
/*     */     
/*     */     protected float getZLevel() {
/* 178 */       return MinecraftGUI.this.zLevel;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\mc12\MinecraftGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
