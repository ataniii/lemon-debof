//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lukflug.panelstudio.mc12;
/*    */ 
/*    */ import com.lukflug.panelstudio.container.GUI;
/*    */ import com.lukflug.panelstudio.hud.HUDGUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MinecraftHUDGUI
/*    */   extends MinecraftGUI
/*    */ {
/*    */   private boolean guiOpened = false;
/*    */   
/*    */   public void enterGUI() {
/* 20 */     if (!getGUI().getGUIVisibility().isOn()) getGUI().getGUIVisibility().toggle(); 
/* 21 */     if (!getGUI().getHUDVisibility().isOn()) getGUI().getHUDVisibility().toggle(); 
/* 22 */     super.enterGUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public void exitGUI() {
/* 27 */     if (getGUI().getGUIVisibility().isOn()) getGUI().getGUIVisibility().toggle(); 
/* 28 */     if (getGUI().getHUDVisibility().isOn()) getGUI().getHUDVisibility().toggle(); 
/* 29 */     super.exitGUI();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void enterHUDEditor() {
/* 36 */     if (getGUI().getGUIVisibility().isOn()) getGUI().getGUIVisibility().toggle(); 
/* 37 */     if (!getGUI().getHUDVisibility().isOn()) getGUI().getHUDVisibility().toggle(); 
/* 38 */     super.enterGUI();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initGui() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void onGuiClosed() {}
/*    */ 
/*    */   
/*    */   protected void renderGUI() {
/* 51 */     if (!this.guiOpened) getGUI().enter(); 
/* 52 */     this.guiOpened = true;
/* 53 */     super.renderGUI();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void render() {
/* 60 */     if (!getGUI().getGUIVisibility().isOn() && !getGUI().getHUDVisibility().isOn()) renderGUI();
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleKeyEvent(int scancode) {
/* 68 */     if (scancode != 1 && !getGUI().getGUIVisibility().isOn() && !getGUI().getGUIVisibility().isOn()) getGUI().handleKey(scancode); 
/*    */   }
/*    */   
/*    */   protected abstract HUDGUI getGUI();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\mc12\MinecraftHUDGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
