//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lukflug.panelstudio.mc12;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.Stack;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GLAllocation;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureUtil;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GLInterface
/*     */   implements IInterface
/*     */ {
/*  39 */   private final Stack<Rectangle> clipRect = new Stack<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean clipX;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GLInterface(boolean clipX) {
/*  50 */     this.clipX = clipX;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getModifier(int modifier) {
/*  55 */     switch (modifier) {
/*     */       case 0:
/*  57 */         return (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
/*     */       case 1:
/*  59 */         return (Keyboard.isKeyDown(29) || Keyboard.isKeyDown(157));
/*     */       case 2:
/*  61 */         return (Keyboard.isKeyDown(56) || Keyboard.isKeyDown(184));
/*     */       case 3:
/*  63 */         return (Keyboard.isKeyDown(219) || Keyboard.isKeyDown(220));
/*     */     } 
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getWindowSize() {
/*  70 */     return new Dimension((int)Math.ceil(getScreenWidth()), (int)Math.ceil(getScreenHeight()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawString(Point pos, int height, String s, Color c) {
/*  75 */     GlStateManager.pushMatrix();
/*  76 */     GlStateManager.translate(pos.x, pos.y, 0.0F);
/*  77 */     double scale = height / (Minecraft.getMinecraft()).fontRenderer.FONT_HEIGHT;
/*  78 */     GlStateManager.scale(scale, scale, 1.0D);
/*  79 */     end(false);
/*  80 */     (Minecraft.getMinecraft()).fontRenderer.drawStringWithShadow(s, 0.0F, 0.0F, c.getRGB());
/*  81 */     begin(false);
/*  82 */     GlStateManager.popMatrix();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFontWidth(int height, String s) {
/*  87 */     double scale = height / (Minecraft.getMinecraft()).fontRenderer.FONT_HEIGHT;
/*  88 */     return (int)Math.round((Minecraft.getMinecraft()).fontRenderer.getStringWidth(s) * scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillTriangle(Point pos1, Point pos2, Point pos3, Color c1, Color c2, Color c3) {
/*  93 */     Tessellator tessellator = Tessellator.getInstance();
/*  94 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  95 */     bufferbuilder.begin(4, DefaultVertexFormats.POSITION_COLOR);
/*  96 */     bufferbuilder.pos(pos1.x, pos1.y, getZLevel()).color(c1.getRed() / 255.0F, c1.getGreen() / 255.0F, c1.getBlue() / 255.0F, c1.getAlpha() / 255.0F).endVertex();
/*  97 */     bufferbuilder.pos(pos2.x, pos2.y, getZLevel()).color(c2.getRed() / 255.0F, c2.getGreen() / 255.0F, c2.getBlue() / 255.0F, c2.getAlpha() / 255.0F).endVertex();
/*  98 */     bufferbuilder.pos(pos3.x, pos3.y, getZLevel()).color(c3.getRed() / 255.0F, c3.getGreen() / 255.0F, c3.getBlue() / 255.0F, c3.getAlpha() / 255.0F).endVertex();
/*  99 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawLine(Point a, Point b, Color c1, Color c2) {
/* 104 */     Tessellator tessellator = Tessellator.getInstance();
/* 105 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 106 */     bufferbuilder.begin(1, DefaultVertexFormats.POSITION_COLOR);
/* 107 */     bufferbuilder.pos(a.x, a.y, getZLevel()).color(c1.getRed() / 255.0F, c1.getGreen() / 255.0F, c1.getBlue() / 255.0F, c1.getAlpha() / 255.0F).endVertex();
/* 108 */     bufferbuilder.pos(b.x, b.y, getZLevel()).color(c2.getRed() / 255.0F, c2.getGreen() / 255.0F, c2.getBlue() / 255.0F, c2.getAlpha() / 255.0F).endVertex();
/* 109 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillRect(Rectangle r, Color c1, Color c2, Color c3, Color c4) {
/* 114 */     Tessellator tessellator = Tessellator.getInstance();
/* 115 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 116 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/* 117 */     bufferbuilder.pos(r.x, (r.y + r.height), getZLevel()).color(c4.getRed() / 255.0F, c4.getGreen() / 255.0F, c4.getBlue() / 255.0F, c4.getAlpha() / 255.0F).endVertex();
/* 118 */     bufferbuilder.pos((r.x + r.width), (r.y + r.height), getZLevel()).color(c3.getRed() / 255.0F, c3.getGreen() / 255.0F, c3.getBlue() / 255.0F, c3.getAlpha() / 255.0F).endVertex();
/* 119 */     bufferbuilder.pos((r.x + r.width), r.y, getZLevel()).color(c2.getRed() / 255.0F, c2.getGreen() / 255.0F, c2.getBlue() / 255.0F, c2.getAlpha() / 255.0F).endVertex();
/* 120 */     bufferbuilder.pos(r.x, r.y, getZLevel()).color(c1.getRed() / 255.0F, c1.getGreen() / 255.0F, c1.getBlue() / 255.0F, c1.getAlpha() / 255.0F).endVertex();
/* 121 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawRect(Rectangle r, Color c1, Color c2, Color c3, Color c4) {
/* 126 */     Tessellator tessellator = Tessellator.getInstance();
/* 127 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 128 */     bufferbuilder.begin(2, DefaultVertexFormats.POSITION_COLOR);
/* 129 */     bufferbuilder.pos(r.x, (r.y + r.height), getZLevel()).color(c4.getRed() / 255.0F, c4.getGreen() / 255.0F, c4.getBlue() / 255.0F, c4.getAlpha() / 255.0F).endVertex();
/* 130 */     bufferbuilder.pos((r.x + r.width), (r.y + r.height), getZLevel()).color(c3.getRed() / 255.0F, c3.getGreen() / 255.0F, c3.getBlue() / 255.0F, c3.getAlpha() / 255.0F).endVertex();
/* 131 */     bufferbuilder.pos((r.x + r.width), r.y, getZLevel()).color(c2.getRed() / 255.0F, c2.getGreen() / 255.0F, c2.getBlue() / 255.0F, c2.getAlpha() / 255.0F).endVertex();
/* 132 */     bufferbuilder.pos(r.x, r.y, getZLevel()).color(c1.getRed() / 255.0F, c1.getGreen() / 255.0F, c1.getBlue() / 255.0F, c1.getAlpha() / 255.0F).endVertex();
/* 133 */     tessellator.draw();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int loadImage(String name) {
/*     */     try {
/* 139 */       ResourceLocation rl = new ResourceLocation(getResourcePrefix() + name);
/* 140 */       InputStream stream = Minecraft.getMinecraft().getResourceManager().getResource(rl).getInputStream();
/* 141 */       BufferedImage image = ImageIO.read(stream);
/* 142 */       int texture = TextureUtil.glGenTextures();
/* 143 */       TextureUtil.uploadTextureImage(texture, image);
/* 144 */       return texture;
/* 145 */     } catch (IOException e) {
/* 146 */       e.printStackTrace();
/* 147 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawImage(Rectangle r, int rotation, boolean parity, int image, Color color) {
/* 153 */     if (image == 0)
/* 154 */       return;  int[][] texCoords = { { 0, 1 }, { 1, 1 }, { 1, 0 }, { 0, 0 } };
/* 155 */     for (int i = 0; i < rotation % 4; i++) {
/* 156 */       int temp1 = texCoords[3][0], temp2 = texCoords[3][1];
/* 157 */       texCoords[3][0] = texCoords[2][0];
/* 158 */       texCoords[3][1] = texCoords[2][1];
/* 159 */       texCoords[2][0] = texCoords[1][0];
/* 160 */       texCoords[2][1] = texCoords[1][1];
/* 161 */       texCoords[1][0] = texCoords[0][0];
/* 162 */       texCoords[1][1] = texCoords[0][1];
/* 163 */       texCoords[0][0] = temp1;
/* 164 */       texCoords[0][1] = temp2;
/*     */     } 
/* 166 */     if (parity) {
/* 167 */       int temp1 = texCoords[3][0], temp2 = texCoords[3][1];
/* 168 */       texCoords[3][0] = texCoords[0][0];
/* 169 */       texCoords[3][1] = texCoords[0][1];
/* 170 */       texCoords[0][0] = temp1;
/* 171 */       texCoords[0][1] = temp2;
/* 172 */       temp1 = texCoords[2][0];
/* 173 */       temp2 = texCoords[2][1];
/* 174 */       texCoords[2][0] = texCoords[1][0];
/* 175 */       texCoords[2][1] = texCoords[1][1];
/* 176 */       texCoords[1][0] = temp1;
/* 177 */       texCoords[1][1] = temp2;
/*     */     } 
/* 179 */     Tessellator tessellator = Tessellator.getInstance();
/* 180 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 181 */     FloatBuffer colorBuffer = GLAllocation.createDirectFloatBuffer(4);
/* 182 */     colorBuffer.put(0, color.getRed() / 255.0F);
/* 183 */     colorBuffer.put(1, color.getGreen() / 255.0F);
/* 184 */     colorBuffer.put(2, color.getBlue() / 255.0F);
/* 185 */     colorBuffer.put(3, color.getAlpha() / 255.0F);
/* 186 */     GlStateManager.bindTexture(image);
/* 187 */     GlStateManager.glTexEnv(8960, 8705, colorBuffer);
/* 188 */     GlStateManager.enableTexture2D();
/* 189 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
/* 190 */     bufferbuilder.pos(r.x, (r.y + r.height), getZLevel()).tex(texCoords[0][0], texCoords[0][1]).endVertex();
/* 191 */     bufferbuilder.pos((r.x + r.width), (r.y + r.height), getZLevel()).tex(texCoords[1][0], texCoords[1][1]).endVertex();
/* 192 */     bufferbuilder.pos((r.x + r.width), r.y, getZLevel()).tex(texCoords[2][0], texCoords[2][1]).endVertex();
/* 193 */     bufferbuilder.pos(r.x, r.y, getZLevel()).tex(texCoords[3][0], texCoords[3][1]).endVertex();
/* 194 */     tessellator.draw();
/* 195 */     GlStateManager.disableTexture2D();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void scissor(Rectangle r) {
/* 203 */     if (r == null) {
/* 204 */       GL11.glScissor(0, 0, 0, 0);
/* 205 */       GL11.glEnable(3089);
/*     */       return;
/*     */     } 
/* 208 */     Point a = guiToScreen(r.getLocation()), b = guiToScreen(new Point(r.x + r.width, r.y + r.height));
/* 209 */     if (!this.clipX) {
/* 210 */       a.x = 0;
/* 211 */       b.x = (Minecraft.getMinecraft()).displayWidth;
/*     */     } 
/* 213 */     GL11.glScissor(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
/* 214 */     GL11.glEnable(3089);
/*     */   }
/*     */ 
/*     */   
/*     */   public void window(Rectangle r) {
/* 219 */     if (this.clipRect.isEmpty()) {
/* 220 */       scissor(r);
/* 221 */       this.clipRect.push(r);
/*     */     } else {
/* 223 */       Rectangle top = this.clipRect.peek();
/* 224 */       if (top == null) {
/* 225 */         scissor(null);
/* 226 */         this.clipRect.push((Rectangle)null);
/*     */       } else {
/*     */         
/* 229 */         int x1 = Math.max(r.x, top.x);
/* 230 */         int y1 = Math.max(r.y, top.y);
/* 231 */         int x2 = Math.min(r.x + r.width, top.x + top.width);
/* 232 */         int y2 = Math.min(r.y + r.height, top.y + top.height);
/* 233 */         if (x2 > x1 && y2 > y1) {
/* 234 */           Rectangle rect = new Rectangle(x1, y1, x2 - x1, y2 - y1);
/* 235 */           scissor(rect);
/* 236 */           this.clipRect.push(rect);
/*     */         } else {
/* 238 */           scissor(null);
/* 239 */           this.clipRect.push((Rectangle)null);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void restore() {
/* 247 */     if (!this.clipRect.isEmpty()) {
/* 248 */       this.clipRect.pop();
/* 249 */       if (this.clipRect.isEmpty()) { GL11.glDisable(3089); }
/* 250 */       else { scissor(this.clipRect.peek()); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point screenToGui(Point p) {
/* 260 */     int resX = (getWindowSize()).width;
/* 261 */     int resY = (getWindowSize()).height;
/* 262 */     return new Point(p.x * resX / (Minecraft.getMinecraft()).displayWidth, resY - p.y * resY / (Minecraft.getMinecraft()).displayHeight - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point guiToScreen(Point p) {
/* 271 */     double resX = getScreenWidth();
/* 272 */     double resY = getScreenHeight();
/* 273 */     return new Point((int)Math.round((p.x * (Minecraft.getMinecraft()).displayWidth) / resX), (int)Math.round((resY - p.y) * (Minecraft.getMinecraft()).displayHeight / resY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double getScreenWidth() {
/* 281 */     return (new ScaledResolution(Minecraft.getMinecraft())).getScaledWidth_double();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double getScreenHeight() {
/* 289 */     return (new ScaledResolution(Minecraft.getMinecraft())).getScaledHeight_double();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin(boolean matrix) {
/* 298 */     if (matrix) {
/* 299 */       GlStateManager.matrixMode(5889);
/* 300 */       GlStateManager.pushMatrix();
/* 301 */       GlStateManager.loadIdentity();
/* 302 */       GlStateManager.ortho(0.0D, getScreenWidth(), getScreenHeight(), 0.0D, -3000.0D, 3000.0D);
/* 303 */       GlStateManager.matrixMode(5888);
/* 304 */       GlStateManager.pushMatrix();
/* 305 */       GlStateManager.loadIdentity();
/*     */     } 
/* 307 */     GlStateManager.enableBlend();
/* 308 */     GlStateManager.disableTexture2D();
/* 309 */     GlStateManager.disableAlpha();
/* 310 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 311 */     GlStateManager.shadeModel(7425);
/* 312 */     GlStateManager.glLineWidth(2.0F);
/*     */     
/* 314 */     GL11.glPushAttrib(262144);
/* 315 */     GlStateManager.glTexEnvi(8960, 8704, 34160);
/*     */     
/* 317 */     GlStateManager.glTexEnvi(8960, 34161, 8448);
/* 318 */     GlStateManager.glTexEnvi(8960, 34162, 8448);
/*     */     
/* 320 */     GlStateManager.glTexEnvi(8960, 34176, 5890);
/* 321 */     GlStateManager.glTexEnvi(8960, 34192, 768);
/* 322 */     GlStateManager.glTexEnvi(8960, 34184, 5890);
/* 323 */     GlStateManager.glTexEnvi(8960, 34200, 770);
/*     */     
/* 325 */     GlStateManager.glTexEnvi(8960, 34177, 34166);
/* 326 */     GlStateManager.glTexEnvi(8960, 34193, 768);
/* 327 */     GlStateManager.glTexEnvi(8960, 34185, 34166);
/* 328 */     GlStateManager.glTexEnvi(8960, 34201, 770);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end(boolean matrix) {
/* 337 */     GL11.glPopAttrib();
/* 338 */     GlStateManager.shadeModel(7424);
/* 339 */     GlStateManager.enableAlpha();
/* 340 */     GlStateManager.enableTexture2D();
/* 341 */     GlStateManager.disableBlend();
/* 342 */     if (matrix) {
/* 343 */       GlStateManager.matrixMode(5889);
/* 344 */       GlStateManager.popMatrix();
/* 345 */       GlStateManager.matrixMode(5888);
/* 346 */       GlStateManager.popMatrix();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract float getZLevel();
/*     */   
/*     */   protected abstract String getResourcePrefix();
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\mc12\GLInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
