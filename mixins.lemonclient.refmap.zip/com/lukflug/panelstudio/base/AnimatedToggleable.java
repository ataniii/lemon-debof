/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AnimatedToggleable
/*    */   implements IToggleable
/*    */ {
/*    */   private final IToggleable toggle;
/*    */   private final Animation animation;
/*    */   
/*    */   public AnimatedToggleable(IToggleable toggle, Animation animation) {
/* 23 */     if (toggle != null) { this.toggle = toggle; }
/* 24 */     else { this.toggle = new SimpleToggleable(false); }
/* 25 */      if (animation != null) { this.animation = animation; }
/* 26 */     else { this.animation = new Animation(System::currentTimeMillis)
/*    */         {
/*    */           protected int getSpeed() {
/* 29 */             return 0; }
/*    */         }; }
/*    */     
/* 32 */     if (this.toggle.isOn()) { this.animation.initValue(1.0D); }
/* 33 */     else { this.animation.initValue(0.0D); }
/*    */   
/*    */   }
/*    */   
/*    */   public void toggle() {
/* 38 */     this.toggle.toggle();
/* 39 */     if (this.toggle.isOn()) { this.animation.setValue(1.0D); }
/* 40 */     else { this.animation.setValue(0.0D); }
/*    */   
/*    */   }
/*    */   
/*    */   public boolean isOn() {
/* 45 */     return this.toggle.isOn();
/*    */   }
/*    */   
/*    */   public double getValue() {
/* 49 */     if (this.animation.getTarget() != (this.toggle.isOn() ? true : false))
/* 50 */       if (this.toggle.isOn()) { this.animation.setValue(1.0D); }
/* 51 */       else { this.animation.setValue(0.0D); }
/*    */        
/* 53 */     return this.animation.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\AnimatedToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */