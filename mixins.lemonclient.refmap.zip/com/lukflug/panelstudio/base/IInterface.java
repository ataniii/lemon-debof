/*     */ package com.lukflug.panelstudio.base;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IInterface
/*     */ {
/*     */   public static final int LBUTTON = 0;
/*     */   public static final int RBUTTON = 1;
/*     */   public static final int SHIFT = 0;
/*     */   public static final int CTRL = 1;
/*     */   public static final int ALT = 2;
/*     */   public static final int SUPER = 3;
/*     */   
/*     */   long getTime();
/*     */   
/*     */   Point getMouse();
/*     */   
/*     */   boolean getButton(int paramInt);
/*     */   
/*     */   boolean getModifier(int paramInt);
/*     */   
/*     */   void drawString(Point paramPoint, int paramInt, String paramString, Color paramColor);
/*     */   
/*     */   int getFontWidth(int paramInt, String paramString);
/*     */   
/*     */   void fillTriangle(Point paramPoint1, Point paramPoint2, Point paramPoint3, Color paramColor1, Color paramColor2, Color paramColor3);
/*     */   
/*     */   void drawLine(Point paramPoint1, Point paramPoint2, Color paramColor1, Color paramColor2);
/*     */   
/*     */   void fillRect(Rectangle paramRectangle, Color paramColor1, Color paramColor2, Color paramColor3, Color paramColor4);
/*     */   
/*     */   void drawRect(Rectangle paramRectangle, Color paramColor1, Color paramColor2, Color paramColor3, Color paramColor4);
/*     */   
/*     */   int loadImage(String paramString);
/*     */   
/*     */   default void drawImage(Rectangle r, int rotation, boolean parity, int image) {
/* 140 */     drawImage(r, rotation, parity, image, new Color(255, 255, 255));
/*     */   }
/*     */   
/*     */   void drawImage(Rectangle paramRectangle, int paramInt1, boolean paramBoolean, int paramInt2, Color paramColor);
/*     */   
/*     */   Dimension getWindowSize();
/*     */   
/*     */   void window(Rectangle paramRectangle);
/*     */   
/*     */   void restore();
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\IInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */