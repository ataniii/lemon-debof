/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ import java.util.function.BooleanSupplier;
/*    */ import java.util.function.Predicate;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface IBoolean
/*    */   extends BooleanSupplier, Supplier<Boolean>, Predicate<Void>
/*    */ {
/*    */   default boolean getAsBoolean() {
/* 21 */     return isOn();
/*    */   }
/*    */ 
/*    */   
/*    */   default Boolean get() {
/* 26 */     return Boolean.valueOf(isOn());
/*    */   }
/*    */ 
/*    */   
/*    */   default boolean test(Void t) {
/* 31 */     return isOn();
/*    */   }
/*    */   
/*    */   boolean isOn();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\IBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */