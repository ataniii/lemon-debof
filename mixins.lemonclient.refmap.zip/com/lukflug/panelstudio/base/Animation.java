/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Animation
/*    */ {
/*    */   protected final Supplier<Long> time;
/*    */   protected double value;
/*    */   protected double lastValue;
/*    */   protected long lastTime;
/*    */   
/*    */   public Animation(Supplier<Long> time) {
/* 28 */     this.time = time;
/* 29 */     this.lastTime = ((Long)time.get()).longValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initValue(double value) {
/* 37 */     this.value = value;
/* 38 */     this.lastValue = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getValue() {
/* 46 */     if (getSpeed() == 0) return this.value; 
/* 47 */     double weight = (((Long)this.time.get()).longValue() - this.lastTime) / getSpeed();
/* 48 */     if (weight >= 1.0D) return this.value; 
/* 49 */     if (weight <= 0.0D) return this.lastValue; 
/* 50 */     weight = interpolate(weight);
/* 51 */     return this.value * weight + this.lastValue * (1.0D - weight);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getTarget() {
/* 59 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(double value) {
/* 67 */     this.lastValue = getValue();
/* 68 */     this.value = value;
/* 69 */     this.lastTime = ((Long)this.time.get()).longValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected double interpolate(double weight) {
/* 77 */     return (weight - 1.0D) * (weight - 1.0D) * (weight - 1.0D) + 1.0D;
/*    */   }
/*    */   
/*    */   protected abstract int getSpeed();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\Animation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */