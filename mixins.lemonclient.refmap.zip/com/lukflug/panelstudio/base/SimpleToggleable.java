/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleToggleable
/*    */   extends ConstantToggleable
/*    */ {
/*    */   public SimpleToggleable(boolean value) {
/* 13 */     super(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void toggle() {
/* 18 */     this.value = !this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\SimpleToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */