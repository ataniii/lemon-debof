/*     */ package com.lukflug.panelstudio.base;
/*     */ 
/*     */ import com.lukflug.panelstudio.popup.IPopupDisplayer;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Context
/*     */ {
/*     */   private final IInterface inter;
/*     */   private final Dimension size;
/*     */   private final Point position;
/*     */   private final boolean focus;
/*     */   private final boolean onTop;
/*     */   private boolean focusRequested = false;
/*     */   private boolean focusOverride = false;
/*  49 */   private Description description = null;
/*  50 */   private IPopupDisplayer popupDisplayer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context(Context context, int width, Point offset, boolean focus, boolean onTop) {
/*  62 */     this.inter = context.getInterface();
/*  63 */     this.size = new Dimension(width, 0);
/*  64 */     this.position = context.getPos();
/*  65 */     this.position.translate(offset.x, offset.y);
/*  66 */     this.focus = (context.hasFocus() && focus);
/*  67 */     this.onTop = (context.onTop() && onTop);
/*  68 */     this.popupDisplayer = context.getPopupDisplayer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Context(IInterface inter, int width, Point position, boolean focus, boolean onTop) {
/*  80 */     this.inter = inter;
/*  81 */     this.size = new Dimension(width, 0);
/*  82 */     this.position = new Point(position);
/*  83 */     this.focus = focus;
/*  84 */     this.onTop = onTop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IInterface getInterface() {
/*  92 */     return this.inter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 100 */     return new Dimension(this.size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeight(int height) {
/* 108 */     this.size.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getPos() {
/* 116 */     return new Point(this.position);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 124 */     return this.focus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onTop() {
/* 132 */     return this.onTop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestFocus() {
/* 139 */     if (!this.focusOverride) this.focusRequested = true;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseFocus() {
/* 146 */     this.focusRequested = false;
/* 147 */     this.focusOverride = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean foucsRequested() {
/* 155 */     return (this.focusRequested && !this.focusOverride);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean focusReleased() {
/* 163 */     return this.focusOverride;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHovered() {
/* 171 */     return ((new Rectangle(this.position, this.size)).contains(this.inter.getMouse()) && this.onTop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClicked(int button) {
/* 179 */     return (isHovered() && this.inter.getButton(button));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getRect() {
/* 187 */     return new Rectangle(this.position, this.size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Description getDescription() {
/* 195 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(Description description) {
/* 203 */     this.description = description;
/*     */   }
/*     */   
/*     */   public IPopupDisplayer getPopupDisplayer() {
/* 207 */     return this.popupDisplayer;
/*     */   }
/*     */   
/*     */   public void setPopupDisplayer(IPopupDisplayer popupDisplayer) {
/* 211 */     this.popupDisplayer = popupDisplayer;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */