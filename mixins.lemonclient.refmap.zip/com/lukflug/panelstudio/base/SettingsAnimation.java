/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SettingsAnimation
/*    */   extends Animation
/*    */ {
/*    */   protected final Supplier<Integer> speed;
/*    */   
/*    */   public SettingsAnimation(Supplier<Integer> speed, Supplier<Long> time) {
/* 20 */     super(time);
/* 21 */     this.speed = speed;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getSpeed() {
/* 26 */     return ((Integer)this.speed.get()).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\SettingsAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */