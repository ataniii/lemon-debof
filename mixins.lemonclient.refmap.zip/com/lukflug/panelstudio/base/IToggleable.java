package com.lukflug.panelstudio.base;

public interface IToggleable extends IBoolean {
  void toggle();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\IToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */