/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Description
/*    */ {
/*    */   private final Rectangle componentPos;
/*    */   private final Rectangle panelPos;
/*    */   private final String content;
/*    */   
/*    */   public Description(Rectangle position, String content) {
/* 29 */     this.componentPos = position;
/* 30 */     this.panelPos = position;
/* 31 */     this.content = content;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Description(Description description, Rectangle position) {
/* 40 */     this.componentPos = description.componentPos;
/* 41 */     this.panelPos = position;
/* 42 */     this.content = description.content;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle getComponentPos() {
/* 50 */     return this.componentPos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle getPanelPos() {
/* 58 */     return this.panelPos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContent() {
/* 66 */     return this.content;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\Description.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */