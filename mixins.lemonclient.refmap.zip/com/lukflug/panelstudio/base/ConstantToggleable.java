/*    */ package com.lukflug.panelstudio.base;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantToggleable
/*    */   implements IToggleable
/*    */ {
/*    */   protected boolean value;
/*    */   
/*    */   public ConstantToggleable(boolean value) {
/* 18 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOn() {
/* 23 */     return this.value;
/*    */   }
/*    */   
/*    */   public void toggle() {}
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\base\ConstantToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */