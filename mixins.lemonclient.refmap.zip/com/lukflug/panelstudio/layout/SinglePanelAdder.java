/*    */ package com.lukflug.panelstudio.layout;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IBoolean;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*    */ import com.lukflug.panelstudio.component.HorizontalComponent;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.component.IResizable;
/*    */ import com.lukflug.panelstudio.component.IScrollSize;
/*    */ import com.lukflug.panelstudio.container.HorizontalContainer;
/*    */ import com.lukflug.panelstudio.container.IContainer;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.theme.IEmptySpaceRenderer;
/*    */ import com.lukflug.panelstudio.theme.IScrollBarRenderer;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import com.lukflug.panelstudio.theme.RendererTuple;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.ResizableComponent;
/*    */ import com.lukflug.panelstudio.widget.ScrollBarComponent;
/*    */ import java.awt.Point;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class SinglePanelAdder implements IComponentAdder {
/*    */   protected IContainer<? super IFixedComponent> container;
/*    */   protected IBoolean isVisible;
/*    */   
/*    */   public SinglePanelAdder(IContainer<? super IFixedComponent> container, ILabeled label, ITheme theme, Point position, int width, Supplier<Animation> animation, IBoolean isVisible, String configName) {
/* 32 */     this.container = container;
/* 33 */     this.isVisible = isVisible;
/* 34 */     this.title = new HorizontalContainer(label, theme.getContainerRenderer(-1, -1, true));
/* 35 */     this.content = new HorizontalContainer(label, theme.getContainerRenderer(-1, -1, true));
/* 36 */     AnimatedToggleable toggle = new AnimatedToggleable((IToggleable)new SimpleToggleable(true), animation.get());
/* 37 */     RendererTuple<Void> renderer = new RendererTuple(Void.class, new ThemeTuple(theme, -1, -1));
/* 38 */     IResizable size = getResizable(width);
/* 39 */     this.size = getScrollSize(size);
/* 40 */     container.addComponent((IComponent)ResizableComponent.createResizableComponent((IComponent)this.title, (IComponent)this.content, () -> null, toggle, renderer, theme.getResizeRenderer(), size, new IScrollSize()
/*    */           {
/*    */             public int getComponentWidth(Context context) {
/* 43 */               return SinglePanelAdder.this.size.getComponentWidth(context);
/*    */             }
/*    */           },  position, width, true, configName), isVisible);
/*    */   }
/*    */   protected HorizontalContainer title; protected HorizontalContainer content; protected final IScrollSize size;
/*    */   
/*    */   public <S extends IComponent, T extends IComponent> void addComponent(S title, T content, ThemeTuple theme, Point position, int width, Supplier<Animation> animation) {
/* 50 */     this.title.addComponent((IComponent)new HorizontalComponent((IComponent)title, 0, 1));
/* 51 */     this.content.addComponent((IComponent)new HorizontalComponent((IComponent)new ScrollBarComponent<Void, T>((IComponent)content, theme.getScrollBarRenderer(Void.class), theme.getEmptySpaceRenderer(Void.class, false), theme.getEmptySpaceRenderer(Void.class, true))
/*    */           {
/*    */             public int getScrollHeight(Context context, int componentHeight) {
/* 54 */               return SinglePanelAdder.this.size.getScrollHeight(context, componentHeight);
/*    */             }
/*    */ 
/*    */             
/*    */             protected Void getState() {
/* 59 */               return null;
/*    */             }
/*    */           }0, 1));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addPopup(IFixedComponent popup) {
/* 66 */     this.container.addComponent((IComponent)popup, this.isVisible);
/*    */   }
/*    */   
/*    */   protected IResizable getResizable(int width) {
/* 70 */     return null;
/*    */   }
/*    */   
/*    */   protected IScrollSize getScrollSize(IResizable size) {
/* 74 */     return new IScrollSize() {
/*    */       
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\SinglePanelAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */