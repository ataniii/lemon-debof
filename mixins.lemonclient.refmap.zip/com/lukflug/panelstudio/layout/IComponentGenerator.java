/*     */ package com.lukflug.panelstudio.layout;
/*     */ import com.lukflug.panelstudio.base.Animation;
/*     */ import com.lukflug.panelstudio.base.IToggleable;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.setting.IBooleanSetting;
/*     */ import com.lukflug.panelstudio.setting.IColorSetting;
/*     */ import com.lukflug.panelstudio.setting.IEnumSetting;
/*     */ import com.lukflug.panelstudio.setting.IKeybindSetting;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.INumberSetting;
/*     */ import com.lukflug.panelstudio.setting.ISetting;
/*     */ import com.lukflug.panelstudio.setting.IStringSetting;
/*     */ import com.lukflug.panelstudio.theme.ITextFieldRenderer;
/*     */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*     */ import com.lukflug.panelstudio.widget.Button;
/*     */ import com.lukflug.panelstudio.widget.ColorSliderComponent;
/*     */ import com.lukflug.panelstudio.widget.CycleButton;
/*     */ import com.lukflug.panelstudio.widget.ITextFieldKeys;
/*     */ import com.lukflug.panelstudio.widget.KeybindComponent;
/*     */ import com.lukflug.panelstudio.widget.NumberSlider;
/*     */ import com.lukflug.panelstudio.widget.TextField;
/*     */ import com.lukflug.panelstudio.widget.ToggleButton;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ public interface IComponentGenerator {
/*     */   default IComponent getComponent(ISetting<?> setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  27 */     if (setting instanceof IBooleanSetting)
/*  28 */       return getBooleanComponent((IBooleanSetting)setting, animation, adder, theme, colorLevel, isContainer); 
/*  29 */     if (setting instanceof INumberSetting)
/*  30 */       return getNumberComponent((INumberSetting)setting, animation, adder, theme, colorLevel, isContainer); 
/*  31 */     if (setting instanceof IEnumSetting)
/*  32 */       return getEnumComponent((IEnumSetting)setting, animation, adder, theme, colorLevel, isContainer); 
/*  33 */     if (setting instanceof IColorSetting)
/*  34 */       return getColorComponent((IColorSetting)setting, animation, adder, theme, colorLevel, isContainer); 
/*  35 */     if (setting instanceof IKeybindSetting)
/*  36 */       return getKeybindComponent((IKeybindSetting)setting, animation, adder, theme, colorLevel, isContainer); 
/*  37 */     if (setting instanceof IStringSetting) {
/*  38 */       return getStringComponent((IStringSetting)setting, animation, adder, theme, colorLevel, isContainer);
/*     */     }
/*  40 */     return (IComponent)new Button((ILabeled)setting, () -> null, theme.getButtonRenderer(Void.class, isContainer));
/*     */   }
/*     */ 
/*     */   
/*     */   default IComponent getBooleanComponent(IBooleanSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  45 */     return (IComponent)new ToggleButton(setting, theme.getButtonRenderer(Boolean.class, isContainer));
/*     */   }
/*     */   
/*     */   default IComponent getNumberComponent(INumberSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  49 */     return (IComponent)new NumberSlider(setting, theme.getSliderRenderer(isContainer));
/*     */   }
/*     */   
/*     */   default IComponent getEnumComponent(IEnumSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  53 */     return (IComponent)new CycleButton(setting, theme.getButtonRenderer(String.class, isContainer));
/*     */   }
/*     */   
/*     */   default IComponent getColorComponent(IColorSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  57 */     return (IComponent)new ColorSliderComponent(setting, new ThemeTuple(theme.theme, theme.logicalLevel, colorLevel));
/*     */   }
/*     */   
/*     */   default IComponent getKeybindComponent(IKeybindSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  61 */     return (IComponent)new KeybindComponent(setting, theme.getKeybindRenderer(isContainer));
/*     */   }
/*     */   
/*     */   default IComponent getStringComponent(IStringSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/*  65 */     return (IComponent)new TextField(setting, new ITextFieldKeys()
/*     */         {
/*     */           public boolean isBackspaceKey(int scancode) {
/*  68 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isDeleteKey(int scancode) {
/*  73 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isInsertKey(int scancode) {
/*  78 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isLeftKey(int scancode) {
/*  83 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isRightKey(int scancode) {
/*  88 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isHomeKey(int scancode) {
/*  93 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isEndKey(int scancode) {
/*  98 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isCopyKey(int scancode) {
/* 103 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isPasteKey(int scancode) {
/* 108 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isCutKey(int scancode) {
/* 113 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isAllKey(int scancode) {
/* 118 */             return false;
/*     */           }
/* 120 */         },  0, (IToggleable)new SimpleToggleable(false), theme.getTextRenderer(false, isContainer))
/*     */       {
/*     */         public boolean allowCharacter(char character) {
/* 123 */           return false;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\IComponentGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */