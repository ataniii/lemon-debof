/*     */ package com.lukflug.panelstudio.layout;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Animation;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.component.HorizontalComponent;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.component.IHorizontalComponent;
/*     */ import com.lukflug.panelstudio.component.IScrollSize;
/*     */ import com.lukflug.panelstudio.container.HorizontalContainer;
/*     */ import com.lukflug.panelstudio.container.IContainer;
/*     */ import com.lukflug.panelstudio.container.VerticalContainer;
/*     */ import com.lukflug.panelstudio.popup.PopupTuple;
/*     */ import com.lukflug.panelstudio.setting.IBooleanSetting;
/*     */ import com.lukflug.panelstudio.setting.ICategory;
/*     */ import com.lukflug.panelstudio.setting.IClient;
/*     */ import com.lukflug.panelstudio.setting.IEnumSetting;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.IModule;
/*     */ import com.lukflug.panelstudio.setting.ISetting;
/*     */ import com.lukflug.panelstudio.theme.IEmptySpaceRenderer;
/*     */ import com.lukflug.panelstudio.theme.IRadioRenderer;
/*     */ import com.lukflug.panelstudio.theme.IScrollBarRenderer;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*     */ import com.lukflug.panelstudio.widget.Button;
/*     */ import com.lukflug.panelstudio.widget.RadioButton;
/*     */ import com.lukflug.panelstudio.widget.ScrollBarComponent;
/*     */ import com.lukflug.panelstudio.widget.ToggleButton;
/*     */ import java.awt.Point;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ public class CSGOLayout
/*     */   implements ILayout, IScrollSize {
/*     */   protected ILabeled label;
/*     */   protected Point position;
/*     */   protected int width;
/*     */   protected Supplier<Animation> animation;
/*     */   protected String enabledButton;
/*     */   
/*     */   public CSGOLayout(ILabeled label, Point position, int width, int popupWidth, Supplier<Animation> animation, String enabledButton, boolean horizontal, boolean moduleColumn, int weight, ChildUtil.ChildMode colorType, PopupTuple popupType) {
/*  44 */     this.label = label;
/*  45 */     this.position = position;
/*  46 */     this.width = width;
/*  47 */     this.animation = animation;
/*  48 */     this.enabledButton = enabledButton;
/*  49 */     this.horizontal = horizontal;
/*  50 */     this.moduleColumn = moduleColumn;
/*  51 */     this.weight = weight;
/*  52 */     this.colorType = colorType;
/*  53 */     this.util = new ChildUtil(popupWidth, animation, popupType);
/*     */   }
/*     */   protected boolean horizontal; protected boolean moduleColumn; protected int weight; protected ChildUtil.ChildMode colorType; protected ChildUtil util;
/*     */   public void populateGUI(IComponentAdder gui, IComponentGenerator components, IClient client, ITheme theme) {
/*     */     IEnumSetting catSelect;
/*  58 */     Button<Void> title = new Button(this.label, () -> null, theme.getButtonRenderer(Void.class, 0, 0, true));
/*  59 */     HorizontalContainer window = new HorizontalContainer(this.label, theme.getContainerRenderer(0, this.horizontal ? 1 : 0, true));
/*     */     
/*  61 */     if (this.horizontal) {
/*  62 */       VerticalContainer container = new VerticalContainer(this.label, theme.getContainerRenderer(0, 0, false));
/*  63 */       catSelect = addContainer(this.label, client.getCategories().map(cat -> cat), (IContainer<IComponent>)container, new ThemeTuple(theme, 0, 1), true, button -> button, () -> true);
/*  64 */       container.addComponent((IComponent)window);
/*  65 */       gui.addComponent(title, container, new ThemeTuple(theme, 0, 0), this.position, this.width, this.animation);
/*     */     } else {
/*  67 */       catSelect = addContainer(this.label, client.getCategories().map(cat -> cat), (IContainer<IComponent>)window, new ThemeTuple(theme, 0, 1), false, button -> wrapColumn((IComponent)button, new ThemeTuple(theme, 0, 1), 1), () -> true);
/*  68 */       gui.addComponent(title, window, new ThemeTuple(theme, 0, 0), this.position, this.width, this.animation);
/*     */     } 
/*  70 */     client.getCategories().forEach(category -> {
/*     */           if (this.moduleColumn) {
/*     */             IEnumSetting modSelect = addContainer((ILabeled)category, category.getModules().map(()), (IContainer<IComponent>)window, new ThemeTuple(theme, 1, 1), false, (), ());
/*     */             category.getModules().forEach(());
/*     */           } else {
/*     */             VerticalContainer categoryContent = new VerticalContainer((ILabeled)category, theme.getContainerRenderer(0, 1, false));
/*     */             window.addComponent((IComponent)wrapColumn((IComponent)categoryContent, new ThemeTuple(theme, 0, 1), 1), ());
/*     */             category.getModules().forEach(());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> void addSettingsComponent(ISetting<T> setting, VerticalContainer container, IComponentAdder gui, IComponentGenerator components, ThemeTuple theme) {
/* 112 */     int colorLevel = (this.colorType == ChildUtil.ChildMode.DOWN) ? theme.graphicalLevel : 0;
/* 113 */     boolean isContainer = (setting.getSubSettings() != null);
/* 114 */     IComponent component = components.getComponent(setting, this.animation, gui, theme, colorLevel, isContainer);
/* 115 */     if (component instanceof VerticalContainer) {
/* 116 */       VerticalContainer colorContainer = (VerticalContainer)component;
/* 117 */       Button<T> button = new Button((ILabeled)setting, () -> setting.getSettingState(), theme.getButtonRenderer(setting.getSettingClass(), (this.colorType == ChildUtil.ChildMode.DOWN)));
/* 118 */       this.util.addContainer((ILabeled)setting, (IComponent)button, (IComponent)colorContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, new ThemeTuple(theme.theme, theme.logicalLevel, colorLevel), this.colorType);
/* 119 */       if (setting.getSubSettings() != null) setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, colorContainer, gui, components, new ThemeTuple(theme.theme, theme.logicalLevel + 1, colorLevel + 1))); 
/* 120 */     } else if (setting.getSubSettings() != null) {
/* 121 */       VerticalContainer settingContainer = new VerticalContainer((ILabeled)setting, theme.getContainerRenderer(false));
/* 122 */       this.util.addContainer((ILabeled)setting, component, (IComponent)settingContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, theme, ChildUtil.ChildMode.DOWN);
/* 123 */       setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, settingContainer, gui, components, new ThemeTuple(theme, 1, 1)));
/*     */     } else {
/* 125 */       container.addComponent(component);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected <T extends IComponent> IEnumSetting addContainer(final ILabeled label, final Stream<ILabeled> labels, IContainer<T> window, ThemeTuple theme, boolean horizontal, Function<RadioButton, T> container, IBoolean visible) {
/* 130 */     IEnumSetting setting = new IEnumSetting()
/*     */       {
/*     */         private int state;
/*     */         private ILabeled[] array;
/*     */         
/*     */         public String getDisplayName() {
/* 136 */           return label.getDisplayName();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getDescription() {
/* 141 */           return label.getDescription();
/*     */         }
/*     */ 
/*     */         
/*     */         public IBoolean isVisible() {
/* 146 */           return label.isVisible();
/*     */         }
/*     */ 
/*     */         
/*     */         public void increment() {
/* 151 */           this.state = (this.state + 1) % this.array.length;
/*     */         }
/*     */ 
/*     */         
/*     */         public void decrement() {
/* 156 */           this.state--;
/* 157 */           if (this.state < 0) this.state = this.array.length - 1;
/*     */         
/*     */         }
/*     */         
/*     */         public String getValueName() {
/* 162 */           return this.array[this.state].getDisplayName();
/*     */         }
/*     */ 
/*     */         
/*     */         public void setValueIndex(int index) {
/* 167 */           this.state = index;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getValueIndex() {
/* 172 */           return this.state;
/*     */         }
/*     */ 
/*     */         
/*     */         public ILabeled[] getAllowedValues() {
/* 177 */           return this.array;
/*     */         }
/*     */       };
/* 180 */     RadioButton button = new RadioButton(setting, theme.getRadioRenderer(true), this.animation.get(), horizontal)
/*     */       {
/*     */         protected boolean isUpKey(int key) {
/* 183 */           if (this.horizontal) return CSGOLayout.this.isLeftKey(key); 
/* 184 */           return CSGOLayout.this.isUpKey(key);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isDownKey(int key) {
/* 189 */           if (this.horizontal) return CSGOLayout.this.isRightKey(key); 
/* 190 */           return CSGOLayout.this.isDownKey(key);
/*     */         }
/*     */       };
/* 193 */     window.addComponent((IComponent)container.apply(button), visible);
/* 194 */     return setting;
/*     */   }
/*     */   
/*     */   protected HorizontalComponent<ScrollBarComponent<Void, IComponent>> wrapColumn(IComponent button, ThemeTuple theme, int weight) {
/* 198 */     return new HorizontalComponent((IComponent)new ScrollBarComponent<Void, IComponent>(button, theme.getScrollBarRenderer(Void.class), theme.getEmptySpaceRenderer(Void.class, false), theme.getEmptySpaceRenderer(Void.class, true))
/*     */         {
/*     */           public int getScrollHeight(Context context, int componentHeight) {
/* 201 */             return CSGOLayout.this.getScrollHeight(context, componentHeight);
/*     */           }
/*     */ 
/*     */           
/*     */           protected Void getState() {
/* 206 */             return null;
/*     */           }
/*     */         }0, weight);
/*     */   }
/*     */   
/*     */   protected boolean isUpKey(int key) {
/* 212 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isDownKey(int key) {
/* 216 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isLeftKey(int key) {
/* 220 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isRightKey(int key) {
/* 224 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\CSGOLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */