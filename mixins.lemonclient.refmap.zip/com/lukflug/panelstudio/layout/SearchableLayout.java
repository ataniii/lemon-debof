/*     */ package com.lukflug.panelstudio.layout;
/*     */ 
/*     */ import com.lukflug.panelstudio.base.Animation;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.component.HorizontalComponent;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.component.IHorizontalComponent;
/*     */ import com.lukflug.panelstudio.component.IScrollSize;
/*     */ import com.lukflug.panelstudio.container.HorizontalContainer;
/*     */ import com.lukflug.panelstudio.container.IContainer;
/*     */ import com.lukflug.panelstudio.container.VerticalContainer;
/*     */ import com.lukflug.panelstudio.popup.PopupTuple;
/*     */ import com.lukflug.panelstudio.setting.IBooleanSetting;
/*     */ import com.lukflug.panelstudio.setting.ICategory;
/*     */ import com.lukflug.panelstudio.setting.IClient;
/*     */ import com.lukflug.panelstudio.setting.IEnumSetting;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.IModule;
/*     */ import com.lukflug.panelstudio.setting.ISetting;
/*     */ import com.lukflug.panelstudio.theme.IEmptySpaceRenderer;
/*     */ import com.lukflug.panelstudio.theme.IScrollBarRenderer;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*     */ import com.lukflug.panelstudio.widget.Button;
/*     */ import com.lukflug.panelstudio.widget.ITextFieldKeys;
/*     */ import com.lukflug.panelstudio.widget.ScrollBarComponent;
/*     */ import com.lukflug.panelstudio.widget.SearchableRadioButton;
/*     */ import java.awt.Point;
/*     */ import java.util.Comparator;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.IntPredicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ public class SearchableLayout
/*     */   implements ILayout, IScrollSize
/*     */ {
/*     */   protected ILabeled titleLabel;
/*     */   protected ILabeled searchLabel;
/*     */   protected Point position;
/*     */   protected int width;
/*     */   protected Supplier<Animation> animation;
/*     */   protected String enabledButton;
/*     */   
/*     */   public SearchableLayout(ILabeled titleLabel, ILabeled searchLabel, Point position, int width, int popupWidth, Supplier<Animation> animation, String enabledButton, int weight, ChildUtil.ChildMode colorType, PopupTuple popupType, Comparator<IModule> comparator, IntPredicate charFilter, ITextFieldKeys keys) {
/*  48 */     this.titleLabel = titleLabel;
/*  49 */     this.searchLabel = searchLabel;
/*  50 */     this.position = position;
/*  51 */     this.width = width;
/*  52 */     this.animation = animation;
/*  53 */     this.enabledButton = enabledButton;
/*  54 */     this.weight = weight;
/*  55 */     this.colorType = colorType;
/*  56 */     this.comparator = comparator;
/*  57 */     this.charFilter = charFilter;
/*  58 */     this.keys = keys;
/*  59 */     this.util = new ChildUtil(popupWidth, animation, popupType);
/*     */   }
/*     */   protected int weight; protected ChildUtil.ChildMode colorType; protected ChildUtil util; protected Comparator<IModule> comparator; protected IntPredicate charFilter; protected ITextFieldKeys keys;
/*     */   
/*     */   public void populateGUI(IComponentAdder gui, IComponentGenerator components, IClient client, ITheme theme) {
/*  64 */     Button<Void> title = new Button(this.titleLabel, () -> null, theme.getButtonRenderer(Void.class, 0, 0, true));
/*  65 */     HorizontalContainer window = new HorizontalContainer(this.titleLabel, theme.getContainerRenderer(0, 0, true));
/*  66 */     Supplier<Stream<IModule>> modules = () -> client.getCategories().flatMap(()).sorted(this.comparator);
/*  67 */     IEnumSetting modSelect = addContainer(this.searchLabel, ((Stream)modules.get()).map(mod -> mod), (IContainer<IComponent>)window, new ThemeTuple(theme, 0, 1), false, button -> wrapColumn((IComponent)button, new ThemeTuple(theme, 0, 1), 1), () -> true);
/*  68 */     gui.addComponent(title, window, new ThemeTuple(theme, 0, 0), this.position, this.width, this.animation);
/*  69 */     ((Stream)modules.get()).forEach(module -> {
/*     */           VerticalContainer container = new VerticalContainer((ILabeled)module, theme.getContainerRenderer(1, 1, false));
/*     */           window.addComponent((IComponent)wrapColumn((IComponent)container, new ThemeTuple(theme, 1, 1), this.weight), ());
/*     */           if (module.isEnabled() != null)
/*     */             container.addComponent(components.getComponent((ISetting<?>)new IBooleanSetting() {
/*     */                     public String getDisplayName() {
/*  75 */                       return SearchableLayout.this.enabledButton;
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public void toggle() {
/*  80 */                       module.isEnabled().toggle();
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public boolean isOn() {
/*  85 */                       return module.isEnabled().isOn();
/*     */                     }
/*     */                   },  this.animation, gui, new ThemeTuple(theme, 1, 2), 2, false)); 
/*     */           module.getSettings().forEach(());
/*     */         });
/*     */   }
/*     */   
/*     */   protected <T> void addSettingsComponent(ISetting<T> setting, VerticalContainer container, IComponentAdder gui, IComponentGenerator components, ThemeTuple theme) {
/*  93 */     int colorLevel = (this.colorType == ChildUtil.ChildMode.DOWN) ? theme.graphicalLevel : 0;
/*  94 */     boolean isContainer = (setting.getSubSettings() != null);
/*  95 */     IComponent component = components.getComponent(setting, this.animation, gui, theme, colorLevel, isContainer);
/*  96 */     if (component instanceof VerticalContainer) {
/*  97 */       VerticalContainer colorContainer = (VerticalContainer)component;
/*  98 */       Button<T> button = new Button((ILabeled)setting, () -> setting.getSettingState(), theme.getButtonRenderer(setting.getSettingClass(), (this.colorType == ChildUtil.ChildMode.DOWN)));
/*  99 */       this.util.addContainer((ILabeled)setting, (IComponent)button, (IComponent)colorContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, new ThemeTuple(theme.theme, theme.logicalLevel, colorLevel), this.colorType);
/* 100 */       if (setting.getSubSettings() != null) setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, colorContainer, gui, components, new ThemeTuple(theme.theme, theme.logicalLevel + 1, colorLevel + 1))); 
/* 101 */     } else if (setting.getSubSettings() != null) {
/* 102 */       VerticalContainer settingContainer = new VerticalContainer((ILabeled)setting, theme.getContainerRenderer(false));
/* 103 */       this.util.addContainer((ILabeled)setting, component, (IComponent)settingContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, theme, ChildUtil.ChildMode.DOWN);
/* 104 */       setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, settingContainer, gui, components, new ThemeTuple(theme, 1, 1)));
/*     */     } else {
/* 106 */       container.addComponent(component);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected <T extends IComponent> IEnumSetting addContainer(final ILabeled label, final Stream<ILabeled> labels, IContainer<T> window, ThemeTuple theme, final boolean horizontal, Function<SearchableRadioButton, T> container, IBoolean visible) {
/* 111 */     IEnumSetting setting = new IEnumSetting()
/*     */       {
/*     */         private int state;
/*     */         private ILabeled[] array;
/*     */         
/*     */         public String getDisplayName() {
/* 117 */           return label.getDisplayName();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getDescription() {
/* 122 */           return label.getDescription();
/*     */         }
/*     */ 
/*     */         
/*     */         public IBoolean isVisible() {
/* 127 */           return label.isVisible();
/*     */         }
/*     */ 
/*     */         
/*     */         public void increment() {
/* 132 */           this.state = (this.state + 1) % this.array.length;
/*     */         }
/*     */ 
/*     */         
/*     */         public void decrement() {
/* 137 */           this.state--;
/* 138 */           if (this.state < 0) this.state = this.array.length - 1;
/*     */         
/*     */         }
/*     */         
/*     */         public String getValueName() {
/* 143 */           return this.array[this.state].getDisplayName();
/*     */         }
/*     */ 
/*     */         
/*     */         public void setValueIndex(int index) {
/* 148 */           this.state = index;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getValueIndex() {
/* 153 */           return this.state;
/*     */         }
/*     */ 
/*     */         
/*     */         public ILabeled[] getAllowedValues() {
/* 158 */           return this.array;
/*     */         }
/*     */       };
/* 161 */     SearchableRadioButton button = new SearchableRadioButton(setting, theme, true, this.keys)
/*     */       {
/*     */         protected Animation getAnimation() {
/* 164 */           return SearchableLayout.this.animation.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean allowCharacter(char character) {
/* 169 */           return SearchableLayout.this.charFilter.test(character);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isUpKey(int key) {
/* 174 */           if (horizontal) return SearchableLayout.this.isLeftKey(key); 
/* 175 */           return SearchableLayout.this.isUpKey(key);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isDownKey(int key) {
/* 180 */           if (horizontal) return SearchableLayout.this.isRightKey(key); 
/* 181 */           return SearchableLayout.this.isDownKey(key);
/*     */         }
/*     */       };
/* 184 */     window.addComponent((IComponent)container.apply(button), visible);
/* 185 */     return setting;
/*     */   }
/*     */   
/*     */   protected HorizontalComponent<ScrollBarComponent<Void, IComponent>> wrapColumn(IComponent button, ThemeTuple theme, int weight) {
/* 189 */     return new HorizontalComponent((IComponent)new ScrollBarComponent<Void, IComponent>(button, theme.getScrollBarRenderer(Void.class), theme.getEmptySpaceRenderer(Void.class, false), theme.getEmptySpaceRenderer(Void.class, true))
/*     */         {
/*     */           public int getScrollHeight(Context context, int componentHeight) {
/* 192 */             return SearchableLayout.this.getScrollHeight(context, componentHeight);
/*     */           }
/*     */ 
/*     */           
/*     */           protected Void getState() {
/* 197 */             return null;
/*     */           }
/*     */         }0, weight);
/*     */   }
/*     */   
/*     */   protected boolean isUpKey(int key) {
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isDownKey(int key) {
/* 207 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isLeftKey(int key) {
/* 211 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isRightKey(int key) {
/* 215 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\SearchableLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */