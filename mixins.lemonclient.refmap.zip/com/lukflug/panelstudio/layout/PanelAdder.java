/*    */ package com.lukflug.panelstudio.layout;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.IBoolean;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.component.IResizable;
/*    */ import com.lukflug.panelstudio.component.IScrollSize;
/*    */ import com.lukflug.panelstudio.container.IContainer;
/*    */ import com.lukflug.panelstudio.theme.RendererTuple;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.ResizableComponent;
/*    */ import java.awt.Point;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.function.UnaryOperator;
/*    */ 
/*    */ public class PanelAdder implements IComponentAdder {
/*    */   protected IContainer<? super IFixedComponent> container;
/*    */   protected boolean open;
/*    */   protected IBoolean isVisible;
/*    */   protected UnaryOperator<String> configName;
/*    */   
/*    */   public PanelAdder(IContainer<? super IFixedComponent> container, boolean open, IBoolean isVisible, UnaryOperator<String> configName) {
/* 27 */     this.container = container;
/* 28 */     this.open = open;
/* 29 */     this.isVisible = isVisible;
/* 30 */     this.configName = configName;
/*    */   }
/*    */ 
/*    */   
/*    */   public <S extends IComponent, T extends IComponent> void addComponent(S title, T content, ThemeTuple theme, Point position, int width, Supplier<Animation> animation) {
/* 35 */     AnimatedToggleable toggle = new AnimatedToggleable((IToggleable)new SimpleToggleable(this.open), animation.get());
/* 36 */     RendererTuple<Void> renderer = new RendererTuple(Void.class, theme);
/* 37 */     IResizable size = getResizable(width);
/* 38 */     this.container.addComponent((IComponent)ResizableComponent.createResizableComponent((IComponent)title, (IComponent)content, () -> null, toggle, renderer, theme.theme.getResizeRenderer(), size, getScrollSize(size), position, width, true, this.configName.apply(content.getTitle())), this.isVisible);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addPopup(IFixedComponent popup) {
/* 43 */     this.container.addComponent((IComponent)popup, this.isVisible);
/*    */   }
/*    */   
/*    */   protected IResizable getResizable(int width) {
/* 47 */     return null;
/*    */   }
/*    */   
/*    */   protected IScrollSize getScrollSize(IResizable size) {
/* 51 */     return new IScrollSize() {
/*    */       
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\PanelAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */