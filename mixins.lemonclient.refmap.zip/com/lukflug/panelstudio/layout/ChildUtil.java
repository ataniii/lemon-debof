/*    */ package com.lukflug.panelstudio.layout;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*    */ import com.lukflug.panelstudio.component.ComponentProxy;
/*    */ import com.lukflug.panelstudio.component.DraggableComponent;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.component.PopupComponent;
/*    */ import com.lukflug.panelstudio.container.VerticalContainer;
/*    */ import com.lukflug.panelstudio.popup.IPopup;
/*    */ import com.lukflug.panelstudio.popup.PopupTuple;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.RendererTuple;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.Button;
/*    */ import com.lukflug.panelstudio.widget.ClosableComponent;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class ChildUtil
/*    */ {
/*    */   protected int width;
/*    */   
/*    */   public ChildUtil(int width, Supplier<Animation> animation, PopupTuple popupType) {
/* 29 */     this.width = width;
/* 30 */     this.animation = animation;
/* 31 */     this.popupType = popupType;
/*    */   } protected Supplier<Animation> animation; protected PopupTuple popupType;
/*    */   protected <T> void addContainer(ILabeled label, IComponent title, IComponent container, Supplier<T> state, Class<T> stateClass, VerticalContainer parent, IComponentAdder gui, ThemeTuple theme, ChildMode mode) {
/*    */     final SimpleToggleable toggle;
/*    */     Button<T> button;
/*    */     final DraggableComponent popup;
/* 37 */     boolean drawTitle = (mode == ChildMode.DRAG_POPUP);
/* 38 */     switch (mode) {
/*    */       case DOWN:
/* 40 */         parent.addComponent((IComponent)new ClosableComponent(title, container, state, new AnimatedToggleable((IToggleable)new SimpleToggleable(false), this.animation.get()), theme.getPanelRenderer(stateClass), false));
/*    */         break;
/*    */       case POPUP:
/*    */       case DRAG_POPUP:
/* 44 */         simpleToggleable = new SimpleToggleable(false);
/* 45 */         button = new Button((ILabeled)new Labeled(label.getDisplayName(), label.getDescription(), () -> (drawTitle && label.isVisible().isOn())), state, theme.getButtonRenderer(stateClass, true));
/* 46 */         if (this.popupType.dynamicPopup) { PopupComponent popupComponent = ClosableComponent.createDynamicPopup((IComponent)button, container, state, this.animation.get(), new RendererTuple(stateClass, theme), this.popupType.popupSize, (IToggleable)simpleToggleable, this.width); }
/* 47 */         else { draggableComponent = ClosableComponent.createStaticPopup((IComponent)button, container, state, this.animation.get(), new RendererTuple(stateClass, theme), this.popupType.popupSize, (IToggleable)simpleToggleable, () -> this.width, false, "", false); }
/* 48 */          parent.addComponent((IComponent)new ComponentProxy<IComponent>(title)
/*    */             {
/*    */               public void handleButton(Context context, int button) {
/* 51 */                 super.handleButton(context, button);
/* 52 */                 if (button == 1 && context.isClicked(button)) {
/* 53 */                   context.getPopupDisplayer().displayPopup((IPopup)popup, context.getRect(), toggle, ChildUtil.this.popupType.popupPos);
/* 54 */                   context.releaseFocus();
/*    */                 } 
/*    */               }
/*    */             });
/* 58 */         gui.addPopup((IFixedComponent)draggableComponent);
/*    */         break;
/*    */     } 
/*    */   }
/*    */   
/*    */   public enum ChildMode {
/* 64 */     DOWN, POPUP, DRAG_POPUP;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\ChildUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */