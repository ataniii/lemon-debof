/*    */ package com.lukflug.panelstudio.layout;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.setting.IKeybindSetting;
/*    */ import com.lukflug.panelstudio.setting.IStringSetting;
/*    */ import com.lukflug.panelstudio.theme.IButtonRenderer;
/*    */ import com.lukflug.panelstudio.theme.ITextFieldRenderer;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.ITextFieldKeys;
/*    */ import com.lukflug.panelstudio.widget.KeybindComponent;
/*    */ import com.lukflug.panelstudio.widget.TextField;
/*    */ import java.util.function.IntPredicate;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class ComponentGenerator implements IComponentGenerator {
/*    */   protected final IntPredicate keybindKey;
/*    */   
/*    */   public ComponentGenerator(IntPredicate keybindKey, IntPredicate charFilter, ITextFieldKeys keys) {
/* 21 */     this.keybindKey = keybindKey;
/* 22 */     this.charFilter = charFilter;
/* 23 */     this.keys = keys;
/*    */   }
/*    */   protected final IntPredicate charFilter; protected final ITextFieldKeys keys;
/*    */   
/*    */   public IComponent getKeybindComponent(IKeybindSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/* 28 */     return (IComponent)new KeybindComponent(setting, theme.getKeybindRenderer(isContainer))
/*    */       {
/*    */         public int transformKey(int scancode) {
/* 31 */           return ComponentGenerator.this.keybindKey.test(scancode) ? 0 : scancode;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public IComponent getStringComponent(IStringSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/* 38 */     return (IComponent)new TextField(setting, this.keys, 0, (IToggleable)new SimpleToggleable(false), theme.getTextRenderer(false, isContainer))
/*    */       {
/*    */         public boolean allowCharacter(char character) {
/* 41 */           return ComponentGenerator.this.charFilter.test(character);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\ComponentGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */