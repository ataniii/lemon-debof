package com.lukflug.panelstudio.layout;

import com.lukflug.panelstudio.setting.IClient;
import com.lukflug.panelstudio.theme.ITheme;

@FunctionalInterface
public interface ILayout {
  void populateGUI(IComponentAdder paramIComponentAdder, IComponentGenerator paramIComponentGenerator, IClient paramIClient, ITheme paramITheme);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\ILayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */