package com.lukflug.panelstudio.layout;

import com.lukflug.panelstudio.base.Animation;
import com.lukflug.panelstudio.component.IFixedComponent;
import com.lukflug.panelstudio.theme.ThemeTuple;
import java.awt.Point;
import java.util.function.Supplier;

public interface IComponentAdder {
  <S extends com.lukflug.panelstudio.component.IComponent, T extends com.lukflug.panelstudio.component.IComponent> void addComponent(S paramS, T paramT, ThemeTuple paramThemeTuple, Point paramPoint, int paramInt, Supplier<Animation> paramSupplier);
  
  void addPopup(IFixedComponent paramIFixedComponent);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\IComponentAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */