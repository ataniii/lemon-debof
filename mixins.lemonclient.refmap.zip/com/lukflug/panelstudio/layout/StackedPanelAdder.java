/*    */ package com.lukflug.panelstudio.layout;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.AnimatedToggleable;
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.IBoolean;
/*    */ import com.lukflug.panelstudio.base.IToggleable;
/*    */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.component.IResizable;
/*    */ import com.lukflug.panelstudio.component.IScrollSize;
/*    */ import com.lukflug.panelstudio.container.IContainer;
/*    */ import com.lukflug.panelstudio.container.VerticalContainer;
/*    */ import com.lukflug.panelstudio.popup.IPopupPositioner;
/*    */ import com.lukflug.panelstudio.popup.PopupTuple;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import com.lukflug.panelstudio.theme.RendererTuple;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.Button;
/*    */ import com.lukflug.panelstudio.widget.ResizableComponent;
/*    */ import java.awt.Point;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class StackedPanelAdder
/*    */   implements IComponentAdder, IScrollSize {
/*    */   protected IContainer<? super IFixedComponent> container;
/*    */   protected ChildUtil.ChildMode mode;
/*    */   protected VerticalContainer content;
/*    */   protected ChildUtil util;
/*    */   protected IBoolean isVisible;
/*    */   
/*    */   public StackedPanelAdder(IContainer<? super IFixedComponent> container, ILabeled label, ITheme theme, Point position, int width, Supplier<Animation> animation, ChildUtil.ChildMode mode, IPopupPositioner popupPos, IBoolean isVisible, String configName) {
/* 35 */     this.container = container;
/* 36 */     this.mode = mode;
/* 37 */     this.isVisible = isVisible;
/* 38 */     this.content = new VerticalContainer(label, theme.getContainerRenderer(-1, -1, true));
/* 39 */     IResizable size = getResizable(width);
/* 40 */     IScrollSize scrollSize = getScrollSize(size);
/* 41 */     container.addComponent((IComponent)ResizableComponent.createResizableComponent((IComponent)new Button(label, () -> null, theme.getButtonRenderer(Void.class, -1, -1, true)), (IComponent)this.content, () -> null, new AnimatedToggleable((IToggleable)new SimpleToggleable(true), animation.get()), new RendererTuple(Void.class, new ThemeTuple(theme, -1, -1)), theme.getResizeRenderer(), size, scrollSize, position, width, true, configName), isVisible);
/* 42 */     this.util = new ChildUtil(width, animation, new PopupTuple(popupPos, false, this));
/*    */   }
/*    */ 
/*    */   
/*    */   public <S extends IComponent, T extends IComponent> void addComponent(S title, T content, ThemeTuple theme, Point position, int width, Supplier<Animation> animation) {
/* 47 */     this.util.addContainer((ILabeled)new Labeled(content.getTitle(), null, () -> content.isVisible()), (IComponent)title, (IComponent)content, () -> null, Void.class, this.content, this, theme, this.mode);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addPopup(IFixedComponent popup) {
/* 52 */     this.container.addComponent((IComponent)popup, this.isVisible);
/*    */   }
/*    */   
/*    */   protected IResizable getResizable(int width) {
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   protected IScrollSize getScrollSize(IResizable size) {
/* 60 */     return new IScrollSize() {
/*    */       
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\StackedPanelAdder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */