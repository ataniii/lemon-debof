/*    */ package com.lukflug.panelstudio.layout;
/*    */ 
/*    */ import com.lukflug.panelstudio.base.Animation;
/*    */ import com.lukflug.panelstudio.base.IBoolean;
/*    */ import com.lukflug.panelstudio.component.IComponent;
/*    */ import com.lukflug.panelstudio.container.VerticalContainer;
/*    */ import com.lukflug.panelstudio.popup.PopupTuple;
/*    */ import com.lukflug.panelstudio.setting.ICategory;
/*    */ import com.lukflug.panelstudio.setting.IClient;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.IModule;
/*    */ import com.lukflug.panelstudio.setting.ISetting;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*    */ import com.lukflug.panelstudio.widget.Button;
/*    */ import com.lukflug.panelstudio.widget.ToggleButton;
/*    */ import java.awt.Point;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.function.IntFunction;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ public class PanelLayout
/*    */   implements ILayout
/*    */ {
/*    */   protected int width;
/*    */   protected Point start;
/*    */   protected int skipX;
/*    */   protected int skipY;
/*    */   
/*    */   public PanelLayout(int width, Point start, int skipX, int skipY, Supplier<Animation> animation, IntFunction<ChildUtil.ChildMode> layoutType, IntFunction<ChildUtil.ChildMode> colorType, PopupTuple popupType) {
/* 32 */     this.width = width;
/* 33 */     this.start = start;
/* 34 */     this.skipX = skipX;
/* 35 */     this.skipY = skipY;
/* 36 */     this.animation = animation;
/* 37 */     this.layoutType = layoutType;
/* 38 */     this.colorType = colorType;
/* 39 */     this.util = new ChildUtil(width, animation, popupType);
/*    */   }
/*    */   protected Supplier<Animation> animation; protected IntFunction<ChildUtil.ChildMode> layoutType; protected IntFunction<ChildUtil.ChildMode> colorType; protected ChildUtil util;
/*    */   
/*    */   public void populateGUI(IComponentAdder gui, IComponentGenerator components, IClient client, ITheme theme) {
/* 44 */     Point pos = this.start;
/* 45 */     AtomicInteger skipY = new AtomicInteger(this.skipY);
/* 46 */     client.getCategories().forEach(category -> {
/*    */           Button<Void> categoryTitle = new Button((ILabeled)category, (), theme.getButtonRenderer(Void.class, 0, 0, true));
/*    */           VerticalContainer categoryContent = new VerticalContainer((ILabeled)category, theme.getContainerRenderer(0, 0, false));
/*    */           gui.addComponent(categoryTitle, categoryContent, new ThemeTuple(theme, 0, 0), new Point(pos), this.width, this.animation);
/*    */           pos.translate(this.skipX, skipY.get());
/*    */           skipY.set(-skipY.get());
/*    */           category.getModules().forEach(());
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected <T> void addSettingsComponent(ISetting<T> setting, VerticalContainer container, IComponentAdder gui, IComponentGenerator components, ThemeTuple theme) {
/* 67 */     int nextLevel = (this.layoutType.apply(theme.logicalLevel - 1) == ChildUtil.ChildMode.DOWN) ? theme.graphicalLevel : 0;
/* 68 */     int colorLevel = (this.colorType.apply(theme.logicalLevel - 1) == ChildUtil.ChildMode.DOWN) ? theme.graphicalLevel : 0;
/* 69 */     boolean isContainer = (setting.getSubSettings() != null && this.layoutType.apply(theme.logicalLevel - 1) == ChildUtil.ChildMode.DOWN);
/* 70 */     IComponent component = components.getComponent(setting, this.animation, gui, theme, colorLevel, isContainer);
/* 71 */     if (component instanceof VerticalContainer) {
/* 72 */       VerticalContainer colorContainer = (VerticalContainer)component;
/* 73 */       Button<T> button = new Button((ILabeled)setting, () -> setting.getSettingState(), theme.getButtonRenderer(setting.getSettingClass(), (this.colorType.apply(theme.logicalLevel - 1) == ChildUtil.ChildMode.DOWN)));
/* 74 */       this.util.addContainer((ILabeled)setting, (IComponent)button, (IComponent)colorContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, new ThemeTuple(theme.theme, theme.logicalLevel, colorLevel), this.colorType.apply(theme.logicalLevel - 1));
/* 75 */       if (setting.getSubSettings() != null) setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, colorContainer, gui, components, new ThemeTuple(theme.theme, theme.logicalLevel + 1, colorLevel + 1))); 
/* 76 */     } else if (setting.getSubSettings() != null) {
/* 77 */       VerticalContainer settingContainer = new VerticalContainer((ILabeled)setting, theme.theme.getContainerRenderer(theme.logicalLevel, nextLevel, false));
/* 78 */       this.util.addContainer((ILabeled)setting, component, (IComponent)settingContainer, () -> setting.getSettingState(), setting.getSettingClass(), container, gui, new ThemeTuple(theme.theme, theme.logicalLevel, nextLevel), this.layoutType.apply(theme.logicalLevel - 1));
/* 79 */       setting.getSubSettings().forEach(subSetting -> addSettingsComponent(subSetting, settingContainer, gui, components, new ThemeTuple(theme.theme, theme.logicalLevel + 1, nextLevel + 1)));
/*    */     } else {
/* 81 */       container.addComponent(component);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lukflug\panelstudio\layout\PanelLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */