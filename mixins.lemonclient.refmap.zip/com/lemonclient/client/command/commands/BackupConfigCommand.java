/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.misc.ZipUtils;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import java.io.File;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ @Declaration(name = "BackupConfig", syntax = "backupconfig", alias = {"backupconfig"})
/*    */ public class BackupConfigCommand
/*    */   extends Command
/*    */ {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 16 */     String filename = "lemonclient-cofig-backup-v0.0.8-" + (new SimpleDateFormat("yyyyMMdd.HHmmss.SSS")).format(new Date()) + ".zip";
/* 17 */     ZipUtils.zip(new File("LemonClient/"), new File(filename));
/* 18 */     MessageBus.sendCommandMessage("Config successfully saved in " + filename + "!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\BackupConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */