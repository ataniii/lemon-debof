//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.command.CommandManager;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.Collection;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.Style;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ import net.minecraft.util.text.event.ClickEvent;
/*    */ import net.minecraft.util.text.event.HoverEvent;
/*    */ 
/*    */ @Declaration(name = "Modules", syntax = "modules (click to toggle)", alias = {"modules", "module", "modulelist", "mod", "mods"})
/*    */ public class ModulesCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 20 */     TextComponentString msg = new TextComponentString("§7Modules: §f ");
/*    */     
/* 22 */     Collection<Module> modules = ModuleManager.getModules();
/* 23 */     int size = modules.size();
/* 24 */     int index = 0;
/*    */     
/* 26 */     for (Module module : modules) {
/* 27 */       msg.appendSibling((new TextComponentString((module.isEnabled() ? (String)ChatFormatting.GREEN : (String)ChatFormatting.RED) + module.getName() + "§7" + ((index == size - 1) ? "" : ", ")))
/* 28 */           .setStyle((new Style())
/* 29 */             .setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (ITextComponent)new TextComponentString(module.getCategory().name())))
/* 30 */             .setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, CommandManager.getCommandPrefix() + "toggle " + module.getName()))));
/*    */       
/* 32 */       index++;
/*    */     } 
/*    */     
/* 35 */     msg.appendSibling((ITextComponent)new TextComponentString(ChatFormatting.GRAY + "!"));
/* 36 */     mc.ingameGUI.getChatGUI().printChatMessage((ITextComponent)msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\ModulesCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
