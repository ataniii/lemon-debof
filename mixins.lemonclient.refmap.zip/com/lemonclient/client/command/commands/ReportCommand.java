/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.ReportBot;
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import java.util.Objects;
/*    */ 
/*    */ @Declaration(name = "Report", syntax = "report [report]", alias = {"report"})
/*    */ public class ReportCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 14 */     if (Objects.equals(message[0], ""))
/* 15 */       return;  this.reportBot = new ReportBot(message[0]);
/* 16 */     MessageBus.sendClientPrefixMessage("Reported " + message[0] + "!", Notification.Type.SUCCESS);
/*    */   }
/*    */   
/*    */   ReportBot reportBot;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\ReportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */