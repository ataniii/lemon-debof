/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.command.CommandManager;
/*    */ 
/*    */ @Declaration(name = "Commands", syntax = "commands", alias = {"commands", "cmd", "command", "commandlist", "help"})
/*    */ public class CmdListCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 12 */     for (Command command1 : CommandManager.getCommands())
/* 13 */       MessageBus.sendMessage(command1.getName() + ": \"" + command1.getSyntax() + "\"!", true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\CmdListCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */