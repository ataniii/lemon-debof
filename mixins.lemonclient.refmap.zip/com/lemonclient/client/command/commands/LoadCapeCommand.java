/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.render.CapeUtil;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "LoadCape", syntax = "loadcape", alias = {"loadcape", "capeload", "reloadcape", "capereload"})
/*    */ public class LoadCapeCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     MessageBus.sendCommandMessage("Reloaded Cape UUID", true);
/* 12 */     CapeUtil.init();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\LoadCapeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */