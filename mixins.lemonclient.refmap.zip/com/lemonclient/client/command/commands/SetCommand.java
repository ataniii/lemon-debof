/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.api.setting.SettingsManager;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "Set", syntax = "set [module] [setting] value (no color support)", alias = {"set", "setmodule", "changesetting", "setting"})
/*    */ public class SetCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 18 */     String main = message[0];
/*    */     
/* 20 */     Module module = ModuleManager.getModule(main);
/* 21 */     String[] string = new String[1];
/*    */     
/* 23 */     if (module == null) {
/* 24 */       string[0] = getSyntax();
/*    */       return;
/*    */     } 
/* 27 */     SettingsManager.getSettingsForModule(module).stream().filter(setting -> setting.getConfigName().equalsIgnoreCase(message[1])).forEach(setting -> {
/*    */           if (setting instanceof com.lemonclient.api.setting.values.BooleanSetting) {
/*    */             if (message[2].equalsIgnoreCase("true") || message[2].equalsIgnoreCase("false")) {
/*    */               setting.setValue(Boolean.valueOf(Boolean.parseBoolean(message[2])));
/*    */               
/*    */               string[0] = module.getName() + " " + setting.getConfigName() + " set to: " + setting.getValue() + "!";
/*    */             } else {
/*    */               string[0] = getSyntax();
/*    */             } 
/*    */           } else if (setting instanceof IntegerSetting) {
/*    */             if (Integer.parseInt(message[2]) > ((IntegerSetting)setting).getMax()) {
/*    */               setting.setValue(Integer.valueOf(((IntegerSetting)setting).getMax()));
/*    */             }
/*    */             
/*    */             if (Integer.parseInt(message[2]) < ((IntegerSetting)setting).getMin()) {
/*    */               setting.setValue(Integer.valueOf(((IntegerSetting)setting).getMin()));
/*    */             }
/*    */             if (Integer.parseInt(message[2]) < ((IntegerSetting)setting).getMax() && Integer.parseInt(message[2]) > ((IntegerSetting)setting).getMin()) {
/*    */               setting.setValue(Integer.valueOf(Integer.parseInt(message[2])));
/*    */             }
/*    */             string[0] = module.getName() + " " + setting.getConfigName() + " set to: " + setting.getValue() + "!";
/*    */           } else if (setting instanceof DoubleSetting) {
/*    */             if (Double.parseDouble(message[2]) > ((DoubleSetting)setting).getMax()) {
/*    */               setting.setValue(Double.valueOf(((DoubleSetting)setting).getMax()));
/*    */             }
/*    */             if (Double.parseDouble(message[2]) < ((DoubleSetting)setting).getMin()) {
/*    */               setting.setValue(Double.valueOf(((DoubleSetting)setting).getMin()));
/*    */             }
/*    */             if (Double.parseDouble(message[2]) < ((DoubleSetting)setting).getMax() && Double.parseDouble(message[2]) > ((DoubleSetting)setting).getMin()) {
/*    */               setting.setValue(Double.valueOf(Double.parseDouble(message[2])));
/*    */             }
/*    */             string[0] = module.getName() + " " + setting.getConfigName() + " set to: " + setting.getValue() + "!";
/*    */           } else if (setting instanceof ModeSetting) {
/*    */             if (!((ModeSetting)setting).getModes().contains(message[2])) {
/*    */               string[0] = getSyntax();
/*    */             } else {
/*    */               setting.setValue(message[2]);
/*    */               string[0] = module.getName() + " " + setting.getConfigName() + " set to: " + setting.getValue() + "!";
/*    */             } 
/*    */           } else {
/*    */             string[0] = getSyntax();
/*    */           } 
/*    */         });
/* 70 */     if (none) { MessageBus.sendServerMessage(string[0]); }
/* 71 */     else { MessageBus.sendCommandMessage(string[0], true); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\SetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */