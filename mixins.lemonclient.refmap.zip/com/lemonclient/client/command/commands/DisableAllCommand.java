/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "DisableAll", syntax = "disableall", alias = {"disableall", "stop"})
/*    */ public class DisableAllCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 12 */     int count = 0;
/*    */     
/* 14 */     for (Module module : ModuleManager.getModules()) {
/* 15 */       if (module.isEnabled()) {
/* 16 */         module.disable();
/* 17 */         count++;
/*    */       } 
/*    */     } 
/*    */     
/* 21 */     MessageBus.sendCommandMessage("Disabled " + count + " modules!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\DisableAllCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */