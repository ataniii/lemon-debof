/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import java.awt.Desktop;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ @Declaration(name = "OpenFolder", syntax = "openfolder", alias = {"openfolder", "open", "folder"})
/*    */ public class OpenFolderCommand
/*    */   extends Command
/*    */ {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/*    */     try {
/* 17 */       Desktop.getDesktop().open(new File("LemonClient/".replace("/", "")));
/* 18 */       MessageBus.sendCommandMessage("Opened config folder!", true);
/* 19 */     } catch (IOException e) {
/* 20 */       MessageBus.sendCommandMessage("Could not open config folder!", true);
/* 21 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\OpenFolderCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */