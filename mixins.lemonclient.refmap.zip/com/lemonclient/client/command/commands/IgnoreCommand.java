/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "Ignore", syntax = "ignore list/add/del [player]", alias = {"ignore", "ignores"})
/*    */ public class IgnoreCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     String string, main = message[0];
/*    */ 
/*    */     
/* 14 */     if (main.equalsIgnoreCase("list")) {
/* 15 */       string = "Ignores: " + SocialManager.getIgnoresByName() + ".";
/*    */     } else {
/* 17 */       String value = message[1];
/* 18 */       if (main.equalsIgnoreCase("add"))
/* 19 */       { if (SocialManager.isOnIgnoreList(value)) {
/* 20 */           string = value + " is already on your ignore.";
/*    */         } else {
/* 22 */           SocialManager.addIgnore(value);
/* 23 */           string = "Added ignore: " + value + ".";
/*    */         }  }
/* 25 */       else if (main.equalsIgnoreCase("del") && SocialManager.isOnIgnoreList(value))
/* 26 */       { if (SocialManager.isOnIgnoreList(value))
/* 27 */         { SocialManager.delIgnore(value);
/* 28 */           string = "Deleted ignore: " + value + "."; }
/* 29 */         else { string = value + " isn't your ignore."; }  }
/*    */       else { return; }
/*    */     
/* 32 */     }  if (none) { MessageBus.sendServerMessage(string); }
/* 33 */     else { MessageBus.sendCommandMessage(string, true); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\IgnoreCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */