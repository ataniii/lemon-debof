/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.command.CommandManager;
/*    */ 
/*    */ @Declaration(name = "Prefix", syntax = "prefix value (no letters or numbers)", alias = {"prefix", "setprefix", "cmdprefix", "commandprefix"})
/*    */ public class PrefixCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     String main = message[0].toUpperCase().replaceAll("[a-zA-Z0-9]", null);
/* 12 */     int size = message[0].length();
/*    */     
/* 14 */     if (size == 1) {
/* 15 */       CommandManager.setCommandPrefix(main);
/* 16 */       MessageBus.sendCommandMessage("Prefix set: \"" + main + "\"!", true);
/* 17 */     } else if (size != 1) {
/* 18 */       MessageBus.sendCommandMessage(getSyntax(), true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\PrefixCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */