/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "RefreshGUI", syntax = "refreshgui", alias = {"refreshgui", "freshgui", "fresh"})
/*    */ public class RefreshGUICommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     LemonClient.INSTANCE.gameSenseGUI.refresh();
/* 12 */     MessageBus.sendCommandMessage("Refreshed ClickGUI!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\RefreshGUICommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */