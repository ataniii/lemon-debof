/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "FixGUI", syntax = "fixgui", alias = {"fixgui", "gui", "resetgui"})
/*    */ public class FixGUICommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 12 */     LemonClient.INSTANCE.gameSenseGUI = new LemonClientGUI();
/* 13 */     MessageBus.sendCommandMessage("ClickGUI positions reset!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\FixGUICommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */