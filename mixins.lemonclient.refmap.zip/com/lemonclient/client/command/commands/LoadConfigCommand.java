/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.config.LoadConfig;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "LoadConfig", syntax = "loadconfig", alias = {"config load", "loadconfig", "load"})
/*    */ public class LoadConfigCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 13 */     LoadConfig.init();
/* 14 */     MessageBus.sendCommandMessage("Config loaded!", true);
/* 15 */     if (none) { MessageBus.sendServerMessage("Config loaded!"); }
/* 16 */     else { MessageBus.sendCommandMessage("Config loaded!", true); }
/* 17 */      LemonClient.INSTANCE.gameSenseGUI.refresh();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\LoadConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */