/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "Drawn", syntax = "drawn [module]", alias = {"drawn", "shown"})
/*    */ public class DrawnCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 12 */     String main = message[0];
/*    */     
/* 14 */     Module module = ModuleManager.getModule(main);
/*    */     
/* 16 */     if (module == null) {
/* 17 */       MessageBus.sendCommandMessage(getSyntax(), true);
/*    */       
/*    */       return;
/*    */     } 
/* 21 */     if (module.isDrawn()) {
/* 22 */       module.setDrawn(false);
/* 23 */       MessageBus.sendCommandMessage("Module " + module.getName() + " drawn set to: FALSE!", true);
/*    */     } else {
/* 25 */       module.setDrawn(true);
/* 26 */       MessageBus.sendCommandMessage("Module " + module.getName() + " drawn set to: TRUE!", true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\DrawnCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */