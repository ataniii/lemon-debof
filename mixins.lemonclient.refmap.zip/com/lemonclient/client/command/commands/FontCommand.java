/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.font.CFontRenderer;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import java.awt.Font;
/*    */ 
/*    */ @Declaration(name = "Font", syntax = "font [name] (use _ for spaces) size antiAlias (true/false) metrics (true/false)", alias = {"font", "setfont", "customfont", "fonts", "chatfont"})
/*    */ public class FontCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 14 */     String main = message[0].replace("_", " ");
/* 15 */     int value = Integer.parseInt(message[1]);
/*    */     
/* 17 */     if (value >= 21 || value <= 15) {
/* 18 */       value = 18;
/*    */     }
/*    */     
/* 21 */     LemonClient.INSTANCE.cFontRenderer = new CFontRenderer(new Font(main, 0, value), Boolean.parseBoolean(message[2]), Boolean.parseBoolean(message[3]));
/* 22 */     LemonClient.INSTANCE.cFontRenderer.setFontName(main);
/* 23 */     LemonClient.INSTANCE.cFontRenderer.setFontSize(value);
/*    */     
/* 25 */     MessageBus.sendCommandMessage("Font set to: " + main.toUpperCase() + ", size " + value + "!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\FontCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */