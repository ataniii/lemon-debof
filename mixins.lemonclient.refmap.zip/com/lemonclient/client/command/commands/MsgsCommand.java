/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "Msgs", syntax = "msgs [module]", alias = {"msgs", "togglemsgs", "showmsgs", "messages"})
/*    */ public class MsgsCommand
/*    */   extends Command
/*    */ {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 14 */     String main = message[0];
/*    */     
/* 16 */     Module module = ModuleManager.getModule(main);
/*    */     
/* 18 */     if (module == null) {
/* 19 */       MessageBus.sendCommandMessage(getSyntax(), true);
/*    */       
/*    */       return;
/*    */     } 
/* 23 */     if (module.isToggleMsg()) {
/* 24 */       module.setToggleMsg(false);
/* 25 */       MessageBus.sendCommandMessage("Module " + module.getName() + " message toggle set to: FALSE!", true);
/*    */     } else {
/* 27 */       module.setToggleMsg(true);
/* 28 */       MessageBus.sendCommandMessage("Module " + module.getName() + " message toggle set to: TRUE!", true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\MsgsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */