/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ @Declaration(name = "Bind", syntax = "bind [module] key", alias = {"bind", "b", "setbind", "key"})
/*    */ public class BindCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 13 */     String main = message[0];
/* 14 */     String value = message[1].toUpperCase();
/*    */     
/* 16 */     for (Module module : ModuleManager.getModules()) {
/* 17 */       if (module.getName().equalsIgnoreCase(main)) {
/* 18 */         if (value.equalsIgnoreCase("none")) {
/* 19 */           module.setBind(0);
/* 20 */           MessageBus.sendCommandMessage("Module " + module.getName() + " bind set to: " + value + "!", true);
/*    */           continue;
/*    */         } 
/* 23 */         if (value.length() == 1) {
/* 24 */           int key = Keyboard.getKeyIndex(value);
/*    */           
/* 26 */           module.setBind(key);
/* 27 */           MessageBus.sendCommandMessage("Module " + module.getName() + " bind set to: " + value + "!", true); continue;
/* 28 */         }  if (value.length() > 1)
/* 29 */           MessageBus.sendCommandMessage(getSyntax(), true); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\BindCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */