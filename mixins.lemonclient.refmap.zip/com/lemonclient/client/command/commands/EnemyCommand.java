/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "Enemy", syntax = "enemy list/add/del [player]", alias = {"enemy", "enemies", "e"})
/*    */ public class EnemyCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     String main = message[0];
/*    */     
/* 13 */     if (main.equalsIgnoreCase("list")) {
/* 14 */       MessageBus.sendCommandMessage("Enemies: " + SocialManager.getEnemiesByName() + ".", true);
/*    */       
/*    */       return;
/*    */     } 
/* 18 */     String value = message[1];
/*    */     
/* 20 */     if (main.equalsIgnoreCase("add") && !SocialManager.isOnEnemyList(value)) {
/* 21 */       if (SocialManager.isOnEnemyList(value)) { MessageBus.sendCommandMessage(value + " is already your enemy.", true); }
/*    */       else
/* 23 */       { SocialManager.addEnemy(value);
/* 24 */         MessageBus.sendCommandMessage("Added enemy: " + value, true); }
/*    */     
/* 26 */     } else if (main.equalsIgnoreCase("del") && SocialManager.isOnEnemyList(value)) {
/* 27 */       if (SocialManager.isOnEnemyList(value)) {
/* 28 */         SocialManager.delEnemy(value);
/* 29 */         MessageBus.sendCommandMessage("Deleted enemy: " + value, true);
/*    */       } else {
/* 31 */         MessageBus.sendCommandMessage(value + " isn't your enemy.", true);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\EnemyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */