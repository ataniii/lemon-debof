/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.HUDModule;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "FixHUD", syntax = "fixhud", alias = {"fixhud", "hud", "resethud"})
/*    */ public class FixHUDCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 14 */     for (Module module : ModuleManager.getModules()) {
/* 15 */       if (module instanceof HUDModule) {
/* 16 */         ((HUDModule)module).resetPosition();
/*    */       }
/*    */     } 
/* 19 */     MessageBus.sendCommandMessage("HUD positions reset!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\FixHUDCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */