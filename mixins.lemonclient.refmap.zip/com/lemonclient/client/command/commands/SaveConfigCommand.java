/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.config.SaveConfig;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ 
/*    */ @Declaration(name = "SaveConfig", syntax = "saveconfig", alias = {"config save", "saveconfig", "save"})
/*    */ public class SaveConfigCommand
/*    */   extends Command
/*    */ {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 14 */     SaveConfig.init();
/* 15 */     MessageBus.sendCommandMessage("Config saved!", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\SaveConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */