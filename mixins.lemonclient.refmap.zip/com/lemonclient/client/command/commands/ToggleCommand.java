/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ 
/*    */ @Declaration(name = "Toggle", syntax = "toggle [module]", alias = {"toggle", "t", "enable", "disable"})
/*    */ public class ToggleCommand
/*    */   extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 13 */     String string, main = message[0];
/*    */     
/* 15 */     Module module = ModuleManager.getModule(main);
/*    */ 
/*    */     
/* 18 */     if (module == null) {
/* 19 */       string = getSyntax();
/*    */     } else {
/* 21 */       module.toggle();
/* 22 */       if (module.isEnabled()) { string = "Module " + module.getName() + " set to: ENABLED!"; }
/* 23 */       else { string = "Module " + module.getName() + " set to: DISABLED!"; }
/*    */     
/* 25 */     }  if (none) { MessageBus.sendServerMessage(string); }
/* 26 */     else { MessageBus.sendCommandMessage(string, true); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\ToggleCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */