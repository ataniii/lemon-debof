//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.command.commands;
/*     */ 
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.client.command.Command;
/*     */ import com.lemonclient.client.command.Command.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.misc.AutoGear;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ @Declaration(name = "AutoGear", syntax = "gear set/save/del/list [name]", alias = {"gear", "gr", "kit"})
/*     */ public class AutoGearCommand
/*     */   extends Command
/*     */ {
/*     */   private static final String pathSave = "LemonClient/Misc/AutoGear.json";
/*  23 */   private static final HashMap<String, String> errorMessage = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(String command, String[] message, boolean none) {
/*  34 */     switch (message[0].toLowerCase()) {
/*     */       
/*     */       case "list":
/*  37 */         if (message.length == 1)
/*  38 */         { listMessage(); }
/*  39 */         else { errorMessage("NoPar"); }
/*     */          return;
/*     */       case "set":
/*  42 */         if (message.length == 2)
/*  43 */         { set(message[1]); }
/*  44 */         else { errorMessage("NoPar"); }
/*     */          return;
/*     */       case "save":
/*     */       case "add":
/*     */       case "create":
/*  49 */         if (message.length == 2)
/*  50 */         { save(message[1]); }
/*  51 */         else { errorMessage("NoPar"); }
/*     */          return;
/*     */       case "del":
/*  54 */         if (message.length == 2)
/*  55 */         { delete(message[1]); }
/*  56 */         else { errorMessage("NoPar"); }
/*     */         
/*     */         return;
/*     */     } 
/*     */     
/*  61 */     MessageBus.sendCommandMessage("AutoGear message is: gear set/save/del/list [name]", true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void listMessage() {
/*  67 */     JsonObject completeJson = new JsonObject();
/*  68 */     String string = "";
/*     */     
/*     */     try {
/*  71 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/*  72 */       int lenghtJson = completeJson.entrySet().size();
/*  73 */       for (int i = 0; i < lenghtJson; i++) {
/*  74 */         String item = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject().entrySet().toArray()[i].toString().split("=")[0];
/*  75 */         if (!item.equals("pointer"))
/*  76 */           if (string.equals("")) { string = item; }
/*  77 */           else { string = string + ", " + item; }
/*     */            
/*     */       } 
/*  80 */       MessageBus.sendCommandMessage("Kit avaible: " + string, true);
/*     */     }
/*  82 */     catch (IOException e) {
/*     */       
/*  84 */       errorMessage("NoEx");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void delete(String name) {
/*  89 */     JsonObject completeJson = new JsonObject();
/*     */     
/*     */     try {
/*  92 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/*  93 */       if (completeJson.get(name) != null && !name.equals("pointer"))
/*     */       
/*  95 */       { completeJson.remove(name);
/*     */         
/*  97 */         if (completeJson.get("pointer").getAsString().equals(name)) {
/*  98 */           completeJson.addProperty("pointer", "none");
/*     */         }
/* 100 */         saveFile(completeJson, name, "deleted"); }
/* 101 */       else { errorMessage("NoEx"); }
/*     */     
/* 103 */     } catch (IOException e) {
/*     */       
/* 105 */       errorMessage("NoEx");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void set(String name) {
/* 110 */     JsonObject completeJson = new JsonObject();
/*     */     
/*     */     try {
/* 113 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/* 114 */       if (completeJson.get(name) != null && !name.equals("pointer"))
/*     */       
/* 116 */       { completeJson.addProperty("pointer", name);
/*     */         
/* 118 */         saveFile(completeJson, name, "selected");
/* 119 */         ((AutoGear)ModuleManager.getModule(AutoGear.class)).onEnable(); }
/* 120 */       else { errorMessage("NoEx"); }
/*     */     
/* 122 */     } catch (IOException e) {
/*     */       
/* 124 */       errorMessage("NoEx");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void save(String name) {
/* 129 */     JsonObject completeJson = new JsonObject();
/*     */     
/*     */     try {
/* 132 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/* 133 */       if (completeJson.get(name) != null && !name.equals("pointer")) {
/* 134 */         errorMessage("Exist");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/* 139 */     } catch (IOException e) {
/*     */       
/* 141 */       completeJson.addProperty("pointer", "none");
/*     */     } 
/*     */ 
/*     */     
/* 145 */     StringBuilder jsonInventory = new StringBuilder();
/* 146 */     for (ItemStack item : mc.player.inventory.mainInventory)
/*     */     {
/* 148 */       jsonInventory.append(item.getItem().getRegistryName().toString() + item.getMetadata()).append(" ");
/*     */     }
/*     */     
/* 151 */     completeJson.addProperty(name, jsonInventory.toString());
/*     */     
/* 153 */     saveFile(completeJson, name, "saved");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveFile(JsonObject completeJson, String name, String operation) {
/*     */     try {
/* 160 */       BufferedWriter bw = new BufferedWriter(new FileWriter("LemonClient/Misc/AutoGear.json"));
/*     */       
/* 162 */       bw.write(completeJson.toString());
/*     */       
/* 164 */       bw.close();
/*     */       
/* 166 */       MessageBus.printDebug("Kit " + name + " " + operation, Boolean.valueOf(false));
/* 167 */     } catch (IOException e) {
/* 168 */       errorMessage("Saving");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void errorMessage(String e) {
/* 173 */     MessageBus.printDebug("Error: " + (String)errorMessage.get(e), Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getCurrentSet() {
/* 178 */     JsonObject completeJson = new JsonObject();
/*     */     
/*     */     try {
/* 181 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/* 182 */       if (!completeJson.get("pointer").getAsString().equals("none")) {
/* 183 */         return completeJson.get("pointer").getAsString();
/*     */       }
/*     */     }
/* 186 */     catch (IOException iOException) {}
/*     */ 
/*     */     
/* 189 */     errorMessage("NoEx");
/* 190 */     return "";
/*     */   }
/*     */   
/*     */   public static String getInventoryKit(String kit) {
/* 194 */     JsonObject completeJson = new JsonObject();
/*     */     
/*     */     try {
/* 197 */       completeJson = (new JsonParser()).parse(new FileReader("LemonClient/Misc/AutoGear.json")).getAsJsonObject();
/* 198 */       return completeJson.get(kit).getAsString();
/*     */     
/*     */     }
/* 201 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 204 */       errorMessage("NoEx");
/* 205 */       return "";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\AutoGearCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
