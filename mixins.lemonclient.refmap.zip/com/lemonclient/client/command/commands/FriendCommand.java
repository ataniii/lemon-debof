/*    */ package com.lemonclient.client.command.commands;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.client.command.Command;
/*    */ import com.lemonclient.client.command.Command.Declaration;
/*    */ 
/*    */ @Declaration(name = "Friend", syntax = "friend list/add/del [player]", alias = {"friend", "friends", "f"})
/*    */ public class FriendCommand extends Command {
/*    */   public void onCommand(String command, String[] message, boolean none) {
/* 11 */     String string, main = message[0];
/*    */ 
/*    */     
/* 14 */     if (main.equalsIgnoreCase("list")) {
/* 15 */       string = "Friends: " + SocialManager.getFriendsByName() + ".";
/*    */     } else {
/* 17 */       String value = message[1];
/* 18 */       if (main.equalsIgnoreCase("add"))
/* 19 */       { if (SocialManager.isOnFriendList(value)) {
/* 20 */           string = value + " is already your friend.";
/*    */         } else {
/* 22 */           SocialManager.addFriend(value);
/* 23 */           string = "Added friend: " + value + ".";
/*    */         }  }
/* 25 */       else if (main.equalsIgnoreCase("del") && SocialManager.isOnFriendList(value))
/* 26 */       { if (SocialManager.isOnFriendList(value))
/* 27 */         { SocialManager.delFriend(value);
/* 28 */           string = "Deleted friend: " + value + "."; }
/* 29 */         else { string = value + " isn't your friend."; }  }
/*    */       else { return; }
/*    */     
/* 32 */     }  if (none) { MessageBus.sendServerMessage(string); }
/* 33 */     else { MessageBus.sendCommandMessage(string, true); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\commands\FriendCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */