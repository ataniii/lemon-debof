/*    */ package com.lemonclient.client.command;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.command.commands.AutoGearCommand;
/*    */ import com.lemonclient.client.command.commands.DrawnCommand;
/*    */ import com.lemonclient.client.command.commands.IgnoreCommand;
/*    */ import com.lemonclient.client.command.commands.ToggleCommand;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class CommandManager {
/* 10 */   private static String commandPrefix = "-";
/* 11 */   public static final ArrayList<Command> commands = new ArrayList<>();
/*    */   
/*    */   public static void init() {
/* 14 */     addCommand((Command)new AutoGearCommand());
/* 15 */     addCommand((Command)new BackupConfigCommand());
/* 16 */     addCommand((Command)new BindCommand());
/* 17 */     addCommand((Command)new CmdListCommand());
/* 18 */     addCommand((Command)new DisableAllCommand());
/* 19 */     addCommand((Command)new DrawnCommand());
/* 20 */     addCommand((Command)new EnemyCommand());
/* 21 */     addCommand((Command)new FixGUICommand());
/* 22 */     addCommand((Command)new FixHUDCommand());
/* 23 */     addCommand((Command)new FontCommand());
/* 24 */     addCommand((Command)new FriendCommand());
/* 25 */     addCommand((Command)new IgnoreCommand());
/* 26 */     addCommand((Command)new LoadCapeCommand());
/* 27 */     addCommand((Command)new LoadConfigCommand());
/* 28 */     addCommand((Command)new ModulesCommand());
/* 29 */     addCommand((Command)new MsgsCommand());
/* 30 */     addCommand((Command)new OpenFolderCommand());
/* 31 */     addCommand((Command)new PrefixCommand());
/* 32 */     addCommand((Command)new RefreshGUICommand());
/* 33 */     addCommand((Command)new ReportCommand());
/* 34 */     addCommand((Command)new SaveConfigCommand());
/* 35 */     addCommand((Command)new SetCommand());
/* 36 */     addCommand((Command)new ToggleCommand());
/*    */   }
/*    */   
/*    */   public static void addCommand(Command command) {
/* 40 */     commands.add(command);
/*    */   }
/*    */   
/*    */   public static ArrayList<Command> getCommands() {
/* 44 */     return commands;
/*    */   }
/*    */   
/*    */   public static String getCommandPrefix() {
/* 48 */     return commandPrefix;
/*    */   }
/*    */   
/*    */   public static void setCommandPrefix(String prefix) {
/* 52 */     commandPrefix = prefix;
/*    */   }
/*    */   public static boolean isValidCommand = false;
/*    */   
/*    */   public static void callCommand(String input, boolean none) {
/* 57 */     String[] split = input.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
/* 58 */     String command1 = split[0];
/* 59 */     String args = input.substring(command1.length()).trim();
/*    */     
/* 61 */     isValidCommand = false;
/*    */     
/* 63 */     commands.forEach(command -> {
/*    */           for (String string : command.getAlias()) {
/*    */             if (string.equalsIgnoreCase(command1)) {
/*    */               isValidCommand = true;
/*    */               try {
/*    */                 command.onCommand(args, args.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"), none);
/* 69 */               } catch (Exception e) {
/*    */                 MessageBus.sendCommandMessage(command.getSyntax(), true);
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         });
/*    */     
/* 76 */     if (!isValidCommand)
/* 77 */       MessageBus.sendCommandMessage("Error! Invalid command!", true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */