//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.command;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ public abstract class Command
/*    */ {
/* 12 */   protected static final Minecraft mc = Minecraft.getMinecraft();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Declaration getDeclaration() {
/* 25 */     return getClass().<Declaration>getAnnotation(Declaration.class);
/*    */   }
/*    */   
/* 28 */   private final String name = getDeclaration().name();
/* 29 */   private final String[] alias = getDeclaration().alias();
/* 30 */   private final String syntax = getDeclaration().syntax();
/*    */   
/*    */   public String getName() {
/* 33 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getSyntax() {
/* 37 */     return CommandManager.getCommandPrefix() + this.syntax;
/*    */   }
/*    */   
/*    */   public String[] getAlias() {
/* 41 */     return this.alias;
/*    */   }
/*    */   
/*    */   public abstract void onCommand(String paramString, String[] paramArrayOfString, boolean paramBoolean);
/*    */   
/*    */   @Retention(RetentionPolicy.RUNTIME)
/*    */   @Target({ElementType.TYPE})
/*    */   public static @interface Declaration {
/*    */     String name();
/*    */     
/*    */     String syntax();
/*    */     
/*    */     String[] alias();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\command\Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
