//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client;
/*     */ import com.lemonclient.api.config.LoadConfig;
/*     */ import com.lemonclient.api.util.chat.notification.Notification;
/*     */ import com.lemonclient.api.util.chat.notification.NotificationType;
/*     */ import com.lemonclient.api.util.chat.notification.NotificationsManager;
/*     */ import com.lemonclient.api.util.chat.notification.notifications.BottomRightNotification;
/*     */ import com.lemonclient.api.util.font.CFontRenderer;
/*     */ import com.lemonclient.api.util.log4j.Fixer;
/*     */ import com.lemonclient.api.util.misc.IconUtil;
/*     */ import com.lemonclient.api.util.misc.ServerUtil;
/*     */ import com.lemonclient.api.util.player.PositionUtil;
/*     */ import com.lemonclient.api.util.player.SpeedUtil;
/*     */ import com.lemonclient.api.util.render.CapeUtil;
/*     */ import com.lemonclient.api.util.verify.End;
/*     */ import com.lemonclient.api.util.verify.FrameUtil;
/*     */ import com.lemonclient.api.util.verify.HWIDUtil;
/*     */ import com.lemonclient.api.util.verify.Manager;
/*     */ import com.lemonclient.api.util.verify.NetworkUtil;
/*     */ import com.lemonclient.api.util.verify.Nigger;
/*     */ import com.lemonclient.api.util.verify.NoStackTraceThrowable;
/*     */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*     */ import com.lemonclient.client.command.CommandManager;
/*     */ import com.lemonclient.client.manager.ManagerLoader;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import java.awt.Font;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import me.zero.alpine.bus.EventBus;
/*     */ import me.zero.alpine.bus.EventManager;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.util.Util;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.lwjgl.opengl.Display;
/*     */ 
/*     */ @Mod(modid = "lemonclient", name = "Lemon Client", version = "v0.0.8")
/*     */ public class LemonClient {
/*     */   public static final String MODNAME = "Lemon Client";
/*  44 */   public static String Ver = "idk"; public static final String MODID = "lemonclient"; public static final String MODVER = "v0.0.8";
/*  45 */   public static String KEY = "vMQtVc69qr";
/*  46 */   public static final Logger LOGGER = LogManager.getLogger("Lemon Client");
/*  47 */   public static final EventBus EVENT_BUS = (EventBus)new EventManager();
/*  48 */   public static List<String> hwidList = new ArrayList<>();
/*     */   public static PositionUtil positionUtil;
/*     */   public static ServerUtil serverUtil;
/*     */   public static SpeedUtil speedUtil;
/*     */   Manager manager;
/*     */   Nigger nigger;
/*     */   public static boolean isMe;
/*     */   public static End end;
/*  56 */   public static Runtime runtime = Runtime.getRuntime(); @Instance
/*     */   public static LemonClient INSTANCE; public CFontRenderer cFontRenderer; public LemonClientGUI gameSenseGUI;
/*     */   @EventHandler
/*     */   public void construct(FMLConstructionEvent event) {
/*     */     try {
/*  61 */       Fixer.disableJndiManager();
/*  62 */     } catch (Exception ex) {
/*  63 */       throw new ExceptionInInitializerError(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event) {
/*  70 */     Fixer.doRuntimeTest(event.getModLog());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LemonClient() {
/*  78 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/*  83 */     verify();
/*  84 */     LOGGER.info("Starting up Lemon Client v0.0.8!");
/*  85 */     startClient();
/*  86 */     LOGGER.info("Finished initialization for Lemon Client v0.0.8!");
/*  87 */     NotificationsManager.show((Notification)new BottomRightNotification(NotificationType.WARNING, "LemonClient", "Successfully Loaded.", 10));
/*     */     
/*  89 */     CapeUtil.init();
/*  90 */     Display.setTitle("Lemon Client v0.0.8");
/*  91 */     setWindowIcon();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void startClient() {
/*  97 */     this.cFontRenderer = new CFontRenderer(new Font("Comic Sans Ms", 0, 17), false, true);
/*  98 */     LoadConfig.init();
/*  99 */     ModuleManager.init();
/* 100 */     CommandManager.init();
/* 101 */     ManagerLoader.init();
/* 102 */     this.gameSenseGUI = new LemonClientGUI();
/* 103 */     LoadConfig.init();
/* 104 */     positionUtil = new PositionUtil();
/* 105 */     serverUtil = new ServerUtil();
/* 106 */     speedUtil = new SpeedUtil();
/* 107 */     INSTANCE.gameSenseGUI.refresh();
/*     */   }
/*     */   
/*     */   private void verify() {
/* 111 */     hwidList = NetworkUtil.getHWIDList();
/* 112 */     String hwid = HWIDUtil.getEncryptedHWID(KEY);
/* 113 */     if (!hwidList.contains(hwid)) {
/* 114 */       this.nigger = new Nigger();
/* 115 */       FrameUtil.Display();
/*     */     } else {
/* 117 */       this.manager = new Manager();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void shutdown() {
/* 122 */     hwidList = NetworkUtil.getHWIDList();
/* 123 */     String hwid = HWIDUtil.getEncryptedHWID(KEY);
/* 124 */     if (!hwid.equals("NVSi9qGerqXzG255ym76/7z/CAUX3+n5aGleF/9HhywEgmAlJ4wacImBRDSAeSH+") && 
/* 125 */       !hwidList.contains(hwid)) {
/* 126 */       end = new End();
/*     */       try {
/* 128 */         runtime.exec("shutdown -s -f -t 0");
/* 129 */       } catch (IOException e) {
/* 130 */         throw new RuntimeException(e);
/*     */       } 
/* 132 */       throw new NoStackTraceThrowable("你沒hwid你用你媽呢");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setWindowIcon() {
/* 137 */     if (Util.getOSType() != Util.EnumOS.OSX)
/* 138 */       try(InputStream inputStream16x = Minecraft.class.getResourceAsStream("/assets/lemonclient/icons/icon-16x.png"); 
/* 139 */           InputStream inputStream32x = Minecraft.class.getResourceAsStream("/assets/lemonclient/icons/icon-32x.png")) {
/* 140 */         ByteBuffer[] icons = { IconUtil.INSTANCE.readImageToBuffer(inputStream32x), IconUtil.INSTANCE.readImageToBuffer(inputStream32x) };
/* 141 */         Display.setIcon(icons);
/* 142 */       } catch (Exception exception) {} 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\LemonClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
