//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client;
/*     */ 
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.misc.ShulkerBypass;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.inventory.InventoryBasic;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.tileentity.TileEntityShulkerBox;
/*     */ import net.minecraftforge.client.ClientCommandHandler;
/*     */ import net.minecraftforge.client.IClientCommand;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mod(modid = "peek", name = "PeekBypass", version = "1", acceptedMinecraftVersions = "[1.12.2]")
/*     */ public class PeekCmd
/*     */ {
/*  28 */   public static int metadataTicks = -1;
/*  29 */   public static int guiTicks = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static ItemStack shulker = ItemStack.EMPTY;
/*  39 */   public static Minecraft mc = Minecraft.getMinecraft(); public static EntityItem drop;
/*     */   public static InventoryBasic toOpen;
/*     */   
/*     */   @EventHandler
/*     */   public void postInit(FMLPostInitializationEvent event) {
/*  44 */     ClientCommandHandler.instance.registerCommand((ICommand)new PeekCommand());
/*     */   }
/*     */   
/*     */   public static NBTTagCompound getShulkerNBT(ItemStack stack) {
/*  48 */     if (mc.player == null) return null; 
/*  49 */     NBTTagCompound compound = stack.getTagCompound();
/*  50 */     if (compound != null && compound.hasKey("BlockEntityTag", 10)) {
/*  51 */       NBTTagCompound tags = compound.getCompoundTag("BlockEntityTag");
/*  52 */       if (ModuleManager.getModule("Peek").isEnabled() && ShulkerBypass.shulkers) {
/*  53 */         if (tags.hasKey("Items", 9)) {
/*  54 */           return tags;
/*     */         }
/*  56 */         MessageBus.sendMessage("Shulker is empty.", Notification.Type.INFO, "Peek", 3, ShulkerBypass.notification);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   public static class PeekCommand
/*     */     extends CommandBase
/*     */     implements IClientCommand {
/*     */     public boolean allowUsageWithoutPrefix(ICommandSender sender, String message) {
/*  68 */       return false;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  72 */       return "peek";
/*     */     }
/*     */     
/*     */     public String getUsage(ICommandSender sender) {
/*  76 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
/*  81 */       if (PeekCmd.mc.player != null && ModuleManager.getModule("Peek").isEnabled() && ShulkerBypass.shulkers) {
/*  82 */         if (!PeekCmd.shulker.isEmpty()) {
/*  83 */           NBTTagCompound shulkerNBT = PeekCmd.getShulkerNBT(PeekCmd.shulker);
/*  84 */           if (shulkerNBT != null) {
/*  85 */             TileEntityShulkerBox fakeShulker = new TileEntityShulkerBox();
/*  86 */             fakeShulker.loadFromNbt(shulkerNBT);
/*  87 */             String customName = "container.shulkerBox";
/*  88 */             boolean hasCustomName = false;
/*  89 */             if (shulkerNBT.hasKey("CustomName", 8)) {
/*  90 */               customName = shulkerNBT.getString("CustomName");
/*  91 */               hasCustomName = true;
/*     */             } 
/*     */             
/*  94 */             InventoryBasic inv = new InventoryBasic(customName, hasCustomName, 27);
/*     */             
/*  96 */             for (int i = 0; i < 27; i++) {
/*  97 */               inv.setInventorySlotContents(i, fakeShulker.getStackInSlot(i));
/*     */             }
/*     */             
/* 100 */             PeekCmd.toOpen = inv;
/* 101 */             PeekCmd.guiTicks = 0;
/*     */           } 
/*     */         } else {
/* 104 */           MessageBus.sendMessage("No shulker detected! please drop and pickup your shulker.", Notification.Type.ERROR, "Peek", 3, ShulkerBypass.notification);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
/* 111 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\PeekCmd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
