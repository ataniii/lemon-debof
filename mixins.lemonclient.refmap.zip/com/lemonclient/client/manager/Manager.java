//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.manager;
/*    */ 
/*    */ import me.zero.alpine.listener.Listenable;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.profiler.Profiler;
/*    */ 
/*    */ public interface Manager
/*    */   extends Listenable {
/*    */   default Minecraft getMinecraft() {
/* 12 */     return Minecraft.getMinecraft();
/*    */   }
/*    */   
/*    */   default EntityPlayerSP getPlayer() {
/* 16 */     return (getMinecraft()).player;
/*    */   }
/*    */   
/*    */   default WorldClient getWorld() {
/* 20 */     return (getMinecraft()).world;
/*    */   }
/*    */   
/*    */   default Profiler getProfiler() {
/* 24 */     return (getMinecraft()).profiler;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\Manager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
