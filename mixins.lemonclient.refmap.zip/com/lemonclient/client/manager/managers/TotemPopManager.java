//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.manager.managers;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.TotemPopEvent;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*     */ 
/*     */ public enum TotemPopManager implements Manager {
/*     */   @EventHandler
/*     */   private final Listener<TotemPopEvent> totemPopEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> packetEventListener;
/*     */   private final HashMap<String, Integer> playerPopCount;
/*     */   public String type4;
/*     */   public String self;
/*     */   public boolean friend;
/*  22 */   INSTANCE; public ChatFormatting numberFormatting; public ChatFormatting friFormatting; public ChatFormatting nameFormatting; public ChatFormatting chatFormatting; public boolean sendMsgs;
/*     */   TotemPopManager() {
/*  24 */     this.sendMsgs = false;
/*  25 */     this.chatFormatting = ChatFormatting.WHITE;
/*  26 */     this.nameFormatting = ChatFormatting.WHITE;
/*  27 */     this.friFormatting = ChatFormatting.WHITE;
/*  28 */     this.numberFormatting = ChatFormatting.WHITE;
/*     */ 
/*     */ 
/*     */     
/*  32 */     this.playerPopCount = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.packetEventListener = new Listener(event -> { if (getPlayer() == null || getWorld() == null) return;  if (event.getPacket() instanceof SPacketEntityStatus) { SPacketEntityStatus packet = (SPacketEntityStatus)event.getPacket(); Entity entity = packet.getEntity((World)getWorld()); if (packet.getOpCode() == 35) LemonClient.EVENT_BUS.post(new TotemPopEvent(entity));  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.totemPopEventListener = new Listener(event -> {
/*     */           if (getPlayer() == null || getWorld() == null) {
/*     */             return;
/*     */           }
/*     */           if (event.getEntity() == null)
/*     */             return; 
/*     */           String entityName = event.getEntity().getName();
/*     */           if (this.playerPopCount.get(entityName) == null) {
/*     */             this.playerPopCount.put(entityName, Integer.valueOf(1));
/*     */             if (this.sendMsgs) {
/*     */               if ((Minecraft.getMinecraft()).player.getName().equals(entityName) && this.self.equals("Disable"))
/*     */                 return; 
/*  80 */               String name = (entityName.equals((Minecraft.getMinecraft()).player.getName()) && this.self.equals("I")) ? "I" : entityName;
/*     */               if (name.equals("") || name.equals(" "))
/*     */                 return; 
/*     */               if (name.equals("I") || (SocialManager.isFriend(name) && !this.type4.equals("Enemy"))) {
/*     */                 if (this.friend)
/*     */                   name = "My Friend " + name; 
/*     */                 MessageBus.sendClientDeleteMessage(this.friFormatting + name + this.chatFormatting + " popped " + this.numberFormatting + '\001' + this.chatFormatting + " totem.", Notification.Type.INFO, "TotemPopCounter" + name, 1000);
/*     */               } 
/*     */               if (!name.equals("I") && !SocialManager.isFriend(name) && !this.type4.equals("Friend"))
/*     */                 MessageBus.sendClientDeleteMessage(this.nameFormatting + name + this.chatFormatting + " popped " + this.numberFormatting + '\001' + this.chatFormatting + " totem.", Notification.Type.INFO, "TotemPopCounter" + name, 1000); 
/*     */             } 
/*     */           } else {
/*     */             int popCounter = ((Integer)this.playerPopCount.get(entityName)).intValue() + 1;
/*     */             this.playerPopCount.put(entityName, Integer.valueOf(popCounter));
/*     */             if (this.sendMsgs) {
/*     */               if ((Minecraft.getMinecraft()).player.getName().equals(entityName) && this.self.equals("Disable"))
/*     */                 return; 
/*  97 */               String name = (entityName.equals((Minecraft.getMinecraft()).player.getName()) && this.self.equals("I")) ? "I" : entityName;
/*     */               if (name.equals("") || name.equals(" "))
/*     */                 return; 
/*     */               if (name.equals("I") || (SocialManager.isFriend(name) && !this.type4.equals("Enemy"))) {
/*     */                 if (this.friend)
/*     */                   name = "My Friend " + name; 
/*     */                 MessageBus.sendClientDeleteMessage(this.friFormatting + name + this.chatFormatting + " popped " + this.numberFormatting + popCounter + this.chatFormatting + " totems.", Notification.Type.INFO, "TotemPopCounter" + name, 1000);
/*     */               } 
/*     */               if (!name.equals("I") && !SocialManager.isFriend(name) && !this.type4.equals("Friend"))
/*     */                 MessageBus.sendClientDeleteMessage(this.nameFormatting + name + this.chatFormatting + " popped " + this.numberFormatting + popCounter + this.chatFormatting + " totems.", Notification.Type.INFO, "TotemPopCounter" + name, 1000); 
/*     */             } 
/*     */           } 
/*     */         }new java.util.function.Predicate[0]);
/*     */   }
/*     */   public int getPlayerPopCount(String name) {
/* 112 */     if (this.playerPopCount.containsKey(name)) {
/* 113 */       return ((Integer)this.playerPopCount.get(name)).intValue();
/*     */     }
/*     */     
/* 116 */     return 0;
/*     */   }
/*     */   
/*     */   public void death(EntityPlayer entityPlayer) {
/*     */     if (!this.playerPopCount.containsKey(entityPlayer.getName()))
/*     */       return; 
/*     */     int pop = getPlayerPopCount(entityPlayer.getName());
/*     */     if (this.sendMsgs) {
/*     */       if ((Minecraft.getMinecraft()).player.getName().equals(entityPlayer.getName()) && this.self.equals("Disable"))
/*     */         return; 
/*     */       String name = (entityPlayer.getName().equals((Minecraft.getMinecraft()).player.getName()) && this.self.equals("I")) ? "I" : entityPlayer.getName();
/*     */       if (name.equals("") || name.equals(" "))
/*     */         return; 
/*     */       if (name.equals("I") || (SocialManager.isFriend(name) && !this.type4.equals("Enemy"))) {
/*     */         if (this.friend)
/*     */           name = "My Friend " + name; 
/*     */         MessageBus.sendClientPrefixMessage(this.friFormatting + name + this.chatFormatting + " died after popping " + this.numberFormatting + getPlayerPopCount(entityPlayer.getName()) + this.chatFormatting + " totem" + ((pop > 1) ? "s." : "."), Notification.Type.INFO);
/*     */       } 
/*     */       if (!name.equals("I") && !SocialManager.isFriend(name) && !this.type4.equals("Friend"))
/*     */         MessageBus.sendClientPrefixMessage(this.nameFormatting + name + this.chatFormatting + " died after popping " + this.numberFormatting + getPlayerPopCount(entityPlayer.getName()) + this.chatFormatting + " totem" + ((pop > 1) ? "s." : "."), Notification.Type.INFO); 
/*     */     } 
/*     */     this.playerPopCount.remove(entityPlayer.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\managers\TotemPopManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
