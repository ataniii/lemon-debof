//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.manager.managers;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerJoinEvent;
/*     */ import com.lemonclient.api.event.events.Render2DEvent;
/*     */ import com.lemonclient.api.event.events.Render3DEvent;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.event.events.SendMessageEvent;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.NameUtil;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.api.util.world.TimerUtils;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.PeekCmd;
/*     */ import com.lemonclient.client.command.CommandManager;
/*     */ import com.lemonclient.client.manager.Manager;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.dev.AntiPush;
/*     */ import com.lemonclient.client.module.modules.misc.ShulkerBypass;
/*     */ import com.lemonclient.mixin.mixins.accessor.AccessorCPacketCustomPayload;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.network.play.client.CPacketCustomPayload;
/*     */ import net.minecraft.network.play.server.SPacketPlayerListItem;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraftforge.client.event.ClientChatEvent;
/*     */ import net.minecraftforge.client.event.ClientChatReceivedEvent;
/*     */ import net.minecraftforge.client.event.EntityViewRenderEvent;
/*     */ import net.minecraftforge.client.event.GuiOpenEvent;
/*     */ import net.minecraftforge.client.event.InputUpdateEvent;
/*     */ import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
/*     */ import net.minecraftforge.client.event.RenderBlockOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.event.entity.EntityJoinWorldEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.player.AttackEntityEvent;
/*     */ import net.minecraftforge.event.world.WorldEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public enum ClientEventManager implements Manager {
/*  59 */   INSTANCE; @EventHandler private final Listener<PacketEvent.Receive> receiveListener; @EventHandler
/*  60 */   private final Listener<PacketEvent.Send> packetSend; final Set<Character> lagMessageSet; final String LAG_MESSAGE = "�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�? �?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?"; ClientEventManager() { this.LAG_MESSAGE = "�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�? �?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?";
/*  61 */     this.lagMessageSet = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     this.packetSend = new Listener(event -> { if (event.getPacket() instanceof net.minecraftforge.fml.common.network.internal.FMLProxyPacket && !Minecraft.getMinecraft().isSingleplayer()) event.cancel();  if (event.getPacket() instanceof CPacketCustomPayload) { CPacketCustomPayload packet = (CPacketCustomPayload)event.getPacket(); if (packet.getChannelName().equalsIgnoreCase("MC|Brand")) ((AccessorCPacketCustomPayload)packet).setData((new PacketBuffer(Unpooled.buffer())).writeString("vanilla"));  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof SPacketPlayerListItem) { SPacketPlayerListItem packet = (SPacketPlayerListItem)event.getPacket(); if (packet.getAction() == SPacketPlayerListItem.Action.ADD_PLAYER) for (SPacketPlayerListItem.AddPlayerData playerData : packet.getEntries()) { if (playerData.getProfile().getId() != (getMinecraft()).session.getProfile().getId()) (new Thread(())).start();  }   if (packet.getAction() == SPacketPlayerListItem.Action.REMOVE_PLAYER) for (SPacketPlayerListItem.AddPlayerData playerData : packet.getEntries()) { if (playerData.getProfile().getId() != (getMinecraft()).session.getProfile().getId()) (new Thread(())).start();  }   }  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate) LemonClient.serverUtil.update();  }new java.util.function.Predicate[0]); }
/*     */   @SubscribeEvent(priority = EventPriority.LOW) public void onRenderGameOverlayEvent(RenderGameOverlayEvent.Text event) { if (event.getType().equals(RenderGameOverlayEvent.ElementType.TEXT)) {
/*     */       ScaledResolution resolution = new ScaledResolution(Minecraft.getMinecraft()); Render2DEvent render2DEvent = new Render2DEvent(event.getPartialTicks(), resolution); for (Module module : ModuleManager.getModules()) {
/*     */         if (!module.isEnabled())
/*     */           continue;  getProfiler().startSection(module.getName()); module.onRender2D(render2DEvent);
/*     */         getProfiler().endSection();
/*     */         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       } 
/*     */     } 
/*     */     LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onChatReceived(ClientChatReceivedEvent event) { if (this.lagMessageSet.isEmpty())
/*     */       for (int i = 0; i < "�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�? �?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?".length(); i++)
/*     */         this.lagMessageSet.add(Character.valueOf("�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�? �?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?�?�?�?�?�?�?�??�?�?�?�?�?�?�?�?�?".charAt(i)));  
/*     */     if (event.getMessage().getFormattedText().contains("{") || event.getMessage().getFormattedText().contains("}")) {
/*     */       event.setCanceled(true);
/*     */       TextComponentString string = new TextComponentString(event.getMessage().getFormattedText().replace("{", "").replace("}", "").replace("$", "").replace("ldap", ""));
/*     */       (Minecraft.getMinecraft()).player.sendMessage((ITextComponent)string);
/*     */       return;
/*     */     } 
/*     */     if (ModuleManager.isModuleEnabled(AntiUnicdoe.class)) {
/*     */       int count = 0;
/*     */       String text = event.getMessage().getFormattedText();
/*     */       for (int i = 0; i < text.length(); i++) {
/*     */         if (this.lagMessageSet.contains(Character.valueOf(text.charAt(i))))
/*     */           count++; 
/*     */       } 
/*     */       if (count >= 25) {
/*     */         event.setCanceled(true);
/*     */         TextComponentString string = new TextComponentString("(lag message)");
/*     */         (Minecraft.getMinecraft()).player.sendMessage((ITextComponent)string);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onAttackEntity(AttackEntityEvent event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onRenderBlockOverlay(RenderBlockOverlayEvent event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onLivingEntityUseItemFinish(LivingEntityUseItemEvent.Finish event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onInputUpdate(InputUpdateEvent event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onLivingDeath(LivingDeathEvent event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onPlayerPush(PlayerSPPushOutOfBlocksEvent event) { if (ModuleManager.isModuleEnabled(AntiPush.class))
/*     */       event.setCanceled(true); 
/* 293 */     LemonClient.EVENT_BUS.post(event); } @SubscribeEvent public void onUpdate(LivingEvent.LivingUpdateEvent event) { if ((getMinecraft()).player == null || (getMinecraft()).world == null)
/*     */       return; 
/* 295 */     if ((event.getEntity().getEntityWorld()).isRemote && event.getEntityLiving() == getPlayer())
/* 296 */     { int timerSpeed = (int)TimerUtils.getTimer();
/* 297 */       for (Module module : ModuleManager.getModules()) {
/*     */         try {
/* 299 */           if (module.isEnabled()) {
/* 300 */             module.onUpdateTimer++;
/* 301 */             if (module.onUpdateTimer >= timerSpeed) {
/* 302 */               module.onUpdate();
/* 303 */               module.onUpdateTimer = 0;
/*     */             } 
/*     */           } 
/* 306 */         } catch (Exception e) {
/* 307 */           if (getWorld() != null && getPlayer() != null)
/* 308 */             MessageBus.sendClientPrefixMessage("Disabled " + module.getName() + " due to " + e, Notification.Type.ERROR); 
/* 309 */           module.setEnabled(false);
/* 310 */           for (StackTraceElement stack : e.getStackTrace()) {
/* 311 */             System.out.println(stack.toString());
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 316 */       LemonClient.EVENT_BUS.post(event); }  }
/*     */   @SubscribeEvent public void onEntitySpawn(EntityJoinWorldEvent event) { Entity entity = event.getEntity(); if (entity instanceof EntityItem) { PeekCmd.drop = (EntityItem)entity; PeekCmd.metadataTicks = 0; }  }
/*     */   @SubscribeEvent public void onWorldLoad(WorldEvent.Load event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onWorldUnload(WorldEvent.Unload event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onGuiOpen(GuiOpenEvent event) { LemonClient.EVENT_BUS.post(event); }
/*     */   @SubscribeEvent public void onFogColor(EntityViewRenderEvent.FogColors event) { LemonClient.EVENT_BUS.post(event); }
/* 322 */   @SubscribeEvent public void onFogDensity(EntityViewRenderEvent.FogDensity event) { LemonClient.EVENT_BUS.post(event); } @SubscribeEvent public void onFov(EntityViewRenderEvent.FOVModifier event) { LemonClient.EVENT_BUS.post(event); } @SubscribeEvent public void onTick(TickEvent.ClientTickEvent event) { if (ModuleManager.isModuleEnabled("Peek") && ShulkerBypass.shulkers) { if (event.phase == TickEvent.Phase.END) { if (PeekCmd.guiTicks > -1) PeekCmd.guiTicks++;  if (PeekCmd.metadataTicks > -1) PeekCmd.metadataTicks++;  }  if (PeekCmd.metadataTicks >= ShulkerBypass.delay) { PeekCmd.metadataTicks = -1; if (PeekCmd.drop.getItem().getItem() instanceof net.minecraft.item.ItemShulkerBox) { MessageBus.sendClientDeleteMessage("New shulker found. use /peek to view its content " + TextFormatting.GREEN + "(" + PeekCmd.drop.getItem().getDisplayName() + ")", Notification.Type.INFO, "Peek", 3); PeekCmd.shulker = PeekCmd.drop.getItem(); }  }  if (PeekCmd.guiTicks == 20) { PeekCmd.guiTicks = -1; (Minecraft.getMinecraft()).player.displayGUIChest((IInventory)PeekCmd.toOpen); }  }  if ((getMinecraft()).player != null && (getMinecraft()).world != null) { int timerSpeed = (int)TimerUtils.getTimer(); for (Module module : ModuleManager.getModules()) { try { if (module.isEnabled()) { module.onTickTimer++; if (module.onTickTimer >= timerSpeed) { module.onTick(); module.onTickTimer = 0; }  }  } catch (Exception e) { if (getWorld() != null && getPlayer() != null) MessageBus.sendClientPrefixMessage("Disabled " + module.getName() + " due to " + e, Notification.Type.ERROR);  module.setEnabled(false); for (StackTraceElement stack : e.getStackTrace()) System.out.println(stack.toString());  }  }  }  LemonClient.EVENT_BUS.post(event); } @SubscribeEvent public void onWorldRender(RenderWorldLastEvent event) { if (event.isCanceled())
/* 323 */       return;  if ((getMinecraft()).player == null || (getMinecraft()).world == null)
/*     */       return; 
/* 325 */     getProfiler().startSection("lemonclient");
/* 326 */     getProfiler().startSection("setup");
/* 327 */     RenderUtil.prepare();
/* 328 */     RenderEvent event1 = new RenderEvent(event.getPartialTicks());
/* 329 */     getProfiler().endSection();
/*     */     
/* 331 */     for (Module module : ModuleManager.getModules()) {
/* 332 */       if (!module.isEnabled())
/* 333 */         continue;  getProfiler().startSection(module.getName());
/* 334 */       module.onWorldRender(event1);
/* 335 */       getProfiler().endSection();
/*     */     } 
/*     */     
/* 338 */     getProfiler().startSection("release");
/* 339 */     RenderUtil.release();
/*     */     
/* 341 */     getProfiler().endSection();
/* 342 */     getProfiler().endSection(); }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRender3D(RenderWorldLastEvent event) {
/* 347 */     if (event.isCanceled())
/* 348 */       return;  if ((getMinecraft()).player == null || (getMinecraft()).world == null)
/*     */       return; 
/* 350 */     getProfiler().startSection("lemonclient");
/* 351 */     getProfiler().startSection("setup");
/* 352 */     GlStateManager.disableTexture2D();
/* 353 */     GlStateManager.enableBlend();
/* 354 */     GlStateManager.disableAlpha();
/* 355 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 356 */     GlStateManager.shadeModel(7425);
/* 357 */     GlStateManager.disableDepth();
/* 358 */     GlStateManager.glLineWidth(1.0F);
/* 359 */     Render3DEvent event2 = new Render3DEvent(event.getPartialTicks());
/* 360 */     getProfiler().endSection();
/*     */     
/* 362 */     for (Module module : ModuleManager.getModules()) {
/* 363 */       if (!module.isEnabled())
/* 364 */         continue;  getProfiler().startSection(module.getName());
/* 365 */       module.onRender3D(event2);
/* 366 */       getProfiler().endSection();
/*     */     } 
/*     */     
/* 369 */     getProfiler().startSection("release");
/* 370 */     GlStateManager.glLineWidth(1.0F);
/* 371 */     GlStateManager.shadeModel(7424);
/* 372 */     GlStateManager.disableBlend();
/* 373 */     GlStateManager.enableAlpha();
/* 374 */     GlStateManager.enableTexture2D();
/* 375 */     GlStateManager.enableDepth();
/* 376 */     GlStateManager.enableCull();
/* 377 */     GlStateManager.enableCull();
/* 378 */     GlStateManager.depthMask(true);
/* 379 */     GlStateManager.enableTexture2D();
/* 380 */     GlStateManager.enableBlend();
/* 381 */     GlStateManager.enableDepth();
/*     */     
/* 383 */     getProfiler().endSection();
/* 384 */     getProfiler().endSection();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRender(RenderGameOverlayEvent.Post event) {
/* 389 */     if ((getMinecraft()).player == null || (getMinecraft()).world == null)
/*     */       return; 
/* 391 */     if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
/* 392 */       for (Module module : ModuleManager.getModules()) {
/* 393 */         if (!module.isEnabled())
/* 394 */           continue;  module.onRender();
/* 395 */         NotificationManager.draw();
/*     */       } 
/*     */ 
/*     */       
/* 399 */       LemonClient.INSTANCE.gameSenseGUI.render();
/*     */     } 
/*     */     
/* 402 */     LemonClient.EVENT_BUS.post(event);
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 407 */     if (!Keyboard.getEventKeyState() || Keyboard.getEventKey() == 0)
/*     */       return; 
/* 409 */     EntityPlayerSP player = getPlayer();
/* 410 */     if (player != null && !player.isSneaking()) {
/* 411 */       String prefix = CommandManager.getCommandPrefix();
/* 412 */       char typedChar = Keyboard.getEventCharacter();
/* 413 */       if (prefix.length() == 1 && prefix.charAt(0) == typedChar) {
/* 414 */         getMinecraft().displayGuiScreen((GuiScreen)new GuiChat(prefix));
/*     */       }
/*     */     } 
/*     */     
/* 418 */     int key = Keyboard.getEventKey();
/*     */     
/* 420 */     if (key != 0) {
/* 421 */       for (Module module : ModuleManager.getModules()) {
/* 422 */         if (module.getBind() != key)
/* 423 */           continue;  module.toggle();
/*     */       } 
/*     */     }
/*     */     
/* 427 */     LemonClient.INSTANCE.gameSenseGUI.handleKeyEvent(Keyboard.getEventKey());
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMouseInput(InputEvent.MouseInputEvent event) {
/* 432 */     if (Mouse.getEventButtonState()) {
/* 433 */       LemonClient.EVENT_BUS.post(event);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onChatSent(ClientChatEvent event) {
/* 439 */     if (event.getMessage().startsWith(CommandManager.getCommandPrefix())) {
/* 440 */       event.setCanceled(true);
/*     */       try {
/* 442 */         (getMinecraft()).ingameGUI.getChatGUI().addToSentMessages(event.getMessage());
/* 443 */         CommandManager.callCommand(event.getMessage().substring(1), false);
/* 444 */       } catch (Exception e) {
/* 445 */         e.printStackTrace();
/* 446 */         MessageBus.sendCommandMessage(ChatFormatting.DARK_RED + "Error: " + e.getMessage(), true);
/*     */       } 
/*     */     } else {
/* 449 */       SendMessageEvent eventNow = new SendMessageEvent(event.getMessage());
/* 450 */       LemonClient.EVENT_BUS.post(eventNow);
/* 451 */       if (eventNow.isCancelled())
/* 452 */         event.setCanceled(true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void init(TickEvent.ClientTickEvent event) {
/* 458 */     fastest();
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void init(TickEvent.ServerTickEvent event) {
/* 462 */     fastest();
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void init(TickEvent.PlayerTickEvent event) {
/* 466 */     fastest();
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void init(TickEvent.WorldTickEvent event) {
/* 470 */     fastest();
/*     */   }
/*     */   
/*     */   public void fastest() {
/* 474 */     if ((getMinecraft()).player != null && (getMinecraft()).world != null) {
/* 475 */       int timerSpeed = (int)TimerUtils.getTimer();
/* 476 */       for (Module module : ModuleManager.getModules()) {
/*     */         try {
/* 478 */           if (module.isEnabled()) {
/* 479 */             module.fastTimer++;
/* 480 */             if (module.fastTimer >= timerSpeed) {
/* 481 */               module.fast();
/* 482 */               module.fastTimer = 0;
/*     */             } 
/*     */           } 
/* 485 */         } catch (Exception e) {
/* 486 */           if (getWorld() != null && getPlayer() != null)
/* 487 */             MessageBus.sendClientPrefixMessage("Disabled " + module.getName() + " due to " + e, Notification.Type.ERROR); 
/* 488 */           module.setEnabled(false);
/* 489 */           for (StackTraceElement stack : e.getStackTrace())
/* 490 */             System.out.println(stack.toString()); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\managers\ClientEventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
