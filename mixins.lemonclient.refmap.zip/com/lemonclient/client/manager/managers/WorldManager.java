/*   */ package com.lemonclient.client.manager.managers;
/*   */ 
/*   */ public enum WorldManager {
/*   */ 
/*   */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\managers\WorldManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */