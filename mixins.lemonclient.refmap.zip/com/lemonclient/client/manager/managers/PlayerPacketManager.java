//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.manager.managers;
/*     */ 
/*     */ import com.lemonclient.api.event.Phase;
/*     */ import com.lemonclient.api.event.events.OnUpdateWalkingPlayerEvent;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.RenderEntityEvent;
/*     */ import com.lemonclient.api.util.misc.CollectionUtil;
/*     */ import com.lemonclient.api.util.player.PlayerPacket;
/*     */ import com.lemonclient.client.manager.Manager;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.render.F5Fix;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ 
/*     */ 
/*     */ public enum PlayerPacketManager
/*     */   implements Manager
/*     */ {
/*  27 */   INSTANCE; @EventHandler private final Listener<RenderEntityEvent.Return> renderEntityEventReturnListener; @EventHandler private final Listener<RenderEntityEvent.Head> renderEntityEventHeadListener; @EventHandler private final Listener<TickEvent.ClientTickEvent> tickEventListener; @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> postSendListener; @EventHandler
/*  29 */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener; PlayerPacketManager() { this.packets = new ArrayList<>();
/*     */     
/*  31 */     this.prevServerSidePosition = Vec3d.ZERO;
/*  32 */     this.serverSidePosition = Vec3d.ZERO;
/*     */     
/*  34 */     this.prevServerSideRotation = Vec2f.ZERO;
/*  35 */     this.serverSideRotation = Vec2f.ZERO;
/*  36 */     this.clientSidePitch = Vec2f.ZERO;
/*     */     
/*  38 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (event.getPhase() != Phase.BY || this.packets.isEmpty()) return;  PlayerPacket packet = (PlayerPacket)CollectionUtil.maxOrNull(this.packets, PlayerPacket::getPriority); if (packet != null) { event.cancel(); event.apply(packet); }  this.packets.clear(); }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.postSendListener = new Listener(event -> { if (event.isCancelled()) return;  Packet<?> rawPacket = event.getPacket(); EntityPlayerSP player = getPlayer(); if (player != null && rawPacket instanceof CPacketPlayer) { CPacketPlayer packet = (CPacketPlayer)rawPacket; if (packet.moving) this.serverSidePosition = new Vec3d(packet.x, packet.y, packet.z);  if (packet.rotating) { this.serverSideRotation = new Vec2f(packet.yaw, packet.pitch); player.rotationYawHead = packet.yaw; }  }  }-200, new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.tickEventListener = new Listener(event -> { if (event.phase != TickEvent.Phase.START) return;  this.prevServerSidePosition = this.serverSidePosition; this.prevServerSideRotation = this.serverSideRotation; }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.renderEntityEventHeadListener = new Listener(event -> { if (!ModuleManager.isModuleEnabled(F5Fix.class)) return;  EntityPlayerSP player = getPlayer(); if (player == null || player.isRiding() || event.getType() != RenderEntityEvent.Type.TEXTURE || event.getEntity() != player) return;  this.clientSidePitch = new Vec2f(player.prevRotationPitch, player.rotationPitch); player.prevRotationPitch = this.prevServerSideRotation.y; player.rotationPitch = this.serverSideRotation.y; }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     this.renderEntityEventReturnListener = new Listener(event -> { if (!ModuleManager.isModuleEnabled(F5Fix.class)) return;  EntityPlayerSP player = getPlayer(); if (player == null || player.isRiding() || event.getType() != RenderEntityEvent.Type.TEXTURE || event.getEntity() != player) return;  player.prevRotationPitch = this.clientSidePitch.x; player.rotationPitch = this.clientSidePitch.y; }new java.util.function.Predicate[0]); }
/*     */ 
/*     */ 
/*     */   
/*     */   private Vec2f clientSidePitch;
/*     */   
/*     */   private Vec2f serverSideRotation;
/*     */   
/*     */   private Vec2f prevServerSideRotation;
/*     */   private Vec3d serverSidePosition;
/*     */   private Vec3d prevServerSidePosition;
/*     */   private final List<PlayerPacket> packets;
/*     */   
/*     */   public void addPacket(PlayerPacket packet) {
/* 112 */     this.packets.add(packet);
/*     */   }
/*     */   
/*     */   public Vec3d getPrevServerSidePosition() {
/* 116 */     return this.prevServerSidePosition;
/*     */   }
/*     */   
/*     */   public Vec3d getServerSidePosition() {
/* 120 */     return this.serverSidePosition;
/*     */   }
/*     */   
/*     */   public Vec2f getPrevServerSideRotation() {
/* 124 */     return this.prevServerSideRotation;
/*     */   }
/*     */   
/*     */   public Vec2f getServerSideRotation() {
/* 128 */     return this.serverSideRotation;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\managers\PlayerPacketManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
