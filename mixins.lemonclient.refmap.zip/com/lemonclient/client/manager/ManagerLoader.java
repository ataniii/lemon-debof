/*    */ package com.lemonclient.client.manager;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.manager.managers.ClientEventManager;
/*    */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*    */ import com.lemonclient.client.manager.managers.TotemPopManager;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ 
/*    */ 
/*    */ public class ManagerLoader
/*    */ {
/* 14 */   private static final List<Manager> managers = new ArrayList<>();
/*    */   
/*    */   public static void init() {
/* 17 */     register((Manager)ClientEventManager.INSTANCE);
/* 18 */     register((Manager)PlayerPacketManager.INSTANCE);
/* 19 */     register((Manager)TotemPopManager.INSTANCE);
/*    */   }
/*    */   
/*    */   private static void register(Manager manager) {
/* 23 */     managers.add(manager);
/* 24 */     LemonClient.EVENT_BUS.subscribe(manager);
/* 25 */     MinecraftForge.EVENT_BUS.register(manager);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\manager\ManagerLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */