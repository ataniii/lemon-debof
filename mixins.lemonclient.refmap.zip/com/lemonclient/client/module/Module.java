//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module;
/*     */ import com.lemonclient.api.event.events.Render2DEvent;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.Setting;
/*     */ import com.lemonclient.api.setting.SettingsManager;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.setting.values.StringSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import me.zero.alpine.listener.Listenable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ public abstract class Module implements Listenable {
/*  28 */   protected static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private final String name = getDeclaration().name();
/*  49 */   private final Category category = getDeclaration().category();
/*  50 */   private final int priority = getDeclaration().priority();
/*  51 */   private int bind = getDeclaration().bind();
/*  52 */   private boolean enabled = getDeclaration().enabled();
/*  53 */   private boolean drawn = getDeclaration().drawn();
/*  54 */   private boolean toggleMsg = getDeclaration().toggleMsg(); public float remainingAnimation; public int onUpdateTimer;
/*     */   public int onTickTimer;
/*     */   public int fastTimer;
/*     */   
/*     */   private Declaration getDeclaration() {
/*  59 */     return getClass().<Declaration>getAnnotation(Declaration.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onTick() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void fast() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onEnable() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onDisable() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {}
/*     */ 
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/*  92 */     this.remainingAnimation++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {}
/*     */   
/*     */   public boolean isEnabled() {
/*  99 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 103 */     this.enabled = enabled;
/*     */   }
/*     */   
/* 106 */   private String disabledMessage = "";
/*     */   
/*     */   public void setDisabledMessage(String message) {
/* 109 */     this.disabledMessage = message;
/*     */   }
/*     */   
/*     */   public void enable() {
/* 113 */     setEnabled(true);
/* 114 */     LemonClient.EVENT_BUS.subscribe(this);
/*     */     try {
/* 116 */       onEnable();
/* 117 */     } catch (Exception e) {
/* 118 */       MessageBus.sendClientPrefixMessage("Disabled " + getName() + " due to " + e, Notification.Type.ERROR);
/* 119 */       for (StackTraceElement stack : e.getStackTrace()) {
/* 120 */         System.out.println(stack.toString());
/*     */       }
/*     */     } 
/* 123 */     if (this.toggleMsg && mc.world != null && mc.player != null) {
/* 124 */       MessageBus.sendClientDeleteMessage(((ColorMain)ModuleManager.<ColorMain>getModule(ColorMain.class)).getModuleColor() + this.name + ChatFormatting.GRAY + " turned " + ((ColorMain)ModuleManager.<ColorMain>getModule(ColorMain.class)).getEnabledColor() + "ON" + ChatFormatting.GRAY + ".", Notification.Type.SUCCESS, getName(), 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void disable() {
/* 129 */     setEnabled(false);
/* 130 */     LemonClient.EVENT_BUS.unsubscribe(this);
/*     */     try {
/* 132 */       onDisable();
/* 133 */     } catch (Exception e) {
/* 134 */       MessageBus.sendClientPrefixMessage("Failed to Disable " + getName() + "properly due to " + e, Notification.Type.ERROR);
/* 135 */       for (StackTraceElement stack : e.getStackTrace()) {
/* 136 */         System.out.println(stack.toString());
/*     */       }
/*     */     } 
/* 139 */     if (this.toggleMsg && mc.world != null && mc.player != null) {
/* 140 */       MessageBus.sendClientDeleteMessage(this.disabledMessage.isEmpty() ? (((ColorMain)ModuleManager.<ColorMain>getModule(ColorMain.class)).getModuleColor() + this.name + ChatFormatting.GRAY + " turned " + ((ColorMain)ModuleManager.<ColorMain>getModule(ColorMain.class)).getDisabledColor() + "OFF" + TextFormatting.GRAY + ".") : this.disabledMessage, Notification.Type.DISABLE, getName(), 0);
/*     */     }
/* 142 */     this.disabledMessage = "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getIdFromString(String name) {
/* 147 */     StringBuilder s = new StringBuilder();
/*     */     
/* 149 */     name = name.replace("禮", "e");
/*     */     
/* 151 */     String blacklist = "[^a-z]";
/*     */     
/* 153 */     for (int i = 0; i < name.length(); i++) {
/* 154 */       s.append(Integer.parseInt(String.valueOf(name.charAt(i)).replaceAll(blacklist, "e"), 36));
/*     */     }
/*     */     try {
/* 157 */       s = new StringBuilder(s.substring(0, 8));
/* 158 */     } catch (StringIndexOutOfBoundsException ignored) {
/* 159 */       s = new StringBuilder(2147483647);
/*     */     } 
/*     */     
/* 162 */     return Integer.MAX_VALUE - Integer.parseInt(s.toString().toLowerCase());
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggle() {
/* 167 */     if (isEnabled()) { disable(); }
/* 168 */     else { enable(); }
/*     */   
/*     */   }
/*     */   public String getName() {
/* 172 */     return this.name;
/*     */   }
/*     */   
/*     */   public Category getCategory() {
/* 176 */     return this.category;
/*     */   }
/*     */   
/*     */   public int getPriority() {
/* 180 */     return this.priority;
/*     */   }
/*     */   
/*     */   public int getBind() {
/* 184 */     return this.bind;
/*     */   }
/*     */   
/*     */   public void setBind(int bind) {
/* 188 */     if (bind >= 0 && bind <= 255) {
/* 189 */       this.bind = bind;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHudInfo() {
/* 194 */     return "";
/*     */   }
/*     */   
/*     */   public boolean isDrawn() {
/* 198 */     return this.drawn;
/*     */   }
/*     */   
/*     */   public void setDrawn(boolean drawn) {
/* 202 */     this.drawn = drawn;
/*     */   }
/*     */   
/*     */   public boolean isToggleMsg() {
/* 206 */     return this.toggleMsg;
/*     */   }
/*     */   
/*     */   public void setToggleMsg(boolean toggleMsg) {
/* 210 */     this.toggleMsg = toggleMsg;
/*     */   }
/*     */   
/*     */   protected IntegerSetting registerInteger(String name, int value, int min, int max) {
/* 214 */     IntegerSetting integerSetting = new IntegerSetting(name, this, value, min, max);
/* 215 */     SettingsManager.addSetting((Setting)integerSetting);
/* 216 */     return integerSetting;
/*     */   }
/*     */   
/*     */   protected IntegerSetting registerInteger(String name, int value, int min, int max, Supplier<Boolean> dipendent) {
/* 220 */     IntegerSetting integerSetting = new IntegerSetting(name, this, value, min, max);
/* 221 */     integerSetting.setVisible(dipendent);
/* 222 */     SettingsManager.addSetting((Setting)integerSetting);
/* 223 */     return integerSetting;
/*     */   }
/*     */   
/*     */   protected StringSetting registerString(String name, String value) {
/* 227 */     StringSetting stringSetting = new StringSetting(name, this, value);
/* 228 */     SettingsManager.addSetting((Setting)stringSetting);
/* 229 */     return stringSetting;
/*     */   }
/*     */   
/*     */   protected StringSetting registerString(String name, String value, Supplier<Boolean> dipendent) {
/* 233 */     StringSetting stringSetting = new StringSetting(name, this, value);
/* 234 */     stringSetting.setVisible(dipendent);
/* 235 */     SettingsManager.addSetting((Setting)stringSetting);
/* 236 */     return stringSetting;
/*     */   }
/*     */   
/*     */   protected DoubleSetting registerDouble(String name, double value, double min, double max) {
/* 240 */     DoubleSetting doubleSetting = new DoubleSetting(name, this, value, min, max);
/* 241 */     SettingsManager.addSetting((Setting)doubleSetting);
/* 242 */     return doubleSetting;
/*     */   }
/*     */   
/*     */   protected DoubleSetting registerDouble(String name, double value, double min, double max, Supplier<Boolean> dipendent) {
/* 246 */     DoubleSetting doubleSetting = new DoubleSetting(name, this, value, min, max);
/* 247 */     doubleSetting.setVisible(dipendent);
/* 248 */     SettingsManager.addSetting((Setting)doubleSetting);
/* 249 */     return doubleSetting;
/*     */   }
/*     */   
/*     */   protected BooleanSetting registerBoolean(String name, boolean value) {
/* 253 */     BooleanSetting booleanSetting = new BooleanSetting(name, this, value);
/* 254 */     SettingsManager.addSetting((Setting)booleanSetting);
/* 255 */     return booleanSetting;
/*     */   }
/*     */   
/*     */   protected BooleanSetting registerBoolean(String name, boolean value, Supplier<Boolean> dipendent) {
/* 259 */     BooleanSetting booleanSetting = new BooleanSetting(name, this, value);
/* 260 */     booleanSetting.setVisible(dipendent);
/* 261 */     SettingsManager.addSetting((Setting)booleanSetting);
/* 262 */     return booleanSetting;
/*     */   }
/*     */   
/*     */   protected ModeSetting registerMode(String name, List<String> modes, String value) {
/* 266 */     ModeSetting modeSetting = new ModeSetting(name, this, value, modes);
/* 267 */     SettingsManager.addSetting((Setting)modeSetting);
/* 268 */     return modeSetting;
/*     */   }
/*     */   
/*     */   protected ModeSetting registerMode(String name, List<String> modes, String value, Supplier<Boolean> dipendent) {
/* 272 */     ModeSetting modeSetting = new ModeSetting(name, this, value, modes);
/* 273 */     modeSetting.setVisible(dipendent);
/* 274 */     SettingsManager.addSetting((Setting)modeSetting);
/* 275 */     return modeSetting;
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name, GSColor color) {
/* 279 */     ColorSetting colorSetting = new ColorSetting(name, this, false, color);
/* 280 */     SettingsManager.addSetting((Setting)colorSetting);
/* 281 */     return colorSetting;
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name, GSColor color, Supplier<Boolean> dipendent) {
/* 285 */     ColorSetting colorSetting = new ColorSetting(name, this, false, color);
/* 286 */     colorSetting.setVisible(dipendent);
/* 287 */     colorSetting.alphaEnabled();
/* 288 */     SettingsManager.addSetting((Setting)colorSetting);
/* 289 */     return colorSetting;
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name, GSColor color, Boolean alphaEnabled) {
/* 293 */     ColorSetting colorSetting = new ColorSetting(name, this, false, color, alphaEnabled.booleanValue());
/* 294 */     colorSetting.alphaEnabled();
/* 295 */     SettingsManager.addSetting((Setting)colorSetting);
/* 296 */     return colorSetting;
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name, GSColor color, Supplier<Boolean> dipendent, Boolean alphaEnabled) {
/* 300 */     ColorSetting colorSetting = new ColorSetting(name, this, false, color, alphaEnabled.booleanValue());
/* 301 */     colorSetting.setVisible(dipendent);
/* 302 */     colorSetting.alphaEnabled();
/* 303 */     SettingsManager.addSetting((Setting)colorSetting);
/* 304 */     return colorSetting;
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name) {
/* 308 */     return registerColor(name, new GSColor(90, 145, 240));
/*     */   }
/*     */   
/*     */   protected ColorSetting registerColor(String name, Supplier<Boolean> dipendent) {
/* 312 */     ColorSetting color = registerColor(name, new GSColor(90, 145, 240));
/* 313 */     color.setVisible(dipendent);
/* 314 */     return color;
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({ElementType.TYPE})
/*     */   public static @interface Declaration {
/*     */     String name();
/*     */     
/*     */     Category category();
/*     */     
/*     */     int priority() default 0;
/*     */     
/*     */     int bind() default 0;
/*     */     
/*     */     boolean enabled() default false;
/*     */     
/*     */     boolean drawn() default true;
/*     */     
/*     */     boolean toggleMsg() default false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
