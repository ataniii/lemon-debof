/*    */ package com.lemonclient.client.module;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.ClassUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class ModuleManager
/*    */ {
/*    */   private static final String modulePath = "com.lemonclient.client.module.modules";
/* 12 */   private static final LinkedHashMap<Class<? extends Module>, Module> modulesClassMap = new LinkedHashMap<>();
/* 13 */   private static final LinkedHashMap<String, Module> modulesNameMap = new LinkedHashMap<>();
/*    */   
/*    */   public static void init() {
/* 16 */     for (Category category : Category.values()) {
/* 17 */       for (Class<?> clazz : (Iterable<Class<?>>)ClassUtil.findClassesInPath("com.lemonclient.client.module.modules." + category.toString().toLowerCase())) {
/*    */         
/* 19 */         if (clazz == null)
/*    */           continue; 
/* 21 */         if (Module.class.isAssignableFrom(clazz)) {
/*    */           try {
/* 23 */             Module module = (Module)clazz.newInstance();
/* 24 */             addMod(module);
/* 25 */           } catch (InstantiationException|IllegalAccessException e) {
/* 26 */             e.printStackTrace();
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void addMod(Module module) {
/* 34 */     modulesClassMap.put(module.getClass(), module);
/* 35 */     modulesNameMap.put(module.getName().toLowerCase(Locale.ROOT), module);
/*    */   }
/*    */   
/*    */   public static Collection<Module> getModules() {
/* 39 */     return modulesClassMap.values();
/*    */   }
/*    */   
/*    */   public static ArrayList<Module> getModulesInCategory(Category category) {
/* 43 */     ArrayList<Module> list = new ArrayList<>();
/*    */     
/* 45 */     for (Module module : modulesClassMap.values()) {
/* 46 */       if (!module.getCategory().equals(category))
/* 47 */         continue;  list.add(module);
/*    */     } 
/*    */     
/* 50 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends Module> T getModule(Class<T> clazz) {
/* 55 */     return (T)modulesClassMap.get(clazz);
/*    */   }
/*    */   
/*    */   public static Module getModule(String name) {
/* 59 */     if (name == null) return null; 
/* 60 */     return modulesNameMap.get(name.toLowerCase(Locale.ROOT));
/*    */   }
/*    */   
/*    */   public static boolean isModuleEnabled(Class<? extends Module> clazz) {
/* 64 */     Module module = getModule((Class)clazz);
/* 65 */     return (module != null && module.isEnabled());
/*    */   }
/*    */   
/*    */   public static boolean isModuleEnabled(String name) {
/* 69 */     Module module = getModule(name);
/* 70 */     return (module != null && module.isEnabled());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\ModuleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */