//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.event.events.Render2DEvent;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.font.FontUtil;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Declaration(name = "EatTimer", category = Category.HUD, drawn = false)
/*    */ public class EatTimer
/*    */   extends Module
/*    */ {
/* 20 */   IntegerSetting timer = registerInteger("Timer", 32, 0, 100);
/* 21 */   int tick = 100;
/*    */   boolean holding = false;
/*    */   
/*    */   public void onEnable() {
/* 25 */     this.holding = false;
/* 26 */     this.tick = 100;
/*    */   }
/*    */   
/*    */   public void onTick() {
/* 30 */     if (mc.world == null || mc.player == null) {
/* 31 */       this.tick = 100;
/*    */       return;
/*    */     } 
/* 34 */     this.tick++;
/* 35 */     this.holding = (mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemFood || mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemFood);
/* 36 */     if (mc.player.isHandActive() && this.holding && 
/* 37 */       this.tick > ((Integer)this.timer.getValue()).intValue()) this.tick = 0;
/*    */   
/*    */   }
/*    */   
/*    */   public void onRender2D(Render2DEvent event) {
/* 42 */     if (mc.world == null || mc.player == null) {
/* 43 */       this.tick = 100;
/*    */       return;
/*    */     } 
/* 46 */     if (this.holding)
/* 47 */     { if (this.tick <= ((Integer)this.timer.getValue()).intValue()) {
/* 48 */         double percent = this.tick / ((Integer)this.timer.getValue()).intValue();
/* 49 */         String text = String.format("%.1f", new Object[] { Double.valueOf(percent * 100.0D) }) + "%";
/* 50 */         int divider = mc.gameSettings.guiScale;
/* 51 */         if (divider == 0) divider = 3; 
/* 52 */         boolean font = ((Boolean)((ColorMain)ModuleManager.getModule(ColorMain.class)).customFont.getValue()).booleanValue();
/* 53 */         FontUtil.drawStringWithShadow(font, text, (mc.displayWidth / divider / 2 - FontUtil.getStringWidth(font, text) / 2), (mc.displayHeight / divider / 2 + 16), new GSColor(255, 255, 255));
/*    */       }  }
/* 55 */     else { this.tick = 100; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\EatTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
