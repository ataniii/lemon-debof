/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ @Declaration(name = "Notifications", category = Category.HUD, drawn = false)
/*    */ public class Notifications extends Module {
/* 16 */   public ColorSetting backGround = registerColor("Info BackGround", new GSColor(255, 255, 255));
/* 17 */   public ColorSetting successBackGround = registerColor("Success BackGround", new GSColor(0, 255, 0));
/* 18 */   public ColorSetting warningBackGround = registerColor("Warning BackGround", new GSColor(255, 0, 0));
/* 19 */   public ColorSetting errorBackGround = registerColor("Error BackGround", new GSColor(0, 0, 0));
/* 20 */   public ColorSetting disableBackGround = registerColor("Disable BackGround", new GSColor(255, 0, 0));
/* 21 */   public IntegerSetting alpha = registerInteger("Alpha", 168, 0, 255);
/* 22 */   public BooleanSetting outline = registerBoolean("Outline", true);
/* 23 */   public IntegerSetting outlineAlpha = registerInteger("Outline Alpha", 200, 0, 255);
/* 24 */   public BooleanSetting mark = registerBoolean("Icon", true);
/* 25 */   public DoubleSetting xSpeed = registerDouble("Animation XSpeed", 0.1D, 0.01D, 0.5D);
/* 26 */   public DoubleSetting ySpeed = registerDouble("Animation YSpeed", 0.1D, 0.01D, 5.0D);
/* 27 */   public IntegerSetting max = registerInteger("Max Count", 10, 0, 100);
/* 28 */   public ModeSetting mode = registerMode("Mode", Arrays.asList(new String[] { "Remove", "Cancel" }, ), "Remove");
/* 29 */   public BooleanSetting disableChat = registerBoolean("No Chat Msg", true);
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Notifications.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */