//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.chat.AnimationUtil;
/*    */ import com.lemonclient.api.util.font.FontUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ @Declaration(name = "ShowArrayList", category = Category.HUD, drawn = false)
/*    */ public final class ShowArrayList extends Module {
/* 18 */   IntegerSetting width = registerInteger("X", 0, 0, 1920); private int count;
/* 19 */   IntegerSetting height = registerInteger("Y", 0, 0, 1080);
/* 20 */   BooleanSetting sortUp = registerBoolean("Sort Up", false);
/* 21 */   BooleanSetting sortRight = registerBoolean("Sort Right", false);
/* 22 */   DoubleSetting animationSpeed = registerDouble("Animation Speed", 3.5D, 0.0D, 5.0D);
/*    */   
/* 24 */   ColorSetting color = registerColor("Color", new GSColor(210, 100, 165)); public static ShowArrayList INSTANCE;
/*    */   
/*    */   public ShowArrayList() {
/* 27 */     INSTANCE = this;
/*    */   }
/*    */   private static String getArrayList(Module module) {
/* 30 */     return module.getName() + ChatFormatting.GRAY + module.getHudInfo();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender() {
/* 35 */     if (!isEnabled() || mc.world == null || mc.player == null)
/* 36 */       return;  this.count = 0;
/* 37 */     ModuleManager.getModules().stream().filter(ShowArrayList::render).sorted(Comparator.comparing(ShowArrayList::getWidth)).forEach(ShowArrayList::drawRect);
/*    */   }
/*    */   
/*    */   private static boolean render(Module it) {
/* 41 */     return it.isDrawn();
/*    */   }
/*    */   
/*    */   private static Integer getWidth(Module it) {
/* 45 */     return Integer.valueOf(FontUtil.getStringWidth(((Boolean)((ColorMain)ModuleManager.getModule(ColorMain.class)).customFont.getValue()).booleanValue(), getArrayList(it)) * -1);
/*    */   }
/*    */   
/*    */   private static void drawRect(Module module) {
/* 49 */     boolean customFont = ((Boolean)((ColorMain)ModuleManager.getModule(ColorMain.class)).customFont.getValue()).booleanValue();
/* 50 */     if (module.isDrawn()) {
/* 51 */       String modText = getArrayList(module);
/* 52 */       float modWidth = FontUtil.getStringWidth(customFont, modText);
/* 53 */       float remainingAnimation = module.remainingAnimation;
/* 54 */       float smoothSpeed = (float)(0.009999999776482582D + ((Double)INSTANCE.animationSpeed.getValue()).doubleValue() / 30.0D);
/* 55 */       float minSpeed = 0.1F;
/* 56 */       if (module.isEnabled()) {
/* 57 */         if (module.remainingAnimation < modWidth) {
/* 58 */           float end = modWidth + 1.0F;
/* 59 */           module.remainingAnimation = AnimationUtil.moveTowards(remainingAnimation, end, smoothSpeed, minSpeed, false);
/* 60 */         } else if (module.remainingAnimation > modWidth) {
/* 61 */           float end2 = modWidth - 1.0F;
/* 62 */           module.remainingAnimation = AnimationUtil.moveTowards(remainingAnimation, end2, smoothSpeed, minSpeed, false);
/*    */         }
/*    */       
/*    */       }
/* 66 */       else if (module.remainingAnimation > 0.0F) {
/* 67 */         float end3 = -modWidth;
/* 68 */         module.remainingAnimation = AnimationUtil.moveTowards(remainingAnimation, end3, smoothSpeed, minSpeed, false);
/*    */       } else {
/*    */         return;
/* 71 */       }  if (((Boolean)INSTANCE.sortRight.getValue()).booleanValue()) { FontUtil.drawStringWithShadow(customFont, modText, (int)(((Integer)INSTANCE.width.getValue()).intValue() - module.remainingAnimation), (((Integer)INSTANCE.height.getValue()).intValue() + 10 * INSTANCE.count * (((Boolean)INSTANCE.sortUp.getValue()).booleanValue() ? 1 : -1)), INSTANCE.color.getValue()); }
/* 72 */       else { FontUtil.drawStringWithShadow(customFont, modText, (int)((((Integer)INSTANCE.width.getValue()).intValue() - 2) - modWidth + module.remainingAnimation), (((Integer)INSTANCE.height.getValue()).intValue() + 10 * INSTANCE.count * (((Boolean)INSTANCE.sortUp.getValue()).booleanValue() ? 1 : -1)), INSTANCE.color.getValue()); }
/* 73 */        INSTANCE.count++;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\ShowArrayList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
