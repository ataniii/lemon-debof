/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.StringSetting;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.HUDModule;
/*    */ import com.lemonclient.client.module.HUDModule.Declaration;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.hud.HUDList;
/*    */ import com.lukflug.panelstudio.hud.ListComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import java.awt.Color;
/*    */ 
/*    */ @Declaration(name = "Watermark", category = Category.HUD, drawn = false)
/*    */ @Declaration(posX = 0, posZ = 0)
/*    */ public class Watermark extends HUDModule {
/* 22 */   BooleanSetting custom = registerBoolean("Custom", false);
/* 23 */   StringSetting text = registerString("Text", "", () -> (Boolean)this.custom.getValue());
/* 24 */   ColorSetting color = registerColor("Color", new GSColor(255, 0, 0, 255));
/*    */ 
/*    */   
/*    */   public void populate(ITheme theme) {
/* 28 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), new WatermarkList(), 9, 1);
/*    */   }
/*    */   
/*    */   private class WatermarkList implements HUDList {
/*    */     private WatermarkList() {}
/*    */     
/*    */     public int getSize() {
/* 35 */       return 1;
/*    */     }
/*    */ 
/*    */     
/*    */     public String getItem(int index) {
/* 40 */       if (((Boolean)Watermark.this.custom.getValue()).booleanValue()) return Watermark.this.text.getText(); 
/* 41 */       return "LemonClient v0.0.8";
/*    */     }
/*    */ 
/*    */     
/*    */     public Color getItemColor(int index) {
/* 46 */       return (Color)Watermark.this.color.getValue();
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean sortUp() {
/* 51 */       return false;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean sortRight() {
/* 56 */       return false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Watermark.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */