//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.HUDModule;
/*    */ import com.lemonclient.client.module.HUDModule.Declaration;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lukflug.panelstudio.base.Context;
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.hud.HUDComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.NonNullList;
/*    */ 
/*    */ @Declaration(name = "InventoryViewer", category = Category.HUD, drawn = false)
/*    */ @Declaration(posX = 0, posZ = 10)
/*    */ public class InventoryViewer extends HUDModule {
/* 29 */   ColorSetting fillColor = registerColor("Fill", new GSColor(0, 0, 0, 100));
/* 30 */   IntegerSetting fill = registerInteger("Fill Alpha", 100, 0, 255);
/* 31 */   ColorSetting outlineColor = registerColor("Outline", new GSColor(255, 0, 0, 255));
/* 32 */   IntegerSetting outline = registerInteger("Outline Alpha", 255, 0, 255);
/*    */ 
/*    */   
/*    */   public void populate(ITheme theme) {
/* 36 */     this.component = (IFixedComponent)new InventoryViewerComponent(theme);
/*    */   }
/*    */   
/*    */   private class InventoryViewerComponent
/*    */     extends HUDComponent {
/*    */     public InventoryViewerComponent(ITheme theme) {
/* 42 */       super((ILabeled)new Labeled(InventoryViewer.this.getName(), null, () -> true), InventoryViewer.this.position, InventoryViewer.this.getName());
/*    */     }
/*    */ 
/*    */     
/*    */     public void render(Context context) {
/* 47 */       super.render(context);
/*    */       
/* 49 */       GSColor gSColor1 = new GSColor(InventoryViewer.this.fillColor.getValue(), ((Integer)InventoryViewer.this.fill.getValue()).intValue());
/* 50 */       context.getInterface().fillRect(context.getRect(), (Color)gSColor1, (Color)gSColor1, (Color)gSColor1, (Color)gSColor1);
/*    */       
/* 52 */       GSColor gSColor2 = new GSColor(InventoryViewer.this.outlineColor.getValue(), ((Integer)InventoryViewer.this.outline.getValue()).intValue());
/* 53 */       context.getInterface().fillRect(new Rectangle(context.getPos(), new Dimension((context.getSize()).width, 1)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 54 */       context.getInterface().fillRect(new Rectangle(context.getPos(), new Dimension(1, (context.getSize()).height)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 55 */       context.getInterface().fillRect(new Rectangle(new Point((context.getPos()).x + (context.getSize()).width - 1, (context.getPos()).y), new Dimension(1, (context.getSize()).height)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 56 */       context.getInterface().fillRect(new Rectangle(new Point((context.getPos()).x, (context.getPos()).y + (context.getSize()).height - 1), new Dimension((context.getSize()).width, 1)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/*    */       
/* 58 */       NonNullList<ItemStack> items = (Minecraft.getMinecraft()).player.inventory.mainInventory;
/* 59 */       for (int size = items.size(), item = 9; item < size; item++) {
/* 60 */         int slotX = (context.getPos()).x + item % 9 * 18;
/* 61 */         int slotY = (context.getPos()).y + 2 + (item / 9 - 1) * 18;
/* 62 */         LemonClientGUI.renderItem((ItemStack)items.get(item), new Point(slotX, slotY));
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public Dimension getSize(IInterface inter) {
/* 68 */       return new Dimension(162, 56);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\InventoryViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
