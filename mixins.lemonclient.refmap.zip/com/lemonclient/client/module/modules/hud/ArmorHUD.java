//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.util.font.FontUtil;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ @Declaration(name = "ArmorHUD", category = Category.HUD, drawn = false)
/*    */ public class ArmorHUD extends Module {
/*    */   public void onRender() {
/* 17 */     GlStateManager.pushMatrix();
/* 18 */     GlStateManager.enableTexture2D();
/*    */     
/* 20 */     ScaledResolution resolution = new ScaledResolution(mc);
/* 21 */     int i = resolution.getScaledWidth() / 2;
/* 22 */     int iteration = 0;
/* 23 */     int y = resolution.getScaledHeight() - 55 - (mc.player.isInWater() ? 10 : 0);
/* 24 */     for (ItemStack is : mc.player.inventory.armorInventory) {
/* 25 */       iteration++;
/* 26 */       if (is.isEmpty())
/* 27 */         continue;  int x = i - 90 + (9 - iteration) * 20 + 2;
/* 28 */       GlStateManager.enableDepth();
/*    */       
/* 30 */       (mc.getRenderItem()).zLevel = 200.0F;
/* 31 */       mc.getRenderItem().renderItemAndEffectIntoGUI(is, x, y);
/* 32 */       mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, is, x, y, "");
/* 33 */       (mc.getRenderItem()).zLevel = 0.0F;
/*    */       
/* 35 */       GlStateManager.enableTexture2D();
/* 36 */       GlStateManager.disableLighting();
/* 37 */       GlStateManager.disableDepth();
/*    */       
/* 39 */       String s = (is.getCount() > 1) ? (is.getCount() + "") : "";
/* 40 */       mc.fontRenderer.drawStringWithShadow(s, (x + 19 - 2 - mc.fontRenderer.getStringWidth(s)), (y + 9), (new GSColor(255, 255, 255)).getRGB());
/* 41 */       float green = (is.getMaxDamage() - is.getItemDamage()) / is.getMaxDamage();
/* 42 */       float red = 1.0F - green;
/* 43 */       int dmg = 100 - (int)(red * 100.0F);
/*    */       
/* 45 */       if (green > 1.0F) {
/* 46 */         green = 1.0F;
/* 47 */       } else if (green < 0.0F) {
/* 48 */         green = 0.0F;
/*    */       } 
/*    */       
/* 51 */       if (red > 1.0F) {
/* 52 */         red = 1.0F;
/*    */       }
/* 54 */       if (dmg < 0) {
/* 55 */         dmg = 0;
/*    */       }
/*    */       
/* 58 */       FontUtil.drawStringWithShadow(((Boolean)((ColorMain)ModuleManager.getModule(ColorMain.class)).customFont.getValue()).booleanValue(), dmg + "", (x + 8 - mc.fontRenderer.getStringWidth(dmg + "") / 2), (y - 11), new GSColor((int)(red * 255.0F), (int)(green * 255.0F), 0));
/*    */     } 
/*    */     
/* 61 */     GlStateManager.enableDepth();
/* 62 */     GlStateManager.popMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\ArmorHUD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
