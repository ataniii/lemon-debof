//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.HUDModule;
/*    */ import com.lemonclient.client.module.HUDModule.Declaration;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.hud.HUDList;
/*    */ import com.lukflug.panelstudio.hud.ListComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ 
/*    */ @Declaration(name = "PotionEffects", category = Category.HUD, drawn = false)
/*    */ @Declaration(posX = 0, posZ = 300)
/*    */ public class PotionEffects extends HUDModule {
/* 23 */   BooleanSetting sortUp = registerBoolean("Sort Up", false);
/* 24 */   BooleanSetting sortRight = registerBoolean("Sort Right", false);
/*    */   
/* 26 */   private final PotionList list = new PotionList();
/*    */ 
/*    */   
/*    */   public void populate(ITheme theme) {
/* 30 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), this.list, 9, 1);
/*    */   }
/*    */   
/*    */   private class PotionList
/*    */     implements HUDList {
/*    */     private PotionList() {}
/*    */     
/*    */     public int getSize() {
/* 38 */       return PotionEffects.mc.player.getActivePotionEffects().size();
/*    */     }
/*    */ 
/*    */     
/*    */     public String getItem(int index) {
/* 43 */       PotionEffect effect = (PotionEffect)PotionEffects.mc.player.getActivePotionEffects().toArray()[index];
/* 44 */       String name = I18n.format(effect.getPotion().getName(), new Object[0]);
/* 45 */       int amplifier = effect.getAmplifier() + 1;
/* 46 */       return name + " " + amplifier + ChatFormatting.GRAY + " " + Potion.getPotionDurationString(effect, 1.0F);
/*    */     }
/*    */ 
/*    */     
/*    */     public Color getItemColor(int i) {
/* 51 */       if ((PotionEffects.mc.player.getActivePotionEffects().toArray()).length != 0) {
/* 52 */         return PotionEffects.this.getColour((PotionEffect)PotionEffects.mc.player.getActivePotionEffects().toArray()[i]);
/*    */       }
/* 54 */       return null;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean sortUp() {
/* 60 */       return ((Boolean)PotionEffects.this.sortUp.getValue()).booleanValue();
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean sortRight() {
/* 65 */       return ((Boolean)PotionEffects.this.sortRight.getValue()).booleanValue();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   Color getColour(PotionEffect potion) {
/* 71 */     int colour = potion.getPotion().getLiquidColor();
/*    */     
/* 73 */     float r = (colour >> 16 & 0xFF) / 255.0F;
/* 74 */     float g = (colour >> 8 & 0xFF) / 255.0F;
/* 75 */     float b = (colour & 0xFF) / 255.0F;
/*    */     
/* 77 */     return new Color(r, g, b);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\PotionEffects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
