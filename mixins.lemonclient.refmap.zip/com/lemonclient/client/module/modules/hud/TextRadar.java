//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.hud;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.HUDModule;
/*     */ import com.lemonclient.client.module.HUDModule.Declaration;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.hud.HUDList;
/*     */ import com.lukflug.panelstudio.hud.ListComponent;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.Labeled;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ @Declaration(name = "TextRadar", category = Category.HUD, drawn = false)
/*     */ @Declaration(posX = 0, posZ = 50)
/*     */ public class TextRadar extends HUDModule {
/*  30 */   ModeSetting display = registerMode("Display", Arrays.asList(new String[] { "All", "Friend", "Enemy" }, ), "All");
/*  31 */   BooleanSetting sortUp = registerBoolean("Sort Up", false);
/*  32 */   BooleanSetting sortRight = registerBoolean("Sort Right", false);
/*  33 */   IntegerSetting range = registerInteger("Range", 100, 1, 260);
/*     */   
/*  35 */   private final PlayerList list = new PlayerList();
/*     */ 
/*     */   
/*     */   public void populate(ITheme theme) {
/*  39 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), this.list, 9, 1);
/*     */   }
/*     */   
/*     */   public void onRender() {
/*  43 */     this.list.players.clear();
/*  44 */     mc.world.loadedEntityList.stream()
/*  45 */       .filter(e -> e instanceof EntityPlayer)
/*  46 */       .filter(e -> (e != mc.player))
/*  47 */       .forEach(e -> {
/*     */           if (mc.player.getDistance(e) > ((Integer)this.range.getValue()).intValue()) {
/*     */             return;
/*     */           }
/*     */           if (((String)this.display.getValue()).equalsIgnoreCase("Friend") && !SocialManager.isFriend(e.getName())) {
/*     */             return;
/*     */           }
/*     */           if (((String)this.display.getValue()).equalsIgnoreCase("Enemy") && !SocialManager.isEnemy(e.getName())) {
/*     */             return;
/*     */           }
/*     */           this.list.players.add((EntityPlayer)e);
/*     */         });
/*     */   }
/*     */   
/*     */   private class PlayerList
/*     */     implements HUDList
/*     */   {
/*  64 */     public List<EntityPlayer> players = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public int getSize() {
/*  68 */       return this.players.size();
/*     */     }
/*     */     
/*     */     public String getItem(int index) {
/*     */       TextFormatting friendcolor, healthcolor, distancecolor;
/*  73 */       EntityPlayer e = this.players.get(index);
/*     */       
/*  75 */       if (SocialManager.isFriend(e.getName())) {
/*  76 */         friendcolor = ((ColorMain)ModuleManager.getModule(ColorMain.class)).getFriendColor();
/*  77 */       } else if (SocialManager.isEnemy(e.getName())) {
/*  78 */         friendcolor = ((ColorMain)ModuleManager.getModule(ColorMain.class)).getEnemyColor();
/*     */       } else {
/*  80 */         friendcolor = TextFormatting.GRAY;
/*     */       } 
/*     */       
/*  83 */       float health = e.getHealth() + e.getAbsorptionAmount();
/*  84 */       if (health <= 5.0F) {
/*  85 */         healthcolor = TextFormatting.RED;
/*  86 */       } else if (health > 5.0F && health < 15.0F) {
/*  87 */         healthcolor = TextFormatting.YELLOW;
/*     */       } else {
/*  89 */         healthcolor = TextFormatting.GREEN;
/*     */       } 
/*     */       
/*  92 */       float distance = TextRadar.mc.player.getDistance((Entity)e);
/*  93 */       if (distance < 20.0F) {
/*  94 */         distancecolor = TextFormatting.RED;
/*  95 */       } else if (distance >= 20.0F && distance < 50.0F) {
/*  96 */         distancecolor = TextFormatting.YELLOW;
/*     */       } else {
/*  98 */         distancecolor = TextFormatting.GREEN;
/*     */       } 
/* 100 */       return TextFormatting.GRAY + "[" + healthcolor + (int)health + TextFormatting.GRAY + "] " + friendcolor + e.getName() + TextFormatting.GRAY + " [" + distancecolor + (int)distance + TextFormatting.GRAY + "]";
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getItemColor(int index) {
/* 105 */       return new Color(255, 255, 255);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortUp() {
/* 110 */       return ((Boolean)TextRadar.this.sortUp.getValue()).booleanValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortRight() {
/* 115 */       return ((Boolean)TextRadar.this.sortRight.getValue()).booleanValue();
/*     */     }
/*     */     
/*     */     private PlayerList() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\TextRadar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
