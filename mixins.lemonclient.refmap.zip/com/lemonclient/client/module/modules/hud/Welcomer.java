//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.hud;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.StringSetting;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.HUDModule;
/*    */ import com.lemonclient.client.module.HUDModule.Declaration;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.hud.HUDList;
/*    */ import com.lukflug.panelstudio.hud.ListComponent;
/*    */ import com.lukflug.panelstudio.setting.ILabeled;
/*    */ import com.lukflug.panelstudio.setting.Labeled;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ @Declaration(name = "Welcomer", category = Category.HUD, drawn = false)
/*    */ @Declaration(posX = 450, posZ = 0)
/*    */ public class Welcomer
/*    */   extends HUDModule {
/* 23 */   StringSetting prefix = registerString("Prefix", "Hi ");
/* 24 */   StringSetting suffix = registerString("Suffix", " :^)");
/* 25 */   ColorSetting color = registerColor("Color", new GSColor(255, 0, 0, 255));
/*    */ 
/*    */   
/*    */   public void populate(ITheme theme) {
/* 29 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), new WelcomerList(), 9, 1);
/*    */   }
/*    */   
/*    */   private class WelcomerList implements HUDList {
/*    */     private WelcomerList() {}
/*    */     
/*    */     public int getSize() {
/* 36 */       return 1;
/*    */     }
/*    */ 
/*    */     
/*    */     public String getItem(int index) {
/* 41 */       return Welcomer.this.prefix.getText() + Welcomer.mc.player.getName() + Welcomer.this.suffix.getText();
/*    */     }
/*    */ 
/*    */     
/*    */     public Color getItemColor(int index) {
/* 46 */       return (Color)Welcomer.this.color.getValue();
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean sortUp() {
/* 51 */       return false;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean sortRight() {
/* 56 */       return false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Welcomer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
