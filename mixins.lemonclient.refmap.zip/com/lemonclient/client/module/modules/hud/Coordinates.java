//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.hud;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.client.module.HUDModule.Declaration;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.hud.HUDList;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import java.awt.Color;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ 
/*     */ @Declaration(name = "Coordinates", category = Category.HUD, drawn = false)
/*     */ @Declaration(posX = 0, posZ = 0)
/*     */ public class Coordinates extends HUDModule {
/*     */   BooleanSetting showNetherOverworld;
/*     */   BooleanSetting thousandsSeparator;
/*     */   IntegerSetting decimalPlaces;
/*     */   private final String[] coordinateString;
/*     */   @EventHandler
/*     */   private final Listener<TickEvent.ClientTickEvent> listener;
/*     */   
/*     */   public Coordinates() {
/*  26 */     this.showNetherOverworld = registerBoolean("Show Nether", true);
/*  27 */     this.thousandsSeparator = registerBoolean("Thousands Separator", true);
/*  28 */     this.decimalPlaces = registerInteger("Decimal Places", 1, 0, 5);
/*     */     
/*  30 */     this.coordinateString = new String[] { "", "" };
/*     */     
/*  32 */     this.listener = new Listener(event -> { EntityPlayerSP entityPlayerSP1; if (event.phase != TickEvent.Phase.END) return;  Entity viewEntity = mc.getRenderViewEntity(); EntityPlayerSP player = mc.player; if (viewEntity == null) if (player != null) { entityPlayerSP1 = player; } else { return; }   int dimension = ((Entity)entityPlayerSP1).dimension; this.coordinateString[0] = "XYZ " + getFormattedCoords(((Entity)entityPlayerSP1).posX, ((Entity)entityPlayerSP1).posY, ((Entity)entityPlayerSP1).posZ); switch (dimension) { case -1: this.coordinateString[1] = "Overworld " + getFormattedCoords(((Entity)entityPlayerSP1).posX * 8.0D, ((Entity)entityPlayerSP1).posY, ((Entity)entityPlayerSP1).posZ * 8.0D); break;case 0: this.coordinateString[1] = "Nether " + getFormattedCoords(((Entity)entityPlayerSP1).posX / 8.0D, ((Entity)entityPlayerSP1).posY, ((Entity)entityPlayerSP1).posZ / 8.0D); break; }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getFormattedCoords(double x, double y, double z) {
/*  67 */     return roundOrInt(x) + ", " + roundOrInt(y) + ", " + roundOrInt(z);
/*     */   }
/*     */ 
/*     */   
/*     */   private String roundOrInt(double input) {
/*     */     String separatorFormat;
/*  73 */     if (((Boolean)this.thousandsSeparator.getValue()).booleanValue()) {
/*  74 */       separatorFormat = ",";
/*     */     } else {
/*  76 */       separatorFormat = "";
/*     */     } 
/*     */     
/*  79 */     return String.format('%' + separatorFormat + '.' + this.decimalPlaces.getValue() + 'f', new Object[] { Double.valueOf(input) });
/*     */   }
/*     */ 
/*     */   
/*     */   public void populate(ITheme theme) {
/*  84 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), new CoordinateLabel(), 9, 1);
/*     */   }
/*     */   
/*     */   private class CoordinateLabel implements HUDList { private CoordinateLabel() {}
/*     */     
/*     */     public int getSize() {
/*  90 */       EntityPlayerSP player = Coordinates.mc.player;
/*  91 */       int dimension = (player != null) ? player.dimension : 1;
/*     */       
/*  93 */       if (((Boolean)Coordinates.this.showNetherOverworld.getValue()).booleanValue() && (dimension == -1 || dimension == 0)) {
/*  94 */         return 2;
/*     */       }
/*  96 */       return 1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getItem(int index) {
/* 102 */       return Coordinates.this.coordinateString[index];
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getItemColor(int index) {
/* 107 */       return new Color(255, 255, 255);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortUp() {
/* 112 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortRight() {
/* 117 */       return false;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Coordinates.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
