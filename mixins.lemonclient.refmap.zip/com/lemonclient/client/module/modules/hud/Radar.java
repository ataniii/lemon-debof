//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.hud;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.HUDModule;
/*     */ import com.lemonclient.client.module.HUDModule.Declaration;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.hud.HUDComponent;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.Labeled;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Declaration(name = "Radar", category = Category.HUD, drawn = false)
/*     */ @Declaration(posX = 0, posZ = 200)
/*     */ public class Radar
/*     */   extends HUDModule
/*     */ {
/*  36 */   BooleanSetting renderPlayer = registerBoolean("Player", true);
/*  37 */   BooleanSetting renderMobs = registerBoolean("Mobs", true);
/*  38 */   ColorSetting playerColor = registerColor("Player Color", new GSColor(0, 0, 255, 255));
/*  39 */   ColorSetting outlineColor = registerColor("Outline Color", new GSColor(255, 0, 0, 255));
/*  40 */   ColorSetting fillColor = registerColor("Fill Color", new GSColor(0, 0, 0, 255));
/*     */ 
/*     */   
/*     */   public void populate(ITheme theme) {
/*  44 */     this.component = (IFixedComponent)new RadarComponent(theme);
/*     */   }
/*     */   
/*     */   private Color getPlayerColor(EntityPlayer entityPlayer) {
/*  48 */     if (SocialManager.isFriend(entityPlayer.getName()))
/*  49 */       return (Color)new GSColor(((ColorMain)ModuleManager.getModule(ColorMain.class)).getFriendGSColor(), 255); 
/*  50 */     if (SocialManager.isEnemy(entityPlayer.getName())) {
/*  51 */       return (Color)new GSColor(((ColorMain)ModuleManager.getModule(ColorMain.class)).getEnemyGSColor(), 255);
/*     */     }
/*  53 */     return (Color)new GSColor(this.playerColor.getValue(), 255);
/*     */   }
/*     */ 
/*     */   
/*     */   private Color getEntityColor(Entity entity) {
/*  58 */     if (entity instanceof net.minecraft.entity.monster.EntityMob || entity instanceof net.minecraft.entity.monster.EntitySlime)
/*  59 */       return (Color)new GSColor(255, 0, 0, 255); 
/*  60 */     if (entity instanceof net.minecraft.entity.passive.EntityAnimal || entity instanceof net.minecraft.entity.passive.EntitySquid) {
/*  61 */       return (Color)new GSColor(0, 255, 0, 255);
/*     */     }
/*  63 */     return (Color)new GSColor(255, 165, 0, 255);
/*     */   }
/*     */   
/*     */   private class RadarComponent extends HUDComponent {
/*     */     private final int maxRange = 50;
/*     */     
/*     */     public RadarComponent(ITheme theme) {
/*  70 */       super((ILabeled)new Labeled(Radar.this.getName(), null, () -> true), Radar.this.position, Radar.this.getName());
/*     */ 
/*     */       
/*  73 */       this.maxRange = 50;
/*     */     }
/*     */     
/*     */     public void render(Context context) {
/*  77 */       super.render(context);
/*     */       
/*  79 */       if (Radar.mc.player != null && Radar.mc.player.ticksExisted >= 10) {
/*     */ 
/*     */         
/*  82 */         if (((Boolean)Radar.this.renderPlayer.getValue()).booleanValue()) {
/*  83 */           Radar.mc.world.playerEntities.stream()
/*  84 */             .filter(entityPlayer -> (entityPlayer != Radar.mc.player))
/*  85 */             .forEach(entityPlayer -> renderEntityPoint((Entity)entityPlayer, Radar.this.getPlayerColor(entityPlayer), context));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  92 */         if (((Boolean)Radar.this.renderMobs.getValue()).booleanValue()) {
/*  93 */           Radar.mc.world.loadedEntityList.stream()
/*  94 */             .filter(entity -> !(entity instanceof EntityPlayer))
/*  95 */             .forEach(entity -> {
/*     */                 if (entity instanceof net.minecraft.entity.EntityCreature || entity instanceof net.minecraft.entity.monster.EntitySlime || entity instanceof net.minecraft.entity.passive.EntitySquid) {
/*     */                   renderEntityPoint(entity, Radar.this.getEntityColor(entity), context);
/*     */                 }
/*     */               });
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 104 */         GSColor gSColor1 = new GSColor(Radar.this.fillColor.getValue(), 100);
/* 105 */         context.getInterface().fillRect(context.getRect(), (Color)gSColor1, (Color)gSColor1, (Color)gSColor1, (Color)gSColor1);
/*     */ 
/*     */         
/* 108 */         GSColor gSColor2 = new GSColor(Radar.this.outlineColor.getValue(), 255);
/* 109 */         context.getInterface().fillRect(new Rectangle(context.getPos(), new Dimension((context.getSize()).width, 1)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 110 */         context.getInterface().fillRect(new Rectangle(context.getPos(), new Dimension(1, (context.getSize()).height)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 111 */         context.getInterface().fillRect(new Rectangle(new Point((context.getPos()).x + (context.getSize()).width - 1, (context.getPos()).y), new Dimension(1, (context.getSize()).height)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/* 112 */         context.getInterface().fillRect(new Rectangle(new Point((context.getPos()).x, (context.getPos()).y + (context.getSize()).height - 1), new Dimension((context.getSize()).width, 1)), (Color)gSColor2, (Color)gSColor2, (Color)gSColor2, (Color)gSColor2);
/*     */ 
/*     */         
/* 115 */         boolean isNorth = isFacing(EnumFacing.NORTH);
/* 116 */         boolean isSouth = isFacing(EnumFacing.SOUTH);
/* 117 */         boolean isEast = isFacing(EnumFacing.EAST);
/* 118 */         boolean isWest = isFacing(EnumFacing.WEST);
/*     */         
/* 120 */         Color selfColor = new Color(255, 255, 255, 255);
/* 121 */         int distanceToCenter = (context.getSize()).height / 2;
/* 122 */         context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter + 3, (context.getPos()).y + distanceToCenter), new Point((context.getPos()).x + distanceToCenter + (isEast ? 1 : 0), (context.getPos()).y + distanceToCenter), isEast ? (Color)gSColor2 : selfColor, isEast ? (Color)gSColor2 : selfColor);
/* 123 */         context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter, (context.getPos()).y + distanceToCenter + 3), new Point((context.getPos()).x + distanceToCenter, (context.getPos()).y + distanceToCenter + (isSouth ? 1 : 0)), isSouth ? (Color)gSColor2 : selfColor, isSouth ? (Color)gSColor2 : selfColor);
/* 124 */         context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter - (isWest ? 1 : 0), (context.getPos()).y + distanceToCenter), new Point((context.getPos()).x + distanceToCenter - 3, (context.getPos()).y + distanceToCenter), isWest ? (Color)gSColor2 : selfColor, isWest ? (Color)gSColor2 : selfColor);
/* 125 */         context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter, (context.getPos()).y + distanceToCenter - (isNorth ? 1 : 0)), new Point((context.getPos()).x + distanceToCenter, (context.getPos()).y + distanceToCenter - 3), isNorth ? (Color)gSColor2 : selfColor, isNorth ? (Color)gSColor2 : selfColor);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isFacing(EnumFacing enumFacing) {
/* 131 */       return Radar.mc.player.getHorizontalFacing().equals(enumFacing);
/*     */     }
/*     */     
/*     */     private void renderEntityPoint(Entity entity, Color color, Context context) {
/* 135 */       int distanceX = findDistance1D(Radar.mc.player.posX, entity.posX);
/* 136 */       int distanceY = findDistance1D(Radar.mc.player.posZ, entity.posZ);
/*     */       
/* 138 */       int distanceToCenter = (context.getSize()).height / 2;
/*     */       
/* 140 */       if (distanceX > 50 || distanceY > 50 || distanceX < -50 || distanceY < -50) {
/*     */         return;
/*     */       }
/*     */       
/* 144 */       context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter + 1 + distanceX, (context.getPos()).y + distanceToCenter + distanceY), new Point((context.getPos()).x + distanceToCenter - 1 + distanceX, (context.getPos()).y + distanceToCenter + distanceY), color, color);
/* 145 */       context.getInterface().drawLine(new Point((context.getPos()).x + distanceToCenter + distanceX, (context.getPos()).y + distanceToCenter + 1 + distanceY), new Point((context.getPos()).x + distanceToCenter + distanceX, (context.getPos()).y + distanceToCenter - 1 + distanceY), color, color);
/*     */     }
/*     */     
/*     */     private int findDistance1D(double player, double entity) {
/* 149 */       double player1 = player;
/* 150 */       double entity1 = entity;
/*     */       
/* 152 */       if (player1 < 0.0D) {
/* 153 */         player1 *= -1.0D;
/*     */       }
/* 155 */       if (entity1 < 0.0D) {
/* 156 */         entity1 *= -1.0D;
/*     */       }
/*     */       
/* 159 */       int value = (int)(entity1 - player1);
/*     */       
/* 161 */       if ((player > 0.0D && entity < 0.0D) || (player < 0.0D && entity > 0.0D)) {
/* 162 */         value = (int)(-1.0D * player + entity);
/*     */       }
/*     */       
/* 165 */       if ((player > 0.0D || player < 0.0D) && entity < 0.0D && entity1 != player1) {
/* 166 */         value = (int)(-1.0D * player + entity);
/*     */       }
/*     */       
/* 169 */       if ((player < 0.0D && entity == 0.0D) || (player == 0.0D && entity < 0.0D)) {
/* 170 */         value = (int)(-1.0D * (entity1 - player1));
/*     */       }
/*     */       
/* 173 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dimension getSize(IInterface anInterface) {
/* 178 */       return new Dimension(103, 103);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Radar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
