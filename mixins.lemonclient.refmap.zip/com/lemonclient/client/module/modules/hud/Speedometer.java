//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.hud;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.world.TimerUtils;
/*     */ import com.lemonclient.client.module.HUDModule.Declaration;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.hud.HUDList;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ 
/*     */ @Declaration(name = "Speedometer", category = Category.HUD, drawn = false)
/*     */ @Declaration(posX = 0, posZ = 70)
/*     */ public class Speedometer extends HUDModule {
/*     */   private static final String MPS = "m/s";
/*     */   private static final String KMH = "km/h";
/*     */   private static final String MPH = "mph";
/*     */   ModeSetting speedUnit;
/*     */   BooleanSetting averageSpeed;
/*     */   IntegerSetting averageSpeedTicks;
/*     */   private final ArrayDeque<Double> speedDeque;
/*     */   private String speedString;
/*     */   @EventHandler
/*     */   private final Listener<TickEvent.ClientTickEvent> listener;
/*     */   
/*     */   public Speedometer() {
/*  34 */     this.speedUnit = registerMode("Unit", Arrays.asList(new String[] { "m/s", "km/h", "mph" }, ), "km/h");
/*  35 */     this.averageSpeed = registerBoolean("Average Speed", true);
/*  36 */     this.averageSpeedTicks = registerInteger("Average Time", 20, 5, 100);
/*     */     
/*  38 */     this.speedDeque = new ArrayDeque<>();
/*  39 */     this.speedString = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.listener = new Listener(event -> { if (event.phase != TickEvent.Phase.END) return;  EntityPlayerSP player = mc.player; if (player == null) return;  String unit = (String)this.speedUnit.getValue(); double speed = calcSpeed(player, unit); double displaySpeed = speed; if (((Boolean)this.averageSpeed.getValue()).booleanValue()) { if (speed > 0.0D || player.ticksExisted % 4 == 0) { this.speedDeque.add(Double.valueOf(speed)); } else { this.speedDeque.pollFirst(); }  while (!this.speedDeque.isEmpty() && this.speedDeque.size() > ((Integer)this.averageSpeedTicks.getValue()).intValue()) this.speedDeque.poll();  displaySpeed = average(this.speedDeque); }  this.speedString = String.format("%.2f", new Object[] { Double.valueOf(displaySpeed) }) + ' ' + unit; }new java.util.function.Predicate[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onDisable() {
/*     */     this.speedDeque.clear();
/*     */     this.speedString = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double calcSpeed(EntityPlayerSP player, String unit) {
/*  76 */     double tps = 1000.0D / TimerUtils.getTickLength();
/*  77 */     double xDiff = player.posX - player.prevPosX;
/*  78 */     double zDiff = player.posZ - player.prevPosZ;
/*     */     
/*  80 */     double speed = Math.hypot(xDiff, zDiff) * tps;
/*     */ 
/*     */     
/*  83 */     switch (unit) {
/*     */       case "km/h":
/*  85 */         speed *= 3.6D;
/*     */         break;
/*     */       case "mph":
/*  88 */         speed *= 2.237D;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  94 */     return speed;
/*     */   }
/*     */   
/*     */   private double average(Collection<Double> collection) {
/*  98 */     if (collection.isEmpty()) return 0.0D;
/*     */     
/* 100 */     double sum = 0.0D;
/* 101 */     int size = 0;
/*     */     
/* 103 */     for (Iterator<Double> iterator = collection.iterator(); iterator.hasNext(); ) { double element = ((Double)iterator.next()).doubleValue();
/* 104 */       sum += element;
/* 105 */       size++; }
/*     */ 
/*     */     
/* 108 */     return sum / size;
/*     */   }
/*     */ 
/*     */   
/*     */   public void populate(ITheme theme) {
/* 113 */     this.component = (IFixedComponent)new ListComponent((ILabeled)new Labeled(getName(), null, () -> true), this.position, getName(), new SpeedLabel(), 9, 1);
/*     */   }
/*     */   
/*     */   private class SpeedLabel implements HUDList { private SpeedLabel() {}
/*     */     
/*     */     public int getSize() {
/* 119 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getItem(int index) {
/* 124 */       return Speedometer.this.speedString;
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getItemColor(int index) {
/* 129 */       return new Color(255, 255, 255);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortUp() {
/* 134 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean sortRight() {
/* 139 */       return false;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\hud\Speedometer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
