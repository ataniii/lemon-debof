//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.movement;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ 
/*    */ @Declaration(name = "ClipFlight", category = Category.Exploits)
/*    */ public class ClipFlight extends Module {
/*    */   ModeSetting flight;
/*    */   IntegerSetting packets;
/*    */   IntegerSetting speed;
/*    */   IntegerSetting speedY;
/*    */   BooleanSetting bypass;
/*    */   IntegerSetting interval;
/*    */   BooleanSetting update;
/*    */   int num;
/*    */   double startFlat;
/*    */   @EventHandler
/*    */   private final Listener<PlayerMoveEvent> playerMoveEventListener;
/*    */   
/*    */   public ClipFlight() {
/* 19 */     this.flight = registerMode("Mode", Arrays.asList(new String[] { "Flight", "Clip" }, ), "Clip");
/* 20 */     this.packets = registerInteger("Packets", 80, 1, 300);
/* 21 */     this.speed = registerInteger("XZ Speed", 7, -99, 99, () -> Boolean.valueOf(((String)this.flight.getValue()).equalsIgnoreCase("Flight")));
/* 22 */     this.speedY = registerInteger("Y Speed", 7, -99, 99, () -> Boolean.valueOf(!((String)this.flight.getValue()).equalsIgnoreCase("Relative")));
/* 23 */     this.bypass = registerBoolean("Bypass", false);
/* 24 */     this.interval = registerInteger("Interval", 25, 1, 100, () -> Boolean.valueOf(((String)this.flight.getValue()).equalsIgnoreCase("Clip")));
/* 25 */     this.update = registerBoolean("Update Position Client Side", false);
/*    */     
/* 27 */     this.num = 0;
/*    */     
/* 29 */     this.startFlat = 0.0D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     this.playerMoveEventListener = new Listener(event -> { double xPos; double yPos; double zPos; double[] dir = MotionUtil.forward(((Integer)this.speed.getValue()).intValue()); switch ((String)this.flight.getValue()) { case "Flight": xPos = mc.player.posX; yPos = mc.player.posY; zPos = mc.player.posZ; if (mc.gameSettings.keyBindJump.isKeyDown() && !mc.gameSettings.keyBindSneak.isKeyDown()) { yPos += ((Integer)this.speedY.getValue()).intValue(); } else if (mc.gameSettings.keyBindSneak.isKeyDown()) { yPos -= ((Integer)this.speedY.getValue()).intValue(); }  xPos += dir[0]; zPos += dir[1]; mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(xPos, yPos, zPos, false)); if (((Boolean)this.update.getValue()).booleanValue()) mc.player.setPosition(xPos, yPos, zPos);  if (((Boolean)this.bypass.getValue()).booleanValue()) mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05D, mc.player.posZ, true));  break;case "Clip": if (mc.gameSettings.keyBindSprint.isKeyDown() || mc.player.ticksExisted % ((Integer)this.interval.getValue()).intValue() == 0) for (int i = 0; i < ((Integer)this.packets.getValue()).intValue(); i++) { double yposition = mc.player.posY + ((Integer)this.speedY.getValue()).intValue(); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, yposition, mc.player.posZ, false)); if (((Boolean)this.update.getValue()).booleanValue()) mc.player.setPosition(mc.player.posX, yposition, mc.player.posZ);  if (((Boolean)this.bypass.getValue()).booleanValue()) mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05D, mc.player.posZ, true));  }   break; }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   public void onEnable() {
/*    */     this.startFlat = mc.player.posY;
/*    */     this.num = 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\ClipFlight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
