//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.movement;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "FastFall", category = Category.Movement)
/*    */ public class FastFall extends Module {
/* 11 */   DoubleSetting dist = registerDouble("Min Distance", 3.0D, 0.0D, 25.0D);
/* 12 */   DoubleSetting speed = registerDouble("Multiplier", 3.0D, 0.0D, 10.0D);
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 16 */     if (mc.world.isAirBlock(new BlockPos(mc.player.getPositionVector())) && 
/* 17 */       mc.player.onGround && (
/* 18 */       !mc.player.isElytraFlying() || mc.player.fallDistance < ((Double)this.dist
/* 19 */       .getValue()).doubleValue() || !mc.player.capabilities.isFlying))
/*    */     {
/* 21 */       mc.player.motionY -= ((Double)this.speed.getValue()).doubleValue();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\FastFall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
