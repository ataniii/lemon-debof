//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.MathUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "PhaseWalk", category = Category.Movement)
/*     */ public class PhaseWalk extends Module {
/*  22 */   BooleanSetting phaseCheck = registerBoolean("Only In Block", true);
/*  23 */   ModeSetting noClipMode = registerMode("NoClipMode", Arrays.asList(new String[] { "Bypass", "NoClip", "None", "Fall" }, ), "NoClip");
/*  24 */   BooleanSetting fallPacket = registerBoolean("Fall Packet", true);
/*  25 */   BooleanSetting sprintPacket = registerBoolean("Sprint Packet", true);
/*  26 */   BooleanSetting instantWalk = registerBoolean("Instant Walk", true);
/*  27 */   BooleanSetting antiVoid = registerBoolean("Anti Void", false);
/*  28 */   BooleanSetting clip = registerBoolean("Clip", true);
/*  29 */   IntegerSetting antiVoidHeight = registerInteger("Anti Void Height", 5, 1, 100);
/*  30 */   DoubleSetting instantWalkSpeed = registerDouble("Instant Speed", 1.8D, 0.1D, 2.0D, () -> (Boolean)this.instantWalk.getValue());
/*  31 */   DoubleSetting phaseSpeed = registerDouble("Phase Walk Speed", 42.4D, 0.1D, 70.0D);
/*  32 */   BooleanSetting downOnShift = registerBoolean("Phase Down When Crouch", true);
/*  33 */   BooleanSetting stopMotion = registerBoolean("Attempt Clips", true);
/*  34 */   IntegerSetting stopMotionDelay = registerInteger("Attempt Clips Delay", 5, 0, 20, () -> (Boolean)this.stopMotion.getValue());
/*     */   
/*     */   int delay;
/*     */   
/*     */   public void onDisable() {
/*  39 */     mc.player.noClip = false;
/*     */   }
/*     */   
/*     */   private boolean air(BlockPos pos) {
/*  43 */     Block blockState = BlockUtil.getBlock(pos);
/*  44 */     return (!BlockUtil.airBlocks.contains(blockState) && blockState != Blocks.WEB);
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  48 */     this.delay++;
/*  49 */     double n = ((Double)this.phaseSpeed.getValue()).doubleValue() / 1000.0D;
/*  50 */     double n2 = ((Double)this.instantWalkSpeed.getValue()).doubleValue() / 10.0D;
/*     */     RayTraceResult rayTraceBlocks;
/*  52 */     if (((Boolean)this.antiVoid.getValue()).booleanValue() && mc.player.posY <= ((Integer)this.antiVoidHeight.getValue()).intValue() && ((rayTraceBlocks = mc.world.rayTraceBlocks(mc.player.getPositionVector(), new Vec3d(mc.player.posX, 0.0D, mc.player.posZ), false, false, false)) == null || rayTraceBlocks.typeOfHit != RayTraceResult.Type.BLOCK)) {
/*  53 */       mc.player.setVelocity(0.0D, 0.0D, 0.0D);
/*     */     }
/*  55 */     if (((Boolean)this.phaseCheck.getValue()).booleanValue())
/*  56 */     { if ((mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown()) && ((!eChestCheck() && air(PlayerUtil.getPlayerPos())) || air(PlayerUtil.getPlayerPos().up())))
/*  57 */       { if (mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isPressed() && mc.player.isSneaking()) {
/*  58 */           double[] motion = getMotion(n);
/*  59 */           if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) {
/*  60 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion[0], mc.player.posY - 0.0424D, mc.player.posZ + motion[1], mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */           } else {
/*     */             
/*  63 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion[0], mc.player.posY, mc.player.posZ + motion[1], mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */           } 
/*  65 */           if (((String)this.noClipMode.getValue()).equals("Fall")) {
/*  66 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX, -1300.0D, mc.player.posZ, mc.player.rotationYaw * -5.0F, mc.player.rotationPitch * -5.0F, true));
/*     */           }
/*  68 */           if (((String)this.noClipMode.getValue()).equals("NoClip")) {
/*  69 */             mc.player.setVelocity(0.0D, 0.0D, 0.0D);
/*  70 */             if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) {
/*  71 */               double[] directionSpeed = MathUtil.directionSpeed(0.05999999865889549D);
/*  72 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + directionSpeed[0], mc.player.posY, mc.player.posZ + directionSpeed[1], mc.player.onGround));
/*  73 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */             } 
/*  75 */             if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/*  76 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 0.05999999865889549D, mc.player.posZ, mc.player.onGround));
/*  77 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */             } 
/*  79 */             if (mc.gameSettings.keyBindJump.isKeyDown()) {
/*  80 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05999999865889549D, mc.player.posZ, mc.player.onGround));
/*  81 */               mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */             } 
/*     */           } 
/*  84 */           if (((String)this.noClipMode.getValue()).equals("Bypass")) {
/*  85 */             mc.player.noClip = true;
/*     */           }
/*  87 */           if (((Boolean)this.fallPacket.getValue()).booleanValue()) {
/*  88 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_RIDING_JUMP));
/*     */           }
/*  90 */           if (((Boolean)this.sprintPacket.getValue()).booleanValue()) {
/*  91 */             mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */           }
/*  93 */           if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) {
/*  94 */             mc.player.setPosition(mc.player.posX + motion[0], mc.player.posY - 0.0424D, mc.player.posZ + motion[1]);
/*     */           } else {
/*     */             
/*  97 */             mc.player.setPosition(mc.player.posX + motion[0], mc.player.posY, mc.player.posZ + motion[1]);
/*     */           } 
/*  99 */           mc.player.motionZ = 0.0D;
/* 100 */           mc.player.motionY = 0.0D;
/* 101 */           mc.player.motionX = 0.0D;
/* 102 */           mc.player.noClip = true;
/*     */         } 
/* 104 */         if (mc.player.collidedHorizontally && ((Boolean)this.clip.getValue()).booleanValue() && !mc.gameSettings.keyBindForward.isKeyDown() && !mc.gameSettings.keyBindBack.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown()) {
/* 105 */           mc.gameSettings.keyBindRight.isKeyDown();
/*     */         }
/*     */         
/* 108 */         if (mc.player.collidedHorizontally ? (((Boolean)this.stopMotion.getValue()).booleanValue() ? (
/* 109 */           this.delay < ((Integer)this.stopMotionDelay.getValue()).intValue()) : 
/*     */ 
/*     */ 
/*     */           
/* 113 */           !mc.player.collidedHorizontally) : !mc.player.collidedHorizontally)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 164 */           if (((Boolean)this.instantWalk.getValue()).booleanValue())
/* 165 */           { double[] directionSpeed3 = MathUtil.directionSpeed(n2);
/* 166 */             mc.player.motionX = directionSpeed3[0];
/* 167 */             mc.player.motionZ = directionSpeed3[1]; }  return; }  double[] motion2 = getMotion(n); if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion2[0], mc.player.posY - 0.1D, mc.player.posZ + motion2[1], mc.player.rotationYaw, mc.player.rotationPitch, false)); } else { mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion2[0], mc.player.posY, mc.player.posZ + motion2[1], mc.player.rotationYaw, mc.player.rotationPitch, false)); }  if (((String)this.noClipMode.getValue()).equals("Fall"))
/*     */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX, -1300.0D, mc.player.posZ, mc.player.rotationYaw * -5.0F, mc.player.rotationPitch * -5.0F, true));  if (((String)this.noClipMode.getValue()).equals("NoClip")) { mc.player.setVelocity(0.0D, 0.0D, 0.0D); if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) { double[] directionSpeed2 = MathUtil.directionSpeed(0.05999999865889549D); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + directionSpeed2[0], mc.player.posY, mc.player.posZ + directionSpeed2[1], mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  if (mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 0.05999999865889549D, mc.player.posZ, mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  if (mc.gameSettings.keyBindJump.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05999999865889549D, mc.player.posZ, mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  }  if (((String)this.noClipMode.getValue()).equals("Bypass"))
/*     */           mc.player.noClip = true;  if (((Boolean)this.fallPacket.getValue()).booleanValue())
/*     */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_RIDING_JUMP));  if (((Boolean)this.sprintPacket.getValue()).booleanValue())
/* 171 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));  if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.setPosition(mc.player.posX + motion2[0], mc.player.posY - 0.1D, mc.player.posZ + motion2[1]); } else { mc.player.setPosition(mc.player.posX + motion2[0], mc.player.posY, mc.player.posZ + motion2[1]); }  mc.player.motionZ = 0.0D; mc.player.motionY = 0.0D; mc.player.motionX = 0.0D; mc.player.noClip = true; this.delay = 0; return; }  } else if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown())
/* 172 */     { if (mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isPressed() && mc.player.isSneaking()) {
/* 173 */         double[] motion3 = getMotion(n);
/* 174 */         if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 175 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion3[0], mc.player.posY - 0.0424D, mc.player.posZ + motion3[1], mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */         } else {
/*     */           
/* 178 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion3[0], mc.player.posY, mc.player.posZ + motion3[1], mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */         } 
/* 180 */         if (((String)this.noClipMode.getValue()).equals("Fall")) {
/* 181 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX, -1300.0D, mc.player.posZ, mc.player.rotationYaw * -5.0F, mc.player.rotationPitch * -5.0F, true));
/*     */         }
/* 183 */         if (((String)this.noClipMode.getValue()).equals("NoClip")) {
/* 184 */           mc.player.setVelocity(0.0D, 0.0D, 0.0D);
/* 185 */           if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) {
/* 186 */             double[] directionSpeed4 = MathUtil.directionSpeed(0.05999999865889549D);
/* 187 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + directionSpeed4[0], mc.player.posY, mc.player.posZ + directionSpeed4[1], mc.player.onGround));
/* 188 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */           } 
/* 190 */           if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 191 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 0.05999999865889549D, mc.player.posZ, mc.player.onGround));
/* 192 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */           } 
/* 194 */           if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 195 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05999999865889549D, mc.player.posZ, mc.player.onGround));
/* 196 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround));
/*     */           } 
/*     */         } 
/* 199 */         if (((String)this.noClipMode.getValue()).equals("Bypass")) {
/* 200 */           mc.player.noClip = true;
/*     */         }
/* 202 */         if (((Boolean)this.fallPacket.getValue()).booleanValue()) {
/* 203 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_RIDING_JUMP));
/*     */         }
/* 205 */         if (((Boolean)this.sprintPacket.getValue()).booleanValue()) {
/* 206 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));
/*     */         }
/* 208 */         if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 209 */           mc.player.setPosition(mc.player.posX + motion3[0], mc.player.posY - 0.0424D, mc.player.posZ + motion3[1]);
/*     */         } else {
/*     */           
/* 212 */           mc.player.setPosition(mc.player.posX + motion3[0], mc.player.posY, mc.player.posZ + motion3[1]);
/*     */         } 
/* 214 */         mc.player.motionZ = 0.0D;
/* 215 */         mc.player.motionY = 0.0D;
/* 216 */         mc.player.motionX = 0.0D;
/* 217 */         mc.player.noClip = true;
/*     */       } 
/*     */       
/* 220 */       if (mc.player.collidedHorizontally ? (((Boolean)this.stopMotion.getValue()).booleanValue() ? (
/* 221 */         this.delay < ((Integer)this.stopMotionDelay.getValue()).intValue()) : 
/*     */ 
/*     */ 
/*     */         
/* 225 */         !mc.player.collidedHorizontally) : !mc.player.collidedHorizontally)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 276 */         if (((Boolean)this.instantWalk.getValue()).booleanValue())
/* 277 */         { double[] directionSpeed6 = MathUtil.directionSpeed(n2);
/* 278 */           mc.player.motionX = directionSpeed6[0];
/* 279 */           mc.player.motionZ = directionSpeed6[1]; }  return; }  double[] motion4 = getMotion(n); if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion4[0], mc.player.posY - 0.1D, mc.player.posZ + motion4[1], mc.player.rotationYaw, mc.player.rotationPitch, false)); } else { mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + motion4[0], mc.player.posY, mc.player.posZ + motion4[1], mc.player.rotationYaw, mc.player.rotationPitch, false)); }  if (((String)this.noClipMode.getValue()).equals("Fall"))
/*     */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX, -1300.0D, mc.player.posZ, mc.player.rotationYaw * -5.0F, mc.player.rotationPitch * -5.0F, true));  if (((String)this.noClipMode.getValue()).equals("NoClip")) { mc.player.setVelocity(0.0D, 0.0D, 0.0D); if (mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown() || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) { double[] directionSpeed5 = MathUtil.directionSpeed(0.05999999865889549D); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + directionSpeed5[0], mc.player.posY, mc.player.posZ + directionSpeed5[1], mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  if (mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 0.05999999865889549D, mc.player.posZ, mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  if (mc.gameSettings.keyBindJump.isKeyDown()) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.05999999865889549D, mc.player.posZ, mc.player.onGround)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, 0.0D, mc.player.posZ, mc.player.onGround)); }  }  if (((String)this.noClipMode.getValue()).equals("Bypass"))
/*     */         mc.player.noClip = true;  if (((Boolean)this.fallPacket.getValue()).booleanValue())
/*     */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_RIDING_JUMP));  if (((Boolean)this.sprintPacket.getValue()).booleanValue())
/*     */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SPRINTING));  if (((Boolean)this.downOnShift.getValue()).booleanValue() && mc.player.collidedVertically && mc.gameSettings.keyBindSneak.isKeyDown()) { mc.player.setPosition(mc.player.posX + motion4[0], mc.player.posY - 0.1D, mc.player.posZ + motion4[1]); } else { mc.player.setPosition(mc.player.posX + motion4[0], mc.player.posY, mc.player.posZ + motion4[1]); }
/*     */        mc.player.motionZ = 0.0D; mc.player.motionY = 0.0D; mc.player.motionX = 0.0D; mc.player.noClip = true; this.delay = 0; return; }
/* 285 */      } private boolean eChestCheck() { return (String.valueOf(mc.player.posY).split("\\.")[1].equals("875") || String.valueOf(mc.player.posY).split("\\.")[1].equals("5")); }
/*     */ 
/*     */   
/*     */   private double[] getMotion(double n) {
/* 289 */     float moveForward = mc.player.movementInput.moveForward;
/* 290 */     float moveStrafe = mc.player.movementInput.moveStrafe;
/* 291 */     float n2 = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/* 292 */     if (moveForward != 0.0F) {
/* 293 */       if (moveStrafe > 0.0F) {
/* 294 */         n2 += ((moveForward > 0.0F) ? -45 : 45);
/*     */       }
/* 296 */       else if (moveStrafe < 0.0F) {
/* 297 */         n2 += ((moveForward > 0.0F) ? 45 : -45);
/*     */       } 
/* 299 */       moveStrafe = 0.0F;
/* 300 */       if (moveForward > 0.0F) {
/* 301 */         moveForward = 1.0F;
/*     */       }
/* 303 */       else if (moveForward < 0.0F) {
/* 304 */         moveForward = -1.0F;
/*     */       } 
/*     */     } 
/* 307 */     return new double[] { moveForward * n * -Math.sin(Math.toRadians(n2)) + moveStrafe * n * Math.cos(Math.toRadians(n2)), moveForward * n * Math.cos(Math.toRadians(n2)) - moveStrafe * n * -Math.sin(Math.toRadians(n2)) };
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\PhaseWalk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
