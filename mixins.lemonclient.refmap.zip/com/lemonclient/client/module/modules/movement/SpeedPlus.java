//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ 
/*     */ import com.lemonclient.api.event.events.MotionUpdateEvent;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.api.event.events.StepEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.StringSetting;
/*     */ import com.lemonclient.api.util.misc.KeyBoardClass;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.RotationUtil;
/*     */ import com.lemonclient.api.util.world.MotionUtil;
/*     */ import com.lemonclient.api.util.world.TimerUtils;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ @Declaration(name = "Speed+", category = Category.Movement, priority = 999)
/*     */ public class SpeedPlus
/*     */   extends Module
/*     */ {
/*     */   public SpeedPlus() {
/*  42 */     this.damageBoost = registerBoolean("DamageBoost", true);
/*  43 */     this.sum = registerBoolean("Sum", false, () -> (Boolean)this.damageBoost.getValue());
/*  44 */     this.longJump = registerBoolean("TryLongJump", false);
/*  45 */     this.lagCoolDown = registerInteger("LagCoolDown", 2200, 0, 8000, () -> (Boolean)this.longJump.getValue());
/*  46 */     this.jumpStage = registerInteger("JumpStage", 6, 1, 20, () -> (Boolean)this.longJump.getValue());
/*  47 */     this.motionJump = registerBoolean("MotionJump", false, () -> (Boolean)this.longJump.getValue());
/*  48 */     this.randomBoost = registerBoolean("RandomBoost", false);
/*  49 */     this.lavaBoost = registerBoolean("LavaBoost", true);
/*  50 */     this.SpeedInWater = registerBoolean("SpeedInWater", true);
/*  51 */     this.strict = registerBoolean("Strict", false);
/*  52 */     this.strictBoost = registerBoolean("StrictBoost", false, () -> (Boolean)this.damageBoost.getValue());
/*  53 */     this.useTimer = registerBoolean("UseTimer", true);
/*  54 */     this.jump = registerBoolean("Jump", true);
/*  55 */     this.stepCheck = registerBoolean("Step Check", true);
/*  56 */     this.bindCheck = registerBoolean("Use Bind", false, () -> (Boolean)this.stepCheck.getValue());
/*  57 */     this.bind = registerString("Step Check Bind", "", () -> Boolean.valueOf((((Boolean)this.stepCheck.getValue()).booleanValue() && ((Boolean)this.bindCheck.getValue()).booleanValue())));
/*  58 */     this.minStepHeight = registerDouble("Min Step Height", 1.0D, 0.0D, 10.0D, () -> (Boolean)this.stepCheck.getValue());
/*  59 */     this.maxStepHeight = registerDouble("Max Step Height", 2.5D, 0.0D, 10.0D, () -> (Boolean)this.stepCheck.getValue());
/*  60 */     this.test = registerBoolean("Test Mode", false, () -> (Boolean)this.stepCheck.getValue());
/*  61 */     this.lagBackCoolDown = new Timing();
/*  62 */     this.rdBoostTimer = new Timing();
/*     */     
/*  64 */     this.stage = 1; this.level = 1;
/*     */     
/*  66 */     this.boostFactor = 6.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) { this.lastDist = 0.0D; this.moveSpeed = applySpeedPotionEffects(); this.stage = 2; this.detectionTime = System.currentTimeMillis(); this.lagDetected = true; this.rdBoostTimer.reset(); this.boostFactor = 8.0F; if (((Boolean)this.longJump.getValue()).booleanValue()) { this.readyStage = 0; this.inCoolDown = true; if (!this.checkCoolDown) { this.lagBackCoolDown.reset(); this.checkCoolDown = true; }  }  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.motionUpdateEventListener = new Listener(event -> {
/*     */           if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */             return;
/*     */           }
/*     */           
/*     */           try {
/*     */             if (this.lagBackCoolDown.passedMs(((Integer)this.lagCoolDown.getValue()).intValue())) {
/*     */               this.checkCoolDown = false;
/*     */               
/*     */               this.inCoolDown = false;
/*     */               this.lagBackCoolDown.reset();
/*     */             } 
/*     */             if (System.currentTimeMillis() - this.detectionTime > 3182L) {
/*     */               this.lagDetected = false;
/*     */             }
/*     */             if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/*     */               TimerUtils.setTickLength(45.955883F);
/*     */             }
/*     */             if (event.stage == 1) {
/*     */               this.lastDist = Math.sqrt((mc.player.posX - mc.player.prevPosX) * (mc.player.posX - mc.player.prevPosX) + (mc.player.posZ - mc.player.prevPosZ) * (mc.player.posZ - mc.player.prevPosZ));
/*     */             }
/* 131 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     this.playerMoveEventListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (mc.player.movementInput.moveForward == 0.0F && mc.player.movementInput.moveStrafe == 0.0F) { event.setX(0.0D); event.setZ(0.0D); event.setSpeed(0.0D); return; }  if (this.checkStep && ((Boolean)this.test.getValue()).booleanValue()) { double yaw = calcMoveYaw(mc.player.rotationYaw, mc.player.movementInput.moveForward, mc.player.movementInput.moveStrafe); double dirX = -Math.sin(yaw); double dirZ = Math.cos(yaw); double dist = calcBlockDistAhead(dirX * 6.0D, dirZ * 6.0D); double stepHeight = ((Boolean)this.test.getValue()).booleanValue() ? calcStepHeight(dist, dirX, dirZ) : this.stepHigh; double multiplier = applySpeedPotionEffects(); if (stepHeight <= ((Double)this.maxStepHeight.getValue()).doubleValue()) { if (dist < 3.0D * multiplier && stepHeight > ((Double)this.minStepHeight.getValue()).doubleValue() * 2.0D) return;  if (dist < 1.4D * multiplier && stepHeight > ((Double)this.minStepHeight.getValue()).doubleValue()) return;  }  }  if (!((Boolean)this.SpeedInWater.getValue()).booleanValue() && shouldReturn()) return;  if (mc.player.onGround) this.level = 2;  if (round(mc.player.posY - (int)mc.player.posY, 3) == round(0.138D, 3) && ((Boolean)this.jump.getValue()).booleanValue()) { mc.player.motionY -= 0.07D; event.setY(event.getY() - 0.08316090325960147D); mc.player.posY -= 0.08316090325960147D; }  if (this.level != 1) { if (this.level == 2) { this.level = 3; if (!mc.player.isInLava() && mc.player.onGround && ((Boolean)this.jump.getValue()).booleanValue()) event.setY(mc.player.motionY = applyJumpBoostPotionEffects());  if (((Boolean)this.strict.getValue()).booleanValue() || mc.player.isSneaking()) { this.moveSpeed *= 1.433D; } else { this.moveSpeed *= 1.64847275D; }  } else if (this.level == 3) { this.level = 4; this.moveSpeed = this.lastDist - 0.6553D * (this.lastDist - applySpeedPotionEffects() + 0.04D); } else { if (mc.player.onGround && (!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.boundingBox.offset(0.0D, mc.player.motionY, 0.0D)).isEmpty() || mc.player.collidedVertically)) this.level = 1;  this.moveSpeed = this.lastDist - this.lastDist / 201.0D; }  } else { this.level = 2; this.moveSpeed = 1.418D * applySpeedPotionEffects(); }  if (((Boolean)this.damageBoost.getValue()).booleanValue() && ColorMain.INSTANCE.velocityBoost != 0.0D) { if (((Boolean)this.longJump.getValue()).booleanValue()) this.readyStage++;  this.boostSpeed = ColorMain.INSTANCE.velocityBoost; this.moveSpeed += this.boostSpeed; if (((Boolean)this.strictBoost.getValue()).booleanValue()) this.moveSpeed = Math.max((this.moveSpeed + 0.10000000149011612D) / 1.5D, applySpeedPotionEffects());  ColorMain.INSTANCE.velocityBoost = 0.0D; }  if (((Boolean)this.randomBoost.getValue()).booleanValue() && this.rdBoostTimer.passedMs(3500L) && !this.lagDetected && MotionUtil.moving((EntityLivingBase)mc.player) && mc.player.onGround) { this.moveSpeed += this.moveSpeed / this.boostFactor; this.boostFactor = 6.0F; this.rdBoostTimer.reset(); }  if (((Boolean)this.longJump.getValue()).booleanValue() && this.readyStage >= ((Integer)this.jumpStage.getValue()).intValue() && !this.inCoolDown) { if (!((Boolean)this.motionJump.getValue()).booleanValue()) { this.moveSpeed *= (((Integer)this.jumpStage.getValue()).intValue() / 10.0F); } else { motionJump(); mc.player.motionY *= 1.02D; mc.player.motionY *= 1.13D; mc.player.motionY *= 1.27D; this.moveSpeed += Math.abs(this.moveSpeed - this.boostSpeed); }  this.readyStage = 0; }  this.moveSpeed = Math.max(this.moveSpeed, applySpeedPotionEffects()); if (!shouldReturn()) { event.setSpeed(this.moveSpeed); } else if (((Boolean)this.lavaBoost.getValue()).booleanValue() && mc.player.isInLava()) { event.setX(event.getX() * 3.1D); event.setZ(event.getZ() * 3.1D); if (mc.gameSettings.keyBindJump.isKeyDown()) event.setY(event.getY() * 3.0D);  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     this.stepEventListener = new Listener(event -> this.stepHigh = (event.getBB()).minY - mc.player.posY, new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   public static SpeedPlus INSTANCE = new SpeedPlus(); BooleanSetting damageBoost; public BooleanSetting sum; BooleanSetting longJump; IntegerSetting lagCoolDown; IntegerSetting jumpStage; BooleanSetting motionJump; BooleanSetting randomBoost; BooleanSetting lavaBoost; BooleanSetting SpeedInWater; BooleanSetting strict; BooleanSetting strictBoost; BooleanSetting useTimer; BooleanSetting jump; BooleanSetting stepCheck; BooleanSetting bindCheck; StringSetting bind; DoubleSetting minStepHeight; DoubleSetting maxStepHeight; BooleanSetting test; Timing lagBackCoolDown; Timing rdBoostTimer;
/* 262 */   public boolean shouldReturn() { return (mc.player.isInLava() || mc.player.isInWater() || mc.player.isInWeb); }
/*     */   boolean lagDetected;
/*     */   boolean inCoolDown;
/*     */   boolean checkCoolDown;
/* 266 */   boolean warn; boolean checkStep; int readyStage; int stage; int level; double boostSpeed; double lastDist; double moveSpeed; double stepHigh; float boostFactor; long detectionTime; @EventHandler private final Listener<PacketEvent.Receive> receiveListener; @EventHandler private final Listener<MotionUpdateEvent> motionUpdateEventListener; @EventHandler private final Listener<PlayerMoveEvent> playerMoveEventListener; @EventHandler private final Listener<StepEvent> stepEventListener; public void onTick() { this.checkStep = false; if (((Boolean)this.stepCheck.getValue()).booleanValue()) if (((Boolean)this.bindCheck.getValue()).booleanValue()) { if (this.bind.getText().isEmpty() || !Keyboard.isKeyDown(KeyBoardClass.getKeyFromChar(this.bind.getText().charAt(0)))) this.checkStep = !this.checkStep;  } else { this.checkStep = true; }   } public static double round(double n, int n2) { if (n2 < 0) throw new IllegalArgumentException();  return (new BigDecimal(n)).setScale(n2, RoundingMode.HALF_UP).doubleValue(); } public void onEnable() { if (mc.player == null) { disable(); return; }  this.boostSpeed = 0.0D; this.lagBackCoolDown.reset(); this.readyStage = 0; this.warn = false; this.moveSpeed = applySpeedPotionEffects(); } public static void motionJump() { if (!mc.player.collidedVertically) { if (mc.player.motionY == -0.07190068807140403D) { mc.player.motionY *= 0.3499999940395355D; } else if (mc.player.motionY == -0.10306193759436909D) { mc.player.motionY *= 0.550000011920929D; } else if (mc.player.motionY == -0.13395038817442878D) { mc.player.motionY *= 0.6700000166893005D; } else if (mc.player.motionY == -0.16635183030382D) { mc.player.motionY *= 0.6899999976158142D; } else if (mc.player.motionY == -0.19088711097794803D) { mc.player.motionY *= 0.7099999785423279D; } else if (mc.player.motionY == -0.21121925191528862D) { mc.player.motionY *= 0.20000000298023224D; } else if (mc.player.motionY == -0.11979897632390576D) { mc.player.motionY *= 0.9300000071525574D; } else if (mc.player.motionY == -0.18758479151225355D) { mc.player.motionY *= 0.7200000286102295D; } else if (mc.player.motionY == -0.21075983825251726D) { mc.player.motionY *= 0.7599999904632568D; }  if (mc.player.motionY < -0.2D && mc.player.motionY > -0.24D) mc.player.motionY *= 0.7D;  if (mc.player.motionY < -0.25D && mc.player.motionY > -0.32D) mc.player.motionY *= 0.8D;  if (mc.player.motionY < -0.35D && mc.player.motionY > -0.8D) mc.player.motionY *= 0.98D;  if (mc.player.motionY < -0.8D && mc.player.motionY > -1.6D) mc.player.motionY *= 0.99D;  }  } public void onDisable() { this.moveSpeed = 0.0D;
/* 267 */     this.stage = 2;
/* 268 */     if (mc.player != null) {
/* 269 */       mc.player.stepHeight = 0.6F;
/* 270 */       TimerUtils.setTickLength(50.0F);
/*     */     }  }
/*     */ 
/*     */   
/*     */   private double calcBlockDistAhead(double offsetX, double offsetZ) {
/* 275 */     if (mc.player.collidedHorizontally) return 0.0D;
/*     */     
/* 277 */     AxisAlignedBB box = mc.player.boundingBox;
/* 278 */     double x = (offsetX > 0.0D) ? box.maxX : box.minX;
/* 279 */     double z = (offsetX > 0.0D) ? box.maxZ : box.minZ;
/*     */     
/* 281 */     return Math.min(
/* 282 */         rayTraceDist(new Vec3d(x, box.minY + 0.6D, z), offsetX, offsetZ), 
/* 283 */         rayTraceDist(new Vec3d(x, box.maxY + 0.6D, z), offsetX, offsetZ));
/*     */   }
/*     */ 
/*     */   
/*     */   private double rayTraceDist(Vec3d start, double offsetX, double offsetZ) {
/* 288 */     RayTraceResult result = mc.world.rayTraceBlocks(start, start.add(offsetX, 0.0D, offsetZ), false, true, false);
/* 289 */     if (result != null && result.hitVec != null) {
/* 290 */       double x = start.x - result.hitVec.x;
/* 291 */       double z = start.z - result.hitVec.z;
/* 292 */       return Math.sqrt(Math.pow(x, 2.0D) + Math.pow(z, 2.0D));
/*     */     } 
/* 294 */     return 999.0D;
/*     */   }
/*     */   private double calcMoveYaw(float yaw, float moveForward, float moveStrafe) {
/* 297 */     double moveYaw = (moveForward == 0.0F && moveStrafe == 0.0F) ? 0.0D : (Math.toDegrees(Math.atan2(moveForward, moveStrafe)) - 90.0D);
/* 298 */     return Math.toRadians(RotationUtil.normalizeAngle(yaw + moveYaw));
/*     */   }
/*     */   
/*     */   private double calcStepHeight(double dist, double motionX, double motionZ) {
/* 302 */     BlockPos pos = PlayerUtil.getPlayerPos();
/* 303 */     if (mc.world.getBlockState(pos).getCollisionBoundingBox((IBlockAccess)mc.world, pos) != null) return 0.0D;
/*     */     
/* 305 */     double i = Math.max(Math.round(dist), 1L);
/* 306 */     double minStepHeight = Double.MAX_VALUE;
/*     */     
/* 308 */     double x = motionX * i;
/* 309 */     double z = motionZ * i;
/* 310 */     minStepHeight = checkBox(minStepHeight, x, 0.0D);
/* 311 */     minStepHeight = checkBox(minStepHeight, 0.0D, z);
/*     */     
/* 313 */     return (minStepHeight == Double.MAX_VALUE) ? 0.0D : minStepHeight;
/*     */   }
/*     */   
/*     */   private double checkBox(double minStepHeight, double offsetX, double offsetZ) {
/* 317 */     AxisAlignedBB box = mc.player.boundingBox.offset(offsetX, 0.0D, offsetZ);
/* 318 */     if (!mc.world.collidesWithAnyBlock(box)) return minStepHeight;
/*     */     
/* 320 */     double stepHeight = minStepHeight;
/*     */     
/* 322 */     for (double y : new double[] { 0.605D, 1.005D, 1.505D, 2.005D, 2.505D }) {
/* 323 */       if (y > minStepHeight)
/*     */         break; 
/* 325 */       AxisAlignedBB stepBox = new AxisAlignedBB(box.minX, box.minY + y - 0.5D, box.minZ, box.maxX, box.minY + y, box.maxZ);
/*     */       
/* 327 */       List<AxisAlignedBB> boxList = mc.world.getCollisionBoxes(null, stepBox);
/* 328 */       AxisAlignedBB maxHeight = boxList.stream().max(Comparator.comparing(bb -> Double.valueOf(bb.maxY))).orElse(null);
/* 329 */       if (maxHeight != null) {
/* 330 */         double maxStepHeight = maxHeight.maxY - mc.player.posY;
/*     */         
/* 332 */         if (!mc.world.collidesWithAnyBlock(box.offset(0.0D, maxStepHeight, 0.0D))) {
/* 333 */           stepHeight = maxStepHeight;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 338 */     return stepHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   private double applySpeedPotionEffects() {
/* 343 */     double result = 0.2873D;
/*     */     
/* 345 */     if (mc.player.getActivePotionEffect(MobEffects.SPEED) != null) {
/* 346 */       result += 0.2873D * (mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier() + 1.0D) * 0.2D;
/*     */     }
/* 348 */     if (mc.player.getActivePotionEffect(MobEffects.SLOWNESS) != null) {
/* 349 */       result -= 0.2873D * (mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier() + 1.0D) * 0.15D;
/*     */     }
/* 351 */     return result;
/*     */   }
/*     */   
/*     */   private double applyJumpBoostPotionEffects() {
/* 355 */     double result = 0.4D;
/*     */     
/* 357 */     if (mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST) != null)
/* 358 */       result += (mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier() + 1) * 0.1D; 
/* 359 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\SpeedPlus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
