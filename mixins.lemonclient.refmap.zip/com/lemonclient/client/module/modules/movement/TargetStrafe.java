//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ 
/*     */ @Declaration(name = "TargetStrafe", category = Category.Movement)
/*     */ public class TargetStrafe extends Module {
/*     */   IntegerSetting range;
/*     */   BooleanSetting jump;
/*     */   BooleanSetting antiStuck;
/*     */   DoubleSetting distanceSetting;
/*     */   DoubleSetting maxDistance;
/*     */   DoubleSetting turnAmount;
/*     */   String pattern;
/*     */   Timing lagBackCoolDown;
/*     */   Timing boostTimer;
/*     */   long detectionTime;
/*     */   boolean checkCoolDown;
/*     */   double boostSpeed;
/*     */   double boostSpeed2;
/*     */   double lastDist;
/*     */   int level;
/*     */   double moveSpeed;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   @EventHandler
/*     */   private final Listener<MotionUpdateEvent> motionUpdateEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveEventListener;
/*     */   int direction;
/*     */   
/*  33 */   public TargetStrafe() { this.range = registerInteger("TargetRange", 20, 0, 256);
/*  34 */     this.jump = registerBoolean("Jump", true);
/*  35 */     this.antiStuck = registerBoolean("AntiStuck", true);
/*  36 */     this.distanceSetting = registerDouble("PreferredDistance", 1.0D, 0.0D, 10.0D);
/*  37 */     this.maxDistance = registerDouble("MaxDistance", 10.0D, 1.0D, 32.0D);
/*  38 */     this.turnAmount = registerDouble("TurnAmount", 5.0D, 1.0D, 90.0D);
/*     */     
/*  40 */     this.pattern = "%.1f";
/*  41 */     this.lagBackCoolDown = new Timing();
/*  42 */     this.boostTimer = new Timing();
/*     */     
/*  44 */     this.checkCoolDown = false;
/*     */ 
/*     */ 
/*     */     
/*  48 */     this.level = 1;
/*     */ 
/*     */     
/*  51 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) { this.lastDist = 0.0D; this.moveSpeed = Math.min(getBaseMoveSpeed(), getBaseMoveSpeed()); this.detectionTime = System.currentTimeMillis(); if (!this.checkCoolDown) { this.lagBackCoolDown.reset(); this.checkCoolDown = true; }  }  if (event.getPacket() instanceof SPacketEntityVelocity && ((SPacketEntityVelocity)event.getPacket()).getEntityID() == mc.player.getEntityId()) { this.boostSpeed = Math.hypot((((SPacketEntityVelocity)event.getPacket()).motionX / 8000.0F), (((SPacketEntityVelocity)event.getPacket()).motionZ / 8000.0F)); this.boostSpeed2 = this.boostSpeed; }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.motionUpdateEventListener = new Listener(event -> {
/*     */           if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */             return;
/*     */           }
/*     */           
/*     */           if (((HoleSnap)ModuleManager.getModule(HoleSnap.class)).isEnabled()) {
/*     */             return;
/*     */           }
/*     */           
/*     */           try {
/*     */             if (this.lagBackCoolDown.passedMs((long)Double.parseDouble(String.format(this.pattern, new Object[] { Double.valueOf(1000.0D) })))) {
/*     */               this.checkCoolDown = false;
/*     */               this.lagBackCoolDown.reset();
/*     */             } 
/*     */             if (event.stage == 1) {
/*     */               this.lastDist = Math.sqrt((mc.player.posX - mc.player.prevPosX) * (mc.player.posX - mc.player.prevPosX) + (mc.player.posZ - mc.player.prevPosZ) * (mc.player.posZ - mc.player.prevPosZ));
/*     */             }
/*  94 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }new java.util.function.Predicate[0]);
/*     */     
/*  97 */     this.playerMoveEventListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  EntityPlayer target = PlayerUtil.getNearestPlayer(((Integer)this.range.getValue()).intValue()); if (target != null) { if (mc.player.isInLava() || mc.player.isInWater() || mc.player.isInWeb) return;  if (mc.player.onGround) this.level = 2;  if (round(mc.player.posY - (int)mc.player.posY, 3) == round(0.138D, 3) && ((Boolean)this.jump.getValue()).booleanValue()) { EntityPlayerSP player = mc.player; player.motionY -= 0.07D; event.setY(event.getY() - 0.08316090325960147D); EntityPlayerSP player2 = mc.player; player2.posY -= 0.08316090325960147D; }  if (this.level != 1 || (mc.player.moveForward == 0.0F && mc.player.moveStrafing == 0.0F)) { if (this.level == 2) { this.level = 3; if (MotionUtil.moving((EntityLivingBase)mc.player)) { if (!mc.player.isInLava() && mc.player.onGround && ((Boolean)this.jump.getValue()).booleanValue()) event.setY(mc.player.motionY = 0.4D);  this.moveSpeed *= 1.433D; }  } else if (this.level == 3) { this.level = 4; this.moveSpeed = this.lastDist - 0.6553D * (this.lastDist - getBaseMoveSpeed() + 0.04D); } else { if (mc.player.onGround && (mc.world.getCollisionBoxes((Entity)mc.player, mc.player.boundingBox.offset(0.0D, mc.player.motionY, 0.0D)).size() > 0 || mc.player.collidedVertically)) this.level = 1;  this.moveSpeed = this.lastDist - this.lastDist / 201.0D; }  } else { this.level = 2; this.moveSpeed = 1.418D * getBaseMoveSpeed(); }  if (MotionUtil.moving((EntityLivingBase)mc.player) && this.boostSpeed2 != 0.0D) { if (this.boostTimer.passedMs(1L)) { this.moveSpeed = this.boostSpeed2; this.boostTimer.reset(); }  this.boostSpeed2 = 0.0D; }  this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed()); if (mc.player.collidedHorizontally && ((Boolean)this.antiStuck.getValue()).booleanValue()) switchDirection();  doStrafeAtSpeed(event, (RotationUtil.getRotationTo(target.getPositionVector())).x, target.getPositionVector()); }  }-100, new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     this.direction = 1; }
/*     */   public static double round(double n, int n2) { if (n2 < 0)
/*     */       throw new IllegalArgumentException(); 
/* 159 */     return (new BigDecimal(n)).setScale(n2, RoundingMode.HALF_UP).doubleValue(); } private void switchDirection() { this.direction = -this.direction; }
/*     */ 
/*     */ 
/*     */   
/*     */   private void doStrafeAtSpeed(PlayerMoveEvent event, float rotation, Vec3d target) {
/* 164 */     float rotationYaw = rotation + 90.0F * this.direction;
/*     */     
/* 166 */     double disX = mc.player.posX - target.x;
/* 167 */     double disZ = mc.player.posZ - target.z;
/*     */     
/* 169 */     double distance = Math.sqrt(disX * disX + disZ * disZ);
/*     */     
/* 171 */     if (distance < ((Double)this.maxDistance.getValue()).doubleValue()) {
/* 172 */       if (distance > ((Double)this.distanceSetting.getValue()).doubleValue()) {
/* 173 */         rotationYaw = (float)(rotationYaw - ((Double)this.turnAmount.getValue()).doubleValue() * this.direction);
/* 174 */       } else if (distance < ((Double)this.distanceSetting.getValue()).doubleValue()) {
/* 175 */         rotationYaw = (float)(rotationYaw + ((Double)this.turnAmount.getValue()).doubleValue() * this.direction);
/*     */       } 
/*     */     } else {
/* 178 */       rotationYaw = rotation;
/*     */     } 
/*     */     
/* 181 */     if (((Boolean)this.jump.getValue()).booleanValue() && mc.player.onGround) mc.player.jump();
/*     */     
/* 183 */     event.setX(this.moveSpeed * Math.cos(Math.toRadians((rotationYaw + 90.0F))));
/* 184 */     event.setZ(this.moveSpeed * Math.sin(Math.toRadians((rotationYaw + 90.0F))));
/*     */   }
/*     */   
/*     */   public double getBaseMoveSpeed() {
/* 188 */     double n = 0.2873D;
/* 189 */     if (mc.player.isPotionActive(MobEffects.SPEED)) {
/* 190 */       n *= 1.0D + 0.2D * (((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier() + 1);
/*     */     }
/* 192 */     return n;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\TargetStrafe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
