//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ @Declaration(name = "ElytraSwap", category = Category.Movement)
/*     */ public class ElytraSwap extends Module {
/*     */   public void onEnable() {
/*  16 */     if (mc.player != null) {
/*  17 */       InventoryPlayer items = mc.player.inventory;
/*  18 */       ItemStack body = items.armorItemInSlot(2);
/*  19 */       String body2 = body.getItem().getItemStackDisplayName(body);
/*  20 */       if (body2.equals("Air")) {
/*  21 */         int t = 0;
/*  22 */         int c = 0;
/*     */         int i;
/*  24 */         for (i = 9; i < 45; i++) {
/*  25 */           if (mc.player.inventory.getStackInSlot(i).getItem() == Items.ELYTRA) {
/*  26 */             t = i;
/*     */             break;
/*     */           } 
/*     */         } 
/*  30 */         if (t != 0) {
/*  31 */           MessageBus.sendClientDeleteMessage("Equipping Elytra", Notification.Type.SUCCESS, "ElytraSwap", 1);
/*  32 */           mc.playerController.windowClick(0, t, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  33 */           mc.playerController.windowClick(0, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */         } 
/*  35 */         if (t == 0) {
/*  36 */           for (i = 9; i < 45; i++) {
/*  37 */             if (mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_CHESTPLATE) {
/*  38 */               c = i;
/*     */               break;
/*     */             } 
/*     */           } 
/*  42 */           if (c != 0) {
/*  43 */             MessageBus.sendClientDeleteMessage("Equipping Chestplate", Notification.Type.SUCCESS, "ElytraSwap", 1);
/*  44 */             mc.playerController.windowClick(0, c, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  45 */             mc.playerController.windowClick(0, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */           } 
/*     */         } 
/*  48 */         if (c == 0 && t == 0)
/*  49 */           MessageBus.sendClientDeleteMessage("You do not have an Elytra or a Chestplate in your inventory. Doing nothing", Notification.Type.ERROR, "ElytraSwap", 1); 
/*  50 */         disable();
/*     */       } 
/*  52 */       if (body2.equals("Elytra")) {
/*  53 */         int t = 0;
/*  54 */         for (int i = 9; i < 45; i++) {
/*  55 */           if (mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_CHESTPLATE) {
/*  56 */             t = i;
/*     */             break;
/*     */           } 
/*     */         } 
/*  60 */         if (t != 0) {
/*  61 */           int l = 0;
/*  62 */           MessageBus.sendClientDeleteMessage("Equipping Chestplate", Notification.Type.SUCCESS, "ElytraSwap", 1);
/*  63 */           mc.playerController.windowClick(0, t, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  64 */           mc.playerController.windowClick(0, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  65 */           for (int j = 9; j < 45; j++) {
/*  66 */             if (mc.player.inventory.getStackInSlot(j).getItem() == Items.AIR) {
/*  67 */               l = j;
/*     */               break;
/*     */             } 
/*     */           } 
/*  71 */           mc.playerController.windowClick(0, l, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */         } 
/*  73 */         if (t == 0)
/*  74 */           MessageBus.sendClientDeleteMessage("You do not have a Chestplate in your inventory. Keeping Elytra equipped", Notification.Type.ERROR, "ElytraSwap", 1); 
/*  75 */         disable();
/*     */       } 
/*  77 */       if (body2.equals("Diamond Chestplate")) {
/*  78 */         int t = 0;
/*  79 */         for (int i = 9; i < 45; i++) {
/*  80 */           if (mc.player.inventory.getStackInSlot(i).getItem() == Items.ELYTRA) {
/*  81 */             t = i;
/*     */             break;
/*     */           } 
/*     */         } 
/*  85 */         if (t != 0) {
/*  86 */           int u = 0;
/*  87 */           MessageBus.sendClientDeleteMessage("Equipping Elytra", Notification.Type.SUCCESS, "ElytraSwap", 1);
/*  88 */           mc.playerController.windowClick(0, t, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  89 */           mc.playerController.windowClick(0, 6, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  90 */           for (int j = 9; j < 45; j++) {
/*  91 */             if (mc.player.inventory.getStackInSlot(j).getItem() == Items.AIR) {
/*  92 */               u = j;
/*     */               break;
/*     */             } 
/*     */           } 
/*  96 */           mc.playerController.windowClick(0, u, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */         } 
/*  98 */         if (t == 0)
/*  99 */           MessageBus.sendClientDeleteMessage("You do not have a Elytra in your inventory. Keeping Chestplate equipped", Notification.Type.ERROR, "ElytraSwap", 1); 
/* 100 */         disable();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\ElytraSwap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
