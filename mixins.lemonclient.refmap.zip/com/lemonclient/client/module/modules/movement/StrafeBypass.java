//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ 
/*     */ import com.lemonclient.api.event.events.MotionUpdateEvent;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerJumpEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.api.util.world.MotionUtil;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.play.server.SPacketEntityVelocity;
/*     */ 
/*     */ @Declaration(name = "StrafeBypass", category = Category.Movement, priority = 999)
/*     */ public class StrafeBypass extends Module {
/*     */   ModeSetting mode;
/*     */   BooleanSetting boost;
/*     */   BooleanSetting randomBoost;
/*     */   BooleanSetting debug;
/*     */   public Timing rdBoostTimer;
/*     */   public float boostFactor;
/*     */   public long detectionTime;
/*     */   public boolean lagDetected;
/*     */   
/*  25 */   public StrafeBypass() { this.mode = registerMode("Mode", Arrays.asList(new String[] { "Strict", "Normal" }, ), "Normal");
/*  26 */     this.boost = registerBoolean("DamageBoost", false);
/*  27 */     this.randomBoost = registerBoolean("RandomBoost", false);
/*  28 */     this.debug = registerBoolean("Debug", false);
/*  29 */     this.rdBoostTimer = new Timing();
/*  30 */     this.boostFactor = 4.0F;
/*     */ 
/*     */ 
/*     */     
/*  34 */     this.stage = 1;
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof SPacketEntityVelocity && ((SPacketEntityVelocity)event.getPacket()).getEntityID() == mc.player.getEntityId() && !((SpeedPlus)ModuleManager.getModule(SpeedPlus.class)).isEnabled()) this.boostSpeed = Math.max(Math.hypot((((SPacketEntityVelocity)event.getPacket()).motionX / 8000.0F), (((SPacketEntityVelocity)event.getPacket()).motionZ / 8000.0F)), this.boostSpeed);  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) { this.detectionTime = System.currentTimeMillis(); this.lagDetected = true; this.rdBoostTimer.reset(); this.boostFactor = 6.0F; }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.motionUpdateEventListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getEra() != LemonClientEvent.Era.PRE) return;  if (System.currentTimeMillis() - this.detectionTime > 3182L) this.lagDetected = false;  if (event.stage == 1) this.lastDist = Math.sqrt((mc.player.posX - mc.player.prevPosX) * (mc.player.posX - mc.player.prevPosX) + (mc.player.posZ - mc.player.prevPosZ) * (mc.player.posZ - mc.player.prevPosZ));  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.jumpEventListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (!mc.player.isInWater() && !mc.player.isInLava()) event.cancel();  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     this.moveEventListener = new Listener(event -> {
/*     */           if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */             return;
/*     */           }
/*     */           if (!mc.player.isInWater() && !mc.player.isInLava()) {
/*     */             if (mc.player.movementInput.moveForward == 0.0D && mc.player.movementInput.moveStrafe == 0.0D) {
/*     */               event.setX(0.0D);
/*     */               event.setZ(0.0D);
/*     */               event.setSpeed(0.0D);
/*     */               return;
/*     */             } 
/*     */             if (mc.player.onGround) {
/*     */               this.stage = 2;
/*     */             }
/*     */             switch (this.stage) {
/*     */               case 0:
/*     */                 this.stage++;
/*     */                 this.lastDist = 0.0D;
/*     */                 break;
/*     */ 
/*     */               
/*     */               case 3:
/*     */                 this.moveSpeed = this.lastDist - (((String)this.mode.getValue()).equals("Normal") ? 0.6896D : 0.795D) * (this.lastDist - getBaseMoveSpeed());
/*     */                 break;
/*     */ 
/*     */               
/*     */               default:
/*     */                 if ((!mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox().offset(0.0D, mc.player.motionY, 0.0D)).isEmpty() || mc.player.collidedVertically) && this.stage > 0)
/* 104 */                   this.stage = (mc.player.moveForward != 0.0F || mc.player.moveStrafing != 0.0F) ? 1 : 0; 
/*     */                 this.moveSpeed = this.lastDist - this.lastDist / 159.0D;
/*     */                 break;
/*     */             } 
/*     */             if (((Boolean)this.boost.getValue()).booleanValue() && this.boostSpeed != 0.0D && MotionUtil.moving((EntityLivingBase)mc.player)) {
/*     */               this.moveSpeed += this.boostSpeed;
/*     */               this.boostSpeed = 0.0D;
/*     */             } 
/*     */             if (((Boolean)this.randomBoost.getValue()).booleanValue() && this.rdBoostTimer.passedMs(3500L) && !this.lagDetected && MotionUtil.moving((EntityLivingBase)mc.player) && mc.player.onGround) {
/*     */               this.moveSpeed += this.moveSpeed / this.boostFactor;
/*     */               if (((Boolean)this.debug.getValue()).booleanValue())
/*     */                 MessageBus.sendClientPrefixMessage("RandomBoost", Notification.Type.INFO); 
/*     */               this.boostFactor = 4.0F;
/*     */               this.rdBoostTimer.reset();
/*     */             } 
/*     */             if (!mc.gameSettings.keyBindJump.isKeyDown() && mc.player.onGround) {
/*     */               this.moveSpeed = getBaseMoveSpeed();
/*     */             } else {
/*     */               this.moveSpeed = Math.max(this.moveSpeed, getBaseMoveSpeed());
/*     */             } 
/*     */             if (mc.player.movementInput.moveForward != 0.0D && mc.player.movementInput.moveStrafe != 0.0D) {
/*     */               mc.player.movementInput.moveForward *= (float)Math.sin(0.7853981633974483D);
/*     */               mc.player.movementInput.moveStrafe *= (float)Math.cos(0.7853981633974483D);
/*     */             } 
/*     */             event.setX((mc.player.movementInput.moveForward * this.moveSpeed * -Math.sin(Math.toRadians(mc.player.rotationYaw)) + mc.player.movementInput.moveStrafe * this.moveSpeed * Math.cos(Math.toRadians(mc.player.rotationYaw))) * (((String)this.mode.getValue()).equals("Normal") ? 0.993D : 0.99D));
/*     */             event.setZ((mc.player.movementInput.moveForward * this.moveSpeed * Math.cos(Math.toRadians(mc.player.rotationYaw)) - mc.player.movementInput.moveStrafe * this.moveSpeed * -Math.sin(Math.toRadians(mc.player.rotationYaw))) * (((String)this.mode.getValue()).equals("Normal") ? 0.993D : 0.99D));
/*     */             this.stage++;
/*     */           } 
/*     */         }new java.util.function.Predicate[0]); } public double boostSpeed; public int stage; private double lastDist; private double moveSpeed; @EventHandler private final Listener<PacketEvent.Receive> receiveListener; @EventHandler private final Listener<MotionUpdateEvent> motionUpdateEventListener; @EventHandler private final Listener<PlayerJumpEvent> jumpEventListener; @EventHandler
/* 133 */   private final Listener<PlayerMoveEvent> moveEventListener; public double getBaseMoveSpeed() { double result = 0.2873D;
/*     */     
/* 135 */     if (mc.player.getActivePotionEffect(MobEffects.SPEED) != null) {
/* 136 */       result += 0.2873D * (mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier() + 1.0D) * 0.2D;
/*     */     }
/* 138 */     if (mc.player.getActivePotionEffect(MobEffects.SLOWNESS) != null) {
/* 139 */       result -= 0.2873D * (mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier() + 1.0D) * 0.15D;
/*     */     }
/* 141 */     return result; }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\StrafeBypass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
