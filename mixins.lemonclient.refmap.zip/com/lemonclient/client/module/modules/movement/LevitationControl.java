//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.movement;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ 
/*    */ @Declaration(name = "LevitationControl", category = Category.Movement)
/*    */ public class LevitationControl extends Module {
/* 14 */   DoubleSetting upAmplifier = registerDouble("Amplifier Up", 1.0D, 1.0D, 3.0D);
/* 15 */   DoubleSetting downAmplifier = registerDouble("Amplifier Down", 1.0D, 1.0D, 3.0D);
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 20 */     if (mc.player.isPotionActive(MobEffects.LEVITATION)) {
/*    */       
/* 22 */       int amplifier = ((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.player.getActivePotionEffect(Objects.<Potion>requireNonNull(Potion.getPotionById(25))))).getAmplifier();
/*    */       
/* 24 */       if (mc.gameSettings.keyBindJump.isKeyDown()) {
/* 25 */         mc.player.motionY = (0.05D * (amplifier + 1) - mc.player.motionY) * 0.2D * ((Double)this.upAmplifier.getValue()).doubleValue();
/* 26 */       } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 27 */         mc.player.motionY = -((0.05D * (amplifier + 1) - mc.player.motionY) * 0.2D * ((Double)this.downAmplifier.getValue()).doubleValue());
/*    */       } else {
/* 29 */         mc.player.motionY = 0.0D;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\LevitationControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
