//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.util.misc.Timer;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.MotionUtil;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.Objects;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.network.play.server.SPacketEntityVelocity;
/*     */ import net.minecraft.network.play.server.SPacketExplosion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ 
/*     */ @Declaration(name = "Speed", category = Category.Movement)
/*     */ public class Speed extends Module {
/*     */   private final Timer timer;
/*     */   public int yl;
/*     */   ModeSetting mode;
/*     */   DoubleSetting speed;
/*     */   BooleanSetting jump;
/*     */   
/*     */   public Speed() {
/*  29 */     this.timer = new Timer();
/*     */     
/*  31 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Strafe", "GroundStrafe", "OnGround", "Fake", "YPort" }, ), "Strafe");
/*     */     
/*  33 */     this.speed = registerDouble("Speed", 2.0D, 0.0D, 10.0D, () -> Boolean.valueOf((((String)this.mode.getValue()).equals("Strafe") || ((String)this.mode.getValue()).equalsIgnoreCase("Beta"))));
/*  34 */     this.jump = registerBoolean("Jump", true, () -> Boolean.valueOf((((String)this.mode.getValue()).equals("Strafe") || ((String)this.mode.getValue()).equalsIgnoreCase("Beta"))));
/*  35 */     this.boost = registerBoolean("Boost", false, () -> Boolean.valueOf((((String)this.mode.getValue()).equalsIgnoreCase("Strafe") || ((String)this.mode.getValue()).equalsIgnoreCase("Beta"))));
/*  36 */     this.multiply = registerDouble("Multiply", 0.8D, 0.1D, 1.0D, () -> Boolean.valueOf((((Boolean)this.boost.getValue()).booleanValue() && this.boost.isVisible())));
/*  37 */     this.max = registerDouble("Maximum", 0.5D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.boost.getValue()).booleanValue() && this.boost.isVisible())));
/*     */     
/*  39 */     this.gSpeed = registerDouble("Ground Speed", 0.3D, 0.0D, 0.5D, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("GroundStrafe")));
/*     */     
/*  41 */     this.yPortSpeed = registerDouble("Speed YPort", 0.06D, 0.01D, 0.15D, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("YPort")));
/*     */     
/*  43 */     this.onGroundSpeed = registerDouble("Speed OnGround", 1.5D, 0.01D, 3.0D, () -> Boolean.valueOf(((String)this.mode.getValue()).equalsIgnoreCase("OnGround")));
/*  44 */     this.strictOG = registerBoolean("Head Block Only", false, () -> Boolean.valueOf(((String)this.mode.getValue()).equalsIgnoreCase("OnGround")));
/*     */     
/*  46 */     this.jumpHeight = registerDouble("Jump Speed", 0.41D, 0.0D, 1.0D, () -> Boolean.valueOf(((((String)this.mode.getValue()).equalsIgnoreCase("Strafe") && ((Boolean)this.jump.getValue()).booleanValue()) || (((String)this.mode.getValue()).equalsIgnoreCase("Beta") && ((Boolean)this.jump.getValue()).booleanValue()))));
/*  47 */     this.jumpDelay = registerInteger("Jump Delay", 300, 0, 1000, () -> Boolean.valueOf(((((String)this.mode.getValue()).equalsIgnoreCase("Strafe") && ((Boolean)this.jump.getValue()).booleanValue()) || (((String)this.mode.getValue()).equalsIgnoreCase("Beta") && ((Boolean)this.jump.getValue()).booleanValue()))));
/*     */     
/*  49 */     this.useTimer = registerBoolean("Timer", false);
/*  50 */     this.timerVal = registerDouble("Timer Speed", 1.088D, 0.8D, 1.2D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.kbTimer = new Timer();
/*     */     
/*  58 */     this.playerMoveEventListener = new Listener(event -> {
/*     */           if (mc.player.isInLava() || mc.player.isInWater() || mc.player.isOnLadder() || mc.player.isInWeb) {
/*     */             return;
/*     */           }
/*     */           
/*     */           if (((String)this.mode.getValue()).equalsIgnoreCase("Strafe")) {
/*     */             double speedY = ((Double)this.jumpHeight.getValue()).doubleValue();
/*     */             
/*     */             if (mc.player.onGround && ((Boolean)this.jump.getValue()).booleanValue()) {
/*     */               mc.player.jump();
/*     */             }
/*     */             
/*     */             if (mc.player.onGround && MotionUtil.moving((EntityLivingBase)mc.player) && this.timer.hasReached(((Integer)this.jumpDelay.getValue()).intValue())) {
/*     */               if (mc.player.isPotionActive(MobEffects.JUMP_BOOST)) {
/*     */                 speedY += ((((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST))).getAmplifier() + 1) * 0.1F);
/*     */               }
/*     */               
/*     */               if (((Boolean)this.jump.getValue()).booleanValue()) {
/*     */                 event.setY(mc.player.motionY = speedY);
/*     */               }
/*     */               
/*  79 */               this.playerSpeed = MotionUtil.getBaseMoveSpeed() * ((EntityUtil.isColliding(0.0D, -0.5D, 0.0D) instanceof net.minecraft.block.BlockLiquid && !EntityUtil.isInLiquid()) ? 0.91D : ((Double)this.speed.getValue()).doubleValue());
/*     */               
/*     */               this.slowDown = true;
/*     */               this.timer.reset();
/*     */             } else if (this.slowDown || mc.player.collidedHorizontally) {
/*  84 */               this.playerSpeed -= (EntityUtil.isColliding(0.0D, -0.8D, 0.0D) instanceof net.minecraft.block.BlockLiquid && !EntityUtil.isInLiquid()) ? 0.4D : (0.7D * MotionUtil.getBaseMoveSpeed());
/*     */               
/*     */               this.slowDown = false;
/*     */             } else {
/*     */               this.playerSpeed -= this.playerSpeed / 159.0D;
/*     */             } 
/*     */             
/*     */             this.playerSpeed = Math.max(this.playerSpeed, MotionUtil.getBaseMoveSpeed());
/*     */             
/*     */             if (((Boolean)this.boost.getValue()).booleanValue() && !this.kbTimer.hasReached(50L)) {
/*     */               this.playerSpeed += Math.min(this.velocity * ((Double)this.multiply.getValue()).doubleValue(), ((Double)this.max.getValue()).doubleValue());
/*     */             }
/*     */             
/*     */             double[] dir = MotionUtil.forward(this.playerSpeed);
/*     */             
/*     */             event.setX(dir[0]);
/*     */             
/*     */             event.setZ(dir[1]);
/*     */           } 
/*     */           
/*     */           if (((String)this.mode.getValue()).equalsIgnoreCase("GroundStrafe")) {
/*     */             this.playerSpeed = ((Double)this.gSpeed.getValue()).doubleValue();
/*     */             
/*     */             this.playerSpeed *= MotionUtil.getBaseMoveSpeed() / 0.2873D;
/*     */             
/*     */             if (mc.player.onGround) {
/*     */               double[] dir = MotionUtil.forward(this.playerSpeed);
/*     */               
/*     */               event.setX(dir[0]);
/*     */               
/*     */               event.setZ(dir[1]);
/*     */             } 
/*     */           } else if (((String)this.mode.getValue()).equalsIgnoreCase("OnGround")) {
/*     */             if (mc.player.collidedHorizontally) {
/*     */               return;
/*     */             }
/*     */             
/*     */             double offset = 0.4D;
/*     */             
/*     */             if (mc.world.collidesWithAnyBlock(mc.player.boundingBox.offset(0.0D, 0.4D, 0.0D))) {
/*     */               offset = 2.0D - mc.player.boundingBox.maxY;
/*     */             } else if (((Boolean)this.strictOG.getValue()).booleanValue()) {
/*     */               return;
/*     */             } 
/*     */             mc.player.posY -= offset;
/*     */             mc.player.motionY = -1000.0D;
/*     */             mc.player.cameraPitch = 0.3F;
/*     */             mc.player.distanceWalkedModified = 44.0F;
/*     */             if (mc.player.onGround) {
/*     */               mc.player.posY += offset;
/*     */               mc.player.motionY = offset;
/*     */               mc.player.distanceWalkedOnStepModified = 44.0F;
/*     */               mc.player.motionX *= ((Double)this.onGroundSpeed.getValue()).doubleValue();
/*     */               mc.player.motionZ *= ((Double)this.onGroundSpeed.getValue()).doubleValue();
/*     */               mc.player.cameraPitch = 0.0F;
/*     */             } 
/*     */           } 
/*     */         }new java.util.function.Predicate[0]);
/* 142 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof SPacketExplosion) { this.velocity = (Math.abs(((SPacketExplosion)event.getPacket()).motionX) + Math.abs(((SPacketExplosion)event.getPacket()).motionZ)); this.kbTimer.reset(); }  if (event.getPacket() instanceof SPacketEntityVelocity) { if (((SPacketEntityVelocity)event.getPacket()).getEntityID() != mc.player.getEntityId()) return;  if (this.velocity < (Math.abs(((SPacketEntityVelocity)event.getPacket()).motionX) + Math.abs(((SPacketEntityVelocity)event.getPacket()).motionZ))) { this.velocity = (Math.abs(((SPacketEntityVelocity)event.getPacket()).motionX) + Math.abs(((SPacketEntityVelocity)event.getPacket()).motionZ)); this.kbTimer.reset(); }  }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   BooleanSetting boost; DoubleSetting multiply; DoubleSetting max;
/*     */   DoubleSetting gSpeed;
/*     */   DoubleSetting yPortSpeed;
/*     */   DoubleSetting onGroundSpeed;
/*     */   BooleanSetting strictOG;
/*     */   DoubleSetting jumpHeight;
/*     */   IntegerSetting jumpDelay;
/*     */   BooleanSetting useTimer;
/*     */   DoubleSetting timerVal;
/*     */   private boolean slowDown;
/*     */   private double playerSpeed;
/*     */   private double velocity;
/*     */   Timer kbTimer;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   
/*     */   public void onEnable() {
/* 163 */     this.playerSpeed = MotionUtil.getBaseMoveSpeed();
/* 164 */     this.yl = (int)mc.player.posY;
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 168 */     this.timer.reset();
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 172 */     if (mc.player == null || mc.world == null) {
/* 173 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     if (((String)this.mode.getValue()).equalsIgnoreCase("YPort")) {
/* 178 */       handleYPortSpeed();
/*     */     }
/*     */     
/* 181 */     if (((Boolean)this.useTimer.getValue()).booleanValue()) {
/* 182 */       TimerUtils.setTickLength(50.0F / ((Double)this.timerVal.getValue()).floatValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleYPortSpeed() {
/* 187 */     if (!MotionUtil.moving((EntityLivingBase)mc.player) || (mc.player.isInWater() && mc.player.isInLava()) || mc.player.collidedHorizontally) {
/*     */       return;
/*     */     }
/*     */     
/* 191 */     if (mc.player.onGround) {
/* 192 */       mc.player.jump();
/* 193 */       MotionUtil.setSpeed((EntityLivingBase)mc.player, MotionUtil.getBaseMoveSpeed() + ((Double)this.yPortSpeed.getValue()).doubleValue());
/*     */     } else {
/* 195 */       mc.player.motionY = -1.0D;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getHudInfo() {
/* 200 */     return "[" + ChatFormatting.WHITE + (String)this.mode.getValue() + ChatFormatting.GRAY + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\Speed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
