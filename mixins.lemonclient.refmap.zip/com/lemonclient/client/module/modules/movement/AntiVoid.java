//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.PlacementUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.Arrays;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AntiVoid", category = Category.Movement)
/*     */ public class AntiVoid
/*     */   extends Module {
/*     */   public AntiVoid() {
/*  31 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Freeze", "Glitch", "Catch" }, ), "Freeze");
/*  32 */     this.height = registerDouble("Height", 2.0D, 0.0D, 5.0D);
/*  33 */     this.chorus = registerBoolean("Chorus", false, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Freeze")));
/*  34 */     this.packetFly = registerBoolean("PacketFly", false, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Catch")));
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.playerMoveEventListener = new Listener(event -> {
/*     */           try {
/*     */             if (mc.player.posY < ((Double)this.height.getValue()).doubleValue() + 0.1D && ((String)this.mode.getValue()).equalsIgnoreCase("Freeze") && mc.world.getBlockState(new BlockPos(mc.player.posX, 0.0D, mc.player.posZ)).getMaterial().isReplaceable()) {
/*     */               int oldSlot;
/*     */               int newSlot;
/*     */               int i;
/*     */               switch ((String)this.mode.getValue()) {
/*     */                 case "Freeze":
/*     */                   mc.player.posY = ((Double)this.height.getValue()).doubleValue();
/*     */                   event.setY(0.0D);
/*     */                   if (mc.player.getRidingEntity() != null) {
/*     */                     mc.player.ridingEntity.setVelocity(0.0D, 0.0D, 0.0D);
/*     */                   }
/*     */                   if (((Boolean)this.chorus.getValue()).booleanValue()) {
/*     */                     int j = -1;
/*     */                     int k = 0;
/*     */                     while (k < 9) {
/*     */                       ItemStack stack = mc.player.inventory.getStackInSlot(k);
/*     */                       if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof net.minecraft.item.ItemChorusFruit)) {
/*     */                         k++;
/*     */                         continue;
/*     */                       } 
/*     */                       j = k;
/*     */                     } 
/*     */                     if (j == -1) {
/*     */                       j = 1;
/*     */                       MessageBus.sendClientPrefixMessage(((ColorMain)ModuleManager.getModule(ColorMain.class)).getDisabledColor() + "Out of chorus!", Notification.Type.ERROR);
/*     */                       this.chorused = false;
/*     */                     } else {
/*     */                       this.chorused = true;
/*     */                     } 
/*     */                     if (this.chorused) {
/*     */                       mc.player.inventory.currentItem = j;
/*     */                       if (mc.player.canEat(true)) {
/*     */                         mc.player.setActiveHand(EnumHand.MAIN_HAND);
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case "Glitch":
/*     */                   mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 69.0D, mc.player.posZ, mc.player.onGround));
/*     */                   break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case "Catch":
/*     */                   oldSlot = mc.player.inventory.currentItem;
/*     */                   newSlot = -1;
/*     */                   for (i = 0; i < 9; i++) {
/*     */                     ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */                     if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
/*     */                       if (Block.getBlockFromItem(stack.getItem()).getDefaultState().isFullBlock()) {
/*     */                         if (!(((ItemBlock)stack.getItem()).getBlock() instanceof net.minecraft.block.BlockFalling)) {
/*     */                           newSlot = i;
/*     */                           break;
/*     */                         } 
/*     */                       }
/*     */                     }
/*     */                   } 
/*     */                   if (newSlot == -1) {
/*     */                     newSlot = 1;
/*     */                     MessageBus.sendClientPrefixMessage(((ColorMain)ModuleManager.getModule(ColorMain.class)).getDisabledColor() + "Out of valid blocks. Disabling!", Notification.Type.DISABLE);
/*     */                     disable();
/*     */                   } 
/*     */                   mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(newSlot));
/*     */                   PlacementUtil.place(new BlockPos(mc.player.posX, 0.0D, mc.player.posZ), EnumHand.MAIN_HAND, true);
/*     */                   if (mc.world.getBlockState(new BlockPos(mc.player.posX, 0.0D, mc.player.posZ)).getMaterial().isReplaceable() && ((Boolean)this.packetFly.getValue()).booleanValue()) {
/*     */                     mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX + mc.player.motionX, mc.player.posY + 0.0624D, mc.player.posZ + mc.player.motionZ, mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */                     mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false));
/*     */                   } 
/*     */                   mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldSlot));
/*     */                   break;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             } 
/* 159 */           } catch (Exception exception) {}
/*     */         }new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   ModeSetting mode;
/*     */   DoubleSetting height;
/*     */   BooleanSetting chorus;
/*     */   BooleanSetting packetFly;
/*     */   boolean chorused;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveEventListener;
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\AntiVoid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
