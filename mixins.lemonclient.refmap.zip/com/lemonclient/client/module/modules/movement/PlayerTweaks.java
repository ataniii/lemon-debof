//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.movement;
/*    */ import com.lemonclient.api.event.events.EntityCollisionEvent;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.event.events.WaterPushEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraftforge.client.event.InputUpdateEvent;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ @Declaration(name = "PlayerTweaks", category = Category.Movement)
/*    */ public class PlayerTweaks extends Module {
/*    */   public BooleanSetting guiMove;
/*    */   BooleanSetting noPush;
/*    */   BooleanSetting noFall;
/*    */   public BooleanSetting noSlow;
/*    */   BooleanSetting antiKnockBack;
/*    */   
/*    */   public PlayerTweaks() {
/* 21 */     this.guiMove = registerBoolean("Gui Move", false);
/* 22 */     this.noPush = registerBoolean("No Push", false);
/* 23 */     this.noFall = registerBoolean("No Fall", false);
/* 24 */     this.noSlow = registerBoolean("No Slow", false);
/* 25 */     this.antiKnockBack = registerBoolean("Velocity", false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     this.eventListener = new Listener(event -> { if (((Boolean)this.noSlow.getValue()).booleanValue() && mc.player.isHandActive() && !mc.player.isRiding()) { (event.getMovementInput()).moveStrafe *= 5.0F; (event.getMovementInput()).moveForward *= 5.0F; }  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     this.entityCollisionEventListener = new Listener(event -> { if (((Boolean)this.noPush.getValue()).booleanValue()) event.cancel();  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     this.receiveListener = new Listener(event -> { if (((Boolean)this.antiKnockBack.getValue()).booleanValue()) { if (event.getPacket() instanceof SPacketEntityVelocity && ((SPacketEntityVelocity)event.getPacket()).getEntityID() == mc.player.getEntityId()) event.cancel();  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketExplosion) event.cancel();  }  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 86 */     this.sendListener = new Listener(event -> { if (((Boolean)this.noFall.getValue()).booleanValue() && event.getPacket() instanceof CPacketPlayer && mc.player.fallDistance >= 3.0D) { CPacketPlayer packet = (CPacketPlayer)event.getPacket(); packet.onGround = true; }  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 95 */     this.waterPushEventListener = new Listener(event -> { if (((Boolean)this.noPush.getValue()).booleanValue()) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private final Listener<InputUpdateEvent> eventListener;
/*    */   @EventHandler
/*    */   private final Listener<EntityCollisionEvent> entityCollisionEventListener;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> receiveListener;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> sendListener;
/*    */   @EventHandler
/*    */   private final Listener<WaterPushEvent> waterPushEventListener;
/*    */   
/*    */   public void onUpdate() {
/*    */     if (((Boolean)this.guiMove.getValue()).booleanValue() && mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.GuiChat)) {
/*    */       if (Keyboard.isKeyDown(200))
/*    */         mc.player.rotationPitch -= 5.0F; 
/*    */       if (Keyboard.isKeyDown(208))
/*    */         mc.player.rotationPitch += 5.0F; 
/*    */       if (Keyboard.isKeyDown(205))
/*    */         mc.player.rotationYaw += 5.0F; 
/*    */       if (Keyboard.isKeyDown(203))
/*    */         mc.player.rotationYaw -= 5.0F; 
/*    */       if (mc.player.rotationPitch > 90.0F)
/*    */         mc.player.rotationPitch = 90.0F; 
/*    */       if (mc.player.rotationPitch < -90.0F)
/*    */         mc.player.rotationPitch = -90.0F; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\PlayerTweaks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
