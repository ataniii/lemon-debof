//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.movement;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.util.world.TimerUtils;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "LiquidSpeed", category = Category.Movement)
/*     */ public class LiquidSpeed extends Module {
/*     */   DoubleSetting timerVal;
/*     */   DoubleSetting XZWater;
/*     */   DoubleSetting upWater;
/*     */   DoubleSetting downWater;
/*     */   DoubleSetting XZBoostWater;
/*     */   DoubleSetting yBoostWater;
/*     */   DoubleSetting XZLava;
/*     */   DoubleSetting upLava;
/*     */   DoubleSetting downLava;
/*     */   
/*     */   public LiquidSpeed() {
/*  25 */     this.timerVal = registerDouble("Timer Speed", 1.0D, 1.0D, 2.0D);
/*     */     
/*  27 */     this.XZWater = registerDouble("XZ Water", 5.75D, 0.01D, 8.0D);
/*  28 */     this.upWater = registerDouble("Y+ Water", 2.69D, 0.01D, 8.0D);
/*  29 */     this.downWater = registerDouble("Y- Water", 0.8D, 0.01D, 8.0D);
/*  30 */     this.XZBoostWater = registerDouble("XZ Boost Water", 6.0D, 1.0D, 8.0D);
/*  31 */     this.yBoostWater = registerDouble("Y Boost Water", 2.9D, 0.1D, 8.0D);
/*     */     
/*  33 */     this.XZLava = registerDouble("XZ Lava", 3.8D, 0.01D, 8.0D);
/*  34 */     this.upLava = registerDouble("Y+ Lava", 2.69D, 0.01D, 8.0D);
/*  35 */     this.downLava = registerDouble("Y- Lava", 4.22D, 0.01D, 8.0D);
/*  36 */     this.XZBoostLava = registerDouble("XZ Boost Lava", 4.0D, 1.0D, 8.0D);
/*  37 */     this.yBoostLava = registerDouble("Y Boost Lava", 2.0D, 0.1D, 8.0D);
/*  38 */     this.jitter = registerDouble("Jitter", 1.0D, 1.0D, 20.0D);
/*  39 */     this.groundIgnore = registerBoolean("Ground Ignore", true);
/*  40 */     this.sides = new Vec3d[] { new Vec3d(0.3D, 0.0D, 0.3D), new Vec3d(0.3D, 0.0D, -0.3D), new Vec3d(-0.3D, 0.0D, 0.3D), new Vec3d(-0.3D, 0.0D, -0.3D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.moveSpeed = 0.0D;
/*  47 */     this.motionY = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketPlayerPosLook) reset();  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     this.playerMoveEventListener = new Listener(event -> { if (mc.player == null || mc.world == null) return;  if (!mc.player.isInWater() && !mc.player.isInLava()) return;  if (((Boolean)this.groundIgnore.getValue()).booleanValue() || !mc.player.onGround) { if (mc.player.isInWater()) { waterSwim(event); } else if (mc.player.isInLava()) { lavaSwim(event); } else { reset(); }  } else { stopMotion(event); reset(); }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   DoubleSetting XZBoostLava;
/*     */   DoubleSetting yBoostLava;
/*     */   DoubleSetting jitter;
/*     */   BooleanSetting groundIgnore;
/*     */   Vec3d[] sides;
/*     */   double moveSpeed;
/*     */   double motionY;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveEventListener;
/*     */   
/*     */   public void onDisable() {
/*     */     reset();
/*     */   }
/*     */   
/*     */   private boolean intersect(BlockPos pos) {
/*     */     return mc.player.boundingBox.intersects(mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos));
/*     */   }
/*     */   
/*     */   private boolean inLiquid(Material material) {
/*     */     Vec3d vec = mc.player.getPositionVector();
/*     */     for (Vec3d side : this.sides) {
/*     */       BlockPos blockPos = new BlockPos(vec.add(side));
/*     */       if (intersect(blockPos)) {
/*     */         IBlockState blockState = BlockUtil.getState(blockPos);
/*     */         if (!(blockState instanceof BlockLiquid))
/*     */           return false; 
/*     */         if (((BlockLiquid)blockState).material != material)
/*     */           return false; 
/*     */       } 
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   private void lavaSwim(PlayerMoveEvent moveEvent) {
/*     */     ySwim(moveEvent, ((Double)this.yBoostLava.getValue()).doubleValue(), ((Double)this.upLava.getValue()).doubleValue(), ((Double)this.downLava.getValue()).doubleValue());
/*     */     boolean jump = mc.player.movementInput.jump;
/*     */     boolean sneak = mc.player.movementInput.sneak;
/*     */     if ((!jump || !sneak) && (jump || sneak)) {
/*     */       TimerUtils.setTimerSpeed(((Double)this.timerVal.getValue()).floatValue());
/*     */     } else {
/*     */       TimerUtils.setTimerSpeed(1.0F);
/*     */     } 
/*     */     if (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F) {
/*     */       double yaw = MotionUtil.calcMoveYaw();
/*     */       this.moveSpeed = Math.min(Math.max(this.moveSpeed * ((Double)this.XZBoostLava.getValue()).doubleValue(), 0.05D), ((Double)this.XZLava.getValue()).doubleValue() / 20.0D);
/*     */       moveEvent.setX(-Math.sin(yaw) * this.moveSpeed);
/*     */       moveEvent.setZ(Math.cos(yaw) * this.moveSpeed);
/*     */     } else {
/*     */       stopMotion(moveEvent);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void waterSwim(PlayerMoveEvent moveEvent) {
/*     */     ySwim(moveEvent, ((Double)this.yBoostWater.getValue()).doubleValue(), ((Double)this.upWater.getValue()).doubleValue(), ((Double)this.downWater.getValue()).doubleValue() * 20.0D);
/*     */     boolean jump = mc.player.movementInput.jump;
/*     */     boolean sneak = mc.player.movementInput.sneak;
/*     */     if ((!jump || !sneak) && (jump || sneak)) {
/*     */       TimerUtils.setTimerSpeed(((Double)this.timerVal.getValue()).floatValue());
/*     */     } else {
/*     */       TimerUtils.setTimerSpeed(1.0F);
/*     */     } 
/*     */     if (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F) {
/*     */       double yaw = MotionUtil.calcMoveYaw();
/*     */       double multiplier = applySpeedPotionEffects();
/*     */       this.moveSpeed = Math.min(Math.max(this.moveSpeed * ((Double)this.XZBoostWater.getValue()).doubleValue(), 0.075D), ((Double)this.XZWater.getValue()).doubleValue() / 20.0D);
/*     */       if (mc.player.movementInput.sneak && !mc.player.movementInput.jump) {
/*     */         double downMotion = mc.player.motionY * 0.25D;
/*     */         this.moveSpeed = Math.min(this.moveSpeed, Math.max(this.moveSpeed + downMotion, 0.0D));
/*     */       } 
/*     */       this.moveSpeed *= multiplier;
/*     */       moveEvent.setX(-Math.sin(yaw) * this.moveSpeed);
/*     */       moveEvent.setZ(Math.cos(yaw) * this.moveSpeed);
/*     */     } else {
/*     */       stopMotion(moveEvent);
/*     */     } 
/*     */   }
/*     */   
/*     */   private double applySpeedPotionEffects() {
/*     */     double result = 1.0D;
/*     */     if (mc.player.getActivePotionEffect(MobEffects.SPEED) != null)
/*     */       result += (mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier() + 1.0D) * 0.2D; 
/*     */     if (mc.player.getActivePotionEffect(MobEffects.SLOWNESS) != null)
/*     */       result -= (mc.player.getActivePotionEffect(MobEffects.SLOWNESS).getAmplifier() + 1.0D) * 0.15D; 
/*     */     return result;
/*     */   }
/*     */   
/*     */   private void ySwim(PlayerMoveEvent moveEvent, double vBoost, double upSpeed, double downSpeed) {
/*     */     boolean jump = mc.player.movementInput.jump;
/*     */     boolean sneak = mc.player.movementInput.sneak;
/*     */     this.motionY = Math.pow(0.1D, ((Double)this.jitter.getValue()).doubleValue());
/*     */     if (!jump || !sneak) {
/*     */       if (jump)
/*     */         this.motionY = Math.min(this.motionY + vBoost / 20.0D, upSpeed / 20.0D); 
/*     */       if (sneak)
/*     */         this.motionY = Math.max(this.motionY - vBoost / 20.0D, -downSpeed / 20.0D); 
/*     */     } 
/*     */     moveEvent.setY(this.motionY);
/*     */   }
/*     */   
/*     */   private void stopMotion(PlayerMoveEvent event) {
/*     */     event.setX(0.0D);
/*     */     event.setZ(0.0D);
/*     */     this.moveSpeed = 0.0D;
/*     */   }
/*     */   
/*     */   private void reset() {
/*     */     this.moveSpeed = 0.0D;
/*     */     this.motionY = 0.0D;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\movement\LiquidSpeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
