//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PlayerJoinEvent;
/*     */ import com.lemonclient.api.event.events.PlayerLeaveEvent;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.misc.Timer;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraftforge.event.world.WorldEvent;
/*     */ 
/*     */ 
/*     */ @Declaration(name = "LogoutSpots", category = Category.Render)
/*     */ public class LogoutSpots
/*     */   extends Module
/*     */ {
/*  36 */   IntegerSetting range = registerInteger("Range", 100, 10, 260);
/*  37 */   BooleanSetting disconnectMsg = registerBoolean("Disconnect Msgs", true);
/*  38 */   BooleanSetting reconnectMsg = registerBoolean("Reconnect Msgs", true);
/*  39 */   BooleanSetting nameTag = registerBoolean("NameTag", true);
/*  40 */   IntegerSetting lineWidth = registerInteger("Width", 1, 1, 10);
/*  41 */   ModeSetting renderMode = registerMode("Render", Arrays.asList(new String[] { "Both", "Outline", "Fill", "None" }, ), "Both");
/*  42 */   ColorSetting color = registerColor("Color", new GSColor(255, 0, 0, 255));
/*     */   
/*  44 */   Map<Entity, String> loggedPlayers = new ConcurrentHashMap<>();
/*  45 */   Set<EntityPlayer> worldPlayers = ConcurrentHashMap.newKeySet();
/*  46 */   Timer timer = new Timer();
/*  47 */   Timer timer2 = new Timer();
/*     */   
/*     */   public void onUpdate() {
/*  50 */     mc.world.playerEntities.stream()
/*  51 */       .filter(entityPlayer -> (entityPlayer != mc.player))
/*  52 */       .filter(entityPlayer -> (entityPlayer.getDistance((Entity)mc.player) <= ((Integer)this.range.getValue()).intValue()))
/*  53 */       .forEach(entityPlayer -> this.worldPlayers.add(entityPlayer));
/*     */   }
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/*  57 */     if (mc.player != null && mc.world != null) {
/*  58 */       this.loggedPlayers.forEach(this::startFunction);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onEnable() {
/*  63 */     this.loggedPlayers.clear();
/*  64 */     this.worldPlayers = ConcurrentHashMap.newKeySet();
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  68 */     this.worldPlayers.clear();
/*     */   }
/*     */   
/*     */   private void startFunction(Entity entity, String string) {
/*  72 */     if (entity.getDistance((Entity)mc.player) > ((Integer)this.range.getValue()).intValue()) {
/*     */       return;
/*     */     }
/*     */     
/*  76 */     int posX = (int)entity.posX;
/*  77 */     int posY = (int)entity.posY;
/*  78 */     int posZ = (int)entity.posZ;
/*     */     
/*  80 */     String[] nameTagMessage = new String[2];
/*  81 */     nameTagMessage[0] = entity.getName() + " (" + string + ")";
/*  82 */     nameTagMessage[1] = "(" + posX + "," + posY + "," + posZ + ")";
/*     */     
/*  84 */     GlStateManager.pushMatrix();
/*     */     
/*  86 */     if (((Boolean)this.nameTag.getValue()).booleanValue()) {
/*  87 */       RenderUtil.drawNametag(entity, nameTagMessage, this.color.getValue(), 0);
/*     */     }
/*     */     
/*  90 */     switch ((String)this.renderMode.getValue()) {
/*     */       case "Both":
/*  92 */         RenderUtil.drawBoundingBox(entity.getRenderBoundingBox(), ((Integer)this.lineWidth.getValue()).intValue(), this.color.getValue());
/*  93 */         RenderUtil.drawBox(entity.getRenderBoundingBox(), true, -0.4D, new GSColor(this.color.getValue(), 50), 63);
/*     */         break;
/*     */       
/*     */       case "Outline":
/*  97 */         RenderUtil.drawBoundingBox(entity.getRenderBoundingBox(), ((Integer)this.lineWidth.getValue()).intValue(), this.color.getValue());
/*     */         break;
/*     */       
/*     */       case "Fill":
/* 101 */         RenderUtil.drawBox(entity.getRenderBoundingBox(), true, -0.4D, new GSColor(this.color.getValue(), 50), 63);
/*     */         break;
/*     */     } 
/*     */     
/* 105 */     GlStateManager.popMatrix();
/*     */   }
/*     */   @EventHandler
/* 108 */   private final Listener<PlayerJoinEvent> playerJoinEventListener = new Listener(event -> { if (mc.world != null) this.loggedPlayers.keySet().removeIf(());  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/* 125 */   private final Listener<PlayerLeaveEvent> playerLeaveEventListener = new Listener(event -> { if (mc.world != null) this.worldPlayers.removeIf(());  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/* 146 */   private final Listener<WorldEvent.Unload> unloadListener = new Listener(event -> { this.worldPlayers.clear(); if (mc.player == null || mc.world == null) this.loggedPlayers.clear();  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/* 155 */   private final Listener<WorldEvent.Load> loadListener = new Listener(event -> { this.worldPlayers.clear(); if (mc.player == null || mc.world == null) this.loggedPlayers.clear();  }new java.util.function.Predicate[0]);
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\LogoutSpots.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
