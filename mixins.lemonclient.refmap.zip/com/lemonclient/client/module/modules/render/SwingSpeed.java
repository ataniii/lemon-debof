/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ @Declaration(name = "SwingSpeed", category = Category.Render)
/*    */ public class SwingSpeed
/*    */   extends Module {
/*    */   public static SwingSpeed INSTANCE;
/* 14 */   public IntegerSetting rotate = registerInteger("rotate", 6, 1, 20);
/* 15 */   public IntegerSetting speed = registerInteger("Speed", 6, 1, 50);
/* 16 */   public ModeSetting type = registerMode("Type", Arrays.asList(new String[] { "X", "Y", "Z" }, ), "X");
/*    */   public boolean isPressed = false;
/*    */   
/*    */   public SwingSpeed() {
/* 20 */     INSTANCE = this;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\SwingSpeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */