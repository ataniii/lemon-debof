//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ 
/*    */ @Declaration(name = "ClientTime", category = Category.Render)
/*    */ public class ClientTime extends Module {
/*    */   IntegerSetting time;
/*    */   
/*    */   public ClientTime() {
/* 14 */     this.time = registerInteger("Time", 1000, 0, 24000);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 21 */     this.noTimeUpdates = new Listener(event -> { if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> noTimeUpdates;
/*    */   
/*    */   public void onUpdate() {
/*    */     mc.world.setWorldTime(((Integer)this.time.getValue()).intValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\ClientTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
