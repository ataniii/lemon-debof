/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.event.events.RenderEntityEvent;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ 
/*    */ @Declaration(name = "NoWither", category = Category.Render)
/*    */ public class NoWither extends Module {
/*    */   public NoWither() {
/* 13 */     this.render = new Listener(event -> { if (event.getEntity() instanceof net.minecraft.entity.boss.EntityWither || event.getEntity() instanceof net.minecraft.entity.projectile.EntityWitherSkull) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private final Listener<RenderEntityEvent.Head> render;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\NoWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */