//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "ChorusViewer", category = Category.Render)
/*     */ public class ChorusViewer extends Module {
/*     */   ModeSetting render;
/*     */   
/*     */   public ChorusViewer() {
/*  24 */     this.render = registerMode("Render", Arrays.asList(new String[] { "None", "Rectangle", "Circle" }, ), "None");
/*  25 */     this.life = registerInteger("Life", 300, 0, 1000);
/*  26 */     this.circleRange = registerDouble("Circle Range", 1.0D, 0.0D, 3.0D);
/*  27 */     this.color = registerColor("Color", new GSColor(255, 255, 255, 150), Boolean.valueOf(true));
/*  28 */     this.desyncCircle = registerBoolean("Desync Circle", false);
/*  29 */     this.stepRainbowCircle = registerInteger("Step Rainbow Circle", 1, 1, 100);
/*  30 */     this.increaseHeight = registerBoolean("Increase Height", true);
/*  31 */     this.speedIncrease = registerDouble("Speed Increase", 0.01D, 0.3D, 0.001D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.toRender = new ArrayList<>();
/*     */     
/*  97 */     this.sendListener = new Listener(event -> { if (event.getPacket() instanceof SPacketSoundEffect) { SPacketSoundEffect soundPacket = (SPacketSoundEffect)event.getPacket(); if (soundPacket.getSound() == SoundEvents.ITEM_CHORUS_FRUIT_TELEPORT) this.toRender.add(new renderClass(new Vec3d(soundPacket.getX(), soundPacket.getY(), soundPacket.getZ()), ((Integer)this.life.getValue()).intValue(), (String)this.render.getValue(), this.color.getValue(), ((Double)this.circleRange.getValue()).doubleValue(), ((Boolean)this.desyncCircle.getValue()).booleanValue(), ((Integer)this.stepRainbowCircle.getValue()).intValue(), ((Double)this.circleRange.getValue()).doubleValue(), ((Integer)this.stepRainbowCircle.getValue()).intValue(), ((Boolean)this.increaseHeight.getValue()).booleanValue(), ((Double)this.speedIncrease.getValue()).doubleValue()));  }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   IntegerSetting life;
/*     */   DoubleSetting circleRange;
/*     */   ColorSetting color;
/*     */   BooleanSetting desyncCircle;
/*     */   IntegerSetting stepRainbowCircle;
/*     */   BooleanSetting increaseHeight;
/*     */   DoubleSetting speedIncrease;
/*     */   ArrayList<renderClass> toRender;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> sendListener;
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/* 111 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/* 113 */     for (int i = 0; i < this.toRender.size(); i++) {
/* 114 */       if (((renderClass)this.toRender.get(i)).update()) {
/* 115 */         this.toRender.remove(i);
/* 116 */         i--;
/*     */       } 
/* 118 */     }  this.toRender.forEach(renderClass::render);
/*     */   }
/*     */   
/*     */   static class renderClass {
/*     */     final Vec3d center;
/*     */     long start;
/*     */     final long life;
/*     */     final String mode;
/*     */     final double circleRange;
/*     */     final GSColor color;
/*     */     final boolean desyncCircle;
/*     */     final int stepRainbowCircle;
/*     */     final double range;
/*     */     final int desync;
/*     */     final boolean increaseHeight;
/*     */     final double speedIncrease;
/*     */     double nowHeigth = 0.0D;
/*     */     boolean up = true;
/*     */     
/*     */     public renderClass(Vec3d center, long life, String mode, GSColor color, double circleRange, boolean desyncCircle, int stepRainbowCircle, double range, int desync, boolean increaseHeight, double speedIncrease) {
/*     */       this.center = center;
/*     */       this.increaseHeight = increaseHeight;
/*     */       this.speedIncrease = speedIncrease;
/*     */       this.range = range;
/*     */       this.start = System.currentTimeMillis();
/*     */       this.life = life;
/*     */       this.mode = mode;
/*     */       this.desync = desync;
/*     */       this.circleRange = circleRange;
/*     */       this.color = color;
/*     */       this.desyncCircle = desyncCircle;
/*     */       this.stepRainbowCircle = stepRainbowCircle;
/*     */     }
/*     */     
/*     */     boolean update() {
/*     */       return (System.currentTimeMillis() - this.start > this.life);
/*     */     }
/*     */     
/*     */     void render() {
/*     */       double inc;
/*     */       switch (this.mode) {
/*     */         case "Rectangle":
/*     */           RenderUtil.drawBox(new BlockPos(this.center.x, this.center.y, this.center.z), 1.8D, this.color, 63);
/*     */           break;
/*     */         case "Circle":
/*     */           inc = 0.0D;
/*     */           if (this.increaseHeight) {
/*     */             this.nowHeigth += this.speedIncrease * (this.up ? true : -1);
/*     */             if (this.nowHeigth > 1.8D) {
/*     */               this.up = false;
/*     */             } else if (this.nowHeigth < 0.0D) {
/*     */               this.up = true;
/*     */             } 
/*     */             inc = this.nowHeigth;
/*     */           } 
/*     */           if (this.desyncCircle) {
/*     */             RenderUtil.drawCircle((float)this.center.x, (float)(this.center.y + inc), (float)this.center.z, Double.valueOf(this.range), this.desync, this.color.getAlpha());
/*     */             break;
/*     */           } 
/*     */           RenderUtil.drawCircle((float)this.center.x, (float)(this.center.y + inc), (float)this.center.z, Double.valueOf(this.range), this.color);
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\ChorusViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
