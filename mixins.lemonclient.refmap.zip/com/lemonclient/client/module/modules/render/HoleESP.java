//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ import com.google.common.collect.Sets;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.RotationUtil;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "HoleESP", category = Category.Render)
/*     */ public class HoleESP extends Module {
/*  27 */   public IntegerSetting range = registerInteger("Range", 5, 1, 20);
/*  28 */   IntegerSetting Yrange = registerInteger("Y Range", 5, 1, 20);
/*     */   
/*  30 */   BooleanSetting single = registerBoolean("1x1", true);
/*  31 */   BooleanSetting Double = registerBoolean("2x1", true);
/*  32 */   BooleanSetting fourBlocks = registerBoolean("2x2", true);
/*  33 */   BooleanSetting custom = registerBoolean("Custom", true);
/*  34 */   ModeSetting type = registerMode("Render", Arrays.asList(new String[] { "Outline", "Fill", "Both" }, ), "Both");
/*  35 */   ModeSetting mode = registerMode("Mode", Arrays.asList(new String[] { "Air", "Ground", "Flat", "Slab", "Double" }, ), "Air");
/*  36 */   BooleanSetting hideOwn = registerBoolean("Hide Own", false);
/*  37 */   BooleanSetting flatOwn = registerBoolean("Flat Own", false);
/*  38 */   BooleanSetting fov = registerBoolean("In Fov", false);
/*  39 */   DoubleSetting slabHeight = registerDouble("Slab Height", 0.5D, 0.0D, 2.0D);
/*  40 */   DoubleSetting outslabHeight = registerDouble("Outline Height", 0.5D, 0.0D, 2.0D);
/*  41 */   IntegerSetting width = registerInteger("Width", 1, 1, 10);
/*  42 */   ColorSetting bedrockColor = registerColor("Bedrock Color", new GSColor(0, 255, 0));
/*  43 */   ColorSetting obsidianColor = registerColor("Obsidian Color", new GSColor(255, 0, 0));
/*  44 */   ColorSetting twobedrockColor = registerColor("2x1 Bedrock Color", new GSColor(0, 255, 0));
/*  45 */   ColorSetting twoobsidianColor = registerColor("2x1 Obsidian Color", new GSColor(255, 0, 0));
/*  46 */   ColorSetting fourColor = registerColor("2x2 Color", new GSColor(255, 0, 0));
/*  47 */   ColorSetting customColor = registerColor("Custom Color", new GSColor(0, 0, 255));
/*  48 */   IntegerSetting alpha = registerInteger("Alpha", 50, 0, 255);
/*  49 */   IntegerSetting ufoAlpha = registerInteger("UFOAlpha", 255, 0, 255);
/*     */   
/*     */   private ConcurrentHashMap<AxisAlignedBB, GSColor> holes;
/*     */   
/*     */   public void onUpdate() {
/*  54 */     if (mc.player == null || mc.world == null) {
/*     */       return;
/*     */     }
/*     */     
/*  58 */     if (this.holes == null) {
/*  59 */       this.holes = new ConcurrentHashMap<>();
/*     */     } else {
/*  61 */       this.holes.clear();
/*     */     } 
/*     */     
/*  64 */     HashSet<BlockPos> possibleHoles = Sets.newHashSet();
/*  65 */     List<BlockPos> blockPosList = EntityUtil.getSphere(PlayerUtil.getPlayerPos(), Double.valueOf(((Integer)this.range.getValue()).intValue()), Double.valueOf(((Integer)this.Yrange.getValue()).intValue()), false, false, 0);
/*     */     
/*  67 */     for (BlockPos pos : blockPosList) {
/*     */       
/*  69 */       if (((Boolean)this.fov.getValue()).booleanValue() && !RotationUtil.isInFov(pos)) {
/*     */         continue;
/*     */       }
/*     */       
/*  73 */       if (!mc.world.getBlockState(pos).getBlock().equals(Blocks.AIR)) {
/*     */         continue;
/*     */       }
/*  76 */       if (mc.world.getBlockState(pos.add(0, -1, 0)).getBlock().equals(Blocks.AIR))
/*     */         continue; 
/*  78 */       if (!mc.world.getBlockState(pos.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
/*     */         continue;
/*     */       }
/*  81 */       if (mc.world.getBlockState(pos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
/*  82 */         possibleHoles.add(pos);
/*     */       }
/*     */     } 
/*  85 */     possibleHoles.forEach(pos -> {
/*     */           HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(pos, false, false, true);
/*     */           HoleUtil.HoleType holeType = holeInfo.getType();
/*     */           if (holeType != HoleUtil.HoleType.NONE) {
/*     */             HoleUtil.BlockSafety holeSafety = holeInfo.getSafety();
/*     */             AxisAlignedBB centreBlocks = holeInfo.getCentre();
/*     */             if (centreBlocks == null) {
/*     */               return;
/*     */             }
/*     */             if (((Boolean)this.fourBlocks.getValue()).booleanValue() && holeType == HoleUtil.HoleType.FOUR) {
/*     */               GSColor colour = new GSColor(this.fourColor.getValue(), 255);
/*     */               this.holes.put(centreBlocks, colour);
/*     */             } else if (((Boolean)this.custom.getValue()).booleanValue() && holeType == HoleUtil.HoleType.CUSTOM) {
/*     */               GSColor colour = new GSColor(this.customColor.getValue(), 255);
/*     */               this.holes.put(centreBlocks, colour);
/*     */             } else if (((Boolean)this.Double.getValue()).booleanValue() && holeType == HoleUtil.HoleType.DOUBLE) {
/*     */               GSColor colour;
/*     */               if (holeSafety == HoleUtil.BlockSafety.UNBREAKABLE) {
/*     */                 colour = new GSColor(this.twobedrockColor.getValue(), 255);
/*     */               } else {
/*     */                 colour = new GSColor(this.twoobsidianColor.getValue(), 255);
/*     */               } 
/*     */               this.holes.put(centreBlocks, colour);
/*     */             } else if (((Boolean)this.single.getValue()).booleanValue() && holeType == HoleUtil.HoleType.SINGLE) {
/*     */               GSColor colour;
/*     */               if (holeSafety == HoleUtil.BlockSafety.UNBREAKABLE) {
/*     */                 colour = new GSColor(this.bedrockColor.getValue(), 255);
/*     */               } else {
/*     */                 colour = new GSColor(this.obsidianColor.getValue(), 255);
/*     */               } 
/*     */               this.holes.put(centreBlocks, colour);
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/* 123 */     if (mc.player == null || mc.world == null || this.holes == null || this.holes.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 127 */     this.holes.forEach(this::renderHoles);
/*     */   }
/*     */   
/*     */   private void renderHoles(AxisAlignedBB hole, GSColor color) {
/* 131 */     switch ((String)this.type.getValue()) {
/*     */       case "Outline":
/* 133 */         renderOutline(hole, color);
/*     */         break;
/*     */       
/*     */       case "Fill":
/* 137 */         renderFill(hole, color);
/*     */         break;
/*     */       
/*     */       case "Both":
/* 141 */         renderOutline(hole, color);
/* 142 */         renderFill(hole, color);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderFill(AxisAlignedBB hole, GSColor color) {
/* 149 */     GSColor fillColor = new GSColor(color, ((Integer)this.alpha.getValue()).intValue());
/* 150 */     int ufoAlpha = ((Integer)this.ufoAlpha.getValue()).intValue() * 50 / 255;
/*     */     
/* 152 */     if (((Boolean)this.hideOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox()))
/*     */       return; 
/* 154 */     switch ((String)this.mode.getValue()) {
/*     */       case "Air":
/* 156 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 157 */           RenderUtil.drawBox(hole, true, 1.0D, fillColor, ufoAlpha, 1); break;
/*     */         } 
/* 159 */         RenderUtil.drawBox(hole, true, 1.0D, fillColor, ufoAlpha, 63);
/*     */         break;
/*     */ 
/*     */       
/*     */       case "Ground":
/* 164 */         RenderUtil.drawBox(hole.offset(0.0D, -1.0D, 0.0D), true, 1.0D, new GSColor(fillColor, ufoAlpha), fillColor.getAlpha(), 63);
/*     */         break;
/*     */       
/*     */       case "Flat":
/* 168 */         RenderUtil.drawBox(hole, true, 1.0D, fillColor, ufoAlpha, 1);
/*     */         break;
/*     */       
/*     */       case "Slab":
/* 172 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 173 */           RenderUtil.drawBox(hole, true, 1.0D, fillColor, ufoAlpha, 1); break;
/*     */         } 
/* 175 */         RenderUtil.drawBox(hole, false, ((Double)this.slabHeight.getValue()).doubleValue(), fillColor, ufoAlpha, 63);
/*     */         break;
/*     */ 
/*     */       
/*     */       case "Double":
/* 180 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 181 */           RenderUtil.drawBox(hole, true, 1.0D, fillColor, ufoAlpha, 1); break;
/*     */         } 
/* 183 */         RenderUtil.drawBox(hole.setMaxY(hole.maxY + 1.0D), true, 2.0D, fillColor, ufoAlpha, 63);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderOutline(AxisAlignedBB hole, GSColor color) {
/* 191 */     GSColor outlineColor = new GSColor(color, 255);
/*     */     
/* 193 */     if (((Boolean)this.hideOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox()))
/*     */       return; 
/* 195 */     switch ((String)this.mode.getValue()) {
/*     */       case "Air":
/* 197 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 198 */           RenderUtil.drawBoundingBoxWithSides(hole, ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue(), 1); break;
/*     */         } 
/* 200 */         RenderUtil.drawBoundingBox(hole, ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue());
/*     */         break;
/*     */ 
/*     */       
/*     */       case "Ground":
/* 205 */         RenderUtil.drawBoundingBox(hole.offset(0.0D, -1.0D, 0.0D), ((Integer)this.width.getValue()).intValue(), new GSColor(outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue()), outlineColor.getAlpha());
/*     */         break;
/*     */       
/*     */       case "Flat":
/* 209 */         RenderUtil.drawBoundingBoxWithSides(hole, ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue(), 1);
/*     */         break;
/*     */       
/*     */       case "Slab":
/* 213 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 214 */           RenderUtil.drawBoundingBoxWithSides(hole, ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue(), 1); break;
/*     */         } 
/* 216 */         RenderUtil.drawBoundingBox(hole.setMaxY(hole.minY + ((Double)this.outslabHeight.getValue()).doubleValue()), ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue());
/*     */         break;
/*     */ 
/*     */       
/*     */       case "Double":
/* 221 */         if (((Boolean)this.flatOwn.getValue()).booleanValue() && hole.intersects(mc.player.getEntityBoundingBox())) {
/* 222 */           RenderUtil.drawBoundingBoxWithSides(hole, ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue(), 1); break;
/*     */         } 
/* 224 */         RenderUtil.drawBoundingBox(hole.setMaxY(hole.maxY + 1.0D), ((Integer)this.width.getValue()).intValue(), outlineColor, ((Integer)this.ufoAlpha.getValue()).intValue());
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\HoleESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
