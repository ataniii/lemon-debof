//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.client.renderer.ItemRenderer;
/*    */ 
/*    */ @Declaration(name = "RenderTweaks", category = Category.Render)
/*    */ public class RenderTweaks
/*    */   extends Module {
/* 14 */   public BooleanSetting viewClip = registerBoolean("View Clip", false);
/* 15 */   BooleanSetting nekoAnimation = registerBoolean("Neko Animation", false);
/* 16 */   BooleanSetting lowOffhand = registerBoolean("Low Offhand", false);
/* 17 */   DoubleSetting lowOffhandSlider = registerDouble("Offhand Height", 1.0D, 0.1D, 1.0D);
/* 18 */   BooleanSetting fovChanger = registerBoolean("FOV", false);
/* 19 */   IntegerSetting fovChangerSlider = registerInteger("FOV Slider", 90, 70, 200);
/*    */   
/* 21 */   ItemRenderer itemRenderer = mc.entityRenderer.itemRenderer;
/*    */   
/*    */   private float oldFOV;
/*    */   
/*    */   public void onUpdate() {
/* 26 */     if (((Boolean)this.nekoAnimation.getValue()).booleanValue() && 
/* 27 */       mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemSword && mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9D) {
/* 28 */       mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0F;
/* 29 */       mc.entityRenderer.itemRenderer.itemStackMainHand = mc.player.getHeldItemMainhand();
/*    */     } 
/*    */     
/* 32 */     if (((Boolean)this.lowOffhand.getValue()).booleanValue()) {
/* 33 */       this.itemRenderer.equippedProgressOffHand = ((Double)this.lowOffhandSlider.getValue()).floatValue();
/*    */     }
/* 35 */     if (((Boolean)this.fovChanger.getValue()).booleanValue()) {
/* 36 */       mc.gameSettings.fovSetting = ((Integer)this.fovChangerSlider.getValue()).intValue();
/*    */     }
/* 38 */     if (!((Boolean)this.fovChanger.getValue()).booleanValue()) {
/* 39 */       mc.gameSettings.fovSetting = this.oldFOV;
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEnable() {
/* 44 */     this.oldFOV = mc.gameSettings.fovSetting;
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 48 */     mc.gameSettings.fovSetting = this.oldFOV;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\RenderTweaks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
