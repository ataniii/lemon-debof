//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.render.Interpolation;
/*     */ import com.lemonclient.api.util.render.animation.AnimationMode;
/*     */ import com.lemonclient.api.util.render.animation.TimeAnimation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.DimensionType;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @Declaration(name = "Trails", category = Category.Render)
/*     */ public class Trails extends Module {
/*     */   BooleanSetting arrows;
/*     */   BooleanSetting pearls;
/*     */   BooleanSetting snowballs;
/*     */   IntegerSetting time;
/*     */   ColorSetting color;
/*     */   IntegerSetting alpha;
/*     */   DoubleSetting width;
/*     */   Map<Integer, TimeAnimation> ids;
/*     */   Map<Integer, List<Trace>> traceLists;
/*     */   Map<Integer, Trace> traces;
/*     */   
/*  33 */   public Trails() { this.arrows = registerBoolean("Arrows", false);
/*  34 */     this.pearls = registerBoolean("Pearls", false);
/*  35 */     this.snowballs = registerBoolean("Snowballs", false);
/*  36 */     this.time = registerInteger("Time", 1, 1, 10);
/*  37 */     this.color = registerColor("Color", new GSColor(255, 0, 0, 255));
/*  38 */     this.alpha = registerInteger("Alpha", 255, 1, 255);
/*  39 */     this.width = registerDouble("Width", 1.600000023841858D, 0.10000000149011612D, 10.0D);
/*     */     
/*  41 */     this.ids = new ConcurrentHashMap<>();
/*  42 */     this.traceLists = new ConcurrentHashMap<>();
/*  43 */     this.traces = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.receiveListener = new Listener(event -> { if (mc.world == null) return;  if (event.getPacket() instanceof SPacketSpawnObject) { SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket(); if ((((Boolean)this.pearls.getValue()).booleanValue() && packet.getType() == 65) || (((Boolean)this.arrows.getValue()).booleanValue() && packet.getType() == 60) || (((Boolean)this.snowballs.getValue()).booleanValue() && packet.getType() == 61)) { TimeAnimation animation = new TimeAnimation((((Integer)this.time.getValue()).intValue() * 1000), 0.0D, ((Integer)this.alpha.getValue()).intValue(), false, AnimationMode.LINEAR); animation.stop(); this.ids.put(Integer.valueOf(packet.getEntityID()), animation); this.traceLists.put(Integer.valueOf(packet.getEntityID()), new ArrayList<>()); this.traces.put(Integer.valueOf(packet.getEntityID()), new Trace(0, null, mc.world.provider.getDimensionType(), new Vec3d(packet.getX(), packet.getY(), packet.getZ()), new ArrayList<>())); }  }  if (event.getPacket() instanceof SPacketDestroyEntities) for (int id : ((SPacketDestroyEntities)event.getPacket()).getEntityIDs()) { if (this.ids.containsKey(Integer.valueOf(id))) ((TimeAnimation)this.ids.get(Integer.valueOf(id))).play();  }   }new java.util.function.Predicate[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Vec3d ORIGIN = new Vec3d(8.0D, 64.0D, 8.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/* 142 */     for (Map.Entry<Integer, List<Trace>> entry : this.traceLists.entrySet())
/* 143 */     { GL11.glLineWidth(((Double)this.width.getValue()).floatValue());
/* 144 */       TimeAnimation animation = this.ids.get(entry.getKey());
/* 145 */       animation.add();
/* 146 */       GL11.glColor4f(this.color.getColor().getRed(), this.color
/* 147 */           .getColor().getGreen(), this.color
/* 148 */           .getColor().getBlue(), 
/* 149 */           MathHelper.clamp((float)(((Integer)this.alpha.getValue()).intValue() - animation.getCurrent() / 255.0D), 0.0F, 255.0F));
/*     */       
/* 151 */       ((List)entry.getValue()).forEach(trace -> {
/*     */             GL11.glBegin(3);
/*     */             
/*     */             trace.getTrace().forEach(this::renderVec);
/*     */             
/*     */             GL11.glEnd();
/*     */           });
/* 158 */       GL11.glColor4f(this.color.getColor().getRed(), this.color
/* 159 */           .getColor().getGreen(), this.color
/* 160 */           .getColor().getBlue(), 
/* 161 */           MathHelper.clamp((float)(((Integer)this.alpha.getValue()).intValue() - animation.getCurrent() / 255.0D), 0.0F, 255.0F));
/*     */       
/* 163 */       GL11.glBegin(3);
/* 164 */       Trace trace = this.traces.get(entry.getKey());
/* 165 */       if (trace != null) {
/* 166 */         trace.getTrace().forEach(this::renderVec);
/*     */       }
/* 168 */       GL11.glEnd(); } 
/*     */   } @EventHandler private final Listener<PacketEvent.Receive> receiveListener; public void onTick() { if (mc.world == null) return;  if (this.ids.keySet().isEmpty()) return;  for (Integer id : this.ids.keySet()) { if (id == null) continue;  if (mc.world.loadedEntityList == null)
/*     */         return;  if (mc.world.loadedEntityList.isEmpty())
/*     */         return;  Trace idTrace = this.traces.get(id); Entity entity = mc.world.getEntityByID(id.intValue()); if (entity != null) { Vec3d vec = entity.getPositionVector(); if (vec.equals(ORIGIN))
/*     */           continue;  if (!this.traces.containsKey(id) || idTrace == null) { this.traces.put(id, new Trace(0, null, mc.world.provider.getDimensionType(), vec, new ArrayList<>())); idTrace = this.traces.get(id); }  List<Trace.TracePos> trace = idTrace.getTrace(); Vec3d vec3d = trace.isEmpty() ? vec : ((Trace.TracePos)trace.get(trace.size() - 1)).getPos(); if (!trace.isEmpty() && (vec.distanceTo(vec3d) > 100.0D || idTrace.getType() != mc.world.provider.getDimensionType())) { ((List<Trace>)this.traceLists.get(id)).add(idTrace); trace = new ArrayList<>(); this.traces.put(id, new Trace(((List)this.traceLists.get(id)).size() + 1, null, mc.world.provider.getDimensionType(), vec, new ArrayList<>())); }  if (trace.isEmpty() || !vec.equals(vec3d))
/*     */           trace.add(new Trace.TracePos(vec));  }  TimeAnimation animation = this.ids.get(id); if (entity instanceof net.minecraft.entity.projectile.EntityArrow && (entity.onGround || entity.collided || !entity.isAirBorne))
/* 174 */         animation.play();  if (animation != null && ((Integer)this.alpha.getValue()).intValue() - animation.getCurrent() <= 0.0D) { animation.stop(); this.ids.remove(id); this.traceLists.remove(id); this.traces.remove(id); }  }  } private void renderVec(Trace.TracePos tracePos) { double x = (tracePos.getPos()).x - Interpolation.getRenderPosX();
/* 175 */     double y = (tracePos.getPos()).y - Interpolation.getRenderPosY();
/* 176 */     double z = (tracePos.getPos()).z - Interpolation.getRenderPosZ();
/* 177 */     GL11.glVertex3d(x, y, z); }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Trace
/*     */   {
/*     */     private String name;
/*     */     
/*     */     private int index;
/*     */     
/*     */     private Vec3d pos;
/*     */     
/*     */     private final List<TracePos> trace;
/*     */     private DimensionType type;
/*     */     
/*     */     public Trace(int index, String name, DimensionType type, Vec3d pos, List<TracePos> trace) {
/* 193 */       this.index = index;
/* 194 */       this.name = name;
/* 195 */       this.type = type;
/* 196 */       this.pos = pos;
/* 197 */       this.trace = trace;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIndex() {
/* 202 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public DimensionType getType() {
/* 207 */       return this.type;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<TracePos> getTrace() {
/* 212 */       return this.trace;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 217 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setName(String name) {
/* 222 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPos(Vec3d pos) {
/* 227 */       this.pos = pos;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setIndex(int index) {
/* 232 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vec3d getPos() {
/* 237 */       return this.pos;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setType(DimensionType type) {
/* 242 */       this.type = type;
/*     */     }
/*     */     
/*     */     public static class TracePos {
/*     */       private final Vec3d pos;
/*     */       
/*     */       public TracePos(Vec3d pos) {
/* 249 */         this.pos = pos;
/*     */       }
/*     */       
/*     */       public Vec3d getPos() {
/* 253 */         return this.pos; } } } public static class TracePos { private final Vec3d pos; public TracePos(Vec3d pos) { this.pos = pos; } public Vec3d getPos() { return this.pos; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\Trails.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
