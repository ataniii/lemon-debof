//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.font.FontUtil;
/*     */ import com.lemonclient.api.util.misc.ColorUtil;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.client.manager.managers.TotemPopManager;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @Declaration(name = "Nametag", category = Category.Render)
/*     */ public class Nametag extends Module {
/*  38 */   IntegerSetting range = registerInteger("Range", 100, 10, 260);
/*  39 */   BooleanSetting scale = registerBoolean("Scale", true);
/*  40 */   BooleanSetting smartScale = registerBoolean("Smart Scale", true);
/*  41 */   DoubleSetting size = registerDouble("Scale", 0.5D, 0.01D, 15.0D);
/*  42 */   DoubleSetting factor = registerDouble("Factor", 0.5D, 0.01D, 1.0D);
/*  43 */   BooleanSetting renderSelf = registerBoolean("Render Self", false);
/*  44 */   BooleanSetting reverse = registerBoolean("Reverse", true);
/*  45 */   BooleanSetting showDurability = registerBoolean("Durability", true);
/*  46 */   BooleanSetting showItems = registerBoolean("Items", true);
/*  47 */   BooleanSetting showEnchantName = registerBoolean("Enchants", true);
/*  48 */   ModeSetting levelColor = registerMode("Level Color", ColorUtil.colors, "Green", () -> (Boolean)this.showEnchantName.getValue());
/*  49 */   BooleanSetting showItemName = registerBoolean("Item Name", false);
/*  50 */   BooleanSetting showGameMode = registerBoolean("Gamemode", false);
/*  51 */   BooleanSetting showHealth = registerBoolean("Health", true);
/*  52 */   BooleanSetting showPing = registerBoolean("Ping", false);
/*  53 */   BooleanSetting showTotem = registerBoolean("Totem Pops", true);
/*  54 */   BooleanSetting showEntityID = registerBoolean("Entity Id", false);
/*  55 */   BooleanSetting border = registerBoolean("Border", false);
/*  56 */   ColorSetting borderColor = registerColor("Border Color", new GSColor(255, 0, 0, 255), () -> (Boolean)this.border.getValue());
/*  57 */   BooleanSetting outline = registerBoolean("Outline", false);
/*  58 */   ColorSetting outlineColor = registerColor("Border Color", new GSColor(255, 0, 0, 255), () -> (Boolean)this.outline.getValue());
/*     */   public void onWorldRender(RenderEvent event) {
/*  60 */     if (mc.player == null || mc.world == null) {
/*     */       return;
/*     */     }
/*     */     
/*  64 */     mc.world.playerEntities.stream().filter(this::shouldRender).forEach(entityPlayer -> {
/*     */           Vec3d vec3d = findEntityVec3d(entityPlayer);
/*     */           renderNameTag(entityPlayer, vec3d.x, vec3d.y, vec3d.z);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean shouldRender(EntityPlayer entityPlayer) {
/*  72 */     if (entityPlayer == mc.player && !((Boolean)this.renderSelf.getValue()).booleanValue()) {
/*  73 */       EntityPlayerSP entityPlayerSP; Entity player = mc.getRenderViewEntity();
/*  74 */       if (player == null) entityPlayerSP = mc.player; 
/*  75 */       if (entityPlayerSP == mc.player) return false;
/*     */     
/*     */     } 
/*  78 */     if (entityPlayer.getName().length() == 0) return false;
/*     */     
/*  80 */     if (entityPlayer.isDead || entityPlayer.getHealth() <= 0.0F) return false;
/*     */     
/*  82 */     return (entityPlayer.getDistance((Entity)mc.player) <= ((Integer)this.range.getValue()).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getDistance(double x, double y, double z) {
/*     */     EntityPlayerSP entityPlayerSP;
/*  88 */     Entity viewEntity = mc.getRenderViewEntity();
/*     */     
/*  90 */     if (viewEntity == null) entityPlayerSP = mc.player; 
/*  91 */     double d0 = ((Entity)entityPlayerSP).posX - x;
/*  92 */     double d1 = ((Entity)entityPlayerSP).posY - y;
/*  93 */     double d2 = ((Entity)entityPlayerSP).posZ - z;
/*  94 */     return MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderNameTag(EntityPlayer player, double x, double y, double z) {
/*  99 */     double tempY = y;
/* 100 */     tempY += player.isSneaking() ? 0.5D : 0.7D;
/* 101 */     String displayTag = buildEntityNameString(player);
/* 102 */     double distance = getDistance(x, y, z);
/* 103 */     int width = FontUtil.getStringWidth(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), displayTag) / 2;
/* 104 */     double scale = (0.0018D + ((Double)this.size.getValue()).doubleValue() * distance * ((Double)this.factor.getValue()).doubleValue()) / 1000.0D;
/* 105 */     if (distance <= 6.0D && ((Boolean)this.smartScale.getValue()).booleanValue()) {
/* 106 */       scale = (0.0018D + (((Double)this.size.getValue()).doubleValue() + 2.0D) * distance * ((Double)this.factor.getValue()).doubleValue()) / 1000.0D;
/*     */     }
/* 108 */     if (distance <= 4.0D && ((Boolean)this.smartScale.getValue()).booleanValue()) {
/* 109 */       scale = (0.0018D + (((Double)this.size.getValue()).doubleValue() + 4.0D) * distance * ((Double)this.factor.getValue()).doubleValue()) / 1000.0D;
/*     */     }
/* 111 */     if (!((Boolean)this.scale.getValue()).booleanValue()) {
/* 112 */       scale = ((Double)this.size.getValue()).doubleValue() / 100.0D;
/*     */     }
/* 114 */     GlStateManager.pushMatrix();
/* 115 */     RenderHelper.enableStandardItemLighting();
/* 116 */     GlStateManager.enablePolygonOffset();
/* 117 */     GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
/* 118 */     GlStateManager.disableLighting();
/* 119 */     GlStateManager.translate((float)x, (float)tempY + 1.4F, (float)z);
/* 120 */     GlStateManager.rotate(-(mc.getRenderManager()).playerViewY, 0.0F, 1.0F, 0.0F);
/* 121 */     GlStateManager.rotate((mc.getRenderManager()).playerViewX, (mc.gameSettings.thirdPersonView == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/* 122 */     GlStateManager.scale(-scale, -scale, scale);
/* 123 */     GlStateManager.disableDepth();
/* 124 */     GlStateManager.enableBlend();
/* 125 */     GlStateManager.enableBlend();
/* 126 */     if (((Boolean)this.border.getValue()).booleanValue()) {
/* 127 */       drawRect((-width - 2), -(FontUtil.getFontHeight(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue()) + 1), width + 2.0F, 1.5F, this.borderColor.getColor().getRGB());
/*     */     }
/* 129 */     else if (!((Boolean)this.outline.getValue()).booleanValue()) {
/* 130 */       drawRect(0.0F, 0.0F, 0.0F, 0.0F, this.borderColor.getColor().getRGB());
/*     */     } 
/* 132 */     if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 133 */       drawOutlineRect((-width - 2), -(FontUtil.getFontHeight(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue()) + 1), width + 2.0F, 1.5F, this.outlineColor.getColor().getRGB());
/*     */     }
/* 135 */     GlStateManager.disableBlend();
/* 136 */     ItemStack renderMainHand = player.getHeldItemMainhand().copy();
/* 137 */     if (renderMainHand.hasEffect() && (renderMainHand.getItem() instanceof net.minecraft.item.ItemTool || renderMainHand.getItem() instanceof net.minecraft.item.ItemArmor)) {
/* 138 */       renderMainHand.stackSize = 1;
/*     */     }
/* 140 */     if (((Boolean)this.showItemName.getValue()).booleanValue() && !renderMainHand.isEmpty && renderMainHand.getItem() != Items.AIR) {
/* 141 */       String stackName = renderMainHand.getDisplayName();
/* 142 */       int stackNameWidth = FontUtil.getStringWidth(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), stackName) / 2;
/* 143 */       GL11.glPushMatrix();
/* 144 */       GL11.glScalef(0.75F, 0.75F, 0.0F);
/* 145 */       FontUtil.drawStringWithShadow(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), stackName, -stackNameWidth, (int)-(getBiggestArmorTag(player) + 20.0F), new GSColor(255, 255, 255));
/* 146 */       GL11.glScalef(1.5F, 1.5F, 1.0F);
/* 147 */       GL11.glPopMatrix();
/*     */     } 
/* 149 */     if (((Boolean)this.showItems.getValue()).booleanValue()) {
/* 150 */       GlStateManager.pushMatrix();
/* 151 */       int xOffset = -6;
/* 152 */       for (ItemStack armourStack : player.inventory.armorInventory) {
/* 153 */         if (armourStack == null) {
/*     */           continue;
/*     */         }
/* 156 */         xOffset -= 8;
/*     */       } 
/* 158 */       xOffset -= 8;
/* 159 */       ItemStack renderOffhand = player.getHeldItemOffhand().copy();
/* 160 */       if (renderOffhand.hasEffect() && (renderOffhand.getItem() instanceof net.minecraft.item.ItemTool || renderOffhand.getItem() instanceof net.minecraft.item.ItemArmor)) {
/* 161 */         renderOffhand.stackSize = 1;
/*     */       }
/* 163 */       renderItemStack(renderOffhand, xOffset);
/* 164 */       xOffset += 16;
/* 165 */       if (((Boolean)this.reverse.getValue()).booleanValue()) {
/* 166 */         for (int index = 0; index <= 3; index++) {
/* 167 */           ItemStack armourStack2 = (ItemStack)player.inventory.armorInventory.get(index);
/* 168 */           if (armourStack2.getItem() != Items.AIR) {
/* 169 */             armourStack2.copy();
/* 170 */             renderItemStack(armourStack2, xOffset);
/* 171 */             xOffset += 16;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 175 */         for (int index = 3; index >= 0; index--) {
/* 176 */           ItemStack armourStack2 = (ItemStack)player.inventory.armorInventory.get(index);
/* 177 */           if (armourStack2.getItem() != Items.AIR) {
/* 178 */             armourStack2.copy();
/* 179 */             renderItemStack(armourStack2, xOffset);
/* 180 */             xOffset += 16;
/*     */           } 
/*     */         } 
/*     */       } 
/* 184 */       renderItemStack(renderMainHand, xOffset);
/* 185 */       GlStateManager.popMatrix();
/*     */     } 
/* 187 */     FontUtil.drawStringWithShadow(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), displayTag, -width, -(FontUtil.getFontHeight(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue()) - 1), findTextColor(player));
/* 188 */     GlStateManager.enableDepth();
/* 189 */     GlStateManager.disableBlend();
/* 190 */     GlStateManager.disablePolygonOffset();
/* 191 */     GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
/* 192 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   private void renderItemStack(ItemStack stack, int x) {
/* 196 */     GlStateManager.pushMatrix();
/* 197 */     GlStateManager.depthMask(true);
/* 198 */     GlStateManager.clear(256);
/* 199 */     RenderHelper.enableStandardItemLighting();
/* 200 */     (mc.getRenderItem()).zLevel = -150.0F;
/* 201 */     GlStateManager.disableAlpha();
/* 202 */     GlStateManager.enableDepth();
/* 203 */     GlStateManager.disableCull();
/* 204 */     mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, -26);
/* 205 */     mc.getRenderItem().renderItemOverlays(mc.fontRenderer, stack, x, -26);
/* 206 */     (mc.getRenderItem()).zLevel = 0.0F;
/* 207 */     RenderHelper.disableStandardItemLighting();
/* 208 */     GlStateManager.enableCull();
/* 209 */     GlStateManager.enableAlpha();
/* 210 */     GlStateManager.scale(0.5F, 0.5F, 0.5F);
/* 211 */     GlStateManager.disableDepth();
/* 212 */     renderEnchantmentText(stack, x);
/* 213 */     GlStateManager.enableDepth();
/* 214 */     GlStateManager.scale(2.0F, 2.0F, 2.0F);
/* 215 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   private void renderEnchantmentText(ItemStack stack, int x) {
/* 219 */     int enchantmentY = -34;
/* 220 */     if (stack.getItem() == Items.GOLDEN_APPLE && stack.hasEffect()) {
/* 221 */       FontUtil.drawStringWithShadow(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), "god", (x * 2), enchantmentY, new GSColor(195, 77, 65));
/* 222 */       enchantmentY -= 8;
/*     */     } 
/* 224 */     NBTTagList enchants = stack.getEnchantmentTagList();
/* 225 */     for (int index = 0; index < enchants.tagCount(); index++) {
/* 226 */       short id = enchants.getCompoundTagAt(index).getShort("id");
/* 227 */       short level = enchants.getCompoundTagAt(index).getShort("lvl");
/* 228 */       Enchantment enc = Enchantment.getEnchantmentByID(id);
/* 229 */       if (enc != null) {
/* 230 */         String encName = enc.isCurse() ? (TextFormatting.RED + enc.getTranslatedName(level).substring(0, 4).toLowerCase()) : (ColorUtil.settingToTextFormatting(this.levelColor) + enc.getTranslatedName(level).substring(0, 2).toLowerCase());
/* 231 */         encName = encName + level;
/* 232 */         FontUtil.drawStringWithShadow(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), encName, (x * 2), enchantmentY, new GSColor(255, 255, 255));
/* 233 */         enchantmentY -= 8;
/*     */       } 
/*     */     } 
/*     */     
/* 237 */     if (((Boolean)this.showDurability.getValue()).booleanValue() && stack.isItemStackDamageable()) {
/* 238 */       float damagePercent = (stack.getMaxDamage() - stack.getItemDamage()) / stack.getMaxDamage();
/*     */       
/* 240 */       float green = damagePercent;
/* 241 */       if (green > 1.0F) { green = 1.0F; }
/* 242 */       else if (green < 0.0F) { green = 0.0F; }
/*     */       
/* 244 */       float red = 1.0F - green;
/* 245 */       FontUtil.drawStringWithShadow(((Boolean)ColorMain.INSTANCE.customFont.getValue()).booleanValue(), (int)(damagePercent * 100.0F) + "%", (x * 2), enchantmentY, new GSColor((int)(red * 255.0F), (int)(green * 255.0F), 0));
/*     */     } 
/*     */   }
/*     */   
/*     */   private float getBiggestArmorTag(EntityPlayer player) {
/* 250 */     float enchantmentY = 0.0F;
/* 251 */     boolean arm = false;
/* 252 */     for (ItemStack stack : player.inventory.armorInventory) {
/* 253 */       float encY = 0.0F;
/* 254 */       if (stack != null) {
/* 255 */         NBTTagList enchants = stack.getEnchantmentTagList();
/* 256 */         for (int index = 0; index < enchants.tagCount(); index++) {
/* 257 */           short id = enchants.getCompoundTagAt(index).getShort("id");
/* 258 */           Enchantment enc = Enchantment.getEnchantmentByID(id);
/* 259 */           if (enc != null) {
/* 260 */             encY += 8.0F;
/* 261 */             arm = true;
/*     */           } 
/*     */         } 
/*     */       } 
/* 265 */       if (encY <= enchantmentY) {
/*     */         continue;
/*     */       }
/* 268 */       enchantmentY = encY;
/*     */     } 
/* 270 */     ItemStack renderMainHand = player.getHeldItemMainhand().copy();
/* 271 */     if (renderMainHand.hasEffect()) {
/* 272 */       float encY2 = 0.0F;
/* 273 */       NBTTagList enchants2 = renderMainHand.getEnchantmentTagList();
/* 274 */       for (int index2 = 0; index2 < enchants2.tagCount(); index2++) {
/* 275 */         short id = enchants2.getCompoundTagAt(index2).getShort("id");
/* 276 */         Enchantment enc2 = Enchantment.getEnchantmentByID(id);
/* 277 */         if (enc2 != null) {
/* 278 */           encY2 += 8.0F;
/* 279 */           arm = true;
/*     */         } 
/*     */       } 
/* 282 */       if (encY2 > enchantmentY) {
/* 283 */         enchantmentY = encY2;
/*     */       }
/*     */     } 
/*     */     ItemStack renderOffHand;
/* 287 */     if ((renderOffHand = player.getHeldItemOffhand().copy()).hasEffect()) {
/* 288 */       float encY2 = 0.0F;
/* 289 */       NBTTagList enchants2 = renderOffHand.getEnchantmentTagList();
/* 290 */       for (int index = 0; index < enchants2.tagCount(); index++) {
/* 291 */         short id2 = enchants2.getCompoundTagAt(index).getShort("id");
/* 292 */         Enchantment enc = Enchantment.getEnchantmentByID(id2);
/* 293 */         if (enc != null) {
/* 294 */           encY2 += 8.0F;
/* 295 */           arm = true;
/*     */         } 
/*     */       } 
/* 298 */       if (encY2 > enchantmentY) {
/* 299 */         enchantmentY = encY2;
/*     */       }
/*     */     } 
/* 302 */     return (arm ? false : 20) + enchantmentY;
/*     */   }
/*     */   
/*     */   private Vec3d findEntityVec3d(EntityPlayer entityPlayer) {
/* 306 */     double posX = balancePosition(entityPlayer.posX, entityPlayer.lastTickPosX);
/* 307 */     double posY = balancePosition(entityPlayer.posY, entityPlayer.lastTickPosY);
/* 308 */     double posZ = balancePosition(entityPlayer.posZ, entityPlayer.lastTickPosZ);
/*     */     
/* 310 */     return new Vec3d(posX, posY, posZ);
/*     */   }
/*     */   
/*     */   private double balancePosition(double newPosition, double oldPosition) {
/* 314 */     return oldPosition + (newPosition - oldPosition) * mc.timer.renderPartialTicks;
/*     */   }
/*     */   
/*     */   private String buildEntityNameString(EntityPlayer entityPlayer) {
/* 318 */     String name = entityPlayer.getName();
/*     */     
/* 320 */     if (((Boolean)this.showEntityID.getValue()).booleanValue()) {
/* 321 */       name = name + " ID: " + entityPlayer.getEntityId();
/*     */     }
/*     */     
/* 324 */     if (((Boolean)this.showGameMode.getValue()).booleanValue()) {
/* 325 */       if (entityPlayer.isCreative()) {
/* 326 */         name = name + " [C]";
/* 327 */       } else if (entityPlayer.isSpectator()) {
/* 328 */         name = name + " [I]";
/*     */       } else {
/* 330 */         name = name + " [S]";
/*     */       } 
/*     */     }
/*     */     
/* 334 */     if (((Boolean)this.showTotem.getValue()).booleanValue()) {
/* 335 */       name = name + " [" + TotemPopManager.INSTANCE.getPlayerPopCount(entityPlayer.getName()) + "]";
/*     */     }
/*     */     
/* 338 */     if (((Boolean)this.showPing.getValue()).booleanValue()) {
/* 339 */       int value = 0;
/*     */       
/* 341 */       if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()) != null) {
/* 342 */         value = mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()).getResponseTime();
/*     */       }
/*     */       
/* 345 */       name = name + " " + value + "ms";
/*     */     } 
/*     */     
/* 348 */     if (((Boolean)this.showHealth.getValue()).booleanValue()) {
/* 349 */       int health = (int)(entityPlayer.getHealth() + entityPlayer.getAbsorptionAmount());
/* 350 */       TextFormatting textFormatting = findHealthColor(health);
/*     */       
/* 352 */       name = name + " " + textFormatting + health;
/*     */     } 
/*     */     
/* 355 */     return name;
/*     */   }
/*     */   
/*     */   private GSColor findTextColor(EntityPlayer entityPlayer) {
/* 359 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 360 */     if (SocialManager.isFriend(entityPlayer.getName()))
/* 361 */       return colorMain.getFriendGSColor(); 
/* 362 */     if (SocialManager.isEnemy(entityPlayer.getName()))
/* 363 */       return colorMain.getEnemyGSColor(); 
/* 364 */     if (entityPlayer.isInvisible())
/* 365 */       return new GSColor(128, 128, 128); 
/* 366 */     if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()) == null)
/* 367 */       return new GSColor(239, 1, 71); 
/* 368 */     if (entityPlayer.isSneaking()) {
/* 369 */       return new GSColor(255, 153, 0);
/*     */     }
/*     */     
/* 372 */     return new GSColor(255, 255, 255);
/*     */   }
/*     */ 
/*     */   
/*     */   private TextFormatting findHealthColor(int health) {
/* 377 */     if (health <= 0)
/* 378 */       return TextFormatting.DARK_RED; 
/* 379 */     if (health <= 5)
/* 380 */       return TextFormatting.RED; 
/* 381 */     if (health <= 10)
/* 382 */       return TextFormatting.GOLD; 
/* 383 */     if (health <= 15)
/* 384 */       return TextFormatting.YELLOW; 
/* 385 */     if (health <= 20) {
/* 386 */       return TextFormatting.DARK_GREEN;
/*     */     }
/*     */     
/* 389 */     return TextFormatting.GREEN;
/*     */   }
/*     */   
/*     */   public void drawOutlineRect(float x, float y, float w, float h, int color) {
/* 393 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/* 394 */     float red = (color >> 16 & 0xFF) / 255.0F;
/* 395 */     float green = (color >> 8 & 0xFF) / 255.0F;
/* 396 */     float blue = (color & 0xFF) / 255.0F;
/* 397 */     Tessellator tessellator = Tessellator.getInstance();
/* 398 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 399 */     GlStateManager.enableBlend();
/* 400 */     GlStateManager.disableTexture2D();
/* 401 */     GlStateManager.glLineWidth(1.0F);
/* 402 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 403 */     bufferbuilder.begin(2, DefaultVertexFormats.POSITION_COLOR);
/* 404 */     bufferbuilder.pos(x, h, 0.0D).color(red, green, blue, alpha).endVertex();
/* 405 */     bufferbuilder.pos(w, h, 0.0D).color(red, green, blue, alpha).endVertex();
/* 406 */     bufferbuilder.pos(w, y, 0.0D).color(red, green, blue, alpha).endVertex();
/* 407 */     bufferbuilder.pos(x, y, 0.0D).color(red, green, blue, alpha).endVertex();
/* 408 */     tessellator.draw();
/* 409 */     GlStateManager.enableTexture2D();
/* 410 */     GlStateManager.disableBlend();
/*     */   }
/*     */   
/*     */   public void drawRect(float x, float y, float w, float h, int color) {
/* 414 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/* 415 */     float red = (color >> 16 & 0xFF) / 255.0F;
/* 416 */     float green = (color >> 8 & 0xFF) / 255.0F;
/* 417 */     float blue = (color & 0xFF) / 255.0F;
/* 418 */     Tessellator tessellator = Tessellator.getInstance();
/* 419 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/* 420 */     GlStateManager.enableBlend();
/* 421 */     GlStateManager.disableTexture2D();
/* 422 */     GlStateManager.glLineWidth(1.0F);
/* 423 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/* 424 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/* 425 */     bufferbuilder.pos(x, h, 0.0D).color(red, green, blue, alpha).endVertex();
/* 426 */     bufferbuilder.pos(w, h, 0.0D).color(red, green, blue, alpha).endVertex();
/* 427 */     bufferbuilder.pos(w, y, 0.0D).color(red, green, blue, alpha).endVertex();
/* 428 */     bufferbuilder.pos(x, y, 0.0D).color(red, green, blue, alpha).endVertex();
/* 429 */     tessellator.draw();
/* 430 */     GlStateManager.enableTexture2D();
/* 431 */     GlStateManager.disableBlend();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\Nametag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
