//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.event.events.RenderEvent;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.api.util.render.RenderUtil;
/*    */ import com.lemonclient.api.util.world.BlockUtil;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.List;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "ShulkerESP", category = Category.Render)
/*    */ public class ShulkerESP
/*    */   extends Module {
/* 21 */   IntegerSetting range = registerInteger("Range", 24, 0, 256);
/* 22 */   ColorSetting color = registerColor("Color", new GSColor(255, 255, 255));
/* 23 */   IntegerSetting alpha = registerInteger("Alpha", 75, 0, 255);
/* 24 */   IntegerSetting outlineAlpha = registerInteger("Outline Alpha", 125, 0, 255);
/*    */   
/*    */   public void onWorldRender(RenderEvent event) {
/* 27 */     List<BlockPos> storage = EntityUtil.getSphere(PlayerUtil.getPlayerPos(), Double.valueOf(((Integer)this.range.getValue()).doubleValue()), Double.valueOf(((Integer)this.range.getValue()).doubleValue()), false, false, 0);
/* 28 */     storage.removeIf(p -> (!(BlockUtil.getBlock(p) instanceof net.minecraft.block.BlockShulkerBox) || mc.player.getDistance(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D) > ((Integer)this.range.getValue()).intValue()));
/* 29 */     for (BlockPos pos : storage) {
/* 30 */       RenderUtil.drawBox(pos, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/* 31 */       RenderUtil.drawBoundingBox(new AxisAlignedBB(pos), 1.0D, new GSColor(this.color.getValue(), ((Integer)this.outlineAlpha.getValue()).intValue()), ((Integer)this.outlineAlpha.getValue()).intValue());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\ShulkerESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
