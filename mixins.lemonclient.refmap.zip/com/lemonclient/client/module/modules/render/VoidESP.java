//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import io.netty.util.internal.ConcurrentSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "VoidESP", category = Category.Render)
/*     */ public class VoidESP
/*     */   extends Module {
/*  23 */   IntegerSetting renderDistance = registerInteger("Distance", 10, 1, 40);
/*  24 */   IntegerSetting activeYValue = registerInteger("Activate Y", 20, 0, 256);
/*  25 */   ModeSetting renderType = registerMode("Render", Arrays.asList(new String[] { "Outline", "Fill", "Both" }, ), "Both");
/*  26 */   ModeSetting renderMode = registerMode("Mode", Arrays.asList(new String[] { "Box", "Flat" }, ), "Flat");
/*  27 */   IntegerSetting width = registerInteger("Width", 1, 1, 10);
/*  28 */   ColorSetting color = registerColor("Color", new GSColor(255, 255, 0));
/*     */   
/*     */   private ConcurrentSet<BlockPos> voidHoles;
/*     */   
/*     */   public void onUpdate() {
/*  33 */     if (mc.player.dimension == 1) {
/*     */       return;
/*     */     }
/*  36 */     if (mc.player.getPosition().getY() > ((Integer)this.activeYValue.getValue()).intValue()) {
/*     */       return;
/*     */     }
/*  39 */     if (this.voidHoles == null) {
/*  40 */       this.voidHoles = new ConcurrentSet();
/*     */     } else {
/*  42 */       this.voidHoles.clear();
/*     */     } 
/*     */     
/*  45 */     List<BlockPos> blockPosList = BlockUtil.getCircle(getPlayerPos(), 0, ((Integer)this.renderDistance.getValue()).intValue(), false);
/*     */     
/*  47 */     for (BlockPos blockPos : blockPosList) {
/*  48 */       if (mc.world.getBlockState(blockPos).getBlock().equals(Blocks.BEDROCK)) {
/*     */         continue;
/*     */       }
/*  51 */       if (isAnyBedrock(blockPos, Offsets.center)) {
/*     */         continue;
/*     */       }
/*  54 */       this.voidHoles.add(blockPos);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/*  59 */     if (mc.player == null || this.voidHoles == null) {
/*     */       return;
/*     */     }
/*  62 */     if (mc.player.getPosition().getY() > ((Integer)this.activeYValue.getValue()).intValue()) {
/*     */       return;
/*     */     }
/*  65 */     if (this.voidHoles.isEmpty()) {
/*     */       return;
/*     */     }
/*  68 */     this.voidHoles.forEach(blockPos -> {
/*     */           if (((String)this.renderMode.getValue()).equalsIgnoreCase("Box")) {
/*     */             drawBox(blockPos);
/*     */           } else {
/*     */             drawFlat(blockPos);
/*     */           } 
/*     */           drawOutline(blockPos, ((Integer)this.width.getValue()).intValue());
/*     */         });
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPos() {
/*  79 */     return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
/*     */   }
/*     */   
/*     */   private boolean isAnyBedrock(BlockPos origin, BlockPos[] offset) {
/*  83 */     for (BlockPos pos : offset) {
/*  84 */       if (mc.world.getBlockState(origin.add((Vec3i)pos)).getBlock().equals(Blocks.BEDROCK)) {
/*  85 */         return true;
/*     */       }
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   private static class Offsets {
/*  92 */     static final BlockPos[] center = new BlockPos[] { new BlockPos(0, 0, 0), new BlockPos(0, 1, 0), new BlockPos(0, 2, 0) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawFlat(BlockPos blockPos) {
/* 100 */     if (((String)this.renderType.getValue()).equalsIgnoreCase("Fill") || ((String)this.renderType.getValue()).equalsIgnoreCase("Both")) {
/* 101 */       GSColor c = new GSColor(this.color.getValue(), 50);
/* 102 */       if (((String)this.renderMode.getValue()).equalsIgnoreCase("Flat")) {
/* 103 */         RenderUtil.drawBox(blockPos, 1.0D, c, 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawBox(BlockPos blockPos) {
/* 109 */     if (((String)this.renderType.getValue()).equalsIgnoreCase("Fill") || ((String)this.renderType.getValue()).equalsIgnoreCase("Both")) {
/* 110 */       GSColor c = new GSColor(this.color.getValue(), 50);
/* 111 */       RenderUtil.drawBox(blockPos, 1.0D, c, 63);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawOutline(BlockPos blockPos, int width) {
/* 116 */     if (((String)this.renderType.getValue()).equalsIgnoreCase("Outline") || ((String)this.renderType.getValue()).equalsIgnoreCase("Both")) {
/* 117 */       if (((String)this.renderMode.getValue()).equalsIgnoreCase("Box")) {
/* 118 */         RenderUtil.drawBoundingBox(blockPos, 1.0D, width, this.color.getValue());
/*     */       }
/* 120 */       if (((String)this.renderMode.getValue()).equalsIgnoreCase("Flat"))
/* 121 */         RenderUtil.drawBoundingBoxWithSides(blockPos, width, this.color.getValue(), 1); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\VoidESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
