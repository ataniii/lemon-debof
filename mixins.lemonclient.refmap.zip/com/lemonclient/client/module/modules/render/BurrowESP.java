//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.event.events.RenderEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.api.util.render.RenderUtil;
/*    */ import com.lemonclient.api.util.world.BlockUtil;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "BurrowESP", category = Category.Render)
/*    */ public class BurrowESP extends Module {
/* 21 */   BooleanSetting self = registerBoolean("Self", true);
/* 22 */   ColorSetting selfColor = registerColor("Self Color", new GSColor(0, 255, 0, 50));
/* 23 */   BooleanSetting friend = registerBoolean("Friend", true);
/* 24 */   ColorSetting friendColor = registerColor("Friend Color", new GSColor(0, 0, 255, 50));
/* 25 */   BooleanSetting enemy = registerBoolean("Enemy", true);
/* 26 */   ColorSetting enemyColor = registerColor("Enemy Color", new GSColor(255, 0, 0));
/* 27 */   IntegerSetting ufoAlpha = registerInteger("Alpha", 120, 0, 255);
/* 28 */   IntegerSetting Alpha = registerInteger("Outline Alpha", 255, 0, 255);
/*    */   
/*    */   public void onWorldRender(RenderEvent event) {
/* 31 */     for (Entity entity : mc.world.playerEntities) {
/* 32 */       BlockPos pos = EntityUtil.getEntityPos(entity);
/* 33 */       if (BlockUtil.getBlock(pos) != Blocks.AIR) {
/* 34 */         String name = entity.getName();
/* 35 */         if (entity == mc.player) {
/* 36 */           if (((Boolean)this.self.getValue()).booleanValue()) {
/* 37 */             RenderUtil.drawBox(pos, 1.0D, new GSColor(this.selfColor.getValue(), ((Integer)this.ufoAlpha.getValue()).intValue()), 63);
/* 38 */             RenderUtil.drawBoundingBox(pos, 1.0D, 1.0F, new GSColor(this.selfColor.getValue(), ((Integer)this.Alpha.getValue()).intValue()));
/*    */           }  continue;
/* 40 */         }  if (SocialManager.isFriend(name)) {
/* 41 */           if (((Boolean)this.friend.getValue()).booleanValue()) {
/* 42 */             RenderUtil.drawBox(pos, 1.0D, new GSColor(this.friendColor.getValue(), ((Integer)this.ufoAlpha.getValue()).intValue()), 63);
/* 43 */             RenderUtil.drawBoundingBox(pos, 1.0D, 1.0F, new GSColor(this.friendColor.getValue(), ((Integer)this.Alpha.getValue()).intValue()));
/*    */           }  continue;
/*    */         } 
/* 46 */         if (((Boolean)this.enemy.getValue()).booleanValue()) {
/* 47 */           RenderUtil.drawBox(pos, 1.0D, new GSColor(this.enemyColor.getValue(), ((Integer)this.ufoAlpha.getValue()).intValue()), 63);
/* 48 */           RenderUtil.drawBoundingBox(pos, 1.0D, 1.0F, new GSColor(this.enemyColor.getValue(), ((Integer)this.Alpha.getValue()).intValue()));
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\BurrowESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
