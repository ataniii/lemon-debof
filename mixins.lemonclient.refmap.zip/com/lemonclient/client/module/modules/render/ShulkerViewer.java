//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.util.font.FontUtil;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.api.util.render.RenderUtil;
/*    */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import java.awt.Point;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.inventory.ItemStackHelper;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.NonNullList;
/*    */ 
/*    */ @Declaration(name = "ShulkerViewer", category = Category.Render)
/*    */ public class ShulkerViewer
/*    */   extends Module {
/* 22 */   public ColorSetting outlineColor = registerColor("Outline", new GSColor(255, 0, 0, 255));
/* 23 */   public ColorSetting fillColor = registerColor("Fill", new GSColor(0, 0, 0, 255));
/*    */ 
/*    */   
/*    */   public void renderShulkerPreview(ItemStack itemStack, int posX, int posY, int width, int height) {
/* 27 */     GSColor outline = new GSColor(this.outlineColor.getValue(), 255);
/* 28 */     GSColor fill = new GSColor(this.fillColor.getValue(), 200);
/*    */     
/* 30 */     RenderUtil.draw2DRect(posX + 1, posY + 1, width - 2, height - 2, 1000, fill);
/*    */     
/* 32 */     RenderUtil.draw2DRect(posX, posY, width, 1, 1000, outline);
/* 33 */     RenderUtil.draw2DRect(posX, posY + height - 1, width, 1, 1000, outline);
/* 34 */     RenderUtil.draw2DRect(posX, posY, 1, height, 1000, outline);
/* 35 */     RenderUtil.draw2DRect(posX + width - 1, posY, 1, height, 1000, outline);
/*    */     
/* 37 */     GlStateManager.disableDepth();
/* 38 */     FontUtil.drawStringWithShadow(((Boolean)((ColorMain)ModuleManager.getModule(ColorMain.class)).customFont.getValue()).booleanValue(), itemStack.getDisplayName(), (posX + 3), (posY + 3), new GSColor(255, 255, 255, 255));
/* 39 */     GlStateManager.enableDepth();
/*    */     
/* 41 */     NonNullList<ItemStack> contentItems = NonNullList.withSize(27, ItemStack.EMPTY);
/* 42 */     ItemStackHelper.loadAllItems(itemStack.getTagCompound().getCompoundTag("BlockEntityTag"), contentItems);
/*    */     
/* 44 */     for (int i = 0; i < contentItems.size(); i++) {
/* 45 */       int finalX = posX + 1 + i % 9 * 18;
/* 46 */       int finalY = posY + 31 + (i / 9 - 1) * 18;
/* 47 */       LemonClientGUI.renderItemTest((ItemStack)contentItems.get(i), new Point(finalX, finalY));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\ShulkerViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
