//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "BreakHighlight", category = Category.Render)
/*     */ public class BreakHighlight extends Module {
/*     */   public static BreakHighlight INSTANCE;
/*     */   BooleanSetting cancelAnimation;
/*     */   IntegerSetting range;
/*     */   IntegerSetting playerRange;
/*     */   BooleanSetting showProgress;
/*     */   IntegerSetting decimal;
/*     */   BooleanSetting doubleMine;
/*     */   ColorSetting nameColor;
/*     */   ModeSetting renderType;
/*     */   ColorSetting color;
/*     */   ColorSetting dColor;
/*     */   IntegerSetting alpha;
/*     */   IntegerSetting outAlpha;
/*     */   IntegerSetting width;
/*     */   DoubleSetting scale;
/*     */   HashMap<EntityPlayer, renderBlock> list;
/*     */   BlockPos lastBreak;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   @EventHandler
/*     */   private final Listener<DrawBlockDamageEvent> drawBlockDamageEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> listener;
/*     */   
/*  37 */   public BreakHighlight() { this.cancelAnimation = registerBoolean("No Animation", true);
/*  38 */     this.range = registerInteger("Range", 64, 0, 256);
/*  39 */     this.playerRange = registerInteger("Player Range", 16, 0, 64);
/*  40 */     this.showProgress = registerBoolean("Show Progress", false);
/*  41 */     this.decimal = registerInteger("Decimal", 2, 0, 2, () -> (Boolean)this.showProgress.getValue());
/*  42 */     this.doubleMine = registerBoolean("Double Mine", true);
/*  43 */     this.nameColor = registerColor("Name Color", new GSColor(255, 255, 255));
/*  44 */     this.renderType = registerMode("Render", Arrays.asList(new String[] { "Outline", "Fill", "Both" }, ), "Both");
/*  45 */     this.color = registerColor("Color", new GSColor(0, 255, 0, 255));
/*  46 */     this.dColor = registerColor("Double Color", new GSColor(0, 255, 0, 255), () -> (Boolean)this.doubleMine.getValue());
/*  47 */     this.alpha = registerInteger("Alpha", 100, 0, 255);
/*  48 */     this.outAlpha = registerInteger("Outline Alpha", 255, 0, 255);
/*  49 */     this.width = registerInteger("Width", 1, 0, 5);
/*  50 */     this.scale = registerDouble("Text Scale", 0.025D, 0.01D, 0.05D);
/*  51 */     this.list = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (event.getPacket() instanceof SPacketBlockBreakAnim) { SPacketBlockBreakAnim packet = (SPacketBlockBreakAnim)event.getPacket(); BlockPos blockPos = packet.getPosition(); if (mc.player.getDistanceSq(blockPos) > (((Integer)this.range.getValue()).intValue() * ((Integer)this.range.getValue()).intValue())) return;  EntityPlayer entityPlayer = (EntityPlayer)mc.world.getEntityByID(packet.getBreakerId()); if (entityPlayer == null) return;  if (this.list.containsKey(entityPlayer)) { if (isPos2((this.list.get(entityPlayer)).pos.pos, blockPos)) return;  (this.list.get(entityPlayer)).pos.updatePos(blockPos); } else { this.list.put(entityPlayer, new renderBlock(new breakPos(blockPos), entityPlayer)); }  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.drawBlockDamageEventListener = new Listener(event -> { if (((Boolean)this.cancelAnimation.getValue()).booleanValue()) event.cancel();  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     this.listener = new Listener(event -> { if (event.getPacket() instanceof CPacketPlayerDigging) { CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket(); if (packet.getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) this.lastBreak = packet.getPosition();  }  }new java.util.function.Predicate[0]); INSTANCE = this; }
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null)
/*     */       return false;  return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); }
/*     */   class renderBlock {
/*     */     private final BreakHighlight.breakPos pos;
/*     */     private final EntityPlayer player;
/*     */     public renderBlock(BreakHighlight.breakPos pos, EntityPlayer player) { this.pos = pos; this.player = player; } void update() { this.pos.update(); BreakHighlight.this.renderBox(this.pos, this.player); } } public void onWorldRender(RenderEvent event) { if (mc.player == null || mc.world == null) { this.list.clear(); return; }  List<EntityPlayer> playerList = mc.world.playerEntities; for (EntityPlayer player : playerList) { if (this.list.containsKey(player)) { BlockPos pos = (this.list.get(player)).pos.pos; BlockPos dPos = (this.list.get(player)).pos.dPos; if (pos != null && mc.world.getBlockState(pos).getBlockHardness((World)mc.world, pos) < 0.0F)
/*     */           (this.list.get(player)).pos.remove();  if (dPos != null && mc.world.getBlockState(dPos).getBlockHardness((World)mc.world, dPos) < 0.0F)
/*     */           (this.list.get(player)).pos.removeDouble();  if (isPos2(pos, dPos))
/*     */           dPos = null;  if (pos == null && dPos == null)
/*     */           continue;  int rangeSq = ((Integer)this.range.getValue()).intValue() * ((Integer)this.range.getValue()).intValue(); int playerSq = ((Integer)this.playerRange.getValue()).intValue() * ((Integer)this.playerRange.getValue()).intValue(); if (pos != null && mc.player.getDistanceSq(pos) > rangeSq && dPos != null && mc.player.getDistanceSq(dPos) > rangeSq)
/*     */           continue;  if (pos != null && player.getDistanceSq(pos) > playerSq && dPos != null && player.getDistanceSq(dPos) > playerSq) { this.list.remove(player); continue; }  ((renderBlock)this.list.get(player)).update(); }  }
/* 225 */      } private int calcBreakTime(BlockPos pos) { if (pos == null) return -1; 
/* 226 */     IBlockState blockState = mc.world.getBlockState(pos);
/* 227 */     float hardness = blockState.getBlockHardness((World)mc.world, pos);
/* 228 */     float breakSpeed = getBreakSpeed(pos, blockState);
/* 229 */     if (breakSpeed == -1.0F) {
/* 230 */       return -1;
/*     */     }
/* 232 */     float relativeDamage = breakSpeed / hardness / 30.0F;
/* 233 */     int ticks = (int)Math.ceil((0.7F / relativeDamage));
/* 234 */     return ticks * 50; }
/*     */   public static GSColor getRainbowColor(int damage) { return GSColor.fromHSB(((1 + damage * 32) % 11520) / 11520.0F, 1.0F, 1.0F); }
/*     */   private void renderBox(breakPos pos, EntityPlayer player) { String[] name = { player.getName() }; BlockPos blockPos = pos.pos; if (blockPos != null) { float mineDamage = (float)(System.currentTimeMillis() - pos.start) / (float)pos.time; if (mineDamage > 1.0F) mineDamage = 1.0F;  AxisAlignedBB getSelectedBoundingBox = new AxisAlignedBB(blockPos); Vec3d getCenter = getSelectedBoundingBox.getCenter(); float prognum = mineDamage * 100.0F; if (((Boolean)this.showProgress.getValue()).booleanValue()) { String[] progress = { String.format("%.0f", new Object[] { Float.valueOf(prognum) }) }; if (((Integer)this.decimal.getValue()).intValue() == 1) { progress = new String[] { String.format("%.1f", new Object[] { Float.valueOf(prognum) }) }; } else if (((Integer)this.decimal.getValue()).intValue() == 2) { progress = new String[] { String.format("%.2f", new Object[] { Float.valueOf(prognum) }) }; }  RenderUtil.drawNametag(blockPos.getX() + 0.5D, blockPos.getY() + 0.39D, blockPos.getZ() + 0.5D, progress, getRainbowColor((int)prognum), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); RenderUtil.drawNametag(blockPos.getX() + 0.5D, blockPos.getY() + 0.61D, blockPos.getZ() + 0.5D, name, new GSColor(this.nameColor.getColor(), 255), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); } else { RenderUtil.drawNametag(blockPos.getX() + 0.5D, blockPos.getY() + 0.5D, blockPos.getZ() + 0.5D, name, new GSColor(this.nameColor.getColor(), 255), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); }  renderESP((new AxisAlignedBB(getCenter.x, getCenter.y, getCenter.z, getCenter.x, getCenter.y, getCenter.z)).grow((getSelectedBoundingBox.minX - getSelectedBoundingBox.maxX) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F), (getSelectedBoundingBox.minY - getSelectedBoundingBox.maxY) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F), (getSelectedBoundingBox.minZ - getSelectedBoundingBox.maxZ) * 0.5D * MathHelper.clamp(mineDamage, 0.0F, 1.0F)), false); }  if (!((Boolean)this.doubleMine.getValue()).booleanValue()) return;  BlockPos doubleBlockPos = pos.dPos; if (doubleBlockPos != null) { float doubleMineDamage = (float)(System.currentTimeMillis() - pos.dStart) / (float)pos.dTime; if (doubleMineDamage > 1.0F)
/*     */         doubleMineDamage = 1.0F;  AxisAlignedBB getDoubleSelectedBoundingBox = new AxisAlignedBB(doubleBlockPos); Vec3d getDoubleCenter = getDoubleSelectedBoundingBox.getCenter(); float doublePrognum = doubleMineDamage * 100.0F; if (((Boolean)this.showProgress.getValue()).booleanValue()) { String[] progress = { String.format("%.0f", new Object[] { Float.valueOf(doublePrognum) }) }; if (((Integer)this.decimal.getValue()).intValue() == 1) { progress = new String[] { String.format("%.1f", new Object[] { Float.valueOf(doublePrognum) }) }; } else if (((Integer)this.decimal.getValue()).intValue() == 2) { progress = new String[] { String.format("%.2f", new Object[] { Float.valueOf(doublePrognum) }) }; }  RenderUtil.drawNametag(doubleBlockPos.getX() + 0.5D, doubleBlockPos.getY() + 0.39D, doubleBlockPos.getZ() + 0.5D, progress, getRainbowColor((int)doublePrognum), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); RenderUtil.drawNametag(doubleBlockPos.getX() + 0.5D, doubleBlockPos.getY() + 0.61D, doubleBlockPos.getZ() + 0.5D, name, new GSColor(this.nameColor.getColor(), 255), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); } else { RenderUtil.drawNametag(doubleBlockPos.getX() + 0.5D, doubleBlockPos.getY() + 0.5D, doubleBlockPos.getZ() + 0.5D, name, new GSColor(this.nameColor.getColor(), 255), 1, ((Double)this.scale.getValue()).doubleValue(), 0.0D); }  renderESP((new AxisAlignedBB(getDoubleCenter.x, getDoubleCenter.y, getDoubleCenter.z, getDoubleCenter.x, getDoubleCenter.y, getDoubleCenter.z)).grow((getDoubleSelectedBoundingBox.minX - getDoubleSelectedBoundingBox.maxX) * 0.5D * MathHelper.clamp(doubleMineDamage, 0.0F, 1.0F), (getDoubleSelectedBoundingBox.minY - getDoubleSelectedBoundingBox.maxY) * 0.5D * MathHelper.clamp(doubleMineDamage, 0.0F, 1.0F), (getDoubleSelectedBoundingBox.minZ - getDoubleSelectedBoundingBox.maxZ) * 0.5D * MathHelper.clamp(doubleMineDamage, 0.0F, 1.0F)), true); }  }
/* 238 */   private void renderESP(AxisAlignedBB axisAlignedBB, boolean dm) { GSColor fillColor = new GSColor(dm ? this.dColor.getValue() : this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()); GSColor outlineColor = new GSColor(dm ? this.dColor.getValue() : this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()); switch ((String)this.renderType.getValue()) { case "Fill": RenderUtil.drawBox(axisAlignedBB, true, 0.0D, fillColor, 63); return;case "Outline": RenderUtil.drawBoundingBox(axisAlignedBB, ((Integer)this.width.getValue()).intValue(), outlineColor); return; }  RenderUtil.drawBox(axisAlignedBB, true, 0.0D, fillColor, 63); RenderUtil.drawBoundingBox(axisAlignedBB, ((Integer)this.width.getValue()).intValue(), outlineColor); } private float getBreakSpeed(BlockPos pos, IBlockState blockState) { float maxSpeed = 1.0F;
/* 239 */     int slot = findItem(pos);
/* 240 */     float speed = mc.player.inventory.getStackInSlot(slot).getDestroySpeed(blockState);
/* 241 */     if (speed <= 1.0F) {
/* 242 */       return maxSpeed;
/*     */     }
/* 244 */     int efficiency = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, mc.player.inventory.getStackInSlot(slot));
/* 245 */     if (efficiency > 0) {
/* 246 */       speed += (efficiency * efficiency) + 1.0F;
/*     */     }
/*     */     
/* 249 */     if (speed > maxSpeed) {
/* 250 */       maxSpeed = speed;
/*     */     }
/* 252 */     return maxSpeed; }
/*     */ 
/*     */   
/*     */   public int findItem(BlockPos pos) {
/* 256 */     if (pos == null) return mc.player.inventory.currentItem; 
/* 257 */     return findBestTool(pos, mc.world.getBlockState(pos));
/*     */   }
/*     */ 
/*     */   
/*     */   public static int findBestTool(BlockPos pos, IBlockState state) {
/* 262 */     int result = mc.player.inventory.currentItem;
/* 263 */     if (state.getBlockHardness((World)mc.world, pos) > 0.0F) {
/* 264 */       double speed = getSpeed(state, mc.player.getHeldItemMainhand());
/* 265 */       for (int i = 0; i < 36; i++) {
/* 266 */         ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 267 */         double stackSpeed = getSpeed(state, stack);
/* 268 */         if (stackSpeed > speed) {
/* 269 */           speed = stackSpeed;
/* 270 */           result = i;
/*     */         } 
/*     */       } 
/*     */     } 
/* 274 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getSpeed(IBlockState state, ItemStack stack) {
/* 279 */     double str = stack.getDestroySpeed(state);
/* 280 */     int effect = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
/* 281 */     return Math.max(str + ((str > 1.0D) ? ((effect * effect) + 1.0D) : 0.0D), 0.0D);
/*     */   }
/*     */   
/*     */   public static class breakPos {
/*     */     private BlockPos pos;
/* 286 */     private BlockPos dPos = null; private long start;
/*     */     private long dStart;
/*     */     private long time;
/*     */     private long dTime;
/*     */     
/*     */     public breakPos(BlockPos pos) {
/* 292 */       this.pos = pos;
/* 293 */       this.start = System.currentTimeMillis();
/* 294 */       this.time = BreakHighlight.INSTANCE.calcBreakTime(pos);
/*     */     }
/*     */     
/*     */     public void updatePos(BlockPos pos) {
/* 298 */       if (this.dPos == null) {
/* 299 */         this.dPos = this.pos;
/* 300 */         this.dStart = this.start;
/* 301 */         this.dTime = (long)(this.time * 1.4D);
/*     */       } 
/* 303 */       this.pos = pos;
/* 304 */       this.start = System.currentTimeMillis();
/* 305 */       this.time = BreakHighlight.INSTANCE.calcBreakTime(pos);
/*     */     }
/*     */     public long getEnd() {
/* 308 */       return this.start + this.time;
/*     */     }
/*     */     public void update() {
/* 311 */       this.time = BreakHighlight.INSTANCE.calcBreakTime(this.pos);
/* 312 */       if (this.dPos != null && BlockUtil.airBlocks.contains(BreakHighlight.mc.world.getBlockState(this.dPos).getBlock()))
/* 313 */         removeDouble(); 
/*     */     }
/*     */     
/*     */     public void remove() {
/* 317 */       this.pos = null;
/*     */     }
/*     */     public void removeDouble() {
/* 320 */       this.dPos = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\BreakHighlight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
