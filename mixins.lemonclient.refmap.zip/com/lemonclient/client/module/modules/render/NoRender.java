//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraftforge.client.event.RenderBlockOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ 
/*     */ @Declaration(name = "NoRender", category = Category.Render)
/*     */ public class NoRender extends Module {
/*     */   public BooleanSetting armor;
/*     */   BooleanSetting fire;
/*     */   BooleanSetting blind;
/*     */   BooleanSetting nausea;
/*     */   public BooleanSetting hurtCam;
/*     */   public BooleanSetting noSkylight;
/*     */   public BooleanSetting noOverlay;
/*     */   BooleanSetting noBossBar;
/*     */   
/*  19 */   public NoRender() { this.armor = registerBoolean("Armor", false);
/*  20 */     this.fire = registerBoolean("Fire", false);
/*  21 */     this.blind = registerBoolean("Blind", false);
/*  22 */     this.nausea = registerBoolean("Nausea", false);
/*  23 */     this.hurtCam = registerBoolean("HurtCam", false);
/*  24 */     this.noSkylight = registerBoolean("Skylight", false);
/*  25 */     this.noOverlay = registerBoolean("No Overlay", false);
/*  26 */     this.noBossBar = registerBoolean("No Boss Bar", false);
/*  27 */     this.nameTag = registerBoolean("No NameTag", false);
/*  28 */     this.noCluster = registerBoolean("No Cluster", false);
/*  29 */     this.maxNoClusterRender = registerInteger("No Cluster Max", 5, 1, 25);
/*     */     
/*  31 */     this.currentClusterAmount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     this.blockOverlayEventListener = new Listener(event -> { if (((Boolean)this.fire.getValue()).booleanValue() && event.getOverlayType() == RenderBlockOverlayEvent.OverlayType.FIRE) event.setCanceled(true);  if (((Boolean)this.noOverlay.getValue()).booleanValue() && event.getOverlayType() == RenderBlockOverlayEvent.OverlayType.WATER) event.setCanceled(true);  if (((Boolean)this.noOverlay.getValue()).booleanValue() && event.getOverlayType() == RenderBlockOverlayEvent.OverlayType.BLOCK) event.setCanceled(true);  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.fogDensityListener = new Listener(event -> { if (((Boolean)this.noOverlay.getValue()).booleanValue() && (event.getState().getMaterial().equals(Material.WATER) || event.getState().getMaterial().equals(Material.LAVA))) { event.setDensity(0.0F); event.setCanceled(true); }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.renderBlockOverlayEventListener = new Listener(event -> { if (((Boolean)this.noOverlay.getValue()).booleanValue()) event.setCanceled(true);  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.renderGameOverlayEventListener = new Listener(event -> { if (((Boolean)this.noOverlay.getValue()).booleanValue()) { if (event.getType().equals(RenderGameOverlayEvent.ElementType.HELMET)) event.setCanceled(true);  if (event.getType().equals(RenderGameOverlayEvent.ElementType.PORTAL)) event.setCanceled(true);  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.bossbarEventListener = new Listener(event -> { if (((Boolean)this.noBossBar.getValue()).booleanValue()) event.cancel();  }new java.util.function.Predicate[0]); }
/*     */   public BooleanSetting nameTag;
/*     */   public BooleanSetting noCluster; IntegerSetting maxNoClusterRender; public int currentClusterAmount; @EventHandler public Listener<RenderBlockOverlayEvent> blockOverlayEventListener; @EventHandler
/*     */   private final Listener<EntityViewRenderEvent.FogDensity> fogDensityListener; @EventHandler
/*     */   private final Listener<RenderBlockOverlayEvent> renderBlockOverlayEventListener; @EventHandler
/*     */   private final Listener<RenderGameOverlayEvent> renderGameOverlayEventListener; @EventHandler
/*     */   private final Listener<BossbarEvent> bossbarEventListener; public void onUpdate() { if (((Boolean)this.blind.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.BLINDNESS))
/*     */       mc.player.removePotionEffect(MobEffects.BLINDNESS); 
/*     */     if (((Boolean)this.nausea.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.NAUSEA))
/*  95 */       mc.player.removePotionEffect(MobEffects.NAUSEA);  } public void onRender() { this.currentClusterAmount = 0; } public boolean incrementNoClusterRender() { this.currentClusterAmount++;
/*  96 */     return (this.currentClusterAmount > ((Integer)this.maxNoClusterRender.getValue()).intValue()); }
/*     */ 
/*     */   
/*     */   public boolean getNoClusterRender() {
/* 100 */     return (this.currentClusterAmount <= ((Integer)this.maxNoClusterRender.getValue()).intValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\NoRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
