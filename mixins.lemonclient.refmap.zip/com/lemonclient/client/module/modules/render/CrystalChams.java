//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @Declaration(name = "CrystalChams", category = Category.Render)
/*     */ public class CrystalChams extends Module {
/*     */   IntegerSetting range;
/*     */   ModeSetting mode;
/*     */   BooleanSetting chams;
/*     */   BooleanSetting throughWalls;
/*     */   BooleanSetting wireframe;
/*     */   BooleanSetting wireWalls;
/*     */   DoubleSetting spinSpeed;
/*     */   DoubleSetting floatSpeed;
/*     */   ColorSetting color;
/*     */   ColorSetting wireFrameColor;
/*     */   DoubleSetting lineWidth;
/*     */   DoubleSetting lineWidthInterp;
/*     */   BooleanSetting show;
/*     */   @EventHandler
/*     */   private final Listener<NewRenderEntityEvent> renderEntityHeadEventListener;
/*     */   
/*     */   public CrystalChams() {
/*  24 */     this.range = registerInteger("Range", 32, 0, 256);
/*  25 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Normal", "Gradient" }, ), "Normal");
/*  26 */     this.chams = registerBoolean("Chams", false);
/*  27 */     this.throughWalls = registerBoolean("ThroughWalls", false);
/*  28 */     this.wireframe = registerBoolean("Wireframe", false);
/*  29 */     this.wireWalls = registerBoolean("WireThroughWalls", false);
/*  30 */     this.spinSpeed = registerDouble("SpinSpeed", 1.0D, 0.0D, 4.0D);
/*  31 */     this.floatSpeed = registerDouble("FloatSpeed", 1.0D, 0.0D, 4.0D);
/*  32 */     this.color = registerColor("Color", new GSColor(255, 255, 255, 255), Boolean.valueOf(true));
/*  33 */     this.wireFrameColor = registerColor("WireframeColor", new GSColor(255, 255, 255, 255), Boolean.valueOf(true));
/*  34 */     this.lineWidth = registerDouble("lineWidth", 1.0D, 0.0D, 4.0D);
/*  35 */     this.lineWidthInterp = registerDouble("lineWidthInterp", 1.0D, 0.1D, 4.0D);
/*  36 */     this.show = registerBoolean("ShowEntity ;;", false);
/*     */     
/*  38 */     this.renderEntityHeadEventListener = new Listener(event -> { if (mc.player == null || mc.world == null || event.entityIn == null || event.entityIn.getName().length() == 0) return;  if (!(event.entityIn instanceof EntityEnderCrystal) || mc.player.getDistance(event.entityIn) > ((Integer)this.range.getValue()).intValue()) return;  if (!((Boolean)this.show.getValue()).booleanValue()) event.cancel();  prepare(); float spinTicks = ((EntityEnderCrystal)event.entityIn).innerRotation + Minecraft.getMinecraft().getRenderPartialTicks(); float floatTicks = MathHelper.sin(spinTicks * 0.2F * ((Double)this.floatSpeed.getValue()).floatValue()) / 2.0F + 0.5F; float spinSpeed = ((Double)this.spinSpeed.getValue()).floatValue(); float scale = 0.0625F; float swingAmount = spinTicks * 3.0F * spinSpeed; floatTicks = floatTicks * floatTicks + floatTicks; floatTicks *= 0.2F; GlStateManager.glLineWidth(getInterpolatedLinWid(mc.player.getDistance(event.entityIn) + 1.0F, ((Double)this.lineWidth.getValue()).floatValue(), ((Double)this.lineWidthInterp.getValue()).floatValue())); GL11.glDisable(3553); if (((String)this.mode.getValue()).equals("Gradient")) { GL11.glPushAttrib(1048575); GL11.glEnable(3042); GL11.glDisable(2896); GL11.glDisable(3553); float alpha = this.color.getValue().getAlpha() / 255.0F; GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha); event.modelBase.render(event.entityIn, 0.0F, swingAmount, floatTicks, 0.0F, 0.0F, scale); GL11.glEnable(3553); GL11.glBlendFunc(770, 771); float f = event.entityIn.ticksExisted + Minecraft.getMinecraft().getRenderPartialTicks(); mc.getTextureManager().bindTexture(new ResourceLocation("textures/rainbow.png")); (Minecraft.getMinecraft()).entityRenderer.setupFogColor(true); GlStateManager.enableBlend(); GlStateManager.depthFunc(514); GlStateManager.depthMask(false); GlStateManager.color(1.0F, 1.0F, 1.0F, alpha); for (int i = 0; i < 2; i++) { GlStateManager.disableLighting(); GlStateManager.color(1.0F, 1.0F, 1.0F, alpha); GlStateManager.matrixMode(5890); GlStateManager.loadIdentity(); GlStateManager.rotate(30.0F - i * 60.0F, 0.0F, 0.0F, 0.5F); GlStateManager.translate(0.0F, f * (0.001F + i * 0.003F) * 20.0F, 0.0F); GlStateManager.matrixMode(5888); event.modelBase.render(event.entityIn, 0.0F, swingAmount, floatTicks, 0.0F, 0.0F, scale); }  GlStateManager.matrixMode(5890); GlStateManager.loadIdentity(); GlStateManager.matrixMode(5888); GlStateManager.enableLighting(); GlStateManager.depthMask(true); GlStateManager.depthFunc(515); GlStateManager.disableBlend(); mc.entityRenderer.setupFogColor(false); GL11.glPopAttrib(); } else { if (((Boolean)this.wireframe.getValue()).booleanValue()) { GSColor gSColor = this.wireFrameColor.getValue(); GL11.glPushAttrib(1048575); GL11.glEnable(3042); GL11.glDisable(3553); GL11.glDisable(2896); GL11.glBlendFunc(770, 771); GL11.glPolygonMode(1032, 6913); if (((Boolean)this.wireWalls.getValue()).booleanValue()) { GL11.glDepthMask(false); GL11.glDisable(2929); }  GL11.glColor4f(gSColor.getRed() / 255.0F, gSColor.getGreen() / 255.0F, gSColor.getBlue() / 255.0F, gSColor.getAlpha() / 255.0F); event.modelBase.render(event.entityIn, 0.0F, swingAmount, floatTicks, 0.0F, 0.0F, scale); GL11.glPopAttrib(); }  if (((Boolean)this.chams.getValue()).booleanValue()) { GSColor gSColor = this.color.getValue(); GL11.glPushAttrib(1048575); GL11.glEnable(3042); GL11.glDisable(3553); GL11.glDisable(2896); GL11.glDisable(3008); GL11.glBlendFunc(770, 771); GL11.glEnable(2960); GL11.glEnable(10754); if (((Boolean)this.throughWalls.getValue()).booleanValue()) { GL11.glDepthMask(false); GL11.glDisable(2929); }  GL11.glColor4f(gSColor.getRed() / 255.0F, gSColor.getGreen() / 255.0F, gSColor.getBlue() / 255.0F, gSColor.getAlpha() / 255.0F); event.modelBase.render(event.entityIn, 0.0F, swingAmount, floatTicks, 0.0F, 0.0F, scale); GL11.glPopAttrib(); }  }  event.limbSwing = 0.0F; event.limbSwingAmount = swingAmount; event.ageInTicks = floatTicks; event.netHeadYaw = 0.0F; event.headPitch = 0.0F; event.scale = scale; release(); }new java.util.function.Predicate[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void prepare() {
/* 155 */     GlStateManager.pushMatrix();
/* 156 */     GlStateManager.disableDepth();
/* 157 */     GlStateManager.disableLighting();
/* 158 */     GlStateManager.depthMask(false);
/* 159 */     GlStateManager.disableAlpha();
/*     */     
/* 161 */     GlStateManager.enableBlend();
/* 162 */     GL11.glDisable(3553);
/* 163 */     GL11.glEnable(2848);
/* 164 */     GL11.glBlendFunc(770, 771);
/*     */   }
/*     */   
/*     */   void release() {
/* 168 */     GlStateManager.depthMask(true);
/* 169 */     GlStateManager.enableLighting();
/* 170 */     GlStateManager.enableDepth();
/* 171 */     GlStateManager.enableAlpha();
/* 172 */     GlStateManager.popMatrix();
/* 173 */     GL11.glEnable(3553);
/* 174 */     GL11.glPolygonMode(1032, 6914);
/* 175 */     (new GSColor(255, 255, 255, 255)).glColor();
/*     */   }
/*     */   
/*     */   float getInterpolatedLinWid(float distance, float line, float lineFactor) {
/* 179 */     return line * lineFactor / distance;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\CrystalChams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
