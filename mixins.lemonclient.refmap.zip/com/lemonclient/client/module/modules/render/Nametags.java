//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.font.FontUtil;
/*     */ import com.lemonclient.api.util.misc.ColorUtil;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.manager.managers.TotemPopManager;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ @Declaration(name = "Nametags", category = Category.Render)
/*     */ public class Nametags extends Module {
/*  32 */   IntegerSetting range = registerInteger("Range", 100, 10, 260);
/*  33 */   DoubleSetting scale = registerDouble("Scale", 0.5D, 0.01D, 1.0D);
/*  34 */   DoubleSetting maxScale = registerDouble("Max Scale", 0.5D, 0.0D, 2.0D);
/*  35 */   BooleanSetting renderSelf = registerBoolean("Render Self", false);
/*  36 */   BooleanSetting showDurability = registerBoolean("Durability", true);
/*  37 */   BooleanSetting showItems = registerBoolean("Items", true);
/*  38 */   BooleanSetting showEnchantName = registerBoolean("Enchants", true);
/*  39 */   ModeSetting levelColor = registerMode("Level Color", ColorUtil.colors, "Green", () -> (Boolean)this.showEnchantName.getValue());
/*  40 */   BooleanSetting showItemName = registerBoolean("Item Name", false);
/*  41 */   BooleanSetting showGameMode = registerBoolean("Gamemode", false);
/*  42 */   BooleanSetting showHealth = registerBoolean("Health", true);
/*  43 */   BooleanSetting showPing = registerBoolean("Ping", false);
/*  44 */   BooleanSetting showTotem = registerBoolean("Totem Pops", true);
/*  45 */   BooleanSetting showEntityID = registerBoolean("Entity Id", false);
/*  46 */   public BooleanSetting border = registerBoolean("Border", false);
/*  47 */   public BooleanSetting outline = registerBoolean("Outline", false);
/*  48 */   public BooleanSetting customColor = registerBoolean("Custom Color", true, () -> (Boolean)this.outline.getValue());
/*  49 */   public ColorSetting borderColor = registerColor("Border Color", new GSColor(255, 0, 0, 255), () -> Boolean.valueOf((((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.customColor.getValue()).booleanValue())));
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/*  52 */     if (mc.player == null || mc.world == null) {
/*     */       return;
/*     */     }
/*     */     
/*  56 */     mc.world.playerEntities.stream().filter(this::shouldRender).forEach(entityPlayer -> {
/*     */           Vec3d vec3d = findEntityVec3d(entityPlayer);
/*     */           renderNameTags(entityPlayer, vec3d.x, vec3d.y, vec3d.z);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean shouldRender(EntityPlayer entityPlayer) {
/*  64 */     if (entityPlayer == mc.player && !((Boolean)this.renderSelf.getValue()).booleanValue()) {
/*  65 */       EntityPlayerSP entityPlayerSP; Entity player = mc.getRenderViewEntity();
/*  66 */       if (player == null) entityPlayerSP = mc.player; 
/*  67 */       if (entityPlayerSP == mc.player) return false;
/*     */     
/*     */     } 
/*  70 */     if (entityPlayer.getName().length() == 0) return false;
/*     */     
/*  72 */     if (entityPlayer.isDead || entityPlayer.getHealth() <= 0.0F) return false;
/*     */     
/*  74 */     return (entityPlayer.getDistance((Entity)mc.player) <= ((Integer)this.range.getValue()).intValue());
/*     */   }
/*     */   
/*     */   private Vec3d findEntityVec3d(EntityPlayer entityPlayer) {
/*  78 */     double posX = balancePosition(entityPlayer.posX, entityPlayer.lastTickPosX);
/*  79 */     double posY = balancePosition(entityPlayer.posY, entityPlayer.lastTickPosY);
/*  80 */     double posZ = balancePosition(entityPlayer.posZ, entityPlayer.lastTickPosZ);
/*     */     
/*  82 */     return new Vec3d(posX, posY, posZ);
/*     */   }
/*     */   
/*     */   private double balancePosition(double newPosition, double oldPosition) {
/*  86 */     return oldPosition + (newPosition - oldPosition) * mc.timer.renderPartialTicks;
/*     */   }
/*     */   
/*     */   private void renderNameTags(EntityPlayer entityPlayer, double posX, double posY, double posZ) {
/*  90 */     double adjustedY = posY + (entityPlayer.isSneaking() ? 1.9D : 2.1D);
/*     */     
/*  92 */     String[] name = new String[1];
/*  93 */     name[0] = buildEntityNameString(entityPlayer);
/*     */     
/*  95 */     RenderUtil.drawNametag(posX, adjustedY, posZ, name, findTextColor(entityPlayer), 2, ((Double)this.scale.getValue()).doubleValue(), ((Double)this.maxScale.getValue()).doubleValue());
/*  96 */     renderItemsAndArmor(entityPlayer, 0, 0);
/*  97 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   private String buildEntityNameString(EntityPlayer entityPlayer) {
/* 101 */     String name = entityPlayer.getName();
/*     */     
/* 103 */     if (((Boolean)this.showEntityID.getValue()).booleanValue()) {
/* 104 */       name = name + " ID: " + entityPlayer.getEntityId();
/*     */     }
/*     */     
/* 107 */     if (((Boolean)this.showGameMode.getValue()).booleanValue()) {
/* 108 */       if (entityPlayer.isCreative()) {
/* 109 */         name = name + " [C]";
/* 110 */       } else if (entityPlayer.isSpectator()) {
/* 111 */         name = name + " [I]";
/*     */       } else {
/* 113 */         name = name + " [S]";
/*     */       } 
/*     */     }
/*     */     
/* 117 */     if (((Boolean)this.showTotem.getValue()).booleanValue()) {
/* 118 */       name = name + " [" + TotemPopManager.INSTANCE.getPlayerPopCount(entityPlayer.getName()) + "]";
/*     */     }
/*     */     
/* 121 */     if (((Boolean)this.showPing.getValue()).booleanValue()) {
/* 122 */       int value = 0;
/*     */       
/* 124 */       if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()) != null) {
/* 125 */         value = mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()).getResponseTime();
/*     */       }
/*     */       
/* 128 */       name = name + " " + value + "ms";
/*     */     } 
/*     */     
/* 131 */     if (((Boolean)this.showHealth.getValue()).booleanValue()) {
/* 132 */       int health = (int)(entityPlayer.getHealth() + entityPlayer.getAbsorptionAmount());
/* 133 */       TextFormatting textFormatting = findHealthColor(health);
/*     */       
/* 135 */       name = name + " " + textFormatting + health;
/*     */     } 
/*     */     
/* 138 */     return name;
/*     */   }
/*     */   
/*     */   private TextFormatting findHealthColor(int health) {
/* 142 */     if (health <= 0)
/* 143 */       return TextFormatting.DARK_RED; 
/* 144 */     if (health <= 5)
/* 145 */       return TextFormatting.RED; 
/* 146 */     if (health <= 10)
/* 147 */       return TextFormatting.GOLD; 
/* 148 */     if (health <= 15)
/* 149 */       return TextFormatting.YELLOW; 
/* 150 */     if (health <= 20) {
/* 151 */       return TextFormatting.DARK_GREEN;
/*     */     }
/*     */     
/* 154 */     return TextFormatting.GREEN;
/*     */   }
/*     */   
/*     */   private GSColor findTextColor(EntityPlayer entityPlayer) {
/* 158 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 159 */     if (SocialManager.isFriend(entityPlayer.getName()))
/* 160 */       return colorMain.getFriendGSColor(); 
/* 161 */     if (SocialManager.isEnemy(entityPlayer.getName()))
/* 162 */       return colorMain.getEnemyGSColor(); 
/* 163 */     if (entityPlayer.isInvisible())
/* 164 */       return new GSColor(128, 128, 128); 
/* 165 */     if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(entityPlayer.getUniqueID()) == null)
/* 166 */       return new GSColor(239, 1, 71); 
/* 167 */     if (entityPlayer.isSneaking()) {
/* 168 */       return new GSColor(255, 153, 0);
/*     */     }
/*     */     
/* 171 */     return new GSColor(255, 255, 255);
/*     */   }
/*     */   
/*     */   private void renderItemsAndArmor(EntityPlayer entityPlayer, int posX, int posY) {
/* 175 */     ItemStack mainHandItem = entityPlayer.getHeldItemMainhand();
/* 176 */     ItemStack offHandItem = entityPlayer.getHeldItemOffhand();
/*     */     
/* 178 */     int armorCount = 3;
/* 179 */     for (int i = 0; i <= 3; i++) {
/* 180 */       ItemStack itemStack = (ItemStack)entityPlayer.inventory.armorInventory.get(armorCount);
/*     */       
/* 182 */       if (!itemStack.isEmpty()) {
/* 183 */         posX -= 8;
/*     */         
/* 185 */         int size = EnchantmentHelper.getEnchantments(itemStack).size();
/*     */         
/* 187 */         if (((Boolean)this.showItems.getValue()).booleanValue() && size > posY) {
/* 188 */           posY = size;
/*     */         }
/*     */       } 
/* 191 */       armorCount--;
/*     */     } 
/*     */     
/* 194 */     if (!mainHandItem.isEmpty() && (((Boolean)this.showItems.getValue()).booleanValue() || (((Boolean)this.showDurability.getValue()).booleanValue() && offHandItem.isItemStackDamageable()))) {
/* 195 */       posX -= 8;
/*     */       
/* 197 */       int enchantSize = EnchantmentHelper.getEnchantments(offHandItem).size();
/* 198 */       if (((Boolean)this.showItems.getValue()).booleanValue() && enchantSize > posY) {
/* 199 */         posY = enchantSize;
/*     */       }
/*     */     } 
/*     */     
/* 203 */     if (!mainHandItem.isEmpty()) {
/*     */       
/* 205 */       int enchantSize = EnchantmentHelper.getEnchantments(mainHandItem).size();
/*     */       
/* 207 */       if (((Boolean)this.showItems.getValue()).booleanValue() && enchantSize > posY) {
/* 208 */         posY = enchantSize;
/*     */       }
/*     */       
/* 211 */       int armorY = findArmorY(posY);
/*     */       
/* 213 */       if (((Boolean)this.showItems.getValue()).booleanValue() || (((Boolean)this.showDurability.getValue()).booleanValue() && mainHandItem.isItemStackDamageable())) {
/* 214 */         posX -= 8;
/*     */       }
/*     */       
/* 217 */       if (((Boolean)this.showItems.getValue()).booleanValue()) {
/* 218 */         renderItem(mainHandItem, posX, armorY, posY);
/* 219 */         armorY -= 32;
/*     */       } 
/*     */       
/* 222 */       if (((Boolean)this.showDurability.getValue()).booleanValue() && mainHandItem.isItemStackDamageable()) {
/* 223 */         renderItemDurability(mainHandItem, posX, armorY);
/*     */       }
/*     */       
/* 226 */       ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 227 */       armorY -= ((Boolean)colorMain.customFont.getValue()).booleanValue() ? FontUtil.getFontHeight(((Boolean)colorMain.customFont.getValue()).booleanValue()) : mc.fontRenderer.FONT_HEIGHT;
/*     */       
/* 229 */       if (((Boolean)this.showItemName.getValue()).booleanValue()) {
/* 230 */         renderItemName(mainHandItem, armorY);
/*     */       }
/*     */       
/* 233 */       if (((Boolean)this.showItems.getValue()).booleanValue() || (((Boolean)this.showDurability.getValue()).booleanValue() && mainHandItem.isItemStackDamageable())) {
/* 234 */         posX += 16;
/*     */       }
/*     */     } 
/*     */     
/* 238 */     int armorCount2 = 3;
/* 239 */     for (int j = 0; j <= 3; j++) {
/* 240 */       ItemStack itemStack = (ItemStack)entityPlayer.inventory.armorInventory.get(armorCount2);
/*     */       
/* 242 */       if (!itemStack.isEmpty()) {
/* 243 */         int armorY = findArmorY(posY);
/*     */         
/* 245 */         if (((Boolean)this.showItems.getValue()).booleanValue()) {
/* 246 */           renderItem(itemStack, posX, armorY, posY);
/* 247 */           armorY -= 32;
/*     */         } 
/*     */         
/* 250 */         if (((Boolean)this.showDurability.getValue()).booleanValue() && itemStack.isItemStackDamageable()) {
/* 251 */           renderItemDurability(itemStack, posX, armorY);
/*     */         }
/* 253 */         posX += 16;
/*     */       } 
/* 255 */       armorCount2--;
/*     */     } 
/*     */     
/* 258 */     if (!offHandItem.isEmpty()) {
/* 259 */       int armorY = findArmorY(posY);
/*     */       
/* 261 */       if (((Boolean)this.showItems.getValue()).booleanValue()) {
/* 262 */         renderItem(offHandItem, posX, armorY, posY);
/* 263 */         armorY -= 32;
/*     */       } 
/*     */       
/* 266 */       if (((Boolean)this.showDurability.getValue()).booleanValue() && offHandItem.isItemStackDamageable()) {
/* 267 */         renderItemDurability(offHandItem, posX, armorY);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private int findArmorY(int posY) {
/* 273 */     int posY2 = ((Boolean)this.showItems.getValue()).booleanValue() ? -26 : -27;
/* 274 */     if (posY > 4) {
/* 275 */       posY2 -= (posY - 4) * 8;
/*     */     }
/*     */     
/* 278 */     return posY2;
/*     */   }
/*     */   
/*     */   private void renderItemName(ItemStack itemStack, int posY) {
/* 282 */     GlStateManager.enableTexture2D();
/* 283 */     GlStateManager.pushMatrix();
/* 284 */     GlStateManager.scale(0.5D, 0.5D, 0.5D);
/* 285 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 286 */     FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), itemStack.getDisplayName(), (-FontUtil.getStringWidth(((Boolean)colorMain.customFont.getValue()).booleanValue(), itemStack.getDisplayName()) / 2), posY, new GSColor(255, 255, 255));
/* 287 */     GlStateManager.popMatrix();
/* 288 */     GlStateManager.disableTexture2D();
/*     */   }
/*     */   
/*     */   private void renderItemDurability(ItemStack itemStack, int posX, int posY) {
/* 292 */     float damagePercent = (itemStack.getMaxDamage() - itemStack.getItemDamage()) / itemStack.getMaxDamage();
/*     */     
/* 294 */     float green = damagePercent;
/* 295 */     if (green > 1.0F) { green = 1.0F; }
/* 296 */     else if (green < 0.0F) { green = 0.0F; }
/*     */     
/* 298 */     float red = 1.0F - green;
/*     */     
/* 300 */     GlStateManager.enableTexture2D();
/* 301 */     GlStateManager.pushMatrix();
/* 302 */     GlStateManager.scale(0.5D, 0.5D, 0.5D);
/* 303 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 304 */     FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), (int)(damagePercent * 100.0F) + "%", (posX * 2), posY, new GSColor((int)(red * 255.0F), (int)(green * 255.0F), 0));
/* 305 */     GlStateManager.popMatrix();
/* 306 */     GlStateManager.disableTexture2D();
/*     */   }
/*     */   
/*     */   private void renderItem(ItemStack itemStack, int posX, int posY, int posY2) {
/* 310 */     GlStateManager.enableTexture2D();
/* 311 */     GlStateManager.depthMask(true);
/* 312 */     GlStateManager.clear(256);
/* 313 */     GlStateManager.enableDepth();
/* 314 */     GlStateManager.disableAlpha();
/*     */     
/* 316 */     int posY3 = (posY2 > 4) ? ((posY2 - 4) * 8 / 2) : 0;
/*     */     
/* 318 */     (mc.getRenderItem()).zLevel = -150.0F;
/* 319 */     RenderHelper.enableStandardItemLighting();
/* 320 */     mc.getRenderItem().renderItemAndEffectIntoGUI(itemStack, posX, posY + posY3);
/* 321 */     mc.getRenderItem().renderItemOverlays(mc.fontRenderer, itemStack, posX, posY + posY3);
/* 322 */     RenderHelper.disableStandardItemLighting();
/* 323 */     (mc.getRenderItem()).zLevel = 0.0F;
/* 324 */     RenderUtil.prepare();
/* 325 */     GlStateManager.pushMatrix();
/* 326 */     GlStateManager.scale(0.5D, 0.5D, 0.5D);
/* 327 */     renderEnchants(itemStack, posX, posY - 24);
/* 328 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   private void renderEnchants(ItemStack itemStack, int posX, int posY) {
/* 332 */     GlStateManager.enableTexture2D();
/*     */     
/* 334 */     for (Enchantment enchantment : EnchantmentHelper.getEnchantments(itemStack).keySet()) {
/* 335 */       if (enchantment == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 339 */       if (((Boolean)this.showEnchantName.getValue()).booleanValue()) {
/* 340 */         int level = EnchantmentHelper.getEnchantmentLevel(enchantment, itemStack);
/* 341 */         ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 342 */         FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), findStringForEnchants(enchantment, level), (posX * 2), posY, new GSColor(255, 255, 255));
/*     */       } 
/* 344 */       posY += 8;
/*     */     } 
/*     */     
/* 347 */     if (itemStack.getItem().equals(Items.GOLDEN_APPLE) && itemStack.hasEffect()) {
/* 348 */       ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 349 */       FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), "God", (posX * 2), (posY + ((!((Boolean)this.showEnchantName.getValue()).booleanValue() && ((Boolean)this.showItems.getValue()).booleanValue()) ? 8 : 0)), new GSColor(195, 77, 65));
/*     */     } 
/*     */     
/* 352 */     GlStateManager.disableTexture2D();
/*     */   }
/*     */   
/*     */   private String findStringForEnchants(Enchantment enchantment, int level) {
/* 356 */     ResourceLocation resourceLocation = (ResourceLocation)Enchantment.REGISTRY.getNameForObject(enchantment);
/*     */     
/* 358 */     String string = (resourceLocation == null) ? enchantment.getName() : resourceLocation.toString();
/*     */     
/* 360 */     int charCount = (level > 1) ? 12 : 13;
/*     */     
/* 362 */     if (string.length() > charCount) {
/* 363 */       string = string.substring(10, charCount);
/*     */     }
/*     */     
/* 366 */     return string.substring(0, 1).toUpperCase() + string.substring(1) + ColorUtil.settingToTextFormatting(this.levelColor) + ((level > 1) ? (String)Integer.valueOf(level) : "");
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\Nametags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
