/*    */ package com.lemonclient.client.module.modules.render;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ @Declaration(name = "AntiFog", category = Category.Render)
/*    */ public class AntiFog
/*    */   extends Module {
/*    */   public static String type;
/* 13 */   ModeSetting mode = registerMode("Mode", Arrays.asList(new String[] { "NoFog", "Air" }, ), "NoFog");
/*    */   
/*    */   public void onUpdate() {
/* 16 */     type = (String)this.mode.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\AntiFog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */