//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.render;
/*     */ 
/*     */ import com.lemonclient.api.event.events.RenderEvent;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ @Declaration(name = "BlockHighlight", category = Category.Render)
/*     */ public class BlockHighlight
/*     */   extends Module {
/*  23 */   ModeSetting renderLook = registerMode("Render", Arrays.asList(new String[] { "Block", "Side" }, ), "Block");
/*  24 */   ModeSetting renderType = registerMode("Type", Arrays.asList(new String[] { "Outline", "Fill", "Both" }, ), "Outline");
/*  25 */   IntegerSetting lineWidth = registerInteger("Width", 1, 1, 5);
/*  26 */   ColorSetting renderColor = registerColor("Color", new GSColor(255, 0, 0, 255));
/*     */   
/*     */   private int lookInt;
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/*  31 */     RayTraceResult rayTraceResult = mc.objectMouseOver;
/*     */     
/*  33 */     if (rayTraceResult == null) {
/*     */       return;
/*     */     }
/*     */     
/*  37 */     EnumFacing enumFacing = mc.objectMouseOver.sideHit;
/*     */     
/*  39 */     if (enumFacing == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     GSColor colorWithOpacity = new GSColor(this.renderColor.getValue(), 50);
/*     */     
/*  48 */     switch ((String)this.renderLook.getValue()) {
/*     */       case "Block":
/*  50 */         this.lookInt = 0;
/*     */         break;
/*     */ 
/*     */       
/*     */       case "Side":
/*  55 */         this.lookInt = 1;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/*  60 */     if (rayTraceResult.typeOfHit == RayTraceResult.Type.BLOCK) {
/*  61 */       BlockPos blockPos = rayTraceResult.getBlockPos();
/*  62 */       AxisAlignedBB axisAlignedBB = mc.world.getBlockState(blockPos).getSelectedBoundingBox((World)mc.world, blockPos);
/*     */       
/*  64 */       if (mc.world.getBlockState(blockPos).getMaterial() != Material.AIR) {
/*  65 */         switch ((String)this.renderType.getValue()) {
/*     */           case "Outline":
/*  67 */             renderOutline(axisAlignedBB, ((Integer)this.lineWidth.getValue()).intValue(), this.renderColor.getValue(), enumFacing, this.lookInt);
/*     */             break;
/*     */           
/*     */           case "Fill":
/*  71 */             renderFill(axisAlignedBB, colorWithOpacity, enumFacing, this.lookInt);
/*     */             break;
/*     */ 
/*     */           
/*     */           case "Both":
/*  76 */             renderOutline(axisAlignedBB, ((Integer)this.lineWidth.getValue()).intValue(), this.renderColor.getValue(), enumFacing, this.lookInt);
/*  77 */             renderFill(axisAlignedBB, colorWithOpacity, enumFacing, this.lookInt);
/*     */             break;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderOutline(AxisAlignedBB axisAlignedBB, int width, GSColor color, EnumFacing enumFacing, int lookInt) {
/*  87 */     if (lookInt == 0) {
/*  88 */       RenderUtil.drawBoundingBox(axisAlignedBB, width, color);
/*  89 */     } else if (lookInt == 1) {
/*  90 */       RenderUtil.drawBoundingBoxWithSides(axisAlignedBB, width, color, findRenderingSide(enumFacing));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void renderFill(AxisAlignedBB axisAlignedBB, GSColor color, EnumFacing enumFacing, int lookInt) {
/*  95 */     int facing = 0;
/*     */     
/*  97 */     if (lookInt == 0) {
/*  98 */       facing = 63;
/*  99 */     } else if (lookInt == 1) {
/* 100 */       facing = findRenderingSide(enumFacing);
/*     */     } 
/*     */     
/* 103 */     RenderUtil.drawBox(axisAlignedBB, true, 1.0D, color, facing);
/*     */   }
/*     */   
/*     */   private int findRenderingSide(EnumFacing enumFacing) {
/* 107 */     int facing = 0;
/*     */     
/* 109 */     if (enumFacing == EnumFacing.EAST) {
/* 110 */       facing = 32;
/* 111 */     } else if (enumFacing == EnumFacing.WEST) {
/* 112 */       facing = 16;
/* 113 */     } else if (enumFacing == EnumFacing.NORTH) {
/* 114 */       facing = 4;
/* 115 */     } else if (enumFacing == EnumFacing.SOUTH) {
/* 116 */       facing = 8;
/* 117 */     } else if (enumFacing == EnumFacing.UP) {
/* 118 */       facing = 2;
/* 119 */     } else if (enumFacing == EnumFacing.DOWN) {
/* 120 */       facing = 1;
/*     */     } 
/*     */     
/* 123 */     return facing;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\BlockHighlight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
