//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.render;
/*    */ import com.lemonclient.api.event.events.TransformSideFirstPersonEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ import net.minecraftforge.client.event.EntityViewRenderEvent;
/*    */ 
/*    */ @Declaration(name = "ViewModel", category = Category.Render)
/*    */ public class ViewModel extends Module {
/*    */   ModeSetting type;
/*    */   public BooleanSetting cancelEating;
/*    */   DoubleSetting xLeft;
/*    */   DoubleSetting yLeft;
/*    */   DoubleSetting zLeft;
/*    */   
/*    */   public ViewModel() {
/* 20 */     this.type = registerMode("Type", Arrays.asList(new String[] { "Value", "FOV", "Both" }, ), "Value");
/* 21 */     this.cancelEating = registerBoolean("No Eat", false);
/* 22 */     this.xLeft = registerDouble("Left X", 0.0D, -2.0D, 2.0D);
/* 23 */     this.yLeft = registerDouble("Left Y", 0.2D, -2.0D, 2.0D);
/* 24 */     this.zLeft = registerDouble("Left Z", -1.2D, -2.0D, 2.0D);
/* 25 */     this.xRight = registerDouble("Right X", 0.0D, -2.0D, 2.0D);
/* 26 */     this.yRight = registerDouble("Right Y", 0.2D, -2.0D, 2.0D);
/* 27 */     this.zRight = registerDouble("Right Z", -1.2D, -2.0D, 2.0D);
/* 28 */     this.fov = registerDouble("Item FOV", 130.0D, 70.0D, 200.0D);
/*    */     
/* 30 */     this.eventListener = new Listener(event -> { if (((String)this.type.getValue()).equalsIgnoreCase("Value") || ((String)this.type.getValue()).equalsIgnoreCase("Both")) if (event.getEnumHandSide() == EnumHandSide.RIGHT) { GlStateManager.translate(((Double)this.xRight.getValue()).doubleValue(), ((Double)this.yRight.getValue()).doubleValue(), ((Double)this.zRight.getValue()).doubleValue()); } else if (event.getEnumHandSide() == EnumHandSide.LEFT) { GlStateManager.translate(((Double)this.xLeft.getValue()).doubleValue(), ((Double)this.yLeft.getValue()).doubleValue(), ((Double)this.zLeft.getValue()).doubleValue()); }   }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 42 */     this.fovModifierListener = new Listener(event -> { if (((String)this.type.getValue()).equalsIgnoreCase("FOV") || ((String)this.type.getValue()).equalsIgnoreCase("Both")) event.setFOV(((Double)this.fov.getValue()).floatValue());  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   DoubleSetting xRight;
/*    */   DoubleSetting yRight;
/*    */   DoubleSetting zRight;
/*    */   DoubleSetting fov;
/*    */   @EventHandler
/*    */   private final Listener<TransformSideFirstPersonEvent> eventListener;
/*    */   @EventHandler
/*    */   private final Listener<EntityViewRenderEvent.FOVModifier> fovModifierListener;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\ViewModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
