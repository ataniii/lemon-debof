package com.lemonclient.client.module.modules.render;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;
import com.lemonclient.client.module.Module.Declaration;

@Declaration(name = "NoFallingBlocks", category = Category.Render)
public class NoFallingBlocks extends Module {}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\render\NoFallingBlocks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */