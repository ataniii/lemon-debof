//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "AutoShulker", category = Category.Dev)
/*     */ public class AutoShulker extends Module {
/*     */   BooleanSetting once;
/*     */   IntegerSetting counts;
/*     */   BooleanSetting disable;
/*     */   DoubleSetting range;
/*     */   DoubleSetting yRange;
/*     */   DoubleSetting targetRange;
/*     */   IntegerSetting tickDelay;
/*     */   BooleanSetting inventory;
/*     */   IntegerSetting Slot;
/*     */   BooleanSetting packetPlace;
/*     */   BooleanSetting placeSwing;
/*     */   BooleanSetting packetSwing;
/*     */   BooleanSetting packetSwitch;
/*     */   private int delayTimeTicks;
/*     */   BlockPos playerPos;
/*     */   ShulkerPos blockAim;
/*     */   List<BlockPos> list;
/*     */   int slot;
/*     */   boolean swapped;
/*     */   @EventHandler
/*     */   private final Listener<DeathEvent> deathEventListener;
/*     */   
/*  39 */   public AutoShulker() { this.once = registerBoolean("Once", false);
/*  40 */     this.counts = registerInteger("EmptySlots", 6, 1, 36, () -> Boolean.valueOf(!((Boolean)this.once.getValue()).booleanValue()));
/*  41 */     this.disable = registerBoolean("Disable After Death", true, () -> Boolean.valueOf(!((Boolean)this.once.getValue()).booleanValue()));
/*  42 */     this.range = registerDouble("Range", 5.0D, 0.0D, 10.0D);
/*  43 */     this.yRange = registerDouble("YRange", 5.0D, 0.0D, 10.0D);
/*  44 */     this.targetRange = registerDouble("Target Range", 8.0D, 0.0D, 16.0D);
/*  45 */     this.tickDelay = registerInteger("Tick Delay", 5, 0, 10);
/*  46 */     this.inventory = registerBoolean("Inventory", true);
/*  47 */     this.Slot = registerInteger("Slot", 1, 1, 9);
/*  48 */     this.packetPlace = registerBoolean("Packet Place", true);
/*  49 */     this.placeSwing = registerBoolean("Place Swing", true);
/*  50 */     this.packetSwing = registerBoolean("Packet Swing", true);
/*  51 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.list = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     this.swapped = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     this.deathEventListener = new Listener(event -> { if (event.player == mc.player && ((Boolean)this.disable.getValue()).booleanValue()) disable();  }new java.util.function.Predicate[0]); }
/*     */   private void switchTo(int slot, Runnable runnable) { int oldslot = mc.player.inventory.currentItem; if (slot < 0 || slot == oldslot) { runnable.run(); return; }  if (slot < 9) { boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue(); if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; }  runnable.run(); if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); } else { mc.player.inventory.currentItem = oldslot; }  }  }
/*     */   private int getShulkerSlot() { for (int i = 0; i < mc.player.inventory.mainInventory.size(); i++) { if (mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemBlock && ((ItemBlock)mc.player.inventory.getStackInSlot(i).getItem()).getBlock() instanceof net.minecraft.block.BlockShulkerBox) return i;  }  return -1; }
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null) return false;  return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); }
/*     */   private void initValues() { List<BlockPos> blocks = EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.yRange.getValue()).doubleValue() + 1.0D), false, true, 0); blocks.removeIf(p -> (ColorMain.INSTANCE.breakList.contains(p) || this.list.contains(p))); List<ShulkerPos> posList = new ArrayList<>(); blocks.forEach(pos -> { EnumFacing facing = getFacing(pos); if (facing == null) return;  BlockPos neighbour = pos.offset(facing); EnumFacing opposite = facing.getOpposite(); Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D)); if (inRange(hitVec)) posList.add(new ShulkerPos(pos, facing, neighbour, opposite, hitVec));  }); EntityPlayer target = PlayerUtil.getNearestPlayer(12.0D); if (target == null) { this.blockAim = posList.stream().min(Comparator.comparing(p -> Double.valueOf(p.getRange((EntityPlayer)mc.player)))).orElse(null); } else { this.blockAim = posList.stream().max(Comparator.comparing(p -> Double.valueOf(getWeight(p, target)))).orElse(null); }  if (this.blockAim == null) return;  this.list.add(this.blockAim.pos); }
/*     */   private double getWeight(ShulkerPos pos, EntityPlayer target) { double range = pos.getRange(target); if (range >= ((Double)this.targetRange.getValue()).doubleValue()) { int y = 256 - pos.pos.getY(); range += (y * 100); }  return range; }
/*     */   private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true;  }  return false; }
/*     */   private EnumFacing getFacing(BlockPos pos) { if (intersectsWithEntity(pos) || (!BlockUtil.canReplace(pos) && !(BlockUtil.getBlock(pos) instanceof net.minecraft.block.BlockShulkerBox))) return null;  EnumFacing[] arrayOfEnumFacing; int i; byte b; for (arrayOfEnumFacing = EnumFacing.VALUES, i = arrayOfEnumFacing.length, b = 0; b < i; ) { EnumFacing facing = arrayOfEnumFacing[b]; if (!BlockUtil.canBeClicked(pos.offset(facing)) || !BlockUtil.airBlocks.contains(mc.world.getBlockState(pos.offset(facing, -1)).getBlock())) { b++; continue; }  return facing; }  return null; }
/*     */   private boolean inRange(Vec3d vec) { double x = vec.x - mc.player.posX; double z = vec.z - mc.player.posZ; double y = vec.y - (PlayerUtil.getEyesPos()).y; double add = Math.sqrt(y * y) / 2.0D; return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue()); }
/*     */   private boolean inRange(BlockPos pos) { double x = pos.x + 0.5D - mc.player.posX; double z = pos.z + 0.5D - mc.player.posZ; double y = pos.y + 0.5D - (PlayerUtil.getEyesPos()).y; double add = Math.sqrt(y * y) / 2.0D; return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue()); } public void onUpdate() { if (mc.player == null) return;  if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiShulkerBox) { this.blockAim = null; return; }  if (this.delayTimeTicks < ((Integer)this.tickDelay.getValue()).intValue()) { this.delayTimeTicks++; return; }  this.delayTimeTicks = 0; if ((this.slot = getShulkerSlot()) == -1) return;  if (((Boolean)this.once.getValue()).booleanValue() || InventoryUtil.getEmptyCounts() >= ((Integer)this.counts.getValue()).intValue()) { if (this.blockAim == null) initValues();  } else { checkPos(); }  if (this.blockAim != null) { if (!inRange(this.blockAim.pos)) { this.blockAim = null; return; }  } else { if (((Boolean)this.once.getValue()).booleanValue()) disable();  return; }  if (this.slot > 8 && !this.swapped) { if (!((Boolean)this.inventory.getValue()).booleanValue()) return;  mc.playerController.windowClick(0, this.slot, 0, ClickType.SWAP, (EntityPlayer)mc.player); mc.playerController.windowClick(0, ((Integer)this.Slot.getValue()).intValue() + 35, 0, ClickType.SWAP, (EntityPlayer)mc.player); mc.playerController.windowClick(0, this.slot, 0, ClickType.SWAP, (EntityPlayer)mc.player); mc.playerController.updateController(); this.swapped = true; if (((Integer)this.tickDelay.getValue()).intValue() != 0) return;  }  if (BlockUtil.isAir(this.blockAim.pos) || BlockUtil.canReplace(this.blockAim.pos)) { switchTo(this.slot, () -> { boolean sneak = false; if (BlockUtil.blackList.contains(mc.world.getBlockState(this.blockAim.neighbour).getBlock()) && !mc.player.isSneaking()) { mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING)); sneak = true; }  BurrowUtil.rightClickBlock(this.blockAim.neighbour, this.blockAim.vec, EnumHand.MAIN_HAND, this.blockAim.opposite, ((Boolean)this.packetPlace.getValue()).booleanValue()); if (sneak) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));  if (((Boolean)this.placeSwing.getValue()).booleanValue()) swing();  }); if (((Integer)this.tickDelay.getValue()).intValue() == 0) openBlock();  } else { openBlock(); }  } private void checkPos() { if (!isPos2(PlayerUtil.getPlayerPos(), this.playerPos)) { this.list = new ArrayList<>(); this.playerPos = PlayerUtil.getPlayerPos(); }  } private void swing() { if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND)); } else { mc.player.swingArm(EnumHand.MAIN_HAND); }  } private void openBlock() { mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); EnumFacing side = EnumFacing.getDirectionFromEntityLiving(this.blockAim.pos, (EntityLivingBase)mc.player); BlockPos neighbour = this.blockAim.pos.offset(side); EnumFacing opposite = side.getOpposite(); Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D)); mc.playerController.processRightClickBlock(mc.player, mc.world, this.blockAim.pos, opposite, hitVec, EnumHand.MAIN_HAND); this.blockAim = null; if (((Boolean)this.once.getValue()).booleanValue()) disable();  } public void onEnable() { checkPos(); } static class ShulkerPos
/*     */   {
/* 256 */     BlockPos pos; EnumFacing facing; public ShulkerPos(BlockPos pos, EnumFacing facing, BlockPos neighbour, EnumFacing opposite, Vec3d vec3d) { this.pos = pos;
/* 257 */       this.facing = facing;
/* 258 */       this.neighbour = neighbour;
/* 259 */       this.opposite = opposite;
/* 260 */       this.vec = vec3d; }
/*     */      Vec3d vec; BlockPos neighbour; EnumFacing opposite;
/*     */     public double getRange(EntityPlayer player) {
/* 263 */       return player.getDistance(this.pos.x + 0.5D, this.pos.y + 0.5D, this.pos.z + 0.5D);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AutoShulker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
