//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerPacket;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "BedCev", category = Category.Dev)
/*     */ public class BedCevBreaker extends Module {
/*     */   public static BedCevBreaker INSTANCE;
/*     */   IntegerSetting delay;
/*     */   BooleanSetting helpBlock;
/*     */   DoubleSetting maxRange;
/*     */   BooleanSetting down;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting instantMine;
/*     */   BooleanSetting pickBypass;
/*     */   BooleanSetting strict;
/*     */   public boolean working;
/*     */   boolean offhand;
/*     */   boolean start;
/*     */   boolean anyBed;
/*     */   int blockSlot;
/*     */   int bedSlot;
/*     */   int pickSlot;
/*     */   long time;
/*     */   EnumFacing facing;
/*     */   Vec2f rotation;
/*     */   Timing timer;
/*     */   BlockPos[] side;
/*     */   @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   BlockPos placePos;
/*     */   int lastSlot;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> postSendListener;
/*     */   
/*  57 */   public BedCevBreaker() { this.delay = registerInteger("Delay", 50, 0, 1000);
/*  58 */     this.helpBlock = registerBoolean("Help Block", true);
/*  59 */     this.maxRange = registerDouble("Max Range", 5.0D, 0.0D, 10.0D, () -> (Boolean)this.helpBlock.getValue());
/*  60 */     this.down = registerBoolean("Down Block", true, () -> (Boolean)this.helpBlock.getValue());
/*  61 */     this.packet = registerBoolean("Packet Place", true);
/*  62 */     this.rotate = registerBoolean("Rotate", false);
/*  63 */     this.swing = registerBoolean("Swing", true);
/*  64 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/*  65 */     this.instantMine = registerBoolean("Instant Mine", true);
/*  66 */     this.pickBypass = registerBoolean("Pick Bypass", false);
/*  67 */     this.strict = registerBoolean("Strict", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.timer = new Timing();
/*  75 */     this.side = new BlockPos[] { new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (this.rotation == null || event.getPhase() != Phase.PRE) return;  PlayerPacket packet = new PlayerPacket(this, new Vec2f(this.rotation.x, (PlayerPacketManager.INSTANCE.getServerSideRotation()).y)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     this.sendListener = new Listener(event -> { if (this.rotation != null) { if (event.getPacket() instanceof CPacketPlayer.Rotation) ((CPacketPlayer.Rotation)event.getPacket()).yaw = this.rotation.x;  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = this.rotation.x;  if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketVehicleMove) ((AccessorCPacketVehicleMove)event.getPacket()).setYaw(this.rotation.x);  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     this.postSendListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (event.getPacket() instanceof CPacketHeldItemChange) { int slot = ((CPacketHeldItemChange)event.getPacket()).getSlotId(); if (slot != this.lastSlot) { this.lastSlot = slot; if (((Boolean)this.strict.getValue()).booleanValue()) { EnumFacing facing = BlockUtil.getRayTraceFacing(this.placePos, this.facing); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.placePos, facing)); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, facing)); if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  this.time = System.currentTimeMillis() + calcBreakTime(); }  }  }  }new java.util.function.Predicate[0]); INSTANCE = this; }
/*     */   public void onEnable() { if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.BLOCK || mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock() == Blocks.BEDROCK) { disable(); return; }  this.placePos = mc.objectMouseOver.getBlockPos(); this.start = this.offhand = false; getItem(); doBreak(); this.timer.reset(); }
/*     */   public void fast() { this.working = false; if (mc.world == null || mc.player == null || this.placePos == null || mc.player.isDead) { disable(); return; }  if (!canPlaceBedWithoutBase() || !space(this.placePos)) { disable(); return; }  getItem(); if (!this.anyBed || this.blockSlot == -1 || this.pickSlot == -1) { disable(); return; }  if (this.bedSlot == 0) return;  if (mc.world.isAirBlock(this.placePos.north()) && mc.world.isAirBlock(this.placePos.west()) && mc.world.isAirBlock(this.placePos.east()) && mc.world.isAirBlock(this.placePos.south())) { helpBlock(this.placePos); this.rotation = null; return; }  if (AntiRegear.INSTANCE.working || AntiBurrow.INSTANCE.mining) return;  BlockPos instantPos = null; if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos;  if (instantPos != null) { if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ))) return;  if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ))) return;  if (mc.world.getBlockState(instantPos).getBlock() == Blocks.WEB) return;  }  this.working = true; if (!isPos2(instantPos, this.placePos)) doBreak();  if (!this.start && mc.world.isAirBlock(this.placePos)) { this.time = System.currentTimeMillis() + (((Boolean)this.instantMine.getValue()).booleanValue() ? 0L : calcBreakTime()); this.start = true; }  if (this.time > System.currentTimeMillis())
/*     */       return;  if (this.start && this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) { BlockPos basePos; if (BlockUtil.isAir(this.placePos))
/*     */         run(this.blockSlot, false, () -> BurrowUtil.placeBlock(this.placePos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()));  if (block(this.placePos.east())) { this.rotation = new Vec2f(90.0F, 90.0F); basePos = this.placePos.add(1, 0, 0); } else if (block(this.placePos.north())) { this.rotation = new Vec2f(0.0F, 90.0F); basePos = this.placePos.add(0, 0, -1); } else if (block(this.placePos.west())) { this.rotation = new Vec2f(-90.0F, 90.0F); basePos = this.placePos.add(-1, 0, 0); } else if (block(this.placePos.south())) { this.rotation = new Vec2f(180.0F, 90.0F); basePos = this.placePos.add(0, 0, 1); } else { this.rotation = null; return; }  if ((PlayerPacketManager.INSTANCE.getServerSideRotation()).x != this.rotation.x)
/*     */         return;  EnumHand hand = this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND; EnumFacing opposite = EnumFacing.DOWN.getOpposite(); Vec3d hitVec = (new Vec3d((Vec3i)basePos)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D)); if (BlockUtil.blackList.contains(mc.world.getBlockState(basePos).getBlock()) && !ColorMain.INSTANCE.sneaking)
/*     */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));  run(this.bedSlot, false, () -> { if (((Boolean)this.packet.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(basePos, EnumFacing.UP, hand, 0.5F, 1.0F, 0.5F)); } else { mc.playerController.processRightClickBlock(mc.player, mc.world, basePos, EnumFacing.UP, hitVec, hand); }  if (((Boolean)this.swing.getValue()).booleanValue())
/*     */               mc.player.swingArm(hand);  }); run(this.pickSlot, ((Boolean)this.pickBypass.getValue()).booleanValue(), () -> { this.facing = BlockUtil.getRayTraceFacing(this.placePos, EnumFacing.UP); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, this.facing)); if (!((Boolean)this.instantMine.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.placePos, this.facing)); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, this.facing)); this.time = System.currentTimeMillis() + calcBreakTime(); }  if (((Boolean)this.swing.getValue()).booleanValue())
/*     */               mc.player.swingArm(EnumHand.MAIN_HAND);  }); EnumFacing side = EnumFacing.UP; Vec3d vec = getHitVecOffset(side); mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placePos.up(), side, hand, (float)vec.x, (float)vec.y, (float)vec.z)); if (((Boolean)this.swing.getValue()).booleanValue())
/*     */         mc.player.swingArm(hand);  this.timer.reset(); }  }
/*     */   private Vec3d getHitVecOffset(EnumFacing face) { Vec3i vec = face.getDirectionVec(); return new Vec3d((vec.x * 0.5F + 0.5F), (vec.y * 0.5F + 0.5F), (vec.z * 0.5F + 0.5F)); }
/*     */   private void helpBlock(BlockPos pos) { NonNullList<BlockPos> nonNullList = NonNullList.create(); for (BlockPos side : this.side)
/*     */       nonNullList.add(pos.add((Vec3i)side));  if (((Boolean)this.down.getValue()).booleanValue())
/*     */       nonNullList.add(pos.down());  BlockPos finalPos = nonNullList.stream().filter(p -> (mc.player.getDistanceSq(p) <= ((Double)this.maxRange.getValue()).doubleValue() * ((Double)this.maxRange.getValue()).doubleValue())).filter(this::canPlaceBase).max(Comparator.comparing(p -> Double.valueOf(mc.player.getDistanceSq(p)))).orElse(null); run(this.blockSlot, false, () -> BurrowUtil.placeBlock(finalPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue())); }
/*     */   private boolean canPlaceBase(BlockPos pos) { if (ColorMain.INSTANCE.breakList.contains(pos))
/*     */       return false;  if (BurrowUtil.getBedFacing(pos) == null)
/*     */       return false;  return (space(pos) && !intersectsWithEntity(pos)); }
/*     */   private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/*     */         return true;  }  return false; }
/* 331 */   private boolean canPlaceBedWithoutBase() { return (space(this.placePos) && (space(this.placePos.east()) || space(this.placePos.north()) || space(this.placePos.west()) || space(this.placePos.south()))); } private int calcBreakTime() { return getBreakTime() * 70; }
/*     */   private boolean block(BlockPos pos) { if (BlockUtil.canReplace(pos)) return false;  return (space(pos) && solid(pos)); }
/*     */   private boolean solid(BlockPos pos) { return (!BlockUtil.isBlockUnSolid(pos) && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockBed) && mc.world.getBlockState(pos).isSideSolid((IBlockAccess)mc.world, pos, EnumFacing.UP) && (BlockUtil.getBlock(pos)).fullBlock); }
/*     */   private boolean space(BlockPos pos) { return (mc.world.getBlockState(pos.up()).getBlock() == Blocks.BED || mc.world.isAirBlock(pos.up())); }
/* 335 */   private void getItem() { this.blockSlot = this.bedSlot = this.pickSlot = -1; this.anyBed = false; if (mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemEndCrystal) { this.bedSlot = 11; this.offhand = true; }  for (int i = 0; i < 36; i++) { ItemStack stack = mc.player.inventory.getStackInSlot(i); if (stack != ItemStack.EMPTY && stack.getItem() instanceof net.minecraft.item.ItemBed) { this.anyBed = true; if (i < 9) this.bedSlot = i;  break; }  }  this.blockSlot = BurrowUtil.findHotbarBlock(BlockObsidian.class); this.pickSlot = findItem(); } private void doBreak() { if (this.placePos == null || mc.world.isAirBlock(this.placePos) || mc.world.getBlockState(this.placePos).getBlock() == Blocks.BEDROCK) return;  if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  mc.playerController.onPlayerDamageBlock(this.placePos, BlockUtil.getRayTraceFacing(this.placePos, EnumFacing.UP)); } private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null) return false;  return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); } private void run(int slot, boolean bypass, Runnable runnable) { int oldslot = mc.player.inventory.currentItem; if (slot < 0 || slot == oldslot) { runnable.run(); return; }  if (bypass || slot > 8) { if (slot < 9) slot += 36;  mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, ItemStack.EMPTY, mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); runnable.run(); mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, ItemStack.EMPTY, mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); } else { if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; }  runnable.run(); if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); } else { mc.player.inventory.currentItem = oldslot; }  }  } private int getBreakTime() { float hardness = 50.0F;
/* 336 */     float breakSpeed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState());
/* 337 */     if (breakSpeed < 0.0F)
/* 338 */       return -1; 
/* 339 */     float relativeDamage = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState()) / hardness / 30.0F;
/* 340 */     return (int)Math.ceil((0.7F / relativeDamage)); }
/*     */ 
/*     */   
/*     */   private int findItem() {
/* 344 */     int result = mc.player.inventory.currentItem;
/* 345 */     double speed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState(), mc.player.getHeldItemMainhand());
/* 346 */     for (int i = 0; i < (((Boolean)this.pickBypass.getValue()).booleanValue() ? 36 : 9); i++) {
/* 347 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 348 */       double stackSpeed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState(), stack);
/* 349 */       if (stackSpeed > speed) {
/* 350 */         speed = stackSpeed;
/* 351 */         result = i;
/*     */       } 
/*     */     } 
/*     */     
/* 355 */     return result;
/*     */   }
/*     */   private double getSpeed(IBlockState state, ItemStack stack) {
/* 358 */     double str = stack.getDestroySpeed(state);
/* 359 */     int effect = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
/* 360 */     return Math.max(str + ((str > 1.0D) ? ((effect * effect) + 1.0D) : 0.0D), 0.0D);
/*     */   }
/*     */   
/*     */   private float getSpeed(IBlockState blockState) {
/* 364 */     ItemStack itemStack = mc.player.inventory.getStackInSlot(this.pickSlot);
/*     */     
/* 366 */     float digSpeed = mc.player.inventory.getStackInSlot(this.pickSlot).getDestroySpeed(blockState); int efficiencyModifier;
/* 367 */     if (!itemStack.isEmpty() && digSpeed > 1.0D && (efficiencyModifier = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, itemStack)) > 0) {
/* 368 */       digSpeed += (float)(StrictMath.pow(efficiencyModifier, 2.0D) + 1.0D);
/*     */     }
/* 370 */     if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 371 */       digSpeed *= 1.0F + (mc.player.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
/*     */     }
/* 373 */     if (mc.player.isPotionActive(MobEffects.MINING_FATIGUE)) {
/*     */       float fatigueScale;
/* 375 */       switch (mc.player.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
/*     */         case 0:
/* 377 */           fatigueScale = 0.3F;
/*     */           break;
/*     */         
/*     */         case 1:
/* 381 */           fatigueScale = 0.09F;
/*     */           break;
/*     */         
/*     */         case 2:
/* 385 */           fatigueScale = 0.0027F;
/*     */           break;
/*     */         
/*     */         default:
/* 389 */           fatigueScale = 8.1E-4F;
/*     */           break;
/*     */       } 
/* 392 */       digSpeed *= fatigueScale;
/*     */     } 
/* 394 */     if (mc.player.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier((EntityLivingBase)mc.player)) {
/* 395 */       digSpeed /= 5.0F;
/*     */     }
/* 397 */     return digSpeed;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\BedCevBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
