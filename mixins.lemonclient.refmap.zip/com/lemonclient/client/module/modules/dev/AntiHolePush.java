//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AntiHolePush", category = Category.Dev)
/*     */ public class AntiHolePush extends Module {
/*  28 */   ModeSetting timeMode = registerMode("Time Mode", Arrays.asList(new String[] { "onUpdate", "Tick", "Both", "Fast" }, ), "Fast");
/*  29 */   BooleanSetting packet = registerBoolean("Packet Place", false);
/*  30 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  31 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  32 */   BooleanSetting strict = registerBoolean("Strict", true);
/*  33 */   BooleanSetting raytrace = registerBoolean("RayTrace", true);
/*  34 */   BooleanSetting trap = registerBoolean("Trap", true);
/*  35 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", false);
/*  36 */   BooleanSetting entityCheck = registerBoolean("Entity Check", true);
/*  37 */   BooleanSetting breakPiston = registerBoolean("Break Piston", false);
/*     */   
/*     */   private void switchTo(int slot, Runnable runnable) {
/*  40 */     int oldslot = mc.player.inventory.currentItem;
/*  41 */     if (slot < 0 || slot == oldslot) {
/*  42 */       runnable.run();
/*     */       return;
/*     */     } 
/*  45 */     if (slot < 9) {
/*  46 */       boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue();
/*  47 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*  48 */       else { mc.player.inventory.currentItem = slot; }
/*  49 */        runnable.run();
/*  50 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/*  51 */       else { mc.player.inventory.currentItem = oldslot; }
/*     */     
/*     */     } 
/*     */   }
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/*  56 */     for (Entity entity : mc.world.loadedEntityList) {
/*  57 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/*  58 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/*  59 */         return true; 
/*     */     } 
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  66 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("onUpdate") || ((String)this.timeMode.getValue()).equalsIgnoreCase("Both")) {
/*  67 */       block();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onTick() {
/*  72 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("Tick") || ((String)this.timeMode.getValue()).equalsIgnoreCase("Both")) {
/*  73 */       block();
/*     */     }
/*     */   }
/*     */   
/*     */   public void fast() {
/*  78 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("Fast"))
/*  79 */       block(); 
/*     */   }
/*     */   
/*     */   private void block() {
/*  83 */     if (mc.player == null || mc.world == null)
/*  84 */       return;  BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
/*  85 */     int obsidian = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  86 */     if (obsidian == -1)
/*  87 */       return;  BlockPos head = pos.add(0, 2, 0);
/*  88 */     BlockPos pos1 = pos.add(1, 1, 0);
/*  89 */     BlockPos pos2 = pos.add(-1, 1, 0);
/*  90 */     BlockPos pos3 = pos.add(0, 1, 1);
/*  91 */     BlockPos pos4 = pos.add(0, 1, -1);
/*  92 */     if (!airBlock(head))
/*  93 */       return;  List<BlockPos> posList = new ArrayList<>();
/*  94 */     if (isPiston(pos1) && 
/*  95 */       isFacing(pos1, EnumFacing.WEST)) {
/*  96 */       BlockPos pos5 = pos.add(-1, 2, 0);
/*  97 */       if (airBlock(pos2) && airBlock(pos5)) posList.add(pos2); 
/*  98 */       if (((Boolean)this.trap.getValue()).booleanValue() && airBlock(head)) {
/*  99 */         posList.add(pos2.up());
/* 100 */         posList.add(head);
/*     */       } 
/* 102 */       if (((Boolean)this.breakPiston.getValue()).booleanValue()) mc.playerController.onPlayerDamageBlock(pos1, BlockUtil.getRayTraceFacing(pos3));
/*     */     
/*     */     } 
/* 105 */     if (isPiston(pos2) && 
/* 106 */       isFacing(pos2, EnumFacing.EAST)) {
/* 107 */       BlockPos pos6 = pos.add(1, 2, 0);
/* 108 */       if (airBlock(pos1) && airBlock(pos6)) posList.add(pos1); 
/* 109 */       if (((Boolean)this.trap.getValue()).booleanValue() && airBlock(head)) {
/* 110 */         posList.add(pos1.up());
/* 111 */         posList.add(head);
/*     */       } 
/* 113 */       if (((Boolean)this.breakPiston.getValue()).booleanValue()) mc.playerController.onPlayerDamageBlock(pos2, BlockUtil.getRayTraceFacing(pos3));
/*     */     
/*     */     } 
/* 116 */     if (isPiston(pos3) && 
/* 117 */       isFacing(pos3, EnumFacing.NORTH)) {
/* 118 */       BlockPos pos7 = pos.add(0, 2, -1);
/* 119 */       if (airBlock(pos4) && airBlock(pos7)) posList.add(pos4); 
/* 120 */       if (((Boolean)this.trap.getValue()).booleanValue() && airBlock(head)) {
/* 121 */         posList.add(pos4.up());
/* 122 */         posList.add(head);
/*     */       } 
/* 124 */       if (((Boolean)this.breakPiston.getValue()).booleanValue()) mc.playerController.onPlayerDamageBlock(pos3, BlockUtil.getRayTraceFacing(pos3));
/*     */     
/*     */     } 
/* 127 */     if (isPiston(pos4) && 
/* 128 */       isFacing(pos4, EnumFacing.SOUTH)) {
/* 129 */       BlockPos pos8 = pos.add(0, 2, 1);
/* 130 */       if (airBlock(pos3) && airBlock(pos8)) posList.add(pos3); 
/* 131 */       if (((Boolean)this.trap.getValue()).booleanValue() && airBlock(head)) {
/* 132 */         posList.add(pos3.up());
/* 133 */         posList.add(head);
/*     */       } 
/* 135 */       if (((Boolean)this.breakPiston.getValue()).booleanValue()) mc.playerController.onPlayerDamageBlock(pos4, BlockUtil.getRayTraceFacing(pos3));
/*     */     
/*     */     } 
/* 138 */     if (!posList.isEmpty())
/* 139 */       switchTo(obsidian, () -> {
/*     */             for (BlockPos placePos : posList)
/*     */               perform(placePos); 
/*     */           }); 
/*     */   }
/*     */   
/*     */   private IBlockState getBlock(BlockPos block) {
/* 146 */     return mc.world.getBlockState(block);
/*     */   }
/*     */   
/*     */   private boolean airBlock(BlockPos pos) {
/* 150 */     return BlockUtil.airBlocks.contains(getBlock(pos).getBlock());
/*     */   }
/*     */   
/*     */   private void perform(BlockPos pos) {
/* 154 */     if ((((Boolean)this.entityCheck.getValue()).booleanValue() && intersectsWithEntity(pos)) || !BlockUtil.canPlace(pos, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue()))
/* 155 */       return;  BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/*     */   }
/*     */   
/*     */   public static boolean isFacing(BlockPos pos, EnumFacing enumFacing) {
/* 159 */     ImmutableMap<IProperty<?>, Comparable<?>> properties = mc.world.getBlockState(pos).getProperties();
/* 160 */     for (UnmodifiableIterator<IProperty> unmodifiableIterator = properties.keySet().iterator(); unmodifiableIterator.hasNext(); ) { IProperty<?> prop = unmodifiableIterator.next();
/* 161 */       if (prop.getValueClass() == EnumFacing.class && (prop.getName().equals("facing") || prop.getName().equals("rotation")) && properties.get(prop) == enumFacing) {
/* 162 */         return true;
/*     */       } }
/*     */     
/* 165 */     return false;
/*     */   }
/*     */   private boolean isPiston(BlockPos pos) {
/* 168 */     return (mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockPistonMoving || mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockPistonBase || mc.world.getBlockState(pos).getBlock() == Blocks.PISTON || mc.world.getBlockState(pos).getBlock() == Blocks.STICKY_PISTON);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AntiHolePush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
