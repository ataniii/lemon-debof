//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.dev;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.misc.Pair;
/*    */ import com.lemonclient.api.util.player.InventoryUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.List;
/*    */ import net.minecraft.enchantment.EnchantmentHelper;
/*    */ import net.minecraft.entity.EnumCreatureAttribute;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemSword;
/*    */ import net.minecraft.util.NonNullList;
/*    */ 
/*    */ @Declaration(name = "SwordSwitch", category = Category.Dev)
/*    */ public class SwordSwitch extends Module {
/* 19 */   BooleanSetting disable = registerBoolean("Disable", true);
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 23 */     Pair<Float, Integer> newSlot = new Pair(Float.valueOf(0.0F), Integer.valueOf(-1));
/* 24 */     newSlot = findSwordSlot();
/* 25 */     if (((Integer)newSlot.getValue()).intValue() != -1) {
/* 26 */       mc.player.inventory.currentItem = ((Integer)newSlot.getValue()).intValue();
/*    */     } else {
/* 28 */       MessageBus.sendClientPrefixMessage("Cant find sword", Notification.Type.ERROR);
/* 29 */       disable();
/*    */       return;
/*    */     } 
/* 32 */     if (((Boolean)this.disable.getValue()).booleanValue()) {
/* 33 */       disable();
/*    */     }
/*    */   }
/*    */   
/*    */   private Pair<Float, Integer> findSwordSlot() {
/* 38 */     List<Integer> items = InventoryUtil.findAllItemSlots(ItemSword.class);
/* 39 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*    */     
/* 41 */     float bestModifier = 0.0F;
/* 42 */     int correspondingSlot = -1;
/* 43 */     for (Integer integer : items) {
/* 44 */       if (integer.intValue() > 8) {
/*    */         continue;
/*    */       }
/*    */       
/* 48 */       ItemStack stack = nonNullList.get(integer.intValue());
/* 49 */       float modifier = (EnchantmentHelper.getModifierForCreature(stack, EnumCreatureAttribute.UNDEFINED) + 1.0F) * ((ItemSword)stack.getItem()).getAttackDamage();
/*    */       
/* 51 */       if (modifier > bestModifier) {
/* 52 */         bestModifier = modifier;
/* 53 */         correspondingSlot = integer.intValue();
/*    */       } 
/*    */     } 
/*    */     
/* 57 */     return new Pair(Float.valueOf(bestModifier), Integer.valueOf(correspondingSlot));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\SwordSwitch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
