//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.List;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "AntiHoleCamper", category = Category.Dev, priority = 1000)
/*     */ public class AntiHoleCamper extends Module {
/*     */   IntegerSetting delay;
/*     */   BooleanSetting pause;
/*     */   ModeSetting mode;
/*     */   IntegerSetting range;
/*     */   BooleanSetting look;
/*     */   BooleanSetting ground;
/*     */   BooleanSetting box;
/*     */   BooleanSetting hole;
/*     */   BooleanSetting pushCheck;
/*     */   BooleanSetting headCheck;
/*     */   BooleanSetting breakRedstone;
/*     */   BooleanSetting pushedCheck;
/*     */   ModeSetting breakBlock;
/*     */   BooleanSetting packetPiston;
/*     */   BooleanSetting packetRedstone;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting block;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting update;
/*     */   BooleanSetting force;
/*     */   BooleanSetting strict;
/*     */   BooleanSetting raytrace;
/*     */   DoubleSetting maxSpeed;
/*     */   BooleanSetting debug;
/*     */   ModeSetting disable;
/*     */   private final Timing timer;
/*     */   BlockPos beforePlayerPos;
/*     */   BlockPos pistonPos;
/*     */   BlockPos redstonePos;
/*     */   PistonPos pos;
/*     */   boolean useBlock;
/*     */   int redstoneSlot;
/*     */   int pistonSlot;
/*     */   int obsiSlot;
/*     */   int waited;
/*     */   int[] enemyCoordsInt;
/*     */   EntityPlayer aimTarget;
/*     */   Vec2f rotation;
/*     */   Vec3d[] sides;
/*     */   @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   
/*  57 */   public AntiHoleCamper() { this.delay = registerInteger("Delay", 0, 0, 20);
/*  58 */     this.pause = registerBoolean("Pause When Move", true);
/*  59 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Block", "Torch", "Both" }, ), "Block");
/*  60 */     this.range = registerInteger("Range", 6, 0, 10);
/*  61 */     this.look = registerBoolean("Looking Target", false);
/*  62 */     this.ground = registerBoolean("OnGround Check", true);
/*  63 */     this.box = registerBoolean("Entity Box", true);
/*  64 */     this.hole = registerBoolean("Double Hole Check", false);
/*  65 */     this.pushCheck = registerBoolean("Push Check", false);
/*  66 */     this.headCheck = registerBoolean("Head Check", false);
/*  67 */     this.breakRedstone = registerBoolean("Break Redstone", false);
/*  68 */     this.pushedCheck = registerBoolean("Pushed Check", true, () -> (Boolean)this.breakRedstone.getValue());
/*  69 */     this.breakBlock = registerMode("Break Block", Arrays.asList(new String[] { "Normal", "Packet" }, ), "Packet", () -> (Boolean)this.breakRedstone.getValue());
/*  70 */     this.packetPiston = registerBoolean("Packet Place Piston", true);
/*  71 */     this.packetRedstone = registerBoolean("Packet Place Redstone", true);
/*  72 */     this.swing = registerBoolean("Swing", true);
/*  73 */     this.rotate = registerBoolean("Rotate", false);
/*  74 */     this.block = registerBoolean("Place Block", true);
/*  75 */     this.packet = registerBoolean("Packet Place", true, () -> (Boolean)this.block.getValue());
/*  76 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/*  77 */     this.update = registerBoolean("Update Controller", true);
/*  78 */     this.force = registerBoolean("Force Rotate", true);
/*  79 */     this.strict = registerBoolean("Strict", true);
/*  80 */     this.raytrace = registerBoolean("RayTrace", true);
/*  81 */     this.maxSpeed = registerDouble("Max Target Speed", 5.0D, 0.0D, 50.0D);
/*  82 */     this.debug = registerBoolean("Debug Msg", true);
/*  83 */     this.disable = registerMode("Disable Mode", Arrays.asList(new String[] { "NoDisable", "Check", "AutoDisable" }, ), "AutoDisable");
/*  84 */     this.timer = new Timing();
/*     */ 
/*     */     
/*  87 */     this.pos = null;
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.aimTarget = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.sides = new Vec3d[] { new Vec3d(0.25D, 0.0D, 0.25D), new Vec3d(-0.25D, 0.0D, 0.25D), new Vec3d(0.25D, 0.0D, -0.25D), new Vec3d(-0.25D, 0.0D, -0.25D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (event.getPhase() != Phase.PRE || this.rotation == null) return;  PlayerPacket packet = new PlayerPacket(this, new Vec2f(this.rotation.x, (PlayerPacketManager.INSTANCE.getServerSideRotation()).y)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     this.sendListener = new Listener(event -> { if (this.rotation != null && ((Boolean)this.force.getValue()).booleanValue()) { if (event.getPacket() instanceof CPacketPlayer.Rotation) ((CPacketPlayer.Rotation)event.getPacket()).yaw = this.rotation.x;  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = this.rotation.x;  }  }new java.util.function.Predicate[0]); }
/*     */   private void switchTo(int slot, Runnable runnable) { int oldslot = mc.player.inventory.currentItem; if (slot < 0 || slot == oldslot) { runnable.run(); return; }
/*     */      if (slot < 9) { boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue(); if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else { mc.player.inventory.currentItem = slot; }
/*     */        if (((Boolean)this.update.getValue()).booleanValue())
/*     */         mc.playerController.updateController();  runnable.run(); if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/*     */       else
/*     */       { mc.player.inventory.currentItem = oldslot; }
/*     */        }
/*     */      }
/*     */   private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) {
/*     */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/*     */         return true; 
/* 189 */     }  return false; } public void onTick() { if (mc.world == null || mc.player == null || mc.player.isDead) {
/* 190 */       disable();
/*     */       return;
/*     */     } 
/* 193 */     this.rotation = null;
/* 194 */     this.aimTarget = null;
/*     */     
/* 196 */     this.redstoneSlot = this.pistonSlot = this.obsiSlot - 1;
/* 197 */     if (!ready()) {
/* 198 */       if (!((String)this.disable.getValue()).equals("NoDisable")) disable();
/*     */       
/*     */       return;
/*     */     } 
/* 202 */     if (!((Boolean)this.look.getValue()).booleanValue()) { this.aimTarget = PlayerUtil.getNearestPlayer(((Integer)this.range.getValue()).intValue() + 1.5D); }
/* 203 */     else { this.aimTarget = PlayerUtil.findLookingPlayer(((Integer)this.range.getValue()).intValue() + 1.5D); }
/* 204 */      this.pos = null;
/* 205 */     if (this.aimTarget != null) {
/* 206 */       if (LemonClient.speedUtil.getPlayerSpeed(this.aimTarget) > ((Double)this.maxSpeed.getValue()).doubleValue())
/* 207 */         return;  if (!this.aimTarget.onGround && ((Boolean)this.ground.getValue()).booleanValue())
/* 208 */         return;  this.beforePlayerPos = new BlockPos(this.aimTarget.posX, this.aimTarget.posY, this.aimTarget.posZ);
/* 209 */       this.enemyCoordsInt = new int[] { (int)this.aimTarget.posX, (int)this.aimTarget.posY, (int)this.aimTarget.posZ };
/* 210 */       if (((Boolean)this.box.getValue()).booleanValue())
/* 211 */       { List<PistonPos> list = new ArrayList<>();
/* 212 */         for (Vec3d side : this.sides) {
/* 213 */           Vec3d vec3d = new Vec3d(this.aimTarget.posX + side.x, this.aimTarget.posY, this.aimTarget.posZ + side.z);
/* 214 */           BlockPos blockPos = vec3toBlockPos(vec3d);
/* 215 */           PistonPos piston = getPos(blockPos, blockPos);
/* 216 */           if (piston != null) list.add(piston);
/*     */         
/*     */         } 
/* 219 */         this
/*     */           
/* 221 */           .pos = list.stream().filter(p -> (p.getMaxRange() <= ((Integer)this.range.getValue()).intValue())).min(Comparator.comparing(PistonPos::getMaxRange)).orElse(null); }
/* 222 */       else { this.pos = getPos(this.beforePlayerPos, this.beforePlayerPos); }
/* 223 */        if (this.pos == null)
/* 224 */         if (((Boolean)this.box.getValue()).booleanValue())
/* 225 */         { List<PistonPos> list = new ArrayList<>();
/* 226 */           for (Vec3d side : this.sides) {
/* 227 */             Vec3d vec3d = new Vec3d(this.aimTarget.posX + side.x, this.aimTarget.posY, this.aimTarget.posZ + side.z);
/* 228 */             BlockPos blockPos = vec3toBlockPos(vec3d);
/* 229 */             PistonPos piston = getPos(blockPos.up(), blockPos);
/* 230 */             if (piston != null) {
/* 231 */               list.add(piston);
/*     */             }
/*     */           } 
/*     */           
/* 235 */           this
/*     */             
/* 237 */             .pos = list.stream().filter(p -> (p.getMaxRange() <= ((Integer)this.range.getValue()).intValue())).min(Comparator.comparing(PistonPos::getMaxRange)).orElse(null); }
/* 238 */         else { this.pos = getPos(this.beforePlayerPos.up(), this.beforePlayerPos); }
/*     */          
/*     */     } else {
/* 241 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendClientDeleteMessage("Cant find target", Notification.Type.ERROR, "AntiCamp", 7); 
/* 242 */       if (!((String)this.disable.getValue()).equals("NoDisable")) disable();
/*     */     
/*     */     } 
/* 245 */     if (this.pistonPos != null && this.beforePlayerPos != null) {
/* 246 */       float[] angle = MathUtil.calcAngle(new Vec3d(this.pistonPos.x, 0.0D, this.pistonPos.z), new Vec3d(this.beforePlayerPos.x, 0.0D, this.beforePlayerPos.z));
/* 247 */       this.rotation = new Vec2f(angle[0] + 180.0F, angle[1]);
/*     */     } 
/*     */     
/* 250 */     if (this.waited++ < ((Integer)this.delay.getValue()).intValue() || (MotionUtil.isMoving((EntityLivingBase)mc.player) && ((Boolean)this.pause.getValue()).booleanValue()))
/*     */       return; 
/* 252 */     this.waited = 0;
/*     */     
/* 254 */     boolean placed = false;
/* 255 */     if (this.pos != null) {
/* 256 */       this.pistonPos = this.pos.piston;
/* 257 */       this.redstonePos = this.pos.redstone;
/* 258 */       this.beforePlayerPos = this.pos.calcPos;
/* 259 */       if (BurrowUtil.getFirstFacing(this.redstonePos) == null) {
/* 260 */         placePiston(this.pistonPos);
/* 261 */         placeRedstone(this.redstonePos);
/*     */       } else {
/* 263 */         placeRedstone(this.redstonePos);
/* 264 */         placePiston(this.pistonPos);
/*     */       } 
/*     */     } 
/* 267 */     if (((Boolean)this.block.getValue()).booleanValue() && this.beforePlayerPos != null)
/* 268 */     { if (this.timer.passedMs(500L)) {
/* 269 */         switchTo(this.obsiSlot, () -> BlockUtil.placeBlock(this.beforePlayerPos, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue()));
/* 270 */         this.beforePlayerPos = null;
/* 271 */         if (((String)this.disable.getValue()).equals("AutoDisable")) {
/* 272 */           disable();
/*     */           return;
/*     */         } 
/*     */       }  }
/* 276 */     else if (((String)this.disable.getValue()).equals("AutoDisable")) { disable(); }
/* 277 */      if (this.beforePlayerPos != null) {
/* 278 */       placed = (mc.world.getBlockState(this.beforePlayerPos).getBlock() == Blocks.OBSIDIAN);
/* 279 */       if (((Boolean)this.breakRedstone.getValue()).booleanValue() && this.redstonePos != null && !airBlock(this.redstonePos) && (
/* 280 */         !((Boolean)this.pushedCheck.getValue()).booleanValue() || mc.world.getBlockState(this.beforePlayerPos).getBlock() == Blocks.PISTON_HEAD || mc.world.getBlockState(this.beforePlayerPos.up()).getBlock() == Blocks.PISTON_HEAD)) {
/* 281 */         doBreak(this.redstonePos);
/*     */       }
/*     */     } 
/* 284 */     if (placed) this.beforePlayerPos = null;
/*     */     
/* 286 */     if (((String)this.disable.getValue()).equals("Check") && (!((Boolean)this.block.getValue()).booleanValue() || placed))
/* 287 */       disable();  }
/*     */   private boolean airBlock(BlockPos pos) { return BlockUtil.canReplace(pos); }
/*     */   private boolean canPlacePiston(BlockPos pos, EnumFacing facing) { BlockPos p = pos.offset(facing); BlockPos push = pos.offset(facing, -1); double feetY = mc.player.posY; return (((!intersectsWithEntity(p) && airBlock(p) && (PlayerUtil.getDistanceI(p) >= 1.4D + p.getY() - feetY || p.getY() <= feetY + 1.0D) && (PlayerUtil.getDistanceI(p) >= 2.4D + feetY - p.getY() || p.getY() >= feetY) && BlockUtil.canPlaceWithoutBase(p, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), true)) || (isFacing(p, pos) && (mc.world.getBlockState(p).getBlock() instanceof net.minecraft.block.BlockPistonBase || mc.world.getBlockState(p).getBlock() == Blocks.PISTON || mc.world.getBlockState(p).getBlock() == Blocks.STICKY_PISTON))) && (!((Boolean)this.hole.getValue()).booleanValue() || airBlock(push)) && (!((Boolean)this.pushCheck.getValue()).booleanValue() || (airBlock(push.up()) && (airBlock(push.up(2)) || airBlock(push))))); }
/*     */   public BlockPos getRedstonePos(BlockPos pistonPos) { BlockPos pos = hasRedstoneBlock(pistonPos); if (pos != null) return pos;  List<BlockPos> redstone = new ArrayList<>(); if (this.useBlock) { for (EnumFacing facing : EnumFacing.VALUES) redstone.add(pistonPos.offset(facing));  } else { BlockPos[] offsets = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) }; for (BlockPos offs : offsets) { for (int i = 0; i < 2; i++) { BlockPos torch = pistonPos.down(i).add((Vec3i)offs); if (i != 1 || !BlockUtil.isBlockUnSolid(torch.up())) redstone.add(torch);  }  }  }  redstone = (List<BlockPos>)redstone.stream().filter(p -> (!ColorMain.INSTANCE.breakList.contains(p) && !intersectsWithEntity(p) && mc.player.getDistance(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D) <= ((Integer)this.range.getValue()).intValue())).collect(Collectors.toList()); if (redstone.isEmpty()) return null;  List<BlockPos> hasBase = (List<BlockPos>)redstone.stream().filter(p -> BlockUtil.canPlaceWithoutBase(p, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), false)).collect(Collectors.toList()); if (hasBase.isEmpty())
/* 291 */       hasBase.addAll(redstone);  return hasBase.stream().min(Comparator.comparing(mc.player::getDistanceSq)).orElse(null); } private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null)
/* 292 */       return false; 
/* 293 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); }
/*     */ 
/*     */   
/*     */   private void placePiston(BlockPos pistonPos) {
/* 297 */     if (!BlockUtil.isAir(pistonPos))
/* 298 */       return;  mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(this.rotation.x, this.rotation.y, true));
/* 299 */     switchTo(this.pistonSlot, () -> {
/*     */           BlockUtil.placeBlock(pistonPos, false, ((Boolean)this.packetPiston.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/*     */           if (((Boolean)this.rotate.getValue()).booleanValue())
/*     */             EntityUtil.facePlacePos(pistonPos, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue()); 
/*     */         });
/*     */   }
/*     */   private void placeRedstone(BlockPos redstonePos) {
/* 306 */     if (!this.useBlock && mc.world.getBlockState(redstonePos.down()).getBlock() == Blocks.AIR) {
/* 307 */       BlockPos obsiPos = new BlockPos(redstonePos.x, redstonePos.y - 1, redstonePos.z);
/* 308 */       switchTo(this.obsiSlot, () -> BlockUtil.placeBlock(obsiPos, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue()));
/*     */     } 
/* 310 */     switchTo(this.redstoneSlot, () -> BlockUtil.placeBlock(redstonePos, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetRedstone.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue()));
/*     */   }
/*     */   
/*     */   private PistonPos getPos(BlockPos calcPos, BlockPos playerPos) {
/* 314 */     if (mc.world.getBlockState(calcPos).getBlock() == Blocks.BEDROCK || mc.world.getBlockState(calcPos).getBlock() == Blocks.OBSIDIAN)
/* 315 */       return null; 
/* 316 */     List<PistonPos> posList = new ArrayList<>();
/*     */     
/* 318 */     if (((Boolean)this.headCheck.getValue()).booleanValue() && !airBlock(playerPos.up(2))) return null;
/*     */     
/* 320 */     for (EnumFacing facing : EnumFacing.VALUES) {
/* 321 */       if (facing != EnumFacing.UP && facing != EnumFacing.DOWN && 
/* 322 */         canPlacePiston(calcPos, facing)) {
/* 323 */         BlockPos pistonPos = calcPos.offset(facing);
/* 324 */         BlockPos redstonePos = getRedstonePos(pistonPos);
/* 325 */         if (redstonePos != null && (
/* 326 */           BlockUtil.hasNeighbour(redstonePos) || BlockUtil.hasNeighbour(pistonPos))) {
/* 327 */           posList.add(new PistonPos(pistonPos, redstonePos, calcPos));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 332 */     return posList.stream()
/* 333 */       .filter(p -> (p.getMaxRange() <= ((Integer)this.range.getValue()).intValue()))
/* 334 */       .min(Comparator.comparing(PistonPos::getMaxRange)).orElse(null);
/*     */   }
/*     */   
/*     */   public static BlockPos vec3toBlockPos(Vec3d vec3d) {
/* 338 */     return new BlockPos(Math.floor(vec3d.x), Math.round(vec3d.y), Math.floor(vec3d.z));
/*     */   }
/*     */   
/*     */   private boolean ready() {
/* 342 */     this.pistonSlot = findHotbarBlock((Block)Blocks.PISTON);
/* 343 */     if (this.pistonSlot == -1) this.pistonSlot = findHotbarBlock((Block)Blocks.STICKY_PISTON); 
/* 344 */     this.redstoneSlot = !((String)this.mode.getValue()).equals("Torch") ? findHotbarBlock(Blocks.REDSTONE_BLOCK) : findHotbarBlock(Blocks.REDSTONE_TORCH);
/* 345 */     if (((String)this.mode.getValue()).equals("Both") && this.redstoneSlot == -1) this.redstoneSlot = findHotbarBlock(Blocks.REDSTONE_TORCH); 
/* 346 */     this.obsiSlot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*     */     
/* 348 */     if (this.redstoneSlot == -1) {
/* 349 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendClientDeleteMessage("Cant find Redstone", Notification.Type.ERROR, "AntiCamp", 7); 
/* 350 */       return false;
/*     */     } 
/* 352 */     this.useBlock = (this.redstoneSlot == findHotbarBlock(Blocks.REDSTONE_BLOCK));
/*     */ 
/*     */     
/* 355 */     if ((!this.useBlock || ((Boolean)this.block.getValue()).booleanValue()) && this.obsiSlot == -1) {
/* 356 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendClientDeleteMessage("Cant find Obsidian", Notification.Type.ERROR, "AntiCamp", 7); 
/* 357 */       return false;
/*     */     } 
/*     */     
/* 360 */     if (BurrowUtil.findHotbarBlock(ItemPiston.class) == -1) {
/* 361 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendClientDeleteMessage("Cant find Piston", Notification.Type.ERROR, "AntiCamp", 7); 
/* 362 */       return false;
/*     */     } 
/* 364 */     return true;
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Block blockIn) {
/* 368 */     for (int i = 0; i < 9; ) {
/* 369 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 370 */       if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock) || ((ItemBlock)stack.getItem()).getBlock() != blockIn) {
/*     */         i++; continue;
/* 372 */       }  return i;
/*     */     } 
/* 374 */     return -1;
/*     */   }
/*     */   
/*     */   private void doBreak(BlockPos pos) {
/* 378 */     if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND); 
/* 379 */     if (((String)this.breakBlock.getValue()).equals("Packet")) {
/* 380 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
/* 381 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
/*     */     } else {
/* 383 */       mc.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isFacing(BlockPos pos, BlockPos facingPos) {
/* 388 */     ImmutableMap<IProperty<?>, Comparable<?>> properties = mc.world.getBlockState(pos).getProperties();
/* 389 */     for (UnmodifiableIterator<IProperty> unmodifiableIterator = properties.keySet().iterator(); unmodifiableIterator.hasNext(); ) { IProperty<?> prop = unmodifiableIterator.next();
/* 390 */       if (prop.getValueClass() == EnumFacing.class && (prop.getName().equals("facing") || prop.getName().equals("rotation"))) {
/* 391 */         BlockPos pushPos = pos.offset((EnumFacing)properties.get(prop));
/* 392 */         if (isPos2(facingPos, pushPos)) return true; 
/*     */       }  }
/*     */     
/* 395 */     return false;
/*     */   }
/*     */   
/*     */   public BlockPos hasRedstoneBlock(BlockPos pos) {
/* 399 */     List<BlockPos> redstone = new ArrayList<>();
/* 400 */     BlockPos[] offsets = { new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     for (BlockPos redstonePos : offsets) redstone.add(pos.add((Vec3i)redstonePos)); 
/* 408 */     if (this.useBlock) redstone.add(pos.add(0, 1, 0)); 
/* 409 */     return redstone.stream().filter(p -> (BlockUtil.getBlock(p) == Blocks.REDSTONE_TORCH || BlockUtil.getBlock(p) == Blocks.REDSTONE_BLOCK)).min(Comparator.comparing(PlayerUtil::getDistanceI)).orElse(null);
/*     */   }
/*     */   
/*     */   static class PistonPos
/*     */   {
/*     */     public BlockPos piston;
/*     */     public BlockPos redstone;
/*     */     public BlockPos calcPos;
/*     */     
/*     */     public PistonPos(BlockPos pistonPos, BlockPos redstonePos, BlockPos pos) {
/* 419 */       this.piston = pistonPos;
/* 420 */       this.redstone = redstonePos;
/* 421 */       this.calcPos = pos;
/*     */     }
/*     */     
/*     */     public double getMaxRange() {
/* 425 */       if (this.piston == null || this.redstone == null) return 999999.0D; 
/* 426 */       return Math.max(PlayerUtil.getDistance(this.piston), PlayerUtil.getDistance(this.redstone));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AntiHoleCamper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
