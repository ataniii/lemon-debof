//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.dev;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.player.BurrowUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.block.BlockEnderChest;
/*    */ import net.minecraft.block.BlockObsidian;
/*    */ import net.minecraft.inventory.ClickType;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketClickWindow;
/*    */ 
/*    */ @Declaration(name = "AutoSwitchEChest", category = Category.Dev)
/*    */ public class AutoEChest extends Module {
/* 16 */   IntegerSetting count = registerInteger("Count", 16, 1, 64);
/* 17 */   IntegerSetting backCount = registerInteger("SwitchBack Count", 121, 1, 256);
/* 18 */   BooleanSetting update = registerBoolean("UpdateController", true); int slot;
/*    */   int slot2;
/*    */   boolean switched = false;
/*    */   
/*    */   private void windowClick(int slot, int to) {
/* 23 */     mc.player.connection.sendPacket((Packet)new CPacketClickWindow(mc.player.inventoryContainer.windowId, slot, to, ClickType.SWAP, ItemStack.EMPTY, mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/* 24 */     if (((Boolean)this.update.getValue()).booleanValue()) mc.playerController.updateController();
/*    */   
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 29 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/* 30 */       return;  int slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 31 */     int echest = BurrowUtil.findInventoryBlock(BlockEnderChest.class);
/* 32 */     if (slot == -1 || echest == -1)
/* 33 */       return;  ItemStack stack = (ItemStack)mc.player.inventory.mainInventory.get(slot);
/* 34 */     if (stack.stackSize <= ((Integer)this.count.getValue()).intValue()) {
/* 35 */       windowClick(echest, slot);
/* 36 */       this.slot = echest;
/* 37 */       this.slot2 = slot;
/* 38 */       this.switched = true;
/*    */     } 
/* 40 */     if (!this.switched)
/* 41 */       return;  int obsiCount = BurrowUtil.getCount(BlockObsidian.class);
/* 42 */     if (obsiCount >= ((Integer)this.backCount.getValue()).intValue())
/* 43 */       windowClick(this.slot, this.slot2); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AutoEChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
