//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ @Declaration(name = "CatOffhand", category = Category.Dev)
/*     */ public class OffHandCat extends Module {
/*     */   public static OffHandCat INSTANCE;
/*     */   public boolean autoCrystal;
/*     */   ModeSetting defaultItem;
/*     */   ModeSetting nonDefaultItem;
/*     */   ModeSetting noPlayerItem;
/*     */   ModeSetting swordMode;
/*     */   ModeSetting gappleMode;
/*     */   ModeSetting pickaxeMode;
/*     */   ModeSetting shiftPickaxeMode;
/*     */   ModeSetting potionChoose;
/*     */   IntegerSetting healthSwitch;
/*     */   IntegerSetting swordHealth;
/*     */   IntegerSetting tickDelay;
/*     */   IntegerSetting fallDistance;
/*     */   IntegerSetting maxSwitchPerSecond;
/*     */   DoubleSetting biasDamage;
/*     */   DoubleSetting playerDistance;
/*     */   BooleanSetting rightGap;
/*     */   BooleanSetting shiftPot;
/*     */   BooleanSetting swordCheck;
/*     */   BooleanSetting crystalGap;
/*     */   BooleanSetting fallDistanceBol;
/*     */   BooleanSetting crystalCheck;
/*     */   IntegerSetting predict;
/*     */   
/*  44 */   public OffHandCat() { this.defaultItem = registerMode("Default", Arrays.asList(new String[] { "Totem", "Crystal", "Gapple", "Plates", "Obby", "EChest", "Pot", "Exp", "Bed" }, ), "Totem");
/*  45 */     this.nonDefaultItem = registerMode("Non Default", Arrays.asList(new String[] { "Totem", "Crystal", "Gapple", "Obby", "EChest", "Pot", "Exp", "Plates", "String", "Skull", "Bed" }, ), "Crystal");
/*  46 */     this.noPlayerItem = registerMode("No Player", Arrays.asList(new String[] { "Totem", "Crystal", "Gapple", "Plates", "Obby", "EChest", "Pot", "Exp", "Bed" }, ), "Gapple");
/*  47 */     this.swordMode = registerMode("Sword Switch", Arrays.asList(new String[] { "Gapple", "Crystal", "Pot", "None" }, ), "Gapple");
/*  48 */     this.gappleMode = registerMode("Gap Switch", Arrays.asList(new String[] { "Totem", "Gapple", "Crystal", "None" }, ), "Crystal");
/*  49 */     this.pickaxeMode = registerMode("Pick Switch", Arrays.asList(new String[] { "Obsidian", "EChest", "Gapple", "Crystal", "None" }, ), "Gapple");
/*  50 */     this.shiftPickaxeMode = registerMode("Shift Pick", Arrays.asList(new String[] { "Obsidian", "EChest", "Gapple", "Crystal", "None" }, ), "Gapple");
/*  51 */     this.potionChoose = registerMode("Potion", Arrays.asList(new String[] { "first", "strength", "swiftness" }, ), "first");
/*  52 */     this.healthSwitch = registerInteger("Health Switch", 14, 0, 36);
/*  53 */     this.swordHealth = registerInteger("Sword Health", 14, 0, 36);
/*  54 */     this.tickDelay = registerInteger("Tick Delay", 0, 0, 20);
/*  55 */     this.fallDistance = registerInteger("Fall Distance", 12, 0, 30);
/*  56 */     this.maxSwitchPerSecond = registerInteger("Max Switch", 6, 2, 10);
/*  57 */     this.biasDamage = registerDouble("Bias Damage", 1.0D, 0.0D, 3.0D);
/*  58 */     this.playerDistance = registerDouble("Player Distance", 0.0D, 0.0D, 30.0D);
/*  59 */     this.rightGap = registerBoolean("Right Click Gap", false);
/*  60 */     this.shiftPot = registerBoolean("Shift Pot", false);
/*  61 */     this.swordCheck = registerBoolean("Only Sword", true);
/*  62 */     this.crystalGap = registerBoolean("Crystal Gap", false);
/*  63 */     this.fallDistanceBol = registerBoolean("Fall Distance", true);
/*  64 */     this.crystalCheck = registerBoolean("Crystal Check", false);
/*  65 */     this.predict = registerInteger("Predict Tick", 1, 0, 20);
/*  66 */     this.noHotBar = registerBoolean("No HotBar", false);
/*  67 */     this.onlyHotBar = registerBoolean("Only HotBar", false);
/*  68 */     this.antiWeakness = registerBoolean("AntiWeakness", false);
/*  69 */     this.hotBarTotem = registerBoolean("Switch HotBar Totem", false);
/*  70 */     this.refill = registerBoolean("ReFill", true, () -> (Boolean)this.hotBarTotem.getValue());
/*  71 */     this.check = registerBoolean("Check", true, () -> Boolean.valueOf((((Boolean)this.hotBarTotem.getValue()).booleanValue() && ((Boolean)this.refill.getValue()).booleanValue())));
/*  72 */     this.totemSlot = registerInteger("Totem Slot", 1, 1, 9, () -> Boolean.valueOf((((Boolean)this.hotBarTotem.getValue()).booleanValue() && ((Boolean)this.refill.getValue()).booleanValue())));
/*  73 */     this.HudMode = registerMode("Hud Mode", Arrays.asList(new String[] { "Totem", "Offhand" }, ), "Offhand");
/*  74 */     this.debug = registerBoolean("Debug Msg", false);
/*     */     
/*  76 */     this.itemCheck = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.switchDone = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*  89 */     this.allowedItemsItem = new HashMap<String, Item>()
/*     */       {
/*     */       
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.allowedItemsBlock = new HashMap<String, Block>()
/*     */       {
/*     */       
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketHeldItemChange) this.nowSlot = ((CPacketHeldItemChange)event.getPacket()).getSlotId();  }new java.util.function.Predicate[0]);
/*     */     INSTANCE = this; } BooleanSetting noHotBar; BooleanSetting onlyHotBar; BooleanSetting antiWeakness; BooleanSetting hotBarTotem; BooleanSetting refill; BooleanSetting check; IntegerSetting totemSlot; ModeSetting HudMode; BooleanSetting debug; String ItemName; String itemCheck; int prevSlot; int tickWaited; int counts; int totems; boolean returnBack; boolean stepChanging; boolean firstChange; Item item; private final ArrayList<Long> switchDone; Map<String, Item> allowedItemsItem; Map<String, Block> allowedItemsBlock; int nowSlot; @EventHandler
/*     */   private final Listener<PacketEvent.Send> postSendListener; public void onEnable() {
/*     */     this.autoCrystal = false;
/*     */     this.firstChange = true;
/*     */     this.returnBack = false;
/*     */   } public void onDisable() {} private boolean switchItemTotemHot() {
/* 215 */     int slot = InventoryUtil.findTotemSlot(0, 8);
/*     */     
/* 217 */     if (slot != -1) {
/*     */       
/* 219 */       if (this.nowSlot != slot) {
/* 220 */         mc.player.inventory.currentItem = slot;
/* 221 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */       } 
/* 223 */       return true;
/*     */     } 
/* 225 */     return false; } public void onTick() { if (mc.world == null || mc.player == null || mc.player.isDead || (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory))) return;  if (((Boolean)this.hotBarTotem.getValue()).booleanValue() && ((Boolean)this.refill.getValue()).booleanValue()) { boolean hasTotem = false; int i; for (i = 0; i < 9; i++) { if (mc.player.inventory.getStackInSlot(i).getItem() == Items.TOTEM_OF_UNDYING) hasTotem = true;  }  if (!hasTotem || !((Boolean)this.check.getValue()).booleanValue()) for (i = 9; i < 36; i++) { if (mc.player.inventory.getStackInSlot(i).getItem() == Items.TOTEM_OF_UNDYING) { mc.playerController.windowClick(0, i, ((Integer)this.totemSlot.getValue()).intValue() - 1, ClickType.SWAP, (EntityPlayer)mc.player); break; }  }   }  if (this.stepChanging)
/*     */       if (this.tickWaited++ >= ((Integer)this.tickDelay.getValue()).intValue()) { this.tickWaited = 0; this.stepChanging = false; mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player); this.switchDone.add(Long.valueOf(System.currentTimeMillis())); } else { return; }   this.totems = mc.player.inventory.mainInventory.stream().filter(itemStack -> (itemStack.getItem() == Items.TOTEM_OF_UNDYING)).mapToInt(ItemStack::getCount).sum(); if (this.returnBack)
/*     */       if (this.tickWaited++ >= ((Integer)this.tickDelay.getValue()).intValue()) { changeBack(); } else { return; }   this.itemCheck = getItem(false); if (offHandSame(this.itemCheck)) { if (((Boolean)this.hotBarTotem.getValue()).booleanValue() && this.itemCheck.equals("Totem"))
/*     */         this.itemCheck = getItem(switchItemTotemHot());  if (offHandSame(this.itemCheck))
/*     */         switchItemNormal(this.itemCheck);  }  GetOffhand(); }
/* 230 */   private void switchItemNormal(String itemCheck) { int t = getInventorySlot(itemCheck);
/*     */     
/* 232 */     if (t == -1)
/*     */       return; 
/* 234 */     if (!itemCheck.equals("Totem") && canSwitch())
/*     */       return; 
/* 236 */     toOffHand(t); } private void GetOffhand() { if (((String)this.HudMode.getValue()).equals("Offhand")) { this.item = mc.player.getHeldItemOffhand().getItem(); int items = mc.player.getHeldItemOffhand().getCount(); this.ItemName = mc.player.getHeldItemOffhand().getDisplayName(); this.counts = mc.player.inventory.mainInventory.stream().filter(itemStack -> (itemStack.getItem() == this.item)).mapToInt(ItemStack::getCount).sum() + items; }  }
/*     */   private void changeBack() { if (this.prevSlot == -1 || !mc.player.inventory.getStackInSlot(this.prevSlot).isEmpty())
/*     */       this.prevSlot = findEmptySlot();  if (this.prevSlot != -1) { mc.playerController.windowClick(0, (this.prevSlot < 9) ? (this.prevSlot + 36) : this.prevSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player); }
/*     */     else if (((Boolean)this.debug.getValue()).booleanValue()) { MessageBus.printDebug("Your inventory is full.", Boolean.valueOf(true)); }
/*     */      this.returnBack = false; this.tickWaited = 0; }
/* 241 */   private String getItem(boolean mainTotem) { String itemCheck = "";
/*     */     
/* 243 */     boolean normalOffHand = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (!mainTotem && ((((Boolean)this.fallDistanceBol.getValue()).booleanValue() && mc.player.fallDistance >= ((Integer)this.fallDistance.getValue()).intValue() && mc.player.prevPosY != mc.player.posY && !mc.player.isElytraFlying()) || (((Boolean)this.crystalCheck
/* 251 */       .getValue()).booleanValue() && crystalDamage()))) {
/* 252 */       normalOffHand = false;
/* 253 */       itemCheck = "Totem";
/*     */     } 
/*     */ 
/*     */     
/* 257 */     Item mainHandItem = mc.player.getHeldItemMainhand().getItem();
/*     */ 
/*     */     
/* 260 */     if (mainHandItem instanceof net.minecraft.item.ItemSword) {
/* 261 */       boolean can = true;
/* 262 */       if (mc.gameSettings.keyBindUseItem.isKeyDown() && ((Boolean)this.swordCheck.getValue()).booleanValue()) {
/* 263 */         if (((Boolean)this.shiftPot.getValue()).booleanValue() && mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 264 */           can = false;
/* 265 */           itemCheck = "Pot";
/* 266 */           normalOffHand = false;
/* 267 */         } else if (((Boolean)this.rightGap.getValue()).booleanValue() && !((String)this.swordMode.getValue()).equals("Gapple")) {
/* 268 */           can = false;
/* 269 */           itemCheck = "Gapple";
/* 270 */           normalOffHand = false;
/*     */         } 
/*     */       }
/* 273 */       if (can) {
/* 274 */         switch ((String)this.swordMode.getValue()) {
/*     */           case "Gapple":
/* 276 */             itemCheck = "Gapple";
/* 277 */             normalOffHand = false;
/*     */             break;
/*     */           case "Crystal":
/* 280 */             itemCheck = "Crystal";
/* 281 */             normalOffHand = false;
/*     */             break;
/*     */           case "Pot":
/* 284 */             itemCheck = "Pot";
/* 285 */             normalOffHand = false;
/*     */             break;
/*     */         } 
/*     */       }
/* 289 */     } else if (!((Boolean)this.swordCheck.getValue()).booleanValue()) {
/* 290 */       if (((Boolean)this.shiftPot.getValue()).booleanValue() && mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 291 */         itemCheck = "Pot";
/* 292 */         normalOffHand = false;
/* 293 */       } else if (((Boolean)this.rightGap.getValue()).booleanValue() && !((String)this.swordMode.getValue()).equals("Gapple")) {
/* 294 */         itemCheck = "Gapple";
/* 295 */         normalOffHand = false;
/*     */       } 
/*     */     } 
/*     */     
/* 299 */     if (mainHandItem == Items.DIAMOND_PICKAXE) {
/* 300 */       if (!mc.gameSettings.keyBindSneak.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 301 */         switch ((String)this.pickaxeMode.getValue()) {
/*     */           case "Obsidian":
/* 303 */             itemCheck = "Obby";
/* 304 */             normalOffHand = false;
/*     */             break;
/*     */           case "EChest":
/* 307 */             itemCheck = "EChest";
/* 308 */             normalOffHand = false;
/*     */             break;
/*     */           case "Gapple":
/* 311 */             itemCheck = "Gapple";
/* 312 */             normalOffHand = false;
/*     */             break;
/*     */           case "Crystal":
/* 315 */             itemCheck = "Crystal";
/* 316 */             normalOffHand = false;
/*     */             break;
/*     */         } 
/*     */       }
/* 320 */       if (mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 321 */         switch ((String)this.shiftPickaxeMode.getValue()) {
/*     */           case "Obsidian":
/* 323 */             itemCheck = "Obby";
/* 324 */             normalOffHand = false;
/*     */             break;
/*     */           case "EChest":
/* 327 */             itemCheck = "EChest";
/* 328 */             normalOffHand = false;
/*     */             break;
/*     */           case "Gapple":
/* 331 */             itemCheck = "Gapple";
/* 332 */             normalOffHand = false;
/*     */             break;
/*     */           case "Crystal":
/* 335 */             itemCheck = "Crystal";
/* 336 */             normalOffHand = false;
/*     */             break;
/*     */         } 
/*     */       
/*     */       }
/*     */     } 
/* 342 */     if (mainHandItem == Items.GOLDEN_APPLE) {
/* 343 */       switch ((String)this.gappleMode.getValue()) {
/*     */         case "Totem":
/* 345 */           itemCheck = "Totem";
/* 346 */           normalOffHand = false;
/*     */           break;
/*     */         case "Gapple":
/* 349 */           itemCheck = "Gapple";
/* 350 */           normalOffHand = false;
/*     */           break;
/*     */         case "Crystal":
/* 353 */           itemCheck = "Crystal";
/* 354 */           normalOffHand = false;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/* 359 */     if (((Boolean)this.crystalGap.getValue()).booleanValue() && mainHandItem == Items.END_CRYSTAL) {
/* 360 */       itemCheck = "Gapple";
/* 361 */       normalOffHand = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 366 */     if (normalOffHand && ((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
/* 367 */       normalOffHand = false;
/* 368 */       itemCheck = "Crystal";
/*     */     } 
/*     */     
/* 371 */     if (this.autoCrystal) {
/* 372 */       itemCheck = "Crystal";
/* 373 */       normalOffHand = false;
/*     */     } 
/*     */ 
/*     */     
/* 377 */     if (normalOffHand && !nearPlayer()) {
/* 378 */       itemCheck = (String)this.noPlayerItem.getValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 383 */     itemCheck = getItemToCheck(itemCheck, mainTotem);
/* 384 */     return itemCheck; }
/*     */ 
/*     */   
/*     */   private boolean canSwitch() {
/* 388 */     long now = System.currentTimeMillis();
/*     */ 
/*     */     
/* 391 */     for (int i = 0; i < this.switchDone.size() && 
/* 392 */       now - ((Long)this.switchDone.get(i)).longValue() > 1000L; i++) {
/* 393 */       this.switchDone.remove(i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 399 */     if (this.switchDone.size() / 2 >= ((Integer)this.maxSwitchPerSecond.getValue()).intValue()) {
/* 400 */       return true;
/*     */     }
/* 402 */     this.switchDone.add(Long.valueOf(now));
/* 403 */     return false;
/*     */   }
/*     */   
/*     */   private boolean nearPlayer() {
/* 407 */     if (((Double)this.playerDistance.getValue()).intValue() == 0)
/* 408 */       return true; 
/* 409 */     for (EntityPlayer pl : mc.world.playerEntities) {
/* 410 */       if (pl != mc.player && mc.player.getDistance((Entity)pl) < ((Double)this.playerDistance.getValue()).doubleValue())
/* 411 */         return true; 
/*     */     } 
/* 413 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean crystalDamage() {
/* 418 */     PredictUtil.PredictSettings settings = new PredictUtil.PredictSettings(((Integer)this.predict.getValue()).intValue(), true, 39, 2, 2, 1, true, true, true, true, 2, 0.15D);
/* 419 */     for (Entity t : mc.world.loadedEntityList) {
/*     */       
/* 421 */       if (t instanceof net.minecraft.entity.item.EntityEnderCrystal && mc.player.getDistance(t) <= 12.0F && (
/* 422 */         DamageUtil.calculateCrystalDamage((EntityLivingBase)PredictUtil.predictPlayer((EntityLivingBase)mc.player, settings), t.posX, t.posY, t.posZ) * ((Double)this.biasDamage.getValue()).doubleValue() >= EntityUtil.getHealth((Entity)mc.player) || (DamageUtil.calculateCrystalDamage((EntityLivingBase)mc.player, t.posX, t.posY, t.posZ) * ((Double)this.biasDamage.getValue()).doubleValue() >= EntityUtil.getHealth((Entity)mc.player) && this.totems > 0))) {
/* 423 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 427 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private int findEmptySlot() {
/* 432 */     for (int i = 35; i > -1; i--) {
/*     */       
/* 434 */       if (mc.player.inventory.getStackInSlot(i).isEmpty()) {
/* 435 */         return i;
/*     */       }
/*     */     } 
/* 438 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean offHandSame(String itemCheck) {
/* 443 */     Item offHandItem = mc.player.getHeldItemOffhand().getItem();
/* 444 */     if (this.allowedItemsBlock.containsKey(itemCheck)) {
/* 445 */       Block item = this.allowedItemsBlock.get(itemCheck);
/* 446 */       if (offHandItem instanceof ItemBlock)
/*     */       {
/* 448 */         return (((ItemBlock)offHandItem).getBlock() != item); } 
/* 449 */       if (offHandItem instanceof net.minecraft.item.ItemSkull && item == Blocks.SKULL)
/* 450 */         return true; 
/*     */     } else {
/* 452 */       Item item = this.allowedItemsItem.get(itemCheck);
/* 453 */       return (item != offHandItem);
/*     */     } 
/* 455 */     return true;
/*     */   }
/*     */   
/*     */   private String getItemToCheck(String str, boolean mainTotem) {
/* 459 */     if (mainTotem) return str.isEmpty() ? (String)this.nonDefaultItem.getValue() : str;
/*     */     
/* 461 */     if (mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemSword) return (PlayerUtil.getHealth() > ((Integer)this.swordHealth.getValue()).intValue()) ? (str.isEmpty() ? (String)this.nonDefaultItem.getValue() : str) : (String)this.defaultItem.getValue(); 
/* 462 */     return (PlayerUtil.getHealth() > ((Integer)this.healthSwitch.getValue()).intValue()) ? (str.isEmpty() ? (String)this.nonDefaultItem.getValue() : str) : (String)this.defaultItem.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private int getInventorySlot(String itemName) {
/*     */     Object item;
/* 468 */     boolean blockBool = false;
/* 469 */     if (this.allowedItemsItem.containsKey(itemName)) {
/* 470 */       item = this.allowedItemsItem.get(itemName);
/*     */     } else {
/* 472 */       item = this.allowedItemsBlock.get(itemName);
/* 473 */       blockBool = true;
/*     */     } 
/*     */ 
/*     */     
/* 477 */     if (!this.firstChange && 
/* 478 */       this.prevSlot != -1) {
/* 479 */       int res = isCorrect(this.prevSlot, blockBool, item, itemName);
/* 480 */       if (res != -1) return res;
/*     */     
/*     */     } 
/*     */     
/* 484 */     for (int i = ((Boolean)this.onlyHotBar.getValue()).booleanValue() ? 8 : 35; i > (((Boolean)this.noHotBar.getValue()).booleanValue() ? 9 : -1); i--) {
/* 485 */       int res = isCorrect(i, blockBool, item, itemName);
/* 486 */       if (res != -1) return res; 
/*     */     } 
/* 488 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int isCorrect(int i, boolean blockBool, Object item, String itemName) {
/* 494 */     Item temp = mc.player.inventory.getStackInSlot(i).getItem();
/*     */     
/* 496 */     if (blockBool) {
/*     */       
/* 498 */       if (temp instanceof ItemBlock)
/* 499 */       { if (((ItemBlock)temp).getBlock() == item) return i;  }
/* 500 */       else if (temp instanceof net.minecraft.item.ItemSkull && item == Blocks.SKULL) { return i;
/*     */          }
/*     */ 
/*     */     
/*     */     }
/* 505 */     else if (item == temp) {
/*     */       
/* 507 */       if (itemName.equals("Pot") && !((String)this.potionChoose.getValue()).equalsIgnoreCase("first") && !(mc.player.inventory.getStackInSlot(i)).stackTagCompound.toString().split(":")[2].contains((CharSequence)this.potionChoose.getValue()))
/* 508 */         return -1; 
/* 509 */       return i;
/*     */     } 
/*     */     
/* 512 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void toOffHand(int t) {
/* 519 */     if (!mc.player.getHeldItemOffhand().isEmpty())
/*     */     
/* 521 */     { if (this.firstChange)
/* 522 */         this.prevSlot = t; 
/* 523 */       this.returnBack = true;
/* 524 */       this.firstChange = !this.firstChange; }
/* 525 */     else { this.prevSlot = -1; }
/*     */ 
/*     */     
/* 528 */     mc.playerController.windowClick(0, (t < 9) ? (t + 36) : t, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 529 */     if (((Integer)this.tickDelay.getValue()).intValue() == 0)
/* 530 */     { mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 531 */       this.switchDone.add(Long.valueOf(System.currentTimeMillis())); }
/* 532 */     else { this.stepChanging = true; }
/* 533 */      this.tickWaited = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHudInfo() {
/* 538 */     if (((String)this.HudMode.getValue()).equals("Totem")) {
/* 539 */       this.counts = this.totems;
/* 540 */       if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) this.counts++; 
/* 541 */       return "[" + ChatFormatting.WHITE + "Totem " + this.counts + ChatFormatting.GRAY + "]";
/*     */     } 
/* 543 */     if (this.itemCheck.isEmpty()) return "[" + ChatFormatting.WHITE + "None" + ChatFormatting.GRAY + "]"; 
/* 544 */     return "[" + ChatFormatting.WHITE + this.itemCheck + " " + this.counts + ChatFormatting.GRAY + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\OffHandCat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
