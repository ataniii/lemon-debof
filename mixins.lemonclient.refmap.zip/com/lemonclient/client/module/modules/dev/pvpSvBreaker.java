//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockPistonBase;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Declaration(name = "PvpSvBreaker", category = Category.Dev)
/*     */ public class pvpSvBreaker
/*     */   extends Module
/*     */ {
/*  35 */   ModeSetting mode = registerMode("Mode", Arrays.asList(new String[] { "Piston", "EChest", "Web", "Down", "Flat" }, ), "EChest");
/*  36 */   IntegerSetting delay = registerInteger("Delay", 0, 0, 20);
/*  37 */   DoubleSetting range = registerDouble("Range", 5.0D, 0.0D, 10.0D);
/*  38 */   DoubleSetting yRange = registerDouble("YRange", 2.5D, 0.0D, 10.0D);
/*  39 */   IntegerSetting bpt = registerInteger("BlocksPerTick", 4, 0, 20);
/*  40 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  41 */   BooleanSetting packet = registerBoolean("Packet Place", false);
/*  42 */   BooleanSetting strict = registerBoolean("Strict", false);
/*  43 */   BooleanSetting raytrcae = registerBoolean("RayTrace", false);
/*  44 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  45 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", false);
/*  46 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*     */   int waited;
/*     */   
/*     */   private void switchTo(int slot) {
/*  50 */     if (slot > -1 && slot < 9 && (
/*  51 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*  52 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/*  54 */       { mc.player.inventory.currentItem = slot;
/*  55 */         mc.playerController.updateController(); }
/*     */     
/*     */     }
/*     */   }
/*     */   
/*     */   int placed;
/*     */   
/*     */   public void onTick() {
/*  63 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*     */       return; 
/*  65 */     if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */       return; 
/*  67 */     this.placed = this.waited = 0;
/*  68 */     switch ((String)this.mode.getValue()) {
/*     */       case "Web":
/*  70 */         web();
/*     */         break;
/*     */       
/*     */       case "Down":
/*  74 */         down();
/*     */         break;
/*     */       
/*     */       case "Flat":
/*  78 */         flat();
/*     */         break;
/*     */       
/*     */       case "Piston":
/*  82 */         piston();
/*     */         break;
/*     */       
/*     */       case "EChest":
/*  86 */         enderChest();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void web() {
/*  93 */     int slot = BurrowUtil.findHotbarBlock(BlockWeb.class);
/*  94 */     if (slot == -1)
/*  95 */       return;  int oldSlot = mc.player.inventory.currentItem;
/*  96 */     List<BlockPos> sphere = EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.yRange.getValue()).doubleValue() + 1.0D), false, false, 0);
/*  97 */     if (!sphere.isEmpty()) {
/*  98 */       switchTo(slot);
/*  99 */       for (BlockPos pos : sphere) {
/* 100 */         if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 101 */           break;  if (cantPlaceCrystal(pos))
/* 102 */           continue;  BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 103 */         this.placed++;
/*     */       } 
/* 105 */       switchTo(oldSlot);
/*     */     } 
/*     */   }
/*     */   private void down() {
/* 109 */     if ((mc.player.getHeldItemMainhand()).isEmpty || !(mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemBlock))
/* 110 */       return;  List<BlockPos> sphere = EntityUtil.getSphere(PlayerUtil.getEyesPos(), (Double)this.range.getValue(), (Double)this.yRange.getValue(), false, false, 0);
/* 111 */     sphere.removeIf(p -> (!BlockUtil.canReplace(p) || intersectsWithEntity(p) || BlockUtil.getFirstFacing(p, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue()) == null || PlayerUtil.getPlayerPos().getY() <= p.getY()));
/* 112 */     for (BlockPos pos : sphere) {
/* 113 */       if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 114 */         break;  BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 115 */       this.placed++;
/*     */     } 
/*     */   }
/*     */   private void flat() {
/* 119 */     if ((mc.player.getHeldItemMainhand()).isEmpty || !(mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemBlock))
/* 120 */       return;  List<BlockPos> sphere = EntityUtil.getSphere(PlayerUtil.getEyesPos(), (Double)this.range.getValue(), (Double)this.yRange.getValue(), false, false, 0);
/* 121 */     sphere.removeIf(p -> (!BlockUtil.canReplace(p) || intersectsWithEntity(p) || BlockUtil.getFirstFacing(p, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue()) == null || PlayerUtil.getPlayerPos().getY() - 1 != p.getY()));
/* 122 */     for (BlockPos pos : sphere) {
/* 123 */       if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 124 */         break;  BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 125 */       this.placed++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void piston() {
/* 130 */     int pistonSlot = BurrowUtil.findHotbarBlock(BlockPistonBase.class);
/* 131 */     int redstoneSlot = BurrowUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK.getClass());
/* 132 */     if (pistonSlot == -1 && redstoneSlot == -1)
/* 133 */       return;  List<BlockPos> sphere = getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.yRange.getValue()).doubleValue() + 1.0D), false, false, 0);
/* 134 */     sphere.removeIf(p -> (!BlockUtil.canReplace(p) || intersectsWithEntity(p)));
/* 135 */     boolean hi = false;
/* 136 */     int slot = mc.player.inventory.currentItem;
/* 137 */     for (BlockPos pos : sphere) {
/* 138 */       if (this.placed >= ((Integer)this.bpt.getValue()).intValue() || 
/* 139 */         PlayerUtil.getPlayerPos().getY() <= pos.getY())
/*     */         break; 
/* 141 */       if (hi) { switchTo(pistonSlot); }
/* 142 */       else { switchTo(redstoneSlot); }
/* 143 */        hi = !hi;
/* 144 */       BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 145 */       this.placed++;
/*     */     } 
/*     */     
/* 148 */     switchTo(slot);
/*     */   }
/*     */ 
/*     */   
/*     */   private void enderChest() {
/* 153 */     int slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/* 154 */     if (slot == -1)
/* 155 */       return;  int oldSlot = mc.player.inventory.currentItem;
/* 156 */     List<BlockPos> sphere = EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.yRange.getValue()).doubleValue() + 1.0D), false, false, 0);
/* 157 */     sphere.removeIf(this::cantPlaceCrystal);
/* 158 */     if (!sphere.isEmpty()) {
/* 159 */       switchTo(slot);
/* 160 */       for (BlockPos pos : sphere) {
/* 161 */         if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 162 */           break;  if (intersectsWithEntity(pos))
/* 163 */           continue;  BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrcae.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 164 */         this.placed++;
/*     */       } 
/* 166 */       switchTo(oldSlot);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 171 */     for (Entity entity : mc.world.loadedEntityList) {
/* 172 */       if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb) && !(entity instanceof net.minecraft.entity.item.EntityExpBottle) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow) && (
/* 173 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 174 */         return true; 
/*     */     } 
/* 176 */     return false;
/*     */   }
/*     */   
/*     */   private boolean inRange(BlockPos pos) {
/* 180 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/* 181 */     return (mc.player.getDistanceSq(pos) <= ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue() && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue());
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos loc, Double r, Double h, boolean hollow, boolean sphere, int plus_y) {
/* 185 */     EnumFacing facing = mc.player.getHorizontalFacing();
/* 186 */     List<BlockPos> circleBlocks = new ArrayList<>();
/* 187 */     double cx = loc.getX();
/* 188 */     double cy = loc.getY();
/* 189 */     double cz = loc.getZ(); double y;
/* 190 */     for (y = sphere ? (cy - r.doubleValue()) : (cy - h.doubleValue()); y < (sphere ? (cy + r.doubleValue()) : (cy + h.doubleValue())); y++) {
/* 191 */       double v = sphere ? ((cy - y) * (cy - y)) : 0.0D;
/* 192 */       if (facing == EnumFacing.EAST || facing == EnumFacing.SOUTH) {
/* 193 */         double x; for (x = cx + r.doubleValue(); x >= cx - r.doubleValue(); x--) {
/* 194 */           double z; for (z = cz + r.doubleValue(); z >= cz - r.doubleValue(); z--) {
/* 195 */             double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + v;
/* 196 */             if (dist < r.doubleValue() * r.doubleValue() && (!hollow || dist >= (r.doubleValue() - 1.0D) * (r.doubleValue() - 1.0D))) {
/* 197 */               BlockPos l = new BlockPos(x, y + plus_y, z);
/* 198 */               circleBlocks.add(l);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/* 203 */         double x; for (x = cx - r.doubleValue(); x <= cx + r.doubleValue(); x++) {
/* 204 */           double z; for (z = cz - r.doubleValue(); z <= cz + r.doubleValue(); z++) {
/* 205 */             double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + v;
/* 206 */             if (dist < r.doubleValue() * r.doubleValue() && (!hollow || dist >= (r.doubleValue() - 1.0D) * (r.doubleValue() - 1.0D))) {
/* 207 */               BlockPos l = new BlockPos(x, y + plus_y, z);
/* 208 */               circleBlocks.add(l);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 214 */     return circleBlocks;
/*     */   }
/*     */   
/*     */   private boolean cantPlaceCrystal(BlockPos p) {
/* 218 */     if (!inRange(p)) return true; 
/* 219 */     if (!mc.world.isAirBlock(p) || !mc.world.isAirBlock(p.up()))
/* 220 */       return true; 
/* 221 */     return (mc.world.getBlockState(p.down()).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(p.down()).getBlock() != Blocks.BEDROCK);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\pvpSvBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
