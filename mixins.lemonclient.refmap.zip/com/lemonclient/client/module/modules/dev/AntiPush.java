//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.dev;
/*    */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.entity.MoverType;
/*    */ import net.minecraft.util.MovementInput;
/*    */ 
/*    */ @Declaration(name = "AntiPush", category = Category.Dev, priority = 1000)
/*    */ public class AntiPush extends Module {
/*    */   public AntiPush() {
/* 14 */     this.move = registerBoolean("Move", false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     this.playerMoveEventListener = new Listener(event -> { MoverType moverType = event.getType(); if (moverType != MoverType.SELF && moverType != MoverType.PLAYER) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   BooleanSetting move;
/*    */   @EventHandler
/*    */   public final Listener<PlayerMoveEvent> playerMoveEventListener;
/*    */   
/*    */   public void fast() {
/*    */     if (mc.world == null || mc.player == null || mc.player.isDead || !((Boolean)this.move.getValue()).booleanValue())
/*    */       return; 
/*    */     MovementInput input = mc.player.movementInput;
/*    */     if (input.moveForward == 0.0D && input.moveStrafe == 0.0D) {
/*    */       mc.player.motionX = 0.0D;
/*    */       mc.player.motionZ = 0.0D;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AntiPush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
