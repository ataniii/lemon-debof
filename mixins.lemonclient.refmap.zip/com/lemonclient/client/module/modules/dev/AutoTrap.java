//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "BetterTrap", category = Category.Dev)
/*     */ public class AutoTrap extends Module {
/*  31 */   DoubleSetting range = registerDouble("Range", 5.0D, 0.0D, 10.0D);
/*  32 */   IntegerSetting delay = registerInteger("Delay", 50, 0, 500);
/*  33 */   IntegerSetting retryDelay = registerInteger("RetryDelay", 50, 0, 500);
/*  34 */   IntegerSetting blocksPerPlace = registerInteger("BlocksPerTick", 8, 1, 30);
/*  35 */   BooleanSetting chest = registerBoolean("EnderChest", true);
/*  36 */   BooleanSetting helpBlocks = registerBoolean("HelpBlocks", false);
/*  37 */   BooleanSetting only = registerBoolean("OnlyUntrapped", true);
/*  38 */   BooleanSetting strict = registerBoolean("Strict", true);
/*  39 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  40 */   BooleanSetting raytrace = registerBoolean("Raytrace", false);
/*  41 */   BooleanSetting antiScaffold = registerBoolean("AntiScaffold", false);
/*  42 */   BooleanSetting antiStep = registerBoolean("AntiStep", false);
/*  43 */   BooleanSetting noGhost = registerBoolean("Packet", false);
/*  44 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  45 */   BooleanSetting check = registerBoolean("SwitchCheck", false);
/*  46 */   BooleanSetting packet = registerBoolean("PacketSwitch", false);
/*  47 */   private final Timing timer = new Timing();
/*  48 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  49 */   private final Timing retryTimer = new Timing();
/*     */   public EntityPlayer target;
/*     */   private boolean didPlace = false;
/*     */   private int lastHotbarSlot;
/*  53 */   private int placements = 0;
/*     */   
/*     */   List<BlockPos> posList;
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  59 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */       return;
/*     */     }
/*  62 */     this.lastHotbarSlot = mc.player.inventory.currentItem;
/*  63 */     this.retries.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  68 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*     */       return; 
/*  70 */     doTrap();
/*     */   }
/*     */   
/*     */   private void doTrap() {
/*  74 */     if (check())
/*     */       return; 
/*  76 */     doStaticTrap();
/*  77 */     if (this.didPlace)
/*  78 */       this.timer.reset(); 
/*     */   }
/*     */   
/*     */   private void doStaticTrap() {
/*  82 */     int obbySlot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  83 */     int eChestSlot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/*  84 */     int slot = ((Boolean)this.chest.getValue()).booleanValue() ? eChestSlot : ((obbySlot == -1) ? eChestSlot : obbySlot);
/*  85 */     if (slot == -1)
/*  86 */       return;  int originalSlot = mc.player.inventory.currentItem;
/*     */     
/*  88 */     Vec3d[] sides = { new Vec3d(0.3D, 0.5D, 0.3D), new Vec3d(-0.3D, 0.5D, 0.3D), new Vec3d(0.3D, 0.5D, -0.3D), new Vec3d(-0.3D, 0.5D, -0.3D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     List<Vec3d> placeTargets = new ArrayList<>();
/*  96 */     for (Vec3d vec3d : sides) {
/*  97 */       placeTargets.addAll(EntityUtil.targets(this.target.getPositionVector().add(vec3d), ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), false, false, false, ((Boolean)this.raytrace.getValue()).booleanValue()));
/*     */     }
/*  99 */     this.posList = placeList(placeTargets, this.target);
/*     */     
/* 101 */     if (!this.posList.isEmpty()) {
/* 102 */       switchTo(slot);
/* 103 */       for (BlockPos pos : this.posList) placeBlock(pos); 
/* 104 */       switchTo(originalSlot);
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<BlockPos> placeList(List<Vec3d> list, EntityPlayer target) {
/* 109 */     list.sort((vec3d, vec3d2) -> Double.compare(mc.player.getDistanceSq(vec3d2.x, vec3d2.y, vec3d2.z), mc.player.getDistanceSq(vec3d.x, vec3d.y, vec3d.z)));
/*     */     
/* 111 */     List<BlockPos> posList = new ArrayList<>();
/* 112 */     for (Vec3d vec3d3 : list) {
/* 113 */       BlockPos position = new BlockPos(vec3d3);
/* 114 */       if (intersectsWithEntity(position) || !BlockUtil.isAir(position))
/* 115 */         continue;  int placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue());
/* 116 */       if (placeability == 1 && (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < 4)) {
/* 117 */         posList.add(position);
/* 118 */         this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/* 119 */         this.retryTimer.reset();
/*     */         continue;
/*     */       } 
/* 122 */       if (placeability != 3 && (
/* 123 */         (Boolean)this.helpBlocks.getValue()).booleanValue() && position.getY() == Math.round(target.posY) + 1L) posList.add(position.down());
/*     */       
/* 125 */       posList.add(position);
/*     */     } 
/* 127 */     posList.sort(Comparator.comparingDouble(pos -> pos.y));
/* 128 */     return posList;
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 133 */     if (slot > -1 && slot < 9 && (
/* 134 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 135 */       if (((Boolean)this.packet.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/* 137 */       { mc.player.inventory.currentItem = slot;
/* 138 */         mc.playerController.updateController(); }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean check() {
/* 145 */     this.didPlace = false;
/* 146 */     this.placements = 0;
/* 147 */     int obbySlot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 148 */     int eChestSlot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/* 149 */     int slot = ((Boolean)this.chest.getValue()).booleanValue() ? eChestSlot : ((obbySlot == -1) ? eChestSlot : obbySlot);
/* 150 */     if (this.retryTimer.passedMs(((Integer)this.retryDelay.getValue()).intValue())) {
/* 151 */       this.retries.clear();
/* 152 */       this.retryTimer.reset();
/*     */     } 
/* 154 */     if (slot == -1) {
/* 155 */       return true;
/*     */     }
/* 157 */     if (mc.player.inventory.currentItem != this.lastHotbarSlot && mc.player.inventory.currentItem != obbySlot) {
/* 158 */       this.lastHotbarSlot = mc.player.inventory.currentItem;
/*     */     }
/* 160 */     this.target = getTarget(((Double)this.range.getValue()).doubleValue(), ((Boolean)this.only.getValue()).booleanValue());
/* 161 */     return (this.target == null || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()));
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget(double range, boolean trapped) {
/* 165 */     EntityPlayer target = null;
/* 166 */     double distance = Math.pow(range, 2.0D) + 1.0D;
/* 167 */     for (EntityPlayer player : mc.world.playerEntities) {
/* 168 */       if (!EntityUtil.isPlayerValid(player, (float)range) || (trapped && EntityUtil.isTrapped(player, ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), false, false, false)) || LemonClient.speedUtil.getPlayerSpeed(player) > 15.0D)
/*     */         continue; 
/* 170 */       if (target == null) {
/* 171 */         target = player;
/* 172 */         distance = mc.player.getDistanceSq((Entity)player);
/*     */         continue;
/*     */       } 
/* 175 */       if (mc.player.getDistanceSq((Entity)player) >= distance)
/* 176 */         continue;  target = player;
/* 177 */       distance = mc.player.getDistanceSq((Entity)player);
/*     */     } 
/* 179 */     return target;
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 183 */     for (Entity entity : mc.world.loadedEntityList) {
/* 184 */       if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb) && !(entity instanceof net.minecraft.entity.item.EntityExpBottle) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow) && (
/* 185 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 186 */         return true; 
/*     */     } 
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 193 */     if (this.placements < ((Integer)this.blocksPerPlace.getValue()).intValue()) {
/* 194 */       BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.noGhost.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 195 */       this.didPlace = true;
/* 196 */       this.placements++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AutoTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
