//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import net.minecraft.block.BlockConcretePowder;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoConcrete", category = Category.Dev)
/*     */ public class AutoConcrete extends Module {
/*  25 */   DoubleSetting range = registerDouble("Range", 5.5D, 0.0D, 10.0D);
/*  26 */   BooleanSetting packet = registerBoolean("Packet Place", true);
/*  27 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  28 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  29 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  30 */   BooleanSetting air = registerBoolean("Air Check", true);
/*  31 */   BooleanSetting disable = registerBoolean("Disable", true);
/*  32 */   IntegerSetting delay = registerInteger("Delay", 5, 0, 100, () -> Boolean.valueOf(!((Boolean)this.disable.getValue()).booleanValue()));
/*  33 */   DoubleSetting maxTargetSpeed = registerDouble("Max Target Speed", 10.0D, 0.0D, 50.0D);
/*     */   
/*     */   int waited;
/*  36 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchTo(int slot, Runnable runnable) {
/*  44 */     int oldslot = mc.player.inventory.currentItem;
/*  45 */     if (slot < 0 || slot == oldslot) {
/*  46 */       runnable.run();
/*     */       return;
/*     */     } 
/*  49 */     if (slot < 9) {
/*  50 */       boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue();
/*  51 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*  52 */       else { mc.player.inventory.currentItem = slot; }
/*  53 */        runnable.run();
/*  54 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/*  55 */       else { mc.player.inventory.currentItem = oldslot; }
/*     */     
/*     */     } 
/*     */   }
/*     */   public void onEnable() {
/*  60 */     this.waited = 100;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  64 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*  65 */       if (((Boolean)this.disable.getValue()).booleanValue()) disable(); 
/*     */       return;
/*     */     } 
/*  68 */     if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */       return; 
/*  70 */     this.waited = 0;
/*     */     
/*  72 */     int slot = BurrowUtil.findHotbarBlock(BlockAnvil.class);
/*  73 */     if (slot == -1) {
/*  74 */       slot = BurrowUtil.findHotbarBlock(BlockConcretePowder.class);
/*  75 */       if (slot == -1)
/*     */         return; 
/*  77 */     }  EntityPlayer player = PlayerUtil.getNearestPlayer(((Double)this.range.getValue()).doubleValue());
/*  78 */     if (LemonClient.speedUtil.getPlayerSpeed(player) > ((Double)this.maxTargetSpeed.getValue()).doubleValue())
/*     */       return; 
/*  80 */     if (player == null) {
/*  81 */       if (((Boolean)this.disable.getValue()).booleanValue()) disable(); 
/*     */       return;
/*     */     } 
/*  84 */     BlockPos pos = new BlockPos(player.posX, player.posY, player.posZ);
/*  85 */     if (!BlockUtil.airBlocks.contains(mc.world.getBlockState(pos).getBlock()) && ((Boolean)this.air.getValue()).booleanValue()) {
/*  86 */       if (((Boolean)this.disable.getValue()).booleanValue()) disable(); 
/*     */       return;
/*     */     } 
/*  89 */     BlockPos placePos = pos.up(2);
/*  90 */     if (intersectsWithEntity(placePos))
/*  91 */       return;  if (BurrowUtil.getFirstFacing(placePos) == null) {
/*  92 */       int obby = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  93 */       if (obby == -1)
/*  94 */         return;  boolean helped = false;
/*  95 */       for (BlockPos side : this.sides) {
/*  96 */         BlockPos helpingBlock = placePos.add((Vec3i)side);
/*  97 */         if (!intersectsWithEntity(helpingBlock)) {
/*  98 */           if (BurrowUtil.getFirstFacing(helpingBlock) != null) {
/*  99 */             switchTo(obby, () -> BurrowUtil.placeBlock(helpingBlock, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()));
/* 100 */             helped = true; break;
/*     */           } 
/* 102 */           if (!intersectsWithEntity(helpingBlock.down())) {
/* 103 */             if (BurrowUtil.getFirstFacing(helpingBlock.down()) != null) {
/* 104 */               switchTo(obby, () -> {
/*     */                     BurrowUtil.placeBlock(helpingBlock.down(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */                     BurrowUtil.placeBlock(helpingBlock, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */                   });
/* 108 */               helped = true; break;
/*     */             } 
/* 110 */             if (!intersectsWithEntity(helpingBlock.down(2)) && BurrowUtil.getFirstFacing(helpingBlock.down(2)) != null) {
/* 111 */               switchTo(obby, () -> {
/*     */                     BurrowUtil.placeBlock(helpingBlock.down(2), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */                     BurrowUtil.placeBlock(helpingBlock.down(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */                     BurrowUtil.placeBlock(helpingBlock, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */                   });
/* 116 */               helped = true;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 122 */       if (!helped)
/*     */         return; 
/* 124 */     }  switchTo(slot, () -> BurrowUtil.placeBlock(placePos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()));
/* 125 */     if (((Boolean)this.disable.getValue()).booleanValue()) disable(); 
/*     */   }
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 128 */     for (Entity entity : mc.world.loadedEntityList) {
/* 129 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 130 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true; 
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AutoConcrete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
