//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraftforge.client.event.InputUpdateEvent;
/*     */ 
/*     */ @Declaration(name = "BlockMove", category = Category.Dev, priority = 120)
/*     */ public class BlockMove extends Module {
/*     */   BooleanSetting middle;
/*     */   IntegerSetting delay;
/*     */   BooleanSetting only;
/*     */   BooleanSetting avoid;
/*     */   Timing timer;
/*     */   Vec3d[] sides;
/*     */   @EventHandler
/*     */   private final Listener<InputUpdateEvent> inputUpdateEventListener;
/*     */   
/*     */   public BlockMove() {
/*  21 */     this.middle = registerBoolean("Middle", true);
/*  22 */     this.delay = registerInteger("Delay", 250, 0, 2000);
/*  23 */     this.only = registerBoolean("Only In Block", true);
/*  24 */     this.avoid = registerBoolean("Avoid Out", true, () -> Boolean.valueOf(!((Boolean)this.only.getValue()).booleanValue()));
/*  25 */     this.timer = new Timing();
/*     */     
/*  27 */     this.sides = new Vec3d[] { new Vec3d(0.24D, 0.0D, 0.24D), new Vec3d(-0.24D, 0.0D, 0.24D), new Vec3d(0.24D, 0.0D, -0.24D), new Vec3d(-0.24D, 0.0D, -0.24D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  34 */     this.inputUpdateEventListener = new Listener(event -> { Vec3d vec = mc.player.getPositionVector(); boolean air = true; AxisAlignedBB playerBox = mc.player.boundingBox; for (Vec3d vec3d : this.sides) { if (!air) break;  for (int i = 0; i < 2; i++) { BlockPos pos = new BlockPos(vec.add(vec3d).add(0.0D, i, 0.0D)); if (!BlockUtil.isAir(pos)) { AxisAlignedBB box = mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos); if (playerBox.intersects(box)) { air = false; break; }  }  }  }  if (air) return;  if (event.getMovementInput() instanceof net.minecraft.util.MovementInputFromOptions) { if (this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) { BlockPos pos = ((Boolean)this.middle.getValue()).booleanValue() ? PlayerUtil.getPlayerPos() : new BlockPos(Math.round(vec.x), vec.y, Math.round(vec.z)); EnumFacing facing = mc.player.getHorizontalFacing(); int x = (pos.offset(facing)).x - pos.x; int z = (pos.offset(facing)).z - pos.z; boolean addX = (x != 0); if ((event.getMovementInput()).forwardKeyDown) { vec = add(pos, addX, addX ? ((x < 0)) : ((z < 0))); } else if ((event.getMovementInput()).backKeyDown) { vec = add(pos, addX, addX ? ((x > 0)) : ((z > 0))); } else if ((event.getMovementInput()).leftKeyDown) { vec = add(pos, !addX, addX ? ((x > 0)) : ((z < 0))); } else if ((event.getMovementInput()).rightKeyDown) { vec = add(pos, !addX, addX ? ((x < 0)) : ((z > 0))); }  if (vec != null) { mc.player.setPosition(vec.x, vec.y, vec.z); this.timer.reset(); }  }  (event.getMovementInput()).forwardKeyDown = false; (event.getMovementInput()).backKeyDown = false; (event.getMovementInput()).leftKeyDown = false; (event.getMovementInput()).rightKeyDown = false; (event.getMovementInput()).moveForward = 0.0F; (event.getMovementInput()).moveStrafe = 0.0F; }  }200, new java.util.function.Predicate[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vec3d add(BlockPos pos, boolean x, boolean negative) {
/*     */     Vec3d vec;
/*  86 */     if (negative)
/*  87 */     { if (x) { vec = pos(pos.add(-1, 0, 0)); }
/*  88 */       else { vec = pos(pos.add(0, 0, -1)); }
/*     */        }
/*  90 */     else if (x) { vec = pos(pos.add(1, 0, 0)); }
/*  91 */     else { vec = pos(pos.add(0, 0, 1)); }
/*     */     
/*  93 */     return vec;
/*     */   }
/*     */   private Vec3d pos(BlockPos pos) {
/*  96 */     if (((Boolean)this.middle.getValue()).booleanValue()) return new Vec3d(pos.x + 0.5D, pos.y, pos.z + 0.5D); 
/*  97 */     Vec3d vec = new Vec3d(pos.x, pos.y, pos.z);
/*  98 */     Vec3d lastVec = vec;
/*  99 */     boolean any = (!mc.world.isAirBlock(pos) || !mc.world.isAirBlock(pos.up()));
/*     */     
/* 101 */     vec = new Vec3d(pos.x - 1.0E-8D, pos.y, pos.z);
/* 102 */     if (mc.world.isAirBlock(new BlockPos(vec)) && mc.world.isAirBlock((new BlockPos(vec)).up())) { lastVec = vec; }
/* 103 */     else { any = true; }
/* 104 */      vec = new Vec3d(pos.x, pos.y, pos.z - 1.0E-8D);
/* 105 */     if (mc.world.isAirBlock(new BlockPos(vec)) && mc.world.isAirBlock((new BlockPos(vec)).up())) { lastVec = vec; }
/* 106 */     else { any = true; }
/* 107 */      vec = new Vec3d(pos.x - 1.0E-8D, pos.y, pos.z - 1.0E-8D);
/* 108 */     if (mc.world.isAirBlock(new BlockPos(vec)) && mc.world.isAirBlock((new BlockPos(vec)).up())) { lastVec = vec; }
/* 109 */     else { any = true; }
/*     */     
/* 111 */     if (!((Boolean)this.only.getValue()).booleanValue() && !any && ((Boolean)this.avoid.getValue()).booleanValue()) return null;
/*     */     
/* 113 */     return lastVec;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\BlockMove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
