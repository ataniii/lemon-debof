//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.combat.DamageUtil;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "SelfBed", category = Category.Dev, priority = 999)
/*     */ public class SelfBed extends Module {
/*     */   ModeSetting page;
/*     */   BooleanSetting packetPlace;
/*     */   BooleanSetting placeSwing;
/*     */   BooleanSetting breakSwing;
/*     */   BooleanSetting packetSwing;
/*     */   BooleanSetting highVersion;
/*     */   BooleanSetting autoSwitch;
/*     */   BooleanSetting update;
/*     */   
/*     */   public SelfBed() {
/*  44 */     this.page = registerMode("Page", Arrays.asList(new String[] { "General", "Calc" }, ), "General");
/*  45 */     this.packetPlace = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  46 */     this.placeSwing = registerBoolean("Place Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  47 */     this.breakSwing = registerBoolean("Break Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  48 */     this.packetSwing = registerBoolean("Packet Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  49 */     this.highVersion = registerBoolean("1.13", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  50 */     this.autoSwitch = registerBoolean("Auto Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  51 */     this.update = registerBoolean("Update", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  52 */     this.silentSwitch = registerBoolean("Switch Back", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("General") && ((Boolean)this.autoSwitch.getValue()).booleanValue())));
/*  53 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*     */     
/*  55 */     this.calcDelay = registerInteger("Calc Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  56 */     this.placeDelay = registerInteger("Place Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  57 */     this.breakDelay = registerInteger("Break Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  58 */     this.range = registerDouble("Place Range", 5.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  59 */     this.yRange = registerDouble("Y Range", 2.5D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  60 */     this.handMode = registerMode("Hand", Arrays.asList(new String[] { "Main", "Off", "Auto" }, ), "Auto", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  61 */     this.maxDmg = registerDouble("Max Self Dmg", 10.0D, 0.0D, 20.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  62 */     this.antiSuicide = registerBoolean("Anti Suicide", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.basetiming = new Timing();
/*  67 */     this.calctiming = new Timing();
/*  68 */     this.placetiming = new Timing();
/*  69 */     this.breaktiming = new Timing();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketHeldItemChange) this.nowSlot = ((CPacketHeldItemChange)event.getPacket()).getSlotId();  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   BooleanSetting silentSwitch; BooleanSetting packetSwitch; IntegerSetting calcDelay; IntegerSetting placeDelay; IntegerSetting breakDelay; DoubleSetting range; DoubleSetting yRange; ModeSetting handMode; DoubleSetting maxDmg; BooleanSetting antiSuicide; BlockPos headPos; BlockPos basePos; float damage; float selfDamage; String face; Timing basetiming; Timing calctiming; Timing placetiming; Timing breaktiming; EnumHand hand; int slot; Vec2f rotation; int nowSlot; @EventHandler
/*     */   private final Listener<PacketEvent.Send> postSendListener;
/*     */   
/*     */   public void onUpdate() {
/*  81 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether()) {
/*  82 */       this.headPos = this.basePos = null;
/*  83 */       this.damage = this.selfDamage = 0.0F;
/*  84 */       this.rotation = null;
/*     */       return;
/*     */     } 
/*  87 */     calc();
/*     */   }
/*     */ 
/*     */   
/*     */   public void fast() {
/*  92 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether())
/*     */       return; 
/*  94 */     if (mc.player.movementInput.moveForward == 0.0F && mc.player.movementInput.moveStrafe == 0.0F)
/*  95 */       return;  bedaura();
/*     */   }
/*     */   
/*     */   private void bedaura() {
/*  99 */     if (this.headPos == null || this.basePos == null)
/* 100 */       return;  if (isBed(this.headPos) || isBed(this.basePos)) breakBed();
/*     */     
/* 102 */     place();
/* 103 */     breakBed();
/*     */   }
/*     */   
/*     */   private void calc() {
/* 107 */     if (this.calctiming.passedMs(((Integer)this.calcDelay.getValue()).intValue())) {
/* 108 */       this.calctiming.reset();
/*     */       
/* 110 */       this.headPos = this.basePos = null;
/* 111 */       this.damage = this.selfDamage = 0.0F;
/* 112 */       this.rotation = null;
/* 113 */       if (mc.player.movementInput.moveForward == 0.0F && mc.player.movementInput.moveStrafe == 0.0F)
/*     */         return; 
/* 115 */       boolean offhand = (!((String)this.handMode.getValue()).equals("Main") && mc.player.getHeldItemOffhand().getItem() == Items.BED);
/* 116 */       if (!offhand && !((String)this.handMode.getValue()).equals("Off")) {
/* 117 */         this.slot = BurrowUtil.findHotbarBlock(ItemBed.class);
/* 118 */         if (this.slot == -1)
/*     */           return; 
/* 120 */       }  this.hand = offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
/*     */       
/* 122 */       BlockPos bedPos = findBlocksExcluding();
/* 123 */       if (bedPos == null)
/*     */         return; 
/* 125 */       this.headPos = bedPos;
/*     */       
/* 127 */       if (mc.player.getHorizontalFacing().equals(EnumFacing.SOUTH)) {
/* 128 */         this.face = "SOUTH";
/* 129 */         this.rotation = new Vec2f(0.0F, 90.0F);
/* 130 */         bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z - 1);
/* 131 */       } else if (mc.player.getHorizontalFacing().equals(EnumFacing.WEST)) {
/* 132 */         this.face = "WEST";
/* 133 */         this.rotation = new Vec2f(90.0F, 90.0F);
/* 134 */         bedPos = new BlockPos(this.headPos.x + 1, this.headPos.y, this.headPos.z);
/* 135 */       } else if (mc.player.getHorizontalFacing().equals(EnumFacing.NORTH)) {
/* 136 */         this.face = "NORTH";
/* 137 */         this.rotation = new Vec2f(180.0F, 90.0F);
/* 138 */         bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z + 1);
/*     */       } else {
/* 140 */         this.face = "EAST";
/* 141 */         this.rotation = new Vec2f(-90.0F, 90.0F);
/* 142 */         bedPos = new BlockPos(this.headPos.x - 1, this.headPos.y, this.headPos.z);
/*     */       } 
/* 144 */       if (!block(bedPos, true)) {
/* 145 */         this.headPos = this.basePos = null;
/* 146 */         this.damage = this.selfDamage = 0.0F;
/* 147 */         this.rotation = null;
/*     */         return;
/*     */       } 
/* 150 */       this.headPos = this.headPos.up();
/* 151 */       this.basePos = bedPos.up();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void place() {
/* 156 */     if (this.placetiming.passedMs(((Integer)this.placeDelay.getValue()).intValue())) {
/* 157 */       BlockPos neighbour = this.basePos.down();
/* 158 */       EnumFacing opposite = EnumFacing.DOWN.getOpposite();
/*     */       
/* 160 */       Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 161 */       boolean sneak = false;
/* 162 */       if (BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) && !mc.player.isSneaking()) {
/* 163 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 164 */         sneak = true;
/*     */       } 
/* 166 */       run(() -> BurrowUtil.rightClickBlock(neighbour, hitVec, this.hand, opposite, ((Boolean)this.packetPlace.getValue()).booleanValue()), this.slot);
/* 167 */       if (((Boolean)this.placeSwing.getValue()).booleanValue()) swing(this.hand); 
/* 168 */       if (sneak) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 169 */       this.placetiming.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void run(Runnable runnable, int slot) {
/* 174 */     if (this.hand == EnumHand.OFF_HAND) {
/* 175 */       runnable.run();
/*     */       
/*     */       return;
/*     */     } 
/* 179 */     int oldSlot = mc.player.inventory.currentItem;
/* 180 */     if (slot != oldSlot)
/* 181 */     { if (((Boolean)this.autoSwitch.getValue()).booleanValue()) {
/* 182 */         switchTo(slot);
/* 183 */         if (this.nowSlot == slot || mc.player.getHeldItemMainhand().getItem() == Items.BED) runnable.run(); 
/* 184 */         if (((Boolean)this.silentSwitch.getValue()).booleanValue()) switchTo(oldSlot); 
/*     */       }  }
/* 186 */     else { runnable.run(); }
/*     */   
/*     */   }
/*     */   private void breakBed() {
/* 190 */     if (this.breaktiming.passedMs(((Integer)this.breakDelay.getValue()).intValue())) {
/* 191 */       EnumFacing side = EnumFacing.UP;
/* 192 */       if (((ColorMain)ModuleManager.getModule(ColorMain.class)).sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 193 */       Vec3d facing = getHitVecOffset(side);
/* 194 */       if (isBed(this.headPos) && !isBed(this.basePos)) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.headPos, side, this.hand, (float)facing.x, (float)facing.y, (float)facing.z)); }
/* 195 */       else { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.basePos, side, this.hand, (float)facing.x, (float)facing.y, (float)facing.z)); }
/* 196 */        if (((Boolean)this.breakSwing.getValue()).booleanValue()) swing(this.hand); 
/* 197 */       this.breaktiming.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private BlockPos findBlocksExcluding() {
/* 202 */     double x = mc.player.prevPosX;
/* 203 */     double z = mc.player.prevPosZ;
/* 204 */     double dX = mc.player.posX - x, dZ = mc.player.posZ - z;
/* 205 */     List<BlockPos> posList = new ArrayList<>();
/*     */     
/* 207 */     for (int y : new int[] { -3, -2, -1, 0, 1, 2 }) { posList.addAll((Collection<? extends BlockPos>)EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(1.0D), false, false, y).stream().filter(p -> ((mc.player.posX - x) * (mc.player.posX - p.x) > 0.0D && (mc.player.posZ - z) * (mc.player.posZ - p.z) > 0.0D)).filter(this::canPlaceBed).filter(p -> ((x - p.x) * dX >= 0.0D && (z - p.z) * dZ >= 0.0D)).filter(p -> {
/*     */               double dmg = DamageUtil.calculateDamage((EntityLivingBase)mc.player, p.x + 0.5D, p.y + 1.5625D, p.z + 0.5D, 5.0F, "Bed");
/* 209 */               return (dmg <= ((Double)this.maxDmg.getValue()).doubleValue() && (!((Boolean)this.antiSuicide.getValue()).booleanValue() || dmg <= (EntityUtil.getHealth((Entity)mc.player) + 1.0F)));
/* 210 */             }).collect(Collectors.toList())); }
/* 211 */      BlockPos pos = posList.stream().min(Comparator.comparing(mc.player::getDistanceSq)).orElse(null);
/* 212 */     return pos;
/*     */   }
/*     */   
/*     */   private boolean canPlaceBed(BlockPos blockPos) {
/* 216 */     if (!block(blockPos, false)) return false; 
/* 217 */     BlockPos pos = blockPos.offset(mc.player.getHorizontalFacing(), -1);
/* 218 */     return (block(pos, true) && inRange(pos.up()));
/*     */   }
/*     */   private boolean block(BlockPos pos, boolean rangeCheck) {
/* 221 */     if (!space(pos.up())) return false; 
/* 222 */     if (BlockUtil.canReplace(pos)) return false; 
/* 223 */     if (!((Boolean)this.highVersion.getValue()).booleanValue() && !solid(pos)) return false; 
/* 224 */     return (!rangeCheck || inRange(pos.up()));
/*     */   }
/*     */   
/*     */   private boolean isBed(BlockPos pos) {
/* 228 */     Block block = mc.world.getBlockState(pos).getBlock();
/* 229 */     return (block == Blocks.BED || block instanceof net.minecraft.block.BlockBed);
/*     */   }
/*     */   
/*     */   private boolean space(BlockPos pos) {
/* 233 */     return (mc.world.isAirBlock(pos) || mc.world.getBlockState(pos).getBlock() == Blocks.BED);
/*     */   }
/*     */   
/*     */   private boolean solid(BlockPos pos) {
/* 237 */     return (!BlockUtil.isBlockUnSolid(pos) && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockBed) && mc.world.getBlockState(pos).isSideSolid((IBlockAccess)mc.world, pos, EnumFacing.UP));
/*     */   }
/*     */   
/*     */   private boolean inRange(BlockPos pos) {
/* 241 */     double x = pos.x - mc.player.posX;
/* 242 */     double z = pos.z - mc.player.posZ;
/* 243 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/* 244 */     double add = Math.sqrt(y * y) / 2.0D;
/* 245 */     return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue());
/*     */   }
/*     */   
/*     */   private Vec3d getHitVecOffset(EnumFacing face) {
/* 249 */     Vec3i vec = face.getDirectionVec();
/* 250 */     return new Vec3d((vec.x * 0.5F + 0.5F), (vec.y * 0.5F + 0.5F), (vec.z * 0.5F + 0.5F));
/*     */   }
/*     */   
/*     */   private void switchTo(int slot) {
/* 254 */     if (slot > -1 && slot < 9) {
/* 255 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 256 */       else { mc.player.inventory.currentItem = slot; }
/* 257 */        if (((Boolean)this.update.getValue()).booleanValue()) mc.playerController.updateController(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void swing(EnumHand hand) {
/* 262 */     if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); }
/* 263 */     else { mc.player.swingArm(hand); }
/*     */   
/*     */   }
/*     */   private boolean inNether() {
/* 267 */     return (mc.player.dimension == 0);
/*     */   }
/*     */   
/*     */   public void onEnable() {
/* 271 */     this.calctiming.reset();
/* 272 */     this.basetiming.reset();
/* 273 */     this.placetiming.reset();
/* 274 */     this.breaktiming.reset();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\SelfBed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
