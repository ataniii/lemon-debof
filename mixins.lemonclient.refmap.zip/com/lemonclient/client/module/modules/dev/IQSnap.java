//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;@Declaration(name = "IQSnap", category = Category.Dev, priority = 120)
/*     */ public class IQSnap extends Module { IntegerSetting targetRange; IntegerSetting fixedRange; IntegerSetting cancelRange; IntegerSetting downRange; IntegerSetting upRange; DoubleSetting hRange; DoubleSetting timer; DoubleSetting speed; BooleanSetting step; ModeSetting mode; ModeSetting height; ModeSetting vHeight; BooleanSetting abnormal; IntegerSetting centerSpeed; BooleanSetting only; BooleanSetting single;
/*     */   BooleanSetting twoBlocks;
/*     */   BooleanSetting custom;
/*     */   BooleanSetting four;
/*     */   BooleanSetting near;
/*     */   BooleanSetting disable;
/*     */   BooleanSetting hud;
/*     */   private int stuckTicks;
/*     */   BlockPos originPos;
/*     */   BlockPos startPos;
/*     */   boolean isActive;
/*     */   boolean wasInHole;
/*     */   boolean slowDown;
/*     */   double playerSpeed;
/*     */   EntityPlayer target;
/*     */   @EventHandler
/*     */   private final Listener<InputUpdateEvent> inputUpdateEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveListener;
/*     */   double[] pointFiveToOne;
/*     */   double[] one;
/*     */   double[] oneFive;
/*     */   double[] oneSixTwoFive;
/*     */   double[] oneEightSevenFive;
/*     */   double[] two;
/*     */   double[] twoFive;
/*     */   double[] threeStep;
/*     */   double[] fourStep;
/*     */   double[] betaShared;
/*     */   double[] betaTwo;
/*     */   double[] betaTwoFive;
/*     */   @EventHandler
/*     */   private final Listener<StepEvent> stepEventListener;
/*     */   
/*  36 */   public IQSnap() { this.targetRange = registerInteger("Target Range", 16, 0, 256);
/*  37 */     this.fixedRange = registerInteger("Fixed Target Range", 16, 0, 256);
/*  38 */     this.cancelRange = registerInteger("Cancel Range", 6, 0, 16);
/*  39 */     this.downRange = registerInteger("Down Range", 5, 0, 8);
/*  40 */     this.upRange = registerInteger("Up Range", 1, 0, 8);
/*  41 */     this.hRange = registerDouble("H Range", 4.0D, 1.0D, 8.0D);
/*  42 */     this.timer = registerDouble("Timer", 2.0D, 1.0D, 50.0D);
/*  43 */     this.speed = registerDouble("Speed", 2.0D, 0.0D, 10.0D);
/*  44 */     this.step = registerBoolean("Step", true);
/*  45 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "NCP", "Vanilla" }, ), "NCP", () -> (Boolean)this.step.getValue());
/*  46 */     this.height = registerMode("NCP Height", Arrays.asList(new String[] { "1", "1.5", "2", "2.5", "3", "4" }, ), "2.5", () -> Boolean.valueOf((((String)this.mode.getValue()).equalsIgnoreCase("NCP") && ((Boolean)this.step.getValue()).booleanValue())));
/*  47 */     this.vHeight = registerMode("Vanilla Height", Arrays.asList(new String[] { "1", "1.5", "2", "2.5", "3", "4" }, ), "2.5", () -> Boolean.valueOf((((String)this.mode.getValue()).equalsIgnoreCase("Vanilla") && ((Boolean)this.step.getValue()).booleanValue())));
/*  48 */     this.abnormal = registerBoolean("Abnormal", false, () -> Boolean.valueOf((!((String)this.mode.getValue()).equalsIgnoreCase("Vanilla") && ((Boolean)this.step.getValue()).booleanValue())));
/*  49 */     this.centerSpeed = registerInteger("Center Speed", 2, 10, 1);
/*  50 */     this.only = registerBoolean("Only 1x1", true);
/*  51 */     this.single = registerBoolean("Single Hole", true, () -> Boolean.valueOf(!((Boolean)this.only.getValue()).booleanValue()));
/*  52 */     this.twoBlocks = registerBoolean("Double Hole", true, () -> Boolean.valueOf(!((Boolean)this.only.getValue()).booleanValue()));
/*  53 */     this.custom = registerBoolean("Custom Hole", true, () -> Boolean.valueOf(!((Boolean)this.only.getValue()).booleanValue()));
/*  54 */     this.four = registerBoolean("Four Blocks", true, () -> Boolean.valueOf(!((Boolean)this.only.getValue()).booleanValue()));
/*  55 */     this.near = registerBoolean("Near Target", true);
/*  56 */     this.disable = registerBoolean("Disable", true);
/*  57 */     this.hud = registerBoolean("Hud", true);
/*  58 */     this.stuckTicks = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.inputUpdateEventListener = new Listener(event -> { if (event.getMovementInput() instanceof net.minecraft.util.MovementInputFromOptions && this.isActive) { (event.getMovementInput()).jump = false; (event.getMovementInput()).sneak = false; (event.getMovementInput()).forwardKeyDown = false; (event.getMovementInput()).backKeyDown = false; (event.getMovementInput()).leftKeyDown = false; (event.getMovementInput()).rightKeyDown = false; (event.getMovementInput()).moveForward = 0.0F; (event.getMovementInput()).moveStrafe = 0.0F; }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     this.playerMoveListener = new Listener(event -> {
/*     */           this.isActive = false;
/*     */           TimerUtils.setTickLength(50.0F);
/*     */           if (!mc.player.isEntityAlive() || mc.player.isElytraFlying() || mc.player.capabilities.isFlying) {
/*     */             return;
/*     */           }
/*     */           double currentSpeed = Math.hypot(mc.player.motionX, mc.player.motionZ);
/*     */           if (currentSpeed <= 0.05D) {
/*     */             this.originPos = PlayerUtil.getPlayerPos();
/*     */           }
/*     */           this.target = getNearestPlayer(this.target);
/*     */           if (this.target == null)
/*     */             return; 
/*     */           double range = mc.player.getDistance((Entity)this.target);
/*     */           boolean inRange = (range <= ((Integer)this.cancelRange.getValue()).intValue());
/*     */           if (shouldDisable(Double.valueOf(currentSpeed), inRange)) {
/*     */             if (((Boolean)this.disable.getValue()).booleanValue())
/*     */               disable(); 
/*     */             return;
/*     */           } 
/*     */           BlockPos hole = findHoles(this.target, inRange);
/*     */           if (hole != null) {
/*     */             double x = hole.getX() + 0.5D;
/*     */             double y = hole.getY();
/*     */             double z = hole.getZ() + 0.5D;
/*     */             if (checkYRange((int)mc.player.posY, this.originPos.y)) {
/*     */               Vec3d playerPos = mc.player.getPositionVector();
/*     */               double yawRad = Math.toRadians((RotationUtil.getRotationTo(playerPos, new Vec3d(x, y, z))).x);
/*     */               double dist = Math.hypot(x - playerPos.x, z - playerPos.z);
/*     */               if (mc.player.onGround) {
/* 149 */                 this.playerSpeed = MotionUtil.getBaseMoveSpeed() * ((EntityUtil.isColliding(0.0D, -0.5D, 0.0D) instanceof net.minecraft.block.BlockLiquid && !EntityUtil.isInLiquid()) ? 0.91D : ((Double)this.speed.getValue()).doubleValue());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 this.slowDown = true;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               double speed = Math.min(dist, this.playerSpeed);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               mc.player.motionX = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               mc.player.motionZ = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               event.setX(-Math.sin(yawRad) * speed);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               event.setZ(Math.cos(yawRad) * speed);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (speed != 0.0D && (-Math.sin(yawRad) != 0.0D || Math.cos(yawRad) != 0.0D)) {
/*     */                 TimerUtils.setTickLength((float)(50.0D / ((Double)this.timer.getValue()).doubleValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 this.isActive = true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (mc.player.collidedHorizontally && hole == null) {
/*     */             this.stuckTicks++;
/*     */           } else {
/*     */             this.stuckTicks = 0;
/*     */           } 
/*     */         }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     this.pointFiveToOne = new double[] { 0.41999998688698D };
/* 269 */     this.one = new double[] { 0.41999998688698D, 0.7531999805212D };
/* 270 */     this.oneFive = new double[] { 0.42D, 0.753D, 1.001D, 1.084D, 1.006D };
/* 271 */     this.oneSixTwoFive = new double[] { 0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D };
/* 272 */     this.oneEightSevenFive = new double[] { 0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D };
/* 273 */     this.two = new double[] { 0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D };
/* 274 */     this.twoFive = new double[] { 0.425D, 0.821D, 0.699D, 0.599D, 1.022D, 1.372D, 1.652D, 1.869D, 2.019D, 1.907D };
/* 275 */     this.threeStep = new double[] { 0.42D, 0.78D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D, 1.78D, 1.63D, 1.51D, 1.9D, 2.21D, 2.45D, 2.43D };
/* 276 */     this.fourStep = new double[] { 0.42D, 0.75D, 0.63D, 0.51D, 0.9D, 1.21D, 1.45D, 1.43D, 1.78D, 1.63D, 1.51D, 1.9D, 2.21D, 2.45D, 2.43D, 2.78D, 2.63D, 2.51D, 2.9D, 3.21D, 3.45D, 3.43D };
/*     */     
/* 278 */     this.betaShared = new double[] { 0.419999986887D, 0.7531999805212D, 1.0013359791121D, 1.1661092609382D, 1.249187078744682D, 1.176759275064238D };
/* 279 */     this.betaTwo = new double[] { 1.596759261951216D, 1.929959255585439D };
/* 280 */     this.betaTwoFive = new double[] { 1.596759261951216D, 1.929959255585439D, 2.178095254176385D, 2.3428685360024515D, 2.425946353808919D };
/*     */ 
/*     */     
/* 283 */     this.stepEventListener = new Listener(event -> { if (!canStep()) return;  double step = (event.getBB()).minY - mc.player.posY; if (((String)this.mode.getValue()).equalsIgnoreCase("Vanilla")) return;  if (((String)this.mode.getValue()).equalsIgnoreCase("NCP")) { if (step == 0.625D && ((Boolean)this.abnormal.getValue()).booleanValue()) { sendOffsets(this.pointFiveToOne); } else if (step == 1.0D || ((step == 0.875D || step == 1.0625D || step == 0.9375D) && ((Boolean)this.abnormal.getValue()).booleanValue())) { sendOffsets(this.one); } else if (step == 1.5D) { sendOffsets(this.oneFive); } else if (step == 1.875D && ((Boolean)this.abnormal.getValue()).booleanValue()) { sendOffsets(this.oneEightSevenFive); } else if (step == 1.625D && ((Boolean)this.abnormal.getValue()).booleanValue()) { sendOffsets(this.oneSixTwoFive); } else if (step == 2.0D) { sendOffsets(this.two); } else if (step == 2.5D) { sendOffsets(this.twoFive); } else if (step == 3.0D) { sendOffsets(this.threeStep); } else if (step == 4.0D) { sendOffsets(this.fourStep); } else { event.cancel(); }  } else if (((String)this.mode.getValue()).equalsIgnoreCase("Beta")) { if (step == 1.5D) { sendOffsets(this.betaShared); } else if (step == 2.0D) { sendOffsets(this.betaShared); sendOffsets(this.betaTwo); } else if (step == 2.5D) { sendOffsets(this.betaShared); sendOffsets(this.betaTwoFive); } else if (step == 3.0D) { sendOffsets(this.betaShared); sendOffsets(this.threeStep); } else if (step == 4.0D) { sendOffsets(this.betaShared); sendOffsets(this.fourStep); } else { event.cancel(); }  }  }new java.util.function.Predicate[0]); }
/*     */ 
/*     */ 
/*     */   
/*     */   private EntityPlayer getNearestPlayer(EntityPlayer target) {
/*     */     if (target != null && mc.player.getDistance((Entity)target) <= ((Integer)this.fixedRange.getValue()).intValue() && !EntityUtil.basicChecksEntity(target)) {
/*     */       return target;
/*     */     }
/*     */     return mc.world.playerEntities.stream().filter(p -> (mc.player.getDistance((Entity)p) <= ((Integer)this.targetRange.getValue()).intValue())).filter(p -> (mc.player.entityId != p.entityId)).filter(p -> !EntityUtil.basicChecksEntity(p)).min(Comparator.comparing(p -> Float.valueOf(mc.player.getDistance((Entity)p)))).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*     */     this.wasInHole = false;
/*     */     this.startPos = this.originPos = PlayerUtil.getPlayerPos();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*     */     if (mc.world == null || mc.player == null || mc.player.isDead || this.startPos == null) {
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (canStep()) {
/*     */       mc.player.stepHeight = getHeight((String)this.mode.getValue());
/*     */     } else {
/*     */       if (mc.player.getRidingEntity() != null) {
/*     */         (mc.player.getRidingEntity()).stepHeight = 1.0F;
/*     */       }
/*     */       mc.player.stepHeight = 0.6F;
/*     */     } 
/*     */     if (this.target == null) {
/*     */       this.isActive = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*     */     this.isActive = false;
/*     */     this.stuckTicks = 0;
/*     */     TimerUtils.setTickLength(50.0F);
/*     */     if (mc.player != null) {
/*     */       if (mc.player.getRidingEntity() != null) {
/*     */         (mc.player.getRidingEntity()).stepHeight = 1.0F;
/*     */       }
/*     */       mc.player.stepHeight = 0.6F;
/*     */     } 
/*     */   }
/*     */   
/*     */   float getHeight(String mode) {
/* 333 */     return Float.parseFloat(mode.equals("Vanilla") ? (String)this.vHeight.getValue() : (String)this.height.getValue());
/*     */   }
/*     */   private BlockPos findHoles(EntityPlayer target, boolean inRange) { if (inRange && this.wasInHole) return null;  this.wasInHole = false; NonNullList<BlockPos> holes = NonNullList.create(); List<BlockPos> blockPosList = EntityUtil.getSphere(EntityUtil.getPlayerPos(target), (Double)this.hRange.getValue(), Double.valueOf(8.0D), false, true, 0); blockPosList.forEach(pos -> { if (!checkYRange((int)mc.player.posY, pos.y)) return;  if (!mc.world.isAirBlock(PlayerUtil.getPlayerPos().up(2)) && (int)mc.player.posY < pos.y) return;  HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(pos, ((Boolean)this.only.getValue()).booleanValue(), false, false); HoleUtil.HoleType holeType = holeInfo.getType(); if (holeType != HoleUtil.HoleType.NONE) { if (((Boolean)this.only.getValue()).booleanValue()) { if (holeType != HoleUtil.HoleType.SINGLE) return;  } else { if (!((Boolean)this.single.getValue()).booleanValue() && holeType == HoleUtil.HoleType.SINGLE) return;  if (!((Boolean)this.twoBlocks.getValue()).booleanValue() && holeType == HoleUtil.HoleType.DOUBLE) return;  if (!((Boolean)this.custom.getValue()).booleanValue() && holeType == HoleUtil.HoleType.CUSTOM) return;  if (!((Boolean)this.four.getValue()).booleanValue() && holeType == HoleUtil.HoleType.FOUR) return;  }  if (mc.world.isAirBlock(pos) && mc.world.isAirBlock(pos.add(0, 1, 0)) && mc.world.isAirBlock(pos.add(0, 2, 0))) { for (int high = 0; high < mc.player.posY - pos.y; high++) { if (high != 0) { if (mc.player.posY > pos.y && !mc.world.isAirBlock(new BlockPos(pos.x, pos.y + high, pos.z))) return;  if (mc.player.posY < pos.y) { BlockPos newPos = new BlockPos(pos.x, pos.y + high, pos.z); if (mc.world.isAirBlock(newPos) && (mc.world.isAirBlock(newPos.down()) || mc.world.isAirBlock(newPos.up()))) return;  }  }  }  holes.add(pos); }  }  }); return holes.stream().min(Comparator.comparing(p -> Double.valueOf(((Boolean)this.near.getValue()).booleanValue() ? target.getDistance(p.x + 0.5D, p.y, p.z + 0.5D) : mc.player.getDistance(p.x + 0.5D, p.y, p.z + 0.5D)))).orElse(null); }
/*     */   private boolean shouldDisable(Double currentSpeed, boolean inRange) { if (this.isActive) return false;  if (!mc.player.onGround) return false;  if (this.stuckTicks > 5 && currentSpeed.doubleValue() < 0.05D) return true;  HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(new BlockPos((PlayerUtil.getPlayerPos()).x, (PlayerUtil.getPlayerPos()).y + 0.5D, (PlayerUtil.getPlayerPos()).z), false, false, false); HoleUtil.HoleType holeType = holeInfo.getType(); if (holeType != HoleUtil.HoleType.NONE && inRange) { if (((Boolean)this.only.getValue()).booleanValue()) { if (holeType != HoleUtil.HoleType.SINGLE) return false;  } else { if (!((Boolean)this.single.getValue()).booleanValue() && holeType == HoleUtil.HoleType.SINGLE) return false;  if (!((Boolean)this.twoBlocks.getValue()).booleanValue() && holeType == HoleUtil.HoleType.DOUBLE) return false;  if (!((Boolean)this.custom.getValue()).booleanValue() && holeType == HoleUtil.HoleType.CUSTOM) return false;  if (!((Boolean)this.four.getValue()).booleanValue() && holeType == HoleUtil.HoleType.FOUR) return false;  }  Vec3d center = getCenter(holeInfo.getCentre()); double XDiff = Math.abs(center.x - mc.player.posX); double ZDiff = Math.abs(center.z - mc.player.posZ); if ((XDiff > 0.3D || ZDiff > 0.3D) && !this.wasInHole) { double MotionX = center.x - mc.player.posX; double MotionZ = center.z - mc.player.posZ; mc.player.motionX = MotionX / ((Integer)this.centerSpeed.getValue()).intValue(); mc.player.motionZ = MotionZ / ((Integer)this.centerSpeed.getValue()).intValue(); }  this.wasInHole = true; return true; }  return false; }
/* 337 */   public Vec3d getCenter(AxisAlignedBB box) { boolean air = mc.world.isAirBlock(new BlockPos(box.minX, box.minY + 1.0D, box.minZ)); return air ? new Vec3d(box.minX + (box.maxX - box.minX) / 2.0D, box.minY, box.minZ + (box.maxZ - box.minZ) / 2.0D) : new Vec3d(box.maxX - 0.5D, box.minY, box.maxZ - 0.5D); } private boolean checkYRange(int playerY, int holeY) { if (playerY >= holeY) return (playerY - holeY <= ((Integer)this.downRange.getValue()).intValue());  return (holeY - playerY <= -((Integer)this.upRange.getValue()).intValue()); } protected boolean canStep() { return (!mc.player.isInWater() && mc.player.onGround && 
/*     */       
/* 339 */       !mc.player.isOnLadder() && !mc.player.movementInput.jump && mc.player.collidedVertically && mc.player.fallDistance < 0.1D && ((Boolean)this.step
/*     */ 
/*     */ 
/*     */       
/* 343 */       .getValue()).booleanValue() && this.isActive); }
/*     */ 
/*     */ 
/*     */   
/*     */   void sendOffsets(double[] offsets) {
/* 348 */     for (double i : offsets) {
/* 349 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + i + 0.0D, mc.player.posZ, false));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHudInfo() {
/* 354 */     return ((Boolean)this.hud.getValue()).booleanValue() ? ("[" + ChatFormatting.WHITE + ((this.target == null) ? "None" : (this.target.getName() + ", " + (this.isActive ? "Chasing" : "Pausing"))) + ChatFormatting.GRAY + "]") : "";
/*     */   } }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\IQSnap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
