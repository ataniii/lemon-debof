//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*     */ 
/*     */ @Declaration(name = "FakePlayerDev", category = Category.Dev)
/*     */ public class FakePlayerDev extends Module {
/*     */   private final ItemStack[] armors;
/*     */   StringSetting nameFakePlayer;
/*     */   BooleanSetting copyInventory;
/*     */   BooleanSetting playerStacked;
/*     */   BooleanSetting onShift;
/*     */   BooleanSetting simulateDamage;
/*     */   IntegerSetting vulnerabilityTick;
/*     */   IntegerSetting resetHealth;
/*     */   IntegerSetting tickRegenVal;
/*     */   IntegerSetting startHealth;
/*     */   ModeSetting moving;
/*     */   DoubleSetting speed;
/*     */   DoubleSetting range;
/*     */   BooleanSetting followPlayer;
/*     */   BooleanSetting resistance;
/*     */   BooleanSetting pop;
/*     */   int incr;
/*     */   boolean beforePressed;
/*     */   ArrayList<playerInfo> listPlayers;
/*     */   movingManager manager;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> packetReceiveListener;
/*     */   
/*     */   public FakePlayerDev() {
/*  41 */     this.armors = new ItemStack[] { new ItemStack((Item)Items.DIAMOND_BOOTS), new ItemStack((Item)Items.DIAMOND_LEGGINGS), new ItemStack((Item)Items.DIAMOND_CHESTPLATE), new ItemStack((Item)Items.DIAMOND_HELMET) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.nameFakePlayer = registerString("Name FakePlayer", "NotLazyOfLazys");
/*  48 */     this.copyInventory = registerBoolean("Copy Inventory", false);
/*  49 */     this.playerStacked = registerBoolean("Player Stacked", false);
/*  50 */     this.onShift = registerBoolean("On Shift", false);
/*  51 */     this.simulateDamage = registerBoolean("Simulate Damage", false);
/*  52 */     this.vulnerabilityTick = registerInteger("Vulnerability Tick", 4, 0, 10);
/*  53 */     this.resetHealth = registerInteger("Reset Health", 10, 0, 36);
/*  54 */     this.tickRegenVal = registerInteger("Tick Regen", 4, 0, 30);
/*  55 */     this.startHealth = registerInteger("Start Health", 20, 0, 30);
/*  56 */     this.moving = registerMode("Moving", Arrays.asList(new String[] { "None", "Line", "Circle", "Random" }, ), "None");
/*  57 */     this.speed = registerDouble("Speed", 0.36D, 0.0D, 4.0D);
/*  58 */     this.range = registerDouble("Range", 3.0D, 0.0D, 14.0D);
/*  59 */     this.followPlayer = registerBoolean("Follow Player", true);
/*  60 */     this.resistance = registerBoolean("Resistance", true);
/*  61 */     this.pop = registerBoolean("Pop", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     this.listPlayers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     this.manager = new movingManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     this.packetReceiveListener = new Listener(event -> { if (((Boolean)this.simulateDamage.getValue()).booleanValue()) { Packet<?> packet = event.getPacket(); if (packet instanceof SPacketSoundEffect) { SPacketSoundEffect packetSoundEffect = (SPacketSoundEffect)packet; if (packetSoundEffect.getCategory() == SoundCategory.BLOCKS && packetSoundEffect.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) for (Entity entity : new ArrayList(mc.world.loadedEntityList)) { if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal && entity.getDistanceSq(packetSoundEffect.getX(), packetSoundEffect.getY(), packetSoundEffect.getZ()) <= 36.0D) for (EntityPlayer entityPlayer : mc.world.playerEntities) { if ((entityPlayer.getName().split(this.nameFakePlayer.getText())).length == 2) { Optional<playerInfo> temp = this.listPlayers.stream().filter(()).findAny(); if (!temp.isPresent() || !((playerInfo)temp.get()).canPop()) continue;  float damage = DamageUtil.calculateDamage((EntityLivingBase)entityPlayer, packetSoundEffect.getX(), packetSoundEffect.getY(), packetSoundEffect.getZ(), 6.0F, "Default"); if (damage > entityPlayer.getHealth()) { entityPlayer.setHealth(((Integer)this.resetHealth.getValue()).intValue()); if (((Boolean)this.pop.getValue()).booleanValue()) { mc.effectRenderer.emitParticleAtEntity((Entity)entityPlayer, EnumParticleTypes.TOTEM, 30); mc.world.playSound(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ, SoundEvents.ITEM_TOTEM_USE, entity.getSoundCategory(), 1.0F, 1.0F, false); }  LemonClient.EVENT_BUS.post(new TotemPopEvent((Entity)entityPlayer)); } else { entityPlayer.setHealth(entityPlayer.getHealth() - damage); }  ((playerInfo)temp.get()).tickPop = 0; }  }   }   }  }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   public void onEnable() {
/*     */     this.incr = 0;
/*     */     this.beforePressed = false;
/*     */     if (mc.player == null || mc.player.isDead) {
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (!((Boolean)this.onShift.getValue()).booleanValue())
/*     */       spawnPlayer(); 
/*     */   }
/*     */   
/*     */   void spawnPlayer() {
/*     */     EntityOtherPlayerMP clonedPlayer = new EntityOtherPlayerMP((World)mc.world, new GameProfile(UUID.fromString("fdee323e-7f0c-4c15-8d1c-0f277442342a"), this.nameFakePlayer.getText()));
/*     */     clonedPlayer.copyLocationAndAnglesFrom((Entity)mc.player);
/*     */     clonedPlayer.rotationYawHead = mc.player.rotationYawHead;
/*     */     clonedPlayer.rotationYaw = mc.player.rotationYaw;
/*     */     clonedPlayer.rotationPitch = mc.player.rotationPitch;
/*     */     clonedPlayer.setGameType(GameType.SURVIVAL);
/*     */     clonedPlayer.setHealth(((Integer)this.startHealth.getValue()).intValue());
/*     */     mc.world.addEntityToWorld(-1234 + this.incr, (Entity)clonedPlayer);
/*     */     this.incr++;
/*     */     if (((Boolean)this.copyInventory.getValue()).booleanValue()) {
/*     */       clonedPlayer.inventory.copyInventory(mc.player.inventory);
/*     */     } else if (((Boolean)this.playerStacked.getValue()).booleanValue()) {
/*     */       for (int i = 0; i < 4; i++) {
/*     */         ItemStack item = this.armors[i];
/*     */         item.addEnchantment((i == 3) ? Enchantments.BLAST_PROTECTION : Enchantments.PROTECTION, 4);
/*     */         clonedPlayer.inventory.armorInventory.set(i, item);
/*     */       } 
/*     */     } 
/*     */     if (((Boolean)this.resistance.getValue()).booleanValue())
/*     */       clonedPlayer.addPotionEffect(new PotionEffect(Potion.getPotionById(11), 123456789, 0)); 
/*     */     clonedPlayer.onEntityUpdate();
/*     */     this.listPlayers.add(new playerInfo(clonedPlayer.getName()));
/*     */     if (!((String)this.moving.getValue()).equals("None"))
/*     */       this.manager.addPlayer(clonedPlayer.entityId, (String)this.moving.getValue(), ((Double)this.speed.getValue()).doubleValue(), ((String)this.moving.getValue()).equals("Line") ? getDirection() : -1, ((Double)this.range.getValue()).doubleValue(), ((Boolean)this.followPlayer.getValue()).booleanValue()); 
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*     */     if (((Boolean)this.onShift.getValue()).booleanValue() && mc.gameSettings.keyBindSneak.isPressed() && !this.beforePressed) {
/*     */       this.beforePressed = true;
/*     */       spawnPlayer();
/*     */     } else {
/*     */       this.beforePressed = false;
/*     */     } 
/*     */     for (int i = 0; i < this.listPlayers.size(); i++) {
/*     */       if (((playerInfo)this.listPlayers.get(i)).update()) {
/*     */         int finalI = i;
/*     */         Optional<EntityPlayer> temp = mc.world.playerEntities.stream().filter(e -> e.getName().equals(((playerInfo)this.listPlayers.get(finalI)).name)).findAny();
/*     */         if (temp.isPresent() && ((EntityPlayer)temp.get()).getHealth() < 20.0F)
/*     */           ((EntityPlayer)temp.get()).setHealth(((EntityPlayer)temp.get()).getHealth() + 1.0F); 
/*     */       } 
/*     */     } 
/*     */     this.manager.update();
/*     */   }
/*     */   
/*     */   int getDirection() {
/*     */     int yaw = (int)RotationUtil.normalizeAngle((mc.player.getPitchYaw()).y);
/*     */     if (yaw < 0)
/*     */       yaw += 360; 
/*     */     yaw += 22;
/*     */     yaw %= 360;
/*     */     return yaw / 45;
/*     */   }
/*     */   
/*     */   class playerInfo {
/*     */     final String name;
/*     */     int tickPop = -1;
/*     */     int tickRegen = 0;
/*     */     
/*     */     public playerInfo(String name) {
/*     */       this.name = name;
/*     */     }
/*     */     
/*     */     boolean update() {
/*     */       if (this.tickPop != -1 && ++this.tickPop >= ((Integer)FakePlayerDev.this.vulnerabilityTick.getValue()).intValue())
/*     */         this.tickPop = -1; 
/*     */       if (++this.tickRegen >= ((Integer)FakePlayerDev.this.tickRegenVal.getValue()).intValue()) {
/*     */         this.tickRegen = 0;
/*     */         return true;
/*     */       } 
/*     */       return false;
/*     */     }
/*     */     
/*     */     boolean canPop() {
/*     */       return (this.tickPop == -1);
/*     */     }
/*     */   }
/*     */   
/*     */   static class movingPlayer {
/*     */     private final int id;
/*     */     private final String type;
/*     */     private final double speed;
/*     */     private final int direction;
/*     */     private final double range;
/*     */     private final boolean follow;
/*     */     int rad = 0;
/*     */     
/*     */     public movingPlayer(int id, String type, double speed, int direction, double range, boolean follow) {
/*     */       this.id = id;
/*     */       this.type = type;
/*     */       this.speed = speed;
/*     */       this.direction = Math.abs(direction);
/*     */       this.range = range;
/*     */       this.follow = follow;
/*     */     }
/*     */     
/*     */     void move() {
/*     */       Entity player = FakePlayerDev.mc.world.getEntityByID(this.id);
/*     */       if (player != null) {
/*     */         double posX;
/*     */         double posY;
/*     */         double posZ;
/*     */         double posXCir;
/*     */         double posZCir;
/*     */         double posYCir;
/*     */         switch (this.type) {
/*     */           case "Line":
/*     */             posX = this.follow ? FakePlayerDev.mc.player.posX : player.posX;
/*     */             posY = this.follow ? FakePlayerDev.mc.player.posY : player.posY;
/*     */             posZ = this.follow ? FakePlayerDev.mc.player.posZ : player.posZ;
/*     */             switch (this.direction) {
/*     */               case 0:
/*     */                 posZ += this.speed;
/*     */                 break;
/*     */               case 1:
/*     */                 posX -= this.speed / 2.0D;
/*     */                 posZ += this.speed / 2.0D;
/*     */                 break;
/*     */               case 2:
/*     */                 posX -= this.speed / 2.0D;
/*     */                 break;
/*     */               case 3:
/*     */                 posZ -= this.speed / 2.0D;
/*     */                 posX -= this.speed / 2.0D;
/*     */                 break;
/*     */               case 4:
/*     */                 posZ -= this.speed;
/*     */                 break;
/*     */               case 5:
/*     */                 posX += this.speed / 2.0D;
/*     */                 posZ -= this.speed / 2.0D;
/*     */                 break;
/*     */               case 6:
/*     */                 posX += this.speed;
/*     */                 break;
/*     */               case 7:
/*     */                 posZ += this.speed / 2.0D;
/*     */                 posX += this.speed / 2.0D;
/*     */                 break;
/*     */             } 
/*     */             if (BlockUtil.getBlock(posX, posY, posZ) instanceof net.minecraft.block.BlockAir) {
/*     */               for (int i = 0; i < 5 && BlockUtil.getBlock(posX, posY - 1.0D, posZ) instanceof net.minecraft.block.BlockAir; i++)
/*     */                 posY--; 
/*     */             } else {
/*     */               for (int i = 0; i < 5 && !(BlockUtil.getBlock(posX, posY, posZ) instanceof net.minecraft.block.BlockAir); i++)
/*     */                 posY++; 
/*     */             } 
/*     */             player.setPositionAndUpdate(posX, posY, posZ);
/*     */             break;
/*     */           case "Circle":
/*     */             posXCir = Math.cos(this.rad / 100.0D) * this.range + FakePlayerDev.mc.player.posX;
/*     */             posZCir = Math.sin(this.rad / 100.0D) * this.range + FakePlayerDev.mc.player.posZ;
/*     */             posYCir = FakePlayerDev.mc.player.posY;
/*     */             if (BlockUtil.getBlock(posXCir, posYCir, posZCir) instanceof net.minecraft.block.BlockAir) {
/*     */               for (int i = 0; i < 5 && BlockUtil.getBlock(posXCir, posYCir - 1.0D, posZCir) instanceof net.minecraft.block.BlockAir; i++)
/*     */                 posYCir--; 
/*     */             } else {
/*     */               for (int i = 0; i < 5 && !(BlockUtil.getBlock(posXCir, posYCir, posZCir) instanceof net.minecraft.block.BlockAir); i++)
/*     */                 posYCir++; 
/*     */             } 
/*     */             player.setPositionAndUpdate(posXCir, posYCir, posZCir);
/*     */             this.rad = (int)(this.rad + this.speed * 10.0D);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class movingManager {
/*     */     private final ArrayList<FakePlayerDev.movingPlayer> players = new ArrayList<>();
/*     */     
/*     */     void addPlayer(int id, String type, double speed, int direction, double range, boolean follow) {
/*     */       this.players.add(new FakePlayerDev.movingPlayer(id, type, speed, direction, range, follow));
/*     */     }
/*     */     
/*     */     void update() {
/*     */       this.players.forEach(FakePlayerDev.movingPlayer::move);
/*     */     }
/*     */     
/*     */     void remove() {
/*     */       this.players.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*     */     if (mc.world != null)
/*     */       for (int i = 0; i < this.incr; i++)
/*     */         mc.world.removeEntityFromWorld(-1234 + i);  
/*     */     this.listPlayers.clear();
/*     */     this.manager.remove();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\FakePlayerDev.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
