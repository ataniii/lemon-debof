//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.dev;
/*     */ @Declaration(name = "AutoPot", category = Category.Dev, priority = 1001)
/*     */ public class AutoPot extends Module {
/*     */   ModeSetting page;
/*     */   BooleanSetting hp;
/*     */   IntegerSetting health;
/*     */   BooleanSetting equal;
/*     */   IntegerSetting healthSlot;
/*     */   IntegerSetting hpDelay;
/*     */   BooleanSetting speed;
/*     */   IntegerSetting time;
/*     */   IntegerSetting swiftnessSlot;
/*     */   IntegerSetting speedDelay;
/*     */   BooleanSetting only;
/*     */   BooleanSetting silentSwitch;
/*     */   BooleanSetting update;
/*     */   IntegerSetting delay;
/*     */   DoubleSetting factor;
/*     */   DoubleSetting range;
/*     */   IntegerSetting badSlot;
/*     */   BooleanSetting weak;
/*     */   BooleanSetting jump;
/*     */   BooleanSetting poison;
/*     */   BooleanSetting slow;
/*     */   HashMap<Integer, Long> weaknessTime;
/*     */   HashMap<Integer, Long> jumpBoostTime;
/*     */   HashMap<Integer, Long> poisonTime;
/*     */   HashMap<Integer, Long> slownessTime;
/*     */   Timing hpTimer;
/*     */   Timing speedTimer;
/*     */   Timing badPotTimer;
/*     */   int potionSlot;
/*     */   int potSlot;
/*     */   boolean working;
/*     */   @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostReceive> receiveListener;
/*     */   @EventHandler
/*     */   private final Listener<EntityRemovedEvent> entityRemovedEventListener;
/*     */   
/*  44 */   public AutoPot() { this.page = registerMode("Page", Arrays.asList(new String[] { "General", "BadPot" }, ), "General");
/*  45 */     this.hp = registerBoolean("Health Potion", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  46 */     this.health = registerInteger("Health", 16, 0, 20, () -> Boolean.valueOf((((Boolean)this.hp.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  47 */     this.equal = registerBoolean("Equal", false, () -> Boolean.valueOf((((Boolean)this.hp.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  48 */     this.healthSlot = registerInteger("Health Slot", 1, 1, 9, () -> Boolean.valueOf((((Boolean)this.hp.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  49 */     this.hpDelay = registerInteger("Health Delay", 50, 0, 1000, () -> Boolean.valueOf((((Boolean)this.hp.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  50 */     this.speed = registerBoolean("Swiftness", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  51 */     this.time = registerInteger("Time Left", 5, 0, 30, () -> Boolean.valueOf((((Boolean)this.speed.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  52 */     this.swiftnessSlot = registerInteger("Swiftness Slot", 1, 1, 9, () -> Boolean.valueOf((((Boolean)this.speed.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  53 */     this.speedDelay = registerInteger("Swiftness Delay", 50, 0, 1000, () -> Boolean.valueOf((((Boolean)this.speed.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  54 */     this.only = registerBoolean("On GroundOnly", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  55 */     this.silentSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  56 */     this.update = registerBoolean("Update Controller", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*     */     
/*  58 */     this.delay = registerInteger("Delay (Ticks)", 10, 0, 100, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  59 */     this.factor = registerDouble("Factor", 0.75D, 0.0D, 1.5D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  60 */     this.range = registerDouble("Range", 4.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  61 */     this.badSlot = registerInteger("BadPot Slot", 1, 1, 9, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  62 */     this.weak = registerBoolean("Weakness", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  63 */     this.jump = registerBoolean("JumpBoost", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  64 */     this.poison = registerBoolean("Poison", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  65 */     this.slow = registerBoolean("Slowness", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("BadPot")));
/*  66 */     this.weaknessTime = new HashMap<>();
/*  67 */     this.jumpBoostTime = new HashMap<>();
/*  68 */     this.poisonTime = new HashMap<>();
/*  69 */     this.slownessTime = new HashMap<>();
/*  70 */     this.hpTimer = new Timing();
/*  71 */     this.speedTimer = new Timing();
/*  72 */     this.badPotTimer = new Timing();
/*     */     
/*  74 */     this.working = false;
/*     */     
/*  76 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  this.working = false; if (((Boolean)this.only.getValue()).booleanValue() || mc.player.isInLava() || mc.player.isInWater()) { boolean inAir = true; for (Vec3d vec3d : new Vec3d[] { new Vec3d(0.3D, 0.0D, 0.3D), new Vec3d(0.3D, 0.0D, -0.3D), new Vec3d(-0.3D, 0.0D, 0.3D), new Vec3d(-0.3D, 0.0D, -0.3D) }) { BlockPos pos = (new BlockPos(mc.player.posX + vec3d.x, mc.player.posY + 0.5D, mc.player.posZ + vec3d.z)).down(3); if (!BlockUtil.isAir(pos)) { inAir = false; break; }  }  if (inAir) for (Vec3d vec3d : new Vec3d[] { new Vec3d(0.3D, 0.0D, 0.3D), new Vec3d(0.3D, 0.0D, -0.3D), new Vec3d(-0.3D, 0.0D, 0.3D), new Vec3d(-0.3D, 0.0D, -0.3D) }) { BlockPos pos = (new BlockPos(mc.player.posX + vec3d.x, mc.player.posY + 0.5D, mc.player.posZ + vec3d.z)).down(2); if (!BlockUtil.isAir(pos)) { inAir = false; break; }  }   if (inAir) for (Vec3d vec3d : new Vec3d[] { new Vec3d(0.3D, 0.0D, 0.3D), new Vec3d(0.3D, 0.0D, -0.3D), new Vec3d(-0.3D, 0.0D, 0.3D), new Vec3d(-0.3D, 0.0D, -0.3D) }) { BlockPos pos = (new BlockPos(mc.player.posX + vec3d.x, mc.player.posY + 0.5D, mc.player.posZ + vec3d.z)).down(); if (!BlockUtil.isAir(pos)) { inAir = false; break; }  }   if (inAir) return;  }  if (this.potionSlot == -1) this.potionSlot = getPotion();  if (this.potSlot == -1) this.potSlot = getBadPot();  if (this.potionSlot == -1 && this.potSlot == -1) return;  this.working = true; if (this.potionSlot > 8) { if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory)) return;  int finalSlot = (this.potionSlot == InventoryUtil.getPotion("swiftness")) ? ((Integer)this.swiftnessSlot.getValue()).intValue() : ((Integer)this.healthSlot.getValue()).intValue(); mc.playerController.windowClick(0, this.potionSlot, finalSlot - 1, ClickType.SWAP, (EntityPlayer)mc.player); mc.player.openContainer.detectAndSendChanges(); this.potionSlot = finalSlot - 1; }  if (this.potSlot > 8) { if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory)) return;  mc.playerController.windowClick(0, this.potSlot, ((Integer)this.badSlot.getValue()).intValue() - 1, ClickType.SWAP, (EntityPlayer)mc.player); mc.player.openContainer.detectAndSendChanges(); this.potSlot = ((Integer)this.badSlot.getValue()).intValue() - 1; }  if (event.getPhase() == Phase.PRE) { PlayerPacket packet = new PlayerPacket(this, new Vec2f((PlayerPacketManager.INSTANCE.getServerSideRotation()).x, 90.0F)); PlayerPacketManager.INSTANCE.addPacket(packet); }  if (event.getPhase() == Phase.POST && ((PlayerPacketManager.INSTANCE.getPrevServerSideRotation()).y > 80.0F || (PlayerPacketManager.INSTANCE.getServerSideRotation()).y > 80.0F)) { int oldslot = mc.player.inventory.currentItem; boolean switched = false; if (this.potionSlot != -1) { if (this.potionSlot != oldslot) { switchTo(this.potionSlot); switched = true; }  mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)); }  if (this.potSlot != -1) { if (this.potSlot != oldslot) { switchTo(this.potSlot); switched = true; }  mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)); }  if (switched) switchTo(oldslot);  this.potionSlot = this.potSlot = -1; }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     this.sendListener = new Listener(event -> { if (this.working) { if (event.getPacket() instanceof CPacketPlayer.Rotation) ((CPacketPlayer.Rotation)event.getPacket()).pitch = 90.0F;  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = 90.0F;  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof SPacketDestroyEntities) { Arrays.stream(((SPacketDestroyEntities)event.getPacket()).getEntityIDs()).forEach(this.weaknessTime::remove); Arrays.stream(((SPacketDestroyEntities)event.getPacket()).getEntityIDs()).forEach(this.jumpBoostTime::remove); Arrays.stream(((SPacketDestroyEntities)event.getPacket()).getEntityIDs()).forEach(this.poisonTime::remove); Arrays.stream(((SPacketDestroyEntities)event.getPacket()).getEntityIDs()).forEach(this.slownessTime::remove); }  if (event.getPacket() instanceof SPacketEntityStatus && ((SPacketEntityStatus)event.getPacket()).getOpCode() == 35) { this.weaknessTime.remove(Integer.valueOf((((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world)).entityId)); this.jumpBoostTime.remove(Integer.valueOf((((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world)).entityId)); this.poisonTime.remove(Integer.valueOf((((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world)).entityId)); this.slownessTime.remove(Integer.valueOf((((SPacketEntityStatus)event.getPacket()).getEntity((World)mc.world)).entityId)); }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     this.entityRemovedEventListener = new Listener(event -> { if (event.getEntity() instanceof EntityPotion) { List<PotionEffect> effectList = PotionUtils.getEffectsFromStack(((EntityPotion)event.getEntity()).getPotion()); PotionEffect weakness = null; PotionEffect jumpBoost = null; PotionEffect poison = null; PotionEffect slowness = null; for (PotionEffect effect : effectList) { if (effect.getPotion() == MobEffects.WEAKNESS) weakness = effect;  if (effect.getPotion() == MobEffects.JUMP_BOOST) jumpBoost = effect;  if (effect.getPotion() == MobEffects.POISON) poison = effect;  if (effect.getPotion() == MobEffects.SLOWNESS) slowness = effect;  }  AxisAlignedBB box = (event.getEntity()).boundingBox.grow(4.0D, 2.0D, 4.0D); PotionEffect finalWeakness = weakness; PotionEffect finalJumpBoost = jumpBoost; PotionEffect finalPoison = poison; PotionEffect finalSlowness = slowness; mc.world.playerEntities.stream().filter(()).filter(EntityUtil::isAlive).filter(()).forEach(()); }  }new java.util.function.Predicate[0]); }
/*     */   public void fast() { for (EntityPlayer player : mc.world.playerEntities) {
/*     */       int id = player.getEntityId(); long time = System.currentTimeMillis(); if (this.weaknessTime.containsKey(Integer.valueOf(id)) && ((Long)this.weaknessTime.get(Integer.valueOf(id))).longValue() <= time)
/*     */         this.weaknessTime.remove(Integer.valueOf(id));  if (this.jumpBoostTime.containsKey(Integer.valueOf(id)) && ((Long)this.jumpBoostTime.get(Integer.valueOf(id))).longValue() <= time)
/*     */         this.jumpBoostTime.remove(Integer.valueOf(id));  if (this.poisonTime.containsKey(Integer.valueOf(id)) && ((Long)this.poisonTime.get(Integer.valueOf(id))).longValue() <= time)
/*     */         this.poisonTime.remove(Integer.valueOf(id));  if (this.slownessTime.containsKey(Integer.valueOf(id)) && ((Long)this.slownessTime.get(Integer.valueOf(id))).longValue() <= time)
/*     */         this.slownessTime.remove(Integer.valueOf(id)); 
/*     */     }  }
/*     */   private int getPotion() { if (((Boolean)this.hp.getValue()).booleanValue() && healthCheck() && this.hpTimer.passedMs(((Integer)this.hpDelay.getValue()).intValue())) {
/*     */       this.hpTimer.reset();
/*     */       int slot = InventoryUtil.getPotion("healing");
/*     */       if (slot != -1)
/*     */         return slot; 
/*     */     } 
/*     */     if (((Boolean)this.speed.getValue()).booleanValue() && (!mc.player.isPotionActive(MobEffects.SPEED) || ((PotionEffect)Objects.requireNonNull((T)mc.player.getActivePotionEffect(MobEffects.SPEED))).getDuration() <= ((Integer)this.time.getValue()).intValue() * 20) && this.speedTimer.passedMs(((Integer)this.speedDelay.getValue()).intValue())) {
/*     */       this.speedTimer.reset();
/*     */       return InventoryUtil.getPotion("swiftness");
/*     */     } 
/*     */     return -1; }
/*     */   private int getBadPot() { if (this.badPotTimer.passedTick(((Integer)this.delay.getValue()).intValue())) {
/*     */       this.badPotTimer.reset();
/*     */       for (EntityPlayer player : mc.world.playerEntities) {
/*     */         if (mc.player.connection.getPlayerInfo(player.getName()) == null || EntityUtil.basicChecksEntity(player) || mc.player.getDistance((Entity)player) > ((Double)this.range.getValue()).doubleValue())
/*     */           continue; 
/*     */         if (((Boolean)this.weak.getValue()).booleanValue() && !this.weaknessTime.containsKey(Integer.valueOf(player.getEntityId()))) {
/*     */           int slot = InventoryUtil.getPotion("weakness");
/*     */           if (slot != -1)
/*     */             return slot; 
/*     */         } 
/*     */         if (((Boolean)this.jump.getValue()).booleanValue() && !this.jumpBoostTime.containsKey(Integer.valueOf(player.getEntityId()))) {
/*     */           int slot = InventoryUtil.getPotion("leaping");
/*     */           if (slot != -1)
/*     */             return slot; 
/*     */         } 
/*     */         if (((Boolean)this.poison.getValue()).booleanValue() && !this.poisonTime.containsKey(Integer.valueOf(player.getEntityId()))) {
/*     */           int slot = InventoryUtil.getPotion("poison");
/*     */           if (slot != -1)
/*     */             return slot; 
/*     */         } 
/*     */         if (((Boolean)this.slow.getValue()).booleanValue() && !this.slownessTime.containsKey(Integer.valueOf(player.getEntityId())))
/*     */           return InventoryUtil.getPotion("slowness"); 
/*     */       } 
/*     */     } 
/* 282 */     return -1; } private boolean healthCheck() { if (((Boolean)this.equal.getValue()).booleanValue()) return (mc.player.getHealth() <= ((Integer)this.health.getValue()).intValue()); 
/* 283 */     return (mc.player.getHealth() < ((Integer)this.health.getValue()).intValue()); }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 287 */     if (((Boolean)this.silentSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 288 */     else { mc.player.inventory.currentItem = slot; }
/* 289 */      if (((Boolean)this.update.getValue()).booleanValue()) mc.playerController.updateController(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\AutoPot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
