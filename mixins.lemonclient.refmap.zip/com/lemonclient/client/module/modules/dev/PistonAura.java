//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*      */ package com.lemonclient.client.module.modules.dev;
/*      */ 
/*      */ import com.lemonclient.api.util.world.BlockUtil;
/*      */ import java.util.List;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ 
/*      */ @Declaration(name = "PistonAura", category = Category.Dev)
/*      */ public class PistonAura extends Module {
/*      */   public static PistonAura INSTANCE;
/*      */   public boolean autoCrystal;
/*      */   ModeSetting page;
/*      */   IntegerSetting maxTarget;
/*      */   DoubleSetting range;
/*      */   IntegerSetting maxY;
/*      */   IntegerSetting delay;
/*      */   IntegerSetting baseDelay;
/*      */   IntegerSetting startBreakDelay;
/*      */   IntegerSetting breakDelay;
/*      */   BooleanSetting alwaysCalc;
/*      */   BooleanSetting pistonCheck;
/*      */   BooleanSetting entityCheck;
/*      */   BooleanSetting base;
/*      */   BooleanSetting fiveB;
/*      */   BooleanSetting push;
/*      */   BooleanSetting crystal;
/*      */   BooleanSetting fire;
/*      */   BooleanSetting fireCheck;
/*      */   BooleanSetting different;
/*      */   IntegerSetting maxPos;
/*      */   ModeSetting redstone;
/*      */   BooleanSetting packetPlace;
/*      */   BooleanSetting packet;
/*      */   BooleanSetting packetBreak;
/*      */   BooleanSetting antiWeakness;
/*      */   BooleanSetting swingArm;
/*      */   BooleanSetting silentSwitch;
/*      */   BooleanSetting packetSwitch;
/*      */   BooleanSetting crystalBypass;
/*      */   BooleanSetting force;
/*      */   BooleanSetting strict;
/*      */   BooleanSetting forceRotate;
/*      */   BooleanSetting rotate;
/*      */   BooleanSetting pistonRotate;
/*      */   BooleanSetting raytrace;
/*      */   BooleanSetting baseRaytrace;
/*      */   DoubleSetting forceRange;
/*      */   BooleanSetting pauseEat;
/*      */   BooleanSetting pause1;
/*      */   DoubleSetting maxSelfSpeed;
/*      */   DoubleSetting maxTargetSpeed;
/*      */   BooleanSetting bypass;
/*      */   BooleanSetting dance;
/*      */   BooleanSetting render;
/*      */   BooleanSetting fireRender;
/*      */   BooleanSetting box;
/*      */   BooleanSetting outline;
/*      */   BooleanSetting iq;
/*      */   DoubleSetting speed;
/*      */   BooleanSetting hud;
/*      */   Vec3d movingPistonNow;
/*      */   BlockPos lastBestPiston;
/*      */   Vec3d movingCrystalNow;
/*      */   BlockPos lastBestCrystal;
/*      */   Vec3d movingRedstoneNow;
/*      */   BlockPos lastBestRedstone;
/*      */   
/*   70 */   public PistonAura() { this.page = registerMode("Page", Arrays.asList(new String[] { "Calc", "General", "Render" }, ), "Calc");
/*      */     
/*   72 */     this.maxTarget = registerInteger("Max Target", 1, 1, 10, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   73 */     this.range = registerDouble("Range", 6.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   74 */     this.maxY = registerInteger("MaxY", 3, 1, 5, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   75 */     this.delay = registerInteger("Delay", 20, 0, 100, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   76 */     this.baseDelay = registerInteger("Base Delay", 0, 0, 100, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   77 */     this.startBreakDelay = registerInteger("Start Break Delay", 0, 0, 100, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   78 */     this.breakDelay = registerInteger("Break Delay", 0, 0, 100, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   79 */     this.alwaysCalc = registerBoolean("Loop Calc", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   80 */     this.pistonCheck = registerBoolean("Piston Check", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   81 */     this.entityCheck = registerBoolean("Crystal Check", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   82 */     this.base = registerBoolean("Base", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   83 */     this.fiveB = registerBoolean("5b Mode", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   84 */     this.push = registerBoolean("Push To Block", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   85 */     this.crystal = registerBoolean("Crystal Detect", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   86 */     this.fire = registerBoolean("Fire", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   87 */     this.fireCheck = registerBoolean("Fire Check", true, () -> Boolean.valueOf((((Boolean)this.fire.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Calc"))));
/*   88 */     this.different = registerBoolean("Different Pos", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*   89 */     this.maxPos = registerInteger("Max Pos", 10, 1, 25, () -> Boolean.valueOf((((Boolean)this.different.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Calc"))));
/*      */     
/*   91 */     this.redstone = registerMode("Redstone", Arrays.asList(new String[] { "Block", "Torch", "Both" }, ), "Block", () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   92 */     this.packetPlace = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   93 */     this.packet = registerBoolean("Packet Crystal", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   94 */     this.packetBreak = registerBoolean("Packet Break", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   95 */     this.antiWeakness = registerBoolean("Anti Weakness", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   96 */     this.swingArm = registerBoolean("Swing Arm", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   97 */     this.silentSwitch = registerBoolean("Switch Back", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   98 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   99 */     this.crystalBypass = registerBoolean("Crystal Bypass", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  100 */     this.force = registerBoolean("Force Bypass", false, () -> Boolean.valueOf((((Boolean)this.crystalBypass.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  101 */     this.strict = registerBoolean("Strict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  102 */     this.forceRotate = registerBoolean("Piston ForceRotate", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  103 */     this.rotate = registerBoolean("Rotate", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  104 */     this.pistonRotate = registerBoolean("Piston Rotate", true, () -> Boolean.valueOf((((Boolean)this.rotate.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  105 */     this.raytrace = registerBoolean("RayTrace", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  106 */     this.baseRaytrace = registerBoolean("Base RayTrace", true, () -> Boolean.valueOf((((Boolean)this.base.getValue()).booleanValue() && ((Boolean)this.raytrace.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  107 */     this.forceRange = registerDouble("Force Range", 3.0D, 0.0D, 6.0D, () -> Boolean.valueOf((((Boolean)this.raytrace.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  108 */     this.pauseEat = registerBoolean("Pause When Eating", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  109 */     this.pause1 = registerBoolean("Pause When Burrow", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  110 */     this.maxSelfSpeed = registerDouble("Max Self Speed", 10.0D, 0.0D, 50.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  111 */     this.maxTargetSpeed = registerDouble("Max Target Speed", 10.0D, 0.0D, 50.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  112 */     this.bypass = registerBoolean("Bypass", false, () -> Boolean.valueOf((((Boolean)this.silentSwitch.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  113 */     this.dance = registerBoolean("Hotbar Dance (?", false, () -> Boolean.valueOf((((Boolean)this.silentSwitch.getValue()).booleanValue() && ((Boolean)this.bypass.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*      */     
/*  115 */     this.render = registerBoolean("Render", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  116 */     this.fireRender = registerBoolean("Fire Render", false, () -> Boolean.valueOf((((Boolean)this.render.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Render"))));
/*  117 */     this.box = registerBoolean("Box", false, () -> Boolean.valueOf((((Boolean)this.render.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Render"))));
/*  118 */     this.outline = registerBoolean("Outline", false, () -> Boolean.valueOf((((Boolean)this.render.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Render"))));
/*  119 */     this.iq = registerBoolean("IQ", false, () -> Boolean.valueOf((((Boolean)this.render.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Render"))));
/*  120 */     this.speed = registerDouble("Speed", 0.5D, 0.01D, 1.0D, () -> Boolean.valueOf((((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.iq.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Render"))));
/*  121 */     this.hud = registerBoolean("HUD", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*      */     
/*  123 */     this.movingPistonNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  124 */     this.lastBestPiston = null;
/*  125 */     this.movingCrystalNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  126 */     this.lastBestCrystal = null;
/*  127 */     this.movingRedstoneNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  128 */     this.lastBestRedstone = null;
/*      */ 
/*      */ 
/*      */     
/*  132 */     this.obbySlot = -1;
/*  133 */     this.timer = new Timing(); this.baseTimer = new Timing(); this.startBreakTimer = new Timing(); this.breakTimer = new Timing();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  142 */     this.saveArray = new BlockPos[25];
/*  143 */     this.sides = new Vec3d[] { new Vec3d(0.24D, 0.0D, 0.24D), new Vec3d(-0.24D, 0.0D, 0.24D), new Vec3d(0.24D, 0.0D, -0.24D), new Vec3d(-0.24D, 0.0D, -0.24D) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  150 */     this.offsets = new BlockPos[] { new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  158 */     this.fireList = new BlockPos[] { new BlockPos(0, 0, 0), new BlockPos(1, 1, 1), new BlockPos(1, 1, 0), new BlockPos(1, 1, -1), new BlockPos(0, 1, 1), new BlockPos(0, 1, -1), new BlockPos(-1, 1, 1), new BlockPos(-1, 1, 0), new BlockPos(-1, 1, -1), new BlockPos(1, 0, 1), new BlockPos(1, 0, 0), new BlockPos(1, 0, -1), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(-1, 0, 1), new BlockPos(-1, 0, 0), new BlockPos(-1, 0, -1), new BlockPos(0, 1, 0) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  179 */     this.sendListener = new Listener(event -> { if (this.rotation != null) { if (event.getPacket() instanceof CPacketPlayer.Rotation) { ((CPacketPlayer.Rotation)event.getPacket()).yaw = this.rotation.x; ((CPacketPlayer.Rotation)event.getPacket()).pitch = 0.0F; }  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) { ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = this.rotation.x; ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = 0.0F; }  if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketVehicleMove) ((AccessorCPacketVehicleMove)event.getPacket()).setYaw(this.rotation.x);  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (this.rotation == null || event.getPhase() != Phase.PRE) return;  PlayerPacket packet = new PlayerPacket(this, new Vec2f(this.rotation.x, 0.0F)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  204 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || this.crystalPos == null) return;  if (event.getPacket() instanceof SPacketSoundEffect) { SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket(); if (packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE && this.crystalPos.distanceSq(packet.getX(), packet.getY(), packet.getZ()) <= 9.0D) this.boom = true;  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  987 */     this.listener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof SPacketSoundEffect) { SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket(); if (packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) for (Entity crystal : new ArrayList(mc.world.loadedEntityList)) { if (crystal instanceof net.minecraft.entity.item.EntityEnderCrystal && crystal.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= ((Double)this.range.getValue()).doubleValue() + 5.0D) crystal.setDead();  }   }  }new java.util.function.Predicate[0]);
/*      */     INSTANCE = this; }
/*      */ 
/*      */   
/*      */   public static EntityPlayer target = null; public BlockPos targetPos; public BlockPos pistonPos; public BlockPos crystalPos; public BlockPos redStonePos; public BlockPos firePos; public BlockPos lastTargetPos; public int pistonSlot; public int crystalSlot; public int redStoneSlot; public int obbySlot; public Timing timer; public Timing baseTimer; public Timing startBreakTimer; public Timing breakTimer; public boolean preparedSpace; public boolean placedPiston; public boolean placedCrystal; public boolean placedRedstone; public boolean brokeCrystal; int oldSlot; boolean useBlock; boolean boom; boolean burrowed; boolean moving;
/*      */   boolean first;
/*      */   Vec2f rotation;
/*      */   BlockPos[] saveArray;
/*      */   Vec3d[] sides;
/*      */   BlockPos[] offsets;
/*      */   BlockPos[] fireList;
/*      */   @EventHandler
/*      */   private final Listener<PacketEvent.Send> sendListener;
/*      */   @EventHandler
/*      */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*      */   @EventHandler
/*      */   private final Listener<PacketEvent.Receive> receiveListener;
/*      */   
/* 1005 */   private int fireLevel(BlockPos pos, BlockPos targetPos) { return (pos.getX() == targetPos.getX() || pos.getZ() == targetPos.getZ()) ? 1 : 0; }
/*      */   @EventHandler private final Listener<PacketEvent.Receive> listener;
/*      */   public void onEnable() { this.lastBestPiston = this.lastBestCrystal = this.lastBestRedstone = null; this.movingPistonNow = this.movingCrystalNow = this.movingRedstoneNow = new Vec3d(-1.0D, -1.0D, -1.0D); this.saveArray = new BlockPos[25]; this.first = true; reset(); } public void onTick() { if (this.autoCrystal) return;  doPA(); } public void doPA() { this.moving = false; this.burrowed = false; BlockPos originalPos = PlayerUtil.getPlayerPos(); Block block = BlockUtil.getBlock(originalPos); if (block == Blocks.BEDROCK || block == Blocks.OBSIDIAN || block == Blocks.ENDER_CHEST) this.burrowed = true;  if (((Boolean)this.pause1.getValue()).booleanValue() && this.burrowed) return;  if (((Boolean)this.pauseEat.getValue()).booleanValue() && EntityUtil.isEating()) return;  if (LemonClient.speedUtil.getPlayerSpeed((EntityPlayer)mc.player) > ((Double)this.maxSelfSpeed.getValue()).doubleValue()) return;  _doPA(); } public void _doPA() { if (!((Boolean)this.forceRotate.getValue()).booleanValue()) this.rotation = null;  if (mc.world == null || mc.player == null || mc.player.isDead) return;  try { if (!findMaterials()) return;  if (((Boolean)this.alwaysCalc.getValue()).booleanValue() || this.boom || target == null || !EntityUtil.isAlive((Entity)target)) { PistonAuraPos pos = findSpace(); if (pos == null) { this.first = true; target = null; this.targetPos = this.pistonPos = this.redStonePos = this.crystalPos = null; this.rotation = null; return; }  target = pos.target; this.targetPos = pos.targetPos; this.pistonPos = pos.piston; this.redStonePos = pos.redstone; this.crystalPos = pos.crystal; }  if (this.targetPos == null || this.pistonPos == null || this.redStonePos == null || this.crystalPos == null) { if (this.breakTimer.passedDms(((Integer)this.breakDelay.getValue()).intValue()) && this.lastTargetPos != null) { if (((Boolean)this.packetBreak.getValue()).booleanValue()) { CrystalUtil.breakCrystalPacket(this.lastTargetPos, ((Boolean)this.swingArm.getValue()).booleanValue()); } else { CrystalUtil.breakCrystal(this.lastTargetPos, ((Boolean)this.swingArm.getValue()).booleanValue()); }  this.breakTimer.reset(); }  reset(); return; }  if (PlayerUtil.getDistanceI(this.pistonPos) > ((Double)this.range.getValue()).doubleValue() || PlayerUtil.getDistanceI(this.redStonePos) > ((Double)this.range.getValue()).doubleValue() || PlayerUtil.getDistanceI(this.crystalPos) > ((Double)this.range.getValue()).doubleValue()) { this.lastTargetPos = null; reset(); return; }  AutoEz.INSTANCE.addTargetedPlayer(target.getName()); this.lastTargetPos = new BlockPos(this.targetPos.getX(), this.crystalPos.getY() + 2, this.targetPos.getZ()); this.oldSlot = mc.player.inventory.currentItem; BlockPos offset = new BlockPos(this.crystalPos.getX() - this.targetPos.getX(), 0, this.crystalPos.getZ() - this.targetPos.getZ()); BlockPos headPos = this.pistonPos.add(offset.getX() * -1, 0, offset.getZ() * -1); Block block = BlockUtil.getBlock(headPos); if (block == Blocks.BEDROCK || block == Blocks.OBSIDIAN || block == Blocks.ENDER_CHEST || checkPos(headPos)) { reset(); return; }  Block piston = BlockUtil.getBlock(this.pistonPos); this.placedPiston = piston instanceof net.minecraft.block.BlockPistonBase; this.placedRedstone = hasRedstone(this.pistonPos); this.placedCrystal = (getCrystal(this.crystalPos.up()) != null && getCrystal(new BlockPos(this.targetPos.getX(), this.crystalPos.getY() + 2, this.targetPos.getZ())) != null); if (!this.placedCrystal && (!BlockUtil.isAirBlock(this.crystalPos.up()) || !BlockUtil.isAirBlock(this.crystalPos.up(2)))) { reset(); return; }  if (!this.placedPiston && (intersectsWithEntity(this.pistonPos) || !BlockUtil.canReplace(this.pistonPos))) { reset(); return; }  if (!this.placedRedstone && (intersectsWithEntity(this.redStonePos) || !BlockUtil.canReplace(this.redStonePos))) { reset(); return; }  float[] angle = MathUtil.calcAngle(new Vec3d((Vec3i)this.crystalPos), new Vec3d((Vec3i)this.targetPos)); this.rotation = new Vec2f(angle[0] + 180.0F, angle[1]); if (!this.preparedSpace) { this.preparedSpace = (canPlace(this.pistonPos) || canPlace(this.redStonePos)); if (!this.preparedSpace) if (!((Boolean)this.base.getValue()).booleanValue()) { this.preparedSpace = true; } else if (this.baseTimer.passedDms(((Integer)this.baseDelay.getValue()).intValue())) { this.baseTimer.reset(); this.preparedSpace = prepareSpace(); }   this.timer.reset(); }  if (this.preparedSpace && this.first) { if (!((Boolean)this.forceRotate.getValue()).booleanValue()) this.timer.setMs(1000000000L);  this.first = false; }  if (this.timer.passedDms(((Integer)this.delay.getValue()).intValue())) { this.timer.reset(); if (!this.placedPiston && !canPlace(this.pistonPos) && canPlace(this.redStonePos)) placeRedstone((this.preparedSpace && !this.placedRedstone));  placePiston((this.preparedSpace && !this.placedPiston)); placeCrystal((this.placedPiston && !this.placedCrystal)); placeRedstone((this.placedCrystal && !this.placedRedstone)); }  boolean finish = (this.placedPiston && this.placedCrystal && this.placedRedstone); if (this.breakTimer.passedDms(((Integer)this.breakDelay.getValue()).intValue())) breakCrystal(finish);  restoreItem(); } catch (Exception exception) {} } private void placePiston(boolean work) { if (!work) return;  setItem(this.pistonSlot, false); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(this.rotation.x, this.rotation.y, true)); this.placedPiston = placeBlock(this.pistonPos, ((Boolean)this.packetPlace.getValue()).booleanValue()); if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(this.pistonSlot, true);  this.startBreakTimer.reset(); this.breakTimer.reset(); } private void placeCrystal(boolean work) { if (!work) return;  EnumHand hand = (this.crystalSlot != 999) ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND; if (((Boolean)this.crystalBypass.getValue()).booleanValue() && (this.crystalSlot >= 9 || ((Boolean)this.force.getValue()).booleanValue()) && hand == EnumHand.MAIN_HAND) { int slot = this.crystalSlot; if (slot < 9) slot += 36;  mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, ItemStack.EMPTY, mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); this.placedCrystal = CrystalUtil.placeCrystal(this.crystalPos, hand, ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.swingArm.getValue()).booleanValue()); mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, Items.END_CRYSTAL.getDefaultInstance(), mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); } else { setItem(this.crystalSlot, false); this.placedCrystal = CrystalUtil.placeCrystal(this.crystalPos, hand, ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.swingArm.getValue()).booleanValue()); if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(this.crystalSlot, true);  }  this.startBreakTimer.reset(); this.breakTimer.reset(); if (this.placedCrystal && ((Boolean)this.fire.getValue()).booleanValue()) { int slot = BurrowUtil.findHotbarBlock(Items.FLINT_AND_STEEL.getClass()); if (slot != -1) { List<BlockPos> canPos = new ArrayList<>(); boolean placedFire = false; for (BlockPos firePos : this.fireList) { BlockPos pos = (new BlockPos(this.targetPos.getX(), this.crystalPos.getY() + 1, this.targetPos.getZ())).add((Vec3i)firePos); boolean cancel = false; for (EnumFacing facing : EnumFacing.values()) { if (isPos2(this.pistonPos.offset(facing, 1), pos)) { cancel = true; break; }  }  if (!cancel && !isPos2(this.pistonPos, pos) && !isPos2(this.redStonePos, pos)) { int x = this.crystalPos.getX() - this.targetPos.getX(); int z = this.crystalPos.getZ() - this.targetPos.getZ(); BlockPos pos1 = this.targetPos.add(-x, 0, -z); BlockPos pos2 = pos1.add(z, 0, x); BlockPos pos3 = pos1.add(-z, 0, -x); BlockPos pos4 = this.targetPos.add(-x, 1, -z); BlockPos pos5 = pos1.add(z, 1, x); BlockPos pos6 = pos1.add(-z, 1, -x); boolean air = (BlockUtil.canReplace(pos1) && BlockUtil.canReplace(pos2) && BlockUtil.canReplace(pos3) && BlockUtil.canReplace(pos4) && BlockUtil.canReplace(pos5) && BlockUtil.canReplace(pos6)); if (((this.targetPos.add(-x, 0, 0).getX() != pos.getX() && this.targetPos.add(0, 0, -z).getZ() != pos.getZ()) || (this.crystalPos.getY() + 1 >= pos.getY() && air)) && this.crystalPos.add(x, 0, 0).getX() != pos.getX() && this.crystalPos.add(0, 0, z).getZ() != pos.getZ()) { if (BlockUtil.getBlock(pos) == Blocks.FIRE) { placedFire = true; break; }  if (canPlaceFire(pos) && !BlockUtil.isBlockUnSolid(pos.down()) && !BlockUtil.canOpen(pos.down()) && mc.world.isAirBlock(pos)) canPos.add(pos);  }  }  }  if (!placedFire) { this.firePos = canPos.stream().sorted(this::fireLevel).min(Comparator.comparing(PlayerUtil::getDistanceI)).orElse(null); setItem(slot, false); placeBlock(this.firePos, ((Boolean)this.packetPlace.getValue()).booleanValue()); if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(slot, true);  }  }  }  } private void placeRedstone(boolean work) { if (!work) return;  setItem(this.redStoneSlot, false); this.placedRedstone = BlockUtil.placeBlockBoolean(this.redStonePos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(this.redStonePos), ((Boolean)this.swingArm.getValue()).booleanValue()); if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(this.redStoneSlot, true);  this.startBreakTimer.reset(); this.breakTimer.reset(); } private void breakCrystal(boolean work) { if (!work) return;  if (!this.startBreakTimer.passedDms(((Integer)this.startBreakDelay.getValue()).intValue())) return;  Entity crystal = mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(this.crystalPos.up(2))).stream().filter(e -> e instanceof net.minecraft.entity.item.EntityEnderCrystal).min(Comparator.comparing(e -> Double.valueOf(getDistance(target, e)))).orElse(null); if (crystal != null) { this.breakTimer.reset(); int oldSlot = mc.player.inventory.currentItem; if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) { int newSlot = -1; for (int i = 0; i < 9; i++) { ItemStack stack = mc.player.inventory.getStackInSlot(i); if (stack != ItemStack.EMPTY) { if (stack.getItem() instanceof net.minecraft.item.ItemSword) { newSlot = i; break; }  if (stack.getItem() instanceof net.minecraft.item.ItemTool) newSlot = i;  }  }  if (newSlot != -1) setItem(newSlot, false);  }  if (((Boolean)this.packetBreak.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal)); } else { mc.playerController.attackEntity((EntityPlayer)mc.player, crystal); }  if (((Boolean)this.swingArm.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  if (((Boolean)this.silentSwitch.getValue()).booleanValue()) setItem(oldSlot, false);  }  } public boolean prepareSpace() { BlockPos piston = this.pistonPos.add(0, -1, 0); if (isPos2(piston, this.redStonePos)) piston = piston.down();  BlockPos redstone = this.redStonePos.add(0, -1, 0); if (!canPlace(this.pistonPos)) { if (intersectsWithEntity(this.pistonPos)) { reset(); } else { BlockPos offset = new BlockPos(this.crystalPos.getX() - this.targetPos.getX(), 0, this.crystalPos.getZ() - this.targetPos.getZ()); BlockPos crystalOffset = this.crystalPos.add((Vec3i)offset); BlockPos crystalOffset1 = crystalOffset.add((Vec3i)offset); setItem(this.obbySlot, false); if (canPlace(piston) && BlockUtil.canReplace(piston) && !isPos2(piston, this.redStonePos)) { if (intersectsWithEntity(piston)) { reset(); } else { BlockUtil.placeBlock(piston, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), (((Boolean)this.raytrace.getValue()).booleanValue() && ((Boolean)this.baseRaytrace.getValue()).booleanValue()), ((Boolean)this.swingArm.getValue()).booleanValue()); }  } else if (canPlace(crystalOffset1) && BlockUtil.canReplace(crystalOffset1) && !isPos2(crystalOffset1, this.redStonePos)) { if (intersectsWithEntity(crystalOffset1)) { reset(); } else { BlockUtil.placeBlock(crystalOffset1, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), (((Boolean)this.raytrace.getValue()).booleanValue() && ((Boolean)this.baseRaytrace.getValue()).booleanValue()), ((Boolean)this.swingArm.getValue()).booleanValue()); }  } else if (canPlace(crystalOffset) && BlockUtil.canReplace(crystalOffset) && !isPos2(crystalOffset, this.redStonePos)) { if (intersectsWithEntity(crystalOffset)) { reset(); } else { BlockUtil.placeBlock(crystalOffset, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), (((Boolean)this.raytrace.getValue()).booleanValue() && ((Boolean)this.baseRaytrace.getValue()).booleanValue()), ((Boolean)this.swingArm.getValue()).booleanValue()); }  } else { reset(); }  if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(this.obbySlot, true);  }  return false; }  if ((!canPlace(this.redStonePos) || (!this.useBlock && this.redStonePos.getY() == this.pistonPos.getY())) && canPlace(redstone) && !isPos2(redstone, this.pistonPos)) { if (intersectsWithEntity(redstone)) { reset(); } else { setItem(this.obbySlot, false); BlockUtil.placeBlock(redstone, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), (((Boolean)this.raytrace.getValue()).booleanValue() && ((Boolean)this.baseRaytrace.getValue()).booleanValue()), ((Boolean)this.swingArm.getValue()).booleanValue()); if (!((Boolean)this.dance.getValue()).booleanValue()) setItem(this.obbySlot, true);  }  return false; }  return true; } public PistonAuraPos findSpace() { List<PistonAuraPos> list = new ArrayList<>(); for (Iterator<EntityPlayer> iterator = PlayerUtil.getNearPlayers(((Double)this.range.getValue()).doubleValue() + 4.0D, ((Integer)this.maxTarget.getValue()).intValue()).iterator(); iterator.hasNext(); ) { EntityPlayer target = iterator.next(); if (LemonClient.speedUtil.getPlayerSpeed(target) > ((Double)this.maxTargetSpeed.getValue()).doubleValue()) continue;  List<PistonAuraPos> sideList = new ArrayList<>(); for (Vec3d vec3d : this.sides) { BlockPos targetPos = new BlockPos(target.posX + vec3d.x, target.posY + 0.5D, target.posZ + vec3d.z); BlockPos cPos = null; for (Entity entity : mc.world.loadedEntityList) { if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) { cPos = new BlockPos(entity.posX, entity.posY - 1.0D, entity.posZ); int x = Math.abs(cPos.getX() - targetPos.getX()); int i = cPos.y - targetPos.y; int z = Math.abs(cPos.getZ() - targetPos.getZ()); if (x > 1 || i > 5 || i < 0 || z > 1) { cPos = null; continue; }  break; }  }  BlockPos[] offsets = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) }; boolean calc = false; List<PistonAuraPos> can = new ArrayList<>(); for (int y = 0; y <= ((Integer)this.maxY.getValue()).intValue(); y++) { boolean cantPlace = false, block = false; for (int high = y + 1; high >= 0; high--) { BlockPos pos = targetPos.up(high); if (DamageUtil.isResistant(BlockUtil.getState(pos))) if (high < y + 1) { cantPlace = true; } else if (!((Boolean)this.push.getValue()).booleanValue()) { cantPlace = true; } else { block = true; }   }  if (!cantPlace) for (BlockPos side : offsets) { if (!((Boolean)this.crystal.getValue()).booleanValue()) cPos = null;  BlockPos offset = (cPos == null) ? side : new BlockPos(cPos.getX() - targetPos.getX(), 0, cPos.getZ() - targetPos.getZ()); if (cPos != null && isPos2(new BlockPos(-offset.getX(), 0, -offset.getZ()), side)) cPos = null;  if (cPos == null) { offset = side; } else if (calc) { continue; }  BlockPos crystalPos = (cPos == null) ? targetPos.add(offset.getX(), y, offset.getZ()) : cPos; if (cPos == null) { if (BlockUtil.getBlock(crystalPos) != Blocks.OBSIDIAN && BlockUtil.getBlock(crystalPos) != Blocks.BEDROCK) continue;  if (!mc.world.isAirBlock(crystalPos.up()) || !mc.world.isAirBlock(crystalPos.up(2))) continue;  if (PlayerUtil.getDistanceI(crystalPos) > ((Double)this.range.getValue()).doubleValue() || !mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(crystalPos.up())).isEmpty() || !mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(crystalPos.up(2))).isEmpty()) continue;  }  BlockPos normal = crystalPos.add((Vec3i)offset); BlockPos oneBlock = normal.add((Vec3i)offset); BlockPos side0 = normal.add(offset.getZ(), 0, offset.getX()); BlockPos side1 = normal.add(offset.getZ() * -1, 0, offset.getX() * -1); BlockPos side2 = oneBlock.add(offset.getZ(), 0, offset.getX()); BlockPos side3 = oneBlock.add(offset.getZ() * -1, 0, offset.getX() * -1); BlockPos side4 = crystalPos.add(offset.getZ(), 0, offset.getX()); BlockPos side5 = crystalPos.add(offset.getZ() * -1, 0, offset.getX() * -1); List<BlockPos> pistons = new ArrayList<>(); if (!((Boolean)this.fiveB.getValue()).booleanValue()) add(pistons, normal);  if (!((Boolean)this.fiveB.getValue()).booleanValue()) add(pistons, oneBlock);  add(pistons, side0); add(pistons, side1); add(pistons, side2); add(pistons, side3); add(pistons, side4); add(pistons, side5); pistons.removeIf(p -> { if (!((Boolean)this.different.getValue()).booleanValue()) return false;  boolean same = false; for (BlockPos savePos : this.saveArray) { if (isPos2(savePos, p)) { same = true; break; }  }  return same; }); BlockPos finalOffset = offset; if (!pistons.isEmpty()) { List<BlockPos> pistonList = (List<BlockPos>)pistons.stream().filter(p -> { BlockPos headPos = p.add(finalOffset.getX() * -1, 0, finalOffset.getZ() * -1); Block headBlock = BlockUtil.getBlock(headPos); if (headBlock == Blocks.BEDROCK || headBlock == Blocks.OBSIDIAN || headBlock == Blocks.ENDER_CHEST || headBlock == Blocks.PISTON_HEAD || checkPos(headPos)) return false;  boolean isPiston = BlockUtil.getBlock(p) instanceof net.minecraft.block.BlockPistonBase; if (!isPiston) { if (!canPlace(p)) return false;  if (mc.player.getDistance(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D) > ((Double)this.range.getValue()).doubleValue()) return false;  double feetY = mc.player.posY; if ((PlayerUtil.getDistanceI(p) < 0.8D + p.getY() - feetY && p.getY() > feetY + 1.0D) || (PlayerUtil.getDistanceI(p) < 1.8D + feetY - p.getY() && p.getY() < feetY)) return false;  } else if (((Boolean)this.pistonCheck.getValue()).booleanValue() && (hasRedstone(p) || !isFacing(p, headPos))) { return false; }  BlockPos redstonePos = getRedStonePos(crystalPos, p, finalOffset); if (redstonePos == null) return false;  if (((Boolean)this.fire.getValue()).booleanValue() && ((Boolean)this.fireCheck.getValue()).booleanValue()) { int slot = BurrowUtil.findHotbarBlock(Items.FLINT_AND_STEEL.getClass()); if (slot != -1) { BlockPos origin = new BlockPos(targetPos.getX(), crystalPos.getY() + 1, targetPos.getZ()); for (BlockPos firePos : this.fireList) { BlockPos pos = origin.add((Vec3i)firePos); boolean cancel = false; for (EnumFacing facing : EnumFacing.values()) { if (isPos2(p.offset(facing, 1), pos)) { cancel = true; break; }  }  if (!cancel && !isPos2(p, pos) && !isPos2(redstonePos, pos)) { int x = crystalPos.getX() - targetPos.getX(); int z = crystalPos.getZ() - targetPos.getZ(); BlockPos pos1 = targetPos.add(-x, 0, -z); BlockPos pos2 = pos1.add(z, 0, x); BlockPos pos3 = pos1.add(-z, 0, -x); BlockPos pos4 = targetPos.add(-x, 1, -z); BlockPos pos5 = pos1.add(z, 1, x); BlockPos pos6 = pos1.add(-z, 1, -x); boolean air = (BlockUtil.canReplace(pos1) && BlockUtil.canReplace(pos2) && BlockUtil.canReplace(pos3) && BlockUtil.canReplace(pos4) && BlockUtil.canReplace(pos5) && BlockUtil.canReplace(pos6)); if ((targetPos.add(-x, 0, 0).getX() != pos.getX() && targetPos.add(0, 0, -z).getZ() != pos.getZ()) || (crystalPos.getY() + 1 >= pos.getY() && air)) if (crystalPos.add(x, 0, 0).getX() != pos.getX() && crystalPos.add(0, 0, z).getZ() != pos.getZ()) { if (BlockUtil.getBlock(pos) == Blocks.FIRE) return true;  if (canPlaceFire(pos) && mc.world.isAirBlock(pos) && !BlockUtil.isBlockUnSolid(pos.down()) && !BlockUtil.canOpen(pos.down())) return true;  }   }  }  }  }  return (isPiston || BlockUtil.canPlaceWithoutBase(p, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(p), (((((Boolean)this.base.getValue()).booleanValue() || canPlace(redstonePos.down())) && this.obbySlot != -1) || canPlace(redstonePos) || BlockUtil.getBlock(p) instanceof net.minecraft.block.BlockPistonBase))); }).collect(Collectors.toList()); if (pistonList.isEmpty()) pistonList.addAll(pistons);  BlockPos piston = pistonList.stream().min(Comparator.comparing(this::blockLevel)).orElse(null); PistonAuraPos pos = new PistonAuraPos(crystalPos, piston, getRedStonePos(crystalPos, piston, offset), offset, target, targetPos, block); can.add(pos); if (cPos != null) calc = true;  }  continue; }   }  List<PistonAuraPos> paList = (List<PistonAuraPos>)can.stream().filter(p -> (!p.block || p.offset.z == 1)).collect(Collectors.toList()); if (paList.isEmpty()) paList.addAll(can);  PistonAuraPos pistonAuraPos = paList.stream().min(Comparator.comparing(PistonAuraPos::range)).orElse(null); if (pistonAuraPos != null) sideList.add(pistonAuraPos);  }  if (!sideList.isEmpty()) list.add(sideList.stream().min(Comparator.comparing(PistonAuraPos::range)).orElse(null));  }  PistonAuraPos best = list.stream().min(Comparator.comparing(PistonAuraPos::range)).orElse(null); if (best == null) { this.saveArray = new BlockPos[25]; return null; }  return best; } public boolean isFacing(BlockPos pos, BlockPos facingPos) { ImmutableMap<IProperty<?>, Comparable<?>> properties = mc.world.getBlockState(pos).getProperties(); for (UnmodifiableIterator<IProperty> unmodifiableIterator = properties.keySet().iterator(); unmodifiableIterator.hasNext(); ) { IProperty<?> prop = unmodifiableIterator.next(); if (prop.getValueClass() == EnumFacing.class && (prop.getName().equals("facing") || prop.getName().equals("rotation"))) { BlockPos pushPos = pos.offset((EnumFacing)properties.get(prop)); return isPos2(facingPos, pushPos); }  }  return false; } public BlockPos getRedStonePos(BlockPos crystalPos, BlockPos pistonPos, BlockPos offset) { BlockPos pos = hasRedstoneBlock(pistonPos); if (pos != null) return pos;  List<BlockPos> redstone = new ArrayList<>(); if (this.useBlock) { for (EnumFacing facing : EnumFacing.VALUES) { BlockPos redstonePos = pistonPos.offset(facing); if (BlockUtil.canReplace(redstonePos) && mc.player.getDistance(redstonePos.getX() + 0.5D, redstonePos.getY() + 0.5D, redstonePos.getZ() + 0.5D) <= ((Double)this.range.getValue()).doubleValue()) { boolean can = true; for (BlockPos blockPos : this.fireList) { if (isPos2(crystalPos.up().add((Vec3i)blockPos), redstonePos)) { can = false; break; }  }  if (can && BlockUtil.canPlaceWithoutBase(redstonePos, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(redstonePos), ((Boolean)this.base.getValue()).booleanValue())) redstone.add(redstonePos);  }  }  } else { BlockPos pistonPush = pistonPos.add(offset.getX() * -1, 0, offset.getZ() * -1); for (BlockPos add : this.offsets) { for (int i = 0; i < 2; i++) { BlockPos torch = pistonPos.down(i).add((Vec3i)add); if (BlockUtil.canReplace(torch) && (torch.getX() != crystalPos.getX() || torch.getZ() != crystalPos.getZ()) && (torch.getX() != pistonPush.getX() || torch.getZ() != pistonPush.getZ()) && (i != 1 || !BlockUtil.isBlockUnSolid(torch.up())) && mc.player.getDistance(torch.getX() + 0.5D, torch.getY() + 0.5D, torch.getZ() + 0.5D) <= ((Double)this.range.getValue()).doubleValue() && BlockUtil.canPlaceWithoutBase(torch, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(torch), ((Boolean)this.base.getValue()).booleanValue())) redstone.add(torch);  }  }  }  return redstone.stream().min(Comparator.comparing(this::blockLevel)).orElse(null); } public boolean hasRedstone(BlockPos pos) { return (hasRedstoneBlock(pos) != null); } public BlockPos hasRedstoneBlock(BlockPos pos) { if (BlockUtil.getBlock(pos.up()) == Blocks.REDSTONE_BLOCK) return pos.up();  for (BlockPos offset : this.offsets) { for (int i = 0; i < 2; i++) { BlockPos blockPos = pos.add((Vec3i)offset).down(i); Block block = BlockUtil.getBlock(blockPos); if (i == 0) { if (block == Blocks.REDSTONE_TORCH || block == Blocks.REDSTONE_BLOCK) return blockPos;  } else if (block == Blocks.REDSTONE_TORCH && !BlockUtil.isBlockUnSolid(blockPos.up())) { return blockPos; }  }  }  return null; } private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null) return false;  return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); } private double getDistance(EntityPlayer player, Entity entity) { double x = player.posX - entity.posX; double z = player.posZ - entity.posZ; return Math.sqrt(x * x + z * z); } private boolean canPlace(BlockPos pos) { return (BlockUtil.getFirstFacing(pos, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(pos)) != null && !intersectsWithEntity(pos)); } private boolean canPlaceFire(BlockPos pos) { return (BlockUtil.getFirstFacing(pos, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(pos)) != null); } private Entity getCrystal(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return entity;  }  return null; } private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb) && !(entity instanceof net.minecraft.entity.item.EntityExpBottle) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow) && (((Boolean)this.entityCheck.getValue()).booleanValue() || !(entity instanceof net.minecraft.entity.item.EntityEnderCrystal)) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true;  }  return false; } public void add(List<BlockPos> pistons, BlockPos pos) { pistons.add(pos.add(0, 1, 0)); pistons.add(pos.add(0, 2, 0)); } public static int findHotbarBlock(Block blockIn) { for (int i = 0; i < 9; ) { ItemStack stack = mc.player.inventory.getStackInSlot(i); if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock) || ((ItemBlock)stack.getItem()).getBlock() != blockIn) { i++; continue; }  return i; }  return -1; } private int getItemHotbar() { for (int i = 0; i < (((Boolean)this.crystalBypass.getValue()).booleanValue() ? 36 : 9); ) { Item item = mc.player.inventory.getStackInSlot(i).getItem(); if (Item.getIdFromItem(item) != Item.getIdFromItem(Items.END_CRYSTAL)) { i++; continue; }  return i; }  return -1; } public boolean findMaterials() { this.pistonSlot = findHotbarBlock((Block)Blocks.PISTON); this.obbySlot = findHotbarBlock(Blocks.OBSIDIAN); this.crystalSlot = getItemHotbar(); if (this.pistonSlot == -1) this.pistonSlot = findHotbarBlock((Block)Blocks.STICKY_PISTON);  if (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) this.crystalSlot = 999;  int block = findHotbarBlock(Blocks.REDSTONE_BLOCK); int torch = findHotbarBlock(Blocks.REDSTONE_TORCH); if (((String)this.redstone.getValue()).equals("Block")) this.redStoneSlot = block;  if (((String)this.redstone.getValue()).equals("Torch")) this.redStoneSlot = torch;  if (((String)this.redstone.getValue()).equals("Both")) if (block != -1) { this.redStoneSlot = block; } else { this.redStoneSlot = torch; }   this.useBlock = (this.redStoneSlot == block); return (this.pistonSlot != -1 && this.crystalSlot != -1 && this.redStoneSlot != -1); } private void reset() { int i; for (i = this.saveArray.length - 1; i > 0; i--) this.saveArray[i] = this.saveArray[i - 1];  if (this.pistonPos != null) this.saveArray[0] = this.pistonPos;  for (i = 0; i < this.saveArray.length; i++) { if (i >= ((Integer)this.maxPos.getValue()).intValue()) this.saveArray[i] = null;  }  if (!((Boolean)this.different.getValue()).booleanValue()) this.saveArray = new BlockPos[25];  target = null; this.targetPos = null; this.pistonPos = null; this.crystalPos = null; this.redStonePos = null; this.firePos = null; this.pistonSlot = -1; this.crystalSlot = -1; this.redStoneSlot = -1; this.obbySlot = -1; this.baseTimer = new Timing(); this.timer = new Timing(); this.startBreakTimer = new Timing(); this.breakTimer = new Timing(); this.preparedSpace = false; this.placedPiston = false; this.placedCrystal = false; this.placedRedstone = false; this.brokeCrystal = false; this.boom = false; } public boolean checkPos(BlockPos pos) { BlockPos myPos = PlayerUtil.getPlayerPos(); return (pos.getX() == myPos.getX() && pos.getZ() == myPos.getZ() && (myPos.getY() == pos.getY() || myPos.getY() + 1 == pos.getY())); } public void setItem(int slot, boolean back) { if (slot == 999) return;  if (((Boolean)this.bypass.getValue()).booleanValue()) { bypassSwitch(slot); } else if (!back) { normalSwitch(slot); }  } private void normalSwitch(int slot) { if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; }  } private void bypassSwitch(int slot) { mc.playerController.windowClick(0, slot + 36, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player); } public void restoreItem() { if (((Boolean)this.silentSwitch.getValue()).booleanValue() && !((Boolean)this.bypass.getValue()).booleanValue()) if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.oldSlot)); } else { mc.player.inventory.currentItem = this.oldSlot; mc.playerController.updateController(); }   } public static class PistonAuraPos {
/* 1008 */     public BlockPos targetPos; public BlockPos crystal; public BlockPos piston; public BlockPos redstone; public BlockPos offset; EntityPlayer target; boolean block; public PistonAuraPos(BlockPos crystal, BlockPos piston, BlockPos redstone, BlockPos offset, EntityPlayer target, BlockPos targetPos, boolean block) { this.crystal = crystal; this.piston = piston; this.redstone = redstone; this.offset = offset; this.targetPos = targetPos; this.target = target; this.block = block; } public double range() { double crystalRange = PlayerUtil.getDistanceL(this.crystal); double pistonRange = PlayerUtil.getDistanceL(this.piston); return Math.max(pistonRange, crystalRange); } } private boolean placeBlock(BlockPos pos, boolean packet) { if (!BlockUtil.canReplace(pos)) return false;  EnumFacing side = BlockUtil.getFirstFacing(pos, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(pos)); if (side == null) return false;  BlockPos neighbour = pos.offset(side); EnumFacing opposite = side.getOpposite(); if (!BlockUtil.canBeClicked(neighbour)) return false;  Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D)); boolean sneak = false; if (!ColorMain.INSTANCE.sneaking && BlockUtil.blackList.contains(BlockUtil.getBlock(neighbour))) { mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING)); mc.player.setSneaking(true); sneak = true; }  if (packet) { rightClickBlock(neighbour, hitVec, EnumHand.MAIN_HAND, opposite); } else { mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, opposite, hitVec, EnumHand.MAIN_HAND); }  if (((Boolean)this.swingArm.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  if (((Boolean)this.rotate.getValue()).booleanValue() && ((Boolean)this.pistonRotate.getValue()).booleanValue()) BlockUtil.faceVector(hitVec);  if (sneak) { mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); mc.player.setSneaking(false); }  return true; } public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction) { float f = (float)(vec.x - pos.getX()); float f1 = (float)(vec.y - pos.getY()); float f2 = (float)(vec.z - pos.getZ()); mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2)); } private int blockLevel(BlockPos pos) { return pos.getY() * 10000; }
/*      */ 
/*      */   
/*      */   private boolean needRaytrace(BlockPos pos) {
/* 1012 */     return (mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > ((Double)this.forceRange.getValue()).doubleValue() && ((Boolean)this.raytrace.getValue()).booleanValue());
/*      */   }
/*      */   
/*      */   public boolean canPistonCrystal(BlockPos crystalPos, BlockPos targetPos) {
/* 1016 */     BlockPos offset = new BlockPos(targetPos.x - crystalPos.x, crystalPos.y, targetPos.z - crystalPos.z);
/*      */ 
/*      */     
/* 1019 */     if (BlockUtil.getBlock(crystalPos) != Blocks.OBSIDIAN && BlockUtil.getBlock(crystalPos) != Blocks.BEDROCK) return false; 
/* 1020 */     if (!mc.world.isAirBlock(crystalPos.up()) || !mc.world.isAirBlock(crystalPos.up(2))) return false;
/*      */     
/* 1022 */     BlockPos normal = crystalPos.add((Vec3i)offset);
/*      */     
/* 1024 */     BlockPos oneBlock = normal.add((Vec3i)offset);
/*      */     
/* 1026 */     BlockPos side0 = normal.add(offset.getZ(), 0, offset.getX());
/* 1027 */     BlockPos side1 = normal.add(offset.getZ() * -1, 0, offset.getX() * -1);
/*      */     
/* 1029 */     BlockPos side2 = oneBlock.add(offset.getZ(), 0, offset.getX());
/* 1030 */     BlockPos side3 = oneBlock.add(offset.getZ() * -1, 0, offset.getX() * -1);
/*      */     
/* 1032 */     BlockPos side4 = crystalPos.add(offset.getZ(), 0, offset.getX());
/* 1033 */     BlockPos side5 = crystalPos.add(offset.getZ() * -1, 0, offset.getX() * -1);
/*      */     
/* 1035 */     List<BlockPos> pistons = new ArrayList<>();
/* 1036 */     if (!((Boolean)this.fiveB.getValue()).booleanValue()) add(pistons, normal); 
/* 1037 */     if (!((Boolean)this.fiveB.getValue()).booleanValue()) add(pistons, oneBlock); 
/* 1038 */     add(pistons, side0);
/* 1039 */     add(pistons, side1);
/* 1040 */     add(pistons, side2);
/* 1041 */     add(pistons, side3);
/* 1042 */     add(pistons, side4);
/* 1043 */     add(pistons, side5);
/*      */     
/* 1045 */     List<BlockPos> posList = new ArrayList<>(pistons);
/* 1046 */     posList.removeIf(p -> {
/*      */           if (!((Boolean)this.different.getValue()).booleanValue()) {
/*      */             return false;
/*      */           }
/*      */           boolean same = false;
/*      */           for (BlockPos savePos : this.saveArray) {
/*      */             if (isPos2(savePos, p)) {
/*      */               same = true;
/*      */               break;
/*      */             } 
/*      */           } 
/*      */           return same;
/*      */         });
/* 1059 */     pistons.removeIf(p -> {
/*      */           if (mc.player.getDistance(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D) > ((Double)this.range.getValue()).doubleValue()) {
/*      */             return true;
/*      */           }
/*      */           BlockPos headPos = p.add(offset.getX() * -1, 0, offset.getZ() * -1);
/*      */           Block headBlock = BlockUtil.getBlock(headPos);
/*      */           if (headBlock == Blocks.BEDROCK || headBlock == Blocks.OBSIDIAN || headBlock == Blocks.ENDER_CHEST || headBlock == Blocks.PISTON_HEAD || checkPos(headPos)) {
/*      */             return true;
/*      */           }
/*      */           boolean isPiston = BlockUtil.getBlock(p) instanceof net.minecraft.block.BlockPistonBase;
/*      */           if (!isPiston) {
/*      */             if (!BlockUtil.canPlaceWithoutBase(p, ((Boolean)this.strict.getValue()).booleanValue(), needRaytrace(p), true))
/*      */               return true; 
/*      */             double feetY = mc.player.posY;
/*      */             if ((PlayerUtil.getDistanceI(p) < 0.8D + p.getY() - feetY && p.getY() > feetY + 1.0D) || (PlayerUtil.getDistanceI(p) < 1.8D + feetY - p.getY() && p.getY() < feetY))
/*      */               return true; 
/*      */           } else if (hasRedstone(p) || !isFacing(p, headPos)) {
/*      */             return true;
/*      */           } 
/*      */           BlockPos redstonePos = getRedStonePos(crystalPos, p, offset);
/*      */           if (redstonePos == null)
/*      */             return true; 
/*      */           if (((Boolean)this.fire.getValue()).booleanValue() && ((Boolean)this.fireCheck.getValue()).booleanValue()) {
/*      */             int slot = BurrowUtil.findHotbarBlock(Items.FLINT_AND_STEEL.getClass());
/*      */             if (slot != -1) {
/*      */               BlockPos origin = new BlockPos(targetPos.getX(), crystalPos.getY() + 1, targetPos.getZ());
/*      */               for (BlockPos firePos : this.fireList) {
/*      */                 BlockPos pos = origin.add((Vec3i)firePos);
/*      */                 boolean cancel = false;
/*      */                 for (EnumFacing facing : EnumFacing.values()) {
/*      */                   if (isPos2(p.offset(facing, 1), pos)) {
/*      */                     cancel = true;
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*      */                 if (!cancel && !isPos2(p, pos) && !isPos2(redstonePos, pos)) {
/*      */                   int x = crystalPos.getX() - targetPos.getX();
/*      */                   int z = crystalPos.getZ() - targetPos.getZ();
/*      */                   BlockPos pos1 = targetPos.add(-x, 0, -z);
/*      */                   BlockPos pos2 = pos1.add(z, 0, x);
/*      */                   BlockPos pos3 = pos1.add(-z, 0, -x);
/*      */                   BlockPos pos4 = targetPos.add(-x, 1, -z);
/*      */                   BlockPos pos5 = pos1.add(z, 1, x);
/*      */                   BlockPos pos6 = pos1.add(-z, 1, -x);
/* 1103 */                   boolean air = (BlockUtil.canReplace(pos1) && BlockUtil.canReplace(pos2) && BlockUtil.canReplace(pos3) && BlockUtil.canReplace(pos4) && BlockUtil.canReplace(pos5) && BlockUtil.canReplace(pos6));
/*      */                   if ((targetPos.add(-x, 0, 0).getX() != pos.getX() && targetPos.add(0, 0, -z).getZ() != pos.getZ()) || (crystalPos.getY() + 1 >= pos.getY() && air))
/*      */                     if (crystalPos.add(x, 0, 0).getX() != pos.getX() && crystalPos.add(0, 0, z).getZ() != pos.getZ()) {
/*      */                       if (BlockUtil.getBlock(pos) == Blocks.FIRE)
/*      */                         return false; 
/*      */                       if (canPlaceFire(pos) && mc.world.isAirBlock(pos) && !BlockUtil.isBlockUnSolid(pos.down()) && !BlockUtil.canOpen(pos.down()))
/*      */                         return false; 
/*      */                     }  
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           return false;
/*      */         });
/* 1117 */     return !pistons.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public void onWorldRender(RenderEvent event) {
/* 1122 */     if (mc.world == null || mc.player == null)
/* 1123 */       return;  if (((Boolean)this.render.getValue()).booleanValue()) {
/* 1124 */       if (this.firePos != null && ((Boolean)this.fireRender.getValue()).booleanValue()) {
/* 1125 */         drawBoxMain(this.firePos.x, this.firePos.y, this.firePos.z, 255, 160, 0);
/*      */       }
/* 1127 */       this.lastBestPiston = this.pistonPos;
/* 1128 */       this.lastBestCrystal = this.crystalPos;
/* 1129 */       this.lastBestRedstone = this.redStonePos;
/* 1130 */       if (((Boolean)this.iq.getValue()).booleanValue()) {
/* 1131 */         if (this.lastBestPiston != null) {
/* 1132 */           if (this.movingPistonNow.x == -1.0D && this.movingPistonNow.y == -1.0D && this.movingPistonNow.z == -1.0D) {
/* 1133 */             this.movingPistonNow = new Vec3d(this.lastBestPiston.getX(), this.lastBestPiston.getY(), this.lastBestPiston.getZ());
/*      */           }
/*      */           
/* 1136 */           this
/*      */ 
/*      */             
/* 1139 */             .movingPistonNow = new Vec3d(this.movingPistonNow.x + (this.lastBestPiston.getX() - this.movingPistonNow.x) * ((Double)this.speed.getValue()).floatValue(), this.movingPistonNow.y + (this.lastBestPiston.getY() - this.movingPistonNow.y) * ((Double)this.speed.getValue()).floatValue(), this.movingPistonNow.z + (this.lastBestPiston.getZ() - this.movingPistonNow.z) * ((Double)this.speed.getValue()).floatValue());
/*      */ 
/*      */           
/* 1142 */           drawBoxMain(this.movingPistonNow.x, this.movingPistonNow.y, this.movingPistonNow.z, 255, 255, 150);
/*      */           
/* 1144 */           if (Math.abs(this.movingPistonNow.x - this.lastBestPiston.getX()) <= 0.125D && Math.abs(this.movingPistonNow.y - this.lastBestPiston.getY()) <= 0.125D && Math.abs(this.movingPistonNow.z - this.lastBestPiston.getZ()) <= 0.125D) {
/* 1145 */             this.lastBestPiston = null;
/*      */           }
/*      */         } 
/* 1148 */         if (this.lastBestCrystal != null) {
/* 1149 */           if (this.movingCrystalNow.x == -1.0D && this.movingCrystalNow.y == -1.0D && this.movingCrystalNow.z == -1.0D) {
/* 1150 */             this.movingCrystalNow = new Vec3d(this.lastBestCrystal.getX(), this.lastBestCrystal.getY(), this.lastBestCrystal.getZ());
/*      */           }
/*      */           
/* 1153 */           this
/*      */ 
/*      */             
/* 1156 */             .movingCrystalNow = new Vec3d(this.movingCrystalNow.x + (this.lastBestCrystal.getX() - this.movingCrystalNow.x) * ((Double)this.speed.getValue()).floatValue(), this.movingCrystalNow.y + (this.lastBestCrystal.getY() - this.movingCrystalNow.y) * ((Double)this.speed.getValue()).floatValue(), this.movingCrystalNow.z + (this.lastBestCrystal.getZ() - this.movingCrystalNow.z) * ((Double)this.speed.getValue()).floatValue());
/*      */ 
/*      */           
/* 1159 */           drawBoxMain(this.movingCrystalNow.x, this.movingCrystalNow.y, this.movingCrystalNow.z, 255, 255, 255);
/*      */           
/* 1161 */           if (Math.abs(this.movingCrystalNow.x - this.lastBestCrystal.getX()) <= 0.125D && Math.abs(this.movingCrystalNow.y - this.lastBestCrystal.getY()) <= 0.125D && Math.abs(this.movingCrystalNow.z - this.lastBestCrystal.getZ()) <= 0.125D) {
/* 1162 */             this.lastBestCrystal = null;
/*      */           }
/*      */         } 
/* 1165 */         if (this.lastBestRedstone != null) {
/* 1166 */           if (this.movingRedstoneNow.x == -1.0D && this.movingRedstoneNow.y == -1.0D && this.movingRedstoneNow.z == -1.0D) {
/* 1167 */             this.movingRedstoneNow = new Vec3d(this.lastBestRedstone.getX(), this.lastBestRedstone.getY(), this.lastBestRedstone.getZ());
/*      */           }
/*      */           
/* 1170 */           this
/*      */ 
/*      */             
/* 1173 */             .movingRedstoneNow = new Vec3d(this.movingRedstoneNow.x + (this.lastBestRedstone.getX() - this.movingRedstoneNow.x) * ((Double)this.speed.getValue()).floatValue(), this.movingRedstoneNow.y + (this.lastBestRedstone.getY() - this.movingRedstoneNow.y) * ((Double)this.speed.getValue()).floatValue(), this.movingRedstoneNow.z + (this.lastBestRedstone.getZ() - this.movingRedstoneNow.z) * ((Double)this.speed.getValue()).floatValue());
/*      */ 
/*      */           
/* 1176 */           drawBoxMain(this.movingRedstoneNow.x, this.movingRedstoneNow.y, this.movingRedstoneNow.z, 225, 50, 50);
/*      */           
/* 1178 */           if (Math.abs(this.movingRedstoneNow.x - this.lastBestRedstone.getX()) <= 0.125D && Math.abs(this.movingRedstoneNow.y - this.lastBestRedstone.getY()) <= 0.125D && Math.abs(this.movingRedstoneNow.z - this.lastBestRedstone.getZ()) <= 0.125D) {
/* 1179 */             this.lastBestRedstone = null;
/*      */           }
/*      */         } 
/* 1182 */       } else if (this.pistonPos != null && this.crystalPos != null && this.redStonePos != null) {
/* 1183 */         drawBoxMain(this.pistonPos.x, this.pistonPos.y, this.pistonPos.z, 255, 255, 150);
/* 1184 */         drawBoxMain(this.crystalPos.x, this.crystalPos.y, this.crystalPos.z, 255, 255, 255);
/* 1185 */         drawBoxMain(this.redStonePos.x, this.redStonePos.y, this.redStonePos.z, 225, 50, 50);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z, int r, int g, int b) {
/* 1191 */     AxisAlignedBB box = getBox(x, y, z);
/* 1192 */     if (((Boolean)this.box.getValue()).booleanValue()) RenderUtil.drawBox(box, false, 1.0D, new GSColor(r, g, b, 25), 63); 
/* 1193 */     if (((Boolean)this.outline.getValue()).booleanValue()) RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(r, g, b, 255)); 
/*      */   }
/*      */   
/*      */   AxisAlignedBB getBox(double x, double y, double z) {
/* 1197 */     double maxX = x + 1.0D;
/* 1198 */     double maxZ = z + 1.0D;
/*      */     
/* 1200 */     return new AxisAlignedBB(x, y, z, maxX, y + 1.0D, maxZ);
/*      */   }
/*      */   
/*      */   public String getHudInfo() {
/* 1204 */     return (((Boolean)this.hud.getValue()).booleanValue() && target != null) ? ("[" + ChatFormatting.WHITE + target.getName() + ChatFormatting.GRAY + "]") : "";
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\dev\PistonAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
