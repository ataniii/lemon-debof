//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*      */ package com.lemonclient.client.module.modules.qwq;
/*      */ 
/*      */ import com.lemonclient.api.event.Phase;
/*      */ import com.lemonclient.api.event.events.OnUpdateWalkingPlayerEvent;
/*      */ import com.lemonclient.api.event.events.PacketEvent;
/*      */ import com.lemonclient.api.setting.values.BooleanSetting;
/*      */ import com.lemonclient.api.setting.values.DoubleSetting;
/*      */ import com.lemonclient.api.setting.values.IntegerSetting;
/*      */ import com.lemonclient.api.setting.values.ModeSetting;
/*      */ import com.lemonclient.api.util.misc.CrystalUtil;
/*      */ import com.lemonclient.api.util.misc.Timing;
/*      */ import com.lemonclient.api.util.player.BurrowUtil;
/*      */ import com.lemonclient.api.util.player.PlayerPacket;
/*      */ import com.lemonclient.api.util.player.PlayerUtil;
/*      */ import com.lemonclient.api.util.player.PredictUtil;
/*      */ import com.lemonclient.api.util.player.RotationUtil;
/*      */ import com.lemonclient.api.util.render.GSColor;
/*      */ import com.lemonclient.api.util.render.RenderUtil;
/*      */ import com.lemonclient.api.util.world.EntityUtil;
/*      */ import com.lemonclient.api.util.world.combat.DamageUtil;
/*      */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*      */ import com.lemonclient.client.module.ModuleManager;
/*      */ import com.lemonclient.client.module.modules.dev.OffHandCat;
/*      */ import com.lemonclient.client.module.modules.dev.PistonAura;
/*      */ import com.lemonclient.client.module.modules.dev.PullCrystal;
/*      */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.stream.Collectors;
/*      */ import me.zero.alpine.listener.EventHandler;
/*      */ import me.zero.alpine.listener.Listener;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.client.entity.EntityPlayerSP;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityLivingBase;
/*      */ import net.minecraft.entity.item.EntityEnderCrystal;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.init.MobEffects;
/*      */ import net.minecraft.init.SoundEvents;
/*      */ import net.minecraft.inventory.ClickType;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.network.Packet;
/*      */ import net.minecraft.network.play.client.CPacketClickWindow;
/*      */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*      */ import net.minecraft.network.play.client.CPacketPlayer;
/*      */ import net.minecraft.network.play.client.CPacketUseEntity;
/*      */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*      */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.EnumHand;
/*      */ import net.minecraft.util.NonNullList;
/*      */ import net.minecraft.util.SoundCategory;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.RayTraceResult;
/*      */ import net.minecraft.util.math.Vec2f;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.util.math.Vec3i;
/*      */ import net.minecraft.world.World;
/*      */ 
/*      */ @Declaration(name = "LemonAura", category = Category.qwq, priority = 999)
/*      */ public class LemonAura extends Module {
/*   70 */   public LemonAura() { this.p = registerMode("Page", Arrays.asList(new String[] { "General", "Combat", "Predict", "Dev", "Render" }, ), "General");
/*      */ 
/*      */     
/*   73 */     this.logic = registerMode("Logic", Arrays.asList(new String[] { "PlaceBreak", "BreakPlace" }, ), "BreakPlace", () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   74 */     this.monster = registerBoolean("Monsters", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   75 */     this.neutral = registerBoolean("Neutrals", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   76 */     this.animal = registerBoolean("Animals", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   77 */     this.updateDelay = registerInteger("UpdateDelay", 25, 0, 1000, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   78 */     this.place = registerBoolean("Place", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   79 */     this.multiPlace = registerBoolean("MultiPlace", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   80 */     this.calc = registerBoolean("CalcHitVec", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   81 */     this.y256 = registerBoolean("Y256", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   82 */     this.placeDelay = registerInteger("PlaceDelay", 25, 0, 1000, () -> Boolean.valueOf((((Boolean)this.place.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   83 */     this.base = registerBoolean("Base", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   84 */     this.baseDelay = registerInteger("BaseDelay", 100, 0, 200, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   85 */     this.toggleDamage = registerInteger("ToggleMaxDmg", 12, 0, 36, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   86 */     this.baseMinDamage = registerInteger("BaseMinDmg", 6, 0, 36, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   87 */     this.maxSpeed = registerDouble("MaxSpeed", 10.0D, 0.0D, 50.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   88 */     this.baseBypass = registerBoolean("BaseBypassSwitch", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   89 */     this.packetPlace = registerBoolean("PacketPlace", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && ((Boolean)this.base.getValue()).booleanValue())));
/*   90 */     this.explode = registerBoolean("Explode", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   91 */     this.hitDelay = registerInteger("HitDelay", 25, 0, 1000, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   92 */     this.antiWeakness = registerBoolean("AntiWeakness", false, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   93 */     this.silentAntiWeak = registerBoolean("SilentAntiWeakness", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   94 */     this.weakBypass = registerBoolean("BypassSilent", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((Boolean)this.silentAntiWeak.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   95 */     this.packetWeak = registerBoolean("PacketSwitch", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((Boolean)this.silentAntiWeak.getValue()).booleanValue() && !((Boolean)this.weakBypass.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   96 */     this.wall = registerBoolean("WallCheck", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   97 */     this.wallAI = registerBoolean("WallAI", true, () -> Boolean.valueOf((((Boolean)this.wall.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   98 */     this.enemyRange = registerInteger("EnemyRange", 7, 1, 16, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   99 */     this.placeRange = registerDouble("PlaceRange", 5.5D, 0.0D, 6.0D, () -> Boolean.valueOf((((Boolean)this.place.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*  100 */     this.placeWallRange = registerDouble("PlaceWallRange", 3.0D, 0.1D, 6.0D, () -> Boolean.valueOf((((Boolean)this.wall.getValue()).booleanValue() && !((Boolean)this.wallAI.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*  101 */     this.breakRange = registerDouble("BreakRange", 5.5D, 0.0D, 6.0D, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*  102 */     this.breakWallRange = registerDouble("BreakWallRange", 3.0D, 0.1D, 6.0D, () -> Boolean.valueOf((((Boolean)this.wall.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*  103 */     this.breakMinDmg = registerInteger("BreakMinDmg", 2, 0, 36, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && !((Boolean)this.wallAI.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*  104 */     this.minDamage = registerDouble("MinDmg", 4.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*  105 */     this.fpMinDmg = registerDouble("FpMinDmg", 1.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*  106 */     this.godMode = registerMode("SelfDamage", Arrays.asList(new String[] { "Auto", "GodMode", "NoGodMode" }, ), "Auto", () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*  107 */     this.forcePlace = registerBoolean("ForcePlace", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*  108 */     this.maxSelfDMG = registerDouble("MaxSelfDmg", 12.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && !((String)this.godMode.getValue()).equals("GodMode"))));
/*  109 */     this.balance = registerDouble("HealthBalance", 1.5D, 0.0D, 10.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && !((String)this.godMode.getValue()).equals("GodMode"))));
/*  110 */     this.ignoreTerrain = registerBoolean("IgnoreTerrain", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*      */ 
/*      */     
/*  113 */     this.switchMode = registerMode("SwitchMode", Arrays.asList(new String[] { "AutoSwitch", "Off" }, ), "Off", () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  114 */     this.offhand = registerBoolean("Offhand", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch"))));
/*  115 */     this.switchBack = registerBoolean("SwitchBack", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue())));
/*  116 */     this.bypass = registerBoolean("Bypass", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue())));
/*  117 */     this.switchSpeed = registerDouble("SwitchSpeed", 10.0D, 0.1D, 20.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue() && ((Boolean)this.bypass.getValue()).booleanValue())));
/*  118 */     this.forceUpdate = registerBoolean("ForceUpdate", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue() && ((Boolean)this.bypass.getValue()).booleanValue())));
/*  119 */     this.packetSwitch = registerBoolean("PacketSwitch", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue())));
/*  120 */     this.packet = registerBoolean("PacketCrystal", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  121 */     this.placeAfter = registerBoolean("PlaceAfterBreak", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  122 */     this.post = registerBoolean("Posted", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.placeAfter.getValue()).booleanValue())));
/*  123 */     this.placeOnRemove = registerBoolean("PlaceOnRemove", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  124 */     this.rotate = registerBoolean("Rotate", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  125 */     this.placeRotate = registerBoolean("PlaceRotate", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.rotate.getValue()).booleanValue())));
/*  126 */     this.swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  127 */     this.packetSwing = registerBoolean("PacketSwing", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.swing.getValue()).booleanValue())));
/*  128 */     this.crystalCheck = registerBoolean("CrystalCheck", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  129 */     this.highVersion = registerBoolean("1.13Place", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  130 */     this.facePlace = registerBoolean("FacePlace", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  131 */     this.BlastHealth = registerInteger("BlastHealth", 10, 0, 20, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.facePlace.getValue()).booleanValue())));
/*  132 */     this.ArmorCheck = registerBoolean("ArmorFucker", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.facePlace.getValue()).booleanValue())));
/*  133 */     this.ArmorRate = registerInteger("Armor%", 15, 0, 100, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.facePlace.getValue()).booleanValue() && ((Boolean)this.ArmorCheck.getValue()).booleanValue())));
/*  134 */     this.PacketExplode = registerBoolean("PacketExplode", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  135 */     this.PacketExplodeDelay = registerInteger("PacketExplodeDelay", 45, 0, 500, () -> Boolean.valueOf((((Boolean)this.PacketExplode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("Combat"))));
/*  136 */     this.ClientSide = registerBoolean("ClientSide", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  137 */     this.PredictHit = registerBoolean("PredictHit", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  138 */     this.PredictHitFactor = registerInteger("PredictHitFactor", 2, 1, 20, () -> Boolean.valueOf((((Boolean)this.PredictHit.getValue()).booleanValue() && ((String)this.p.getValue()).equals("Combat"))));
/*      */ 
/*      */     
/*  141 */     this.target = registerBoolean("Target", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  142 */     this.self = registerBoolean("Self", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  143 */     this.tickPredict = registerInteger("TickPredict", 8, 0, 30, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  144 */     this.calculateYPredict = registerBoolean("CalculateYPredict", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  145 */     this.startDecrease = registerInteger("StartDecrease", 39, 0, 200, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  146 */     this.exponentStartDecrease = registerInteger("ExponentStart", 2, 1, 5, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  147 */     this.decreaseY = registerInteger("DecreaseY", 2, 1, 5, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  148 */     this.exponentDecreaseY = registerInteger("ExponentDecreaseY", 1, 1, 3, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  149 */     this.splitXZ = registerBoolean("SplitXZ", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  150 */     this.manualOutHole = registerBoolean("ManualOutHole", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  151 */     this.aboveHoleManual = registerBoolean("AboveHoleManual", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.manualOutHole.getValue()).booleanValue())));
/*  152 */     this.stairPredict = registerBoolean("StairPredict", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  153 */     this.nStair = registerInteger("NStair", 2, 1, 4, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*  154 */     this.speedActivationStair = registerDouble("SpeedActivationStair", 0.11D, 0.0D, 1.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*      */ 
/*      */     
/*  157 */     this.MineDetect = registerBoolean("MineDetect", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  158 */     this.packetOptimize = registerBoolean("PacketOptimize", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  159 */     this.limit = registerInteger("Limit", 40, 1, 100, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Dev") && ((Boolean)this.packetOptimize.getValue()).booleanValue())));
/*  160 */     this.pause = registerBoolean("PausePistonAura", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  161 */     this.eat = registerBoolean("WhileEating", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  162 */     this.showBreakDelay = registerBoolean("ShowBreakDelay", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  163 */     this.speedDebug = registerBoolean("SpeedDebug", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*      */ 
/*      */     
/*  166 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Solid", "Both", "Outline" }, ), "Full", () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  167 */     this.showDamage = registerBoolean("ShowDamage", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  168 */     this.flat = registerBoolean("Flat", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  169 */     this.color = registerColor("Color", new GSColor(255, 255, 255), () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  170 */     this.alpha = registerInteger("Alpha", 50, 0, 255, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  171 */     this.outAlpha = registerInteger("OutlineAlpha", 125, 0, 255, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  172 */     this.move = registerBoolean("Move", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  173 */     this.movingSpeed = registerDouble("MovingSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.move.getValue()).booleanValue())));
/*      */     
/*  175 */     this.reset = registerBoolean("Reset", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.move.getValue()).booleanValue())));
/*  176 */     this.fade = registerBoolean("Fade", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  177 */     this.fadeAlpha = registerInteger("FadeAlpha", 50, 0, 255, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  178 */     this.fadeOutAlpha = registerInteger("FadeOutlineAlpha", 125, 0, 255, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  179 */     this.lifeTime = registerInteger("LifeTime", 3000, 0, 5000, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  180 */     this.scale = registerBoolean("BoxScale", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && (((Boolean)this.move.getValue()).booleanValue() || ((Boolean)this.fade.getValue()).booleanValue()))));
/*  181 */     this.growSpeed = registerDouble("BoxGrowSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && this.scale.isVisible() && ((Boolean)this.scale.getValue()).booleanValue())));
/*  182 */     this.reduceSpeed = registerDouble("BoxReduceSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && this.scale.isVisible() && ((Boolean)this.scale.getValue()).booleanValue())));
/*  183 */     this.managerRenderBlocks = new managerClassRenderBlocks();
/*  184 */     this.shorts = new ArrayList<>();
/*      */     
/*  186 */     this.PacketExplodeTimer = new Timing();
/*  187 */     this.ExplodeTimer = new Timing();
/*  188 */     this.UpdateTimer = new Timing();
/*  189 */     this.PlaceTimer = new Timing();
/*  190 */     this.CalcTimer = new Timing();
/*      */     
/*  192 */     this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  193 */     this.lastBestPlace = null;
/*      */ 
/*      */     
/*  196 */     this.ShouldInfoLastBreak = false;
/*  197 */     this.afterAttacking = false;
/*  198 */     this.canPredictHit = false;
/*      */ 
/*      */     
/*  201 */     this.infoBreakTime = 0L;
/*  202 */     this.lastBreakTime = 0L;
/*  203 */     this.lastEntityID = -1;
/*  204 */     this.placements = 0;
/*  205 */     this.StuckTimes = 0;
/*  206 */     this.crystals = 0;
/*      */ 
/*      */     
/*  209 */     this.size = -1.0D;
/*      */ 
/*      */     
/*  212 */     this.timer = new Timing();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  264 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (event.getPhase() != Phase.PRE || this.lastHitVec == null || !((Boolean)this.rotate.getValue()).booleanValue()) return;  PlayerPacket packet = new PlayerPacket(this, RotationUtil.getRotationTo(this.lastHitVec)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketUseEntity && ((Boolean)this.placeAfter.getValue()).booleanValue() && ((Boolean)this.post.getValue()).booleanValue() && ((CPacketUseEntity)event.getPacket()).getAction() == CPacketUseEntity.Action.ATTACK) { Entity attacked = ((CPacketUseEntity)event.getPacket()).getEntityFromWorld((World)mc.world); if (attacked instanceof EntityEnderCrystal) { long passed = this.PlaceTimer.getTime(); this.PlaceTimer.setMs((((Integer)this.placeDelay.getValue()).intValue() + 1)); place(false); this.PlaceTimer.setTime(passed); }  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  286 */     this.sendListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (((Boolean)this.packetOptimize.getValue()).booleanValue() && event.getPacket() instanceof CPacketUseEntity && packetList.size() > ((Integer)this.limit.getValue()).intValue()) { event.cancel(); packetList.clear(); }  if (event.getPacket() instanceof CPacketUseEntity && ((Boolean)this.placeAfter.getValue()).booleanValue() && !((Boolean)this.post.getValue()).booleanValue() && ((CPacketUseEntity)event.getPacket()).getAction() == CPacketUseEntity.Action.ATTACK) { Entity attacked = ((CPacketUseEntity)event.getPacket()).getEntityFromWorld((World)mc.world); if (attacked instanceof EntityEnderCrystal) { long passed = this.PlaceTimer.getTime(); this.PlaceTimer.setMs((((Integer)this.placeDelay.getValue()).intValue() + 1)); place(false); this.PlaceTimer.setTime(passed); }  }  if (((Boolean)this.rotate.getValue()).booleanValue() && this.lastHitVec != null) { Vec2f vec = RotationUtil.getRotationTo(this.lastHitVec); if (event.getPacket() instanceof CPacketPlayer.Rotation) { ((CPacketPlayer.Rotation)event.getPacket()).yaw = vec.x; ((CPacketPlayer.Rotation)event.getPacket()).pitch = vec.y; }  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) { ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = vec.x; ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = vec.y; }  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof SPacketSpawnObject) { SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket(); if (((Boolean)this.PredictHit.getValue()).booleanValue()) for (Entity e : mc.world.loadedEntityList) { if ((e instanceof net.minecraft.entity.item.EntityItem || e instanceof net.minecraft.entity.projectile.EntityArrow || e instanceof net.minecraft.entity.item.EntityEnderPearl || e instanceof net.minecraft.entity.projectile.EntitySnowball || e instanceof net.minecraft.entity.projectile.EntityEgg) && e.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= 6.0D) { this.lastEntityID = -1; this.canPredictHit = false; event.cancel(); }  }   if (packet.getType() == 51) { this.lastEntityID = packet.getEntityID(); EntityEnderCrystal crystal = (EntityEnderCrystal)mc.world.getEntityByID(this.lastEntityID); if (crystal != null && ((Boolean)this.PacketExplode.getValue()).booleanValue() && this.PacketExplodeTimer.passedMs(((Integer)this.PacketExplodeDelay.getValue()).intValue()) && ((Boolean)this.explode.getValue()).booleanValue() && this.lastCrystal != null && renderEnt != null) { if (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal)) return;  if (canHitCrystal(crystal)) { PacketExplode(this.lastEntityID); this.PacketExplodeTimer.reset(); }  }  }  }  if (event.getPacket() instanceof SPacketSoundEffect) { SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket(); if (packet.getSound().equals(SoundEvents.ENTITY_EXPERIENCE_BOTTLE_THROW) || packet.getSound().equals(SoundEvents.ENTITY_ITEM_BREAK)) this.canPredictHit = false;  if (packet.getSound().equals(SoundEvents.ITEM_TOTEM_USE)) for (EntityPlayer entity : mc.world.playerEntities) renderEnt = (Entity)entity;   if (packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE && this.render != null) { this.ShouldInfoLastBreak = true; for (Entity e : new ArrayList(mc.world.loadedEntityList)) { if (e instanceof EntityEnderCrystal && e.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= 6.0D) { e.setDead(); this.crystals++; if (((Boolean)this.placeOnRemove.getValue()).booleanValue()) { long passed = this.PlaceTimer.getTime(); this.PlaceTimer.setMs((((Integer)this.placeDelay.getValue()).intValue() + 1)); place(false); this.PlaceTimer.setTime(passed); }  }  }  }  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1027 */     this.c = 0; }
/*      */   
/* 1029 */   public static CopyOnWriteArrayList<CPacketUseEntity> packetList = new CopyOnWriteArrayList<>(); public static LemonAura INSTANCE = new LemonAura(); public static Entity renderEnt; ModeSetting p; ModeSetting logic; BooleanSetting monster; BooleanSetting neutral; BooleanSetting animal; IntegerSetting updateDelay; BooleanSetting place; BooleanSetting multiPlace; BooleanSetting calc; BooleanSetting y256; IntegerSetting placeDelay; BooleanSetting base; IntegerSetting baseDelay; IntegerSetting toggleDamage; IntegerSetting baseMinDamage; DoubleSetting maxSpeed; BooleanSetting baseBypass; BooleanSetting packetPlace; BooleanSetting explode; IntegerSetting hitDelay; BooleanSetting antiWeakness; BooleanSetting silentAntiWeak; BooleanSetting weakBypass; BooleanSetting packetWeak; BooleanSetting wall; BooleanSetting wallAI; IntegerSetting enemyRange; DoubleSetting placeRange; DoubleSetting placeWallRange; DoubleSetting breakRange; DoubleSetting breakWallRange; IntegerSetting breakMinDmg; DoubleSetting minDamage; DoubleSetting fpMinDmg; ModeSetting godMode; BooleanSetting forcePlace; DoubleSetting maxSelfDMG; DoubleSetting balance; public BooleanSetting ignoreTerrain; ModeSetting switchMode; BooleanSetting offhand; BooleanSetting switchBack; BooleanSetting bypass; DoubleSetting switchSpeed; BooleanSetting forceUpdate; BooleanSetting packetSwitch; BooleanSetting packet; BooleanSetting placeAfter; BooleanSetting post; BooleanSetting placeOnRemove; BooleanSetting rotate; BooleanSetting placeRotate; BooleanSetting swing; BooleanSetting packetSwing; BooleanSetting crystalCheck; BooleanSetting highVersion; BooleanSetting facePlace; IntegerSetting BlastHealth; BooleanSetting ArmorCheck; IntegerSetting ArmorRate; BooleanSetting PacketExplode; IntegerSetting PacketExplodeDelay; BooleanSetting ClientSide; BooleanSetting PredictHit; IntegerSetting PredictHitFactor; BooleanSetting target; BooleanSetting self; IntegerSetting tickPredict; BooleanSetting calculateYPredict; IntegerSetting startDecrease; IntegerSetting exponentStartDecrease; IntegerSetting decreaseY; IntegerSetting exponentDecreaseY; BooleanSetting splitXZ; BooleanSetting manualOutHole; BooleanSetting aboveHoleManual; BooleanSetting stairPredict; IntegerSetting nStair; DoubleSetting speedActivationStair; BooleanSetting MineDetect; BooleanSetting packetOptimize; IntegerSetting limit; BooleanSetting pause; BooleanSetting eat; public String getHudInfo() { if (renderEnt == null) return ""; 
/* 1030 */     if (this.ShouldInfoLastBreak && this.lastBreakTime != 0L) {
/* 1031 */       this.infoBreakTime = System.currentTimeMillis() - this.lastBreakTime;
/* 1032 */       this.lastBreakTime = 0L;
/* 1033 */       this.ShouldInfoLastBreak = false;
/*      */     } 
/*      */ 
/*      */     
/* 1037 */     if (this.calculated) {
/* 1038 */       this.c = this.crystals;
/* 1039 */       this.calculated = false;
/* 1040 */       this.crystals = 0;
/*      */     } 
/*      */     
/* 1043 */     String text = "[" + ChatFormatting.WHITE + renderEnt.getName() + (((Boolean)this.showBreakDelay.getValue()).booleanValue() ? (", " + this.infoBreakTime + "ms") : "") + (((Boolean)this.speedDebug.getValue()).booleanValue() ? (", " + this.c + "c/s)") : "") + ChatFormatting.GRAY + "]";
/* 1044 */     return text; }
/*      */   BooleanSetting showBreakDelay;
/*      */   BooleanSetting speedDebug;
/*      */   ModeSetting mode;
/*      */   BooleanSetting showDamage;
/*      */   BooleanSetting flat;
/*      */   ColorSetting color;
/*      */   IntegerSetting alpha; IntegerSetting outAlpha; BooleanSetting move; DoubleSetting movingSpeed; BooleanSetting reset; BooleanSetting fade; IntegerSetting fadeAlpha; IntegerSetting fadeOutAlpha; IntegerSetting lifeTime; BooleanSetting scale; DoubleSetting growSpeed; DoubleSetting reduceSpeed; managerClassRenderBlocks managerRenderBlocks; List<Short> shorts; PredictUtil.PredictSettings settings; Timing PacketExplodeTimer; Timing ExplodeTimer; Timing UpdateTimer; Timing PlaceTimer; Timing CalcTimer; EntityEnderCrystal lastCrystal; Vec3d movingPlaceNow; BlockPos lastBestPlace; BlockPos render; BlockPos webPos; boolean ShouldInfoLastBreak; boolean afterAttacking; boolean canPredictHit; boolean calculated; boolean canBase; long infoBreakTime; long lastBreakTime; int lastEntityID; int placements; int StuckTimes; int crystals; int waited; int crystalSlot; double size; float damage; Vec3d lastHitVec; Timing timer; @EventHandler private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener; @EventHandler private final Listener<PacketEvent.PostSend> postSendListener; @EventHandler private final Listener<PacketEvent.Send> sendListener; @EventHandler private final Listener<PacketEvent.Receive> receiveListener; boolean tryCalc; int c; BlockPos blockPos; public void windowClick(int windowId, int slotId, int mouseButton, ClickType type, ItemStack itemstack, EntityPlayer player, short id) { player.openContainer.slotClick(slotId, mouseButton, type, player); } private void switchTo(int slot, boolean bypass, boolean shouldSwitch, boolean back, Runnable runnable) { int oldslot = mc.player.inventory.currentItem; if (!shouldSwitch || slot < 0 || slot == oldslot) { runnable.run(); return; }  if (bypass) { if (this.timer.passedMs((long)(1000.0D / ((Double)this.switchSpeed.getValue()).doubleValue()))) { this.timer.reset(); if (slot < 9) slot += 36;  short id = mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory); this.shorts.add(Short.valueOf(id)); if (!((Boolean)this.packetSwitch.getValue()).booleanValue()) windowClick(0, slot, oldslot, ClickType.SWAP, ItemStack.EMPTY, (EntityPlayer)mc.player, id);  mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, oldslot, ClickType.SWAP, ItemStack.EMPTY, id)); runnable.run(); mc.player.openContainer.detectAndSendChanges(); id = mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory); this.shorts.add(Short.valueOf(id)); if (!((Boolean)this.packetSwitch.getValue()).booleanValue()) windowClick(0, slot, oldslot, ClickType.SWAP, Items.END_CRYSTAL.getDefaultInstance(), (EntityPlayer)mc.player, id);  mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, oldslot, ClickType.SWAP, ((Boolean)this.forceUpdate.getValue()).booleanValue() ? Items.END_CRYSTAL.getDefaultInstance() : ItemStack.EMPTY, id)); mc.player.openContainer.detectAndSendChanges(); }  } else if (slot < 9) { boolean packetSwitch = (back && ((Boolean)this.packetSwitch.getValue()).booleanValue()); if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; }  runnable.run(); if (back) if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); } else { mc.player.inventory.currentItem = oldslot; }   }  } public static double getRange(Vec3d a, double x, double y, double z) { double xl = a.x - x; double yl = a.y - y; double zl = a.z - z; return Math.sqrt(xl * xl + yl * yl + zl * zl); } public void onTick() { if (!this.tryCalc) return;  if (this.UpdateTimer.passedMs(((Integer)this.updateDelay.getValue()).intValue())) { if (this.crystalSlot == -1 && (!((Boolean)this.offhand.getValue()).booleanValue() || !((String)this.switchMode.getValue()).equals("AutoSwitch")) && mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) return;  CrystalTarget crystalTarget = Calc(); renderEnt = crystalTarget.target; this.render = crystalTarget.blockPos; this.damage = (float)crystalTarget.dmg; if (renderEnt == null || this.render == null) { if (((Boolean)this.reset.getValue()).booleanValue()) this.lastBestPlace = null;  this.damage = 0.0F; this.lastBreakTime = System.currentTimeMillis(); this.render = null; switchOffhand(false); pausePA(false); this.lastHitVec = null; return; }  if (renderEnt instanceof EntityPlayer) AutoEz.INSTANCE.addTargetedPlayer(renderEnt.getName());  this.UpdateTimer.reset(); }  } public void fast() { if (mc.world == null || mc.player == null || mc.player.isDead) return;  this.managerRenderBlocks.update(((Integer)this.lifeTime.getValue()).intValue()); if (this.CalcTimer.passedMs(1000L)) { this.CalcTimer.reset(); this.calculated = true; }  this.crystalSlot = getItemHotbar(); if (this.crystalSlot == -1 && (!((Boolean)this.offhand.getValue()).booleanValue() || !((String)this.switchMode.getValue()).equals("AutoSwitch")) && mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) { if (((Boolean)this.reset.getValue()).booleanValue()) this.lastBestPlace = null;  this.damage = 0.0F; this.lastBreakTime = System.currentTimeMillis(); renderEnt = null; this.render = null; switchOffhand(false); pausePA(false); this.lastHitVec = null; this.tryCalc = false; return; }  this.tryCalc = true; if (((Boolean)this.base.getValue()).booleanValue() && this.waited++ >= ((Integer)this.baseDelay.getValue()).intValue()) { this.canBase = true; this.waited = 0; }  if (renderEnt == null || this.render == null) return;  if (!((Boolean)this.eat.getValue()).booleanValue() && EntityUtil.isEating()) { this.lastHitVec = null; return; }  if (((String)this.logic.getValue()).equals("BreakPlace")) { explode(); place(((Boolean)this.crystalCheck.getValue()).booleanValue()); } else { place(((Boolean)this.crystalCheck.getValue()).booleanValue()); explode(); }  } public void explode() { if (this.damage == 0.0F) return;  EntityEnderCrystal crystal = mc.world.loadedEntityList.stream().filter(e -> (e instanceof EntityEnderCrystal && !e.isDead && canHitCrystal((EntityEnderCrystal)e))).map(e -> (EntityEnderCrystal)e).min(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance((Entity)e)))).orElse(null); if (mc.player != null && crystal != null && renderEnt != null) { if (((Boolean)this.explode.getValue()).booleanValue() && mc.player.getDistance((Entity)crystal) <= ((Double)this.breakRange.getValue()).doubleValue()) { this.lastCrystal = crystal; if (!((Boolean)this.wall.getValue()).booleanValue() || mc.player.getDistance((Entity)crystal) <= ((Double)this.breakWallRange.getValue()).doubleValue() || CrystalUtil.calculateRaytrace((Entity)crystal)) { if (this.StuckTimes > 0) this.StuckTimes = 0;  this.lastHitVec = new Vec3d(crystal.posX, crystal.posY, crystal.posZ); ExplodeCrystal((Entity)this.lastCrystal); this.afterAttacking = true; } else { this.afterAttacking = false; this.StuckTimes++; }  }  if (((Boolean)this.ClientSide.getValue()).booleanValue()) { for (Entity o : mc.world.getLoadedEntityList()) { if (o instanceof EntityEnderCrystal && o.getDistance(o.posX, o.posY, o.posZ) <= 6.0D) o.setDead();  }  mc.world.removeAllEntities(); }  if (((Boolean)this.multiPlace.getValue()).booleanValue() && this.placements >= 3) { this.placements = 0; this.afterAttacking = true; }  }  } private boolean in(int number, int floor, int ceil) { return (number >= floor && number <= ceil); } private boolean crystalPlaceBoxIntersectsCrystalBox(BlockPos placePos, Double x, Double y, Double z) { return (in(x.intValue() - placePos.y, 0, 2) && in(y.intValue() - placePos.x, -1, 1) && in(z.intValue() - placePos.z, -1, 1)); } private void place(boolean check) { if (((Boolean)this.place.getValue()).booleanValue() && this.render != null) { boolean useOffhand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL); if (mc.player.inventory.currentItem != this.crystalSlot && !useOffhand) if (((String)this.switchMode.getValue()).equals("AutoSwitch")) { if (((Boolean)this.offhand.getValue()).booleanValue()) { switchOffhand(true); return; }  } else { return; }   pausePA(((Boolean)this.pause.getValue()).booleanValue()); if (mc.world.getBlockState(this.render).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(this.render).getBlock() != Blocks.OBSIDIAN) { int obby = BurrowUtil.findBlock(BlockObsidian.class, findInventory()); if (obby == -1) return;  switchTo(obby, ((Boolean)this.baseBypass.getValue()).booleanValue(), true, true, () -> BurrowUtil.placeBlock(this.render, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue())); this.canBase = false; }  if (this.PlaceTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue())) { boolean detected = true; for (Entity entity : new ArrayList(mc.world.loadedEntityList)) { if (entity instanceof EntityEnderCrystal && !entity.isDead && crystalPlaceBoxIntersectsCrystalBox(this.render, Double.valueOf(entity.posX), Double.valueOf(entity.posY), Double.valueOf(entity.posZ))) detected = false;  }  if (detected || !check) { EnumHand hand = useOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND; EnumFacing facing = (((Boolean)this.y256.getValue()).booleanValue() && this.render.getY() == 255) ? EnumFacing.DOWN : EnumFacing.UP; if (((Boolean)this.calc.getValue()).booleanValue()) { RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(this.render.getX() + 0.5D, this.render.getY() + 0.5D, this.render.getZ() + 0.5D)); if (result != null && result.sideHit != null) facing = result.sideHit;  }  EnumFacing opposite = facing.getOpposite(); Vec3d vec = (new Vec3d((Vec3i)this.render)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(opposite.getDirectionVec())); this.lastHitVec = ((Boolean)this.placeRotate.getValue()).booleanValue() ? vec : new Vec3d(this.render.x + 0.5D, (this.render.y + 1), this.render.z + 0.5D); EnumFacing finalFacing = facing; switchTo(this.crystalSlot, findInventory(), (!useOffhand && ((String)this.switchMode.getValue()).equals("AutoSwitch")), ((Boolean)this.switchBack.getValue()).booleanValue(), () -> { if (((Boolean)this.packet.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.render, finalFacing, hand, 0.0F, 0.0F, 0.0F)); } else { mc.playerController.processRightClickBlock(mc.player, mc.world, this.render, finalFacing, vec, hand); }  }); if (((Boolean)this.swing.getValue()).booleanValue()) if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); } else { mc.player.swingArm(hand); }   this.placements++; this.PlaceTimer.reset(); }  }  if (((Boolean)this.PredictHit.getValue()).booleanValue() && renderEnt != null && DamageUtil.calculateCrystalDamage((EntityLivingBase)renderEnt, this.render.x + 0.5D, (this.render.y + 1), this.render.z + 0.5D) > ((Integer)this.breakMinDmg.getValue()).intValue()) try { if (renderEnt.isDead || !this.canPredictHit || (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal))) { this.PlaceTimer.reset(); return; }  if (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal)) return;  if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) > ((Double)this.maxSelfDMG.getValue()).doubleValue() && this.lastEntityID != -1 && this.lastCrystal != null && this.canPredictHit) for (int i = 0; i < ((Integer)this.PredictHitFactor.getValue()).intValue(); i++) PacketExplode(this.lastEntityID + i + 2);   } catch (Exception exception) {}  }  } public CrystalTarget Calc() { EntityPlayer entityPlayer1; List<BlockPos> default_blocks; EntityPlayer entityPlayer2; List<EntityLivingBase> entities = getEntities(); double damage = 0.0D; EntityLivingBase renderEnt = null; BlockPos render = null; BlockPos setToAir = null; IBlockState state = null; if (((Boolean)this.wall.getValue()).booleanValue() && ((Boolean)this.wallAI.getValue()).booleanValue()) { double TempRange = ((Double)this.placeRange.getValue()).doubleValue(); double temp2 = TempRange - this.StuckTimes * 0.5D; if (this.StuckTimes > 0) { TempRange = ((Double)this.placeRange.getValue()).doubleValue(); if (temp2 > ((Double)this.placeWallRange.getValue()).doubleValue()) { TempRange = temp2; } else if (((Double)this.placeWallRange.getValue()).doubleValue() < ((Double)this.placeRange.getValue()).doubleValue()) { TempRange = 3.0D; }  }  default_blocks = renditions(TempRange); } else { default_blocks = renditions(((Double)this.placeRange.getValue()).doubleValue()); }  this.settings = new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue()); EntityPlayerSP entityPlayerSP = mc.player; if (((Boolean)this.self.getValue()).booleanValue()) entityPlayer2 = PredictUtil.predictPlayer((EntityLivingBase)entityPlayerSP, this.settings);  for (EntityLivingBase entity2 : entities) { EntityPlayer entityPlayer; if (entity2.getHealth() <= 0.0F || entity2.isDead) continue;  if (((Boolean)this.target.getValue()).booleanValue()) entityPlayer = PredictUtil.predictPlayer(entity2, this.settings);  BlockPos playerPos = new BlockPos(entityPlayer.getPositionVector()); Block web = mc.world.getBlockState(playerPos).getBlock(); if (web == Blocks.WEB) { setToAir = playerPos; state = mc.world.getBlockState(playerPos); mc.world.setBlockToAir(playerPos); }  BlockPos vec = new BlockPos(((EntityLivingBase)entityPlayer).posX, ((EntityLivingBase)entityPlayer).posY, ((EntityLivingBase)entityPlayer).posZ); Vec3d doubleTargetPos = new Vec3d((Vec3i)vec); List<BlockPos> legBlocks = findLegBlocks(doubleTargetPos); this.canPredictHit = (((!((Boolean)this.PredictHit.getValue()).booleanValue() || !entityPlayer.getHeldItemMainhand().getItem().equals(Items.EXPERIENCE_BOTTLE)) && !entityPlayer.getHeldItemOffhand().getItem().equals(Items.EXPERIENCE_BOTTLE)) || !ModuleManager.getModule("AutoMend").isEnabled()); legBlocks.addAll(default_blocks); for (BlockPos blockPos : legBlocks) { boolean shouldBase = (mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN); if ((shouldBase && (!this.canBase || blockPos.y >= (int)(((EntityLivingBase)entityPlayer).posY + 0.5D) || !(entityPlayer instanceof EntityPlayer) || BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1 || LemonClient.speedUtil.getPlayerSpeed(entityPlayer) > ((Double)this.maxSpeed.getValue()).doubleValue())) || intersectsWithEntity(blockPos.up()) || intersectsWithEntity(blockPos.up(2)) || blockPos.equals(vec) || entityPlayer.getDistanceSq(blockPos) >= (((Integer)this.enemyRange.getValue()).intValue() * ((Integer)this.enemyRange.getValue()).intValue()) || mc.player.getDistance(blockPos.getX(), blockPos.getY(), blockPos.getZ()) > ((Double)this.placeRange.getValue()).doubleValue() || (((Boolean)this.wall.getValue()).booleanValue() && PlayerUtil.getDistanceI(blockPos) > ((Double)this.placeWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace(blockPos))) continue;  double d = DamageUtil.calculateCrystalDamage((EntityLivingBase)entityPlayer, blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D); if (d < damage || (shouldBase && ((int)d == (int)damage || damage >= ((Integer)this.toggleDamage.getValue()).intValue() || d < ((Integer)this.baseMinDamage.getValue()).intValue()))) continue;  float healthTarget = entityPlayer.getHealth() + entityPlayer.getAbsorptionAmount(); float healthSelf = mc.player.getHealth() + mc.player.getAbsorptionAmount(); double self = DamageUtil.calculateCrystalDamage((EntityLivingBase)entityPlayer2, blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D); switch ((String)this.godMode.getValue()) { case "GodMode": self = 0.0D; break;case "Auto": if (mc.player.isCreative()) self = 0.0D;  break; }  if (d >= healthTarget) { if (self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= healthSelf && !((Boolean)this.forcePlace.getValue()).booleanValue()) continue;  } else if (d < (((Boolean)this.facePlace.getValue()).booleanValue() ? (canFacePlace((EntityLivingBase)entityPlayer) ? 1.0D : ((Double)this.minDamage.getValue()).doubleValue()) : ((Double)this.minDamage.getValue()).doubleValue()) || (self > d && d < healthTarget) || (self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= healthSelf) || (self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= ((Double)this.maxSelfDMG.getValue()).doubleValue())) { continue; }  damage = d; render = blockPos; entityPlayer1 = entityPlayer; }  if (setToAir != null) { mc.world.setBlockState(setToAir, state); this.webPos = render; }  if (entityPlayer1 != null) break;  }  if (entityPlayer1 == null) entityPlayer1 = PlayerUtil.getNearestPlayer(((Integer)this.enemyRange.getValue()).intValue());  if (entityPlayer1 != null && render == null && ((Boolean)this.MineDetect.getValue()).booleanValue()) { BlockPos instantPos = null; if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos;  if (instantPos != null) { BlockPos targetPos = EntityUtil.getEntityPos((Entity)entityPlayer1); for (EnumFacing facing : EnumFacing.HORIZONTALS) { BlockPos pos = targetPos.offset(facing); if (!BlockUtil.isAir(pos) && instantPos.x == pos.x && instantPos.y == pos.y && instantPos.z == pos.z) { BlockPos crystalPos = pos.offset(facing).down(); if (canPlaceCrystal(crystalPos) && !intersectsWithCrystal(crystalPos.up()) && !intersectsWithCrystal(crystalPos.up(2))) { render = crystalPos; damage = 0.0D; }  }  }  }  }  return new CrystalTarget(render, (Entity)entityPlayer1, damage); } private void switchOffhand(boolean value) { if (ModuleManager.isModuleEnabled(OffHand.class)) OffHand.INSTANCE.autoCrystal = value;  if (ModuleManager.isModuleEnabled(OffHandCat.class)) OffHandCat.INSTANCE.autoCrystal = value;  } private void pausePA(boolean value) { if (ModuleManager.isModuleEnabled(PistonAura.class)) PistonAura.INSTANCE.autoCrystal = value;  if (ModuleManager.isModuleEnabled(PullCrystal.class)) PullCrystal.INSTANCE.autoCrystal = value;  } private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof EntityEnderCrystal) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true;  }  return false; } private boolean intersectsWithCrystal(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true;  }  return false; } public List<EntityLivingBase> getEntities() { List<EntityLivingBase> entities = (List<EntityLivingBase>)mc.world.playerEntities.stream().filter(entity -> (mc.player.getDistance((Entity)entity) < ((Integer)this.enemyRange.getValue()).intValue())).filter(entity -> !EntityUtil.basicChecksEntity(entity)).sorted(Comparator.comparingDouble(entity -> entity.getDistance((Entity)mc.player))).collect(Collectors.toList()); if (entities.isEmpty()) for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof EntityLivingBase) || mc.player.getDistance(entity) > ((Integer)this.enemyRange.getValue()).intValue() || EntityUtil.isDead(entity)) continue;  if (((Boolean)this.monster.getValue()).booleanValue() && EntityUtil.isMobAggressive(entity)) entities.add((EntityLivingBase)entity);  if (((Boolean)this.neutral.getValue()).booleanValue() && EntityUtil.isNeutralMob(entity)) entities.add((EntityLivingBase)entity);  if (((Boolean)this.animal.getValue()).booleanValue() && EntityUtil.isPassive(entity)) entities.add((EntityLivingBase)entity);  }   return entities; } public void ExplodeCrystal(Entity crystal) { if (crystal != null) { if (this.ExplodeTimer.passedMs(((Integer)this.hitDelay.getValue()).intValue()) && mc.getConnection() != null) { PacketExplode(crystal.getEntityId()); EnumHand hand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND; if (((Boolean)this.swing.getValue()).booleanValue()) if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); } else { mc.player.swingArm(hand); }   mc.player.resetCooldown(); this.ExplodeTimer.reset(); }  if (this.lastBreakTime == 0L) this.lastBreakTime = System.currentTimeMillis();  }  } public void PacketExplode(int i) { if (this.lastCrystal != null && renderEnt != null) try { if (mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakRange.getValue()).doubleValue() || !canHitCrystal(this.lastCrystal)) return;  int slot = -1; if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS) && (!mc.player.isPotionActive(MobEffects.STRENGTH) || ((PotionEffect)Objects.requireNonNull((T)mc.player.getActivePotionEffect(MobEffects.STRENGTH))).getAmplifier() < 1)) for (int b = 0; b < (findInventory() ? 36 : 9); b++) { ItemStack stack = mc.player.inventory.getStackInSlot(b); if (stack != ItemStack.EMPTY) { if (stack.getItem() instanceof net.minecraft.item.ItemSword) { slot = b; break; }  if (stack.getItem() instanceof net.minecraft.item.ItemTool) { slot = b; break; }  }  }   switchTo(slot, ((Boolean)this.weakBypass.getValue()).booleanValue(), true, ((Boolean)this.packetWeak.getValue()).booleanValue(), () -> { CPacketUseEntity crystal = new CPacketUseEntity(); setEntityId(crystal, i); setAction(crystal, CPacketUseEntity.Action.ATTACK); mc.player.connection.sendPacket((Packet)crystal); if (((Boolean)this.packetOptimize.getValue()).booleanValue()) packetList.add(crystal);  }); } catch (Exception exception) {}  } public static void setEntityId(CPacketUseEntity packet, int entityId) { ((AccessorCPacketUseEntity)packet).setId(entityId); } public static void setAction(CPacketUseEntity packet, CPacketUseEntity.Action action) { ((AccessorCPacketUseEntity)packet).setAction(action); } public boolean canHitCrystal(EntityEnderCrystal crystal) { if (mc.player.getDistance((Entity)crystal) > ((Double)this.breakRange.getValue()).doubleValue()) return false;  float healthSelf = mc.player.getHealth() + mc.player.getAbsorptionAmount(); if (mc.player.isDead || healthSelf <= 0.0F) return false;  float selfDamage = DamageUtil.calculateCrystalDamage(((Boolean)this.self.getValue()).booleanValue() ? (EntityLivingBase)PredictUtil.predictPlayer((EntityLivingBase)mc.player, this.settings) : (EntityLivingBase)mc.player, crystal.posX, crystal.posY, crystal.posZ); switch ((String)this.godMode.getValue()) { case "GodMode": selfDamage = 0.0F; break;case "Auto": if (mc.player.isCreative()) selfDamage = 0.0F;  break; }  if (selfDamage != 0.0F && selfDamage + ((Double)this.balance.getValue()).doubleValue() >= healthSelf) return false;  if (this.render != null && ((new AxisAlignedBB(this.render)).intersects(crystal.getEntityBoundingBox()) || (new AxisAlignedBB(this.render.up())).intersects(crystal.getEntityBoundingBox()))) return true;  List<EntityPlayer> entities = (List<EntityPlayer>)mc.world.playerEntities.stream().filter(p -> !EntityUtil.basicChecksEntity(p)).sorted(Comparator.comparing(crystal::getDistance)).collect(Collectors.toList()); for (EntityPlayer player : entities) { double target = DamageUtil.calculateCrystalDamage((EntityLivingBase)player, crystal.posX, crystal.posY, crystal.posZ); if (target > (player.getHealth() + player.getAbsorptionAmount())) return true;  double minDamage = ((Integer)this.breakMinDmg.getValue()).intValue(); if (canFacePlace((EntityLivingBase)player)) minDamage = ((Double)this.fpMinDmg.getValue()).doubleValue();  if (target < minDamage || selfDamage > target) continue;  return true; }  return false; } public boolean canFacePlace(EntityLivingBase target) { float healthTarget = target.getHealth() + target.getAbsorptionAmount(); if (healthTarget <= ((Integer)this.BlastHealth.getValue()).intValue()) return true;  if (((Boolean)this.ArmorCheck.getValue()).booleanValue()) for (ItemStack itemStack : target.getArmorInventoryList()) { if (itemStack.isEmpty()) continue;  float dmg = (itemStack.getMaxDamage() - itemStack.getItemDamage()) / itemStack.getMaxDamage(); if (dmg <= ((Integer)this.ArmorRate.getValue()).intValue() / 100.0F) return true;  }   return false; } public static List<BlockPos> getSphere(Vec3d loc, double r, double h, boolean hollow, boolean sphere, int plus_y) { List<BlockPos> circleBlocks = new ArrayList<>(); int cx = (int)loc.x; int cy = (int)loc.y; int cz = (int)loc.z; for (int x = cx - (int)r; x <= cx + r; x++) { for (int z = cz - (int)r; z <= cz + r; ) { int y = sphere ? (cy - (int)r) : cy; for (;; z++) { if (y < (sphere ? (cy + r) : (cy + h))) { double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0)); if (dist < r * r && (!hollow || dist >= (r - 1.0D) * (r - 1.0D))) { BlockPos l = new BlockPos(x, y + plus_y, z); circleBlocks.add(l); }  y++; continue; }  }  }  }  return circleBlocks; } public List<BlockPos> renditions(double range) { NonNullList<BlockPos> positions = NonNullList.create(); positions.addAll((Collection)getSphere(getPlayerPos(), range, range, false, true, 0).stream().filter(this::canPlaceCrystal).collect(Collectors.toList())); return (List<BlockPos>)positions; } public static List<BlockPos> getLegVec(Vec3d add) { List<BlockPos> circleBlocks = new ArrayList<>(); BlockPos uwu = new BlockPos(add.x, add.y, add.z); circleBlocks.add(uwu); return circleBlocks; } private List<BlockPos> findLegBlocks(Vec3d targetPos) { NonNullList<BlockPos> positions = NonNullList.create(); positions.addAll((Collection)getLegVec(targetPos.add(0.0D, 0.0D, 0.0D)).stream().filter(this::canPlaceCrystal).collect(Collectors.toList())); return (List<BlockPos>)positions; } public Vec3d getPlayerPos() { return new Vec3d(mc.player.posX, mc.player.posY, mc.player.posZ); } public boolean canPlaceCrystal(BlockPos blockPos) { BlockPos boost = blockPos.add(0, 1, 0); BlockPos boost2 = blockPos.add(0, 2, 0); if (mc.world.getBlockState(boost).getBlock() == Blocks.WATER || mc.world.getBlockState(boost).getBlock() == Blocks.WATERLILY || mc.world.getBlockState(boost).getBlock() == Blocks.FLOWING_WATER || mc.world.getBlockState(boost).getBlock() == Blocks.MAGMA || mc.world.getBlockState(boost).getBlock() == Blocks.LAVA || mc.world.getBlockState(boost).getBlock() == Blocks.FLOWING_LAVA) return false;  if (mc.world.getBlockState(boost2).getBlock() == Blocks.WATER || mc.world.getBlockState(boost2).getBlock() == Blocks.WATERLILY || mc.world.getBlockState(boost2).getBlock() == Blocks.FLOWING_WATER || mc.world.getBlockState(boost2).getBlock() == Blocks.MAGMA || mc.world.getBlockState(boost2).getBlock() == Blocks.LAVA || mc.world.getBlockState(boost2).getBlock() == Blocks.FLOWING_LAVA) return false;  if (mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN) { if (!this.canBase) return false;  if (!mc.world.isAirBlock(blockPos) || !mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty()) return false;  if (BurrowUtil.getFirstFacing(blockPos) == null) return false;  }  if (((Boolean)this.highVersion.getValue()).booleanValue()) { if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR) return false;  } else if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR || mc.world.getBlockState(boost2).getBlock() != Blocks.AIR) { return false; }  for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost))) { if (!(entity instanceof EntityEnderCrystal)) return false;  }  for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2))) { if (!(entity instanceof EntityEnderCrystal)) return false;  }  webCalc(); if (((Boolean)this.multiPlace.getValue()).booleanValue()) return ((mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && mc.world.getBlockState(boost).getBlock() == Blocks.AIR && mc.world.getBlockState(boost2).getBlock() == Blocks.AIR && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty());  if (this.afterAttacking) for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof EntityEnderCrystal)) continue;  EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)entity; if (Math.abs(entityEnderCrystal.posY - (blockPos.getY() + 1)) >= 2.0D) continue;  double d2 = (this.lastCrystal != null) ? this.lastCrystal.getDistance(blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D) : 10000.0D; if (d2 <= 6.0D || getRange(entityEnderCrystal.getPositionVector(), blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D) >= 2.0D) continue;  return false; }   return true; } public void webCalc() { if (this.webPos != null) if (mc.player.getDistanceSq(this.webPos) > MathUtil.square((Double)this.breakRange.getValue())) { this.webPos = null; } else { for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(this.webPos))) { if (entity instanceof EntityEnderCrystal) { this.webPos = null; break; }  }  }   } private int getItemHotbar() { for (int i = 0; i < (findInventory() ? 36 : 9); ) { Item item = mc.player.inventory.getStackInSlot(i).getItem(); if (Item.getIdFromItem(item) != Item.getIdFromItem(Items.END_CRYSTAL)) { i++; continue; }  return i; }  return -1; } public void onEnable() { this.lastBreakTime = System.currentTimeMillis(); this.lastEntityID = -1; this.crystals = this.c = 0; this.size = 0.0D; this.ShouldInfoLastBreak = false; this.afterAttacking = false; this.canPredictHit = true; this.PlaceTimer.reset(); this.ExplodeTimer.reset(); this.PacketExplodeTimer.reset(); this.UpdateTimer.reset(); this.CalcTimer.reset(); packetList.clear(); this.timer = new Timing(); if (((Boolean)this.reset.getValue()).booleanValue()) { this.lastBestPlace = null; this.managerRenderBlocks.blocks.clear(); }  } public void onDisable() { switchOffhand(false); pausePA(false); this.lastHitVec = null; renderEnt = null; this.render = null; this.StuckTimes = 0; packetList.clear(); if (((Boolean)this.reset.getValue()).booleanValue()) { this.lastBestPlace = null; this.managerRenderBlocks.blocks.clear(); }  } private boolean findInventory() { return (((Boolean)this.bypass.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue()); } public static class CrystalTarget
/*      */   {
/* 1053 */     public BlockPos blockPos; public Entity target; public double dmg; public CrystalTarget(BlockPos block, Entity target, double dmg) { this.blockPos = block;
/* 1054 */       this.target = target;
/* 1055 */       this.dmg = dmg; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void onWorldRender(RenderEvent event) {
/* 1061 */     if (mc.world == null || mc.player == null) {
/*      */       return;
/*      */     }
/* 1064 */     if (this.render != null) {
/* 1065 */       this.blockPos = this.render;
/* 1066 */       if (((Boolean)this.move.getValue()).booleanValue()) { this.lastBestPlace = this.render; }
/* 1067 */       else { drawBoxMain(this.blockPos.x, this.blockPos.y, this.blockPos.z); }
/* 1068 */        if (((Boolean)this.fade.getValue()).booleanValue()) this.managerRenderBlocks.addRender(this.render);
/*      */     
/*      */     } 
/* 1071 */     this.managerRenderBlocks.render();
/*      */     
/* 1073 */     if (!((Boolean)this.move.getValue()).booleanValue())
/* 1074 */       return;  if (this.lastBestPlace != null) {
/* 1075 */       if (this.movingPlaceNow.x == -1.0D && this.movingPlaceNow.y == -1.0D && this.movingPlaceNow.z == -1.0D) {
/* 1076 */         this.movingPlaceNow = new Vec3d(this.lastBestPlace.getX(), this.lastBestPlace.getY(), this.lastBestPlace.getZ());
/*      */       }
/*      */       
/* 1079 */       this
/*      */ 
/*      */         
/* 1082 */         .movingPlaceNow = new Vec3d(this.movingPlaceNow.x + (this.lastBestPlace.getX() - this.movingPlaceNow.x) * ((Double)this.movingSpeed.getValue()).floatValue(), this.movingPlaceNow.y + (this.lastBestPlace.getY() - this.movingPlaceNow.y) * ((Double)this.movingSpeed.getValue()).floatValue(), this.movingPlaceNow.z + (this.lastBestPlace.getZ() - this.movingPlaceNow.z) * ((Double)this.movingSpeed.getValue()).floatValue());
/*      */ 
/*      */ 
/*      */       
/* 1086 */       if (Math.abs(this.movingPlaceNow.x - this.lastBestPlace.getX()) <= 0.125D && Math.abs(this.movingPlaceNow.y - this.lastBestPlace.getY()) <= 0.125D && Math.abs(this.movingPlaceNow.z - this.lastBestPlace.getZ()) <= 0.125D) {
/* 1087 */         this.lastBestPlace = null;
/*      */       }
/*      */     } 
/*      */     
/* 1091 */     if (this.movingPlaceNow.x != -1.0D && this.movingPlaceNow.y != -1.0D && this.movingPlaceNow.z != -1.0D) drawBoxMain(this.movingPlaceNow.x, this.movingPlaceNow.y, this.movingPlaceNow.z);
/*      */   
/*      */   }
/*      */   
/*      */   AxisAlignedBB getBox(double x, double y, double z) {
/* 1096 */     double maxX = x + 1.0D;
/* 1097 */     double maxZ = z + 1.0D;
/*      */     
/* 1099 */     return new AxisAlignedBB(x, y, z, maxX, y + 1.0D, maxZ);
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z) {
/* 1103 */     AxisAlignedBB box = getBox(x, y, z);
/*      */     
/* 1105 */     if (((Boolean)this.scale.getValue()).booleanValue() && this.scale.isVisible())
/* 1106 */     { if (renderEnt == null || this.render == null || Math.abs(x - this.render.x) > 0.5D || Math.abs(z - this.render.z) > 0.5D)
/* 1107 */       { this.size -= ((Double)this.reduceSpeed.getValue()).doubleValue(); }
/* 1108 */       else if (this.size != 1.0D) { this.size += ((Double)this.growSpeed.getValue()).doubleValue(); }
/* 1109 */        if (this.size > 1.0D) this.size = 1.0D; 
/* 1110 */       if (this.size < 0.0D) this.size = 0.0D;
/*      */       
/* 1112 */       if ((renderEnt == null || this.render == null) && 
/* 1113 */         this.size == 0.0D) this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*      */       
/* 1115 */       box = box.grow((1.0D - this.size) * (1.0D - this.size) / 2.0D - 1.0D); }
/* 1116 */     else if (renderEnt == null || this.render == null) { this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D); }
/*      */     
/* 1118 */     if (((Boolean)this.flat.getValue()).booleanValue()) box = new AxisAlignedBB(box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ);
/*      */     
/* 1120 */     switch ((String)this.mode.getValue()) {
/*      */       case "Outline":
/* 1122 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */         break;
/*      */       
/*      */       case "Solid":
/* 1126 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/*      */         break;
/*      */       
/*      */       case "Both":
/* 1130 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/* 1131 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1136 */     if (((Boolean)this.showDamage.getValue()).booleanValue()) {
/* 1137 */       box = getBox(x, y, z);
/* 1138 */       String[] damageText = { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) };
/* 1139 */       RenderUtil.drawNametag(box.minX + 0.5D, box.minY + 0.5D, box.minZ + 0.5D, damageText, new GSColor(255, 255, 255), 1, 0.02666666666666667D, 0.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z, double percent) {
/* 1144 */     int alpha = (int)(((Integer)this.fadeAlpha.getValue()).intValue() * percent);
/* 1145 */     int outAlpha = (int)(((Integer)this.fadeOutAlpha.getValue()).intValue() * percent);
/* 1146 */     AxisAlignedBB box = getBox(x, y, z);
/*      */     
/* 1148 */     if (((Boolean)this.scale.getValue()).booleanValue() && this.scale.isVisible()) {
/* 1149 */       box = box.grow((1.0D - percent) * (1.0D - percent) / 2.0D - 1.0D);
/*      */     }
/*      */     
/* 1152 */     if (((Boolean)this.flat.getValue()).booleanValue()) box = new AxisAlignedBB(box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ);
/*      */     
/* 1154 */     switch ((String)this.mode.getValue()) {
/*      */       case "Outline":
/* 1156 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), outAlpha));
/*      */         break;
/*      */       
/*      */       case "Solid":
/* 1160 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), alpha), 63);
/*      */         break;
/*      */       
/*      */       case "Both":
/* 1164 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), alpha), 63);
/* 1165 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), outAlpha));
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean sameBlockPos(BlockPos first, BlockPos second) {
/* 1171 */     if (first == null || second == null)
/* 1172 */       return false; 
/* 1173 */     return (first.getX() == second.getX() && first.getY() == second.getY() && first.getZ() == second.getZ());
/*      */   }
/*      */   
/*      */   class managerClassRenderBlocks {
/* 1177 */     ArrayList<LemonAura.renderBlock> blocks = new ArrayList<>();
/*      */     void update(int time) {
/* 1179 */       this.blocks.removeIf(e -> (System.currentTimeMillis() - e.start > time));
/*      */     }
/*      */     
/*      */     void render()
/*      */     {
/* 1184 */       this.blocks.forEach(e -> {
/*      */             if (LemonAura.this.render != null && LemonAura.this.sameBlockPos(e.pos, LemonAura.this.render)) {
/*      */               e.resetTime();
/*      */             } else {
/*      */               e.render();
/*      */             } 
/*      */           }); } void addRender(BlockPos pos) {
/* 1191 */       boolean render = true;
/* 1192 */       for (LemonAura.renderBlock block : this.blocks) {
/* 1193 */         if (LemonAura.this.sameBlockPos(block.pos, pos)) {
/* 1194 */           render = false;
/* 1195 */           block.resetTime(); break;
/*      */         } 
/*      */       } 
/* 1198 */       if (render)
/* 1199 */         this.blocks.add(new LemonAura.renderBlock(pos)); 
/*      */     }
/*      */   }
/*      */   
/*      */   class renderBlock
/*      */   {
/*      */     private final BlockPos pos;
/*      */     private long start;
/*      */     
/*      */     public renderBlock(BlockPos pos) {
/* 1209 */       this.start = System.currentTimeMillis();
/* 1210 */       this.pos = pos;
/*      */     }
/*      */ 
/*      */     
/*      */     void resetTime() {
/* 1215 */       this.start = System.currentTimeMillis();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void render() {
/* 1221 */       LemonAura.this.drawBoxMain(this.pos.x, this.pos.y, this.pos.z, percent());
/*      */     }
/*      */ 
/*      */     
/*      */     public double percent() {
/* 1226 */       long end = this.start + ((Integer)LemonAura.this.lifeTime.getValue()).intValue();
/* 1227 */       double result = (end - System.currentTimeMillis()) / (end - this.start);
/* 1228 */       if (result < 0.0D) result = 0.0D; 
/* 1229 */       if (result > 1.0D) result = 1.0D; 
/* 1230 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\LemonAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
