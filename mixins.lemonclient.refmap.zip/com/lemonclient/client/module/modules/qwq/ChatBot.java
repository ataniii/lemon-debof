//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.qwq;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.misc.ServerUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.network.NetworkPlayerInfo;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ 
/*     */ @Declaration(name = "ChatBot", category = Category.qwq)
/*     */ public class ChatBot extends Module {
/*     */   ModeSetting mode;
/*     */   IntegerSetting delay;
/*     */   String botmessage;
/*     */   boolean msg;
/*     */   int waited;
/*     */   private final Pattern CHAT_PATTERN;
/*     */   private final Pattern CHAT_PATTERN2;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   
/*     */   public ChatBot() {
/*  27 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Client", "Everyone" }, ), "Everyone");
/*  28 */     this.delay = registerInteger("Delay", 0, 0, 20, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Everyone")));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  33 */     this.CHAT_PATTERN = Pattern.compile("<.*?> ");
/*  34 */     this.CHAT_PATTERN2 = Pattern.compile("(.*?)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     this.receiveListener = new Listener(event -> { if (this.msg) return;  if (event.getPacket() instanceof SPacketChat) { String s = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText(); Matcher matcher = this.CHAT_PATTERN.matcher(s); String username = "unnamed"; Matcher matcher2 = this.CHAT_PATTERN2.matcher(s); if (matcher2.find()) { matcher2.group(); s = matcher2.replaceFirst(""); }  if (matcher.find()) { username = matcher.group(); username = username.substring(1, username.length() - 2); s = matcher.replaceFirst(""); }  if (!s.startsWith("!")) return;  s = s.substring(Math.min(s.length(), 1)); if (s.startsWith("online")) return;  if (s.startsWith("ping")) { s = s.substring(Math.min(s.length(), 5)); ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(Minecraft.getMinecraft().getConnection().getPlayerInfoMap()); for (Entity qwq : mc.world.loadedEntityList) { if (qwq instanceof net.minecraft.entity.player.EntityPlayer && s.contains(qwq.getName())) s = qwq.getName();  }  String finalS = s; NetworkPlayerInfo profile = infoMap.stream().filter(()).findFirst().orElse(null); if (profile != null) { String message = profile.getGameProfile().getName() + "'s ping is " + profile.getResponseTime(); String messageSanitized = message.replaceAll("禮", ""); if (messageSanitized.length() > 255) messageSanitized = messageSanitized.substring(0, 255);  this.botmessage = messageSanitized; this.msg = true; }  } else if (s.startsWith("myping")) { ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(Minecraft.getMinecraft().getConnection().getPlayerInfoMap()); String finalUsername = username; NetworkPlayerInfo profile = infoMap.stream().filter(()).findFirst().orElse(null); if (profile != null) { String message = "Your ping is " + profile.getResponseTime(); String messageSanitized = message.replaceAll("禮", ""); if (messageSanitized.length() > 255) messageSanitized = messageSanitized.substring(0, 255);  this.botmessage = messageSanitized; this.msg = true; }  } else if (s.startsWith("tps")) { String message = "The tps is now " + ServerUtil.getTPS(); String messageSanitized = message.replaceAll("禮", ""); if (messageSanitized.length() > 255) messageSanitized = messageSanitized.substring(0, 255);  this.botmessage = messageSanitized; this.msg = true; } else if (s.startsWith("help")) { String uwu = "The commands are : tps, myping, ping playername"; String messageSanitized = uwu.replaceAll("禮", ""); if (messageSanitized.length() > 255) messageSanitized = messageSanitized.substring(0, 255);  this.botmessage = messageSanitized; this.msg = true; } else if (s.startsWith("gay")) { s = s.substring(Math.min(s.length(), 4)); ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(Minecraft.getMinecraft().getConnection().getPlayerInfoMap()); for (Entity qwq : mc.world.loadedEntityList) { if (qwq instanceof net.minecraft.entity.player.EntityPlayer && s.contains(qwq.getName())) s = qwq.getName();  }  String finalS = s; NetworkPlayerInfo profile = infoMap.stream().filter(()).findFirst().orElse(null); if (profile != null) { String name = profile.getGameProfile().getName(); this.botmessage = name + " is " + String.format("%.1f", new Object[] { Double.valueOf(Math.random() * 100.0D) }) + "% gay"; this.msg = true; }  } else if (s.startsWith("byebyebot")) { this.botmessage = "!online owob"; this.msg = true; } else { String uwu = "Sorry, I cant understand this command"; String messageSanitized = uwu.replaceAll("禮", ""); if (messageSanitized.length() > 255) messageSanitized = messageSanitized.substring(0, 255);  this.botmessage = messageSanitized; this.msg = true; }  }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*     */     if (this.msg)
/*     */       if (((String)this.mode.getValue()).equals("Client")) {
/*     */         MessageBus.sendClientDeleteMessage(this.botmessage, Notification.Type.INFO, "ChatBot", 4);
/*     */         this.msg = false;
/*     */       } else if (this.waited++ >= ((Integer)this.delay.getValue()).intValue()) {
/*     */         MessageBus.sendServerMessage(this.botmessage);
/*     */         this.waited = 0;
/*     */         this.msg = false;
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\ChatBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
