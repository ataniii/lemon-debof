//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*      */ package com.lemonclient.client.module.modules.qwq;
/*      */ import com.lemonclient.api.setting.values.BooleanSetting;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ 
/*      */ @Declaration(name = "FacePlace", category = Category.qwq, priority = 999)
/*      */ public class FacePlace extends Module {
/*      */   public static Entity renderEnt;
/*      */   ModeSetting p;
/*      */   ModeSetting logic;
/*      */   IntegerSetting updateDelay;
/*      */   BooleanSetting place;
/*      */   BooleanSetting calc;
/*      */   BooleanSetting y256;
/*      */   IntegerSetting placeDelay;
/*      */   BooleanSetting explode;
/*      */   IntegerSetting hitDelay;
/*      */   BooleanSetting antiWeakness;
/*      */   BooleanSetting silentAntiWeak;
/*      */   BooleanSetting weakBypass;
/*      */   BooleanSetting packetWeak;
/*      */   BooleanSetting wall;
/*      */   BooleanSetting wallAI;
/*      */   IntegerSetting enemyRange;
/*      */   DoubleSetting placeRange;
/*      */   DoubleSetting placeWallRange;
/*      */   DoubleSetting breakRange;
/*      */   IntegerSetting breakMinDmg;
/*      */   DoubleSetting breakWallRange;
/*      */   DoubleSetting minDamage;
/*      */   DoubleSetting maxDamage;
/*      */   ModeSetting godMode;
/*      */   BooleanSetting forcePlace;
/*      */   DoubleSetting maxSelfDMG;
/*      */   DoubleSetting balance;
/*      */   ModeSetting switchMode;
/*      */   BooleanSetting offhand;
/*      */   BooleanSetting switchBack;
/*      */   BooleanSetting bypass;
/*      */   DoubleSetting switchSpeed;
/*      */   BooleanSetting forceUpdate;
/*      */   BooleanSetting packetSwitch;
/*      */   BooleanSetting packet;
/*      */   BooleanSetting rotate;
/*      */   BooleanSetting placeRotate;
/*      */   BooleanSetting swing;
/*      */   BooleanSetting packetSwing;
/*      */   BooleanSetting crystalCheck;
/*      */   BooleanSetting highVersion;
/*      */   BooleanSetting PacketExplode;
/*      */   IntegerSetting PacketExplodeDelay;
/*      */   BooleanSetting ClientSide;
/*      */   BooleanSetting PredictHit;
/*      */   IntegerSetting PredictHitFactor;
/*      */   BooleanSetting target;
/*      */   BooleanSetting self;
/*      */   IntegerSetting tickPredict;
/*      */   BooleanSetting calculateYPredict;
/*      */   IntegerSetting startDecrease;
/*      */   IntegerSetting exponentStartDecrease;
/*      */   IntegerSetting decreaseY;
/*      */   IntegerSetting exponentDecreaseY;
/*      */   
/*      */   public FacePlace() {
/*   67 */     this.p = registerMode("Page", Arrays.asList(new String[] { "General", "Combat", "Predict", "Dev", "Render" }, ), "General");
/*      */ 
/*      */     
/*   70 */     this.logic = registerMode("Logic", Arrays.asList(new String[] { "PlaceBreak", "BreakPlace" }, ), "BreakPlace", () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   71 */     this.updateDelay = registerInteger("UpdateDelay", 25, 0, 1000, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   72 */     this.place = registerBoolean("Place", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   73 */     this.calc = registerBoolean("CalcHitVec", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   74 */     this.y256 = registerBoolean("Y256", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   75 */     this.placeDelay = registerInteger("PlaceDelay", 25, 0, 1000, () -> Boolean.valueOf((((Boolean)this.place.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   76 */     this.explode = registerBoolean("Explode", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   77 */     this.hitDelay = registerInteger("HitDelay", 25, 0, 1000, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   78 */     this.antiWeakness = registerBoolean("AntiWeakness", false, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   79 */     this.silentAntiWeak = registerBoolean("SilentAntiWeakness", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   80 */     this.weakBypass = registerBoolean("BypassSilent", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((Boolean)this.silentAntiWeak.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   81 */     this.packetWeak = registerBoolean("PacketSwitch", false, () -> Boolean.valueOf((((Boolean)this.antiWeakness.getValue()).booleanValue() && ((Boolean)this.silentAntiWeak.getValue()).booleanValue() && !((Boolean)this.weakBypass.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   82 */     this.wall = registerBoolean("Wall", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   83 */     this.wallAI = registerBoolean("WallAI", true, () -> Boolean.valueOf((((Boolean)this.wall.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   84 */     this.enemyRange = registerInteger("EnemyRange", 7, 1, 16, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   85 */     this.placeRange = registerDouble("PlaceRange", 5.5D, 0.0D, 6.0D, () -> Boolean.valueOf((((Boolean)this.place.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   86 */     this.placeWallRange = registerDouble("PlaceWallRange", 3.0D, 0.1D, 6.0D, () -> Boolean.valueOf((!((Boolean)this.wallAI.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   87 */     this.breakRange = registerDouble("BreakRange", 5.5D, 0.0D, 6.0D, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   88 */     this.breakMinDmg = registerInteger("BreakMinDmg", 2, 0, 36, () -> Boolean.valueOf((((Boolean)this.explode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("General"))));
/*   89 */     this.breakWallRange = registerDouble("BreakWallRange", 3.0D, 0.1D, 6.0D, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   90 */     this.minDamage = registerDouble("MinDmg", 4.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   91 */     this.maxDamage = registerDouble("MaxDmg", 12.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   92 */     this.godMode = registerMode("SelfDamage", Arrays.asList(new String[] { "Auto", "GodMode", "NoGodMode" }, ), "Auto", () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   93 */     this.forcePlace = registerBoolean("ForcePlace", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("General")));
/*   94 */     this.maxSelfDMG = registerDouble("MaxSelfDmg", 12.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && !((String)this.godMode.getValue()).equals("GodMode"))));
/*   95 */     this.balance = registerDouble("HealthBalance", 1.5D, 0.0D, 10.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("General") && !((String)this.godMode.getValue()).equals("GodMode"))));
/*      */ 
/*      */     
/*   98 */     this.switchMode = registerMode("SwitchMode", Arrays.asList(new String[] { "AutoSwitch", "Off" }, ), "Off", () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*   99 */     this.offhand = registerBoolean("Offhand", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch"))));
/*  100 */     this.switchBack = registerBoolean("SwitchBack", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue())));
/*  101 */     this.bypass = registerBoolean("Bypass", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue())));
/*  102 */     this.switchSpeed = registerDouble("SwitchSpeed", 10.0D, 0.1D, 20.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((String)this.switchMode.getValue()).equals("AutoSwitch") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue() && ((Boolean)this.bypass.getValue()).booleanValue())));
/*  103 */     this.forceUpdate = registerBoolean("ForceUpdate", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue() && ((Boolean)this.bypass.getValue()).booleanValue())));
/*  104 */     this.packetSwitch = registerBoolean("PacketSwitch", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && !((Boolean)this.offhand.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue())));
/*  105 */     this.packet = registerBoolean("PacketCrystal", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  106 */     this.rotate = registerBoolean("Rotate", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  107 */     this.placeRotate = registerBoolean("PlaceRotate", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.rotate.getValue()).booleanValue())));
/*  108 */     this.swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  109 */     this.packetSwing = registerBoolean("PacketSwing", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Combat") && ((Boolean)this.swing.getValue()).booleanValue())));
/*  110 */     this.crystalCheck = registerBoolean("CrystalCheck", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  111 */     this.highVersion = registerBoolean("1.13Place", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  112 */     this.PacketExplode = registerBoolean("PacketExplode", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  113 */     this.PacketExplodeDelay = registerInteger("PacketExplodeDelay", 45, 0, 500, () -> Boolean.valueOf((((Boolean)this.PacketExplode.getValue()).booleanValue() && ((String)this.p.getValue()).equals("Combat"))));
/*  114 */     this.ClientSide = registerBoolean("ClientSide", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  115 */     this.PredictHit = registerBoolean("PredictHit", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Combat")));
/*  116 */     this.PredictHitFactor = registerInteger("PredictHitFactor", 2, 1, 20, () -> Boolean.valueOf((((Boolean)this.PredictHit.getValue()).booleanValue() && ((String)this.p.getValue()).equals("Combat"))));
/*      */ 
/*      */     
/*  119 */     this.target = registerBoolean("Target", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  120 */     this.self = registerBoolean("Self", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  121 */     this.tickPredict = registerInteger("TickPredict", 8, 0, 30, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  122 */     this.calculateYPredict = registerBoolean("CalculateYPredict", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  123 */     this.startDecrease = registerInteger("StartDecrease", 39, 0, 200, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  124 */     this.exponentStartDecrease = registerInteger("ExponentStart", 2, 1, 5, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  125 */     this.decreaseY = registerInteger("DecreaseY", 2, 1, 5, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  126 */     this.exponentDecreaseY = registerInteger("ExponentDecreaseY", 1, 1, 3, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  127 */     this.splitXZ = registerBoolean("SplitXZ", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  128 */     this.manualOutHole = registerBoolean("ManualOutHole", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  129 */     this.aboveHoleManual = registerBoolean("AboveHoleManual", false, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.manualOutHole.getValue()).booleanValue())));
/*  130 */     this.stairPredict = registerBoolean("StairPredict", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Predict")));
/*  131 */     this.nStair = registerInteger("NStair", 2, 1, 4, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*  132 */     this.speedActivationStair = registerDouble("SpeedActivationStair", 0.11D, 0.0D, 1.0D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Predict") && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*      */ 
/*      */     
/*  135 */     this.onlyInHole = registerBoolean("InHole Only", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  136 */     this.sword = registerBoolean("Pause While Swording", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  137 */     this.pause = registerBoolean("PausePistonAura", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*  138 */     this.eat = registerBoolean("WhileEating", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Dev")));
/*      */ 
/*      */     
/*  141 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "Solid", "Both", "Outline" }, ), "Full", () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  142 */     this.showDamage = registerBoolean("ShowDamage", false, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  143 */     this.flat = registerBoolean("Flat", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  144 */     this.color = registerColor("Color", new GSColor(255, 255, 255), () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  145 */     this.alpha = registerInteger("Alpha", 50, 0, 255, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  146 */     this.outAlpha = registerInteger("OutlineAlpha", 125, 0, 255, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  147 */     this.move = registerBoolean("Move", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  148 */     this.movingSpeed = registerDouble("MovingSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.move.getValue()).booleanValue())));
/*  149 */     this.reset = registerBoolean("Reset", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.move.getValue()).booleanValue())));
/*  150 */     this.fade = registerBoolean("Fade", true, () -> Boolean.valueOf(((String)this.p.getValue()).equals("Render")));
/*  151 */     this.fadeAlpha = registerInteger("FadeAlpha", 50, 0, 255, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  152 */     this.fadeOutAlpha = registerInteger("FadeOutlineAlpha", 125, 0, 255, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  153 */     this.lifeTime = registerInteger("LifeTime", 3000, 0, 5000, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  154 */     this.scale = registerBoolean("BoxScale", true, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && (((Boolean)this.move.getValue()).booleanValue() || ((Boolean)this.fade.getValue()).booleanValue()))));
/*  155 */     this.growSpeed = registerDouble("BoxGrowSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && this.scale.isVisible() && ((Boolean)this.scale.getValue()).booleanValue())));
/*  156 */     this.reduceSpeed = registerDouble("BoxReduceSpeed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.p.getValue()).equals("Render") && this.scale.isVisible() && ((Boolean)this.scale.getValue()).booleanValue())));
/*  157 */     this.managerRenderBlocks = new managerClassRenderBlocks();
/*      */     
/*  159 */     this.shorts = new ArrayList<>();
/*  160 */     this.PacketExplodeTimer = new Timing();
/*  161 */     this.ExplodeTimer = new Timing();
/*  162 */     this.UpdateTimer = new Timing();
/*  163 */     this.PlaceTimer = new Timing();
/*  164 */     this.CalcTimer = new Timing();
/*      */     
/*  166 */     this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  167 */     this.lastBestPlace = null;
/*      */ 
/*      */     
/*  170 */     this.ShouldInfoLastBreak = false;
/*  171 */     this.afterAttacking = false;
/*  172 */     this.canPredictHit = false;
/*      */     
/*  174 */     this.lastEntityID = -1;
/*  175 */     this.placements = 0;
/*  176 */     this.StuckTimes = 0;
/*      */     
/*  178 */     this.size = -1.0D;
/*      */ 
/*      */     
/*  181 */     this.timer = new Timing();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  233 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (event.getPhase() != Phase.PRE || this.lastHitVec == null || !((Boolean)this.rotate.getValue()).booleanValue()) return;  PlayerPacket packet = new PlayerPacket(this, RotationUtil.getRotationTo(this.lastHitVec)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  240 */     this.sendListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (((Boolean)this.rotate.getValue()).booleanValue() && this.lastHitVec != null) { Vec2f vec = RotationUtil.getRotationTo(this.lastHitVec); if (event.getPacket() instanceof CPacketPlayer.Rotation) { ((CPacketPlayer.Rotation)event.getPacket()).yaw = vec.x; ((CPacketPlayer.Rotation)event.getPacket()).pitch = vec.y; }  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) { ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = vec.x; ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = vec.y; }  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  258 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof SPacketSpawnObject) { SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket(); if (((Boolean)this.PredictHit.getValue()).booleanValue()) for (Entity e : mc.world.loadedEntityList) { if ((e instanceof net.minecraft.entity.item.EntityItem || e instanceof net.minecraft.entity.projectile.EntityArrow || e instanceof net.minecraft.entity.item.EntityEnderPearl || e instanceof net.minecraft.entity.projectile.EntitySnowball || e instanceof net.minecraft.entity.projectile.EntityEgg) && e.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= 6.0D) { this.lastEntityID = -1; this.canPredictHit = false; event.cancel(); }  }   if (packet.getType() == 51) { this.lastEntityID = packet.getEntityID(); EntityEnderCrystal crystal = (EntityEnderCrystal)mc.world.getEntityByID(this.lastEntityID); if (crystal != null && ((Boolean)this.PacketExplode.getValue()).booleanValue() && this.PacketExplodeTimer.passedMs(((Integer)this.PacketExplodeDelay.getValue()).intValue()) && ((Boolean)this.explode.getValue()).booleanValue() && this.lastCrystal != null && renderEnt != null) { if (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal)) return;  if (canHitCrystal(crystal)) { PacketExplode(this.lastEntityID); this.PacketExplodeTimer.reset(); }  }  }  }  if (event.getPacket() instanceof SPacketSoundEffect) { SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket(); if (packet.getSound().equals(SoundEvents.ENTITY_EXPERIENCE_BOTTLE_THROW) || packet.getSound().equals(SoundEvents.ENTITY_ITEM_BREAK)) this.canPredictHit = false;  if (packet.getSound().equals(SoundEvents.ITEM_TOTEM_USE)) for (EntityPlayer entity : mc.world.playerEntities) renderEnt = (Entity)entity;   if (packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE && this.render != null) { this.ShouldInfoLastBreak = true; for (Entity e : new ArrayList(mc.world.loadedEntityList)) { if (e instanceof EntityEnderCrystal && e.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= 6.0D) e.setDead();  }  }  }  }new java.util.function.Predicate[0]);
/*      */   } BooleanSetting splitXZ; BooleanSetting manualOutHole; BooleanSetting aboveHoleManual; BooleanSetting stairPredict; IntegerSetting nStair; DoubleSetting speedActivationStair; BooleanSetting onlyInHole; BooleanSetting sword; BooleanSetting pause; BooleanSetting eat; ModeSetting mode; BooleanSetting showDamage; BooleanSetting flat; ColorSetting color; IntegerSetting alpha; IntegerSetting outAlpha; BooleanSetting move; DoubleSetting movingSpeed; BooleanSetting reset; BooleanSetting fade; IntegerSetting fadeAlpha; IntegerSetting fadeOutAlpha; IntegerSetting lifeTime; BooleanSetting scale; DoubleSetting growSpeed; DoubleSetting reduceSpeed; managerClassRenderBlocks managerRenderBlocks; PredictUtil.PredictSettings settings; List<Short> shorts; Timing PacketExplodeTimer; Timing ExplodeTimer; Timing UpdateTimer; Timing PlaceTimer; Timing CalcTimer; EntityEnderCrystal lastCrystal; Vec3d movingPlaceNow; BlockPos lastBestPlace; BlockPos render; BlockPos webPos; boolean ShouldInfoLastBreak; boolean afterAttacking; boolean canPredictHit; boolean calculated; int lastEntityID; int placements; int StuckTimes; int crystalSlot; double size; float damage; Vec3d lastHitVec; Timing timer; @EventHandler
/*      */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener; @EventHandler
/*      */   private final Listener<PacketEvent.Send> sendListener; @EventHandler
/*      */   private final Listener<PacketEvent.Receive> receiveListener; boolean tryCalc; BlockPos blockPos; public void windowClick(int windowId, int slotId, int mouseButton, ClickType type, ItemStack itemstack, EntityPlayer player, short id) {
/*      */     player.openContainer.slotClick(slotId, mouseButton, type, player);
/*      */   }
/*      */   private void switchTo(int slot, boolean bypass, boolean shouldSwitch, boolean back, Runnable runnable) {
/*      */     int oldslot = mc.player.inventory.currentItem;
/*      */     if (!shouldSwitch || slot < 0 || slot == oldslot) {
/*      */       runnable.run();
/*      */       return;
/*      */     } 
/*      */     if (bypass) {
/*      */       if (this.timer.passedMs((long)(1000.0D / ((Double)this.switchSpeed.getValue()).doubleValue()))) {
/*      */         this.timer.reset();
/*      */         if (slot < 9)
/*      */           slot += 36; 
/*      */         short id = mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory);
/*      */         this.shorts.add(Short.valueOf(id));
/*      */         if (!((Boolean)this.packetSwitch.getValue()).booleanValue())
/*      */           windowClick(0, slot, oldslot, ClickType.SWAP, ItemStack.EMPTY, (EntityPlayer)mc.player, id); 
/*      */         mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, oldslot, ClickType.SWAP, ItemStack.EMPTY, id));
/*      */         runnable.run();
/*      */         mc.player.openContainer.detectAndSendChanges();
/*      */         id = mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory);
/*      */         this.shorts.add(Short.valueOf(id));
/*      */         if (!((Boolean)this.packetSwitch.getValue()).booleanValue())
/*      */           windowClick(0, slot, oldslot, ClickType.SWAP, Items.END_CRYSTAL.getDefaultInstance(), (EntityPlayer)mc.player, id); 
/*      */         mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, oldslot, ClickType.SWAP, ((Boolean)this.forceUpdate.getValue()).booleanValue() ? Items.END_CRYSTAL.getDefaultInstance() : ItemStack.EMPTY, id));
/*      */         mc.player.openContainer.detectAndSendChanges();
/*      */       } 
/*      */     } else if (slot < 9) {
/*      */       boolean packetSwitch = (back && ((Boolean)this.packetSwitch.getValue()).booleanValue());
/*      */       if (packetSwitch) {
/*      */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*      */       } else {
/*      */         mc.player.inventory.currentItem = slot;
/*      */       } 
/*      */       runnable.run();
/*      */       if (back)
/*      */         if (packetSwitch) {
/*      */           mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot));
/*      */         } else {
/*      */           mc.player.inventory.currentItem = oldslot;
/*      */         }  
/*      */     } 
/*      */   }
/*      */   public static double getRange(Vec3d a, double x, double y, double z) {
/*      */     double xl = a.x - x;
/*      */     double yl = a.y - y;
/*      */     double zl = a.z - z;
/*      */     return Math.sqrt(xl * xl + yl * yl + zl * zl);
/*      */   }
/*      */   public void onTick() {
/*  313 */     if (!this.tryCalc)
/*  314 */       return;  if (this.UpdateTimer.passedMs(((Integer)this.updateDelay.getValue()).intValue())) {
/*  315 */       CrystalTarget crystalTarget = Calc();
/*  316 */       renderEnt = crystalTarget.target;
/*  317 */       this.render = crystalTarget.blockPos;
/*  318 */       this.damage = (float)crystalTarget.dmg;
/*      */       
/*  320 */       if (renderEnt == null || this.render == null) {
/*  321 */         if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  322 */           this.lastBestPlace = null;
/*      */         }
/*  324 */         this.damage = 0.0F;
/*  325 */         this.render = null;
/*  326 */         switchOffhand(false);
/*  327 */         pausePA(false);
/*  328 */         this.lastHitVec = null;
/*      */         return;
/*      */       } 
/*  331 */       if (renderEnt instanceof EntityPlayer) AutoEz.INSTANCE.addTargetedPlayer(renderEnt.getName()); 
/*  332 */       this.UpdateTimer.reset();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void fast() {
/*  337 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*      */       return;
/*      */     }
/*  340 */     this.managerRenderBlocks.update(((Integer)this.lifeTime.getValue()).intValue());
/*      */     
/*  342 */     if (this.CalcTimer.passedMs(1000L)) {
/*  343 */       this.CalcTimer.reset();
/*  344 */       this.calculated = true;
/*      */     } 
/*      */     
/*  347 */     this.crystalSlot = getItemHotbar();
/*  348 */     if (this.crystalSlot == -1 && (!((Boolean)this.offhand.getValue()).booleanValue() || !((String)this.switchMode.getValue()).equals("AutoSwitch")) && mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) {
/*  349 */       if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  350 */         this.lastBestPlace = null;
/*      */       }
/*  352 */       this.damage = 0.0F;
/*  353 */       renderEnt = null;
/*  354 */       this.render = null;
/*  355 */       switchOffhand(false);
/*  356 */       pausePA(false);
/*  357 */       this.lastHitVec = null;
/*  358 */       this.tryCalc = false;
/*      */       
/*      */       return;
/*      */     } 
/*  362 */     this.tryCalc = true;
/*      */     
/*  364 */     if (renderEnt == null || this.render == null)
/*      */       return; 
/*  366 */     if (!((Boolean)this.eat.getValue()).booleanValue() && EntityUtil.isEating()) {
/*  367 */       this.lastHitVec = null;
/*      */       
/*      */       return;
/*      */     } 
/*  371 */     if (((String)this.logic.getValue()).equals("BreakPlace")) {
/*  372 */       explode();
/*  373 */       place(((Boolean)this.crystalCheck.getValue()).booleanValue());
/*      */     } else {
/*  375 */       place(((Boolean)this.crystalCheck.getValue()).booleanValue());
/*  376 */       explode();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void explode() {
/*  381 */     if (this.damage == 0.0F)
/*      */       return; 
/*  383 */     EntityEnderCrystal crystal = mc.world.loadedEntityList.stream().filter(e -> (e instanceof EntityEnderCrystal && !e.isDead && canHitCrystal((EntityEnderCrystal)e))).map(e -> (EntityEnderCrystal)e).min(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance((Entity)e)))).orElse(null);
/*  384 */     if (mc.player != null && crystal != null && renderEnt != null) {
/*  385 */       if (((Boolean)this.explode.getValue()).booleanValue() && mc.player.getDistance((Entity)crystal) <= ((Double)this.breakRange.getValue()).doubleValue()) {
/*  386 */         this.lastCrystal = crystal;
/*      */         
/*  388 */         if (!((Boolean)this.wall.getValue()).booleanValue() || mc.player.getDistance((Entity)crystal) <= ((Double)this.breakWallRange.getValue()).doubleValue() || CrystalUtil.calculateRaytrace((Entity)crystal)) {
/*  389 */           if (this.StuckTimes > 0) this.StuckTimes = 0; 
/*  390 */           this.lastHitVec = new Vec3d(crystal.posX, crystal.posY, crystal.posZ);
/*  391 */           ExplodeCrystal((Entity)this.lastCrystal);
/*  392 */           this.afterAttacking = true;
/*      */         } else {
/*  394 */           this.afterAttacking = false;
/*  395 */           this.StuckTimes++;
/*      */         } 
/*      */       } 
/*      */       
/*  399 */       if (((Boolean)this.ClientSide.getValue()).booleanValue()) {
/*  400 */         for (Entity o : mc.world.getLoadedEntityList()) {
/*  401 */           if (o instanceof EntityEnderCrystal && o.getDistance(o.posX, o.posY, o.posZ) <= 6.0D) {
/*  402 */             o.setDead();
/*      */           }
/*      */         } 
/*  405 */         mc.world.removeAllEntities();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean in(int number, int floor, int ceil) {
/*  411 */     return (number >= floor && number <= ceil);
/*      */   }
/*      */   
/*      */   private boolean crystalPlaceBoxIntersectsCrystalBox(BlockPos placePos, Double x, Double y, Double z) {
/*  415 */     return (in(x.intValue() - placePos.y, 0, 2) && 
/*  416 */       in(y.intValue() - placePos.x, -1, 1) && 
/*  417 */       in(z.intValue() - placePos.z, -1, 1));
/*      */   }
/*      */   
/*      */   private void place(boolean check) {
/*  421 */     if (((Boolean)this.place.getValue()).booleanValue() && this.render != null) {
/*      */       
/*  423 */       boolean useOffhand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL);
/*  424 */       if (mc.player.inventory.currentItem != this.crystalSlot && !useOffhand)
/*  425 */         if (((String)this.switchMode.getValue()).equals("AutoSwitch")) {
/*  426 */           if (((Boolean)this.offhand.getValue()).booleanValue()) {
/*  427 */             switchOffhand(true);
/*      */             return;
/*      */           } 
/*      */         } else {
/*      */           return;
/*      */         }  
/*  433 */       pausePA(((Boolean)this.pause.getValue()).booleanValue());
/*      */       
/*  435 */       if (this.PlaceTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue())) {
/*  436 */         boolean detected = true;
/*  437 */         for (Entity entity : new ArrayList(mc.world.loadedEntityList)) {
/*  438 */           if (entity instanceof EntityEnderCrystal && 
/*  439 */             !entity.isDead && 
/*  440 */             crystalPlaceBoxIntersectsCrystalBox(this.render, Double.valueOf(entity.posX), Double.valueOf(entity.posY), Double.valueOf(entity.posZ))) {
/*  441 */             detected = false;
/*      */           }
/*      */         } 
/*  444 */         if (detected || !check) {
/*  445 */           EnumHand hand = useOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
/*  446 */           EnumFacing facing = (((Boolean)this.y256.getValue()).booleanValue() && this.render.getY() == 255) ? EnumFacing.DOWN : EnumFacing.UP;
/*  447 */           if (((Boolean)this.calc.getValue()).booleanValue()) {
/*  448 */             RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(this.render.getX() + 0.5D, this.render.getY() + 0.5D, this.render.getZ() + 0.5D));
/*  449 */             if (result != null && result.sideHit != null) facing = result.sideHit; 
/*      */           } 
/*  451 */           EnumFacing opposite = facing.getOpposite();
/*  452 */           Vec3d vec = (new Vec3d((Vec3i)this.render)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(opposite.getDirectionVec()));
/*  453 */           this.lastHitVec = ((Boolean)this.placeRotate.getValue()).booleanValue() ? vec : new Vec3d(this.render.x + 0.5D, (this.render.y + 1), this.render.z + 0.5D);
/*      */ 
/*      */ 
/*      */           
/*  457 */           EnumFacing finalFacing = facing;
/*  458 */           switchTo(this.crystalSlot, findInventory(), (!useOffhand && ((String)this.switchMode.getValue()).equals("AutoSwitch")), ((Boolean)this.switchBack.getValue()).booleanValue(), () -> { if (((Boolean)this.packet.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.render, finalFacing, hand, 0.0F, 0.0F, 0.0F)); }
/*      */                 else
/*      */                 { mc.playerController.processRightClickBlock(mc.player, mc.world, this.render, finalFacing, vec, hand); }
/*      */               
/*  462 */               }); if (((Boolean)this.swing.getValue()).booleanValue())
/*  463 */             if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); }
/*  464 */             else { mc.player.swingArm(hand); }
/*      */              
/*  466 */           this.placements++;
/*  467 */           this.PlaceTimer.reset();
/*      */         } 
/*      */       } 
/*      */       
/*  471 */       if (((Boolean)this.PredictHit.getValue()).booleanValue() && renderEnt != null && DamageUtil.calculateCrystalDamage((EntityLivingBase)renderEnt, this.render.x + 0.5D, (this.render.y + 1), this.render.z + 0.5D) > ((Integer)this.breakMinDmg.getValue()).intValue())
/*      */         try {
/*  473 */           if (renderEnt.isDead || !this.canPredictHit || (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal))) {
/*  474 */             this.PlaceTimer.reset();
/*      */             return;
/*      */           } 
/*  477 */           if (((Boolean)this.wall.getValue()).booleanValue() && mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace((Entity)this.lastCrystal))
/*      */             return; 
/*  479 */           if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) > ((Double)this.maxSelfDMG.getValue()).doubleValue() && this.lastEntityID != -1 && this.lastCrystal != null && this.canPredictHit) {
/*  480 */             for (int i = 0; i < ((Integer)this.PredictHitFactor.getValue()).intValue(); i++) {
/*  481 */               PacketExplode(this.lastEntityID + i + 2);
/*      */             }
/*      */           }
/*  484 */         } catch (Exception exception) {} 
/*      */     } 
/*      */   }
/*      */   
/*      */   public CrystalTarget Calc() {
/*      */     EntityPlayer entityPlayer1;
/*      */     List<BlockPos> default_blocks;
/*      */     EntityPlayer entityPlayer2;
/*  492 */     if (((Boolean)this.sword.getValue()).booleanValue() && mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemSword) return new CrystalTarget(null, (Entity)PlayerUtil.getNearestPlayer(((Integer)this.enemyRange.getValue()).intValue()), 0.0D); 
/*  493 */     List<EntityLivingBase> entities = getEntities();
/*  494 */     double damage = 0.0D;
/*  495 */     EntityLivingBase renderEnt = null;
/*  496 */     BlockPos render = null;
/*  497 */     BlockPos setToAir = null;
/*  498 */     IBlockState state = null;
/*      */     
/*  500 */     if (((Boolean)this.wall.getValue()).booleanValue() && ((Boolean)this.wallAI.getValue()).booleanValue())
/*  501 */     { double TempRange = ((Double)this.placeRange.getValue()).doubleValue();
/*  502 */       double temp2 = TempRange - this.StuckTimes * 0.5D;
/*  503 */       if (this.StuckTimes > 0) {
/*  504 */         TempRange = ((Double)this.placeRange.getValue()).doubleValue();
/*  505 */         if (temp2 > ((Double)this.placeWallRange.getValue()).doubleValue()) {
/*  506 */           TempRange = temp2;
/*  507 */         } else if (((Double)this.placeWallRange.getValue()).doubleValue() < ((Double)this.placeRange.getValue()).doubleValue()) {
/*  508 */           TempRange = 3.0D;
/*      */         } 
/*      */       } 
/*  511 */       default_blocks = renditions(TempRange); }
/*  512 */     else { default_blocks = renditions(((Double)this.placeRange.getValue()).doubleValue()); }
/*  513 */      this.settings = new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue());
/*  514 */     EntityPlayerSP entityPlayerSP = mc.player;
/*  515 */     if (((Boolean)this.self.getValue()).booleanValue()) entityPlayer2 = PredictUtil.predictPlayer((EntityLivingBase)entityPlayerSP, this.settings); 
/*  516 */     for (EntityLivingBase entity2 : entities) {
/*  517 */       EntityPlayer entityPlayer; if (entity2.getHealth() <= 0.0F || entity2.isDead) {
/*      */         continue;
/*      */       }
/*  520 */       if (((Boolean)this.target.getValue()).booleanValue()) entityPlayer = PredictUtil.predictPlayer(entity2, this.settings); 
/*  521 */       BlockPos playerPos = new BlockPos(entityPlayer.getPositionVector());
/*  522 */       Block web = mc.world.getBlockState(playerPos).getBlock();
/*  523 */       if (web == Blocks.WEB) {
/*  524 */         setToAir = playerPos;
/*  525 */         state = mc.world.getBlockState(playerPos);
/*  526 */         mc.world.setBlockToAir(playerPos);
/*      */       } 
/*  528 */       BlockPos vec = new BlockPos(((EntityLivingBase)entityPlayer).posX, ((EntityLivingBase)entityPlayer).posY, ((EntityLivingBase)entityPlayer).posZ);
/*  529 */       Vec3d doubleTargetPos = new Vec3d((Vec3i)vec);
/*  530 */       List<BlockPos> legBlocks = findLegBlocks(doubleTargetPos);
/*  531 */       this.canPredictHit = (((!((Boolean)this.PredictHit.getValue()).booleanValue() || !entityPlayer.getHeldItemMainhand().getItem().equals(Items.EXPERIENCE_BOTTLE)) && !entityPlayer.getHeldItemOffhand().getItem().equals(Items.EXPERIENCE_BOTTLE)) || !ModuleManager.getModule("AutoMend").isEnabled());
/*  532 */       legBlocks.addAll(default_blocks);
/*  533 */       for (BlockPos blockPos : legBlocks) {
/*  534 */         if (intersectsWithEntity(blockPos.up()) || intersectsWithEntity(blockPos.up(2)) || 
/*  535 */           blockPos.equals(vec) || 
/*  536 */           entityPlayer.getDistanceSq(blockPos) >= (((Integer)this.enemyRange.getValue()).intValue() * ((Integer)this.enemyRange.getValue()).intValue()) || 
/*  537 */           mc.player.getDistance(blockPos.getX(), blockPos.getY(), blockPos.getZ()) > ((Double)this.placeRange.getValue()).doubleValue() || ((
/*  538 */           (Boolean)this.wall.getValue()).booleanValue() && PlayerUtil.getDistanceI(blockPos) > ((Double)this.placeWallRange.getValue()).doubleValue() && !CrystalUtil.calculateRaytrace(blockPos)))
/*  539 */           continue;  double d = DamageUtil.calculateCrystalDamage((EntityLivingBase)entityPlayer, blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D);
/*  540 */         if (d > ((Double)this.maxDamage.getValue()).doubleValue()) return new CrystalTarget(null, (Entity)PlayerUtil.getNearestPlayer(((Integer)this.enemyRange.getValue()).intValue()), 0.0D); 
/*  541 */         if (d < damage)
/*      */           continue; 
/*  543 */         float healthTarget = entityPlayer.getHealth() + entityPlayer.getAbsorptionAmount();
/*  544 */         float healthSelf = mc.player.getHealth() + mc.player.getAbsorptionAmount();
/*  545 */         double self = DamageUtil.calculateCrystalDamage((EntityLivingBase)entityPlayer2, blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D);
/*  546 */         switch ((String)this.godMode.getValue()) {
/*      */           case "GodMode":
/*  548 */             self = 0.0D;
/*      */             break;
/*      */           
/*      */           case "Auto":
/*  552 */             if (mc.player.isCreative()) {
/*  553 */               self = 0.0D;
/*      */             }
/*      */             break;
/*      */         } 
/*      */         
/*  558 */         if ((d >= healthTarget) ? (
/*  559 */           self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= healthSelf && !((Boolean)this.forcePlace.getValue()).booleanValue()) : (
/*      */           
/*  561 */           d < ((Double)this.minDamage.getValue()).doubleValue() || (
/*  562 */           self > d && d < healthTarget) || (
/*  563 */           self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= healthSelf) || (
/*  564 */           self != 0.0D && self + ((Double)this.balance.getValue()).doubleValue() >= ((Double)this.maxSelfDMG.getValue()).doubleValue()))) {
/*      */           continue;
/*      */         }
/*  567 */         damage = d;
/*  568 */         render = blockPos;
/*  569 */         entityPlayer1 = entityPlayer;
/*      */       } 
/*  571 */       if (setToAir != null) {
/*  572 */         mc.world.setBlockState(setToAir, state);
/*  573 */         this.webPos = render;
/*      */       } 
/*      */       
/*  576 */       if (entityPlayer1 != null) {
/*      */         break;
/*      */       }
/*      */     } 
/*  580 */     if (entityPlayer1 == null) entityPlayer1 = PlayerUtil.getNearestPlayer(((Integer)this.enemyRange.getValue()).intValue()); 
/*  581 */     return new CrystalTarget(render, (Entity)entityPlayer1, damage);
/*      */   }
/*      */   
/*      */   private void switchOffhand(boolean value) {
/*  585 */     if (ModuleManager.isModuleEnabled(OffHand.class)) OffHand.INSTANCE.autoCrystal = value; 
/*  586 */     if (ModuleManager.isModuleEnabled(OffHandCat.class)) OffHandCat.INSTANCE.autoCrystal = value; 
/*      */   }
/*      */   
/*      */   private void pausePA(boolean value) {
/*  590 */     if (ModuleManager.isModuleEnabled(PistonAura.class)) PistonAura.INSTANCE.autoCrystal = value; 
/*  591 */     if (ModuleManager.isModuleEnabled(PullCrystal.class)) PullCrystal.INSTANCE.autoCrystal = value; 
/*      */   }
/*      */   
/*      */   private boolean intersectsWithEntity(BlockPos pos) {
/*  595 */     for (Entity entity : mc.world.loadedEntityList) {
/*  596 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof EntityEnderCrystal) && (
/*  597 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/*  598 */         return true; 
/*      */     } 
/*  600 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<EntityLivingBase> getEntities() {
/*  605 */     return (List<EntityLivingBase>)mc.world.playerEntities.stream()
/*  606 */       .filter(entity -> (mc.player.getDistance((Entity)entity) < ((Integer)this.enemyRange.getValue()).intValue()))
/*  607 */       .filter(entity -> !EntityUtil.basicChecksEntity(entity)).sorted(Comparator.comparingDouble(entity -> entity.getDistance((Entity)mc.player)))
/*  608 */       .filter(entity -> (!((Boolean)this.onlyInHole.getValue()).booleanValue() || HoleUtil.isInHole((Entity)entity, false, false, false))).collect(Collectors.toList());
/*      */   }
/*      */   
/*      */   public void ExplodeCrystal(Entity crystal) {
/*  612 */     if (crystal != null && 
/*  613 */       this.ExplodeTimer.passedMs(((Integer)this.hitDelay.getValue()).intValue()) && mc.getConnection() != null) {
/*  614 */       PacketExplode(crystal.getEntityId());
/*  615 */       EnumHand hand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
/*  616 */       if (((Boolean)this.swing.getValue()).booleanValue())
/*  617 */         if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); }
/*  618 */         else { mc.player.swingArm(hand); }
/*      */          
/*  620 */       mc.player.resetCooldown();
/*  621 */       this.ExplodeTimer.reset();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void PacketExplode(int i) {
/*  627 */     if (this.lastCrystal != null && renderEnt != null) {
/*      */       try {
/*  629 */         if (mc.player.getDistance((Entity)this.lastCrystal) > ((Double)this.breakRange.getValue()).doubleValue() || !canHitCrystal(this.lastCrystal))
/*  630 */           return;  int slot = -1;
/*  631 */         if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS) && (!mc.player.isPotionActive(MobEffects.STRENGTH) || ((PotionEffect)Objects.requireNonNull((T)mc.player.getActivePotionEffect(MobEffects.STRENGTH))).getAmplifier() < 1)) {
/*  632 */           for (int b = 0; b < (findInventory() ? 36 : 9); b++) {
/*  633 */             ItemStack stack = mc.player.inventory.getStackInSlot(b);
/*  634 */             if (stack != ItemStack.EMPTY) {
/*  635 */               if (stack.getItem() instanceof net.minecraft.item.ItemSword) {
/*  636 */                 slot = b; break;
/*      */               } 
/*  638 */               if (stack.getItem() instanceof net.minecraft.item.ItemTool) {
/*  639 */                 slot = b;
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*  646 */         switchTo(slot, ((Boolean)this.weakBypass.getValue()).booleanValue(), true, ((Boolean)this.packetWeak.getValue()).booleanValue(), () -> {
/*      */               CPacketUseEntity crystal = new CPacketUseEntity();
/*      */               setEntityId(crystal, i);
/*      */               setAction(crystal, CPacketUseEntity.Action.ATTACK);
/*      */               mc.player.connection.sendPacket((Packet)crystal);
/*      */             });
/*  652 */       } catch (Exception exception) {}
/*      */     }
/*      */   }
/*      */   
/*      */   public static void setEntityId(CPacketUseEntity packet, int entityId) {
/*  657 */     ((AccessorCPacketUseEntity)packet).setId(entityId);
/*      */   }
/*      */   public static void setAction(CPacketUseEntity packet, CPacketUseEntity.Action action) {
/*  660 */     ((AccessorCPacketUseEntity)packet).setAction(action);
/*      */   }
/*      */   public boolean canHitCrystal(EntityEnderCrystal crystal) {
/*  663 */     if (mc.player.getDistance((Entity)crystal) > ((Double)this.breakRange.getValue()).doubleValue()) return false; 
/*  664 */     float healthSelf = mc.player.getHealth() + mc.player.getAbsorptionAmount();
/*  665 */     if (mc.player.isDead || healthSelf <= 0.0F) return false; 
/*  666 */     float selfDamage = DamageUtil.calculateCrystalDamage(((Boolean)this.self.getValue()).booleanValue() ? (EntityLivingBase)PredictUtil.predictPlayer((EntityLivingBase)mc.player, this.settings) : (EntityLivingBase)mc.player, crystal.posX, crystal.posY, crystal.posZ);
/*  667 */     switch ((String)this.godMode.getValue()) {
/*      */       case "GodMode":
/*  669 */         selfDamage = 0.0F;
/*      */         break;
/*      */       
/*      */       case "Auto":
/*  673 */         if (mc.player.isCreative()) selfDamage = 0.0F;
/*      */         
/*      */         break;
/*      */     } 
/*  677 */     if (selfDamage != 0.0F && selfDamage + ((Double)this.balance.getValue()).doubleValue() >= healthSelf) return false; 
/*  678 */     if (this.render != null && ((
/*  679 */       new AxisAlignedBB(this.render)).intersects(crystal.getEntityBoundingBox()) || (new AxisAlignedBB(this.render.up())).intersects(crystal.getEntityBoundingBox()))) {
/*  680 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  685 */     List<EntityPlayer> entities = (List<EntityPlayer>)mc.world.playerEntities.stream().filter(p -> !EntityUtil.basicChecksEntity(p)).sorted(Comparator.comparing(crystal::getDistance)).collect(Collectors.toList());
/*      */     
/*  687 */     for (EntityPlayer player : entities) {
/*  688 */       double target = DamageUtil.calculateCrystalDamage((EntityLivingBase)player, crystal.posX, crystal.posY, crystal.posZ);
/*  689 */       if (target > (player.getHealth() + player.getAbsorptionAmount())) return true;
/*      */       
/*  691 */       double minDamage = ((Integer)this.breakMinDmg.getValue()).intValue();
/*  692 */       if (target < minDamage || 
/*  693 */         selfDamage > target)
/*  694 */         continue;  return true;
/*      */     } 
/*  696 */     return false;
/*      */   }
/*      */   
/*      */   public static List<BlockPos> getSphere(Vec3d loc, double r, double h, boolean hollow, boolean sphere, int plus_y) {
/*  700 */     List<BlockPos> circleBlocks = new ArrayList<>();
/*  701 */     int cx = (int)loc.x;
/*  702 */     int cy = (int)loc.y;
/*  703 */     int cz = (int)loc.z;
/*  704 */     for (int x = cx - (int)r; x <= cx + r; x++) {
/*  705 */       for (int z = cz - (int)r; z <= cz + r; ) {
/*  706 */         int y = sphere ? (cy - (int)r) : cy; for (;; z++) { if (y < (sphere ? (cy + r) : (cy + h))) {
/*  707 */             double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/*  708 */             if (dist < r * r && (!hollow || dist >= (r - 1.0D) * (r - 1.0D))) {
/*  709 */               BlockPos l = new BlockPos(x, y + plus_y, z);
/*  710 */               circleBlocks.add(l);
/*      */             }  y++; continue;
/*      */           }  }
/*      */       
/*      */       } 
/*  715 */     }  return circleBlocks;
/*      */   }
/*      */   public List<BlockPos> renditions(double range) {
/*  718 */     NonNullList<BlockPos> positions = NonNullList.create();
/*  719 */     positions.addAll((Collection)getSphere(getPlayerPos(), range, range, false, true, 0)
/*      */         
/*  721 */         .stream()
/*  722 */         .filter(this::canPlaceCrystal).collect(Collectors.toList()));
/*  723 */     return (List<BlockPos>)positions;
/*      */   }
/*      */   
/*      */   public static List<BlockPos> getLegVec(Vec3d add) {
/*  727 */     List<BlockPos> circleBlocks = new ArrayList<>();
/*  728 */     BlockPos uwu = new BlockPos(add.x, add.y, add.z);
/*  729 */     circleBlocks.add(uwu);
/*  730 */     return circleBlocks;
/*      */   }
/*      */   private List<BlockPos> findLegBlocks(Vec3d targetPos) {
/*  733 */     NonNullList<BlockPos> positions = NonNullList.create();
/*  734 */     positions.addAll((Collection)getLegVec(targetPos.add(0.0D, 0.0D, 0.0D))
/*  735 */         .stream().filter(this::canPlaceCrystal).collect(Collectors.toList()));
/*  736 */     return (List<BlockPos>)positions;
/*      */   }
/*      */   public Vec3d getPlayerPos() {
/*  739 */     return new Vec3d(mc.player.posX, mc.player.posY, mc.player.posZ);
/*      */   }
/*      */   
/*      */   public boolean canPlaceCrystal(BlockPos blockPos) {
/*  743 */     BlockPos boost = blockPos.add(0, 1, 0);
/*  744 */     BlockPos boost2 = blockPos.add(0, 2, 0);
/*  745 */     if (mc.world.getBlockState(boost).getBlock() == Blocks.WATER || mc.world
/*  746 */       .getBlockState(boost).getBlock() == Blocks.WATERLILY || mc.world
/*  747 */       .getBlockState(boost).getBlock() == Blocks.FLOWING_WATER || mc.world
/*  748 */       .getBlockState(boost).getBlock() == Blocks.MAGMA || mc.world
/*  749 */       .getBlockState(boost).getBlock() == Blocks.LAVA || mc.world
/*  750 */       .getBlockState(boost).getBlock() == Blocks.FLOWING_LAVA)
/*  751 */       return false; 
/*  752 */     if (mc.world.getBlockState(boost2).getBlock() == Blocks.WATER || mc.world
/*  753 */       .getBlockState(boost2).getBlock() == Blocks.WATERLILY || mc.world
/*  754 */       .getBlockState(boost2).getBlock() == Blocks.FLOWING_WATER || mc.world
/*  755 */       .getBlockState(boost2).getBlock() == Blocks.MAGMA || mc.world
/*  756 */       .getBlockState(boost2).getBlock() == Blocks.LAVA || mc.world
/*  757 */       .getBlockState(boost2).getBlock() == Blocks.FLOWING_LAVA)
/*  758 */       return false; 
/*  759 */     if (mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN) {
/*  760 */       return false;
/*      */     }
/*  762 */     if (((Boolean)this.highVersion.getValue()).booleanValue())
/*  763 */     { if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR) return false;
/*      */        }
/*  765 */     else if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR || mc.world.getBlockState(boost2).getBlock() != Blocks.AIR) { return false; }
/*      */     
/*  767 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost))) {
/*  768 */       if (!(entity instanceof EntityEnderCrystal)) {
/*  769 */         return false;
/*      */       }
/*      */     } 
/*  772 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2))) {
/*  773 */       if (!(entity instanceof EntityEnderCrystal)) {
/*  774 */         return false;
/*      */       }
/*      */     } 
/*  777 */     webCalc();
/*  778 */     if (this.afterAttacking) {
/*  779 */       for (Entity entity : mc.world.loadedEntityList) {
/*  780 */         if (!(entity instanceof EntityEnderCrystal))
/*  781 */           continue;  EntityEnderCrystal entityEnderCrystal = (EntityEnderCrystal)entity;
/*  782 */         if (Math.abs(entityEnderCrystal.posY - (blockPos.getY() + 1)) >= 2.0D)
/*  783 */           continue;  double d2 = (this.lastCrystal != null) ? this.lastCrystal.getDistance(blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D) : 10000.0D;
/*  784 */         if (d2 <= 6.0D || 
/*  785 */           getRange(entityEnderCrystal.getPositionVector(), blockPos.getX() + 0.5D, (blockPos.getY() + 1), blockPos.getZ() + 0.5D) >= 2.0D)
/*  786 */           continue;  return false;
/*      */       } 
/*      */     }
/*  789 */     return true;
/*      */   }
/*      */   
/*      */   public void webCalc() {
/*  793 */     if (this.webPos != null)
/*  794 */       if (mc.player.getDistanceSq(this.webPos) > MathUtil.square((Double)this.breakRange.getValue())) {
/*  795 */         this.webPos = null;
/*      */       } else {
/*  797 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(this.webPos))) {
/*  798 */           if (entity instanceof EntityEnderCrystal) {
/*  799 */             this.webPos = null;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }  
/*      */   }
/*      */   
/*      */   private int getItemHotbar() {
/*  807 */     for (int i = 0; i < (findInventory() ? 36 : 9); ) {
/*  808 */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/*  809 */       if (Item.getIdFromItem(item) != Item.getIdFromItem(Items.END_CRYSTAL)) { i++; continue; }
/*  810 */        return i;
/*      */     } 
/*  812 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEnable() {
/*  817 */     this.lastEntityID = -1;
/*  818 */     this.size = 0.0D;
/*  819 */     this.ShouldInfoLastBreak = false;
/*  820 */     this.afterAttacking = false;
/*  821 */     this.canPredictHit = true;
/*  822 */     this.PlaceTimer.reset();
/*  823 */     this.ExplodeTimer.reset();
/*  824 */     this.PacketExplodeTimer.reset();
/*  825 */     this.UpdateTimer.reset();
/*  826 */     this.CalcTimer.reset();
/*  827 */     this.timer = new Timing();
/*  828 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  829 */       this.lastBestPlace = null;
/*  830 */       this.managerRenderBlocks.blocks.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void onDisable() {
/*  836 */     switchOffhand(false);
/*  837 */     pausePA(false);
/*  838 */     this.lastHitVec = null;
/*  839 */     renderEnt = null;
/*  840 */     this.render = null;
/*  841 */     this.StuckTimes = 0;
/*  842 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  843 */       this.lastBestPlace = null;
/*  844 */       this.managerRenderBlocks.blocks.clear();
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean findInventory() {
/*  849 */     return (((Boolean)this.bypass.getValue()).booleanValue() && ((Boolean)this.switchBack.getValue()).booleanValue());
/*      */   }
/*      */   
/*      */   public String getHudInfo() {
/*  853 */     if (renderEnt == null) return ""; 
/*  854 */     return "[" + ChatFormatting.WHITE + renderEnt.getName() + ChatFormatting.GRAY + "]";
/*      */   }
/*      */   
/*      */   public static class CrystalTarget {
/*      */     public BlockPos blockPos;
/*      */     public Entity target;
/*      */     public double dmg;
/*      */     
/*      */     public CrystalTarget(BlockPos block, Entity target, double dmg) {
/*  863 */       this.blockPos = block;
/*  864 */       this.target = target;
/*  865 */       this.dmg = dmg;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void onWorldRender(RenderEvent event) {
/*  871 */     if (mc.world == null || mc.player == null) {
/*      */       return;
/*      */     }
/*  874 */     if (this.render != null) {
/*  875 */       this.blockPos = this.render;
/*  876 */       if (((Boolean)this.move.getValue()).booleanValue()) { this.lastBestPlace = this.render; }
/*  877 */       else { drawBoxMain(this.blockPos.x, this.blockPos.y, this.blockPos.z); }
/*  878 */        if (((Boolean)this.fade.getValue()).booleanValue()) this.managerRenderBlocks.addRender(this.render);
/*      */     
/*      */     } 
/*  881 */     this.managerRenderBlocks.render();
/*      */     
/*  883 */     if (!((Boolean)this.move.getValue()).booleanValue())
/*  884 */       return;  if (this.lastBestPlace != null) {
/*  885 */       if (this.movingPlaceNow.x == -1.0D && this.movingPlaceNow.y == -1.0D && this.movingPlaceNow.z == -1.0D) {
/*  886 */         this.movingPlaceNow = new Vec3d(this.lastBestPlace.getX(), this.lastBestPlace.getY(), this.lastBestPlace.getZ());
/*      */       }
/*      */       
/*  889 */       this
/*      */ 
/*      */         
/*  892 */         .movingPlaceNow = new Vec3d(this.movingPlaceNow.x + (this.lastBestPlace.getX() - this.movingPlaceNow.x) * ((Double)this.movingSpeed.getValue()).floatValue(), this.movingPlaceNow.y + (this.lastBestPlace.getY() - this.movingPlaceNow.y) * ((Double)this.movingSpeed.getValue()).floatValue(), this.movingPlaceNow.z + (this.lastBestPlace.getZ() - this.movingPlaceNow.z) * ((Double)this.movingSpeed.getValue()).floatValue());
/*      */ 
/*      */ 
/*      */       
/*  896 */       if (Math.abs(this.movingPlaceNow.x - this.lastBestPlace.getX()) <= 0.125D && Math.abs(this.movingPlaceNow.y - this.lastBestPlace.getY()) <= 0.125D && Math.abs(this.movingPlaceNow.z - this.lastBestPlace.getZ()) <= 0.125D) {
/*  897 */         this.lastBestPlace = null;
/*      */       }
/*      */     } 
/*      */     
/*  901 */     if (this.movingPlaceNow.x != -1.0D && this.movingPlaceNow.y != -1.0D && this.movingPlaceNow.z != -1.0D) drawBoxMain(this.movingPlaceNow.x, this.movingPlaceNow.y, this.movingPlaceNow.z);
/*      */   
/*      */   }
/*      */   
/*      */   AxisAlignedBB getBox(double x, double y, double z) {
/*  906 */     double maxX = x + 1.0D;
/*  907 */     double maxZ = z + 1.0D;
/*      */     
/*  909 */     return new AxisAlignedBB(x, y, z, maxX, y + 1.0D, maxZ);
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z) {
/*  913 */     AxisAlignedBB box = getBox(x, y, z);
/*      */     
/*  915 */     if (((Boolean)this.scale.getValue()).booleanValue() && this.scale.isVisible())
/*  916 */     { if (renderEnt == null || this.render == null || Math.abs(x - this.render.x) > 0.5D || Math.abs(z - this.render.z) > 0.5D)
/*  917 */       { this.size -= ((Double)this.reduceSpeed.getValue()).doubleValue(); }
/*  918 */       else if (this.size != 1.0D) { this.size += ((Double)this.growSpeed.getValue()).doubleValue(); }
/*  919 */        if (this.size > 1.0D) this.size = 1.0D; 
/*  920 */       if (this.size < 0.0D) this.size = 0.0D;
/*      */       
/*  922 */       if ((renderEnt == null || this.render == null) && 
/*  923 */         this.size == 0.0D) this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*      */       
/*  925 */       box = box.grow((1.0D - this.size) * (1.0D - this.size) / 2.0D - 1.0D); }
/*  926 */     else if (renderEnt == null || this.render == null) { this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D); }
/*      */     
/*  928 */     if (((Boolean)this.flat.getValue()).booleanValue()) box = new AxisAlignedBB(box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ);
/*      */     
/*  930 */     switch ((String)this.mode.getValue()) {
/*      */       case "Outline":
/*  932 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */         break;
/*      */       
/*      */       case "Solid":
/*  936 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/*      */         break;
/*      */       
/*      */       case "Both":
/*  940 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/*  941 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  946 */     if (((Boolean)this.showDamage.getValue()).booleanValue()) {
/*  947 */       box = getBox(x, y, z);
/*  948 */       String[] damageText = { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) };
/*  949 */       RenderUtil.drawNametag(box.minX + 0.5D, box.minY + 0.5D, box.minZ + 0.5D, damageText, new GSColor(255, 255, 255), 1, 0.02666666666666667D, 0.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z, double percent) {
/*  954 */     int alpha = (int)(((Integer)this.fadeAlpha.getValue()).intValue() * percent);
/*  955 */     int outAlpha = (int)(((Integer)this.fadeOutAlpha.getValue()).intValue() * percent);
/*  956 */     AxisAlignedBB box = getBox(x, y, z);
/*      */     
/*  958 */     if (((Boolean)this.scale.getValue()).booleanValue() && this.scale.isVisible()) {
/*  959 */       box = box.grow((1.0D - percent) * (1.0D - percent) / 2.0D - 1.0D);
/*      */     }
/*      */     
/*  962 */     if (((Boolean)this.flat.getValue()).booleanValue()) box = new AxisAlignedBB(box.minX, box.maxY, box.minZ, box.maxX, box.maxY, box.maxZ);
/*      */     
/*  964 */     switch ((String)this.mode.getValue()) {
/*      */       case "Outline":
/*  966 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), outAlpha));
/*      */         break;
/*      */       
/*      */       case "Solid":
/*  970 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), alpha), 63);
/*      */         break;
/*      */       
/*      */       case "Both":
/*  974 */         RenderUtil.drawBox(box, true, ((Boolean)this.flat.getValue()).booleanValue() ? 0.0D : 1.0D, new GSColor(this.color.getValue(), alpha), 63);
/*  975 */         RenderUtil.drawBoundingBox(box, 1.0D, new GSColor(this.color.getValue(), outAlpha));
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean sameBlockPos(BlockPos first, BlockPos second) {
/*  981 */     if (first == null || second == null)
/*  982 */       return false; 
/*  983 */     return (first.getX() == second.getX() && first.getY() == second.getY() && first.getZ() == second.getZ());
/*      */   }
/*      */   
/*      */   class managerClassRenderBlocks {
/*  987 */     ArrayList<FacePlace.renderBlock> blocks = new ArrayList<>();
/*      */     void update(int time) {
/*  989 */       this.blocks.removeIf(e -> (System.currentTimeMillis() - e.start > time));
/*      */     }
/*      */     
/*      */     void render()
/*      */     {
/*  994 */       this.blocks.forEach(e -> {
/*      */             if (FacePlace.this.render != null && FacePlace.this.sameBlockPos(e.pos, FacePlace.this.render)) {
/*      */               e.resetTime();
/*      */             } else {
/*      */               e.render();
/*      */             } 
/*      */           }); } void addRender(BlockPos pos) {
/* 1001 */       boolean render = true;
/* 1002 */       for (FacePlace.renderBlock block : this.blocks) {
/* 1003 */         if (FacePlace.this.sameBlockPos(block.pos, pos)) {
/* 1004 */           render = false;
/* 1005 */           block.resetTime(); break;
/*      */         } 
/*      */       } 
/* 1008 */       if (render)
/* 1009 */         this.blocks.add(new FacePlace.renderBlock(pos)); 
/*      */     }
/*      */   }
/*      */   
/*      */   class renderBlock
/*      */   {
/*      */     private final BlockPos pos;
/*      */     private long start;
/*      */     
/*      */     public renderBlock(BlockPos pos) {
/* 1019 */       this.start = System.currentTimeMillis();
/* 1020 */       this.pos = pos;
/*      */     }
/*      */ 
/*      */     
/*      */     void resetTime() {
/* 1025 */       this.start = System.currentTimeMillis();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void render() {
/* 1031 */       FacePlace.this.drawBoxMain(this.pos.x, this.pos.y, this.pos.z, percent());
/*      */     }
/*      */ 
/*      */     
/*      */     public double percent() {
/* 1036 */       long end = this.start + ((Integer)FacePlace.this.lifeTime.getValue()).intValue();
/* 1037 */       double result = (end - System.currentTimeMillis()) / (end - this.start);
/* 1038 */       if (result < 0.0D) result = 0.0D; 
/* 1039 */       if (result > 1.0D) result = 1.0D; 
/* 1040 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\FacePlace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
