//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.qwq;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.world.BlockUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Declaration(name = "test Module", category = Category.qwq)
/*    */ public class testModule
/*    */   extends Module
/*    */ {
/* 36 */   BooleanSetting ewe = registerBoolean("Don't Use or AutoCrash", true);
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {}
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 44 */     BlockPos pos = mc.objectMouseOver.getBlockPos();
/* 45 */     if (pos != null)
/* 46 */       MessageBus.sendClientRawMessage(String.valueOf(BlockUtil.getBlock(pos))); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\testModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
