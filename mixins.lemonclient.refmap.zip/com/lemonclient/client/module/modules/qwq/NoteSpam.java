//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.qwq;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.api.util.world.BlockUtil;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "NoteSpam", category = Category.qwq)
/*    */ public class NoteSpam extends Module {
/* 22 */   ModeSetting timeMode = registerMode("Time Mode", Arrays.asList(new String[] { "onUpdate", "Tick", "Fast" }, ), "Fast");
/* 23 */   DoubleSetting range = registerDouble("Range", 5.5D, 1.0D, 10.0D);
/* 24 */   IntegerSetting max = registerInteger("MaxBlocks", 30, 1, 150);
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 28 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("onUpdate")) {
/* 29 */       doNoteSpam();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onTick() {
/* 34 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("Tick")) {
/* 35 */       doNoteSpam();
/*    */     }
/*    */   }
/*    */   
/*    */   public void fast() {
/* 40 */     if (((String)this.timeMode.getValue()).equalsIgnoreCase("Fast"))
/* 41 */       doNoteSpam(); 
/*    */   }
/*    */   
/*    */   private void doNoteSpam() {
/* 45 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*    */       return;
/*    */     }
/* 48 */     int counter = 0;
/* 49 */     List<BlockPos> posList = EntityUtil.getSphere(PlayerUtil.getPlayerPos(), (Double)this.range.getValue(), (Double)this.range.getValue(), false, true, 0);
/* 50 */     for (BlockPos b : posList) {
/* 51 */       if (BlockUtil.getBlock(b) == Blocks.NOTEBLOCK) {
/* 52 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, b, EnumFacing.UP));
/* 53 */         if (++counter > ((Integer)this.max.getValue()).intValue())
/*    */           return; 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\NoteSpam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
