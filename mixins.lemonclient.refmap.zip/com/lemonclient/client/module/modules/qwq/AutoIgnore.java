//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.qwq;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import java.util.HashMap;
/*    */ import java.util.TimerTask;
/*    */ import java.util.regex.Matcher;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ 
/*    */ @Declaration(name = "AutoIgnore", category = Category.qwq)
/*    */ public class AutoIgnore extends Module {
/*    */   BooleanSetting filterFriend;
/*    */   BooleanSetting ignoreAll;
/*    */   BooleanSetting playerCheck;
/*    */   IntegerSetting times;
/*    */   IntegerSetting life;
/*    */   HashMap<String, Integer> messageTimes;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> receiveListener;
/*    */   
/*    */   public AutoIgnore() {
/* 24 */     this.filterFriend = registerBoolean("Filter Friend", false);
/* 25 */     this.ignoreAll = registerBoolean("AllWhisper", false);
/* 26 */     this.playerCheck = registerBoolean("PlayerCheck", true);
/* 27 */     this.times = registerInteger("Times", 10, 0, 30);
/* 28 */     this.life = registerInteger("LifeTime", 600, 0, 3000);
/* 29 */     this.messageTimes = new HashMap<>();
/*    */     
/* 31 */     this.receiveListener = new Listener(event -> { if (mc.player == null) return;  if (!(event.getPacket() instanceof SPacketChat)) return;  String message = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText(); if (((Boolean)this.ignoreAll.getValue()).booleanValue() && message.contains(":")) { String username = ""; int spaceIndex = message.indexOf(" "); if (spaceIndex != -1) username = message.substring(0, spaceIndex);  if ((!username.isEmpty() && !SocialManager.isOnIgnoreList(username) && !SocialManager.isOnFriendList(username)) || !((Boolean)this.filterFriend.getValue()).booleanValue()) { SocialManager.addIgnore(username); MessageBus.sendClientDeleteMessage(username + " has been added to ignore list", Notification.Type.INFO, "AutoIgnore", 13); }  }  String s = message.replaceAll("\\[.*?]|<.*?>|\\d+", ""); addToList(s); if (((Integer)this.messageTimes.get(s)).intValue() > ((Integer)this.times.getValue()).intValue()) { Matcher matcher = Pattern.compile("<.*?> ").matcher(message); String username = ""; if (matcher.find()) { username = matcher.group(); username = username.substring(1, username.length() - 2); } else if (message.contains(":")) { int spaceIndex = message.indexOf(" "); if (spaceIndex != -1) username = message.substring(0, spaceIndex);  }  username = ColorMain.cleanColor(username); if (username.equals(mc.player.getName()) || (((Boolean)this.playerCheck.getValue()).booleanValue() && mc.player.connection.getPlayerInfo(username) == null)) return;  if ((!username.isEmpty() && !SocialManager.isOnIgnoreList(username) && !SocialManager.isOnFriendList(username)) || !((Boolean)this.filterFriend.getValue()).booleanValue()) { SocialManager.addIgnore(username); MessageBus.sendClientDeleteMessage(username + " has been added to ignore list", Notification.Type.INFO, "AutoIgnore", 13); }  event.cancel(); }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addToList(final String string) {
/* 72 */     int time = 1;
/* 73 */     if (this.messageTimes.containsKey(string)) time += ((Integer)this.messageTimes.get(string)).intValue(); 
/* 74 */     this.messageTimes.put(string, Integer.valueOf(time));
/* 75 */     (new Timer()).schedule(new TimerTask()
/*    */         {
/*    */           public void run() {
/* 78 */             AutoIgnore.this.messageTimes.put(string, Integer.valueOf(((Integer)AutoIgnore.this.messageTimes.get(string)).intValue() - 1));
/*    */           }
/* 80 */         }(((Integer)this.life.getValue()).intValue() * 1000));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\AutoIgnore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
