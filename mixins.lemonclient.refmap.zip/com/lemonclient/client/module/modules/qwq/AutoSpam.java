//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.qwq;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import java.util.Random;
/*    */ 
/*    */ @Declaration(name = "AutoSpam", category = Category.qwq)
/*    */ public class AutoSpam extends Module {
/*    */   StringSetting string;
/*    */   IntegerSetting delay;
/*    */   BooleanSetting hide;
/*    */   BooleanSetting randomThing;
/*    */   BooleanSetting letter;
/*    */   BooleanSetting number;
/*    */   IntegerSetting character;
/*    */   BooleanSetting antiSpam;
/*    */   String sent;
/*    */   int waited;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> receiveListener;
/*    */   
/*    */   public AutoSpam() {
/* 21 */     this.string = registerString("Message", "/msg _yonkie_ gay");
/* 22 */     this.delay = registerInteger("Delay", 1, 0, 200);
/* 23 */     this.hide = registerBoolean("Hide", true);
/* 24 */     this.randomThing = registerBoolean("Random Thing", false);
/* 25 */     this.letter = registerBoolean("Letter", true, () -> (Boolean)this.randomThing.getValue());
/* 26 */     this.number = registerBoolean("Number", true, () -> (Boolean)this.randomThing.getValue());
/* 27 */     this.character = registerInteger("Character", 20, 0, 256, () -> (Boolean)this.randomThing.getValue());
/* 28 */     this.antiSpam = registerBoolean("AntiSpam", true);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || !((Boolean)this.hide.getValue()).booleanValue()) return;  if (event.getPacket() instanceof SPacketChat) { String message = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText(); Matcher matcher = Pattern.compile("<.*?> ").matcher(message); String username = ""; if (matcher.find()) { username = matcher.group(); username = username.substring(1, username.length() - 2); } else if (message.contains(":")) { int spaceIndex = message.indexOf(" "); if (spaceIndex != -1) username = message.substring(0, spaceIndex);  }  username = ColorMain.cleanColor(username); if ((message.toLowerCase().contains("to") && message.contains(":")) || username.equals(mc.player.getName())) { event.cancel(); MessageBus.sendDeleteMessage("Spamming", "AutoSpam", 14); }  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   public void onTick() {
/*    */     if (mc.world == null || mc.player == null)
/*    */       return; 
/*    */     if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*    */       return; 
/*    */     this.waited = 0;
/*    */     StringBuilder phrase = new StringBuilder(this.string.getText());
/*    */     if (((Boolean)this.randomThing.getValue()).booleanValue()) {
/*    */       String characters = (((Boolean)this.letter.getValue()).booleanValue() ? "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz" : "") + (((Boolean)this.number.getValue()).booleanValue() ? "0123456789" : "");
/*    */       Random random = new Random();
/*    */       for (int i = 0; i < ((Integer)this.character.getValue()).intValue(); i++) {
/*    */         int index = random.nextInt(characters.length());
/*    */         phrase.append(characters.charAt(index));
/*    */       } 
/*    */     } 
/*    */     if (((Boolean)this.antiSpam.getValue()).booleanValue()) {
/*    */       Random random = new Random();
/*    */       int nextInt = random.nextInt(16777216);
/*    */       String hex = String.format("#%06x", new Object[] { Integer.valueOf(nextInt) });
/*    */       phrase.append(" [").append(hex).append("]");
/*    */     } 
/*    */     this.sent = phrase.toString();
/*    */     MessageBus.sendServerMessage(this.sent);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\AutoSpam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
