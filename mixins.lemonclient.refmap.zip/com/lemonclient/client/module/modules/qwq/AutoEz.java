//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.qwq;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ 
/*     */ @Declaration(name = "AutoEz", category = Category.qwq)
/*     */ public class AutoEz extends Module {
/*     */   public static AutoEz INSTANCE;
/*     */   public BooleanSetting hi;
/*     */   StringSetting msg;
/*     */   IntegerSetting delay;
/*     */   List<Target> targetedPlayers;
/*     */   int waited;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   @EventHandler
/*     */   private final Listener<LivingDeathEvent> livingDeathEventListener;
/*     */   
/*     */   public AutoEz() {
/*  29 */     this.hi = registerBoolean("Use {name} for target name", true);
/*  30 */     this.msg = registerString("Msg", ">Ez");
/*  31 */     this.delay = registerInteger("Delay", 0, 0, 20);
/*     */ 
/*     */ 
/*     */     
/*  35 */     this.sendListener = new Listener(event -> { if (mc.player != null) { if (this.targetedPlayers == null) this.targetedPlayers = new ArrayList<>();  if (this.waited > 0) return;  if (event.getPacket() instanceof CPacketUseEntity) { CPacketUseEntity cPacketUseEntity = (CPacketUseEntity)event.getPacket(); if (cPacketUseEntity.getAction().equals(CPacketUseEntity.Action.ATTACK)) { Entity targetEntity = cPacketUseEntity.getEntityFromWorld((World)mc.world); if (targetEntity instanceof EntityPlayer) addTargetedPlayer(targetEntity.getName());  }  }  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.livingDeathEventListener = new Listener(event -> { if (mc.player != null) { if (this.targetedPlayers == null) this.targetedPlayers = new ArrayList<>();  if (this.waited > 0) return;  EntityLivingBase entity = event.getEntityLiving(); if (entity != null && entity instanceof EntityPlayer) { EntityPlayer player = (EntityPlayer)entity; if (player.getHealth() <= 0.0F) { String name = player.getName(); doAnnounce(name); }  }  }  }new java.util.function.Predicate[0]);
/*     */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  81 */     this.targetedPlayers = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  85 */     this.targetedPlayers = null;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  89 */     if (this.targetedPlayers == null) {
/*  90 */       this.targetedPlayers = new ArrayList<>();
/*     */     }
/*  92 */     this.waited--;
/*  93 */     if (this.waited > 0)
/*     */       return; 
/*  95 */     List<String> nameList = new ArrayList<>();
/*  96 */     for (EntityPlayer player : mc.world.playerEntities) {
/*  97 */       String name = player.getName();
/*  98 */       nameList.add(name);
/*  99 */       if (inList(name) && 
/* 100 */         player.getHealth() <= 0.0F) {
/* 101 */         doAnnounce(name);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 106 */     this.targetedPlayers.removeIf(target -> {
/*     */           if (!nameList.contains(target.name) || target.name.equals(""))
/*     */             return true; 
/*     */           target.updateTime();
/*     */           return (target.time <= 0);
/*     */         });
/*     */   }
/*     */   private void doAnnounce(String name) {
/* 114 */     if (name.equals(mc.player.getName()))
/* 115 */       return;  boolean in = false;
/* 116 */     for (Target target : this.targetedPlayers) {
/* 117 */       if (target.name.equals(name)) {
/* 118 */         this.targetedPlayers.remove(target);
/* 119 */         in = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 123 */     if (!in)
/* 124 */       return;  String message = this.msg.getText();
/*     */     
/* 126 */     String messageSanitized = message.replace("{name}", name);
/* 127 */     if (messageSanitized.length() > 255) {
/* 128 */       messageSanitized = messageSanitized.substring(0, 255);
/*     */     }
/*     */     
/* 131 */     MessageBus.sendServerMessage(messageSanitized);
/* 132 */     this.waited = ((Integer)this.delay.getValue()).intValue();
/*     */   }
/*     */   
/*     */   public void addTargetedPlayer(String name) {
/* 136 */     if (!Objects.equals(name, mc.player.getName())) {
/* 137 */       if (this.targetedPlayers == null) this.targetedPlayers = new ArrayList<>(); 
/* 138 */       boolean added = false;
/* 139 */       for (Target target : this.targetedPlayers) {
/* 140 */         if (target.name.equals(name)) {
/* 141 */           target.update();
/* 142 */           added = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 146 */       if (!added) this.targetedPlayers.add(new Target(name)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean inList(String name) {
/* 151 */     for (Target target : this.targetedPlayers) {
/* 152 */       if (target.name.equals(name)) return true; 
/*     */     } 
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   static class Target { String name;
/*     */     int time;
/*     */     
/*     */     public Target(String name) {
/* 161 */       this.name = name;
/* 162 */       this.time = 20;
/*     */     }
/*     */     
/*     */     void updateTime() {
/* 166 */       this.time--;
/*     */     }
/*     */     void update() {
/* 169 */       this.time = 20;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\AutoEz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
