//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.qwq;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockTNT;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "TNTAura", category = Category.qwq)
/*     */ public class TNTAura extends Module {
/*  34 */   IntegerSetting delay = registerInteger("Delay", 100, 0, 2000);
/*  35 */   IntegerSetting range = registerInteger("Range", 5, 0, 10);
/*  36 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  37 */   BooleanSetting packet = registerBoolean("Packet Place", false);
/*  38 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  39 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", false);
/*  40 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*  41 */   BooleanSetting trap = registerBoolean("Trap", false);
/*  42 */   BooleanSetting doubleTnt = registerBoolean("Double", false);
/*  43 */   IntegerSetting maxTarget = registerInteger("Max Target", 1, 1, 10);
/*  44 */   IntegerSetting blocksPerTick = registerInteger("Blocks Per Tick", 8, 1, 20);
/*  45 */   DoubleSetting maxSpeed = registerDouble("Max Target Speed", 10.0D, 0.0D, 50.0D);
/*     */   int placed;
/*  47 */   Timing timer = new Timing();
/*  48 */   List<EntityPlayer> list = new ArrayList<>();
/*     */   
/*  50 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   BlockPos[] high = new BlockPos[] { new BlockPos(0, 1, 0), new BlockPos(0, 2, 0), new BlockPos(0, 3, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/*  63 */     if (slot > -1 && slot < 9 && (
/*  64 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*  65 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/*  67 */       { mc.player.inventory.currentItem = slot;
/*  68 */         mc.playerController.updateController(); }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  75 */     this.placed = 0;
/*  76 */     this.timer.reset();
/*  77 */     this.list = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public void fast() {
/*  81 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */       return;
/*     */     }
/*  84 */     int tnt = BurrowUtil.findHotbarBlock(BlockTNT.class);
/*  85 */     int flint = BurrowUtil.findHotbarBlock(Items.FLINT_AND_STEEL.getClass());
/*  86 */     if (tnt == -1 || flint == -1)
/*  87 */       return;  List<EntityPlayer> targetList = PlayerUtil.getNearPlayers(((Integer)this.range.getValue()).intValue(), ((Integer)this.maxTarget.getValue()).intValue());
/*  88 */     if (targetList.isEmpty())
/*  89 */       return;  List<EntityPlayer> targets = new ArrayList<>();
/*  90 */     for (EntityPlayer entityPlayer : targetList) {
/*  91 */       if (!this.list.contains(entityPlayer)) targets.add(entityPlayer); 
/*     */     } 
/*  93 */     if (targets.isEmpty()) {
/*  94 */       this.list.clear();
/*  95 */       targets.addAll(targetList);
/*     */     } 
/*  97 */     int count = targetList.size();
/*     */     
/*  99 */     if (!this.timer.passedMs((((Integer)this.delay.getValue()).intValue() / count)))
/* 100 */       return;  this.timer.reset();
/* 101 */     this.placed = 0;
/*     */     
/* 103 */     for (EntityPlayer target : targetList) {
/* 104 */       AutoEz.INSTANCE.addTargetedPlayer(target.getName());
/* 105 */       this.list.add(target);
/* 106 */       BlockPos pos = EntityUtil.getPlayerPos(target);
/* 107 */       BlockPos tntPos = pos.up(2);
/* 108 */       if (mc.player.getDistance((Entity)target) > ((Integer)this.range.getValue()).intValue() || LemonClient.speedUtil.getPlayerSpeed(target) > ((Double)this.maxSpeed.getValue()).doubleValue() || !BlockUtil.isAir(pos.up())) {
/*     */         return;
/*     */       }
/* 111 */       int obsi = BurrowUtil.findHotbarBlock(BlockObsidian.class), oldSlot = mc.player.inventory.currentItem;
/* 112 */       if (obsi != -1) {
/* 113 */         List<BlockPos> trap = new ArrayList<>();
/* 114 */         for (BlockPos side : this.sides) {
/* 115 */           for (BlockPos high : this.high) {
/* 116 */             if (((Boolean)this.doubleTnt.getValue()).booleanValue() || high.getY() != 3) {
/* 117 */               BlockPos blockPos = pos.add((Vec3i)side).add((Vec3i)high);
/* 118 */               if (!intersectsWithEntity(blockPos) && BlockUtil.isAir(blockPos)) trap.add(blockPos); 
/*     */             } 
/*     */           } 
/* 121 */         }  if (((Boolean)this.trap.getValue()).booleanValue()) {
/* 122 */           BlockPos north = tntPos.north();
/* 123 */           trap.add(north.up());
/* 124 */           trap.add(north.up(2));
/* 125 */           trap.add(tntPos.up(2));
/*     */         } 
/* 127 */         switchTo(obsi);
/* 128 */         for (BlockPos trapPos : trap) {
/* 129 */           ItemStack stack = mc.player.inventory.getStackInSlot(obsi);
/* 130 */           if (this.placed >= ((Integer)this.blocksPerTick.getValue()).intValue() || stack == ItemStack.EMPTY) {
/* 131 */             switchTo(oldSlot);
/*     */             return;
/*     */           } 
/* 134 */           if (BlockUtil.isAir(trapPos)) {
/* 135 */             BurrowUtil.placeBlock(trapPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 136 */             this.placed++;
/*     */           } 
/*     */         } 
/* 139 */         switchTo(oldSlot);
/*     */       } else {
/*     */         return;
/* 142 */       }  boolean can = canPlace(tntPos), canDouble = canPlace(tntPos.up());
/* 143 */       if (!can)
/* 144 */         return;  switchTo(tnt);
/* 145 */       BurrowUtil.placeBlock(tntPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 146 */       if (((Boolean)this.doubleTnt.getValue()).booleanValue() && canDouble) BurrowUtil.placeBlock(tntPos.up(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */ 
/*     */       
/* 149 */       switchTo(flint);
/* 150 */       EnumFacing facing = EnumFacing.DOWN;
/* 151 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(tntPos, facing, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 152 */       if (((Boolean)this.doubleTnt.getValue()).booleanValue() && canDouble) mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(tntPos.up(), facing, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/*     */       
/* 154 */       switchTo(oldSlot);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean canPlace(BlockPos pos) {
/* 159 */     return ((BlockUtil.hasNeighbour(pos) && BlockUtil.isAir(pos)) || mc.world.getBlockState(pos).getBlock() == Blocks.TNT);
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 163 */     for (Entity entity : mc.world.loadedEntityList) {
/* 164 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 165 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 166 */         return true; 
/*     */     } 
/* 168 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\qwq\TNTAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
