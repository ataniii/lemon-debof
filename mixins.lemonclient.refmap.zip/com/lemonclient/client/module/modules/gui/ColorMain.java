//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.gui;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ 
/*     */ @Declaration(name = "Colors", category = Category.GUI, enabled = true, drawn = false, priority = 10000)
/*     */ public class ColorMain extends Module {
/*     */   public static ColorMain INSTANCE;
/*     */   public ColorSetting enabledColor;
/*     */   public DoubleSetting rainbowSpeed;
/*     */   public ModeSetting rainbowMode;
/*     */   public BooleanSetting customFont;
/*     */   public BooleanSetting textFont;
/*     */   public BooleanSetting highlightSelf;
/*     */   public ModeSetting selfColor;
/*     */   public ModeSetting friendColor;
/*     */   public ModeSetting enemyColor;
/*     */   public ModeSetting chatModuleColor;
/*     */   public ModeSetting chatEnableColor;
/*     */   public ModeSetting chatDisableColor;
/*     */   public ColorSetting Title;
/*     */   public ColorSetting Enabled;
/*     */   public ColorSetting Disabled;
/*     */   public ColorSetting Background;
/*     */   public ColorSetting Font;
/*     */   public ColorSetting ScrollBar;
/*     */   public ColorSetting Highlight;
/*     */   public ModeSetting colorModel;
/*     */   Color title;
/*     */   Color enable;
/*     */   Color disable;
/*     */   Color background;
/*     */   Color font;
/*     */   Color scrollBar;
/*     */   Color highlight;
/*     */   public boolean sneaking;
/*     */   public double velocityBoost;
/*     */   public List<BlockPos> breakList;
/*     */   HashMap<EntityPlayer, BlockPos> list;
/*     */   BlockPos lastBreak;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> postSendListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> packetSend;
/*     */   @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   @EventHandler
/*     */   public Listener<EntityUseTotemEvent> listListener;
/*     */   
/*  52 */   public ColorMain() { this.enabledColor = registerColor("Main Color", new GSColor(255, 0, 0, 255));
/*  53 */     this.rainbowSpeed = registerDouble("Rainbow Speed", 1.0D, 0.1D, 10.0D);
/*  54 */     this.rainbowMode = registerMode("Rainbow Mode", Arrays.asList(new String[] { "Normal", "Sin", "Tan", "Sec", "CoTan", "CoSec" }, ), "Normal");
/*  55 */     this.customFont = registerBoolean("Custom Font", true);
/*  56 */     this.textFont = registerBoolean("Custom Text", false);
/*  57 */     this.highlightSelf = registerBoolean("Highlight SelfName", false);
/*  58 */     this.selfColor = registerMode("Self Color", ColorUtil.colors, "Blue");
/*  59 */     this.friendColor = registerMode("Friend Color", ColorUtil.colors, "Green");
/*  60 */     this.enemyColor = registerMode("Enemy Color", ColorUtil.colors, "Red");
/*  61 */     this.chatModuleColor = registerMode("Msg Module", ColorUtil.colors, "Aqua");
/*  62 */     this.chatEnableColor = registerMode("Msg Enable", ColorUtil.colors, "Green");
/*  63 */     this.chatDisableColor = registerMode("Msg Disable", ColorUtil.colors, "Red");
/*  64 */     this.Title = registerColor("Title Color", new GSColor(90, 145, 240));
/*  65 */     this.Enabled = registerColor("Enabled Color", new GSColor(90, 145, 240));
/*  66 */     this.Disabled = registerColor("Disabled", new GSColor(64, 64, 64));
/*  67 */     this.Background = registerColor("BackGround Color", new GSColor(195, 195, 195, 150), Boolean.valueOf(true));
/*  68 */     this.Font = registerColor("Font Color", new GSColor(255, 255, 255));
/*  69 */     this.ScrollBar = registerColor("ScrollBar Color", new GSColor(90, 145, 240));
/*  70 */     this.Highlight = registerColor("Highlight Color", new GSColor(0, 0, 240));
/*  71 */     this.colorModel = registerMode("Color Model", Arrays.asList(new String[] { "RGB", "HSB" }, ), "HSB");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     this.breakList = new ArrayList<>();
/*  77 */     this.list = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketEntityAction) { if (((CPacketEntityAction)event.getPacket()).getAction() == CPacketEntityAction.Action.START_SNEAKING) this.sneaking = true;  if (((CPacketEntityAction)event.getPacket()).getAction() == CPacketEntityAction.Action.STOP_SNEAKING) this.sneaking = false;  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     this.packetSend = new Listener(event -> { if (event.getPacket() instanceof net.minecraftforge.fml.common.network.internal.FMLProxyPacket && !mc.isSingleplayer()) event.cancel();  if (event.getPacket() instanceof CPacketCustomPayload) { CPacketCustomPayload packet = (CPacketCustomPayload)event.getPacket(); if (packet.getChannelName().equalsIgnoreCase("MC|Brand")) ((AccessorCPacketCustomPayload)packet).setData((new PacketBuffer(Unpooled.buffer())).writeString("vanilla"));  }  if (event.getPacket() instanceof CPacketPlayerDigging) { CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket(); if (packet.getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) this.lastBreak = packet.getPosition();  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  LemonClient.speedUtil.update(); LemonClient.positionUtil.updatePosition(); }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || EntityUtil.isDead((Entity)mc.player)) return;  if (event.getPacket() instanceof SPacketChat) { String message = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText(); Matcher matcher = Pattern.compile("<.*?> ").matcher(message); String username = ""; if (matcher.find()) { username = matcher.group(); username = username.substring(1, username.length() - 2); } else if (message.contains(":")) { int spaceIndex = message.indexOf(" "); if (spaceIndex != -1) username = message.substring(0, spaceIndex);  }  username = cleanColor(username); if (SocialManager.isIgnore(username)) event.cancel();  }  if (event.getPacket() instanceof SPacketBlockBreakAnim) { SPacketBlockBreakAnim packet = (SPacketBlockBreakAnim)event.getPacket(); BlockPos blockPos = packet.getPosition(); EntityPlayer entityPlayer = (EntityPlayer)mc.world.getEntityByID(packet.getBreakerId()); if (entityPlayer == null) return;  this.list.put(entityPlayer, blockPos); }  if (event.getPacket() instanceof SPacketEntityVelocity) { SPacketEntityVelocity packet = (SPacketEntityVelocity)event.getPacket(); Entity entity = mc.world.getEntityByID(packet.entityID); if (entity != null && entity == mc.player) this.velocityBoost = ((Boolean)SpeedPlus.INSTANCE.sum.getValue()).booleanValue() ? (this.velocityBoost + Math.hypot((packet.motionX / 8000.0F), (packet.motionZ / 8000.0F))) : Math.max(this.velocityBoost, Math.hypot((packet.motionX / 8000.0F), (packet.motionZ / 8000.0F)));  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     this.listListener = new Listener(event -> { if (event.getEntity() == mc.player && mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory)) mc.player.closeScreen();  }new java.util.function.Predicate[0]); INSTANCE = this; }
/*     */   public void onDisable() { enable(); }
/*     */   public void fast() { if (this.title != this.Title.getColor() || this.enable != this.Enabled.getColor() || this.disable != this.Disabled.getColor() || this.background != this.Background.getColor() || this.font != this.Font.getColor() || this.scrollBar != this.ScrollBar.getColor() || this.highlight != this.Highlight.getColor()) { this.title = (Color)this.Title.getColor(); this.enable = (Color)this.Enabled.getColor(); this.disable = (Color)this.Disabled.getColor(); this.background = (Color)this.Background.getColor(); this.font = (Color)this.Font.getColor(); this.scrollBar = (Color)this.ScrollBar.getColor(); this.highlight = (Color)this.Highlight.getColor(); LemonClient.INSTANCE.gameSenseGUI.refresh(); }
/*     */      if (!((Boolean)AutoEz.INSTANCE.hi.getValue()).booleanValue())
/*     */       AutoEz.INSTANCE.hi.setValue(Boolean.valueOf(true));  this.breakList = new ArrayList<>(); this.breakList.add(this.lastBreak); List<EntityPlayer> playerList = mc.world.playerEntities; for (EntityPlayer player : playerList) { if (this.list.containsKey(player)) {
/*     */         BlockPos pos = this.list.get(player); this.breakList.add(pos);
/*     */       }  }
/* 211 */      } public static String cleanColor(String input) { return input.replaceAll("(?i)\\u00A7.", ""); }
/*     */   public void onUpdate() { if (!Display.getTitle().equals("Lemon Client v0.0.8")) { Display.setTitle("Lemon Client v0.0.8"); LemonClient.setWindowIcon(); }  if (!SpeedPlus.INSTANCE.isEnabled() && MotionUtil.moving((EntityLivingBase)mc.player))
/*     */       this.velocityBoost = 0.0D;  }
/* 214 */   public String highlight(String string) { if (string != null && isEnabled()) { String username = mc.getSession().getUsername(); return string.replace(username, getSelfColor() + username).replace(username.toLowerCase(), getSelfColor() + username.toLowerCase()).replace(username.toUpperCase(), getSelfColor() + username.toUpperCase()); }  return string; } public TextFormatting getSelfColor() { return ColorUtil.settingToTextFormatting(this.selfColor); }
/*     */   
/*     */   public TextFormatting getFriendColor() {
/* 217 */     return ColorUtil.settingToTextFormatting(this.friendColor);
/*     */   }
/*     */   public TextFormatting getEnemyColor() {
/* 220 */     return ColorUtil.settingToTextFormatting(this.enemyColor);
/*     */   }
/*     */   public TextFormatting getModuleColor() {
/* 223 */     return ColorUtil.settingToTextFormatting(this.chatModuleColor);
/*     */   }
/*     */   public TextFormatting getEnabledColor() {
/* 226 */     return ColorUtil.settingToTextFormatting(this.chatEnableColor);
/*     */   }
/*     */   
/*     */   public TextFormatting getDisabledColor() {
/* 230 */     return ColorUtil.settingToTextFormatting(this.chatDisableColor);
/*     */   }
/*     */   public GSColor getFriendGSColor() {
/* 233 */     return new GSColor(ColorUtil.settingToColor(this.friendColor));
/*     */   }
/*     */   
/*     */   public GSColor getEnemyGSColor() {
/* 237 */     return new GSColor(ColorUtil.settingToColor(this.enemyColor));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\gui\ColorMain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
