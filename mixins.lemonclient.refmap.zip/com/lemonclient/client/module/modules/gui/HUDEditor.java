/*    */ package com.lemonclient.client.module.modules.gui;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ 
/*    */ @Declaration(name = "HudEditor", category = Category.GUI, drawn = false)
/*    */ public class HUDEditor extends Module {
/*    */   public void onEnable() {
/* 11 */     LemonClient.INSTANCE.gameSenseGUI.enterHUDEditor();
/* 12 */     disable();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\gui\HUDEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */