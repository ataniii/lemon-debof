/*    */ package com.lemonclient.client.module.modules.gui;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.api.setting.SettingsManager;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Declaration(name = "ClickGUI", category = Category.GUI, bind = 25, drawn = false)
/*    */ public class ClickGuiModule
/*    */   extends Module
/*    */ {
/* 24 */   public IntegerSetting scrollSpeed = registerInteger("Scroll Speed", 10, 1, 20);
/* 25 */   public IntegerSetting animationSpeed = registerInteger("Animation Speed", 300, 0, 1000);
/* 26 */   public ModeSetting scrolling = registerMode("Scrolling", Arrays.asList(new String[] { "Screen", "Container" }, ), "Container");
/* 27 */   public BooleanSetting showHUD = registerBoolean("Show HUD Panels", false);
/* 28 */   public BooleanSetting csgoLayout = registerBoolean("CSGO Layout", false);
/* 29 */   public ModeSetting theme = registerMode("Skin", Collections.singletonList("Clear"), "Clear", () -> Boolean.valueOf(false));
/* 30 */   public BooleanSetting gradient = registerBoolean("Gradient", true);
/*    */   
/*    */   public void onEnable() {
/* 33 */     LemonClient.INSTANCE.gameSenseGUI.enterGUI();
/* 34 */     disable();
/*    */   }
/*    */   
/*    */   public ColorSetting registerColor(String name, String configName, Supplier<Boolean> isVisible, boolean rainbow, boolean rainbowEnabled, boolean alphaEnabled, GSColor value) {
/* 38 */     ColorSetting setting = new ColorSetting(name, configName, this, isVisible, rainbow, rainbowEnabled, alphaEnabled, value);
/* 39 */     SettingsManager.addSetting((Setting)setting);
/* 40 */     return setting;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\gui\ClickGuiModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */