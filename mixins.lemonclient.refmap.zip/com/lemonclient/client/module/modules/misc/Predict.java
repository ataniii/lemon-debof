//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.RenderEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ColorSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.player.PredictUtil;
/*    */ import com.lemonclient.api.util.render.RenderUtil;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ @Declaration(name = "Predict", category = Category.Misc)
/*    */ public class Predict extends Module {
/* 15 */   IntegerSetting range = registerInteger("Range", 10, 0, 100);
/* 16 */   IntegerSetting tickPredict = registerInteger("Tick Predict", 8, 0, 30);
/* 17 */   BooleanSetting calculateYPredict = registerBoolean("Calculate Y Predict", true);
/* 18 */   IntegerSetting startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> (Boolean)this.calculateYPredict.getValue());
/* 19 */   IntegerSetting exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> (Boolean)this.calculateYPredict.getValue());
/* 20 */   IntegerSetting decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> (Boolean)this.calculateYPredict.getValue());
/* 21 */   IntegerSetting exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> (Boolean)this.calculateYPredict.getValue());
/* 22 */   BooleanSetting splitXZ = registerBoolean("Split XZ", true);
/* 23 */   BooleanSetting hideSelf = registerBoolean("Hide Self", false);
/* 24 */   IntegerSetting width = registerInteger("Line Width", 2, 1, 5);
/* 25 */   BooleanSetting justOnce = registerBoolean("Just Once", false);
/* 26 */   BooleanSetting manualOutHole = registerBoolean("Manual Out Hole", false);
/* 27 */   BooleanSetting aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> (Boolean)this.manualOutHole.getValue());
/* 28 */   BooleanSetting stairPredict = registerBoolean("Stair Predict", false);
/* 29 */   IntegerSetting nStair = registerInteger("N Stair", 2, 1, 4, () -> (Boolean)this.stairPredict.getValue());
/* 30 */   DoubleSetting speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> (Boolean)this.stairPredict.getValue());
/* 31 */   ColorSetting mainColor = registerColor("Color");
/*    */   
/*    */   public void onWorldRender(RenderEvent event) {
/* 34 */     PredictUtil.PredictSettings settings = new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue());
/* 35 */     mc.world.playerEntities.stream().filter(entity -> (!((Boolean)this.hideSelf.getValue()).booleanValue() || entity != mc.player)).filter(this::rangeEntityCheck).forEach(entity -> {
/*    */           EntityPlayer clonedPlayer = PredictUtil.predictPlayer((EntityLivingBase)entity, settings);
/*    */           RenderUtil.drawBoundingBox(clonedPlayer.getEntityBoundingBox(), ((Integer)this.width.getValue()).intValue(), this.mainColor.getColor());
/*    */         });
/* 39 */     if (((Boolean)this.justOnce.getValue()).booleanValue())
/* 40 */       disable(); 
/*    */   }
/*    */   
/*    */   private boolean rangeEntityCheck(Entity entity) {
/* 44 */     return (entity.getDistance((Entity)mc.player) <= ((Integer)this.range.getValue()).intValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\Predict.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
