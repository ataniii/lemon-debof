//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.player.InventoryUtil;
/*    */ import net.minecraft.inventory.ClickType;
/*    */ import net.minecraft.item.ItemEnderPearl;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketClickWindow;
/*    */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*    */ import net.minecraft.util.EnumHand;
/*    */ 
/*    */ @Declaration(name = "MCP", category = Category.Misc)
/*    */ public class MCP extends Module {
/*    */   BooleanSetting clipRotate;
/*    */   IntegerSetting pearlPitch;
/*    */   BooleanSetting packetSwitch;
/*    */   BooleanSetting check;
/*    */   @EventHandler
/*    */   private final Listener<InputEvent.MouseInputEvent> listener;
/*    */   
/*    */   public MCP() {
/* 22 */     this.clipRotate = registerBoolean("clipRotate", false);
/* 23 */     this.pearlPitch = registerInteger("Pitch", 85, -90, 90, () -> (Boolean)this.clipRotate.getValue());
/* 24 */     this.packetSwitch = registerBoolean("Packet Switch", false);
/* 25 */     this.check = registerBoolean("Switch Check", false);
/* 26 */     this.listener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead || mc.player.inventory == null) return;  if (Mouse.getEventButton() == 2) { if (mc.objectMouseOver.typeOfHit == RayTraceResult.Type.ENTITY) return;  if (((Boolean)this.clipRotate.getValue()).booleanValue()) mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(mc.player.rotationYaw, ((Integer)this.pearlPitch.getValue()).floatValue(), mc.player.onGround));  int pearlInvSlot = InventoryUtil.findFirstItemSlot(ItemEnderPearl.class, 0, 35); int pearlHotSlot = InventoryUtil.findFirstItemSlot(ItemEnderPearl.class, 0, 8); if (pearlInvSlot == -1 && pearlHotSlot == -1) return;  int oldSlot = mc.player.inventory.currentItem; if (pearlHotSlot == -1) { ItemStack itemStack = mc.player.inventory.getStackInSlot(pearlInvSlot); mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, pearlInvSlot, mc.player.inventory.currentItem, ClickType.SWAP, ItemStack.EMPTY, mc.player.openContainer.getNextTransactionID(mc.player.inventory))); mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)); mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, pearlInvSlot, mc.player.inventory.currentItem, ClickType.SWAP, itemStack, mc.player.openContainer.getNextTransactionID(mc.player.inventory))); } else { switchTo(pearlHotSlot); mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)); switchTo(oldSlot); }  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void switchTo(int slot) {
/* 58 */     if (slot > -1 && slot < 9 && (
/* 59 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot))
/* 60 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 61 */       else { mc.player.inventory.currentItem = slot; }
/*    */        
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\MCP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
