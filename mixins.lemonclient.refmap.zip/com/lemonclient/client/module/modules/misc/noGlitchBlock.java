/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ 
/*    */ @Declaration(name = "NoGlitchBlock", category = Category.Misc)
/*    */ public class noGlitchBlock extends Module {
/* 10 */   public BooleanSetting breakBlock = registerBoolean("Break", true);
/* 11 */   public BooleanSetting placeBlock = registerBoolean("Place", true);
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\noGlitchBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */