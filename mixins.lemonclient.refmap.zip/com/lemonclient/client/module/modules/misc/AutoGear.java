//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.client.command.commands.AutoGearCommand;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.inventory.ContainerChest;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ @Declaration(name = "AutoGear", category = Category.Misc)
/*     */ public class AutoGear extends Module {
/*  19 */   IntegerSetting tickDelay = registerInteger("Tick Delay", 0, 0, 20);
/*  20 */   IntegerSetting switchForTick = registerInteger("Switch Per Tick", 1, 1, 100);
/*     */   
/*  22 */   BooleanSetting enderChest = registerBoolean("EnderChest", false);
/*  23 */   BooleanSetting confirmSort = registerBoolean("Confirm Sort", true);
/*  24 */   BooleanSetting invasive = registerBoolean("Invasive", false);
/*  25 */   BooleanSetting closeAfter = registerBoolean("Close After", false);
/*  26 */   BooleanSetting infoMsgs = registerBoolean("Info Msgs", true);
/*  27 */   BooleanSetting debugMode = registerBoolean("Debug Mode", false);
/*     */   
/*  29 */   private HashMap<Integer, String> planInventory = new HashMap<>();
/*  30 */   private final HashMap<Integer, String> containerInv = new HashMap<>();
/*  31 */   private ArrayList<Integer> sortItems = new ArrayList<>();
/*     */   
/*     */   private int delayTimeTicks;
/*     */   private int stepNow;
/*     */   private boolean openedBefore;
/*     */   private boolean finishSort;
/*     */   private boolean doneBefore;
/*     */   
/*     */   public void onEnable() {
/*  40 */     String curConfigName = AutoGearCommand.getCurrentSet();
/*     */     
/*  42 */     if (curConfigName.equals("")) {
/*  43 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  47 */     if (((Boolean)this.infoMsgs.getValue()).booleanValue()) {
/*  48 */       MessageBus.printDebug("Config " + curConfigName + " activated", Boolean.valueOf(false));
/*     */     }
/*  50 */     String inventoryConfig = AutoGearCommand.getInventoryKit(curConfigName);
/*     */     
/*  52 */     if (inventoryConfig.equals("")) {
/*  53 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  57 */     String[] inventoryDivided = inventoryConfig.split(" ");
/*     */     
/*  59 */     this.planInventory = new HashMap<>();
/*  60 */     HashMap<String, Integer> nItems = new HashMap<>();
/*     */     
/*  62 */     for (int i = 0; i < inventoryDivided.length; i++) {
/*     */       
/*  64 */       if (!inventoryDivided[i].contains("air")) {
/*     */         
/*  66 */         this.planInventory.put(Integer.valueOf(i), inventoryDivided[i]);
/*     */         
/*  68 */         if (nItems.containsKey(inventoryDivided[i])) {
/*     */           
/*  70 */           nItems.put(inventoryDivided[i], Integer.valueOf(((Integer)nItems.get(inventoryDivided[i])).intValue() + 1));
/*     */         } else {
/*     */           
/*  73 */           nItems.put(inventoryDivided[i], Integer.valueOf(1));
/*     */         } 
/*     */       } 
/*     */     } 
/*  77 */     this.delayTimeTicks = 0;
/*     */     
/*  79 */     this.openedBefore = this.doneBefore = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  85 */     if (this.delayTimeTicks < ((Integer)this.tickDelay.getValue()).intValue()) {
/*  86 */       this.delayTimeTicks++;
/*     */       return;
/*     */     } 
/*  89 */     this.delayTimeTicks = 0;
/*     */ 
/*     */ 
/*     */     
/*  93 */     if (this.planInventory.size() == 0) {
/*  94 */       disable();
/*     */     }
/*     */     
/*  97 */     if ((mc.player.openContainer instanceof ContainerChest && (((Boolean)this.enderChest.getValue()).booleanValue() || !((ContainerChest)mc.player.openContainer).getLowerChestInventory().getDisplayName().getUnformattedText().equals("Ender Chest"))) || mc.player.openContainer instanceof net.minecraft.inventory.ContainerShulkerBox)
/*     */     
/*     */     { 
/*     */       
/* 101 */       sortInventoryAlgo(); }
/* 102 */     else { this.openedBefore = false; }
/*     */   
/*     */   }
/*     */   
/*     */   private void sortInventoryAlgo() {
/* 107 */     if (!this.openedBefore) {
/*     */       
/* 109 */       int maxValue = (mc.player.openContainer instanceof ContainerChest) ? ((ContainerChest)mc.player.openContainer).getLowerChestInventory().getSizeInventory() : 27;
/*     */ 
/*     */       
/* 112 */       for (int i = 0; i < maxValue; i++) {
/* 113 */         ItemStack item = (ItemStack)mc.player.openContainer.getInventory().get(i);
/* 114 */         this.containerInv.put(Integer.valueOf(i), ((ResourceLocation)Objects.<ResourceLocation>requireNonNull(item.getItem().getRegistryName())).toString() + item.getMetadata());
/*     */       } 
/* 116 */       this.openedBefore = true;
/*     */       
/* 118 */       HashMap<Integer, String> inventoryCopy = getInventoryCopy(maxValue);
/*     */       
/* 120 */       HashMap<Integer, String> aimInventory = getInventoryCopy(maxValue, this.planInventory);
/*     */       
/* 122 */       this.sortItems = getInventorySort(inventoryCopy, aimInventory, maxValue);
/*     */       
/* 124 */       if (this.sortItems.size() == 0 && !this.doneBefore) {
/*     */         
/* 126 */         this.finishSort = false;
/*     */         
/* 128 */         if (((Boolean)this.closeAfter.getValue()).booleanValue()) {
/* 129 */           mc.player.closeScreen();
/*     */         }
/*     */       } else {
/* 132 */         this.finishSort = true;
/* 133 */         this.stepNow = 0;
/*     */       } 
/* 135 */       this.openedBefore = true;
/* 136 */     } else if (this.finishSort) {
/* 137 */       for (int i = 0; i < ((Integer)this.switchForTick.getValue()).intValue(); i++) {
/*     */ 
/*     */         
/* 140 */         if (this.sortItems.size() != 0) {
/*     */           
/* 142 */           int slotChange = ((Integer)this.sortItems.get(this.stepNow++)).intValue();
/*     */           
/* 144 */           mc.playerController.windowClick(mc.player.openContainer.windowId, slotChange, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */         } 
/*     */         
/* 147 */         if (this.stepNow == this.sortItems.size()) {
/*     */           
/* 149 */           if (((Boolean)this.confirmSort.getValue()).booleanValue() && 
/* 150 */             !this.doneBefore) {
/*     */             
/* 152 */             this.openedBefore = false;
/* 153 */             this.finishSort = false;
/* 154 */             this.doneBefore = true;
/*     */             
/* 156 */             checkLastItem();
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 161 */           this.finishSort = false;
/*     */           
/* 163 */           if (((Boolean)this.infoMsgs.getValue()).booleanValue()) {
/* 164 */             MessageBus.printDebug("Inventory sorted", Boolean.valueOf(false));
/*     */           }
/*     */           
/* 167 */           checkLastItem();
/* 168 */           this.doneBefore = false;
/*     */           
/* 170 */           if (((Boolean)this.closeAfter.getValue()).booleanValue()) {
/* 171 */             mc.player.closeScreen();
/*     */           }
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkLastItem() {
/* 180 */     if (this.sortItems.size() != 0) {
/*     */       
/* 182 */       int slotChange = ((Integer)this.sortItems.get(this.sortItems.size() - 1)).intValue();
/*     */       
/* 184 */       if (((ItemStack)mc.player.openContainer.getInventory().get(slotChange)).isEmpty())
/*     */       {
/* 186 */         mc.playerController.windowClick(0, slotChange, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<Integer> getInventorySort(HashMap<Integer, String> copyInventory, HashMap<Integer, String> planInventoryCopy, int startValues) {
/* 196 */     ArrayList<Integer> planMove = new ArrayList<>();
/*     */ 
/*     */     
/* 199 */     HashMap<String, Integer> nItemsCopy = new HashMap<>();
/*     */     
/* 201 */     for (String value : planInventoryCopy.values()) {
/* 202 */       if (nItemsCopy.containsKey(value)) {
/* 203 */         nItemsCopy.put(value, Integer.valueOf(((Integer)nItemsCopy.get(value)).intValue() + 1)); continue;
/*     */       } 
/* 205 */       nItemsCopy.put(value, Integer.valueOf(1));
/*     */     } 
/*     */ 
/*     */     
/* 209 */     ArrayList<Integer> ignoreValues = new ArrayList<>();
/*     */ 
/*     */     
/* 212 */     int[] listValue = new int[planInventoryCopy.size()];
/*     */     
/* 214 */     int id = 0;
/* 215 */     for (Iterator<Integer> iterator = planInventoryCopy.keySet().iterator(); iterator.hasNext(); ) { int idx = ((Integer)iterator.next()).intValue();
/* 216 */       listValue[id++] = idx; }
/*     */ 
/*     */ 
/*     */     
/* 220 */     for (int item : listValue) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       if (((String)copyInventory.get(Integer.valueOf(item))).equals(planInventoryCopy.get(Integer.valueOf(item)))) {
/*     */         
/* 227 */         ignoreValues.add(Integer.valueOf(item));
/*     */         
/* 229 */         nItemsCopy.put(planInventoryCopy.get(Integer.valueOf(item)), Integer.valueOf(((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(item)))).intValue() - 1));
/*     */         
/* 231 */         if (((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(item)))).intValue() == 0) {
/* 232 */           nItemsCopy.remove(planInventoryCopy.get(Integer.valueOf(item)));
/*     */         }
/* 234 */         planInventoryCopy.remove(Integer.valueOf(item));
/*     */       } 
/*     */     } 
/*     */     
/* 238 */     String pickedItem = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     for (int i = startValues; i < startValues + copyInventory.size(); i++) {
/*     */       
/* 245 */       if (!ignoreValues.contains(Integer.valueOf(i))) {
/*     */         
/* 247 */         String itemCheck = copyInventory.get(Integer.valueOf(i));
/*     */         
/* 249 */         Optional<Map.Entry<Integer, String>> momentAim = planInventoryCopy.entrySet().stream().filter(x -> ((String)x.getValue()).equals(itemCheck)).findFirst();
/*     */         
/* 251 */         if (momentAim.isPresent()) {
/*     */ 
/*     */           
/* 254 */           if (pickedItem == null) {
/* 255 */             planMove.add(Integer.valueOf(i));
/*     */           }
/* 257 */           int aimKey = ((Integer)((Map.Entry)momentAim.get()).getKey()).intValue();
/* 258 */           planMove.add(Integer.valueOf(aimKey));
/*     */           
/* 260 */           if (pickedItem == null || !pickedItem.equals(itemCheck)) {
/* 261 */             ignoreValues.add(Integer.valueOf(aimKey));
/*     */           }
/*     */           
/* 264 */           nItemsCopy.put(itemCheck, Integer.valueOf(((Integer)nItemsCopy.get(itemCheck)).intValue() - 1));
/*     */           
/* 266 */           if (((Integer)nItemsCopy.get(itemCheck)).intValue() == 0) {
/* 267 */             nItemsCopy.remove(itemCheck);
/*     */           }
/* 269 */           copyInventory.put(Integer.valueOf(i), copyInventory.get(Integer.valueOf(aimKey)));
/* 270 */           copyInventory.put(Integer.valueOf(aimKey), itemCheck);
/*     */ 
/*     */           
/* 273 */           if (!((String)copyInventory.get(Integer.valueOf(aimKey))).equals("minecraft:air0")) {
/*     */ 
/*     */ 
/*     */             
/* 277 */             if (i >= startValues + copyInventory.size()) {
/*     */               continue;
/*     */             }
/*     */             
/* 281 */             pickedItem = copyInventory.get(Integer.valueOf(i));
/* 282 */             i--;
/*     */           } else {
/*     */             
/* 285 */             pickedItem = null;
/*     */           } 
/*     */           
/* 288 */           planInventoryCopy.remove(Integer.valueOf(aimKey));
/*     */           continue;
/*     */         } 
/* 291 */         if (pickedItem != null) {
/*     */           
/* 293 */           planMove.add(Integer.valueOf(i));
/* 294 */           copyInventory.put(Integer.valueOf(i), pickedItem);
/*     */           
/* 296 */           pickedItem = null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       continue;
/*     */     } 
/*     */     
/* 304 */     if (planMove.size() != 0 && ((Integer)planMove.get(planMove.size() - 1)).equals(planMove.get(planMove.size() - 2))) {
/* 305 */       planMove.remove(planMove.size() - 1);
/*     */     }
/*     */     
/* 308 */     Object[] keyList = this.containerInv.keySet().toArray();
/*     */ 
/*     */     
/* 311 */     for (int values = 0; values < keyList.length; values++) {
/*     */       
/* 313 */       int itemC = ((Integer)keyList[values]).intValue();
/*     */       
/* 315 */       if (nItemsCopy.containsKey(this.containerInv.get(Integer.valueOf(itemC)))) {
/*     */         
/* 317 */         int start = ((Integer)((Map.Entry)planInventoryCopy.entrySet().stream().filter(x -> ((String)x.getValue()).equals(this.containerInv.get(Integer.valueOf(itemC)))).findFirst().get()).getKey()).intValue();
/*     */         
/* 319 */         if (((Boolean)this.invasive.getValue()).booleanValue() || ((ItemStack)mc.player.openContainer.getInventory().get(start)).isEmpty()) {
/*     */           
/* 321 */           planMove.add(Integer.valueOf(start));
/* 322 */           planMove.add(Integer.valueOf(itemC));
/* 323 */           planMove.add(Integer.valueOf(start));
/*     */           
/* 325 */           nItemsCopy.put(planInventoryCopy.get(Integer.valueOf(start)), Integer.valueOf(((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(start)))).intValue() - 1));
/* 326 */           if (((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(start)))).intValue() == 0) {
/* 327 */             nItemsCopy.remove(planInventoryCopy.get(Integer.valueOf(start)));
/*     */           }
/* 329 */           planInventoryCopy.remove(Integer.valueOf(start));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 336 */     if (((Boolean)this.debugMode.getValue()).booleanValue())
/*     */     {
/* 338 */       for (Iterator<Integer> iterator1 = planMove.iterator(); iterator1.hasNext(); ) { int valuePath = ((Integer)iterator1.next()).intValue();
/* 339 */         MessageBus.printDebug(Integer.toString(valuePath), Boolean.valueOf(false)); }
/*     */     
/*     */     }
/*     */     
/* 343 */     return planMove;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<Integer, String> getInventoryCopy(int startPoint) {
/* 349 */     HashMap<Integer, String> output = new HashMap<>();
/*     */     
/* 351 */     int sizeInventory = mc.player.inventory.mainInventory.size();
/*     */ 
/*     */     
/* 354 */     for (int i = 0; i < sizeInventory; i++) {
/*     */       
/* 356 */       int value = i + startPoint + ((i < 9) ? (sizeInventory - 9) : -9);
/*     */       
/* 358 */       ItemStack item = (ItemStack)mc.player.openContainer.getInventory().get(value);
/*     */       
/* 360 */       output.put(Integer.valueOf(value), ((ResourceLocation)Objects.<ResourceLocation>requireNonNull(item.getItem().getRegistryName())).toString() + item.getMetadata());
/*     */     } 
/*     */     
/* 363 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<Integer, String> getInventoryCopy(int startPoint, HashMap<Integer, String> inventory) {
/* 369 */     HashMap<Integer, String> output = new HashMap<>();
/*     */     
/* 371 */     int sizeInventory = mc.player.inventory.mainInventory.size();
/* 372 */     for (Iterator<Integer> iterator = inventory.keySet().iterator(); iterator.hasNext(); ) { int val = ((Integer)iterator.next()).intValue();
/*     */       
/* 374 */       output.put(Integer.valueOf(val + startPoint + ((val < 9) ? (sizeInventory - 9) : -9)), inventory.get(Integer.valueOf(val))); }
/*     */ 
/*     */     
/* 377 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AutoGear.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
