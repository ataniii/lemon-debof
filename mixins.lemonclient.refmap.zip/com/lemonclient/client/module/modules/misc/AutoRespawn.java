//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketClientStatus;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.client.event.GuiOpenEvent;
/*    */ 
/*    */ @Declaration(name = "AutoRespawn", category = Category.Misc)
/*    */ public class AutoRespawn extends Module {
/*    */   BooleanSetting respawn;
/*    */   BooleanSetting coords;
/*    */   BooleanSetting respawnMessage;
/*    */   StringSetting message;
/*    */   IntegerSetting respawnMessageDelay;
/*    */   
/*    */   public AutoRespawn() {
/* 21 */     this.respawn = registerBoolean("Respawn", false);
/* 22 */     this.coords = registerBoolean("Death Coords", false);
/* 23 */     this.respawnMessage = registerBoolean("Respawn Message", false);
/* 24 */     this.message = registerString("Message", "/kit name");
/* 25 */     this.respawnMessageDelay = registerInteger("Msg Delay(ms)", 0, 0, 5000);
/*    */     
/* 27 */     this.sentRespawnMessage = true;
/*    */ 
/*    */ 
/*    */     
/* 31 */     this.livingDeathEventListener = new Listener(event -> { if (!isEnabled()) return;  if (event.getGui() instanceof net.minecraft.client.gui.GuiGameOver) { this.isDead = true; this.deathPos = PlayerUtil.getPlayerPos(); this.sentRespawnMessage = true; if (((Boolean)this.respawn.getValue()).booleanValue()) { event.setCanceled(true); mc.player.connection.sendPacket((Packet)new CPacketClientStatus(CPacketClientStatus.State.PERFORM_RESPAWN)); }  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean isDead;
/*    */   
/*    */   private boolean sentRespawnMessage;
/*    */   
/*    */   long timeSinceRespawn;
/*    */   
/*    */   BlockPos deathPos;
/*    */   
/*    */   @EventHandler
/*    */   private final Listener<GuiOpenEvent> livingDeathEventListener;
/*    */   
/*    */   public void onUpdate() {
/* 47 */     if (mc.player == null) {
/*    */       return;
/*    */     }
/* 50 */     if (this.isDead && mc.player.isEntityAlive()) {
/* 51 */       if (((Boolean)this.coords.getValue()).booleanValue()) {
/* 52 */         MessageBus.sendMessage("You died at X:" + this.deathPos.getX() + ", Y:" + this.deathPos.getY() + ", Z:" + this.deathPos.getZ() + ".", false);
/*    */       }
/* 54 */       if (((Boolean)this.respawnMessage.getValue()).booleanValue()) {
/* 55 */         this.sentRespawnMessage = false;
/* 56 */         this.timeSinceRespawn = System.currentTimeMillis();
/*    */       } 
/* 58 */       this.isDead = false;
/*    */     } 
/*    */     
/* 61 */     if (!this.sentRespawnMessage && 
/* 62 */       System.currentTimeMillis() - this.timeSinceRespawn > ((Integer)this.respawnMessageDelay.getValue()).intValue()) {
/* 63 */       mc.player.connection.sendPacket((Packet)new CPacketChatMessage(this.message.getText()));
/* 64 */       this.sentRespawnMessage = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AutoRespawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
