//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.monster.EntitySlime;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*    */ 
/*    */ @Declaration(name = "NoKick", category = Category.Misc)
/*    */ public class NoKick extends Module {
/*    */   public BooleanSetting noPacketKick;
/*    */   BooleanSetting noSlimeCrash;
/*    */   
/*    */   public NoKick() {
/* 20 */     this.noPacketKick = registerBoolean("Packet", true);
/* 21 */     this.noSlimeCrash = registerBoolean("Slime", false);
/* 22 */     this.noOffhandCrash = registerBoolean("Offhand", false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     this.receiveListener = new Listener(event -> { if (((Boolean)this.noOffhandCrash.getValue()).booleanValue() && event.getPacket() instanceof SPacketSoundEffect && ((SPacketSoundEffect)event.getPacket()).getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   BooleanSetting noOffhandCrash;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> receiveListener;
/*    */   
/*    */   public void onUpdate() {
/*    */     if (mc.world != null && ((Boolean)this.noSlimeCrash.getValue()).booleanValue())
/*    */       mc.world.loadedEntityList.forEach(entity -> {
/*    */             if (entity instanceof EntitySlime) {
/*    */               EntitySlime slime = (EntitySlime)entity;
/*    */               if (slime.getSlimeSize() > 4)
/*    */                 mc.world.removeEntity(entity); 
/*    */             } 
/*    */           }); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\NoKick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
