//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.client.command.commands.AutoGearCommand;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.inventory.GuiInventory;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Declaration(name = "SortInventory", category = Category.Misc)
/*     */ public class SortInventory
/*     */   extends Module
/*     */ {
/*  37 */   IntegerSetting tickDelay = registerInteger("Tick Delay", 0, 0, 20);
/*  38 */   BooleanSetting confirmSort = registerBoolean("Confirm Sort", true);
/*  39 */   BooleanSetting instaSort = registerBoolean("Insta Sort", false);
/*  40 */   BooleanSetting closeAfter = registerBoolean("Close After", false);
/*  41 */   BooleanSetting infoMsgs = registerBoolean("Info Msgs", true);
/*  42 */   BooleanSetting debugMode = registerBoolean("Debug Mode", false);
/*     */ 
/*     */   
/*  45 */   private HashMap<Integer, String> planInventory = new HashMap<>();
/*  46 */   private HashMap<String, Integer> nItems = new HashMap<>();
/*     */   
/*  48 */   private ArrayList<Integer> sortItems = new ArrayList<>();
/*     */   
/*     */   private int delayTimeTicks;
/*     */   
/*     */   private int stepNow;
/*     */   
/*     */   private boolean openedBefore;
/*     */   
/*     */   private boolean finishSort;
/*     */   
/*     */   private boolean doneBefore;
/*     */   
/*     */   public void onEnable() {
/*  61 */     String curConfigName = AutoGearCommand.getCurrentSet();
/*     */     
/*  63 */     if (curConfigName.equals("")) {
/*  64 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  68 */     if (((Boolean)this.infoMsgs.getValue()).booleanValue()) {
/*  69 */       MessageBus.printDebug("Config " + curConfigName + " actived", Boolean.valueOf(false));
/*     */     }
/*  71 */     String inventoryConfig = AutoGearCommand.getInventoryKit(curConfigName);
/*     */     
/*  73 */     if (inventoryConfig.equals("")) {
/*  74 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     String[] inventoryDivided = inventoryConfig.split(" ");
/*     */     
/*  80 */     this.planInventory = new HashMap<>();
/*  81 */     this.nItems = new HashMap<>();
/*     */     
/*  83 */     for (int i = 0; i < inventoryDivided.length; i++) {
/*     */       
/*  85 */       if (!inventoryDivided[i].contains("air")) {
/*     */         
/*  87 */         this.planInventory.put(Integer.valueOf(i), inventoryDivided[i]);
/*     */         
/*  89 */         if (this.nItems.containsKey(inventoryDivided[i])) {
/*     */           
/*  91 */           this.nItems.put(inventoryDivided[i], Integer.valueOf(((Integer)this.nItems.get(inventoryDivided[i])).intValue() + 1));
/*     */         } else {
/*     */           
/*  94 */           this.nItems.put(inventoryDivided[i], Integer.valueOf(1));
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     this.delayTimeTicks = 0;
/*     */     
/* 100 */     this.openedBefore = this.doneBefore = false;
/*     */     
/* 102 */     if (((Boolean)this.instaSort.getValue()).booleanValue())
/* 103 */       mc.displayGuiScreen((GuiScreen)new GuiInventory((EntityPlayer)mc.player)); 
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 107 */     if (((Boolean)this.infoMsgs.getValue()).booleanValue() && this.planInventory.size() > 0) {
/* 108 */       MessageBus.printDebug("AutoSort Turned Off!", Boolean.valueOf(true));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 113 */     if (this.delayTimeTicks < ((Integer)this.tickDelay.getValue()).intValue()) {
/* 114 */       this.delayTimeTicks++;
/*     */       return;
/*     */     } 
/* 117 */     this.delayTimeTicks = 0;
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (this.planInventory.size() == 0) {
/* 122 */       disable();
/*     */     }
/* 124 */     if (mc.currentScreen instanceof GuiInventory)
/*     */     
/* 126 */     { sortInventoryAlgo(); }
/* 127 */     else { this.openedBefore = false; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void sortInventoryAlgo() {
/* 134 */     if (!this.openedBefore) {
/*     */       
/* 136 */       if (((Boolean)this.infoMsgs.getValue()).booleanValue() && !this.doneBefore) {
/* 137 */         MessageBus.printDebug("Start sorting inventory...", Boolean.valueOf(false));
/*     */       }
/* 139 */       this.sortItems = getInventorySort();
/*     */       
/* 141 */       if (this.sortItems.size() == 0 && !this.doneBefore) {
/* 142 */         this.finishSort = false;
/*     */         
/* 144 */         if (((Boolean)this.infoMsgs.getValue()).booleanValue()) {
/* 145 */           MessageBus.printDebug("Inventory arleady sorted...", Boolean.valueOf(true));
/*     */         }
/* 147 */         if (((Boolean)this.instaSort.getValue()).booleanValue() || ((Boolean)this.closeAfter.getValue()).booleanValue()) {
/* 148 */           mc.player.closeScreen();
/* 149 */           if (((Boolean)this.instaSort.getValue()).booleanValue()) {
/* 150 */             disable();
/*     */           }
/*     */         } 
/*     */       } else {
/* 154 */         this.finishSort = true;
/* 155 */         this.stepNow = 0;
/*     */       } 
/* 157 */       this.openedBefore = true;
/*     */     }
/* 159 */     else if (this.finishSort) {
/*     */ 
/*     */       
/* 162 */       if (this.sortItems.size() != 0) {
/*     */         
/* 164 */         int slotChange = ((Integer)this.sortItems.get(this.stepNow++)).intValue();
/*     */         
/* 166 */         mc.playerController.windowClick(0, (slotChange < 9) ? (slotChange + 36) : slotChange, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */       } 
/*     */       
/* 169 */       if (this.stepNow == this.sortItems.size()) {
/*     */         
/* 171 */         if (((Boolean)this.confirmSort.getValue()).booleanValue() && 
/* 172 */           !this.doneBefore) {
/*     */           
/* 174 */           this.openedBefore = false;
/* 175 */           this.finishSort = false;
/* 176 */           this.doneBefore = true;
/*     */           
/* 178 */           checkLastItem();
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 183 */         this.finishSort = false;
/*     */         
/* 185 */         if (((Boolean)this.infoMsgs.getValue()).booleanValue()) {
/* 186 */           MessageBus.printDebug("Inventory sorted", Boolean.valueOf(false));
/*     */         }
/*     */         
/* 189 */         checkLastItem();
/* 190 */         this.doneBefore = false;
/*     */         
/* 192 */         if (((Boolean)this.instaSort.getValue()).booleanValue() || ((Boolean)this.closeAfter.getValue()).booleanValue()) {
/* 193 */           mc.player.closeScreen();
/* 194 */           if (((Boolean)this.instaSort.getValue()).booleanValue()) {
/* 195 */             disable();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkLastItem() {
/* 204 */     if (this.sortItems.size() != 0) {
/*     */       
/* 206 */       int slotChange = ((Integer)this.sortItems.get(this.sortItems.size() - 1)).intValue();
/*     */       
/* 208 */       if (mc.player.inventory.getStackInSlot(slotChange).isEmpty())
/*     */       {
/* 210 */         mc.playerController.windowClick(0, (slotChange < 9) ? (slotChange + 36) : slotChange, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<Integer> getInventorySort() {
/* 218 */     ArrayList<Integer> planMove = new ArrayList<>();
/*     */     
/* 220 */     ArrayList<String> copyInventory = getInventoryCopy();
/*     */ 
/*     */     
/* 223 */     HashMap<Integer, String> planInventoryCopy = (HashMap<Integer, String>)this.planInventory.clone();
/*     */     
/* 225 */     HashMap<String, Integer> nItemsCopy = (HashMap<String, Integer>)this.nItems.clone();
/*     */     
/* 227 */     ArrayList<Integer> ignoreValues = new ArrayList<>();
/*     */ 
/*     */     
/* 230 */     for (int i = 0; i < this.planInventory.size(); i++) {
/* 231 */       int value = ((Integer)this.planInventory.keySet().toArray()[i]).intValue();
/*     */       
/* 233 */       if (((String)copyInventory.get(value)).equals(planInventoryCopy.get(Integer.valueOf(value)))) {
/*     */         
/* 235 */         ignoreValues.add(Integer.valueOf(value));
/*     */         
/* 237 */         nItemsCopy.put(planInventoryCopy.get(Integer.valueOf(value)), Integer.valueOf(((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(value)))).intValue() - 1));
/*     */         
/* 239 */         if (((Integer)nItemsCopy.get(planInventoryCopy.get(Integer.valueOf(value)))).intValue() == 0) {
/* 240 */           nItemsCopy.remove(planInventoryCopy.get(Integer.valueOf(value)));
/*     */         }
/* 242 */         planInventoryCopy.remove(Integer.valueOf(value));
/*     */       } 
/*     */     } 
/* 245 */     String pickedItem = null;
/*     */ 
/*     */     
/* 248 */     for (int j = 0; j < copyInventory.size(); j++) {
/*     */       
/* 250 */       if (!ignoreValues.contains(Integer.valueOf(j))) {
/*     */         
/* 252 */         String itemCheck = copyInventory.get(j);
/*     */         
/* 254 */         Optional<Map.Entry<Integer, String>> momentAim = planInventoryCopy.entrySet().stream().filter(x -> ((String)x.getValue()).equals(itemCheck)).findFirst();
/*     */         
/* 256 */         if (momentAim.isPresent()) {
/*     */ 
/*     */           
/* 259 */           if (pickedItem == null) {
/* 260 */             planMove.add(Integer.valueOf(j));
/*     */           }
/* 262 */           int aimKey = ((Integer)((Map.Entry)momentAim.get()).getKey()).intValue();
/* 263 */           planMove.add(Integer.valueOf(aimKey));
/*     */           
/* 265 */           if (pickedItem == null || !pickedItem.equals(itemCheck)) {
/* 266 */             ignoreValues.add(Integer.valueOf(aimKey));
/*     */           }
/*     */           
/* 269 */           nItemsCopy.put(itemCheck, Integer.valueOf(((Integer)nItemsCopy.get(itemCheck)).intValue() - 1));
/*     */           
/* 271 */           if (((Integer)nItemsCopy.get(itemCheck)).intValue() == 0) {
/* 272 */             nItemsCopy.remove(itemCheck);
/*     */           }
/* 274 */           copyInventory.set(j, copyInventory.get(aimKey));
/* 275 */           copyInventory.set(aimKey, itemCheck);
/*     */ 
/*     */           
/* 278 */           if (!((String)copyInventory.get(aimKey)).equals("minecraft:air0")) {
/*     */ 
/*     */ 
/*     */             
/* 282 */             if (j >= copyInventory.size()) {
/*     */               continue;
/*     */             }
/*     */             
/* 286 */             pickedItem = copyInventory.get(j);
/* 287 */             j--;
/*     */           } else {
/*     */             
/* 290 */             pickedItem = null;
/*     */           } 
/*     */           
/* 293 */           planInventoryCopy.remove(Integer.valueOf(aimKey));
/*     */           continue;
/*     */         } 
/* 296 */         if (pickedItem != null) {
/*     */           
/* 298 */           planMove.add(Integer.valueOf(j));
/* 299 */           copyInventory.set(j, pickedItem);
/*     */           
/* 301 */           pickedItem = null;
/*     */         } 
/*     */       } 
/*     */       
/*     */       continue;
/*     */     } 
/* 307 */     if (planMove.size() != 0 && ((Integer)planMove.get(planMove.size() - 1)).equals(planMove.get(planMove.size() - 2))) {
/* 308 */       planMove.remove(planMove.size() - 1);
/*     */     }
/*     */ 
/*     */     
/* 312 */     if (((Boolean)this.debugMode.getValue()).booleanValue())
/*     */     {
/* 314 */       for (Iterator<Integer> iterator = planMove.iterator(); iterator.hasNext(); ) { int valuePath = ((Integer)iterator.next()).intValue();
/* 315 */         MessageBus.printDebug(Integer.toString(valuePath), Boolean.valueOf(false)); }
/*     */     
/*     */     }
/*     */     
/* 319 */     return planMove;
/*     */   }
/*     */ 
/*     */   
/*     */   private ArrayList<String> getInventoryCopy() {
/* 324 */     ArrayList<String> output = new ArrayList<>();
/* 325 */     for (ItemStack i : mc.player.inventory.mainInventory) {
/* 326 */       output.add(((ResourceLocation)Objects.<ResourceLocation>requireNonNull(i.getItem().getRegistryName())).toString() + i.getMetadata());
/*     */     }
/* 328 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\SortInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
