//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemFood;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ @Declaration(name = "AutoEat", category = Category.Misc)
/*    */ public class AutoEat extends Module {
/* 17 */   IntegerSetting health = registerInteger("Health", 10, 1, 36);
/* 18 */   BooleanSetting equal = registerBoolean("Equal", false);
/*    */   
/*    */   boolean eating = false;
/*    */   
/*    */   public void onDisable() {
/* 23 */     stopEating();
/*    */   }
/*    */   
/*    */   public void onTick() {
/* 27 */     if (EntityUtil.isDead((Entity)mc.player)) {
/* 28 */       if (this.eating) stopEating(); 
/*    */       return;
/*    */     } 
/* 31 */     if (shouldEat())
/* 32 */     { EnumHand hand = null;
/* 33 */       if (isValid(mc.player.getHeldItemMainhand())) hand = EnumHand.MAIN_HAND; 
/* 34 */       if (isValid(mc.player.getHeldItemOffhand())) hand = EnumHand.OFF_HAND; 
/* 35 */       if (hand != null) { eat(hand); }
/*    */       else
/* 37 */       { int slot = findHotbarFood();
/* 38 */         if (slot != -1) mc.player.inventory.currentItem = slot;  }
/*    */        }
/* 40 */     else if (this.eating) { stopEating(); }
/*    */   
/*    */   }
/*    */   
/*    */   private int findHotbarFood() {
/* 45 */     for (int i = 0; i < 9; i++) {
/* 46 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 47 */       if (stack != ItemStack.EMPTY)
/*    */       {
/*    */         
/* 50 */         if (isValid(stack)) return i;  } 
/*    */     } 
/* 52 */     return -1;
/*    */   }
/*    */   
/*    */   private boolean shouldEat() {
/* 56 */     if (((Boolean)this.equal.getValue()).booleanValue()) return (mc.player.getHealth() + mc.player.getAbsorptionAmount() <= ((Integer)this.health.getValue()).intValue()); 
/* 57 */     return (mc.player.getHealth() + mc.player.getAbsorptionAmount() < ((Integer)this.health.getValue()).intValue());
/*    */   }
/*    */   
/*    */   private void eat(EnumHand hand) {
/* 61 */     if (!this.eating || !mc.player.isHandActive() || mc.player.getActiveHand() != hand) {
/* 62 */       KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
/* 63 */       mc.playerController.processRightClick((EntityPlayer)mc.player, (World)mc.world, hand);
/*    */     } 
/*    */     
/* 66 */     this.eating = true;
/*    */   }
/*    */   
/*    */   private void stopEating() {
/* 70 */     KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
/* 71 */     this.eating = false;
/*    */   }
/*    */   private boolean isValid(ItemStack itemStack) {
/* 74 */     Item item = itemStack.item;
/*    */     
/* 76 */     return (item instanceof ItemFood && item != Items.CHORUS_FRUIT && !isBadFood(itemStack, (ItemFood)item) && mc.player.canEat((item == Items.GOLDEN_APPLE)));
/*    */   }
/*    */   
/*    */   private boolean isBadFood(ItemStack itemStack, ItemFood item) {
/* 80 */     return (item == Items.ROTTEN_FLESH || item == Items.SPIDER_EYE || item == Items.POISONOUS_POTATO || (item == Items.FISH && (itemStack
/*    */ 
/*    */       
/* 83 */       .getMetadata() == 3 || itemStack.getMetadata() == 2)));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AutoEat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
