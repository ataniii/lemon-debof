//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.play.client.CPacketChatMessage;
/*    */ 
/*    */ @Declaration(name = "LemonClient", category = Category.Misc)
/*    */ public class LemonClient extends Module {
/*    */   BooleanSetting commands;
/*    */   String SUFFIX;
/*    */   @EventHandler
/*    */   public Listener<PacketEvent.Send> listener;
/*    */   
/*    */   public LemonClient() {
/* 17 */     this.commands = registerBoolean("Commands", false);
/*    */     
/* 19 */     this.SUFFIX = " �?? ℓємℴภ";
/*    */     
/* 21 */     this.listener = new Listener(event -> { if (event.getPacket() instanceof CPacketChatMessage) { String s = ((CPacketChatMessage)event.getPacket()).getMessage(); if (s.startsWith("/") && !((Boolean)this.commands.getValue()).booleanValue()) return;  if (s.contains(this.SUFFIX) || s.isEmpty()) return;  s = s + this.SUFFIX; if (s.length() >= 256) s = s.substring(0, 256);  ((CPacketChatMessage)event.getPacket()).message = s; }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\LemonClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
