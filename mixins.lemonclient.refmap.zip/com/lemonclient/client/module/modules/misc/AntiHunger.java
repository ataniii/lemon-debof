//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.play.client.CPacketEntityAction;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ 
/*    */ @Declaration(name = "AntiHunger", category = Category.Misc, priority = 999)
/*    */ public class AntiHunger extends Module {
/*    */   BooleanSetting cancelMove;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> sendListener;
/*    */   
/*    */   public AntiHunger() {
/* 15 */     this.cancelMove = registerBoolean("Cancel Spring", false);
/*    */     
/* 17 */     this.sendListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (event.getPacket() instanceof CPacketPlayer.Position) onPacket((CPacketPlayer)event.getPacket());  if (event.getPacket() instanceof CPacketEntityAction && ((Boolean)this.cancelMove.getValue()).booleanValue()) { CPacketEntityAction packet = (CPacketEntityAction)event.getPacket(); if (packet.getAction() == CPacketEntityAction.Action.START_SPRINTING || packet.getAction() == CPacketEntityAction.Action.STOP_SPRINTING) event.cancel();  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void onPacket(CPacketPlayer packet) {
/* 33 */     packet.onGround = ((mc.player.fallDistance <= 0.0F || mc.playerController.isHittingBlock) && mc.player.isElytraFlying());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AntiHunger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
