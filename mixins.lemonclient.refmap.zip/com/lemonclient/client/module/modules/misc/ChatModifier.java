//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.ModeSetting;
/*    */ import com.lemonclient.client.command.CommandManager;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Arrays;
/*    */ import java.util.Date;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.play.client.CPacketChatMessage;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ import net.minecraftforge.client.event.ClientChatReceivedEvent;
/*    */ 
/*    */ @Declaration(name = "ChatModifier", category = Category.Misc)
/*    */ public class ChatModifier extends Module {
/*    */   public BooleanSetting clearBkg;
/*    */   public Pair<Object, Object> watermarkSpecial;
/*    */   BooleanSetting greenText;
/*    */   BooleanSetting chatTimeStamps;
/*    */   ModeSetting format;
/*    */   
/*    */   public ChatModifier() {
/* 25 */     this.clearBkg = registerBoolean("Clear Chat", false);
/*    */     
/* 27 */     this.greenText = registerBoolean("Green Text", false);
/* 28 */     this.chatTimeStamps = registerBoolean("Chat Time Stamps", false);
/* 29 */     this.format = registerMode("Format", Arrays.asList(new String[] { "H24:mm", "H12:mm", "H12:mm a", "H24:mm:ss", "H12:mm:ss", "H12:mm:ss a" }, ), "H24:mm");
/* 30 */     this.decoration = registerMode("Deco", Arrays.asList(new String[] { "< >", "[ ]", "{ }", " " }, ), "[ ]");
/* 31 */     this.color = registerMode("Color", ColorUtil.colors, ChatFormatting.GRAY.getName());
/* 32 */     this.space = registerBoolean("Space", false);
/*    */     
/* 34 */     this.chatReceivedEventListener = new Listener(event -> { if (((Boolean)this.chatTimeStamps.getValue()).booleanValue()) { String decoLeft = ((String)this.decoration.getValue()).equalsIgnoreCase(" ") ? "" : ((String)this.decoration.getValue()).split(" ")[0]; String decoRight = ((String)this.decoration.getValue()).equalsIgnoreCase(" ") ? "" : ((String)this.decoration.getValue()).split(" ")[1]; if (((Boolean)this.space.getValue()).booleanValue()) decoRight = decoRight + " ";  String dateFormat = ((String)this.format.getValue()).replace("H24", "k").replace("H12", "h"); String date = (new SimpleDateFormat(dateFormat)).format(new Date()); TextComponentString time = new TextComponentString(ChatFormatting.getByName((String)this.color.getValue()) + decoLeft + date + decoRight + ChatFormatting.RESET); event.setMessage(time.appendSibling(event.getMessage())); }  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     this.listener = new Listener(event -> { if (((Boolean)this.greenText.getValue()).booleanValue() && event.getPacket() instanceof CPacketChatMessage) { if (((CPacketChatMessage)event.getPacket()).getMessage().startsWith("/") || ((CPacketChatMessage)event.getPacket()).getMessage().startsWith(CommandManager.getCommandPrefix())) return;  String message = ((CPacketChatMessage)event.getPacket()).getMessage(); String prefix = ""; prefix = ">"; String s = prefix + message; if (s.length() > 255) return;  ((CPacketChatMessage)event.getPacket()).message = s; }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   ModeSetting decoration;
/*    */   ModeSetting color;
/*    */   BooleanSetting space;
/*    */   @EventHandler
/*    */   private final Listener<ClientChatReceivedEvent> chatReceivedEventListener;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> listener;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\ChatModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
