package com.lemonclient.client.module.modules.misc;

import com.lemonclient.client.module.Category;
import com.lemonclient.client.module.Module;
import com.lemonclient.client.module.Module.Declaration;

@Declaration(name = "MultiTask", category = Category.Misc)
public class MultiTask extends Module {}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\MultiTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */