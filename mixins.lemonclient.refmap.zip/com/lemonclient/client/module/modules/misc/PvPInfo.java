//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.ColorUtil;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.manager.managers.TotemPopManager;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ @Declaration(name = "PvPInfo", category = Category.Misc)
/*     */ public class PvPInfo extends Module {
/*  26 */   BooleanSetting visualRange = registerBoolean("Visual Range", false);
/*  27 */   BooleanSetting coords = registerBoolean("Coords", true, () -> (Boolean)this.visualRange.getValue());
/*  28 */   BooleanSetting pearlAlert = registerBoolean("Pearl Alert", false);
/*  29 */   BooleanSetting strengthDetect = registerBoolean("Strength Detect", false);
/*  30 */   BooleanSetting weaknessDetect = registerBoolean("Weakness Detect", false);
/*  31 */   BooleanSetting popCounter = registerBoolean("Pop Counter", false);
/*  32 */   BooleanSetting friend = registerBoolean("My Friend", false);
/*  33 */   BooleanSetting sharp32 = registerBoolean("sharp32", true);
/*  34 */   ModeSetting type = registerMode("Visual Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  35 */   ModeSetting type1 = registerMode("Pearl Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  36 */   ModeSetting type2 = registerMode("Strength Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  37 */   ModeSetting type3 = registerMode("Weakness Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  38 */   ModeSetting type4 = registerMode("Pop Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  39 */   ModeSetting type5 = registerMode("32k Type", Arrays.asList(new String[] { "Friend", "Enemy", "All" }, ), "All");
/*  40 */   ModeSetting self = registerMode("Self", Arrays.asList(new String[] { "I", "Name", "Disable" }, ), "Name");
/*  41 */   ModeSetting chatColor = registerMode("Color", ColorUtil.colors, "Light Purple");
/*  42 */   ModeSetting nameColor = registerMode("Name Color", ColorUtil.colors, "Light Purple");
/*  43 */   ModeSetting friColor = registerMode("Friend Color", ColorUtil.colors, "Light Purple");
/*  44 */   ModeSetting numberColor = registerMode("Number Color", ColorUtil.colors, "Light Purple");
/*     */   
/*  46 */   List<Entity> knownPlayers = new ArrayList<>();
/*  47 */   List<Entity> antiPearlList = new ArrayList<>();
/*     */   List<Entity> players;
/*     */   List<Entity> pearls;
/*  50 */   private final Set<EntityPlayer> strengthPlayers = Collections.newSetFromMap(new WeakHashMap<>());
/*  51 */   private final Set<EntityPlayer> weaknessPlayers = Collections.newSetFromMap(new WeakHashMap<>());
/*  52 */   private final Set<EntityPlayer> sword = Collections.newSetFromMap(new WeakHashMap<>());
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  56 */     if (mc.player == null || mc.world == null) {
/*     */       return;
/*     */     }
/*  59 */     TotemPopManager.INSTANCE.sendMsgs = ((Boolean)this.popCounter.getValue()).booleanValue();
/*  60 */     if (((Boolean)this.popCounter.getValue()).booleanValue()) {
/*  61 */       TotemPopManager.INSTANCE.chatFormatting = ColorUtil.textToChatFormatting(this.chatColor);
/*  62 */       TotemPopManager.INSTANCE.nameFormatting = ColorUtil.textToChatFormatting(this.nameColor);
/*  63 */       TotemPopManager.INSTANCE.friFormatting = ColorUtil.textToChatFormatting(this.friColor);
/*  64 */       TotemPopManager.INSTANCE.numberFormatting = ColorUtil.textToChatFormatting(this.numberColor);
/*  65 */       TotemPopManager.INSTANCE.friend = ((Boolean)this.friend.getValue()).booleanValue();
/*  66 */       TotemPopManager.INSTANCE.self = (String)this.self.getValue();
/*  67 */       TotemPopManager.INSTANCE.type4 = (String)this.type4.getValue();
/*     */     } 
/*  69 */     if (((Boolean)this.visualRange.getValue()).booleanValue()) {
/*  70 */       this.players = (List<Entity>)mc.world.playerEntities.stream().filter(entity -> !entity.getName().equals(mc.player.getName())).collect(Collectors.toList());
/*     */       try {
/*  72 */         for (Entity e : this.players) {
/*  73 */           if (!e.getName().equalsIgnoreCase("fakeplayer") && 
/*  74 */             !this.knownPlayers.contains(e)) {
/*  75 */             this.knownPlayers.add(e);
/*  76 */             String xyz = ((Boolean)this.coords.getValue()).booleanValue() ? (" at x:" + (int)e.posX + " y:" + (int)e.posY + " z:" + (int)e.posZ) : "";
/*  77 */             String name = e.getName();
/*  78 */             if (name.equals("") || name.equals(" "))
/*  79 */               return;  if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type.getValue()).equals("Enemy"))) {
/*  80 */               MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.chatColor) + "Found (" + ColorUtil.textToChatFormatting(this.friColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + ")" + xyz, Notification.Type.INFO, "VisualRange" + name, 2000);
/*     */             }
/*  82 */             if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type.getValue()).equals("Friend")) {
/*  83 */               MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.chatColor) + "Found (" + ColorUtil.textToChatFormatting(this.nameColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + ")" + xyz, Notification.Type.INFO, "VisualRange" + name, 2000);
/*     */             }
/*     */           } 
/*     */         } 
/*  87 */       } catch (Exception exception) {}
/*     */       try {
/*  89 */         for (Entity e : this.knownPlayers) {
/*  90 */           if (!e.getName().equalsIgnoreCase("fakeplayer") && 
/*  91 */             !this.players.contains(e)) {
/*  92 */             this.knownPlayers.remove(e);
/*  93 */             String xyz = ((Boolean)this.coords.getValue()).booleanValue() ? (" at x:" + (int)e.posX + " y:" + (int)e.posY + " z:" + (int)e.posZ) : "";
/*  94 */             String name = e.getName();
/*  95 */             if (name.equals("") || name.equals(" "))
/*     */               return; 
/*  97 */             if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type.getValue()).equals("Enemy"))) {
/*  98 */               MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.chatColor) + "Gone (" + ColorUtil.textToChatFormatting(this.friColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + ")" + xyz, Notification.Type.INFO, "VisualRange" + name, 2000);
/*     */             }
/* 100 */             if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type.getValue()).equals("Friend")) {
/* 101 */               MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.chatColor) + "Gone (" + ColorUtil.textToChatFormatting(this.nameColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + ")" + xyz, Notification.Type.INFO, "VisualRange" + name, 2000);
/*     */             }
/*     */           } 
/*     */         } 
/* 105 */       } catch (Exception exception) {}
/*     */     } 
/* 107 */     if (((Boolean)this.pearlAlert.getValue()).booleanValue()) {
/* 108 */       this.pearls = (List<Entity>)mc.world.loadedEntityList.stream().filter(e -> e instanceof net.minecraft.entity.item.EntityEnderPearl).collect(Collectors.toList());
/*     */       try {
/* 110 */         for (Entity e : this.pearls) {
/* 111 */           if (e instanceof net.minecraft.entity.item.EntityEnderPearl && 
/* 112 */             !e.getEntityWorld().getClosestPlayerToEntity(e, 3.0D).getName().equalsIgnoreCase("fakeplayer") && 
/* 113 */             !this.antiPearlList.contains(e)) {
/* 114 */             this.antiPearlList.add(e);
/* 115 */             String faceing = e.getHorizontalFacing().toString();
/* 116 */             if (faceing.equals("west")) {
/* 117 */               faceing = "east";
/* 118 */             } else if (faceing.equals("east")) {
/* 119 */               faceing = "west";
/*     */             } 
/* 121 */             if (mc.player.getName().equals(e.getEntityWorld().getClosestPlayerToEntity(e, 3.0D).getName()) && ((String)this.self.getValue()).equals("Disable")) {
/*     */               return;
/*     */             }
/* 124 */             String name = (e.getEntityWorld().getClosestPlayerToEntity(e, 3.0D).getName().equals(mc.player.getName()) && ((String)this.self.getValue()).equals("I")) ? "I" : e.getEntityWorld().getClosestPlayerToEntity(e, 3.0D).getName();
/* 125 */             if (name.equals("") || name.equals(" "))
/*     */               return; 
/* 127 */             if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type1.getValue()).equals("Enemy"))) {
/* 128 */               MessageBus.sendClientPrefixMessage(ColorUtil.textToChatFormatting(this.friColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + " has just thrown a pearl! (" + faceing + ")", Notification.Type.INFO);
/*     */             }
/* 130 */             if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type1.getValue()).equals("Friend")) {
/* 131 */               MessageBus.sendClientPrefixMessage(ColorUtil.textToChatFormatting(this.nameColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + " has just thrown a pearl! (" + faceing + ")", Notification.Type.INFO);
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/* 136 */       } catch (Exception exception) {}
/*     */     } 
/* 138 */     if (((Boolean)this.strengthDetect.getValue()).booleanValue()) {
/* 139 */       for (EntityPlayer player : mc.world.playerEntities) {
/* 140 */         if (player.getName().equalsIgnoreCase("fakeplayer"))
/* 141 */           continue;  if (player.isPotionActive(MobEffects.STRENGTH) && !this.strengthPlayers.contains(player)) {
/* 142 */           if (mc.player.getName().equals(player.getName()) && ((String)this.self.getValue()).equals("Disable"))
/* 143 */             return;  String str = (player.getName().equals(mc.player.getName()) && ((String)this.self.getValue()).equals("I")) ? "I" : player.getName();
/* 144 */           if (str.equals("") || str.equals(" "))
/*     */             return; 
/* 146 */           if (str.equals("I") || (SocialManager.isFriend(str) && !((String)this.type2.getValue()).equals("Enemy"))) {
/* 147 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.friColor) + str + ColorUtil.textToChatFormatting(this.chatColor) + " has drank strength", Notification.Type.INFO, "Strength" + str, 2000);
/*     */           }
/* 149 */           if (!str.equals("I") && !SocialManager.isFriend(str) && !((String)this.type2.getValue()).equals("Friend")) {
/* 150 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + str + ChatFormatting.RED + " has drank strength", Notification.Type.INFO, "Strength" + str, 2000);
/*     */           }
/* 152 */           this.strengthPlayers.add(player);
/*     */         } 
/* 154 */         if (!this.strengthPlayers.contains(player)) {
/*     */           continue;
/*     */         }
/* 157 */         if (player.isPotionActive(MobEffects.STRENGTH)) {
/*     */           continue;
/*     */         }
/* 160 */         if (mc.player.getName().equals(player.getName()) && ((String)this.self.getValue()).equals("Disable"))
/* 161 */           return;  String name = (player.getName().equals(mc.player.getName()) && ((String)this.self.getValue()).equals("I")) ? "I" : player.getName();
/* 162 */         if (name.equals("") || name.equals(" "))
/*     */           return; 
/* 164 */         if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type2.getValue()).equals("Enemy"))) {
/* 165 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.friColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + " no longer has strength", Notification.Type.INFO, "Strength" + name, 2000);
/*     */         }
/* 167 */         if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type2.getValue()).equals("Friend")) {
/* 168 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + name + ChatFormatting.GREEN + " no longer has strength", Notification.Type.INFO, "Strength" + name, 2000);
/*     */         }
/* 170 */         this.strengthPlayers.remove(player);
/*     */       } 
/*     */     }
/* 173 */     if (((Boolean)this.weaknessDetect.getValue()).booleanValue()) {
/* 174 */       for (EntityPlayer player : mc.world.playerEntities) {
/* 175 */         if (player.getName().equalsIgnoreCase("FakePlayer"))
/* 176 */           continue;  if (player.isPotionActive(MobEffects.WEAKNESS) && !this.weaknessPlayers.contains(player)) {
/* 177 */           if (mc.player.getName().equals(player.getName()) && ((String)this.self.getValue()).equals("Disable"))
/* 178 */             return;  String str = (player.getName().equals(mc.player.getName()) && ((String)this.self.getValue()).equals("I")) ? "I" : player.getName();
/* 179 */           if (str.isEmpty() || str.equals(" "))
/*     */             return; 
/* 181 */           if (str.equals("I") || (SocialManager.isFriend(str) && !((String)this.type3.getValue()).equals("Enemy"))) {
/* 182 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.friColor) + str + ColorUtil.textToChatFormatting(this.chatColor) + " has drank weekness", Notification.Type.INFO, "Weakness" + str, 2000);
/*     */           }
/* 184 */           if (!str.equals("I") && !SocialManager.isFriend(str) && !((String)this.type3.getValue()).equals("Friend")) {
/* 185 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + str + ChatFormatting.GREEN + " has drank weekness", Notification.Type.INFO, "Weakness" + str, 2000);
/*     */           }
/* 187 */           this.weaknessPlayers.add(player);
/*     */         } 
/* 189 */         if (!this.weaknessPlayers.contains(player)) {
/*     */           continue;
/*     */         }
/* 192 */         if (player.isPotionActive(MobEffects.WEAKNESS)) {
/*     */           continue;
/*     */         }
/* 195 */         if (mc.player.getName().equals(player.getName()) && ((String)this.self.getValue()).equals("Disable"))
/* 196 */           return;  String name = (player.getName().equals(mc.player.getName()) && ((String)this.self.getValue()).equals("I")) ? "I" : player.getName();
/* 197 */         if (name.equals("") || name.equals(" "))
/*     */           return; 
/* 199 */         if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type3.getValue()).equals("Enemy"))) {
/* 200 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.friColor) + name + ColorUtil.textToChatFormatting(this.chatColor) + " no longer has weekness", Notification.Type.INFO, "Weakness" + name, 2000);
/*     */         }
/* 202 */         if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type3.getValue()).equals("Friend")) {
/* 203 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + name + ChatFormatting.RED + " no longer has weekness", Notification.Type.INFO, "Weakness" + name, 2000);
/*     */         }
/* 205 */         this.weaknessPlayers.remove(player);
/*     */       } 
/*     */     }
/* 208 */     if (((Boolean)this.sharp32.getValue()).booleanValue()) {
/* 209 */       for (EntityPlayer player : mc.world.playerEntities) {
/* 210 */         if (player.getName().equalsIgnoreCase("fakeplayer") || player.getName().equals(mc.player.getName()))
/* 211 */           continue;  if (is32k(player.itemStackMainHand) && !this.sword.contains(player)) {
/* 212 */           String str = player.getName();
/* 213 */           if (str.equals("") || str.equals(" "))
/*     */             return; 
/* 215 */           if (str.equals("I") || (SocialManager.isFriend(str) && !((String)this.type5.getValue()).equals("Enemy"))) {
/* 216 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + str + " is " + ColorUtil.textToChatFormatting(this.chatColor) + "holding a 32k", Notification.Type.INFO, "32k" + str, 2000);
/*     */           }
/* 218 */           if (!str.equals("I") && !SocialManager.isFriend(str) && !((String)this.type5.getValue()).equals("Friend")) {
/* 219 */             MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + str + " is " + ChatFormatting.RED + "holding" + ColorUtil.textToChatFormatting(this.chatColor) + " a 32k", Notification.Type.INFO, "32k" + str, 2000);
/*     */           }
/* 221 */           this.sword.add(player);
/*     */         } 
/* 223 */         if (!this.sword.contains(player)) {
/*     */           continue;
/*     */         }
/* 226 */         if (is32k(player.itemStackMainHand)) {
/*     */           continue;
/*     */         }
/* 229 */         String name = player.getName();
/* 230 */         if (name.equals("") || name.equals(" "))
/*     */           return; 
/* 232 */         if (name.equals("I") || (SocialManager.isFriend(name) && !((String)this.type5.getValue()).equals("Enemy"))) {
/* 233 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.friColor) + name + " is " + ColorUtil.textToChatFormatting(this.chatColor) + "no longer holding a 32k", Notification.Type.INFO, "32k" + name, 2000);
/*     */         }
/* 235 */         if (!name.equals("I") && !SocialManager.isFriend(name) && !((String)this.type5.getValue()).equals("Friend")) {
/* 236 */           MessageBus.sendClientDeleteMessage(ColorUtil.textToChatFormatting(this.nameColor) + name + " is " + ChatFormatting.GREEN + "no longer holding" + ColorUtil.textToChatFormatting(this.chatColor) + " a 32k", Notification.Type.INFO, "32k" + name, 2000);
/*     */         }
/* 238 */         this.sword.remove(player);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean is32k(ItemStack stack) {
/* 245 */     if (stack.getItem() instanceof net.minecraft.item.ItemSword) {
/* 246 */       NBTTagList enchants = stack.getEnchantmentTagList();
/* 247 */       for (int i = 0; i < enchants.tagCount(); i++) {
/* 248 */         if (enchants.getCompoundTagAt(i).getShort("lvl") >= 1000) {
/* 249 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 253 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 258 */     this.knownPlayers.clear();
/* 259 */     TotemPopManager.INSTANCE.sendMsgs = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\PvPInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
