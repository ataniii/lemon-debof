//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ import club.minnced.discord.rpc.DiscordEventHandlers;
/*     */ import club.minnced.discord.rpc.DiscordRPC;
/*     */ import club.minnced.discord.rpc.DiscordRichPresence;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.multiplayer.ServerData;
/*     */ import net.minecraftforge.client.event.ClientChatReceivedEvent;
/*     */ 
/*     */ @Declaration(name = "DiscordRPC", category = Category.Misc)
/*     */ public class DiscordRPCModule extends Module {
/*     */   private static final String applicationId = "899193061324775454";
/*     */   BooleanSetting PlayerID;
/*     */   BooleanSetting ServerIp;
/*     */   BooleanSetting coords;
/*     */   private final DiscordRPC discordRPC;
/*     */   
/*     */   public DiscordRPCModule() {
/*  19 */     this.PlayerID = registerBoolean("Player ID", true);
/*  20 */     this.ServerIp = registerBoolean("Server IP", true);
/*  21 */     this.coords = registerBoolean("Coords", true);
/*  22 */     this.discordRPC = DiscordRPC.INSTANCE;
/*  23 */     this.handlers = new DiscordEventHandlers();
/*  24 */     this.presence = new DiscordRichPresence();
/*     */ 
/*     */ 
/*     */     
/*  28 */     this.listener = new Listener(event -> lastChat = event.getMessage().getUnformattedText(), new java.util.function.Predicate[0]);
/*     */   }
/*     */   DiscordEventHandlers handlers; DiscordRichPresence presence; static String lastChat; static ServerData svr; @EventHandler
/*     */   private final Listener<ClientChatReceivedEvent> listener;
/*     */   public void onEnable() {
/*  33 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  38 */     this.discordRPC.Discord_Shutdown();
/*  39 */     this.discordRPC.Discord_ClearPresence();
/*     */   }
/*     */   
/*     */   private void init() {
/*  43 */     this.discordRPC.Discord_Initialize("899193061324775454", this.handlers, true, "");
/*  44 */     this.presence.startTimestamp = System.currentTimeMillis() / 1000L;
/*  45 */     this.presence.state = "Main Menu";
/*  46 */     if (((Boolean)this.PlayerID.getValue()).booleanValue()) {
/*  47 */       this.presence.details = ID();
/*     */     } else {
/*  49 */       this.presence.details = "";
/*     */     } 
/*  51 */     this.presence.largeImageKey = "lemonclient";
/*  52 */     this.presence.largeImageText = "Lemon Client v0.0.8";
/*  53 */     this.discordRPC.Discord_UpdatePresence(this.presence);
/*  54 */     (new Thread(() -> {
/*     */           while (!Thread.currentThread().isInterrupted() && isEnabled()) {
/*     */             try {
/*     */               this.discordRPC.Discord_RunCallbacks();
/*     */               
/*     */               if (((Boolean)this.PlayerID.getValue()).booleanValue()) {
/*     */                 this.presence.details = ID();
/*     */               } else {
/*     */                 this.presence.details = "";
/*     */               } 
/*     */               
/*     */               this.presence.state = "";
/*     */               if (((Boolean)this.coords.getValue()).booleanValue() && mc.player != null && mc.world != null) {
/*     */                 String dimension;
/*     */                 this.presence.smallImageKey = "lazy_crocodile";
/*     */                 if (dimension() == -1) {
/*     */                   dimension = "Nether";
/*     */                 } else if (dimension() == 0) {
/*     */                   dimension = "Overworld";
/*     */                 } else {
/*     */                   dimension = "The End";
/*     */                 } 
/*     */                 this.presence.smallImageText = "X:" + (int)mc.player.posX + " Y:" + (int)mc.player.posY + " Z:" + (int)mc.player.posZ + " (" + dimension + ")";
/*     */               } else {
/*     */                 this.presence.smallImageText = "";
/*     */               } 
/*     */               if (mc.isIntegratedServerRunning()) {
/*     */                 this.presence.state = "Single Player";
/*     */               } else if (mc.getCurrentServerData() != null) {
/*     */                 svr = mc.getCurrentServerData();
/*     */                 if (!svr.serverIP.equals("")) {
/*     */                   if (((Boolean)this.ServerIp.getValue()).booleanValue()) {
/*     */                     this.presence.state = "Multi Player (" + svr.serverIP + ")";
/*     */                     if (svr.serverIP.equals("2b2t.org")) {
/*     */                       try {
/*     */                         if (lastChat.contains("Position in queue: ")) {
/*     */                           this.presence.details += " (in queue" + Integer.parseInt(lastChat.substring(19)) + ")";
/*     */                         }
/*  92 */                       } catch (Throwable e) {
/*     */                         e.printStackTrace();
/*     */                       } 
/*     */                     }
/*     */                   } else {
/*     */                     this.presence.state = "Multi Player";
/*     */                   } 
/*     */                 }
/*     */               } else {
/*     */                 this.presence.details = "Main Menu";
/*     */               } 
/*     */               
/*     */               this.discordRPC.Discord_UpdatePresence(this.presence);
/* 105 */             } catch (Exception e2) {
/*     */               e2.printStackTrace();
/*     */             } 
/*     */             
/*     */             try {
/*     */               Thread.sleep(5000L);
/* 111 */             } catch (InterruptedException e3) {
/*     */               e3.printStackTrace();
/*     */             } 
/*     */           } 
/* 115 */         }"Discord-RPC-Callback-Handler")).start();
/*     */   }
/*     */   private int dimension() {
/* 118 */     return mc.player.dimension;
/*     */   }
/*     */   public static String ID() {
/* 121 */     if (mc.player != null)
/* 122 */       return mc.player.getName(); 
/* 123 */     return mc.getSession().getUsername();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\DiscordRPCModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
