//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.event.events.RenderEntityEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import net.minecraft.network.play.server.SPacketSoundEffect;
/*    */ 
/*    */ @Declaration(name = "AntiLag", category = Category.Misc)
/*    */ public class NoLag extends Module {
/*    */   BooleanSetting particles;
/*    */   BooleanSetting effect;
/*    */   BooleanSetting soundEffect;
/*    */   BooleanSetting skulls;
/*    */   BooleanSetting tnt;
/*    */   BooleanSetting parrots;
/*    */   BooleanSetting spawn;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Receive> receiveListener;
/*    */   @EventHandler
/*    */   private final Listener<RenderEntityEvent> renderEntityEventListener;
/*    */   
/*    */   public NoLag() {
/* 22 */     this.particles = registerBoolean("Particles", true);
/* 23 */     this.effect = registerBoolean("Effect", true);
/* 24 */     this.soundEffect = registerBoolean("Sound Effect", true);
/* 25 */     this.skulls = registerBoolean("Skull", true);
/* 26 */     this.tnt = registerBoolean("Tnt", true);
/* 27 */     this.parrots = registerBoolean("Parrot", true);
/* 28 */     this.spawn = registerBoolean("Spawn", true);
/*    */     
/* 30 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketParticles && ((Boolean)this.particles.getValue()).booleanValue()) event.cancel();  if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketEffect && ((Boolean)this.effect.getValue()).booleanValue()) event.cancel();  if (event.getPacket() instanceof SPacketSoundEffect && ((Boolean)this.soundEffect.getValue()).booleanValue()) { SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket(); if (packet.getCategory() == SoundCategory.PLAYERS && packet.getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) event.cancel();  if (packet.getCategory() == SoundCategory.WEATHER && packet.getSound() == SoundEvents.ENTITY_LIGHTNING_THUNDER) event.cancel();  }  if (event.getPacket() instanceof SPacketSpawnMob && ((Boolean)this.spawn.getValue()).booleanValue()) { SPacketSpawnMob packet = (SPacketSpawnMob)event.getPacket(); if (packet.getEntityType() == 55) event.cancel();  }  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     this.renderEntityEventListener = new Listener(event -> { if (((Boolean)this.skulls.getValue()).booleanValue() && event.getEntity() instanceof net.minecraft.entity.projectile.EntityWitherSkull) event.cancel();  if (((Boolean)this.tnt.getValue()).booleanValue() && event.getEntity() instanceof net.minecraft.entity.item.EntityTNTPrimed) event.cancel();  if (((Boolean)this.parrots.getValue()).booleanValue() && event.getEntity() instanceof net.minecraft.entity.passive.EntityParrot) event.cancel();  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 75 */     mc.renderGlobal.loadRenderers();
/* 76 */     super.onDisable();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\NoLag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
