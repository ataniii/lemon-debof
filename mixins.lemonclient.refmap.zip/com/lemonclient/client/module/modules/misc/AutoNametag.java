//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumHand;
/*     */ 
/*     */ 
/*     */ @Declaration(name = "AutoNametag", category = Category.Misc)
/*     */ public class AutoNametag
/*     */   extends Module
/*     */ {
/*  23 */   ModeSetting modeSetting = registerMode("Mode", Arrays.asList(new String[] { "Any", "Wither" }, ), "Wither");
/*  24 */   DoubleSetting range = registerDouble("Range", 3.5D, 0.0D, 10.0D);
/*  25 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  26 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*  27 */   BooleanSetting disable = registerBoolean("Auto Disable", true);
/*     */   
/*  29 */   private String currentName = "";
/*  30 */   private int currentSlot = -1;
/*     */   
/*     */   public void onUpdate() {
/*  33 */     findNameTags();
/*  34 */     useNameTag();
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/*  39 */     if (slot > -1 && slot < 9 && (
/*  40 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*  41 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/*  43 */       { mc.player.inventory.currentItem = slot; }
/*     */       
/*  45 */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void useNameTag() {
/*  51 */     int originalSlot = mc.player.inventory.currentItem;
/*  52 */     for (Entity w : mc.world.getLoadedEntityList()) {
/*  53 */       switch ((String)this.modeSetting.getValue()) {
/*     */         case "Wither":
/*  55 */           if (w instanceof net.minecraft.entity.boss.EntityWither && !w.getDisplayName().getUnformattedText().equals(this.currentName) && 
/*  56 */             mc.player.getDistance(w) <= ((Double)this.range.getValue()).doubleValue()) {
/*  57 */             int oldslot = mc.player.inventory.currentItem;
/*  58 */             selectNameTags();
/*  59 */             mc.playerController.interactWithEntity((EntityPlayer)mc.player, w, EnumHand.MAIN_HAND);
/*  60 */             switchTo(oldslot);
/*     */           } 
/*     */ 
/*     */         
/*     */         case "Any":
/*  65 */           if ((w instanceof net.minecraft.entity.monster.EntityMob || w instanceof net.minecraft.entity.passive.EntityAnimal) && !w.getDisplayName().getUnformattedText().equals(this.currentName) && 
/*  66 */             mc.player.getDistance(w) <= ((Double)this.range.getValue()).doubleValue()) {
/*  67 */             int oldslot = mc.player.inventory.currentItem;
/*  68 */             selectNameTags();
/*  69 */             mc.playerController.interactWithEntity((EntityPlayer)mc.player, w, EnumHand.MAIN_HAND);
/*  70 */             switchTo(oldslot);
/*     */           } 
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/*  76 */     mc.player.inventory.currentItem = originalSlot;
/*     */   }
/*     */   
/*     */   private void selectNameTags() {
/*  80 */     if (this.currentSlot == -1 || !isNametag(this.currentSlot)) {
/*  81 */       if (((Boolean)this.disable.getValue()).booleanValue()) disable();
/*     */       
/*     */       return;
/*     */     } 
/*  85 */     switchTo(this.currentSlot);
/*     */   }
/*     */   
/*     */   private void findNameTags() {
/*  89 */     for (int i = 0; i < 9; i++) {
/*  90 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*  91 */       if (stack != ItemStack.EMPTY && !(stack.getItem() instanceof net.minecraft.item.ItemBlock) && 
/*  92 */         isNametag(i)) {
/*  93 */         this.currentName = stack.getDisplayName();
/*  94 */         this.currentSlot = i;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isNametag(int i) {
/* 101 */     ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 102 */     Item tag = stack.getItem();
/* 103 */     return (tag instanceof net.minecraft.item.ItemNameTag && !stack.getDisplayName().equals("Name Tag"));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AutoNametag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
