//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ @Declaration(name = "Peek", category = Category.Misc)
/*    */ public class ShulkerBypass extends Module {
/* 13 */   BooleanSetting notifications = registerBoolean("Notification", false);
/* 14 */   BooleanSetting shulker = registerBoolean("Shulker", true);
/* 15 */   IntegerSetting cmdDelay = registerInteger("Shulker Delay", 0, 0, 20);
/* 16 */   BooleanSetting map = registerBoolean("Map", true);
/* 17 */   BooleanSetting book = registerBoolean("Book", true);
/*    */   public static boolean notification;
/*    */   public static boolean shulkers;
/*    */   
/*    */   public void onEnable() {
/* 22 */     if ((Minecraft.getMinecraft()).player == null)
/* 23 */       return;  MessageBus.sendMessage("[ShulkerBypass] To use this throw a shulker on the ground", Notification.Type.INFO, "Peek", 3, ((Boolean)this.notifications.getValue()).booleanValue());
/*    */   }
/*    */   public static boolean maps; public static boolean books; public static int delay;
/*    */   
/*    */   public void onUpdate() {
/* 28 */     notification = ((Boolean)this.notifications.getValue()).booleanValue();
/* 29 */     delay = ((Integer)this.cmdDelay.getValue()).intValue();
/* 30 */     shulkers = ((Boolean)this.shulker.getValue()).booleanValue();
/* 31 */     maps = ((Boolean)this.map.getValue()).booleanValue();
/* 32 */     books = ((Boolean)this.book.getValue()).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\ShulkerBypass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
