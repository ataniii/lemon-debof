//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.Pair;
/*     */ import com.lemonclient.api.util.player.InventoryUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.NonNullList;
/*     */ 
/*     */ @Declaration(name = "HotbarRefill", category = Category.Misc)
/*     */ public class HotbarRefill extends Module {
/*  23 */   IntegerSetting threshold = registerInteger("Threshold", 32, 1, 63);
/*  24 */   IntegerSetting tickDelay = registerInteger("Tick Delay", 2, 1, 10);
/*     */   
/*  26 */   private int delayStep = 0;
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  30 */     if (mc.player == null) {
/*     */       return;
/*     */     }
/*     */     
/*  34 */     if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer) {
/*     */       return;
/*     */     }
/*     */     
/*  38 */     if (this.delayStep < ((Integer)this.tickDelay.getValue()).intValue()) {
/*  39 */       this.delayStep++;
/*     */       return;
/*     */     } 
/*  42 */     this.delayStep = 0;
/*     */ 
/*     */     
/*  45 */     Pair<Integer, Integer> slots = findReplenishableHotbarSlot();
/*     */     
/*  47 */     if (slots == null) {
/*     */       return;
/*     */     }
/*     */     
/*  51 */     int inventorySlot = ((Integer)slots.getKey()).intValue();
/*  52 */     int hotbarSlot = ((Integer)slots.getValue()).intValue();
/*     */     
/*  54 */     mc.playerController.windowClick(0, inventorySlot, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Pair<Integer, Integer> findReplenishableHotbarSlot() {
/*  70 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/*  72 */     for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
/*  73 */       ItemStack stack = nonNullList.get(hotbarSlot);
/*     */       
/*  75 */       if (stack.isStackable())
/*     */       {
/*     */ 
/*     */         
/*  79 */         if (!stack.isEmpty && stack.getItem() != Items.AIR)
/*     */         {
/*     */ 
/*     */           
/*  83 */           if (stack.stackSize < stack.getMaxStackSize() && stack.stackSize <= ((Integer)this.threshold.getValue()).intValue()) {
/*     */ 
/*     */ 
/*     */             
/*  87 */             int inventorySlot = findCompatibleInventorySlot(stack);
/*     */             
/*  89 */             if (inventorySlot != -1)
/*     */             {
/*     */               
/*  92 */               return new Pair(Integer.valueOf(inventorySlot), Integer.valueOf(hotbarSlot)); } 
/*     */           }  }  } 
/*  94 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int findCompatibleInventorySlot(ItemStack hotbarStack) {
/* 100 */     Item item = hotbarStack.getItem();
/* 101 */     if (item instanceof ItemBlock) {
/* 102 */       potentialSlots = InventoryUtil.findAllBlockSlots(((ItemBlock)item).getBlock().getClass());
/*     */     } else {
/* 104 */       potentialSlots = InventoryUtil.findAllItemSlots(item.getClass());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     List<Integer> potentialSlots = (List<Integer>)potentialSlots.stream().filter(integer -> (integer.intValue() > 8 && integer.intValue() < 36)).sorted(Comparator.comparingInt(interger -> -interger.intValue())).collect(Collectors.toList());
/*     */     
/* 112 */     for (Iterator<Integer> iterator = potentialSlots.iterator(); iterator.hasNext(); ) { int slot = ((Integer)iterator.next()).intValue();
/* 113 */       if (isCompatibleStacks(hotbarStack, mc.player.inventory.getStackInSlot(slot))) {
/* 114 */         return slot;
/*     */       } }
/*     */     
/* 117 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isCompatibleStacks(ItemStack stack1, ItemStack stack2) {
/* 122 */     if (!stack1.getItem().equals(stack2.getItem())) {
/* 123 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 127 */     if (stack1.getItem() instanceof ItemBlock && stack2.getItem() instanceof ItemBlock) {
/* 128 */       Block block1 = ((ItemBlock)stack1.getItem()).getBlock();
/* 129 */       Block block2 = ((ItemBlock)stack2.getItem()).getBlock();
/* 130 */       if (!block1.material.equals(block2.material)) {
/* 131 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 136 */     if (!stack1.getDisplayName().equals(stack2.getDisplayName())) {
/* 137 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 142 */     if (stack1.getItemDamage() != stack2.getItemDamage()) {
/* 143 */       return false;
/*     */     }
/* 145 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\HotbarRefill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
