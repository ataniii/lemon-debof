//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;@Declaration(name = "AntiSpam", category = Category.Misc)
/*     */ public class AntiSpam extends Module { BooleanSetting greenText; BooleanSetting discordLinks; BooleanSetting webLinks; BooleanSetting announcers; BooleanSetting spammers; BooleanSetting insulter; BooleanSetting greeters;
/*     */   BooleanSetting tradeChat;
/*     */   BooleanSetting ips;
/*     */   BooleanSetting ipsAgr;
/*     */   BooleanSetting numberSuffix;
/*     */   BooleanSetting duplicates;
/*     */   IntegerSetting duplicatesTimeout;
/*     */   BooleanSetting filterFriend;
/*     */   BooleanSetting showBlocked;
/*     */   BooleanSetting autoIgnore;
/*     */   IntegerSetting ignoreDuration;
/*     */   IntegerSetting violations;
/*     */   private final Pattern CHAT_PATTERN;
/*     */   private ConcurrentHashMap<String, Long> messageHistory;
/*     */   public List<String> ignoredBySpamCheck;
/*     */   public Map<String, Integer> violate;
/*     */   public List<String> ignoredList;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   
/*     */   public AntiSpam() {
/*  23 */     this.greenText = registerBoolean("Green Text", true);
/*  24 */     this.discordLinks = registerBoolean("Discord Link", true);
/*  25 */     this.webLinks = registerBoolean("Web Link", true);
/*  26 */     this.announcers = registerBoolean("Announcer", true);
/*  27 */     this.spammers = registerBoolean("Spammer", true);
/*  28 */     this.insulter = registerBoolean("Insulter", true);
/*  29 */     this.greeters = registerBoolean("Greeter", true);
/*  30 */     this.tradeChat = registerBoolean("Trade Chat", true);
/*  31 */     this.ips = registerBoolean("Server Ip", true);
/*  32 */     this.ipsAgr = registerBoolean("Ip Aggressive", true);
/*  33 */     this.numberSuffix = registerBoolean("Number Suffix", true);
/*  34 */     this.duplicates = registerBoolean("Duplicates", true);
/*  35 */     this.duplicatesTimeout = registerInteger("Duplicates Timeout", 30, 1, 600, () -> (Boolean)this.duplicates.getValue());
/*  36 */     this.filterFriend = registerBoolean("Filter Friend", false);
/*  37 */     this.showBlocked = registerBoolean("Show Blocked", false);
/*  38 */     this.autoIgnore = registerBoolean("Auto Ignore", true);
/*  39 */     this.ignoreDuration = registerInteger("Ignore Duration", 120, 0, 43200, () -> (Boolean)this.autoIgnore.getValue());
/*  40 */     this.violations = registerInteger("Violations", 3, 1, 100, () -> (Boolean)this.autoIgnore.getValue());
/*  41 */     this.CHAT_PATTERN = Pattern.compile("<.*?> ");
/*     */     
/*  43 */     this.ignoredBySpamCheck = new ArrayList<>();
/*  44 */     this.violate = new ConcurrentHashMap<>();
/*  45 */     this.ignoredList = new ArrayList<>();
/*  46 */     this.receiveListener = new Listener(event -> { if (mc.player == null || !isEnabled()) return;  if (!(event.getPacket() instanceof SPacketChat)) return;  String s = ((SPacketChat)event.getPacket()).getChatComponent().getUnformattedText(); Matcher matcher = this.CHAT_PATTERN.matcher(s); String username = "null"; if (matcher.find()) { username = matcher.group(); username = username.substring(1, username.length() - 2); } else if (s.contains(":")) { int spaceIndex = s.indexOf(" "); if (spaceIndex != -1) username = s.substring(0, spaceIndex);  }  username = cleanColor(username); if (username.equals("null") || mc.player.connection.getPlayerInfo(username) == null || SocialManager.isIgnore(username) || (((Boolean)this.filterFriend.getValue()).booleanValue() && SocialManager.isOnFriendList(username))) return;  SPacketChat sPacketChat = (SPacketChat)event.getPacket(); if (detectSpam(sPacketChat.getChatComponent().getUnformattedText()) && !username.equalsIgnoreCase(mc.player.getName())) { if (((Boolean)this.autoIgnore.getValue()).booleanValue()) if ((this.violate.get(username) != null && ((Integer)this.violate.get(username)).intValue() >= ((Integer)this.violations.getValue()).intValue()) || ((Integer)this.violations.getValue()).intValue() == 0) { if (!SocialManager.isIgnore(username)) { MessageBus.sendMessage(ChatFormatting.RED + username + " has exceeded the limitation of spam violation, ignoring.", Notification.Type.INFO, "AntiSpam", 13, false); String finalUsername = username; MultiThreading.runAsync(()); this.violate.remove(username); }  } else if (this.violate.get(username) == null) { this.violate.put(username, Integer.valueOf(1)); } else { this.violate.put(username, Integer.valueOf(((Integer)this.violate.get(username)).intValue() + 1)); }   event.cancel(); }  }new java.util.function.Predicate[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String cleanColor(String input) {
/*  93 */     return input.replaceAll("(?i)\\u00A7.", "");
/*     */   }
/*     */   
/*     */   public void startIgnore(final String finalUsername) {
/*  97 */     if (mc.player.getName().equalsIgnoreCase(finalUsername)) {
/*     */       return;
/*     */     }
/* 100 */     if (SocialManager.isIgnore(finalUsername)) {
/*     */       return;
/*     */     }
/* 103 */     SocialManager.addIgnore(finalUsername);
/* 104 */     this.ignoredBySpamCheck.add(finalUsername);
/* 105 */     this.ignoredList.add(finalUsername);
/* 106 */     MessageBus.sendMessage(ChatFormatting.RED + finalUsername + " has been auto ignored by AntiSpam for " + this.ignoreDuration.getValue() + ((((Integer)this.ignoreDuration.getValue()).intValue() > 1) ? " seconds" : " second"), Notification.Type.INFO, "AntiSpam", 13, false);
/* 107 */     (new Timer()).schedule(new TimerTask()
/*     */         {
/*     */           public void run() {
/* 110 */             AntiSpam.this.ignoredList.remove(finalUsername);
/* 111 */             if (!SocialManager.isIgnore(finalUsername)) {
/*     */               return;
/*     */             }
/* 114 */             SocialManager.delIgnore(finalUsername);
/*     */           }
/* 116 */         },  (((Integer)this.ignoreDuration.getValue()).intValue() * 1000));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/* 121 */     this.messageHistory = new ConcurrentHashMap<>();
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 125 */     this.messageHistory = null;
/*     */   }
/*     */   private boolean detectSpam(String message) {
/* 128 */     if (((Boolean)this.greenText.getValue()).booleanValue() && findPatterns(FilterPatterns.GREEN_TEXT, message)) {
/* 129 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 130 */         MessageBus.sendMessage("[AntiSpam] Green Text: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 132 */       return true;
/*     */     } 
/* 134 */     if (((Boolean)this.discordLinks.getValue()).booleanValue() && findPatterns(FilterPatterns.DISCORD, message)) {
/* 135 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 136 */         MessageBus.sendMessage("[AntiSpam] Discord Link: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 138 */       return true;
/*     */     } 
/* 140 */     if (((Boolean)this.webLinks.getValue()).booleanValue() && findPatterns(FilterPatterns.WEB_LINK, message)) {
/* 141 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 142 */         MessageBus.sendMessage("[AntiSpam] Web Link: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 144 */       return true;
/*     */     } 
/* 146 */     if (((Boolean)this.ips.getValue()).booleanValue() && findPatterns(FilterPatterns.IP_ADDR, message)) {
/* 147 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 148 */         MessageBus.sendMessage("[AntiSpam] IP Address: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 150 */       return true;
/*     */     } 
/* 152 */     if (((Boolean)this.ipsAgr.getValue()).booleanValue() && findPatterns(FilterPatterns.IP_ADDR_AGR, message)) {
/* 153 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 154 */         MessageBus.sendMessage("[AntiSpam] IP Aggressive: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 156 */       return true;
/*     */     } 
/* 158 */     if (((Boolean)this.tradeChat.getValue()).booleanValue() && findPatterns(FilterPatterns.TRADE_CHAT, message)) {
/* 159 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 160 */         MessageBus.sendMessage("[AntiSpam] Trade Chat: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 162 */       return true;
/*     */     } 
/* 164 */     if (((Boolean)this.numberSuffix.getValue()).booleanValue() && findPatterns(FilterPatterns.NUMBER_SUFFIX, message)) {
/* 165 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 166 */         MessageBus.sendMessage("[AntiSpam] Number Suffix: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 168 */       return true;
/*     */     } 
/* 170 */     if (((Boolean)this.announcers.getValue()).booleanValue() && findPatterns(FilterPatterns.ANNOUNCER, message)) {
/* 171 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 172 */         MessageBus.sendMessage("[AntiSpam] Announcer: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 174 */       return true;
/*     */     } 
/* 176 */     if (((Boolean)this.spammers.getValue()).booleanValue() && findPatterns(FilterPatterns.SPAMMER, message)) {
/* 177 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 178 */         MessageBus.sendMessage("[AntiSpam] Spammers: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 180 */       return true;
/*     */     } 
/* 182 */     if (((Boolean)this.insulter.getValue()).booleanValue() && findPatterns(FilterPatterns.INSULTER, message)) {
/* 183 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 184 */         MessageBus.sendMessage("[AntiSpam] Insulter: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 186 */       return true;
/*     */     } 
/* 188 */     if (((Boolean)this.greeters.getValue()).booleanValue() && findPatterns(FilterPatterns.GREETER, message)) {
/* 189 */       if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 190 */         MessageBus.sendMessage("[AntiSpam] Greeter: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */       }
/* 192 */       return true;
/*     */     } 
/* 194 */     if (((Boolean)this.duplicates.getValue()).booleanValue()) {
/* 195 */       if (this.messageHistory == null) {
/* 196 */         this.messageHistory = new ConcurrentHashMap<>();
/*     */       }
/* 198 */       boolean isDuplicate = (this.messageHistory.containsKey(message) && (System.currentTimeMillis() - ((Long)this.messageHistory.get(message)).longValue()) / 1000L < ((Integer)this.duplicatesTimeout.getValue()).intValue());
/* 199 */       this.messageHistory.put(message, Long.valueOf(System.currentTimeMillis()));
/* 200 */       if (isDuplicate) {
/* 201 */         if (((Boolean)this.showBlocked.getValue()).booleanValue()) {
/* 202 */           MessageBus.sendMessage("[AntiSpam] Duplicate: " + message, Notification.Type.INFO, "AntiSpam", 13, false);
/*     */         }
/* 204 */         return true;
/*     */       } 
/*     */     } 
/* 207 */     return false;
/*     */   }
/*     */   
/*     */   private boolean findPatterns(String[] patterns, String string) {
/* 211 */     for (String pattern : patterns) {
/* 212 */       if (Pattern.compile(pattern).matcher(string).find()) {
/* 213 */         return true;
/*     */       }
/*     */     } 
/* 216 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class FilterPatterns
/*     */   {
/* 234 */     private static final String[] ANNOUNCER = new String[] { "I just walked .+ feet!", "I just placed a .+!", "I just attacked .+ with a .+!", "I just dropped a .+!", "I just opened chat!", "I just opened my console!", "I just opened my GUI!", "I just went into full screen mode!", "I just paused my game!", "I just opened my inventory!", "I just looked at the player list!", "I just took a screen shot!", "I just swaped hands!", "I just ducked!", "I just changed perspectives!", "I just jumped!", "I just ate a .+!", "I just crafted .+ .+!", "I just picked up a .+!", "I just smelted .+ .+!", "I just respawned!", "I just attacked .+ with my hands", "I just broke a .+!", "I recently walked .+ blocks", "I just droped a .+ called, .+!", "I just placed a block called, .+!", "Im currently breaking a block called, .+!", "I just broke a block called, .+!", "I just opened chat!", "I just opened chat and typed a slash!", "I just paused my game!", "I just opened my inventory!", "I just looked at the player list!", "I just changed perspectives, now im in .+!", "I just crouched!", "I just jumped!", "I just attacked a entity called, .+ with a .+", "Im currently eatting a peice of food called, .+!", "Im currently using a item called, .+!", "I just toggled full screen mode!", "I just took a screen shot!", "I just swaped hands and now theres a .+ in my main hand and a .+ in my off hand!", "I just used pick block on a block called, .+!", "Ra just completed his blazing ark", "Its a new day yes it is", "I just placed .+ thanks to (http:\\/\\/)?DotGod\\.CC!", "I just flew .+ meters like a butterfly thanks to (http:\\/\\/)?DotGod\\.CC!" };
/* 235 */     private static final String[] SPAMMER = new String[] { "WWE Client's spammer", "Lol get gud", "Future client is bad", "WWE > Future", "WWE > Impact", "Default Message", "IKnowImEZ is a god", "THEREALWWEFAN231 is a god", "WWE Client made by IKnowImEZ/THEREALWWEFAN231", "WWE Client was the first public client to have Path Finder/New Chunks", "WWE Client was the first public client to have color signs", "WWE Client was the first client to have Teleport Finder", "WWE Client was the first client to have Tunneller & Tunneller Back Fill" };
/* 236 */     private static final String[] INSULTER = new String[] { ".+ Download WWE utility mod, Its free!", ".+ 4b4t is da best mintscreft serber", ".+ dont abouse", ".+ you cuck", ".+ https://www.youtube.com/channel/UCJGCNPEjvsCn0FKw3zso0TA", ".+ is my step dad", ".+ again daddy!", "dont worry .+ it happens to every one", ".+ dont buy future it's crap, compared to WWE!", "What are you, fucking gay, .+?", "Did you know? .+ hates you, .+", "You are literally 10, .+", ".+ finally lost their virginity, sadly they lost it to .+... yeah, that's unfortunate.", ".+, don't be upset, it's not like anyone cares about you, fag.", ".+, see that rubbish bin over there? Get your ass in it, or I'll get .+ to whoop your ass.", ".+, may I borrow that dirt block? that guy named .+ needs it...", "Yo, .+, btfo you virgin", "Hey .+ want to play some High School RP with me and .+?", ".+ is an Archon player. Why is he on here? Fucking factions player.", "Did you know? .+ just joined The Vortex Coalition!", ".+ has successfully conducted the cactus dupe and duped a itemhand!", ".+, are you even human? You act like my dog, holy shit.", ".+, you were never loved by your family.", "Come on .+, you hurt .+'s feelings. You meany.", "Stop trying to meme .+, you can't do that. kek", ".+, .+ is gay. Don't go near him.", "Whoa .+ didn't mean to offend you, .+.", ".+ im not pvping .+, im WWE'ing .+.", "Did you know? .+ just joined The Vortex Coalition!", ".+, are you even human? You act like my dog, holy shit." };
/* 237 */     private static final String[] GREETER = new String[] { "Bye, Bye .+", "Farwell, .+" };
/* 238 */     private static final String[] DISCORD = new String[] { "discord.gg", "discordapp.com", "discord.io", "invite.gg" };
/* 239 */     private static final String[] NUMBER_SUFFIX = new String[] { ".+\\d{3,}$" };
/* 240 */     private static final String[] GREEN_TEXT = new String[] { "^<.+> >" };
/* 241 */     private static final String[] TRADE_CHAT = new String[] { "buy", "sell" };
/* 242 */     private static final String[] WEB_LINK = new String[] { "http:\\/\\/", "https:\\/\\/", "www." };
/* 243 */     private static final String[] IP_ADDR = new String[] { "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\:\\d{1,5}\\b", "\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}", "^(?:http(?:s)?:\\/\\/)?(?:[^\\.]+\\.)?.*\\..*\\..*$", ".*\\..*\\:\\d{1,5}$" };
/* 244 */     private static final String[] IP_ADDR_AGR = new String[] { ".*\\..*$" };
/*     */   } }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AntiSpam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
