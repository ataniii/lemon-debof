//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.StringSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ 
/*    */ @Declaration(name = "NameProtect", category = Category.Misc)
/*    */ public class NameProtect extends Module {
/*    */   public static NameProtect INSTANCE;
/*    */   StringSetting name;
/*    */   
/*    */   public NameProtect() {
/* 14 */     this.name = registerString("Name", "");
/*    */     INSTANCE = this;
/*    */   } public String replaceName(String string) {
/* 17 */     if (string != null && isEnabled()) {
/* 18 */       String username = mc.getSession().getUsername();
/* 19 */       return string.replace(username, this.name.getText()).replace(username.toLowerCase(), this.name.getText().toLowerCase()).replace(username.toUpperCase(), this.name.getText().toUpperCase());
/*    */     } 
/*    */     
/* 22 */     return string;
/*    */   }
/*    */   
/*    */   public String getName(String original) {
/* 26 */     if (this.name.getText().length() > 0) {
/* 27 */       return this.name.getText();
/*    */     }
/*    */     
/* 30 */     return original;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\NameProtect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
