//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "AntiContainer", category = Category.Misc)
/*    */ public class AntiContainer extends Module {
/*    */   BooleanSetting Chest;
/*    */   BooleanSetting EnderChest;
/*    */   BooleanSetting Trapped_Chest;
/*    */   
/*    */   public AntiContainer() {
/* 17 */     this.Chest = registerBoolean("Chest", true);
/* 18 */     this.EnderChest = registerBoolean("EnderChest", true);
/* 19 */     this.Trapped_Chest = registerBoolean("Trapped_Chest", true);
/* 20 */     this.Hopper = registerBoolean("Hopper", true);
/* 21 */     this.Dispenser = registerBoolean("Dispenser", true);
/* 22 */     this.Furnace = registerBoolean("Furnace", true);
/* 23 */     this.Beacon = registerBoolean("Beacon", true);
/* 24 */     this.Crafting_Table = registerBoolean("Crafting_Table", true);
/* 25 */     this.Anvil = registerBoolean("Anvil", true);
/* 26 */     this.Enchanting_table = registerBoolean("Enchanting_table", true);
/* 27 */     this.Brewing_Stand = registerBoolean("Brewing_Stand", true);
/* 28 */     this.ShulkerBox = registerBoolean("ShulkerBox", true);
/*    */     
/* 30 */     this.listener = new Listener(event -> { if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) { BlockPos pos = ((CPacketPlayerTryUseItemOnBlock)event.getPacket()).getPos(); if (check(pos)) event.cancel();  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   BooleanSetting Hopper; BooleanSetting Dispenser; BooleanSetting Furnace; BooleanSetting Beacon; BooleanSetting Crafting_Table; BooleanSetting Anvil; BooleanSetting Enchanting_table;
/*    */   BooleanSetting Brewing_Stand;
/*    */   BooleanSetting ShulkerBox;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> listener;
/*    */   
/*    */   public boolean check(BlockPos pos) {
/* 39 */     return ((mc.world.getBlockState(pos).getBlock() == Blocks.CHEST && ((Boolean)this.Chest.getValue()).booleanValue()) || (mc.world
/* 40 */       .getBlockState(pos).getBlock() == Blocks.ENDER_CHEST && ((Boolean)this.EnderChest.getValue()).booleanValue()) || (mc.world
/* 41 */       .getBlockState(pos).getBlock() == Blocks.TRAPPED_CHEST && ((Boolean)this.Trapped_Chest.getValue()).booleanValue()) || (mc.world
/* 42 */       .getBlockState(pos).getBlock() == Blocks.HOPPER && ((Boolean)this.Hopper.getValue()).booleanValue()) || (mc.world
/* 43 */       .getBlockState(pos).getBlock() == Blocks.DISPENSER && ((Boolean)this.Dispenser.getValue()).booleanValue()) || (mc.world
/* 44 */       .getBlockState(pos).getBlock() == Blocks.FURNACE && ((Boolean)this.Furnace.getValue()).booleanValue()) || (mc.world
/* 45 */       .getBlockState(pos).getBlock() == Blocks.BEACON && ((Boolean)this.Beacon.getValue()).booleanValue()) || (mc.world
/* 46 */       .getBlockState(pos).getBlock() == Blocks.CRAFTING_TABLE && ((Boolean)this.Crafting_Table.getValue()).booleanValue()) || (mc.world
/* 47 */       .getBlockState(pos).getBlock() == Blocks.ANVIL && ((Boolean)this.Anvil.getValue()).booleanValue()) || (mc.world
/* 48 */       .getBlockState(pos).getBlock() == Blocks.ENCHANTING_TABLE && ((Boolean)this.Enchanting_table.getValue()).booleanValue()) || (mc.world
/* 49 */       .getBlockState(pos).getBlock() == Blocks.BREWING_STAND && ((Boolean)this.Brewing_Stand.getValue()).booleanValue()) || (mc.world
/* 50 */       .getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockShulkerBox && ((Boolean)this.ShulkerBox.getValue()).booleanValue()));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AntiContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
