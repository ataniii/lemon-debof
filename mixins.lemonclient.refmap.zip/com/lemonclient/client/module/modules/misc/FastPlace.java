//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.init.Items;
/*    */ 
/*    */ @Declaration(name = "FastPlace", category = Category.Misc)
/*    */ public class FastPlace extends Module {
/* 11 */   BooleanSetting exp = registerBoolean("Exp", false);
/* 12 */   BooleanSetting crystals = registerBoolean("Crystals", false);
/* 13 */   BooleanSetting offhandCrystal = registerBoolean("Offhand Crystal", false);
/* 14 */   BooleanSetting everything = registerBoolean("Everything", false);
/*    */   
/*    */   public void onUpdate() {
/* 17 */     if ((((Boolean)this.exp.getValue()).booleanValue() && mc.player.getHeldItemMainhand().getItem() == Items.EXPERIENCE_BOTTLE) || mc.player.getHeldItemOffhand().getItem() == Items.EXPERIENCE_BOTTLE) {
/* 18 */       mc.rightClickDelayTimer = 0;
/*    */     }
/*    */     
/* 21 */     if (((Boolean)this.crystals.getValue()).booleanValue() && mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) {
/* 22 */       mc.rightClickDelayTimer = 0;
/*    */     }
/*    */     
/* 25 */     if (((Boolean)this.offhandCrystal.getValue()).booleanValue() && mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
/* 26 */       mc.rightClickDelayTimer = 0;
/*    */     }
/*    */     
/* 29 */     if (((Boolean)this.everything.getValue()).booleanValue()) {
/* 30 */       mc.rightClickDelayTimer = 0;
/*    */     }
/*    */     
/* 33 */     mc.playerController.blockHitDelay = 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\FastPlace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
