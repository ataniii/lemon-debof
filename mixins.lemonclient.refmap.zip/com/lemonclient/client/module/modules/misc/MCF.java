//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ 
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*    */ import org.lwjgl.input.Mouse;
/*    */ 
/*    */ @Declaration(name = "MCF", category = Category.Misc)
/*    */ public class MCF extends Module {
/*    */   @EventHandler
/* 20 */   private final Listener<InputEvent.MouseInputEvent> listener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead || mc.objectMouseOver == null) return;  if (mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.ENTITY) && mc.objectMouseOver.entityHit instanceof net.minecraft.entity.player.EntityPlayer && Mouse.isButtonDown(2)) if (SocialManager.isFriend(mc.objectMouseOver.entityHit.getName())) { SocialManager.delFriend(mc.objectMouseOver.entityHit.getName()); MessageBus.sendClientPrefixMessage(((ColorMain)ModuleManager.getModule(ColorMain.class)).getDisabledColor() + "Removed " + mc.objectMouseOver.entityHit.getName() + " from friends list", Notification.Type.SUCCESS); } else { SocialManager.addFriend(mc.objectMouseOver.entityHit.getName()); MessageBus.sendClientPrefixMessage(((ColorMain)ModuleManager.getModule(ColorMain.class)).getEnabledColor() + "Added " + mc.objectMouseOver.entityHit.getName() + " to friends list", Notification.Type.SUCCESS); }   }new java.util.function.Predicate[0]);
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\MCF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
