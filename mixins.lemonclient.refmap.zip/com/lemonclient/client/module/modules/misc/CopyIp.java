//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ 
/*    */ import com.lemonclient.api.util.chat.Notification;
/*    */ import com.lemonclient.api.util.misc.MessageBus;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.datatransfer.Clipboard;
/*    */ import java.awt.datatransfer.StringSelection;
/*    */ 
/*    */ @Declaration(name = "Copy IP", category = Category.Misc)
/*    */ public class CopyIp
/*    */   extends Module
/*    */ {
/*    */   String server;
/*    */   
/*    */   public void onEnable() {
/*    */     try {
/* 20 */       this.server = (mc.getCurrentServerData()).serverIP;
/* 21 */     } catch (Exception e) {
/* 22 */       this.server = "Singleplayer";
/*    */     } 
/* 24 */     String myString = this.server;
/* 25 */     StringSelection stringSelection = new StringSelection(myString);
/* 26 */     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 27 */     clipboard.setContents(stringSelection, null);
/* 28 */     MessageBus.sendClientPrefixMessage("Copied '" + this.server + "' to clipboard.", Notification.Type.INFO);
/* 29 */     disable();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\CopyIp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
