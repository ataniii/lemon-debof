//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.misc;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.effect.EntityLightningBolt;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ @Declaration(name = "KillEffect", category = Category.Misc)
/*    */ public class KillEffect extends Module {
/* 16 */   BooleanSetting thunder = registerBoolean("Thunder", true);
/* 17 */   IntegerSetting numbersThunder = registerInteger("Number Thunder", 1, 1, 10);
/* 18 */   BooleanSetting sound = registerBoolean("Sound", true);
/* 19 */   IntegerSetting numberSound = registerInteger("Number Sound", 1, 1, 10);
/* 20 */   ArrayList<EntityPlayer> playersDead = new ArrayList<>();
/*    */ 
/*    */   
/*    */   protected void onEnable() {
/* 24 */     this.playersDead.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 30 */     if (mc.world == null) {
/* 31 */       this.playersDead.clear();
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     mc.world.playerEntities.forEach(entity -> {
/*    */           if (this.playersDead.contains(entity)) {
/*    */             if (entity.getHealth() > 0.0F)
/*    */               this.playersDead.remove(entity); 
/*    */           } else if (entity.getHealth() == 0.0F) {
/*    */             if (((Boolean)this.thunder.getValue()).booleanValue())
/*    */               for (int i = 0; i < ((Integer)this.numbersThunder.getValue()).intValue(); i++)
/*    */                 mc.world.spawnEntity((Entity)new EntityLightningBolt((World)mc.world, entity.posX, entity.posY, entity.posZ, true));  
/*    */             if (((Boolean)this.sound.getValue()).booleanValue())
/*    */               for (int i = 0; i < ((Integer)this.numberSound.getValue()).intValue(); i++)
/*    */                 mc.player.playSound(SoundEvents.ENTITY_LIGHTNING_THUNDER, 0.5F, 1.0F);  
/*    */             this.playersDead.add(entity);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\KillEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
