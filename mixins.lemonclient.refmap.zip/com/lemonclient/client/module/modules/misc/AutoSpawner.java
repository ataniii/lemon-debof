//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.misc;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.boss.EntityWither;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Declaration(name = "AutoSpawner", category = Category.Misc)
/*     */ public class AutoSpawner
/*     */   extends Module
/*     */ {
/*  40 */   ModeSetting useMode = registerMode("Use Mode", Arrays.asList(new String[] { "Single", "Spam" }, ), "Spam");
/*  41 */   BooleanSetting party = registerBoolean("Wither Party", false);
/*  42 */   ModeSetting entityMode = registerMode("Entity Mode", Arrays.asList(new String[] { "Snow", "Iron", "Wither" }, ), "Wither");
/*  43 */   BooleanSetting nametagWithers = registerBoolean("Nametag", true);
/*  44 */   DoubleSetting placeRange = registerDouble("Place Range", 3.5D, 1.0D, 10.0D);
/*  45 */   IntegerSetting delay = registerInteger("Delay", 20, 0, 100);
/*  46 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  47 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  48 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*  49 */   BooleanSetting packet = registerBoolean("Packet Place", true);
/*  50 */   BooleanSetting swing = registerBoolean("Swing", true);
/*     */   
/*     */   private static boolean isSneaking;
/*     */   
/*     */   private BlockPos placeTarget;
/*     */   
/*     */   private boolean rotationPlaceableX;
/*     */   
/*     */   private boolean rotationPlaceableZ;
/*     */   private int bodySlot;
/*     */   private int headSlot;
/*     */   private int buildStage;
/*     */   private int delayStep;
/*     */   
/*     */   private void useNameTag() {
/*  65 */     int originalSlot = mc.player.inventory.currentItem;
/*  66 */     for (Entity w : mc.world.getLoadedEntityList()) {
/*  67 */       if (w instanceof EntityWither && w.getDisplayName().getUnformattedText().equalsIgnoreCase("Wither")) {
/*  68 */         EntityWither wither = (EntityWither)w;
/*  69 */         if (mc.player.getDistance((Entity)wither) <= ((Double)this.placeRange.getValue()).doubleValue()) {
/*  70 */           selectNameTags();
/*  71 */           mc.playerController.interactWithEntity((EntityPlayer)mc.player, (Entity)wither, EnumHand.MAIN_HAND);
/*     */         } 
/*     */       } 
/*     */     } 
/*  75 */     switchTo(originalSlot);
/*     */   }
/*     */   
/*     */   private void selectNameTags() {
/*  79 */     int tagSlot = -1;
/*  80 */     for (int i = 0; i < 9; i++) {
/*  81 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*  82 */       if (stack != ItemStack.EMPTY && !(stack.getItem() instanceof ItemBlock)) {
/*  83 */         Item tag = stack.getItem();
/*  84 */         if (tag instanceof net.minecraft.item.ItemNameTag) tagSlot = i; 
/*     */       } 
/*     */     } 
/*  87 */     if (tagSlot == -1) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     switchTo(tagSlot);
/*     */   }
/*     */   
/*     */   private static EnumFacing getPlaceableSide(BlockPos pos) {
/*  95 */     for (EnumFacing side : EnumFacing.values()) {
/*  96 */       BlockPos neighbour = pos.offset(side);
/*     */       
/*  98 */       if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/*     */ 
/*     */ 
/*     */         
/* 102 */         IBlockState blockState = mc.world.getBlockState(neighbour);
/* 103 */         if (!blockState.getMaterial().isReplaceable() && !(blockState.getBlock() instanceof net.minecraft.block.BlockTallGrass) && !(blockState.getBlock() instanceof net.minecraft.block.BlockDeadBush)) {
/* 104 */           return side;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onEnable() {
/* 114 */     this.buildStage = 1;
/* 115 */     this.delayStep = 1;
/*     */   }
/*     */   
/*     */   private boolean checkBlocksInHotbar() {
/* 119 */     this.headSlot = -1;
/* 120 */     this.bodySlot = -1;
/*     */     
/* 122 */     for (int i = 0; i < 9; i++) {
/* 123 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */       
/* 125 */       if (stack == ItemStack.EMPTY) {
/*     */         continue;
/*     */       }
/*     */       
/* 129 */       if (((String)this.entityMode.getValue()).equals("Wither")) {
/*     */         
/* 131 */         if (stack.getItem() == Items.SKULL && stack.getItemDamage() == 1) {
/* 132 */           if ((mc.player.inventory.getStackInSlot(i)).stackSize >= 3) {
/* 133 */             this.headSlot = i;
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 138 */         if (!(stack.getItem() instanceof ItemBlock))
/*     */           continue; 
/* 140 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 141 */         if (block instanceof net.minecraft.block.BlockSoulSand && 
/* 142 */           (mc.player.inventory.getStackInSlot(i)).stackSize >= 4) {
/* 143 */           this.bodySlot = i;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 148 */       if (((String)this.entityMode.getValue()).equals("Iron")) {
/* 149 */         if (!(stack.getItem() instanceof ItemBlock))
/*     */           continue; 
/* 151 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/*     */         
/* 153 */         if ((block == Blocks.LIT_PUMPKIN || block == Blocks.PUMPKIN) && 
/* 154 */           (mc.player.inventory.getStackInSlot(i)).stackSize >= 1) {
/* 155 */           this.headSlot = i;
/*     */         }
/*     */ 
/*     */         
/* 159 */         if (block == Blocks.IRON_BLOCK && 
/* 160 */           (mc.player.inventory.getStackInSlot(i)).stackSize >= 4) {
/* 161 */           this.bodySlot = i;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 166 */       if (((String)this.entityMode.getValue()).equals("Snow") && 
/* 167 */         stack.getItem() instanceof ItemBlock) {
/*     */         
/* 169 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/*     */         
/* 171 */         if ((block == Blocks.LIT_PUMPKIN || block == Blocks.PUMPKIN) && 
/* 172 */           (mc.player.inventory.getStackInSlot(i)).stackSize >= 1) {
/* 173 */           this.headSlot = i;
/*     */         }
/*     */ 
/*     */         
/* 177 */         if (block == Blocks.SNOW && 
/* 178 */           (mc.player.inventory.getStackInSlot(i)).stackSize >= 2) {
/* 179 */           this.bodySlot = i;
/*     */         }
/*     */       } 
/*     */       
/*     */       continue;
/*     */     } 
/*     */     
/* 186 */     return (this.bodySlot != -1 && this.headSlot != -1);
/*     */   }
/*     */   
/*     */   private boolean testStructure() {
/* 190 */     if (((String)this.entityMode.getValue()).equals("Wither")) return testWitherStructure();
/*     */     
/* 192 */     if (((String)this.entityMode.getValue()).equals("Iron")) return testIronGolemStructure();
/*     */     
/* 194 */     if (((String)this.entityMode.getValue()).equals("Snow")) return testSnowGolemStructure();
/*     */     
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   private boolean testWitherStructure() {
/* 200 */     boolean noRotationPlaceable = true;
/* 201 */     this.rotationPlaceableX = true;
/* 202 */     this.rotationPlaceableZ = true;
/* 203 */     boolean isShitGrass = false;
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (mc.world.getBlockState(this.placeTarget) == null) return false;
/*     */ 
/*     */     
/* 210 */     Block block = mc.world.getBlockState(this.placeTarget).getBlock();
/* 211 */     if (block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockDeadBush) isShitGrass = true;
/*     */     
/* 213 */     if (getPlaceableSide(this.placeTarget.up()) == null) return false;
/*     */     
/* 215 */     for (BlockPos pos : BodyParts.bodyBase) {
/* 216 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 217 */         noRotationPlaceable = false;
/*     */       }
/*     */     } 
/*     */     
/* 221 */     for (BlockPos pos : BodyParts.ArmsX) {
/* 222 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos)) || placingIsBlocked(this.placeTarget.add((Vec3i)pos.down()))) {
/* 223 */         this.rotationPlaceableX = false;
/*     */       }
/*     */     } 
/*     */     
/* 227 */     for (BlockPos pos : BodyParts.ArmsZ) {
/* 228 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos)) || placingIsBlocked(this.placeTarget.add((Vec3i)pos.down()))) {
/* 229 */         this.rotationPlaceableZ = false;
/*     */       }
/*     */     } 
/*     */     
/* 233 */     for (BlockPos pos : BodyParts.headsX) {
/* 234 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 235 */         this.rotationPlaceableX = false;
/*     */       }
/*     */     } 
/*     */     
/* 239 */     for (BlockPos pos : BodyParts.headsZ) {
/* 240 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 241 */         this.rotationPlaceableZ = false;
/*     */       }
/*     */     } 
/*     */     
/* 245 */     return (!isShitGrass && noRotationPlaceable && (this.rotationPlaceableX || this.rotationPlaceableZ));
/*     */   }
/*     */   
/*     */   private boolean testIronGolemStructure() {
/* 249 */     boolean noRotationPlaceable = true;
/* 250 */     this.rotationPlaceableX = true;
/* 251 */     this.rotationPlaceableZ = true;
/* 252 */     boolean isShitGrass = false;
/*     */ 
/*     */ 
/*     */     
/* 256 */     if (mc.world.getBlockState(this.placeTarget) == null) return false;
/*     */ 
/*     */     
/* 259 */     Block block = mc.world.getBlockState(this.placeTarget).getBlock();
/* 260 */     if (block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockDeadBush) isShitGrass = true;
/*     */     
/* 262 */     if (getPlaceableSide(this.placeTarget.up()) == null) return false;
/*     */     
/* 264 */     for (BlockPos pos : BodyParts.bodyBase) {
/* 265 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 266 */         noRotationPlaceable = false;
/*     */       }
/*     */     } 
/*     */     
/* 270 */     for (BlockPos pos : BodyParts.ArmsX) {
/* 271 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos)) || placingIsBlocked(this.placeTarget.add((Vec3i)pos.down()))) {
/* 272 */         this.rotationPlaceableX = false;
/*     */       }
/*     */     } 
/*     */     
/* 276 */     for (BlockPos pos : BodyParts.ArmsZ) {
/* 277 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos)) || placingIsBlocked(this.placeTarget.add((Vec3i)pos.down()))) {
/* 278 */         this.rotationPlaceableZ = false;
/*     */       }
/*     */     } 
/*     */     
/* 282 */     for (BlockPos pos : BodyParts.head) {
/* 283 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 284 */         noRotationPlaceable = false;
/*     */       }
/*     */     } 
/*     */     
/* 288 */     return (!isShitGrass && noRotationPlaceable && (this.rotationPlaceableX || this.rotationPlaceableZ));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean testSnowGolemStructure() {
/* 294 */     boolean noRotationPlaceable = true;
/* 295 */     boolean isShitGrass = false;
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (mc.world.getBlockState(this.placeTarget) == null) {
/* 300 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 304 */     Block block = mc.world.getBlockState(this.placeTarget).getBlock();
/* 305 */     if (block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockDeadBush) {
/* 306 */       isShitGrass = true;
/*     */     }
/*     */     
/* 309 */     if (getPlaceableSide(this.placeTarget.up()) == null) {
/* 310 */       return false;
/*     */     }
/*     */     
/* 313 */     for (BlockPos pos : BodyParts.bodyBase) {
/* 314 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 315 */         noRotationPlaceable = false;
/*     */       }
/*     */     } 
/*     */     
/* 319 */     for (BlockPos pos : BodyParts.head) {
/* 320 */       if (placingIsBlocked(this.placeTarget.add((Vec3i)pos))) {
/* 321 */         noRotationPlaceable = false;
/*     */       }
/*     */     } 
/*     */     
/* 325 */     return (!isShitGrass && noRotationPlaceable);
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 330 */     if (slot > -1 && slot < 9 && (
/* 331 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 332 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/* 334 */       { mc.player.inventory.currentItem = slot; }
/*     */       
/* 336 */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 343 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*     */       return; 
/* 345 */     if (((Boolean)this.nametagWithers.getValue()).booleanValue() && (((Boolean)this.party.getValue()).booleanValue() || (!((Boolean)this.party.getValue()).booleanValue() && ((String)this.entityMode.getValue()).equals("Wither")))) useNameTag();
/*     */     
/* 347 */     if (this.buildStage == 1) {
/* 348 */       isSneaking = false;
/* 349 */       this.rotationPlaceableX = false;
/* 350 */       this.rotationPlaceableZ = false;
/*     */       
/* 352 */       if (((Boolean)this.party.getValue()).booleanValue()) {
/* 353 */         this.entityMode.setValue("Wither");
/*     */       }
/*     */       
/* 356 */       if (!checkBlocksInHotbar()) {
/* 357 */         if (((String)this.useMode.getValue()).equals("Single")) disable();
/*     */         
/*     */         return;
/*     */       } 
/* 361 */       List<BlockPos> blockPosList = EntityUtil.getSphere(mc.player.getPosition().down(), (Double)this.placeRange.getValue(), (Double)this.placeRange.getValue(), false, true, 0);
/*     */       
/* 363 */       boolean noPositionInArea = true;
/*     */       
/* 365 */       for (BlockPos pos : blockPosList) {
/* 366 */         this.placeTarget = pos.down();
/* 367 */         if (testStructure()) {
/* 368 */           noPositionInArea = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 373 */       if (noPositionInArea) {
/* 374 */         if (((String)this.useMode.getValue()).equals("Single")) {
/* 375 */           disable();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 380 */       int oldslot = mc.player.inventory.currentItem;
/* 381 */       switchTo(this.bodySlot);
/*     */       
/* 383 */       for (BlockPos pos : BodyParts.bodyBase) BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */       
/* 385 */       if (((String)this.entityMode.getValue()).equals("Wither") || ((String)this.entityMode.getValue()).equals("Iron")) {
/* 386 */         if (this.rotationPlaceableX) {
/* 387 */           for (BlockPos pos : BodyParts.ArmsX) {
/* 388 */             BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */           }
/* 390 */         } else if (this.rotationPlaceableZ) {
/* 391 */           for (BlockPos pos : BodyParts.ArmsZ) {
/* 392 */             BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 397 */       switchTo(oldslot);
/* 398 */       this.buildStage = 2;
/*     */     }
/* 400 */     else if (this.buildStage == 2) {
/* 401 */       int oldslot = mc.player.inventory.currentItem;
/* 402 */       switchTo(this.headSlot);
/*     */       
/* 404 */       if (((String)this.entityMode.getValue()).equals("Wither")) {
/* 405 */         if (this.rotationPlaceableX) {
/* 406 */           for (BlockPos pos : BodyParts.headsX) {
/* 407 */             BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */           }
/* 409 */         } else if (this.rotationPlaceableZ) {
/* 410 */           for (BlockPos pos : BodyParts.headsZ) {
/* 411 */             BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 416 */       if (((String)this.entityMode.getValue()).equals("Iron") || ((String)this.entityMode.getValue()).equals("Snow")) {
/* 417 */         for (BlockPos pos : BodyParts.head) BurrowUtil.placeBlock(this.placeTarget.add((Vec3i)pos), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */       
/*     */       }
/* 420 */       if (isSneaking) {
/* 421 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/* 422 */         isSneaking = false;
/*     */       } 
/*     */       
/* 425 */       if (((String)this.useMode.getValue()).equals("Single")) disable(); 
/* 426 */       switchTo(oldslot);
/* 427 */       this.buildStage = 3;
/* 428 */     } else if (this.buildStage == 3) {
/* 429 */       if (this.delayStep < ((Integer)this.delay.getValue()).intValue()) {
/* 430 */         this.delayStep++;
/*     */       } else {
/* 432 */         this.delayStep = 1;
/* 433 */         this.buildStage = 1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean placingIsBlocked(BlockPos pos) {
/* 440 */     Block block = mc.world.getBlockState(pos).getBlock();
/* 441 */     if (!(block instanceof net.minecraft.block.BlockAir)) return true;
/*     */ 
/*     */     
/* 444 */     for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos))) {
/* 445 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb)) {
/* 446 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 450 */     return false;
/*     */   }
/*     */   
/*     */   private static class BodyParts {
/* 454 */     private static final BlockPos[] bodyBase = new BlockPos[] { new BlockPos(0, 1, 0), new BlockPos(0, 2, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 459 */     private static final BlockPos[] ArmsX = new BlockPos[] { new BlockPos(-1, 2, 0), new BlockPos(1, 2, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 464 */     private static final BlockPos[] ArmsZ = new BlockPos[] { new BlockPos(0, 2, -1), new BlockPos(0, 2, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     private static final BlockPos[] headsX = new BlockPos[] { new BlockPos(0, 3, 0), new BlockPos(-1, 3, 0), new BlockPos(1, 3, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 475 */     private static final BlockPos[] headsZ = new BlockPos[] { new BlockPos(0, 3, 0), new BlockPos(0, 3, -1), new BlockPos(0, 3, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 481 */     private static final BlockPos[] head = new BlockPos[] { new BlockPos(0, 3, 0) };
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\misc\AutoSpawner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
