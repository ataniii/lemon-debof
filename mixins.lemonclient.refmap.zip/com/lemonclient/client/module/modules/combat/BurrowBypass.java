//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ @Declaration(name = "BurrowBypass", category = Category.Combat)
/*     */ public class BurrowBypass extends Module {
/*     */   BooleanSetting multiPlace;
/*     */   BooleanSetting tpCenter;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting strict;
/*     */   BooleanSetting raytrace;
/*     */   ModeSetting jumpMode;
/*     */   ModeSetting bypassMode;
/*     */   ModeSetting rubberBand;
/*     */   DoubleSetting offsetX;
/*     */   DoubleSetting offsetY;
/*     */   DoubleSetting offsetZ;
/*     */   BooleanSetting head;
/*     */   BooleanSetting breakCrystal;
/*     */   BooleanSetting onlyOnGround;
/*     */   BooleanSetting air;
/*     */   BooleanSetting antiWk;
/*     */   ModeSetting mode;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting check;
/*     */   BooleanSetting testMode;
/*     */   BooleanSetting move;
/*     */   boolean moved;
/*     */   Vec3d[] offsets;
/*     */   @EventHandler
/*     */   private final Listener<PlayerMoveEvent> playerMoveListener;
/*     */   
/*  33 */   public BurrowBypass() { this.multiPlace = registerBoolean("MultiPlace", false);
/*  34 */     this.tpCenter = registerBoolean("TPCenter", false);
/*  35 */     this.rotate = registerBoolean("Rotate", true);
/*  36 */     this.packet = registerBoolean("Packet Place", true);
/*  37 */     this.swing = registerBoolean("Swing", true);
/*  38 */     this.strict = registerBoolean("Strict", true);
/*  39 */     this.raytrace = registerBoolean("RayTrace", true);
/*  40 */     this.jumpMode = registerMode("JumpMode", Arrays.asList(new String[] { "Normal", "Future", "Strict" }, ), "Normal");
/*  41 */     this.bypassMode = registerMode("Bypass", Arrays.asList(new String[] { "Normal", "Middle", "Test" }, ), "Normal");
/*  42 */     this.rubberBand = registerMode("RubberBand", Arrays.asList(new String[] { "Cn", "Strict", "Future", "FutureStrict", "Troll", "Void", "Auto", "Test", "Custom" }, ), "Cn");
/*  43 */     this.offsetX = registerDouble("OffsetX", -7.0D, -10.0D, 10.0D, () -> Boolean.valueOf(((String)this.rubberBand.getValue()).equals("Custom")));
/*  44 */     this.offsetY = registerDouble("OffsetY", -7.0D, -10.0D, 10.0D, () -> Boolean.valueOf(((String)this.rubberBand.getValue()).equals("Custom")));
/*  45 */     this.offsetZ = registerDouble("OffsetZ", -7.0D, -10.0D, 10.0D, () -> Boolean.valueOf(((String)this.rubberBand.getValue()).equals("Custom")));
/*  46 */     this.head = registerBoolean("Head", true);
/*  47 */     this.breakCrystal = registerBoolean("BreakCrystal", true);
/*  48 */     this.onlyOnGround = registerBoolean("OnGround Only", true);
/*  49 */     this.air = registerBoolean("NotAir", true);
/*  50 */     this.antiWk = registerBoolean("AntiWeak", true, () -> (Boolean)this.breakCrystal.getValue());
/*  51 */     this.mode = registerMode("BlockMode", Arrays.asList(new String[] { "Obsidian", "EChest", "ObbyEChest", "EChestObby" }, ), "ObbyEChest");
/*  52 */     this.packetSwitch = registerBoolean("Packet Switch", false);
/*  53 */     this.check = registerBoolean("Switch Check", true);
/*  54 */     this.testMode = registerBoolean("Test Mode", true);
/*  55 */     this.move = registerBoolean("Move", true, () -> (Boolean)this.testMode.getValue());
/*     */     
/*  57 */     this.offsets = new Vec3d[] { new Vec3d(0.3D, 0.0D, 0.3D), new Vec3d(-0.3D, 0.0D, 0.3D), new Vec3d(0.3D, 0.0D, -0.3D), new Vec3d(-0.3D, 0.0D, -0.3D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.playerMoveListener = new Listener(event -> {
/*     */           if (!mc.player.isEntityAlive() || mc.player.isElytraFlying() || mc.player.capabilities.isFlying) {
/*     */             return;
/*     */           }
/*     */           if (!this.moved)
/*     */           { BlockPos blockPos = PlayerUtil.getPlayerPos();
/*     */             for (Vec3d vec3d : new Vec3d[] { new Vec3d(0.4D, 0.0D, 0.4D), new Vec3d(0.4D, 0.0D, -0.4D), new Vec3d(-0.4D, 0.0D, 0.4D), new Vec3d(-0.4D, 0.0D, -0.4D) }) {
/*     */               BlockPos pos = new BlockPos(mc.player.posX + vec3d.x, mc.player.posY, mc.player.posZ + vec3d.z);
/*     */               if (BlockUtil.isAir(pos.down()) && mc.world.isAirBlock(pos) && mc.world.isAirBlock(pos.up()) && mc.world.isAirBlock(pos.up(2))) {
/*     */                 blockPos = pos;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */             double x = roundToClosest(mc.player.posX, blockPos.x + 0.02D, blockPos.x + 0.98D);
/*     */             double y = mc.player.posY;
/*     */             double z = roundToClosest(mc.player.posZ, blockPos.z + 0.02D, blockPos.z + 0.98D);
/*     */             Vec3d playerPos = mc.player.getPositionVector();
/*     */             double yawRad = Math.toRadians((RotationUtil.getRotationTo(playerPos, new Vec3d(x, y, z))).x);
/*     */             double dist = Math.hypot(x - playerPos.x, z - playerPos.z);
/*     */             if (x - playerPos.x == 0.0D && z - playerPos.z == 0.0D)
/*     */               this.moved = true; 
/* 154 */             double playerSpeed = MotionUtil.getBaseMoveSpeed() * ((EntityUtil.isColliding(0.0D, -0.5D, 0.0D) instanceof net.minecraft.block.BlockLiquid && !EntityUtil.isInLiquid()) ? 0.91D : 1.0D); double speed = Math.min(dist, playerSpeed); event.setX(-Math.sin(yawRad) * speed); event.setZ(Math.cos(yawRad) * speed); if (LemonClient.speedUtil.getPlayerSpeed((EntityPlayer)mc.player) == 0.0D)
/*     */               this.moved = true;  }  }new java.util.function.Predicate[0]); }
/*     */   private void switchTo(int slot) { if (slot > -1 && slot < 9 && (!((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot))
/*     */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; mc.playerController.updateController(); }   }
/*     */   public void breakCrystal() { AxisAlignedBB axisAlignedBB = new AxisAlignedBB(getFlooredPosition((Entity)mc.player)); List<Entity> l = mc.world.getEntitiesWithinAABBExcludingEntity(null, axisAlignedBB); for (Entity entity : l) { if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) { if (((Boolean)this.antiWk.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) { int newSlot = -1; for (int i = 0; i < 9; i++) { ItemStack stack = mc.player.inventory.getStackInSlot(i); if (stack != ItemStack.EMPTY) { if (stack.getItem() instanceof net.minecraft.item.ItemSword) { newSlot = i; break; }  if (stack.getItem() instanceof net.minecraft.item.ItemTool) { newSlot = i; break; }  }  }
/*     */            int oldSlot = mc.player.inventory.currentItem; if (newSlot != -1)
/*     */             switchTo(newSlot);  mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity)); mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND)); switchTo(oldSlot); continue; }
/*     */          mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity)); mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND)); }
/*     */        }
/* 163 */      } public void onEnable() { this.moved = !((Boolean)this.move.getValue()).booleanValue();
/* 164 */     if (((Boolean)this.onlyOnGround.getValue()).booleanValue() && !mc.player.onGround) {
/* 165 */       disable();
/*     */       return;
/*     */     } 
/* 168 */     if (((Boolean)this.air.getValue()).booleanValue() && mc.world.getBlockState(getFlooredPosition((Entity)mc.player).offset(EnumFacing.DOWN)).getBlock().equals(Blocks.AIR))
/* 169 */       disable();  }
/*     */   public static void back() { for (Entity crystal : mc.world.loadedEntityList.stream().filter(e -> (e instanceof net.minecraft.entity.item.EntityEnderCrystal && !e.isDead)).sorted(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance(e)))).collect(Collectors.toList())) { if (crystal instanceof net.minecraft.entity.item.EntityEnderCrystal) { mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal)); mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND)); }  }
/*     */      }
/*     */   private double roundToClosest(double num, double low, double high) { double d2 = high - num; double d1 = num - low; if (d2 > d1)
/*     */       return low;  return high; }
/* 174 */   private boolean canGoTo(BlockPos pos) { return (isAir(pos) && isAir(pos.up())); } public void onUpdate() { int i; BlockPos bestPos; int j; double distance; BlockPos playerPos = new BlockPos(mc.player.posX, mc.player.posY + 0.5D, mc.player.posZ);
/* 175 */     Vec3d vecPos = new Vec3d(mc.player.posX, (int)(mc.player.posY + 0.5D), mc.player.posZ);
/*     */     
/* 177 */     int a = mc.player.inventory.currentItem;
/* 178 */     int slot = -1;
/* 179 */     switch ((String)this.mode.getValue()) {
/*     */       case "Obsidian":
/* 181 */         slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*     */         break;
/*     */       
/*     */       case "EChest":
/* 185 */         slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/*     */         break;
/*     */       
/*     */       case "EChestObby":
/* 189 */         slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/* 190 */         if (slot == -1) slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*     */         
/*     */         break;
/*     */       case "ObbyEChest":
/* 194 */         slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 195 */         if (slot == -1) slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/*     */         
/*     */         break;
/*     */     } 
/* 199 */     if (slot == -1) {
/* 200 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 204 */     if (((Boolean)this.testMode.getValue()).booleanValue()) {
/* 205 */       if (!this.moved)
/* 206 */         return;  boolean burrow = false;
/* 207 */       for (Vec3d vec3d : this.offsets) {
/* 208 */         if (!isPos2(new BlockPos(vecPos.add(vec3d)), playerPos)) {
/* 209 */           burrow = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 213 */       if (!burrow) {
/* 214 */         disable();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 219 */     if (((Boolean)this.breakCrystal.getValue()).booleanValue()) back();
/*     */     
/* 221 */     if (!mc.world.isBlockLoaded(mc.player.getPosition()) || mc.player.isInLava() || mc.player.isInWater() || mc.player.isInWeb) {
/* 222 */       disable();
/*     */       return;
/*     */     } 
/* 225 */     if (((Boolean)this.tpCenter.getValue()).booleanValue()) {
/* 226 */       PlayerUtil.centerPlayer();
/*     */     }
/* 228 */     boolean bypassed = false;
/* 229 */     if (!fakeBBoxCheck()) {
/* 230 */       if ((((Boolean)this.testMode.getValue()).booleanValue() && !bypassBurrowed()) || ((!BlockUtil.canReplace(playerPos) || !BlockUtil.canReplace(playerPos.up())) && intersect(playerPos.up()))) {
/* 231 */         gotoPos(playerPos);
/*     */       } else {
/* 233 */         List<BlockPos> posList = new ArrayList<>();
/* 234 */         List<BlockPos> airList = new ArrayList<>();
/* 235 */         if (((Boolean)this.testMode.getValue()).booleanValue()) {
/* 236 */           airList.add(playerPos);
/* 237 */           for (Vec3d vec : this.offsets) {
/* 238 */             BlockPos pos = new BlockPos(vecPos.add(vec));
/* 239 */             if (!BlockUtil.isAir(pos.up())) posList.add(pos.up()); 
/*     */           } 
/*     */         } else {
/* 242 */           for (Vec3d vec : this.offsets) {
/* 243 */             boolean air = true;
/* 244 */             BlockPos pos = new BlockPos(vecPos.add(vec));
/* 245 */             for (int k = 0; k < 2; k++) {
/* 246 */               BlockPos blockPos = pos.up(k);
/* 247 */               if (!isAir(blockPos)) air = false; 
/*     */             } 
/* 249 */             if (intersect(pos) && !air) { posList.add(pos); }
/* 250 */             else { airList.add(pos); }
/*     */           
/*     */           } 
/*     */         } 
/* 254 */         BlockPos movePos = posList.isEmpty() ? airList.stream().min(Comparator.comparing(p -> Double.valueOf(mc.player.getDistance(p.x + 0.5D, mc.player.posY, p.z + 0.5D)))).orElse(null) : posList.stream().min(Comparator.comparing(p -> Double.valueOf(mc.player.getDistance(p.x + 0.5D, mc.player.posY, p.z + 0.5D)))).orElse(null);
/* 255 */         gotoPos(movePos);
/*     */       } 
/* 257 */       bypassed = true;
/*     */     } else {
/* 259 */       switch ((String)this.jumpMode.getValue()) {
/*     */         case "Normal":
/* 261 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419999986886978D, mc.player.posZ, false));
/* 262 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7531999805212015D, mc.player.posZ, false));
/* 263 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.001335979112147D, mc.player.posZ, false));
/* 264 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.166109260938214D, mc.player.posZ, false));
/*     */           break;
/*     */         
/*     */         case "Future":
/* 268 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419997486886978D, mc.player.posZ, false));
/* 269 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7500025D, mc.player.posZ, false));
/* 270 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.999995D, mc.player.posZ, false));
/* 271 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170005001788139D, mc.player.posZ, false));
/* 272 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.2426050013947485D, mc.player.posZ, false));
/*     */           break;
/*     */         
/*     */         case "Strict":
/* 276 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419998586886978D, mc.player.posZ, false));
/* 277 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7500014D, mc.player.posZ, false));
/* 278 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.9999972D, mc.player.posZ, false));
/* 279 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170002801788139D, mc.player.posZ, false));
/* 280 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170009801788139D, mc.player.posZ, false));
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 286 */     switchTo(slot);
/* 287 */     if (!((Boolean)this.multiPlace.getValue()).booleanValue()) { placeBlock(new BlockPos((Vec3i)getPlayerPosFixY((EntityPlayer)mc.player))); }
/*     */     else
/* 289 */     { for (Vec3d vec3d : this.offsets) placeBlock(vecPos.add(vec3d)); 
/* 290 */       if (((Boolean)this.head.getValue()).booleanValue() && bypassed) for (Vec3d vec3d : this.offsets) placeBlock(vecPos.add(vec3d).add(0.0D, 1.0D, 0.0D));   }
/*     */     
/* 292 */     switchTo(a);
/*     */     
/* 294 */     switch ((String)this.rubberBand.getValue()) {
/*     */       case "Cn":
/* 296 */         distance = 0.0D;
/* 297 */         bestPos = null;
/* 298 */         for (BlockPos pos : BlockUtil.getBox(6.0F)) {
/* 299 */           if (!canGoTo(pos) || 
/* 300 */             mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 3.0D) {
/*     */             continue;
/*     */           }
/* 303 */           if (bestPos != null && mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) >= distance) {
/*     */             continue;
/*     */           }
/* 306 */           bestPos = pos;
/* 307 */           distance = mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
/*     */         } 
/*     */         
/* 310 */         if (bestPos != null) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(bestPos.getX() + 0.5D, bestPos.getY(), bestPos.getZ() + 0.5D, false)); break; }
/* 311 */          mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Future":
/* 315 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.242609801394749D, mc.player.posZ, false));
/* 316 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 2.340028003576279D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "FutureStrict":
/* 320 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.315205001001358D, mc.player.posZ, false));
/* 321 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.315205001001358D, mc.player.posZ, false));
/* 322 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 2.485225002789497D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Troll":
/* 326 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 3.3400880035762786D, mc.player.posZ, false));
/* 327 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Strict":
/* 331 */         distance = 0.0D;
/* 332 */         bestPos = null;
/* 333 */         for (j = 0; j < 20; j++) {
/* 334 */           BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY + 0.5D + j, mc.player.posZ);
/* 335 */           if (canGoTo(pos) && 
/* 336 */             mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 5.0D && (
/* 337 */             bestPos == null || mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) < distance)) {
/* 338 */             bestPos = pos;
/* 339 */             distance = mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 344 */         if (bestPos != null) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(bestPos.getX() + 0.5D, bestPos.getY(), bestPos.getZ() + 0.5D, false)); break; }
/* 345 */          mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Void":
/* 349 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Auto":
/* 353 */         for (i = -10; i < 10; i++) {
/* 354 */           if (i == -1)
/* 355 */             i = 4; 
/* 356 */           if (mc.world.getBlockState(getFlooredPosition((Entity)mc.player).add(0, i, 0)).getBlock().equals(Blocks.AIR) && mc.world.getBlockState(getFlooredPosition((Entity)mc.player).add(0, i + 1, 0)).getBlock().equals(Blocks.AIR)) {
/* 357 */             BlockPos pos = getFlooredPosition((Entity)mc.player).add(0, i, 0);
/* 358 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(pos.getX() + 0.3D, pos.getY(), pos.getZ() + 0.3D, false));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case "Custom":
/* 365 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + ((Double)this.offsetX.getValue()).doubleValue(), mc.player.posY + ((Double)this.offsetY.getValue()).doubleValue(), mc.player.posZ + ((Double)this.offsetZ.getValue()).doubleValue(), false));
/*     */         break;
/*     */     } 
/*     */     
/* 369 */     disable(); }
/*     */ 
/*     */   
/*     */   private void gotoPos(BlockPos pos) {
/* 373 */     switch ((String)this.bypassMode.getValue()) {
/*     */       case "Normal":
/* 375 */         if (Math.abs(pos.getX() + 0.5D - mc.player.posX) < Math.abs(pos.getZ() + 0.5D - mc.player.posZ)) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.2D, pos.getZ() + 0.5D, true)); break; }
/* 376 */          mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(pos.getX() + 0.5D, mc.player.posY + 0.2D, mc.player.posZ, true));
/*     */         break;
/*     */       
/*     */       case "Middle":
/* 380 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(pos.getX() + 0.5D, mc.player.posY + 0.2D, pos.getZ() + 0.5D, true));
/*     */         break;
/*     */       
/*     */       case "Test":
/* 384 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + (pos.getX() + 0.5D - mc.player.posX) * 0.42132D, mc.player.posY + 0.12160004615784D, mc.player.posZ + (pos.getZ() + 0.5D - mc.player.posZ) * 0.42132D, false));
/* 385 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + (pos.getX() + 0.5D - mc.player.posX) * 0.95D, mc.player.posY + 0.200000047683716D, mc.player.posZ + (pos.getZ() + 0.5D - mc.player.posZ) * 0.95D, false));
/* 386 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + (pos.getX() + 0.5D - mc.player.posX) * 1.03D, mc.player.posY + 0.200000047683716D, mc.player.posZ + (pos.getZ() + 0.5D - mc.player.posZ) * 1.03D, false));
/* 387 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + (pos.getX() + 0.5D - mc.player.posX) * 1.0933D, mc.player.posY + 0.12160004615784D, mc.player.posZ + (pos.getZ() + 0.5D - mc.player.posZ) * 1.0933D, false));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean intersect(BlockPos pos) {
/* 394 */     return mc.player.boundingBox.intersects(mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos));
/*     */   }
/*     */   
/*     */   public static BlockPos getFlooredPosition(Entity entity) {
/* 398 */     return new BlockPos(Math.floor(entity.posX), Math.round(entity.posY), Math.floor(entity.posZ));
/*     */   }
/*     */   
/*     */   private boolean fakeBBoxCheck() {
/* 402 */     Vec3d playerPos = mc.player.getPositionVector();
/* 403 */     playerPos = new Vec3d(playerPos.x, (int)(playerPos.y + 0.5D), playerPos.z);
/* 404 */     for (Vec3d vec : this.offsets) {
/* 405 */       for (int i = 0; i < 3; i++) {
/* 406 */         BlockPos pos = new BlockPos(playerPos.add(vec).add(0.0D, i, 0.0D));
/* 407 */         if ((i >= 2 || intersect(pos)) && 
/* 408 */           !isAir(pos)) return false; 
/*     */       } 
/*     */     } 
/* 411 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isAir(Vec3d vec3d) {
/* 415 */     return isAir(new BlockPos(vec3d));
/*     */   }
/*     */   public static boolean isAir(BlockPos pos) {
/* 418 */     return BlockUtil.canReplace(pos);
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 422 */     BlockUtil.placeBlockBoolean(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/*     */   }
/*     */   
/*     */   public static Vec3d getEyesPos() {
/* 426 */     return new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 430 */     if (pos1 == null || pos2 == null)
/* 431 */       return false; 
/* 432 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   private void placeBlock(Vec3d vec3d) {
/* 436 */     BlockPos pos = new BlockPos(vec3d);
/* 437 */     if (((Boolean)this.testMode.getValue()).booleanValue() && (!bypassBurrowed() || !((Boolean)this.head.getValue()).booleanValue()) && isPos2(pos, PlayerUtil.getPlayerPos()))
/* 438 */       return;  placeBlock(pos);
/*     */   }
/*     */   
/*     */   private BlockPos getPlayerPosFixY(EntityPlayer player) {
/* 442 */     return new BlockPos(Math.floor(player.posX), Math.round(player.posY), Math.floor(player.posZ));
/*     */   }
/*     */   
/*     */   private boolean bypassBurrowed() {
/* 446 */     Vec3d pos = new Vec3d(mc.player.posX, (int)(mc.player.posY + 0.5D), mc.player.posZ);
/* 447 */     for (Vec3d vec3d : this.offsets) {
/* 448 */       if (!BlockUtil.isAir((new BlockPos(pos.add(vec3d))).up())) return true; 
/*     */     } 
/* 450 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\BurrowBypass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
