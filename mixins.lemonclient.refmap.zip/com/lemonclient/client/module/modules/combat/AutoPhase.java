//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoPhase", category = Category.Combat)
/*     */ public class AutoPhase extends Module {
/*     */   ModeSetting mode;
/*     */   ModeSetting bound;
/*     */   BooleanSetting twoBeePvP;
/*     */   BooleanSetting update;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting mine;
/*     */   BooleanSetting burrow;
/*     */   BooleanSetting doubleBurrow;
/*     */   IntegerSetting entity;
/*     */   BooleanSetting ignoreCrystal;
/*     */   IntegerSetting checkDelay;
/*     */   BlockPos originalPos;
/*     */   boolean down;
/*     */   Timing timing;
/*     */   Timing timer;
/*     */   int tpid;
/*     */   List<Block> blockList;
/*     */   BlockPos[] sides;
/*     */   BlockPos[] height;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   
/*  43 */   public AutoPhase() { this.mode = registerMode("Mode", Arrays.asList(new String[] { "5b", "Jp" }, ), "5b");
/*  44 */     this.bound = registerMode("Bounds", PhaseUtil.bound, "Min", () -> Boolean.valueOf(((String)this.mode.getValue()).equals("5b")));
/*  45 */     this.twoBeePvP = registerBoolean("2b2tpvp", false, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("5b")));
/*  46 */     this.update = registerBoolean("Update Pos", false, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("5b")));
/*  47 */     this.packet = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  48 */     this.swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  49 */     this.mine = registerBoolean("Mine", true, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  50 */     this.burrow = registerBoolean("Try Burrow", true, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  51 */     this.doubleBurrow = registerBoolean("Double", true, () -> Boolean.valueOf((((String)this.mode.getValue()).equals("Jp") && ((Boolean)this.burrow.getValue()).booleanValue())));
/*  52 */     this.entity = registerInteger("Entity Time", 5, 0, 10, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  53 */     this.ignoreCrystal = registerBoolean("Ignore Crystal", true, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*  54 */     this.checkDelay = registerInteger("Check Time", 50, 0, 500, () -> Boolean.valueOf(((String)this.mode.getValue()).equals("Jp")));
/*     */ 
/*     */     
/*  57 */     this.timing = new Timing();
/*  58 */     this.timer = new Timing();
/*  59 */     this.tpid = 0;
/*  60 */     this.blockList = Arrays.asList(new Block[] { Blocks.BEDROCK, Blocks.OBSIDIAN, Blocks.ENDER_CHEST, Blocks.ANVIL });
/*  61 */     this.sides = new BlockPos[] { new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.height = new BlockPos[] { new BlockPos(0, 0, 0), new BlockPos(0, 1, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.receiveListener = new Listener(event -> { if (event.getPacket() instanceof SPacketPlayerPosLook) this.tpid = ((SPacketPlayerPosLook)event.getPacket()).teleportId;  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.sendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketPlayer.PositionRotation || event.getPacket() instanceof CPacketPlayer.Position) this.tpid++;  }new java.util.function.Predicate[0]); }
/*     */   public void onEnable() { if (((String)this.mode.getValue()).equals("Jp")) {
/*     */       this.down = true; this.originalPos = PlayerUtil.getPlayerPos(); this.originalPos = new BlockPos(this.originalPos.x, this.originalPos.y + 0.2D, this.originalPos.z); if (BurrowUtil.findHotbarBlock(BlockTrapDoor.class) == -1 || !mc.world.isAirBlock(this.originalPos)) {
/*     */         disable(); return;
/*     */       }  mc.player.setPosition(mc.player.posX, (int)mc.player.posY, mc.player.posZ); this.timing.reset();
/*     */       this.timer.reset();
/*     */       this.down = false;
/*     */     }  }
/*     */   public void onDisable() { if (((String)this.mode.getValue()).equals("Jp") && ModuleManager.isModuleEnabled(PacketMine.class))
/* 150 */       PacketMine.INSTANCE.lastBlock = null;  } private void trapdoor() { if (mc.world == null || mc.player == null || mc.player.isDead || this.originalPos == null) {
/* 151 */       disable();
/*     */       return;
/*     */     } 
/* 154 */     if (!this.down) {
/* 155 */       if (BurrowUtil.findHotbarBlock(BlockTrapDoor.class) == -1) {
/* 156 */         disable();
/*     */         return;
/*     */       } 
/* 159 */       if (intersectsWithEntity(this.originalPos) && this.timer.passedS(((Integer)this.entity.getValue()).intValue())) {
/* 160 */         disable();
/*     */         return;
/*     */       } 
/* 163 */       EnumFacing facing = BurrowUtil.getTrapdoorFacing(this.originalPos);
/* 164 */       BlockPos burrowPos = null;
/*     */       
/* 166 */       for (BlockPos side : this.sides) {
/* 167 */         BlockPos blockPos = PlayerUtil.getPlayerPos().add((Vec3i)side);
/* 168 */         if (BlockUtil.getBlock(blockPos) == Blocks.BEDROCK || BlockUtil.getBlock(blockPos) == Blocks.OBSIDIAN) {
/* 169 */           burrowPos = blockPos;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 174 */       int obsidian = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 175 */       if (facing == null || (burrowPos == null && ((Boolean)this.burrow.getValue()).booleanValue())) {
/* 176 */         if (((Boolean)this.burrow.getValue()).booleanValue()) {
/* 177 */           boolean placed = false;
/* 178 */           if (obsidian != -1) {
/* 179 */             for (BlockPos side : this.sides) {
/* 180 */               BlockPos blockPos = PlayerUtil.getPlayerPos().add((Vec3i)side);
/* 181 */               if (!intersectsWithEntity(blockPos) && BlockUtil.hasNeighbour(blockPos)) {
/* 182 */                 mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(obsidian));
/* 183 */                 BurrowUtil.placeBlock(blockPos, EnumHand.MAIN_HAND, false, false, false, false);
/* 184 */                 if (((Boolean)this.doubleBurrow.getValue()).booleanValue()) BurrowUtil.placeBlock(blockPos.up(), EnumHand.MAIN_HAND, false, false, false, false); 
/* 185 */                 placed = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           }
/* 190 */           if (!placed) {
/* 191 */             disable(); return;
/*     */           } 
/*     */         } else {
/* 194 */           disable();
/*     */         }  return;
/* 196 */       }  if (((Boolean)this.burrow.getValue()).booleanValue() && ((Boolean)this.doubleBurrow.getValue()).booleanValue() && BlockUtil.isAir(burrowPos.up())) {
/* 197 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(obsidian));
/* 198 */         BurrowUtil.placeBlock(burrowPos.up(), EnumHand.MAIN_HAND, false, false, false, false);
/*     */       } 
/* 200 */       BlockPos neighbour = this.originalPos.offset(facing);
/* 201 */       EnumFacing opposite = facing.getOpposite();
/*     */       
/* 203 */       double x = mc.player.posX;
/* 204 */       double y = mc.player.posY;
/* 205 */       double z = mc.player.posZ;
/* 206 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y + 0.20000000298023224D, z, mc.player.onGround));
/* 207 */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(BurrowUtil.findHotbarBlock(BlockTrapDoor.class)));
/* 208 */       boolean sneak = false;
/* 209 */       if ((BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) || BlockUtil.shulkerList.contains(mc.world.getBlockState(neighbour).getBlock())) && !mc.player.isSneaking()) {
/* 210 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 211 */         mc.player.setSneaking(true);
/* 212 */         sneak = true;
/*     */       } 
/* 214 */       rightClickBlock(neighbour, opposite, new Vec3d(0.5D, 0.8D, 0.5D), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 215 */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(mc.player.inventory.currentItem));
/* 216 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y, z, mc.player.onGround));
/* 217 */       if (sneak) {
/* 218 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/* 219 */         mc.player.setSneaking(false);
/*     */       } 
/* 221 */       if (((Boolean)this.burrow.getValue()).booleanValue()) {
/* 222 */         if (burrowPos == null)
/* 223 */           return;  mc.player.setPosition(burrowPos.x + 0.5D, burrowPos.y, burrowPos.z + 0.5D);
/* 224 */         disable();
/*     */       } else {
/* 226 */         int bedrocks = 0;
/* 227 */         int blocks = 0;
/* 228 */         double xAdd = 0.0D;
/* 229 */         double zAdd = 0.0D;
/* 230 */         for (BlockPos side : this.sides) {
/* 231 */           for (BlockPos add : this.sides) {
/* 232 */             if (!isPos2(this.originalPos, this.originalPos.add((Vec3i)side).add((Vec3i)add)) && !isPos2(side, add)) {
/*     */               
/* 234 */               int bedrock = 0;
/* 235 */               int block = 0;
/* 236 */               BlockPos sidePos = this.originalPos.add((Vec3i)side);
/* 237 */               BlockPos addPos = this.originalPos.add((Vec3i)add);
/* 238 */               BlockPos addSide = this.originalPos.add((Vec3i)side).add((Vec3i)add);
/* 239 */               for (BlockPos high : this.height) {
/* 240 */                 Block sideState = mc.world.getBlockState(sidePos.add((Vec3i)high)).getBlock();
/* 241 */                 Block addState = mc.world.getBlockState(addPos.add((Vec3i)high)).getBlock();
/* 242 */                 Block addSideState = mc.world.getBlockState(addSide.add((Vec3i)high)).getBlock();
/* 243 */                 if (this.blockList.contains(sideState))
/* 244 */                   block += 3; 
/* 245 */                 if (sideState == Blocks.BEDROCK)
/* 246 */                   bedrock += 3; 
/* 247 */                 if (this.blockList.contains(addState))
/* 248 */                   block += 3; 
/* 249 */                 if (addState == Blocks.BEDROCK)
/* 250 */                   bedrock += 3; 
/* 251 */                 if (this.blockList.contains(addSideState))
/* 252 */                   block++; 
/* 253 */                 if (addSideState == Blocks.BEDROCK)
/* 254 */                   bedrock++; 
/*     */               } 
/* 256 */               boolean shouldSet = false;
/* 257 */               if (block > blocks) { shouldSet = true; }
/* 258 */               else if (block == blocks && bedrock > bedrocks) { shouldSet = true; }
/* 259 */                if (shouldSet) {
/* 260 */                 bedrocks = bedrock;
/* 261 */                 blocks = block;
/* 262 */                 xAdd = getAdd(side.x + add.x);
/* 263 */                 zAdd = getAdd(side.z + add.z);
/*     */               } 
/*     */             } 
/*     */           } 
/* 267 */         }  mc.player.setPosition(this.originalPos.getX() + xAdd, this.originalPos.getY(), this.originalPos.getZ() + zAdd);
/* 268 */         mc.player.motionX = 0.0D;
/* 269 */         mc.player.motionZ = 0.0D;
/* 270 */         if (mc.player.posX == this.originalPos.getX() + xAdd && mc.player.posZ == this.originalPos.getZ() + zAdd && !mc.world.isAirBlock(this.originalPos) && 
/* 271 */           this.timing.passedMs(((Integer)this.checkDelay.getValue()).intValue())) this.down = true; 
/*     */       } 
/*     */     } 
/* 274 */     if (this.down)
/* 275 */     { this.timing.reset();
/* 276 */       mc.player.motionX = 0.0D;
/* 277 */       mc.player.motionZ = 0.0D;
/* 278 */       if (((Boolean)this.mine.getValue()).booleanValue()) { mc.playerController.onPlayerDamageBlock(this.originalPos, EnumFacing.UP); }
/* 279 */       else { disable(); }
/* 280 */        if (mc.world.isAirBlock(this.originalPos))
/* 281 */         disable();  }  }
/*     */   public void onUpdate() { if (((String)this.mode.getValue()).equals("Jp")) { trapdoor(); } else { packetFly(); }  }
/*     */   void packetFly() { double[] clip = MotionUtil.forward(0.0624D); if (mc.player.onGround) { tp(0.0D, -0.0624D, 0.0D, false); } else { tp(clip[0], 0.0D, clip[1], true); }  disable(); }
/*     */   void tp(double x, double y, double z, boolean onGround) { double[] dir = MotionUtil.forward(-0.0312D); if (((Boolean)this.twoBeePvP.getValue()).booleanValue())
/*     */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX + dir[0], mc.player.posY, mc.player.posZ + dir[1], onGround));  mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position((((Boolean)this.twoBeePvP.getValue()).booleanValue() ? (x / 2.0D) : x) + mc.player.posX, y + mc.player.posY, (((Boolean)this.twoBeePvP.getValue()).booleanValue() ? (z / 2.0D) : z) + mc.player.posZ, onGround)); mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(this.tpid - 1)); mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(this.tpid)); mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(this.tpid + 1)); PhaseUtil.doBounds((String)this.bound.getValue(), true); if (((Boolean)this.update.getValue()).booleanValue())
/* 286 */       mc.player.setPosition(x, y, z);  } private double getAdd(int pos) { if (pos == 1) return 0.99999999D; 
/* 287 */     return 0.0D; }
/*     */ 
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 291 */     if (pos1 == null || pos2 == null)
/* 292 */       return false; 
/* 293 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, EnumFacing facing, Vec3d hVec, boolean packet, boolean swing) {
/* 297 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(hVec).add((new Vec3d(facing.getDirectionVec())).scale(0.5D));
/*     */     
/* 299 */     if (packet) {
/* 300 */       rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, facing);
/*     */     } else {
/* 302 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, hitVec, EnumHand.MAIN_HAND);
/*     */     } 
/* 304 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction) {
/* 308 */     float f = (float)(vec.x - pos.getX());
/* 309 */     float f1 = (float)(vec.y - pos.getY());
/* 310 */     float f2 = (float)(vec.z - pos.getZ());
/* 311 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 315 */     for (Entity entity : mc.world.loadedEntityList) {
/* 316 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 317 */         !(entity instanceof net.minecraft.entity.item.EntityEnderCrystal) || !((Boolean)this.ignoreCrystal.getValue()).booleanValue()) && 
/* 318 */         entity != mc.player && (
/* 319 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) {
/* 320 */         return true;
/*     */       }
/*     */     } 
/* 323 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoPhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
