//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Pair;
/*     */ import com.lemonclient.api.util.player.PlayerPacket;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import java.util.Arrays;
/*     */ import java.util.Optional;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "KillAura", category = Category.Combat)
/*     */ public class KillAura extends Module {
/*     */   ModeSetting itemUsed;
/*     */   ModeSetting enemyPriority;
/*     */   BooleanSetting silentaura;
/*     */   BooleanSetting tp;
/*     */   BooleanSetting e;
/*     */   BooleanSetting strafe;
/*     */   BooleanSetting caCheck;
/*     */   BooleanSetting criticals;
/*     */   BooleanSetting stopspring;
/*     */   BooleanSetting rotation;
/*     */   
/*  41 */   public KillAura() { this.itemUsed = registerMode("Item used", Arrays.asList(new String[] { "Sword", "All" }, ), "Sword");
/*  42 */     this.enemyPriority = registerMode("Enemy Priority", Arrays.asList(new String[] { "Closest", "Health" }, ), "Closest");
/*  43 */     this.silentaura = registerBoolean("SilentAura", false);
/*  44 */     this.tp = registerBoolean("Tp Aura", false);
/*  45 */     this.e = registerBoolean("SA", false, () -> (Boolean)this.tp.getValue());
/*  46 */     this.strafe = registerBoolean("Shift Strafe", true);
/*  47 */     this.caCheck = registerBoolean("AC Check", false);
/*  48 */     this.criticals = registerBoolean("Criticals", true);
/*  49 */     this.stopspring = registerBoolean("Stop Spring", true);
/*  50 */     this.rotation = registerBoolean("Rotation", true);
/*  51 */     this.autoSwitch = registerBoolean("Switch", false);
/*  52 */     this.swing = registerBoolean("Swing", false);
/*  53 */     this.switchHealth = registerDouble("Min Switch Health", 0.0D, 0.0D, 20.0D);
/*  54 */     this.range = registerDouble("Range", 5.0D, 0.0D, 25.0D);
/*  55 */     this.srange = registerDouble("Silent Range", 5.0D, 0.0D, 6.0D);
/*     */     
/*  57 */     this.isAttacking = false;
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.newSlot = new Pair(Float.valueOf(0.0F), Integer.valueOf(-1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     this.listener = new Listener(event -> { if (event.getPacket() instanceof CPacketUseEntity && ((Boolean)this.criticals.getValue()).booleanValue() && ((CPacketUseEntity)event.getPacket()).getAction() == CPacketUseEntity.Action.ATTACK && mc.player.onGround && this.isAttacking) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.10000000149011612D, mc.player.posZ, false)); mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false)); }  }new java.util.function.Predicate[0]); }
/*     */   BooleanSetting autoSwitch; BooleanSetting swing; DoubleSetting switchHealth; DoubleSetting range; DoubleSetting srange; private boolean isAttacking; Entity target; public static boolean SA; Pair<Float, Integer> newSlot; int temp; @EventHandler private final Listener<PacketEvent.Send> listener; public void onUpdate() { if (!((Boolean)this.silentaura.getValue()).booleanValue())
/*     */       SA = false;  if (mc.player == null || !mc.player.isEntityAlive())
/*     */       return;  double rangeSq = ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue(); Optional<EntityPlayer> optionalTarget = mc.world.playerEntities.stream().filter(entity -> !EntityUtil.basicChecksEntity(entity)).filter(entity -> (mc.player.getDistanceSq((Entity)entity) <= rangeSq)).min(Comparator.comparing(e -> Double.valueOf(((String)this.enemyPriority.getValue()).equals("Closest") ? mc.player.getDistanceSq((Entity)e) : e.getHealth()))); boolean sword = ((String)this.itemUsed.getValue()).equalsIgnoreCase("Sword"); boolean all = ((String)this.itemUsed.getValue()).equalsIgnoreCase("All"); if (optionalTarget.isPresent()) { this.newSlot = findSwordSlot(); this.temp = mc.player.inventory.currentItem; if (((Boolean)this.silentaura.getValue()).booleanValue() || shouldAttack(sword, all)) { if (((Integer)this.newSlot.getValue()).intValue() == -1)
/*     */           return;  if (((Boolean)this.autoSwitch.getValue()).booleanValue() && (mc.player.getHealth() + mc.player.getAbsorptionAmount()) >= ((Double)this.switchHealth.getValue()).doubleValue() && ((Integer)this.newSlot.getValue()).intValue() != -1)
/*     */           mc.player.inventory.currentItem = ((Integer)this.newSlot.getValue()).intValue();  this.target = (Entity)optionalTarget.get(); if (((Boolean)this.rotation.getValue()).booleanValue()) { Vec2f rotation = RotationUtil.getRotationTo(this.target.getEntityBoundingBox()); PlayerPacket packet = new PlayerPacket(this, rotation); PlayerPacketManager.INSTANCE.addPacket(packet); }
/*     */          SA = true; attack(this.target); }
/*     */       else
/*     */       { SA = false; mc.player.inventory.currentItem = this.temp; }
/*     */        }
/*     */     else
/*     */     { SA = false; }
/* 125 */      } private Pair<Float, Integer> findSwordSlot() { List<Integer> items = InventoryUtil.findAllItemSlots(ItemSword.class);
/* 126 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 128 */     float bestModifier = 0.0F;
/* 129 */     int correspondingSlot = -1;
/* 130 */     for (Integer integer : items) {
/* 131 */       if (integer.intValue() > 8) {
/*     */         continue;
/*     */       }
/*     */       
/* 135 */       ItemStack stack = nonNullList.get(integer.intValue());
/* 136 */       float modifier = (EnchantmentHelper.getModifierForCreature(stack, EnumCreatureAttribute.UNDEFINED) + 1.0F) * ((ItemSword)stack.getItem()).getAttackDamage();
/*     */       
/* 138 */       if (modifier > bestModifier) {
/* 139 */         bestModifier = modifier;
/* 140 */         correspondingSlot = integer.intValue();
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     return new Pair(Float.valueOf(bestModifier), Integer.valueOf(correspondingSlot)); }
/*     */ 
/*     */   
/*     */   private boolean shouldAttack(boolean sword, boolean all) {
/* 148 */     Item item = mc.player.getHeldItemMainhand().getItem();
/* 149 */     return (all || (sword && item instanceof ItemSword && 
/*     */       
/* 151 */       !((Boolean)this.caCheck.getValue()).booleanValue()));
/*     */   }
/*     */   
/*     */   private void attack(Entity e) {
/* 155 */     if (mc.player.getCooledAttackStrength(0.0F) >= 1.0F) {
/* 156 */       this.isAttacking = true;
/* 157 */       SA = true;
/* 158 */       boolean switched = false;
/* 159 */       if (((Boolean)this.stopspring.getValue()).booleanValue()) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SPRINTING)); 
/* 160 */       if (((Boolean)this.silentaura.getValue()).booleanValue()) {
/* 161 */         if (((Integer)this.newSlot.getValue()).intValue() != -1) {
/* 162 */           if (mc.player.inventory.currentItem != ((Integer)this.newSlot.getValue()).intValue()) {
/* 163 */             if (mc.player.getDistanceSq(e) > ((Double)this.srange.getValue()).doubleValue() * ((Double)this.srange.getValue()).doubleValue())
/*     */               return; 
/* 165 */             switched = true;
/* 166 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(((Integer)this.newSlot.getValue()).intValue()));
/*     */           } 
/*     */         } else {
/* 169 */           SA = false;
/*     */           return;
/*     */         } 
/*     */       }
/* 173 */       double lastX = mc.player.posX;
/* 174 */       double lastY = mc.player.posY;
/* 175 */       double lastZ = mc.player.posZ;
/* 176 */       if ((!switched || ((Boolean)this.e.getValue()).booleanValue()) && ((Boolean)this.tp.getValue()).booleanValue()) tpGoBrrrrr(e.posX, e.posY, e.posZ); 
/* 177 */       mc.playerController.attackEntity((EntityPlayer)mc.player, e);
/* 178 */       if ((!switched || ((Boolean)this.e.getValue()).booleanValue()) && ((Boolean)this.tp.getValue()).booleanValue()) tpGoBrrrrr(lastX, lastY, lastZ); 
/* 179 */       if (((Boolean)this.strafe.getValue()).booleanValue() && mc.gameSettings.keyBindSneak.isKeyDown()) {
/* 180 */         double r = Math.toRadians(mc.player.ticksExisted) * 6.19208751D;
/* 181 */         double dist = Math.sqrt(Math.pow(e.posX - mc.player.posX, 2.0D) + Math.pow(e.posZ - mc.player.posZ, 2.0D));
/* 182 */         double dx = e.posX + ((dist > 8.0D) ? 0.0D : (Math.sin(r) * 8.0D)) - mc.player.posX;
/* 183 */         double dz = e.posZ + ((dist > 8.0D) ? 0.0D : (Math.cos(r) * 8.0D)) - mc.player.posZ;
/* 184 */         double dy = e.posY - mc.player.posY;
/* 185 */         double speed = 1.0D;
/* 186 */         mc.player.motionX = Math.max(Math.min(dx, speed), -speed);
/* 187 */         mc.player.motionZ = Math.max(Math.min(dz, speed), -speed);
/* 188 */         TimerUtils.setSpeed(1.2F);
/* 189 */         mc.player.motionY = ((mc.player.movementInput.jump ? 1 : 0) + (mc.player.movementInput.sneak ? -1 : 0)) + Math.max(Math.min(dy, 1.0D), -1.0D);
/*     */       } 
/* 191 */       if (switched) {
/* 192 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.temp));
/*     */       }
/* 194 */       if (((Boolean)this.swing.getValue()).booleanValue()) {
/* 195 */         mc.player.swingArm(EnumHand.MAIN_HAND);
/*     */       }
/* 197 */       this.isAttacking = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void tpGoBrrrrr(double x, double y, double z) {
/* 202 */     EntityPlayerSP player = mc.player;
/* 203 */     double dist = 5.0D;
/* 204 */     for (int i = 0; i < 20 && dist > 1.0D; i++) {
/*     */       
/* 206 */       double dx = x - player.posX;
/* 207 */       double dy = y - player.posY;
/* 208 */       double dz = z - player.posZ;
/*     */       
/* 210 */       double hdist = Math.sqrt(dx * dx + dz * dz);
/*     */       
/* 212 */       double rx = Math.atan2(dx, dz);
/* 213 */       double ry = Math.atan2(dy, hdist);
/*     */       
/* 215 */       dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
/* 216 */       double o = (dist > 1.0D) ? 1.0D : dist;
/* 217 */       Vec3d vec = new Vec3d(Math.sin(rx) * Math.cos(ry) * o, o * Math.sin(ry * 1.0D), Math.cos(rx) * Math.cos(ry) * o);
/* 218 */       mc.player.move(MoverType.SELF, vec.x, vec.y, vec.z);
/*     */       
/* 220 */       vClip2(0.0D, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void vClip2(double d, boolean onGround) {
/* 225 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + d, mc.player.posZ, onGround));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\KillAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
