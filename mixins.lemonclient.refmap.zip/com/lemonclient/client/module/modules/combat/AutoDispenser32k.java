//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MathUtil;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Declaration(name = "AutoDispenser32k", category = Category.Combat)
/*     */ public class AutoDispenser32k
/*     */   extends Module
/*     */ {
/*     */   private static final int scale = 1;
/*  49 */   private static final RoundingMode roundingMode = RoundingMode.CEILING; private int hopperSlot; private int redstoneSlot; private int shulkerSlot; private int dispenserSlot;
/*     */   private int obiSlot;
/*     */   private int stage;
/*  52 */   DoubleSetting range = registerDouble("PlaceRange", 4.0D, 0.0D, 10.0D);
/*  53 */   DoubleSetting yRange = registerDouble("Y Range", 2.5D, 0.0D, 10.0D);
/*  54 */   DoubleSetting targetRange = registerDouble("Target Range", 4.0D, 0.0D, 16.0D);
/*  55 */   BooleanSetting placeCloseToEnemy = registerBoolean("Place Close To Enemy", true);
/*  56 */   BooleanSetting hopperWait = registerBoolean("HopperWait", true);
/*  57 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  58 */   BooleanSetting dispenserRotate = registerBoolean("Dispenser Rotate", false);
/*  59 */   BooleanSetting packet = registerBoolean("Packet", false);
/*  60 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  61 */   BooleanSetting silent = registerBoolean("Silent", true);
/*  62 */   BooleanSetting debugMessages = registerBoolean("Debug Messages", false); private int delay; private int waited;
/*     */   private int oldslot;
/*     */   DispenserPos placeTarget;
/*     */   
/*     */   private double getWeight(BlockPos pos, EntityPlayer target) {
/*  67 */     double range = target.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D);
/*  68 */     if (range >= ((Double)this.targetRange.getValue()).doubleValue()) {
/*  69 */       int y = 256 - pos.getY();
/*  70 */       range += (y * 100);
/*     */     } 
/*  72 */     return range;
/*     */   }
/*     */   private List<DispenserPos> getPlaceableBlocks() {
/*  75 */     List<DispenserPos> posList = new ArrayList<>();
/*  76 */     for (BlockPos pos : EntityUtil.getSphere(PlayerUtil.getEyesPos(), (Double)this.range.getValue(), (Double)this.yRange.getValue(), false, false, 0)) {
/*  77 */       for (EnumFacing facing : EnumFacing.HORIZONTALS) {
/*  78 */         BlockPos base = pos.down();
/*  79 */         BlockPos shulker = pos.offset(facing);
/*  80 */         BlockPos redstone = getRedStonePos(pos, shulker);
/*  81 */         if (redstone != null) {
/*  82 */           BlockPos hopper = pos.down().offset(facing);
/*  83 */           if (isAreaPlaceable(base, pos, shulker, redstone, hopper)) posList.add(new DispenserPos(base, pos, redstone, shulker, hopper)); 
/*     */         } 
/*     */       } 
/*  86 */     }  return posList;
/*     */   }
/*     */   
/*     */   private boolean isAreaPlaceable(BlockPos base, BlockPos dispenser, BlockPos shulker, BlockPos redstone, BlockPos hopper) {
/*  90 */     if (!inRange(dispenser) || !inRange(redstone) || !inRange(hopper)) return false; 
/*  91 */     if (Math.abs(dispenser.y - mc.player.posY + mc.player.getEyeHeight()) >= 2.0D && Math.sqrt(mc.player.getDistance(dispenser.x + 0.5D, mc.player.posY, dispenser.z + 0.5D)) <= 2.0D)
/*  92 */       return false; 
/*  93 */     if ((BurrowUtil.getFirstFacing(dispenser) == null || BurrowUtil.getFirstFacing(hopper) == null) && (
/*  94 */       intersectsWithEntity(base) || BurrowUtil.getFirstFacing(base) == null || !BlockUtil.canReplace(base) || !inRange(base))) return false; 
/*  95 */     return (canPlace(dispenser) && canPlace(shulker) && canPlace(redstone) && canPlace(hopper));
/*     */   }
/*     */   public void onEnable() {
/*  98 */     if (mc.player == null || mc.world == null || mc.player.isDead) {
/*  99 */       disable();
/*     */       return;
/*     */     } 
/* 102 */     this.placeTarget = null;
/* 103 */     this.oldslot = mc.player.inventory.currentItem;
/* 104 */     this.hopperSlot = this.redstoneSlot = this.shulkerSlot = this.dispenserSlot = this.obiSlot = -1; int i;
/* 105 */     for (i = 0; i < 36; i++) {
/* 106 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 107 */       if (stack != ItemStack.EMPTY && 
/* 108 */         stack.getItem() instanceof ItemBlock) {
/* 109 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 110 */         if (BlockUtil.shulkerList.contains(block)) {
/* 111 */           this.shulkerSlot = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 117 */     for (i = 0; i < 9 && (this.obiSlot == -1 || this.dispenserSlot == -1 || this.redstoneSlot == -1 || this.hopperSlot == -1); i++) {
/* 118 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 119 */       if (stack != ItemStack.EMPTY && 
/* 120 */         stack.getItem() instanceof ItemBlock) {
/* 121 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 122 */         if (block == Blocks.HOPPER) {
/* 123 */           this.hopperSlot = i;
/* 124 */         } else if (block == Blocks.OBSIDIAN) {
/* 125 */           this.obiSlot = i;
/* 126 */         } else if (block == Blocks.DISPENSER) {
/* 127 */           this.dispenserSlot = i;
/* 128 */         } else if (block == Blocks.REDSTONE_BLOCK) {
/* 129 */           this.redstoneSlot = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     if (this.obiSlot == -1 || this.dispenserSlot == -1 || this.shulkerSlot == -1 || this.redstoneSlot == -1 || this.hopperSlot == -1) {
/* 135 */       if (((Boolean)this.debugMessages.getValue()).booleanValue()) MessageBus.sendClientPrefixMessage("Item missing, " + ((ColorMain)ModuleManager.getModule(ColorMain.class)).getModuleColor() + "AutoDispenser32k" + ChatFormatting.GRAY + " disabling.", Notification.Type.ERROR); 
/* 136 */       disable();
/*     */     } 
/*     */     
/* 139 */     this.stage = 0;
/*     */   }
/*     */   
/*     */   public BlockPos getRedStonePos(BlockPos dispenser, BlockPos shulkerPos) {
/* 143 */     List<BlockPos> redstone = new ArrayList<>();
/* 144 */     for (EnumFacing facing : EnumFacing.VALUES) {
/* 145 */       if (facing != EnumFacing.DOWN) {
/* 146 */         BlockPos redstonePos = dispenser.offset(facing);
/* 147 */         if (canPlace(redstonePos) && !isPos2(redstonePos, shulkerPos))
/* 148 */           redstone.add(redstonePos); 
/*     */       } 
/*     */     } 
/* 151 */     return redstone.stream().min(Comparator.comparing(p -> Double.valueOf(mc.player.getDistance(p.getX() + 0.5D, p.getY() + 0.5D, p.getZ() + 0.5D)))).orElse(null);
/*     */   } public void onUpdate() {
/*     */     List<DispenserPos> canPlaceLocation;
/*     */     EntityPlayer targetPlayer;
/*     */     float[] angle;
/* 156 */     if (mc.player == null || mc.world == null || mc.player.isDead) {
/* 157 */       disable();
/*     */       return;
/*     */     } 
/* 160 */     switch (this.stage) {
/*     */       case 0:
/* 162 */         this.delay = 10;
/* 163 */         this.waited = 0;
/* 164 */         canPlaceLocation = getPlaceableBlocks();
/* 165 */         targetPlayer = mc.world.playerEntities.stream().filter(e -> (e != mc.player && !SocialManager.isFriend(e.getName()))).min(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance((Entity)e)))).orElse(null);
/* 166 */         if (targetPlayer != null)
/* 167 */         { if (((Boolean)this.placeCloseToEnemy.getValue()).booleanValue()) { this.placeTarget = canPlaceLocation.stream().min(Comparator.comparing(e -> Double.valueOf(BlockUtil.blockDistance(e.hopper.x + 0.5D, e.hopper.y + 0.5D, e.hopper.z + 0.5D, (Entity)targetPlayer)))).orElse(null); }
/* 168 */           else { this.placeTarget = canPlaceLocation.stream().max(Comparator.comparing(e -> Double.valueOf(getWeight(e.hopper, targetPlayer)))).orElse(null); }  }
/* 169 */         else { this.placeTarget = canPlaceLocation.stream().min(Comparator.comparing(e -> Double.valueOf(BlockUtil.blockDistance(e.hopper.x, e.hopper.y, e.hopper.z, (Entity)mc.player)))).orElse(null); }
/* 170 */          if (this.placeTarget == null) {
/* 171 */           if (((Boolean)this.debugMessages.getValue()).booleanValue()) MessageBus.sendClientPrefixMessage("No suitable place to place, " + ((ColorMain)ModuleManager.getModule(ColorMain.class)).getModuleColor() + "AutoDispenser32k" + ChatFormatting.GRAY + " disabling.", Notification.Type.ERROR); 
/* 172 */           disable();
/*     */           
/*     */           break;
/*     */         } 
/* 176 */         if (BurrowUtil.getFirstFacing(this.placeTarget.dispenser) == null || BurrowUtil.getFirstFacing(this.placeTarget.hopper) == null) {
/* 177 */           mc.player.inventory.currentItem = this.obiSlot;
/* 178 */           BurrowUtil.placeBlock(this.placeTarget.base, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */         } 
/* 180 */         mc.player.inventory.currentItem = this.dispenserSlot;
/* 181 */         angle = MathUtil.calcAngle(new Vec3d((Vec3i)this.placeTarget.dispenser), new Vec3d((Vec3i)this.placeTarget.shulker));
/* 182 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(angle[0] + 180.0F, angle[1], true));
/* 183 */         placeBlock(this.placeTarget.dispenser);
/* 184 */         if (ColorMain.INSTANCE.sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 185 */         mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placeTarget.dispenser, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 186 */         if (((Boolean)this.silent.getValue()).booleanValue()) mc.player.inventory.currentItem = this.oldslot; 
/* 187 */         this.stage++;
/*     */         break;
/*     */       case 1:
/* 190 */         if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiDispenser) {
/* 191 */           if (this.shulkerSlot > 8) { mc.playerController.windowClick(mc.player.openContainer.windowId, this.shulkerSlot, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player); }
/* 192 */           else { mc.playerController.windowClick(mc.player.openContainer.windowId, 1, this.shulkerSlot, ClickType.SWAP, (EntityPlayer)mc.player); }
/* 193 */            mc.player.closeScreen();
/* 194 */           this.stage++;
/*     */         } 
/*     */         break;
/*     */       case 2:
/* 198 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 199 */         mc.player.inventory.currentItem = this.redstoneSlot;
/* 200 */         BurrowUtil.placeBlock(this.placeTarget.redstone, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 201 */         if (((Boolean)this.silent.getValue()).booleanValue()) mc.player.inventory.currentItem = this.oldslot; 
/* 202 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/* 203 */         this.stage++;
/*     */         break;
/*     */       case 3:
/* 206 */         if (!((Boolean)this.hopperWait.getValue()).booleanValue()) {
/* 207 */           mc.player.inventory.currentItem = this.hopperSlot;
/* 208 */           BurrowUtil.placeBlock(this.placeTarget.hopper, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 209 */           if (ColorMain.INSTANCE.sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 210 */           mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placeTarget.hopper, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 211 */           mc.player.inventory.currentItem = ((Boolean)this.silent.getValue()).booleanValue() ? this.oldslot : this.shulkerSlot;
/* 212 */           this.stage = 0;
/* 213 */           disable(); break;
/*     */         } 
/* 215 */         if (this.waited >= this.delay || BlockUtil.getBlock(this.placeTarget.shulker) instanceof net.minecraft.block.BlockShulkerBox) {
/* 216 */           mc.player.inventory.currentItem = this.hopperSlot;
/* 217 */           BurrowUtil.placeBlock(this.placeTarget.hopper, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 218 */           if (ColorMain.INSTANCE.sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 219 */           mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placeTarget.hopper, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 220 */           mc.player.inventory.currentItem = ((Boolean)this.silent.getValue()).booleanValue() ? this.oldslot : this.shulkerSlot;
/* 221 */           this.stage = 0;
/* 222 */           if (((Boolean)this.debugMessages.getValue()).booleanValue()) MessageBus.sendClientPrefixMessage("AutoDispenser32k Place Target: " + this.placeTarget.hopper.x + " " + this.placeTarget.hopper.y + " " + this.placeTarget.hopper.z + " Distance: " + BigDecimal.valueOf(mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)this.placeTarget.hopper))).setScale(1, roundingMode), Notification.Type.SUCCESS); 
/* 223 */           disable(); break;
/* 224 */         }  this.waited++;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 231 */     if (!BlockUtil.canReplace(pos))
/* 232 */       return;  EnumFacing side = BurrowUtil.getFirstFacing(pos);
/* 233 */     if (side == null)
/* 234 */       return;  BlockPos neighbour = pos.offset(side);
/* 235 */     EnumFacing opposite = side.getOpposite();
/* 236 */     if (!BlockUtil.canBeClicked(neighbour))
/* 237 */       return;  Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 238 */     boolean sneak = false;
/* 239 */     if ((BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) || BlockUtil.shulkerList.contains(mc.world.getBlockState(neighbour).getBlock())) && !mc.player.isSneaking()) {
/* 240 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 241 */       mc.player.setSneaking(true);
/* 242 */       sneak = true;
/*     */     } 
/*     */     
/* 245 */     if (((Boolean)this.packet.getValue()).booleanValue()) { BlockUtil.rightClickBlock(neighbour, hitVec, EnumHand.MAIN_HAND, opposite); }
/*     */     else
/* 247 */     { mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, opposite, hitVec, EnumHand.MAIN_HAND);
/* 248 */       if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  }
/*     */     
/* 250 */     if (((Boolean)this.dispenserRotate.getValue()).booleanValue()) BlockUtil.faceVector(hitVec);
/*     */     
/* 252 */     if (sneak) {
/* 253 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/* 254 */       mc.player.setSneaking(false);
/*     */     } 
/*     */   }
/*     */   static class DispenserPos { BlockPos base;
/*     */     BlockPos dispenser;
/*     */     
/*     */     public DispenserPos(BlockPos base, BlockPos dispenser, BlockPos redstone, BlockPos shulker, BlockPos hopper) {
/* 261 */       this.base = base;
/* 262 */       this.dispenser = dispenser;
/* 263 */       this.redstone = redstone;
/* 264 */       this.shulker = shulker;
/* 265 */       this.hopper = hopper;
/*     */     }
/*     */     BlockPos redstone; BlockPos shulker; BlockPos hopper; }
/*     */   
/*     */   private boolean canPlace(BlockPos pos) {
/* 270 */     return (!intersectsWithEntity(pos) && BlockUtil.canReplace(pos));
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 274 */     for (Entity entity : mc.world.loadedEntityList) {
/* 275 */       if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb) && !(entity instanceof net.minecraft.entity.item.EntityExpBottle) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow) && (
/* 276 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 277 */         return true; 
/*     */     } 
/* 279 */     return false;
/*     */   }
/*     */   public boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 282 */     if (pos1 == null || pos2 == null)
/* 283 */       return false; 
/* 284 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   private boolean inRange(BlockPos pos) {
/* 288 */     double x = pos.x - mc.player.posX;
/* 289 */     double z = pos.z - mc.player.posZ;
/* 290 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/* 291 */     double add = Math.sqrt(y * y) / 2.0D;
/* 292 */     return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoDispenser32k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
