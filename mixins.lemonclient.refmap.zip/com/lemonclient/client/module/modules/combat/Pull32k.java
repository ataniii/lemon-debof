//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.DoubleSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import net.minecraft.enchantment.EnchantmentHelper;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Enchantments;
/*    */ import net.minecraft.inventory.ClickType;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*    */ 
/*    */ @Declaration(name = "Pull32k", category = Category.Combat)
/*    */ public class Pull32k extends Module {
/* 20 */   BooleanSetting force = registerBoolean("Force Switch", true);
/* 21 */   IntegerSetting slot = registerInteger("Slot", 1, 1, 9, () -> (Boolean)this.force.getValue());
/* 22 */   DoubleSetting range = registerDouble("Range", 7.5D, 0.0D, 64.0D);
/*    */   boolean foundsword = false;
/*    */   
/*    */   public void onUpdate() {
/* 26 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*    */       return; 
/* 28 */     if (((Double)this.range.getValue()).doubleValue() != 0.0D) {
/* 29 */       EntityPlayer enemy = PlayerUtil.getNearestPlayer(((Double)this.range.getValue()).doubleValue());
/* 30 */       if (enemy == null)
/*    */         return; 
/* 32 */     }  boolean foundair = false;
/* 33 */     int enchantedSwordIndex = -1; int i;
/* 34 */     for (i = 0; i < 9; i++) {
/* 35 */       ItemStack itemStack = (ItemStack)mc.player.inventory.mainInventory.get(i);
/* 36 */       if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, itemStack) >= 25) {
/* 37 */         enchantedSwordIndex = i;
/* 38 */         this.foundsword = true;
/*    */       } 
/* 40 */       if (!this.foundsword) {
/* 41 */         enchantedSwordIndex = -1;
/*    */       }
/*    */     } 
/* 44 */     if (enchantedSwordIndex != -1) {
/* 45 */       if (mc.player.inventory.currentItem != enchantedSwordIndex) {
/* 46 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(enchantedSwordIndex));
/* 47 */         mc.player.inventory.currentItem = enchantedSwordIndex;
/* 48 */         mc.playerController.updateController();
/*    */       } 
/* 50 */     } else if (mc.player.openContainer != null && mc.player.openContainer instanceof net.minecraft.inventory.ContainerHopper && mc.player.openContainer.inventorySlots != null && !mc.player.openContainer.inventorySlots.isEmpty()) {
/* 51 */       for (i = 0; i < 5; i++) {
/* 52 */         if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, ((Slot)mc.player.openContainer.inventorySlots.get(0)).inventory.getStackInSlot(i)) >= 20) {
/* 53 */           enchantedSwordIndex = i;
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/* 58 */       if (enchantedSwordIndex == -1) {
/*    */         return;
/*    */       }
/* 61 */       for (i = 0; i < 9; i++) {
/* 62 */         ItemStack itemStack = (ItemStack)mc.player.inventory.mainInventory.get(i);
/* 63 */         if (itemStack.getItem() instanceof net.minecraft.item.ItemAir || checkStuff(i)) {
/* 64 */           if (mc.player.inventory.currentItem != i) {
/* 65 */             mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(i));
/* 66 */             mc.player.inventory.currentItem = i;
/* 67 */             mc.playerController.updateController();
/*    */           } 
/* 69 */           foundair = true;
/*    */           break;
/*    */         } 
/*    */       } 
/* 73 */       if (!foundair && ((Boolean)this.force.getValue()).booleanValue()) {
/* 74 */         i = ((Integer)this.slot.getValue()).intValue() - 1;
/* 75 */         if (mc.player.inventory.currentItem != i) {
/* 76 */           mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(i));
/* 77 */           mc.player.inventory.currentItem = i;
/* 78 */           mc.playerController.updateController();
/*    */         } 
/* 80 */         foundair = true;
/*    */       } 
/* 82 */       if (foundair)
/* 83 */         mc.playerController.windowClick(mc.player.openContainer.windowId, enchantedSwordIndex, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean checkStuff(int slot) {
/* 88 */     return (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, (ItemStack)mc.player.inventory.mainInventory.get(slot)) == 5);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\Pull32k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
