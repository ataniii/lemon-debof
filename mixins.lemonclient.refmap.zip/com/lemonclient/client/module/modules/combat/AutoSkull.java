//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.misc.Timing;
/*    */ import com.lemonclient.api.util.player.BurrowUtil;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.client.event.InputUpdateEvent;
/*    */ 
/*    */ @Declaration(name = "AutoSkull", category = Category.Combat)
/*    */ public class AutoSkull extends Module {
/*    */   BooleanSetting moving;
/*    */   IntegerSetting delay;
/*    */   BooleanSetting packet;
/*    */   BooleanSetting rotate;
/*    */   BooleanSetting swing;
/*    */   BooleanSetting onlyHoles;
/*    */   
/*    */   public AutoSkull() {
/* 24 */     this.moving = registerBoolean("Moving", false);
/* 25 */     this.delay = registerInteger("Delay", 50, 0, 1000);
/* 26 */     this.packet = registerBoolean("Packet Place", true);
/* 27 */     this.rotate = registerBoolean("Rotate", false);
/* 28 */     this.swing = registerBoolean("Swing", true);
/* 29 */     this.onlyHoles = registerBoolean("Only Holes", false);
/* 30 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/* 31 */     this.disableAfter = registerBoolean("Disable After", true);
/* 32 */     this.disable = registerBoolean("Auto Disable", true);
/* 33 */     this.timer = new Timing();
/*    */ 
/*    */     
/* 36 */     this.inputUpdateEventListener = new Listener(event -> { if (!((Boolean)this.disable.getValue()).booleanValue()) return;  if (event.getMovementInput() instanceof net.minecraft.util.MovementInputFromOptions) { if ((event.getMovementInput()).jump) disable();  if ((event.getMovementInput()).forwardKeyDown || (event.getMovementInput()).backKeyDown || (event.getMovementInput()).leftKeyDown || (event.getMovementInput()).rightKeyDown) { double posY = mc.player.posY - this.y; if (posY * posY > 0.25D) disable();  }  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   BooleanSetting packetSwitch;
/*    */   BooleanSetting disableAfter;
/*    */   BooleanSetting disable;
/*    */   Timing timer;
/*    */   double y;
/*    */   @EventHandler
/*    */   private final Listener<InputUpdateEvent> inputUpdateEventListener;
/*    */   
/*    */   public void onEnable() {
/* 49 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/* 50 */       disable();
/*    */       return;
/*    */     } 
/* 53 */     this.y = mc.player.posY;
/*    */   }
/*    */   
/*    */   public void fast() {
/* 57 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*    */       return;
/*    */     }
/* 60 */     if (((Boolean)this.onlyHoles.getValue()).booleanValue() && !HoleUtil.isInHole((Entity)mc.player, true, true, false)) {
/*    */       return;
/*    */     }
/* 63 */     if (!((Boolean)this.moving.getValue()).booleanValue() && MotionUtil.isMoving((EntityLivingBase)mc.player))
/*    */       return; 
/* 65 */     int slot = InventoryUtil.findSkullSlot();
/* 66 */     if (slot == -1)
/* 67 */       return;  BlockPos pos = PlayerUtil.getPlayerPos();
/* 68 */     if (BurrowUtil.getFirstFacing(pos) == null || !BlockUtil.isAir(pos))
/*    */       return; 
/* 70 */     if (this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) {
/* 71 */       run(slot, () -> BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()));
/* 72 */       if (((Boolean)this.disableAfter.getValue()).booleanValue()) disable(); 
/* 73 */       this.timer.reset();
/*    */     } 
/*    */   }
/*    */   
/*    */   private void run(int slot, Runnable runnable) {
/* 78 */     int oldslot = mc.player.inventory.currentItem;
/* 79 */     if (slot < 0 || slot == oldslot) {
/* 80 */       runnable.run();
/*    */       return;
/*    */     } 
/* 83 */     if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 84 */     else { mc.player.inventory.currentItem = slot; }
/* 85 */      runnable.run();
/* 86 */     if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/* 87 */     else { mc.player.inventory.currentItem = oldslot; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
