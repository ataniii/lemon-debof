//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.network.play.server.SPacketBlockBreakAnim;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AntiCity", category = Category.Combat)
/*     */ public class AntiCity extends Module {
/*     */   ModeSetting time;
/*     */   IntegerSetting bpt;
/*     */   BooleanSetting self;
/*     */   BooleanSetting smart;
/*     */   BooleanSetting breakCrystal;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting check;
/*     */   BooleanSetting packetBreak;
/*     */   BooleanSetting antiWeakness;
/*     */   BooleanSetting silentSwitch;
/*     */   BlockPos breakPos;
/*     */   private int obsidian;
/*     */   private int placeID;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> sendListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   int placed;
/*     */   
/*  37 */   public AntiCity() { this.time = registerMode("Time Mode", Arrays.asList(new String[] { "Tick", "onUpdate", "Fast" }, ), "Tick");
/*  38 */     this.bpt = registerInteger("Blocks Per Tick", 4, 0, 20);
/*  39 */     this.self = registerBoolean("Self", false);
/*  40 */     this.smart = registerBoolean("Smart", false);
/*  41 */     this.breakCrystal = registerBoolean("Break Crystal", true);
/*  42 */     this.rotate = registerBoolean("Rotate", true);
/*  43 */     this.packet = registerBoolean("Packet", true);
/*  44 */     this.swing = registerBoolean("Swing", true);
/*  45 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/*  46 */     this.check = registerBoolean("Switch Check", true);
/*  47 */     this.packetBreak = registerBoolean("Packet Break", false);
/*  48 */     this.antiWeakness = registerBoolean("Anti Weakness", true);
/*  49 */     this.silentSwitch = registerBoolean("Silent Switch", true);
/*     */     
/*  51 */     this.obsidian = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     this.sendListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (!((Boolean)this.self.getValue()).booleanValue()) return;  if (event.getPacket() instanceof CPacketPlayerDigging && ((CPacketPlayerDigging)event.getPacket()).getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) { CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket(); BlockPos ab = packet.getPosition(); this.breakPos = packet.getPosition(); BlockPos player = EntityUtil.getPlayerPos((EntityPlayer)mc.player); if (ab.equals(player.add(1, 0, 0))) this.placeID = 1;  if (ab.equals(player.add(-1, 0, 0))) this.placeID = 2;  if (ab.equals(player.add(0, 0, 1))) this.placeID = 3;  if (ab.equals(player.add(0, 0, -1))) this.placeID = 4;  if (ab.equals(player.add(2, 0, 0))) this.placeID = 5;  if (ab.equals(player.add(-2, 0, 0))) this.placeID = 6;  if (ab.equals(player.add(0, 0, 2))) this.placeID = 7;  if (ab.equals(player.add(0, 0, -2))) this.placeID = 8;  if (ab.equals(player.add(1, 1, 0))) this.placeID = 9;  if (ab.equals(player.add(-1, 1, 0))) this.placeID = 10;  if (ab.equals(player.add(0, 1, 1))) this.placeID = 11;  if (ab.equals(player.add(0, 1, -1))) this.placeID = 12;  if (ab.equals(player.add(1, 0, 1))) this.placeID = 13;  if (ab.equals(player.add(1, 0, -1))) this.placeID = 14;  if (ab.equals(player.add(-1, 0, 1))) this.placeID = 15;  if (ab.equals(player.add(-1, 0, -1))) this.placeID = 16;  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (event.getPacket() instanceof SPacketBlockBreakAnim) { SPacketBlockBreakAnim packet = (SPacketBlockBreakAnim)event.getPacket(); BlockPos ab = packet.getPosition(); this.breakPos = packet.getPosition(); BlockPos player = EntityUtil.getPlayerPos((EntityPlayer)mc.player); if (ab.equals(player.add(1, 0, 0))) this.placeID = 1;  if (ab.equals(player.add(-1, 0, 0))) this.placeID = 2;  if (ab.equals(player.add(0, 0, 1))) this.placeID = 3;  if (ab.equals(player.add(0, 0, -1))) this.placeID = 4;  if (ab.equals(player.add(2, 0, 0))) this.placeID = 5;  if (ab.equals(player.add(-2, 0, 0))) this.placeID = 6;  if (ab.equals(player.add(0, 0, 2))) this.placeID = 7;  if (ab.equals(player.add(0, 0, -2))) this.placeID = 8;  if (ab.equals(player.add(1, 1, 0))) this.placeID = 9;  if (ab.equals(player.add(-1, 1, 0))) this.placeID = 10;  if (ab.equals(player.add(0, 1, 1))) this.placeID = 11;  if (ab.equals(player.add(0, 1, -1))) this.placeID = 12;  if (ab.equals(player.add(1, 0, 1))) this.placeID = 13;  if (ab.equals(player.add(1, 0, -1))) this.placeID = 14;  if (ab.equals(player.add(-1, 0, 1))) this.placeID = 15;  if (ab.equals(player.add(-1, 0, -1))) this.placeID = 16;  }  }new java.util.function.Predicate[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/*     */     if (slot > -1 && slot < 9 && (!((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*     */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) {
/*     */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */       } else {
/*     */         mc.player.inventory.currentItem = slot;
/*     */       } 
/*     */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean noHard(Block block) {
/*     */     return (block != Blocks.BEDROCK);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*     */     if (((String)this.time.getValue()).equals("onUpdate")) {
/*     */       antiCity();
/*     */     }
/*     */     this.placed = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IBlockState getBlock(BlockPos block) {
/* 368 */     if (block == null) return null; 
/* 369 */     return mc.world.getBlockState(block);
/*     */   }
/*     */   public void onTick() { if (((String)this.time.getValue()).equals("Tick")) antiCity();  }
/*     */   public void fast() { if (((String)this.time.getValue()).equals("Fast")) antiCity();  }
/*     */   public void antiCity() { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (LemonClient.speedUtil.getPlayerSpeed((EntityPlayer)mc.player) >= 15.0D) return;  this.obsidian = BurrowUtil.findHotbarBlock(BlockObsidian.class); if (this.obsidian == -1) return;  BlockPos pos = EntityUtil.getPlayerPos((EntityPlayer)mc.player); if (pos == null) return;  pos = new BlockPos(pos.x, pos.y + 0.2D, pos.z); if (this.breakPos != null) { if ((this.breakPos.equals(pos.add(1, 0, 0)) || this.breakPos.equals(pos.add(1, 1, 0))) && isAir(pos.add(1, 0, 0)) && isAir(pos.add(1, 1, 0))) if (this.breakPos.equals(pos.add(1, 0, 0))) { perform(pos.add(1, 1, 0)); } else { perform(pos.add(1, 0, 0)); }   if ((this.breakPos.equals(pos.add(-1, 0, 0)) || this.breakPos.equals(pos.add(-1, 1, 0))) && isAir(pos.add(-1, 0, 0)) && isAir(pos.add(-1, 1, 0))) if (this.breakPos.equals(pos.add(-1, 0, 0))) { perform(pos.add(-1, 1, 0)); } else { perform(pos.add(-1, 0, 0)); }   if ((this.breakPos.equals(pos.add(0, 0, 1)) || this.breakPos.equals(pos.add(0, 1, 1))) && isAir(pos.add(0, 0, 1)) && isAir(pos.add(0, 1, 1))) if (this.breakPos.equals(pos.add(0, 0, 1))) { perform(pos.add(0, 1, 1)); } else { perform(pos.add(0, 0, 1)); }   if ((this.breakPos.equals(pos.add(0, 0, -1)) || this.breakPos.equals(pos.add(0, 1, -1))) && isAir(pos.add(0, 0, -1)) && isAir(pos.add(0, 1, -1))) if (this.breakPos.equals(pos.add(0, 0, -1))) { perform(pos.add(0, 1, -1)); } else { perform(pos.add(0, 0, -1)); }   }  if (noHard(getBlock(pos.add(1, 0, 0)).getBlock())) { if (this.placeID == 1) { perform(pos.add(2, 0, 0)); perform(pos.add(1, 0, 1)); perform(pos.add(1, 0, -1)); perform(pos.add(1, 1, 0)); if (EntityCheck(pos.add(2, 0, 0))) { perform(pos.add(3, 0, 0)); perform(pos.add(3, 1, 0)); }  }  if (this.placeID == 5) { perform(pos.add(1, 0, 0)); perform(pos.add(2, 1, 0)); perform(pos.add(3, 0, 0)); }  if (this.placeID == 9) { perform(pos.add(1, 0, 0)); perform(pos.add(2, 1, 0)); }  if (this.placeID == 13 || this.placeID == 14) perform(pos.add(1, 0, 0));  }  if (noHard(getBlock(pos.add(-1, 0, 0)).getBlock())) { if (this.placeID == 2) { perform(pos.add(-2, 0, 0)); perform(pos.add(-1, 0, 1)); perform(pos.add(-1, 0, -1)); perform(pos.add(-1, 1, 0)); if (EntityCheck(pos.add(-2, 0, 0))) { perform(pos.add(-3, 0, 0)); perform(pos.add(-3, 1, 0)); }  }  if (this.placeID == 6) { perform(pos.add(-1, 0, 0)); perform(pos.add(-2, 1, 0)); perform(pos.add(-3, 0, 0)); }  if (this.placeID == 10) { perform(pos.add(-1, 0, 0)); perform(pos.add(-2, 1, 0)); }  if (this.placeID == 15 || this.placeID == 16) perform(pos.add(-1, 0, 0));  }  if (noHard(getBlock(pos.add(0, 0, 1)).getBlock())) { if (this.placeID == 3) { perform(pos.add(0, 0, 2)); perform(pos.add(1, 0, 1)); perform(pos.add(-1, 0, 1)); perform(pos.add(0, 1, 1)); if (EntityCheck(pos.add(0, 0, 2))) { perform(pos.add(0, 0, 3)); perform(pos.add(0, 1, 3)); }  }  if (this.placeID == 7) { perform(pos.add(0, 0, 1)); perform(pos.add(0, 1, 2)); perform(pos.add(0, 0, 3)); }  if (this.placeID == 11) { perform(pos.add(0, 0, 1)); perform(pos.add(0, 1, 2)); }  if (this.placeID == 13 || this.placeID == 15) perform(pos.add(0, 0, 1));  }  if (noHard(getBlock(pos.add(0, 0, -1)).getBlock())) { if (this.placeID == 4) { perform(pos.add(0, 0, -2)); perform(pos.add(1, 0, -1)); perform(pos.add(-1, 0, -1)); perform(pos.add(0, 1, -1)); if (EntityCheck(pos.add(0, 0, -2))) { perform(pos.add(0, 0, -3)); perform(pos.add(0, 1, -3)); }  }  if (this.placeID == 8) { perform(pos.add(0, 0, -1)); perform(pos.add(0, 1, -2)); perform(pos.add(0, 0, -3)); }  if (this.placeID == 12) { perform(pos.add(0, 0, -1)); perform(pos.add(0, 1, -2)); }  if (this.placeID == 14 || this.placeID == 16) perform(pos.add(0, 0, -1));  }  this.placeID = 0; } public static boolean EntityCheck(BlockPos pos) { for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) { if (entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb) continue;  if (entity != null)
/* 374 */         return true;  }  return false; } private void breakCrystal(Entity crystal) { if (crystal == null)
/* 375 */       return;  int oldSlot = mc.player.inventory.currentItem;
/* 376 */     if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
/* 377 */       int newSlot = -1;
/* 378 */       for (int i = 0; i < 9; i++) {
/* 379 */         ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 380 */         if (stack != ItemStack.EMPTY) {
/* 381 */           if (stack.getItem() instanceof net.minecraft.item.ItemSword) {
/* 382 */             newSlot = i; break;
/*     */           } 
/* 384 */           if (stack.getItem() instanceof net.minecraft.item.ItemTool) {
/* 385 */             newSlot = i;
/*     */           }
/*     */         } 
/*     */       } 
/* 389 */       if (newSlot != -1)
/* 390 */         switchTo(newSlot); 
/*     */     } 
/* 392 */     if (!((Boolean)this.packetBreak.getValue()).booleanValue()) { CrystalUtil.breakCrystal(crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 393 */     else { CrystalUtil.breakCrystalPacket(crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 394 */      if (((Boolean)this.silentSwitch.getValue()).booleanValue())
/* 395 */       switchTo(oldSlot);  }
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 398 */     if (pos1 == null || pos2 == null)
/* 399 */       return false; 
/* 400 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */ 
/*     */   
/*     */   private void perform(BlockPos pos) {
/* 405 */     if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 406 */       return;  BlockPos instantPos = null;
/* 407 */     if (ModuleManager.isModuleEnabled(PacketMine.class)) {
/* 408 */       instantPos = PacketMine.INSTANCE.packetPos;
/*     */     }
/* 410 */     if (PlayerCheck(pos) || !CanPlace(pos) || (((Boolean)this.smart.getValue()).booleanValue() && isPos2(pos, instantPos))) {
/*     */       return;
/*     */     }
/* 413 */     if (((Boolean)this.breakCrystal.getValue()).booleanValue()) {
/* 414 */       for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 415 */         if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/* 416 */           breakCrystal(entity);
/*     */         }
/*     */       } 
/*     */     }
/* 420 */     int old = mc.player.inventory.currentItem;
/* 421 */     switchTo(this.obsidian);
/* 422 */     BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 423 */     switchTo(old);
/* 424 */     this.placed++;
/*     */   }
/*     */   public boolean CanPlace(BlockPos block) {
/* 427 */     for (EnumFacing face : EnumFacing.VALUES) {
/* 428 */       if (isReplaceable(block) && !BlockUtil.airBlocks.contains(getBlock(block.offset(face))) && mc.player.getDistanceSq(block) <= MathUtil.square(5.0D)) {
/* 429 */         return true;
/*     */       }
/*     */     } 
/* 432 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isReplaceable(BlockPos pos) {
/* 436 */     return BlockUtil.getState(pos).getMaterial().isReplaceable();
/*     */   }
/*     */   
/*     */   private boolean isAir(BlockPos block) {
/* 440 */     return (mc.world.getBlockState(block).getBlock() == Blocks.AIR);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean PlayerCheck(BlockPos pos) {
/* 445 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 446 */       if (entity instanceof EntityPlayer) {
/* 447 */         return true;
/*     */       }
/*     */     } 
/* 450 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AntiCity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
