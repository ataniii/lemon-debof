//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.combat.CrystalUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityEnderCrystal;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.client.event.InputUpdateEvent;
/*     */ 
/*     */ @Declaration(name = "Surround", category = Category.Combat)
/*     */ public class Surround extends Module {
/*     */   ModeSetting time;
/*     */   BooleanSetting once;
/*     */   BooleanSetting echest;
/*     */   BooleanSetting floor;
/*     */   IntegerSetting delay;
/*     */   IntegerSetting range;
/*     */   IntegerSetting bpt;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting check;
/*     */   BooleanSetting forceBase;
/*     */   BooleanSetting hit;
/*     */   
/*  40 */   public Surround() { this.time = registerMode("Time Mode", Arrays.asList(new String[] { "Tick", "onUpdate", "Fast" }, ), "Tick");
/*  41 */     this.once = registerBoolean("Once", true);
/*  42 */     this.echest = registerBoolean("Ender Chest", true);
/*  43 */     this.floor = registerBoolean("Floor", true);
/*  44 */     this.delay = registerInteger("Delay", 0, 0, 20);
/*  45 */     this.range = registerInteger("Range", 5, 0, 10);
/*  46 */     this.bpt = registerInteger("BlocksPerTick", 4, 0, 20);
/*  47 */     this.rotate = registerBoolean("Rotate", false);
/*  48 */     this.packet = registerBoolean("Packet Place", false);
/*  49 */     this.swing = registerBoolean("Swing", false);
/*  50 */     this.packetSwitch = registerBoolean("Packet Switch", true);
/*  51 */     this.check = registerBoolean("Switch Check", true);
/*  52 */     this.forceBase = registerBoolean("Force Base", false);
/*  53 */     this.hit = registerBoolean("Hit", true);
/*  54 */     this.packetBreak = registerBoolean("Packet Break", false);
/*  55 */     this.antiWeakness = registerBoolean("Anti Weakness", true);
/*  56 */     this.packetswitch = registerBoolean("Silent Switch", true);
/*  57 */     this.crystals = new ArrayList<>();
/*  58 */     this.surround = new ArrayList<>();
/*  59 */     this.hasEntity = new ArrayList<>();
/*  60 */     this.posList = new ArrayList<>();
/*  61 */     this.floorPos = new ArrayList<>();
/*     */ 
/*     */     
/*  64 */     this.sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.neighbour = new BlockPos[] { new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1), new BlockPos(0, 1, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.inputUpdateEventListener = new Listener(event -> { if (event.getMovementInput() instanceof net.minecraft.util.MovementInputFromOptions) { if ((event.getMovementInput()).jump) disable();  if ((event.getMovementInput()).forwardKeyDown || (event.getMovementInput()).backKeyDown || (event.getMovementInput()).leftKeyDown || (event.getMovementInput()).rightKeyDown) { double posY = mc.player.posY - this.y; if (posY * posY > 0.25D) disable();  }  }  }new java.util.function.Predicate[0]); }
/*     */   BooleanSetting packetBreak;
/*     */   BooleanSetting antiWeakness;
/*     */   BooleanSetting packetswitch;
/*     */   List<EntityEnderCrystal> crystals; List<BlockPos> surround; List<BlockPos> hasEntity; List<BlockPos> posList; List<BlockPos> floorPos; int placed; int waited; int slot; double y; BlockPos[] sides; BlockPos[] neighbour; @EventHandler
/*     */   private final Listener<InputUpdateEvent> inputUpdateEventListener; public void onEnable() { if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     this.y = mc.player.posY; } public void onUpdate() { if (((String)this.time.getValue()).equals("onUpdate"))
/*     */       doSurround();  } public void onTick() { if (((String)this.time.getValue()).equals("Tick"))
/*     */       doSurround();  } public void fast() { if (((String)this.time.getValue()).equals("Fast"))
/* 114 */       doSurround();  } private void doSurround() { if (mc.world == null || mc.player == null || mc.player.isDead) {
/* 115 */       disable();
/*     */       return;
/*     */     } 
/* 118 */     this.slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 119 */     if (this.slot == -1 && ((Boolean)this.echest.getValue()).booleanValue()) this.slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class); 
/* 120 */     if (this.slot == -1)
/* 121 */       return;  if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */       return; 
/* 123 */     this.waited = this.placed = 0;
/* 124 */     calc();
/* 125 */     if (((Boolean)this.hit.getValue()).booleanValue() && !this.crystals.isEmpty()) {
/* 126 */       EntityEnderCrystal entityEnderCrystal; Entity crystal = null;
/* 127 */       Iterator<EntityEnderCrystal> iterator = this.crystals.iterator(); if (iterator.hasNext()) { EntityEnderCrystal enderCrystal = iterator.next();
/* 128 */         entityEnderCrystal = enderCrystal; }
/*     */ 
/*     */       
/* 131 */       breakCrystal((Entity)entityEnderCrystal);
/*     */     } 
/* 133 */     if (((Boolean)this.floor.getValue()).booleanValue()) for (BlockPos pos : this.floorPos) this.surround.add(pos.down());  
/* 134 */     if (this.surround.isEmpty())
/* 135 */       return;  for (BlockPos pos : this.surround) {
/* 136 */       if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 137 */         break;  if (!mc.world.isAirBlock(pos) && mc.world.getBlockState(pos).getBlock() != Blocks.FIRE && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockLiquid))
/*     */         continue; 
/* 139 */       EnumFacing face = BurrowUtil.getFirstFacing(pos);
/* 140 */       if (face == null || ((Boolean)this.forceBase.getValue()).booleanValue()) {
/* 141 */         boolean canPlace = false;
/* 142 */         for (BlockPos side : this.neighbour) {
/* 143 */           BlockPos blockPos = pos.add((Vec3i)side);
/* 144 */           if (!intersectsWithEntity(blockPos) && 
/* 145 */             BlockUtil.hasNeighbour(blockPos)) {
/* 146 */             placeBlock(blockPos, BurrowUtil.getFirstFacing(blockPos));
/* 147 */             canPlace = true;
/*     */             break;
/*     */           } 
/*     */         } 
/* 151 */         if (!canPlace)
/* 152 */           continue;  face = BurrowUtil.getFirstFacing(pos);
/*     */       } 
/* 154 */       placeBlock(pos, face);
/*     */     } 
/* 156 */     if (((Boolean)this.once.getValue()).booleanValue())
/* 157 */       disable();  }
/*     */ 
/*     */   
/*     */   private void breakCrystal(Entity crystal) {
/* 161 */     if (crystal == null)
/* 162 */       return;  int oldSlot = mc.player.inventory.currentItem;
/* 163 */     if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
/* 164 */       int newSlot = -1;
/* 165 */       for (int i = 0; i < 9; i++) {
/* 166 */         ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 167 */         if (stack != ItemStack.EMPTY) {
/* 168 */           if (stack.getItem() instanceof net.minecraft.item.ItemSword) {
/* 169 */             newSlot = i; break;
/*     */           } 
/* 171 */           if (stack.getItem() instanceof net.minecraft.item.ItemTool) {
/* 172 */             newSlot = i;
/*     */           }
/*     */         } 
/*     */       } 
/* 176 */       if (newSlot != -1)
/* 177 */         switchTo(newSlot); 
/*     */     } 
/* 179 */     if (!((Boolean)this.packetBreak.getValue()).booleanValue()) { CrystalUtil.breakCrystal(crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 180 */     else { CrystalUtil.breakCrystalPacket(crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 181 */      if (((Boolean)this.packetswitch.getValue()).booleanValue()) {
/* 182 */       switchTo(oldSlot);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 188 */     if (slot > -1 && slot < 9 && (
/* 189 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 190 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/* 192 */       { mc.player.inventory.currentItem = slot; }
/*     */       
/* 194 */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void placeBlock(BlockPos pos, EnumFacing side) {
/* 200 */     if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 201 */       return;  if (intersectsWithEntity(pos))
/* 202 */       return;  if (side == null)
/* 203 */       return;  BlockPos neighbour = pos.offset(side);
/* 204 */     EnumFacing opposite = side.getOpposite();
/*     */     
/* 206 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*     */     
/* 208 */     if ((BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) || BlockUtil.shulkerList.contains(mc.world.getBlockState(neighbour).getBlock())) && !mc.player.isSneaking()) {
/* 209 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 210 */       mc.player.setSneaking(true);
/*     */     } 
/*     */     
/* 213 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 214 */       BurrowUtil.faceVector(hitVec, true);
/*     */     }
/*     */     
/* 217 */     int oldslot = mc.player.inventory.currentItem;
/* 218 */     switchTo(this.slot);
/* 219 */     BurrowUtil.rightClickBlock(neighbour, hitVec, EnumHand.MAIN_HAND, opposite, ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 220 */     switchTo(oldslot);
/* 221 */     this.placed++;
/*     */   }
/*     */   
/*     */   private void calc() {
/* 225 */     this.crystals = new ArrayList<>();
/* 226 */     this.surround = new ArrayList<>();
/* 227 */     this.hasEntity = new ArrayList<>();
/* 228 */     this.posList = new ArrayList<>();
/* 229 */     this.floorPos = new ArrayList<>();
/* 230 */     BlockPos playerPos = PlayerUtil.getPlayerPos();
/* 231 */     playerPos = new BlockPos(playerPos.x, playerPos.y + 0.55D, playerPos.z);
/* 232 */     addPos(playerPos);
/* 233 */     if (!this.hasEntity.isEmpty()) entityCalc(); 
/*     */   }
/*     */   
/*     */   private void entityCalc() {
/* 237 */     this.posList = new ArrayList<>();
/* 238 */     this.posList.addAll(this.hasEntity);
/* 239 */     this.hasEntity = new ArrayList<>();
/* 240 */     for (BlockPos pos : this.posList) addPos(pos); 
/* 241 */     this.hasEntity.removeIf(blockPos -> (blockPos == null || this.floorPos.contains(blockPos) || mc.player.getDistanceSq(blockPos) > (((Integer)this.range.getValue()).intValue() * ((Integer)this.range.getValue()).intValue())));
/* 242 */     this.surround.removeIf(blockPos -> (blockPos == null || mc.player.getDistanceSq(blockPos) > (((Integer)this.range.getValue()).intValue() * ((Integer)this.range.getValue()).intValue())));
/* 243 */     if (!this.hasEntity.isEmpty()) entityCalc(); 
/*     */   }
/*     */   
/*     */   private void addPos(BlockPos pos) {
/* 247 */     if (this.floorPos.contains(pos))
/* 248 */       return;  for (BlockPos side : this.sides) {
/* 249 */       BlockPos blockPos = pos.add((Vec3i)side);
/* 250 */       if (intersectsWithEntity(blockPos)) { this.hasEntity.add(blockPos); }
/* 251 */       else { this.surround.add(blockPos); }
/*     */     
/* 253 */     }  this.floorPos.add(pos);
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 257 */     for (Entity entity : mc.world.loadedEntityList) {
/* 258 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 259 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) {
/* 260 */         if (entity instanceof EntityEnderCrystal) { this.crystals.add((EntityEnderCrystal)entity); continue; }
/* 261 */          if (entity instanceof net.minecraft.entity.player.EntityPlayer) return true; 
/*     */       } 
/*     */     } 
/* 264 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\Surround.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
