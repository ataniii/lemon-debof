//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureAttribute;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.item.ItemTool;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ 
/*     */ @Declaration(name = "32kAura", category = Category.Combat)
/*     */ public class kAura extends Module {
/*  28 */   ModeSetting time = registerMode("Time Mode", Arrays.asList(new String[] { "Tick", "onUpdate", "Both", "Fast" }, ), "Tick"); private int hasWaited;
/*  29 */   ModeSetting mode = registerMode("Mode", Arrays.asList(new String[] { "CPS", "CPT" }, ), "CPS");
/*  30 */   IntegerSetting range = registerInteger("Range", 6, 0, 20);
/*  31 */   BooleanSetting only32k = registerBoolean("32k Only", true);
/*  32 */   BooleanSetting xin = registerBoolean("Xin", true);
/*  33 */   BooleanSetting packet = registerBoolean("Packet Attack", true);
/*  34 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  35 */   BooleanSetting autoswitch = registerBoolean("Auto Switch", true);
/*  36 */   BooleanSetting packetswitch = registerBoolean("Packet Switch", true);
/*  37 */   BooleanSetting playersOnly = registerBoolean("Players only", true);
/*  38 */   IntegerSetting hit = registerInteger("Hit", 20, 0, 2147483647);
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  42 */     if (((String)this.time.getValue()).equals("onUpdate") || ((String)this.time.getValue()).equals("Both")) {
/*  43 */       attack();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onTick() {
/*  48 */     if (((String)this.time.getValue()).equals("Tick") || ((String)this.time.getValue()).equals("Both")) {
/*  49 */       attack();
/*     */     }
/*     */   }
/*     */   
/*     */   public void fast() {
/*  54 */     if (((String)this.time.getValue()).equals("Fast"))
/*  55 */       attack(); 
/*     */   }
/*     */   
/*     */   private void attack() {
/*  59 */     if (!((Boolean)this.xin.getValue()).booleanValue()) {
/*     */       int reqDelay;
/*  61 */       if (((String)this.mode.getValue()).equals("CPS")) {
/*  62 */         reqDelay = (int)Math.round(20.0D / ((Integer)this.hit.getValue()).intValue());
/*     */       } else {
/*  64 */         reqDelay = (int)Math.round(1.0D / ((Integer)this.hit.getValue()).intValue());
/*     */       } 
/*     */       
/*  67 */       if (this.hasWaited < reqDelay) {
/*  68 */         this.hasWaited++;
/*     */         return;
/*     */       } 
/*     */     } 
/*  72 */     this.hasWaited = 0;
/*  73 */     for (Entity entity : mc.world.getLoadedEntityList()) {
/*  74 */       if (!(entity instanceof EntityLivingBase) || entity == mc.player) {
/*     */         continue;
/*     */       }
/*  77 */       if (mc.player.getDistance(entity) > ((Integer)this.range.getValue()).intValue() || ((EntityLivingBase)entity)
/*  78 */         .getHealth() <= 0.0F || (!(entity instanceof EntityPlayer) && ((Boolean)this.playersOnly
/*  79 */         .getValue()).booleanValue()))
/*     */         continue; 
/*  81 */       if (((Boolean)this.autoswitch.getValue()).booleanValue()) {
/*  82 */         int oldSlot = mc.player.inventory.currentItem;
/*  83 */         equipBestWeapon();
/*  84 */         if (!isSuperWeapon(mc.player.getHeldItemMainhand()) && ((Boolean)this.only32k.getValue()).booleanValue()) {
/*  85 */           switchtoslot(oldSlot);
/*     */         }
/*     */       } 
/*  88 */       if (((Boolean)this.only32k.getValue()).booleanValue() && !isSuperWeapon(mc.player.getHeldItemMainhand())) {
/*     */         continue;
/*     */       }
/*  91 */       if (!SocialManager.isFriend(entity.getName())) {
/*  92 */         boolean attack = true;
/*  93 */         if (((Boolean)this.xin.getValue()).booleanValue() && 
/*  94 */           mc.player.getCooledAttackStrength(0.0F) < 1.0F) {
/*  95 */           attack = false;
/*     */         }
/*     */         
/*  98 */         if (attack) {
/*  99 */           if (((Boolean)this.packet.getValue()).booleanValue()) {
/* 100 */             mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
/*     */           } else {
/* 102 */             mc.playerController.attackEntity((EntityPlayer)mc.player, entity);
/*     */           } 
/* 104 */           if (((Boolean)this.swing.getValue()).booleanValue()) {
/* 105 */             mc.player.swingArm(EnumHand.MAIN_HAND);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSuperWeapon(ItemStack item) {
/* 114 */     if (item == null)
/* 115 */       return false; 
/* 116 */     if (item.getTagCompound() == null)
/* 117 */       return false; 
/* 118 */     if (item.getEnchantmentTagList().getTagType() == 0)
/* 119 */       return false; 
/* 120 */     NBTTagList enchants = (NBTTagList)item.getTagCompound().getTag("ench");
/* 121 */     int i = 0;
/* 122 */     while (i < enchants.tagCount()) {
/* 123 */       NBTTagCompound enchant = enchants.getCompoundTagAt(i);
/* 124 */       if (enchant.getInteger("id") == 16) {
/* 125 */         int lvl = enchant.getInteger("lvl");
/* 126 */         if (lvl >= 16)
/* 127 */           return true; 
/*     */         break;
/*     */       } 
/* 130 */       i++;
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   private void switchtoslot(int slot) {
/* 136 */     if (((Boolean)this.packetswitch.getValue()).booleanValue()) {
/* 137 */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */     } else {
/* 139 */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/* 140 */       mc.player.inventory.currentItem = slot;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void equipBestWeapon() {
/* 145 */     int bestSlot = -1;
/* 146 */     double maxDamage = 0.0D;
/* 147 */     for (int i = 0; i < 9; i++) {
/* 148 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 149 */       if (!stack.isEmpty)
/* 150 */         if (stack.getItem() instanceof ItemTool) {
/* 151 */           double damage = (((ItemTool)stack.getItem()).attackDamage + EnchantmentHelper.getModifierForCreature(stack, EnumCreatureAttribute.UNDEFINED));
/* 152 */           if (damage > maxDamage) {
/* 153 */             maxDamage = damage;
/* 154 */             bestSlot = i;
/*     */           } 
/* 156 */         } else if (stack.getItem() instanceof ItemSword) {
/* 157 */           double damage = (((ItemSword)stack.getItem()).getAttackDamage() + EnchantmentHelper.getModifierForCreature(stack, EnumCreatureAttribute.UNDEFINED));
/* 158 */           if (damage > maxDamage) {
/* 159 */             maxDamage = damage;
/* 160 */             bestSlot = i;
/*     */           } 
/*     */         }  
/*     */     } 
/* 164 */     if (bestSlot != -1)
/* 165 */       switchtoslot(bestSlot); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\kAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
