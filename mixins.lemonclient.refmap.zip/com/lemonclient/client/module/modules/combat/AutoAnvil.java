//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoAnvil", category = Category.Combat)
/*     */ public class AutoAnvil extends Module {
/*  34 */   ModeSetting anvilMode = registerMode("Mode", Arrays.asList(new String[] { "Pick", "Feet", "None" }, ), "Pick");
/*  35 */   ModeSetting target = registerMode("Target", Arrays.asList(new String[] { "Nearest", "Looking" }, ), "Nearest");
/*  36 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  37 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", false);
/*  38 */   BooleanSetting packetPlace = registerBoolean("Packet Place", false);
/*  39 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  40 */   DoubleSetting enemyRange = registerDouble("Range", 5.9D, 0.0D, 6.0D);
/*  41 */   DoubleSetting decrease = registerDouble("Decrease", 2.0D, 0.0D, 6.0D);
/*  42 */   IntegerSetting tickDelay = registerInteger("Tick Delay", 5, 0, 10);
/*  43 */   IntegerSetting blocksPerTick = registerInteger("Blocks Per Tick", 4, 0, 8);
/*  44 */   IntegerSetting hDistance = registerInteger("H Distance", 7, 1, 10);
/*  45 */   IntegerSetting minH = registerInteger("Min H", 3, 1, 10);
/*  46 */   IntegerSetting maxH = registerInteger("Max H", 3, 1, 10);
/*     */   private boolean noMaterials = false;
/*     */   private boolean enoughSpace = true;
/*     */   private boolean blockUp = false;
/*  50 */   private int[] slot_mat = new int[] { -1, -1, -1 };
/*     */   private double[] enemyCoords;
/*  52 */   int[][] model = new int[][] { { 1, 1, 1 }, { -1, 1, -1 }, { -1, 1, 1 }, { 1, 1, -1 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int blocksPlaced = 0;
/*  61 */   private int delayTimeTicks = 0;
/*  62 */   private int offsetSteps = 0;
/*     */   private BlockPos base;
/*     */   private EntityPlayer aimTarget;
/*     */   
/*     */   public void onEnable() {
/*  67 */     this.blocksPlaced = 0;
/*  68 */     this.blockUp = false;
/*  69 */     this.slot_mat = new int[] { -1, -1, -1 };
/*  70 */     to_place = new ArrayList<>();
/*     */     
/*  72 */     if (mc.player == null) disable(); 
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  76 */     if (mc.player == null) {
/*     */       return;
/*     */     }
/*     */     
/*  80 */     if (this.noMaterials) { setDisabledMessage("No Materials Detected... AutoAnvil turned OFF!"); }
/*  81 */     else if (!this.enoughSpace) { setDisabledMessage("Not enough space... AutoAnvil turned OFF!"); }
/*  82 */     else if (this.blockUp) { setDisabledMessage("Enemy head blocked.. AutoAnvil turned OFF!"); }
/*     */     
/*  84 */     this.noMaterials = false;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  88 */     if (mc.player == null) {
/*  89 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  93 */     if (((String)this.target.getValue()).equals("Nearest")) { this.aimTarget = PlayerUtil.getNearestPlayer(((Double)this.enemyRange.getValue()).doubleValue()); }
/*  94 */     else if (((String)this.target.getValue()).equals("Looking")) { this.aimTarget = PlayerUtil.findLookingPlayer(((Double)this.enemyRange.getValue()).doubleValue()); }
/*     */     
/*  96 */     if (this.aimTarget == null || mc.player.isDead) {
/*  97 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     if (getMaterialsSlot())
/* 102 */     { this.enemyCoords = new double[] { this.aimTarget.posX, this.aimTarget.posY, this.aimTarget.posZ };
/* 103 */       this.enoughSpace = createStructure(); }
/* 104 */     else { this.noMaterials = true; }
/*     */     
/* 106 */     if (this.noMaterials || !this.enoughSpace || this.blockUp) {
/* 107 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 111 */     if (this.delayTimeTicks < ((Integer)this.tickDelay.getValue()).intValue()) {
/* 112 */       this.delayTimeTicks++;
/*     */       return;
/*     */     } 
/* 115 */     this.delayTimeTicks = 0;
/* 116 */     if (!BlockUtil.isAir(new BlockPos(this.enemyCoords[0], this.enemyCoords[1] + 2.0D, this.enemyCoords[2])) && !(BlockUtil.getBlock(this.enemyCoords[0], this.enemyCoords[1] + 2.0D, this.enemyCoords[2]) instanceof net.minecraft.block.BlockAnvil)) {
/* 117 */       this.blockUp = true;
/*     */     }
/*     */     
/* 120 */     this.blocksPlaced = 0;
/*     */     
/* 122 */     while (this.blocksPlaced <= ((Integer)this.blocksPerTick.getValue()).intValue()) {
/*     */ 
/*     */       
/* 125 */       int maxSteps = to_place.size();
/*     */       
/* 127 */       if (this.offsetSteps >= maxSteps) {
/* 128 */         this.offsetSteps = 0;
/*     */         
/*     */         break;
/*     */       } 
/* 132 */       BlockPos offsetPos = new BlockPos(to_place.get(this.offsetSteps));
/* 133 */       BlockPos targetPos = (new BlockPos(this.enemyCoords[0], this.enemyCoords[1], this.enemyCoords[2])).add(offsetPos.getX(), offsetPos.getY(), offsetPos.getZ());
/*     */       
/* 135 */       boolean tryPlacing = true;
/*     */       
/* 137 */       if (this.offsetSteps > 0 && this.offsetSteps < to_place.size() - 1) {
/* 138 */         for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(targetPos))) {
/* 139 */           if (entity instanceof EntityPlayer) {
/* 140 */             tryPlacing = false;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 145 */       if (tryPlacing && placeBlock(targetPos, this.offsetSteps)) this.blocksPlaced++;
/*     */       
/* 147 */       this.offsetSteps++;
/*     */     } 
/*     */     
/* 150 */     BlockPos instantPos = null;
/* 151 */     if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos;
/*     */     
/* 153 */     if (((String)this.anvilMode.getValue()).equalsIgnoreCase("Pick") && (instantPos == null || !instantPos.equals(new BlockPos(this.enemyCoords[0], this.enemyCoords[1], this.enemyCoords[2])))) {
/* 154 */       mc.playerController.onPlayerDamageBlock(new BlockPos(this.enemyCoords[0], this.enemyCoords[1], this.enemyCoords[2]), EnumFacing.UP);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean placeBlock(BlockPos pos, int step) {
/* 159 */     if (intersectsWithEntity(pos)) return false; 
/* 160 */     if (!BlockUtil.canReplace(pos)) return false;
/*     */ 
/*     */     
/* 163 */     int utilSlot = (step == 0 && ((String)this.anvilMode.getValue()).equalsIgnoreCase("feet")) ? 2 : ((step >= to_place.size() - 1) ? 1 : 0);
/* 164 */     if (utilSlot == 0 && BlockUtil.canBeClicked(this.base)) {
/* 165 */       return false;
/*     */     }
/* 167 */     int slot = this.slot_mat[utilSlot];
/* 168 */     int oldslot = mc.player.inventory.currentItem;
/* 169 */     if (mc.player.inventory.getStackInSlot(slot) != ItemStack.EMPTY)
/* 170 */     { if (oldslot != slot)
/* 171 */       { if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 172 */         else { mc.player.inventory.currentItem = slot; }  }
/* 173 */       else { oldslot = -1; }  }
/* 174 */     else { return false; }
/*     */     
/* 176 */     BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packetPlace.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */     
/* 178 */     if (oldslot != -1) {
/* 179 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/* 180 */       else { mc.player.inventory.currentItem = oldslot; }
/*     */     
/*     */     }
/* 183 */     return true;
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 187 */     for (Entity entity : mc.world.loadedEntityList) {
/* 188 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 189 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true; 
/*     */     } 
/* 191 */     return false;
/*     */   }
/*     */   
/* 194 */   private static ArrayList<Vec3d> to_place = new ArrayList<>();
/*     */   
/*     */   private boolean getMaterialsSlot() {
/* 197 */     boolean feet = ((String)this.anvilMode.getValue()).equalsIgnoreCase("Feet");
/*     */     
/* 199 */     for (int i = 0; i < 9; i++) {
/* 200 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */       
/* 202 */       if (stack != ItemStack.EMPTY)
/*     */       {
/*     */         
/* 205 */         if (stack.getItem() instanceof ItemBlock) {
/*     */           
/* 207 */           Block block = ((ItemBlock)stack.getItem()).getBlock();
/*     */           
/* 209 */           if (block instanceof net.minecraft.block.BlockObsidian) {
/* 210 */             this.slot_mat[0] = i;
/*     */           }
/* 212 */           else if (block instanceof net.minecraft.block.BlockAnvil) {
/* 213 */             this.slot_mat[1] = i;
/*     */           }
/* 215 */           else if (feet && (block instanceof net.minecraft.block.BlockPressurePlate || block instanceof net.minecraft.block.BlockButton)) {
/* 216 */             this.slot_mat[2] = i;
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 220 */     int count = 0;
/* 221 */     for (int val : this.slot_mat) {
/* 222 */       if (val != -1) {
/* 223 */         count++;
/*     */       }
/*     */     } 
/* 226 */     return (count - (feet ? 1 : 0) == 2);
/*     */   }
/*     */   
/*     */   private boolean createStructure() {
/* 230 */     to_place = new ArrayList<>();
/* 231 */     if (((String)this.anvilMode.getValue()).equalsIgnoreCase("feet")) {
/* 232 */       to_place.add(new Vec3d(0.0D, 0.0D, 0.0D));
/*     */     }
/*     */     
/* 235 */     int hDistanceMod = ((Integer)this.hDistance.getValue()).intValue();
/* 236 */     double distEnemy = mc.player.getDistance((Entity)this.aimTarget);
/* 237 */     while (distEnemy > ((Double)this.decrease.getValue()).doubleValue()) {
/* 238 */       hDistanceMod--;
/* 239 */       distEnemy -= ((Double)this.decrease.getValue()).doubleValue();
/*     */     } 
/* 241 */     hDistanceMod += (int)(mc.player.posY - this.aimTarget.posY);
/*     */     
/* 243 */     double min_found = Double.MAX_VALUE;
/* 244 */     int cor = -1;
/* 245 */     int i = 0;
/* 246 */     BlockPos[] posList = { new BlockPos(this.enemyCoords[0] + 1.0D, this.enemyCoords[1], this.enemyCoords[2] + 1.0D), new BlockPos(this.enemyCoords[0] - 1.0D, this.enemyCoords[1], this.enemyCoords[2] - 1.0D), new BlockPos(this.enemyCoords[0] - 1.0D, this.enemyCoords[1], this.enemyCoords[2] + 1.0D), new BlockPos(this.enemyCoords[0] + 1.0D, this.enemyCoords[1], this.enemyCoords[2] - 1.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     for (BlockPos pos : posList) {
/* 254 */       boolean breakOut = false;
/* 255 */       for (int h = 0; h <= ((Integer)this.minH.getValue()).intValue(); h++) {
/* 256 */         if (BlockUtil.checkEntity(pos.up(h))) {
/* 257 */           breakOut = true;
/* 258 */           i++;
/*     */           break;
/*     */         } 
/*     */       } 
/* 262 */       if (!breakOut) {
/* 263 */         double distance_now = mc.player.getDistanceSq(pos);
/* 264 */         if (distance_now < min_found) {
/* 265 */           min_found = distance_now;
/* 266 */           cor = i;
/*     */         } 
/* 268 */         i++;
/*     */       } 
/* 270 */     }  if (cor == -1) return false; 
/* 271 */     List<Vec3d> baseList = new ArrayList<>();
/* 272 */     baseList.add(new Vec3d(this.model[cor][0], (this.model[cor][1] - 1), this.model[cor][2]));
/* 273 */     baseList.add(new Vec3d(this.model[cor][0], this.model[cor][1], this.model[cor][2]));
/* 274 */     int incr = 1;
/*     */     
/* 276 */     while (incr != ((Integer)this.maxH.getValue()).intValue() && 
/* 277 */       BlockUtil.getBlock(this.enemyCoords[0], this.enemyCoords[1] + incr, this.enemyCoords[2]) instanceof net.minecraft.block.BlockAir && incr < hDistanceMod) {
/* 278 */       baseList.add(new Vec3d(this.model[cor][0], (this.model[cor][1] + incr), this.model[cor][2]));
/* 279 */       incr++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 284 */     boolean possible = (incr >= ((Integer)this.minH.getValue()).intValue() && incr <= ((Integer)this.maxH.getValue()).intValue());
/* 285 */     BlockPos targetPos = new BlockPos(this.enemyCoords[0], this.enemyCoords[1], this.enemyCoords[2]);
/* 286 */     double x = mc.player.getDistanceSq((new BlockPos((Vec3i)targetPos)).add(this.model[cor][0], 0, 0));
/* 287 */     double z = mc.player.getDistanceSq((new BlockPos((Vec3i)targetPos)).add(0, 0, this.model[cor][2]));
/* 288 */     Vec3d base = new Vec3d(this.model[cor][0], (this.model[cor][1] + incr - 1), 0.0D);
/* 289 */     if (x > z) base = new Vec3d(0.0D, (this.model[cor][1] + incr - 1), this.model[cor][2]); 
/* 290 */     this.base = targetPos.add(base.x, base.y, base.z);
/* 291 */     to_place.add(base);
/*     */     
/* 293 */     double yRef = base.y;
/* 294 */     if (BurrowUtil.getFirstFacing(targetPos.add(0.0D, yRef, 0.0D)) == null)
/* 295 */       to_place.addAll(baseList); 
/* 296 */     to_place.add(new Vec3d(0.0D, yRef, 0.0D));
/*     */     
/* 298 */     return possible;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoAnvil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
