//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.PredictUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.combat.DamageUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.modules.qwq.AutoEz;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AutoCreeper", category = Category.Combat)
/*     */ public class AutoCreeper extends Module {
/*  25 */   DoubleSetting minDamage = registerDouble("Min Damage", 6.0D, 0.0D, 36.0D);
/*  26 */   IntegerSetting delay = registerInteger("Delay", 50, 0, 1000);
/*  27 */   DoubleSetting enemyRange = registerDouble("Enemy Range", 10.0D, 0.0D, 16.0D);
/*  28 */   DoubleSetting range = registerDouble("Range", 5.0D, 0.0D, 6.0D);
/*  29 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  30 */   BooleanSetting packet = registerBoolean("Packet", false);
/*  31 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  32 */   BooleanSetting silent = registerBoolean("Silent Switch", true);
/*  33 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", false);
/*     */   
/*  35 */   BooleanSetting predict = registerBoolean("Predict", true);
/*  36 */   IntegerSetting tickPredict = registerInteger("TickPredict", 8, 0, 30, () -> (Boolean)this.predict.getValue());
/*  37 */   BooleanSetting calculateYPredict = registerBoolean("CalculateYPredict", true, () -> (Boolean)this.predict.getValue());
/*  38 */   IntegerSetting startDecrease = registerInteger("StartDecrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  39 */   IntegerSetting exponentStartDecrease = registerInteger("ExponentStart", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  40 */   IntegerSetting decreaseY = registerInteger("DecreaseY", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  41 */   IntegerSetting exponentDecreaseY = registerInteger("ExponentDecreaseY", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.calculateYPredict.getValue()).booleanValue())));
/*  42 */   BooleanSetting splitXZ = registerBoolean("SplitXZ", true, () -> (Boolean)this.predict.getValue());
/*  43 */   BooleanSetting manualOutHole = registerBoolean("ManualOutHole", false, () -> (Boolean)this.predict.getValue());
/*  44 */   BooleanSetting aboveHoleManual = registerBoolean("AboveHoleManual", false, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.manualOutHole.getValue()).booleanValue())));
/*  45 */   BooleanSetting stairPredict = registerBoolean("StairPredict", false, () -> (Boolean)this.predict.getValue());
/*  46 */   IntegerSetting nStair = registerInteger("NStair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*  47 */   DoubleSetting speedActivationStair = registerDouble("SpeedActivationStair", 0.11D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.predict.getValue()).booleanValue() && ((Boolean)this.stairPredict.getValue()).booleanValue())));
/*     */   
/*  49 */   Timing timer = new Timing();
/*     */   EntityPlayer target;
/*     */   
/*     */   public void onTick() {
/*  53 */     int slot = getSlot();
/*  54 */     if (slot == -1)
/*  55 */       return;  this.target = PlayerUtil.getNearestPlayer(((Double)this.enemyRange.getValue()).doubleValue());
/*  56 */     if (this.target == null)
/*  57 */       return;  if (AutoEz.INSTANCE.isEnabled()) AutoEz.INSTANCE.addTargetedPlayer(this.target.getName()); 
/*  58 */     PredictUtil.PredictSettings settings = new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue());
/*  59 */     if (((Boolean)this.predict.getValue()).booleanValue()) this.target = PredictUtil.predictPlayer((EntityLivingBase)this.target, settings); 
/*  60 */     BlockPos blockPos = null;
/*  61 */     double dmg = 0.0D;
/*  62 */     for (BlockPos pos : EntityUtil.getSphere(PlayerUtil.getEyesPos(), (Double)this.range.getValue(), (Double)this.range.getValue(), false, false, 0)) {
/*  63 */       if (BurrowUtil.getFirstFacing(pos) == null)
/*  64 */         continue;  double damage = DamageUtil.calculateDamage((EntityLivingBase)this.target, pos.x + 0.5D, pos.y, pos.z + 0.5D, 3.0F, "Default");
/*  65 */       if (damage >= ((Double)this.minDamage.getValue()).doubleValue() && 
/*  66 */         dmg < damage) {
/*  67 */         blockPos = pos;
/*  68 */         dmg = damage;
/*     */       } 
/*     */     } 
/*  71 */     if (blockPos == null)
/*  72 */       return;  if (this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) {
/*  73 */       this.timer.reset();
/*  74 */       int oldslot = mc.player.inventory.currentItem;
/*  75 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*  76 */       else { mc.player.inventory.currentItem = slot; }
/*  77 */        BurrowUtil.placeBlock(blockPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*  78 */       if (((Boolean)this.silent.getValue()).booleanValue())
/*  79 */         if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/*  80 */         else { mc.player.inventory.currentItem = oldslot; }
/*     */          
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getSlot() {
/*  86 */     int newSlot = -1;
/*  87 */     for (int i = 0; i < 9; ) {
/*     */ 
/*     */       
/*  90 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */       
/*  92 */       if (stack == ItemStack.EMPTY || stack.getItem() != Items.SPAWN_EGG) {
/*     */         i++;
/*     */         continue;
/*     */       } 
/*  96 */       newSlot = i;
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return newSlot;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoCreeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
