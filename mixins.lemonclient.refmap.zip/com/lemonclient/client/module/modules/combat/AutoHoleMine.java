//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.dev.BedCevBreaker;
/*     */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoHoleMine", category = Category.Combat)
/*     */ public final class AutoHoleMine extends Module {
/*     */   public static AutoHoleMine INSTANCE;
/*     */   BooleanSetting breakTrap;
/*     */   BooleanSetting doubleMine;
/*     */   BooleanSetting ignore;
/*     */   BooleanSetting ignorePiston;
/*     */   
/*     */   public AutoHoleMine() {
/*  27 */     this.breakTrap = registerBoolean("Break Trap", false);
/*  28 */     this.doubleMine = registerBoolean("Double Mine", true);
/*  29 */     this.ignore = registerBoolean("Ignore Bed", false);
/*  30 */     this.ignorePiston = registerBoolean("Ignore Piston", false);
/*  31 */     this.ignoreWeb = registerBoolean("Ignore Web", false);
/*  32 */     this.fire = registerBoolean("Fire", false);
/*  33 */     this.sand = registerBoolean("Falling Blocks", false);
/*     */ 
/*     */     
/*  36 */     this.side = new BlockPos[] { new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0) };
/*     */     INSTANCE = this;
/*     */   }
/*     */   BooleanSetting ignoreWeb; BooleanSetting fire;
/*     */   BooleanSetting sand;
/*     */   public boolean working;
/*     */   BlockPos[] side;
/*     */   
/*     */   public void onUpdate() {
/*  45 */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */       return;
/*     */     }
/*  48 */     this.working = false;
/*  49 */     if (AntiBurrow.INSTANCE.mining || AntiRegear.INSTANCE.working || CevBreaker.INSTANCE.working || BedCevBreaker.INSTANCE.working)
/*     */       return; 
/*  51 */     BlockPos instantPos = null;
/*  52 */     if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos; 
/*  53 */     if (instantPos != null) {
/*  54 */       if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ)))
/*  55 */         return;  if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ)))
/*  56 */         return;  if (mc.world.getBlockState(instantPos).getBlock() == Blocks.WEB)
/*     */         return; 
/*     */     } 
/*  59 */     EntityPlayer target = PlayerUtil.getNearestPlayer(8.0D);
/*  60 */     if (target == null)
/*  61 */       return;  BlockPos feet = new BlockPos(target.posX, target.posY + 0.2D, target.posZ);
/*     */     
/*  63 */     double breakRange = 0.0D;
/*  64 */     BlockPos doublePos = null;
/*  65 */     if (ModuleManager.isModuleEnabled(PacketMine.class)) {
/*  66 */       doublePos = PacketMine.INSTANCE.doublePos;
/*  67 */       breakRange = ((Double)PacketMine.INSTANCE.breakRange.getValue()).doubleValue();
/*     */     } 
/*     */     
/*  70 */     BlockPos pos = null;
/*  71 */     for (BlockPos side : this.side) {
/*  72 */       BlockPos surroundPos = feet.add((Vec3i)side);
/*  73 */       BlockPos crystalPos = surroundPos.add((Vec3i)side);
/*  74 */       if (BlockUtil.isAir(surroundPos)) {
/*  75 */         if (BlockUtil.isAir(surroundPos.up()))
/*  76 */           return;  if (BlockUtil.isAirBlock(crystalPos) && BlockUtil.isAirBlock(crystalPos.up()))
/*  77 */           if (((Boolean)this.breakTrap.getValue()).booleanValue()) { pos = surroundPos.up(); }
/*     */           else
/*     */           { return; }
/*     */            
/*     */       } 
/*  82 */     }  if (pos != null) {
/*  83 */       surroundMine(pos);
/*     */       
/*     */       return;
/*     */     } 
/*  87 */     List<BlockPos> posList = new ArrayList<>();
/*  88 */     for (BlockPos side : this.side) {
/*  89 */       BlockPos surroundPos = feet.add((Vec3i)side);
/*  90 */       BlockPos crystalPos = surroundPos.add((Vec3i)side);
/*  91 */       if (BlockUtil.isAirBlock(crystalPos) && BlockUtil.isAirBlock(crystalPos.up()))
/*  92 */       { if (checkMine(surroundPos, breakRange)) posList.add(surroundPos);  }
/*  93 */       else if (BlockUtil.isAir(surroundPos) && BlockUtil.isAirBlock(crystalPos.up()))
/*  94 */       { if (checkMine(crystalPos, breakRange)) posList.add(crystalPos);  }
/*  95 */       else if (BlockUtil.isAir(surroundPos) && BlockUtil.isAirBlock(crystalPos) && 
/*  96 */         checkMine(crystalPos.up(), breakRange)) { posList.add(crystalPos.up()); }
/*     */     
/*     */     } 
/*     */     
/* 100 */     if (!posList.isEmpty()) {
/* 101 */       surroundMine(posList.stream().min(Comparator.comparing(mc.player::getDistanceSq)).orElse(null));
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     if (((Boolean)this.doubleMine.getValue()).booleanValue()) {
/* 106 */       List<DoubleBreak> breakList = new ArrayList<>();
/* 107 */       for (BlockPos side : this.side) {
/* 108 */         BlockPos surroundPos = feet.add((Vec3i)side);
/* 109 */         BlockPos crystalPos = surroundPos.add((Vec3i)side);
/* 110 */         if (!BlockUtil.isAir(surroundPos) && !BlockUtil.isAirBlock(crystalPos) && BlockUtil.isAirBlock(crystalPos.up()))
/* 111 */         { if (checkMine(surroundPos, breakRange) && checkMine(crystalPos, breakRange)) breakList.add(new DoubleBreak(surroundPos, crystalPos));  }
/* 112 */         else if (!BlockUtil.isAir(surroundPos) && !BlockUtil.isAirBlock(crystalPos.up()) && BlockUtil.isAirBlock(crystalPos))
/* 113 */         { if (checkMine(surroundPos, breakRange) && checkMine(crystalPos.up(), breakRange)) breakList.add(new DoubleBreak(surroundPos, crystalPos.up()));  }
/* 114 */         else if (BlockUtil.isAir(surroundPos) && !BlockUtil.isAirBlock(crystalPos) && !BlockUtil.isAirBlock(crystalPos.up()) && 
/* 115 */           checkMine(crystalPos, breakRange) && checkMine(crystalPos.up(), breakRange)) { breakList.add(new DoubleBreak(crystalPos, crystalPos.up())); }
/*     */       
/*     */       } 
/*     */       
/* 119 */       if (breakList.isEmpty()) {
/* 120 */         for (BlockPos side : this.side) {
/* 121 */           BlockPos surroundPos = feet.add((Vec3i)side);
/* 122 */           BlockPos crystalPos = surroundPos.add((Vec3i)side);
/* 123 */           if (checkMine(surroundPos, breakRange) && checkMine(crystalPos, breakRange) && checkMine(crystalPos.up(), breakRange)) {
/* 124 */             breakList.add(new DoubleBreak(crystalPos, crystalPos.up()));
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 129 */       if (breakList.isEmpty()) {
/* 130 */         for (BlockPos side : this.side) {
/* 131 */           BlockPos surroundPos = feet.add((Vec3i)side);
/* 132 */           BlockPos crystalPos = surroundPos.add((Vec3i)side);
/* 133 */           if (!BlockUtil.isAirBlock(crystalPos) && !BlockUtil.isAirBlock(crystalPos.up()) && !checkMine(crystalPos) && !checkMine(crystalPos.up()) && checkMine(surroundPos, breakRange) && checkMine(surroundPos.up(), breakRange)) {
/* 134 */             breakList.add(new DoubleBreak(surroundPos, surroundPos.up()));
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 139 */       if (!breakList.isEmpty()) {
/* 140 */         DoubleBreak doubleBreak = breakList.stream().min(Comparator.comparing(DoubleBreak::maxRange)).orElse(null);
/* 141 */         surroundMine(doubleBreak.doublePos);
/* 142 */         if (doublePos == null) surroundMine(doubleBreak.packetPos); 
/*     */         return;
/*     */       } 
/*     */     } else {
/* 146 */       for (BlockPos side : this.side) {
/* 147 */         BlockPos surroundPos = feet.add((Vec3i)side);
/* 148 */         BlockPos crystalPos = surroundPos.add((Vec3i)side);
/* 149 */         if (!BlockUtil.isAir(surroundPos) && checkMine(surroundPos, breakRange)) {
/* 150 */           if ((BlockUtil.isAirBlock(crystalPos) && checkMine(crystalPos, breakRange)) || (BlockUtil.isAirBlock(crystalPos.up()) && checkMine(crystalPos.up(), breakRange)))
/* 151 */             posList.add(surroundPos); 
/* 152 */         } else if (!BlockUtil.isAirBlock(crystalPos) && checkMine(crystalPos, breakRange)) {
/* 153 */           if ((BlockUtil.isAir(surroundPos) && checkMine(surroundPos, breakRange)) || (BlockUtil.isAirBlock(crystalPos.up()) && checkMine(crystalPos.up(), breakRange)))
/* 154 */             posList.add(crystalPos); 
/* 155 */         } else if (!BlockUtil.isAirBlock(crystalPos.up()) && checkMine(crystalPos.up(), breakRange) && ((
/* 156 */           BlockUtil.isAir(surroundPos) && checkMine(surroundPos, breakRange)) || (BlockUtil.isAirBlock(crystalPos) && checkMine(crystalPos, breakRange)))) {
/* 157 */           posList.add(crystalPos.up());
/*     */         } 
/*     */       } 
/* 160 */       if (posList.isEmpty()) {
/* 161 */         for (BlockPos side : this.side) {
/* 162 */           BlockPos surroundPos = feet.add((Vec3i)side);
/* 163 */           BlockPos crystalPos = surroundPos.add((Vec3i)side);
/* 164 */           if (checkMine(surroundPos, breakRange) && checkMine(crystalPos, breakRange) && checkMine(crystalPos.up(), breakRange)) {
/* 165 */             posList.add(crystalPos.up());
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 170 */       if (!posList.isEmpty()) {
/* 171 */         surroundMine(posList.stream().min(Comparator.comparing(mc.player::getDistanceSq)).orElse(null));
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 176 */     boolean hole = true;
/* 177 */     for (BlockPos offset : this.side) {
/* 178 */       if (BlockUtil.isAir(feet.add((Vec3i)offset)) && BlockUtil.isAir(feet.add((Vec3i)offset).up())) hole = false; 
/*     */     } 
/* 180 */     if (!hole)
/*     */       return; 
/* 182 */     for (BlockPos side : this.side) {
/* 183 */       BlockPos surroundPos = feet.add((Vec3i)side);
/* 184 */       if (checkMine(surroundPos, breakRange)) posList.add(surroundPos);
/*     */     
/*     */     } 
/* 187 */     if (!posList.isEmpty()) surroundMine(posList.stream().min(Comparator.comparing(mc.player::getDistanceSq)).orElse(null)); 
/*     */   }
/*     */   
/*     */   private boolean checkMine(BlockPos pos) {
/* 191 */     return (!BlockUtil.isAir(pos) && (BlockUtil.getBlock(pos)).blockHardness >= 0.0F && can(pos));
/*     */   }
/*     */   private boolean checkMine(BlockPos pos, double range) {
/* 194 */     return (!BlockUtil.isAir(pos) && (BlockUtil.getBlock(pos)).blockHardness >= 0.0F && can(pos) && getDistance(pos) <= range);
/*     */   }
/*     */   
/*     */   private boolean can(BlockPos pos) {
/* 198 */     return ((!((Boolean)this.ignore.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.BED) && (
/* 199 */       !((Boolean)this.ignorePiston.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.PISTON_HEAD) && (
/* 200 */       !((Boolean)this.ignoreWeb.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.WEB) && (((Boolean)this.fire
/* 201 */       .getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.FIRE) && (((Boolean)this.sand
/* 202 */       .getValue()).booleanValue() || (mc.world.getBlockState(pos).getBlock() != Blocks.SAND && mc.world.getBlockState(pos).getBlock() != Blocks.GRAVEL && mc.world.getBlockState(pos).getBlock() != Blocks.ANVIL && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockConcretePowder))));
/*     */   }
/*     */   
/*     */   private void surroundMine(BlockPos pos) {
/* 206 */     if (pos == null || !checkMine(pos))
/* 207 */       return;  this.working = true;
/*     */ 
/*     */     
/* 210 */     BlockPos doublePos = null, instantPos = doublePos;
/* 211 */     if (ModuleManager.isModuleEnabled(PacketMine.class)) {
/* 212 */       instantPos = PacketMine.INSTANCE.packetPos;
/* 213 */       doublePos = PacketMine.INSTANCE.doublePos;
/*     */     } 
/* 215 */     if (instantPos != null && instantPos.equals(pos))
/* 216 */       return;  if (doublePos != null && doublePos.equals(pos))
/*     */       return; 
/* 218 */     mc.playerController.onPlayerDamageBlock(pos, BlockUtil.getRayTraceFacing(pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getDistance(BlockPos pos) {
/* 245 */     return mc.player.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D);
/*     */   }
/*     */   class DoubleBreak { BlockPos packetPos;
/*     */     
/*     */     public DoubleBreak(BlockPos packetPos, BlockPos doublePos) {
/* 250 */       this.packetPos = packetPos;
/* 251 */       this.doublePos = doublePos;
/*     */     }
/*     */     BlockPos doublePos;
/*     */     public double maxRange() {
/* 255 */       double packetRange = AutoHoleMine.this.getDistance(this.packetPos);
/* 256 */       double doubleRange = AutoHoleMine.this.getDistance(this.doublePos);
/* 257 */       return Math.max(packetRange, doubleRange);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoHoleMine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
