//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.PredictUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AutoWeb", category = Category.Combat)
/*     */ public class AutoWeb extends Module {
/*  30 */   ModeSetting page = registerMode("Page", Arrays.asList(new String[] { "Settings", "Predict" }, ), "Settings");
/*  31 */   BooleanSetting silentSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  32 */   BooleanSetting check = registerBoolean("Switch Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  33 */   BooleanSetting rotate = registerBoolean("Rotate", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  34 */   BooleanSetting packet = registerBoolean("Packet", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  35 */   BooleanSetting swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  36 */   IntegerSetting delay = registerInteger("Delay", 50, 0, 2000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  37 */   IntegerSetting multiPlace = registerInteger("MultiPlace", 1, 1, 8, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  38 */   BooleanSetting strict = registerBoolean("Strict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  39 */   BooleanSetting raytrace = registerBoolean("Raytrace", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  40 */   BooleanSetting noInWeb = registerBoolean("NoInWeb", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  41 */   BooleanSetting checkSelf = registerBoolean("CheckSelf", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  42 */   BooleanSetting onlyGround = registerBoolean("SelfGround", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  43 */   BooleanSetting down = registerBoolean("Down", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  44 */   BooleanSetting face = registerBoolean("Face", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  45 */   BooleanSetting feet = registerBoolean("Feet", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  46 */   BooleanSetting onlyAir = registerBoolean("OnlyAir", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  47 */   BooleanSetting air = registerBoolean("Air", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  48 */   DoubleSetting minTargetSpeed = registerDouble("MinTargetSpeed", 10.0D, 0.0D, 50.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  49 */   DoubleSetting range = registerDouble("Range", 5.0D, 1.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Settings")));
/*  50 */   IntegerSetting tickPredict = registerInteger("Tick Predict", 8, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Predict")));
/*  51 */   BooleanSetting calculateYPredict = registerBoolean("Calculate Y Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Predict")));
/*  52 */   IntegerSetting startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  53 */   IntegerSetting exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  54 */   IntegerSetting decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  55 */   IntegerSetting exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  56 */   BooleanSetting splitXZ = registerBoolean("Split XZ", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Predict")));
/*  57 */   BooleanSetting manualOutHole = registerBoolean("Manual Out Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Predict")));
/*  58 */   BooleanSetting aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> Boolean.valueOf((((Boolean)this.manualOutHole.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  59 */   BooleanSetting stairPredict = registerBoolean("Stair Predict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Predict")));
/*  60 */   IntegerSetting nStair = registerInteger("N Stair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  61 */   DoubleSetting speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Predict"))));
/*  62 */   private final Timing timer = new Timing();
/*  63 */   private int progress = 0;
/*     */   
/*     */   public void onTick() {
/*  66 */     if (!this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) {
/*     */       return;
/*     */     }
/*     */     
/*  70 */     if (((Boolean)this.onlyGround.getValue()).booleanValue() && !mc.player.onGround) {
/*     */       return;
/*     */     }
/*  73 */     this.progress = 0;
/*  74 */     PredictUtil.PredictSettings settings = new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue());
/*  75 */     for (EntityPlayer player : mc.world.playerEntities) {
/*  76 */       EntityPlayer target = PredictUtil.predictPlayer((EntityLivingBase)player, settings);
/*  77 */       if (EntityUtil.invalid((Entity)target, ((Double)this.range.getValue()).doubleValue() + 3.0D) || (isInWeb(player) && ((Boolean)this.noInWeb.getValue()).booleanValue()) || 
/*  78 */         LemonClient.speedUtil.getPlayerSpeed(player) < ((Double)this.minTargetSpeed.getValue()).doubleValue() || ((
/*  79 */         (Boolean)this.onlyAir.getValue()).booleanValue() && player.onGround))
/*  80 */         continue;  if (((Boolean)this.down.getValue()).booleanValue()) {
/*  81 */         placeWeb(new BlockPos(target.posX, target.posY - 0.3D, target.posZ));
/*  82 */         placeWeb(new BlockPos(target.posX + 0.1D, target.posY - 0.3D, target.posZ + 0.1D));
/*  83 */         placeWeb(new BlockPos(target.posX - 0.1D, target.posY - 0.3D, target.posZ + 0.1D));
/*  84 */         placeWeb(new BlockPos(target.posX - 0.1D, target.posY - 0.3D, target.posZ - 0.1D));
/*  85 */         placeWeb(new BlockPos(target.posX + 0.1D, target.posY - 0.3D, target.posZ - 0.1D));
/*     */       } 
/*  87 */       if (((Boolean)this.face.getValue()).booleanValue()) {
/*  88 */         placeWeb(new BlockPos(target.posX + 0.2D, target.posY + 1.5D, target.posZ + 0.2D));
/*  89 */         placeWeb(new BlockPos(target.posX - 0.2D, target.posY + 1.5D, target.posZ + 0.2D));
/*  90 */         placeWeb(new BlockPos(target.posX - 0.2D, target.posY + 1.5D, target.posZ - 0.2D));
/*  91 */         placeWeb(new BlockPos(target.posX + 0.2D, target.posY + 1.5D, target.posZ - 0.2D));
/*     */       } 
/*  93 */       if (!((Boolean)this.air.getValue()).booleanValue() || player.onGround || !((Boolean)this.feet.getValue()).booleanValue() || HoleUtil.isHoleBlock(EntityUtil.getEntityPos((Entity)target), true, false, false))
/*  94 */         continue;  placeWeb(new BlockPos(target.posX + 0.2D, target.posY + 0.5D, target.posZ + 0.2D));
/*  95 */       placeWeb(new BlockPos(target.posX - 0.2D, target.posY + 0.5D, target.posZ + 0.2D));
/*  96 */       placeWeb(new BlockPos(target.posX - 0.2D, target.posY + 0.5D, target.posZ - 0.2D));
/*  97 */       placeWeb(new BlockPos(target.posX + 0.2D, target.posY + 0.5D, target.posZ - 0.2D));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isInWeb(EntityPlayer player) {
/* 102 */     if (isWeb(new BlockPos(player.posX + 0.3D, player.posY + 1.5D, player.posZ + 0.3D))) {
/* 103 */       return true;
/*     */     }
/* 105 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY + 1.5D, player.posZ + 0.3D))) {
/* 106 */       return true;
/*     */     }
/* 108 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY + 1.5D, player.posZ - 0.3D))) {
/* 109 */       return true;
/*     */     }
/* 111 */     if (isWeb(new BlockPos(player.posX + 0.3D, player.posY + 1.5D, player.posZ - 0.3D))) {
/* 112 */       return true;
/*     */     }
/* 114 */     if (isWeb(new BlockPos(player.posX + 0.3D, player.posY - 0.5D, player.posZ + 0.3D))) {
/* 115 */       return true;
/*     */     }
/* 117 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY - 0.5D, player.posZ + 0.3D))) {
/* 118 */       return true;
/*     */     }
/* 120 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY - 0.5D, player.posZ - 0.3D))) {
/* 121 */       return true;
/*     */     }
/* 123 */     if (isWeb(new BlockPos(player.posX + 0.3D, player.posY - 0.5D, player.posZ - 0.3D))) {
/* 124 */       return true;
/*     */     }
/* 126 */     if (isWeb(new BlockPos(player.posX + 0.3D, player.posY + 0.5D, player.posZ + 0.3D))) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY + 0.5D, player.posZ + 0.3D))) {
/* 130 */       return true;
/*     */     }
/* 132 */     if (isWeb(new BlockPos(player.posX - 0.3D, player.posY + 0.5D, player.posZ - 0.3D))) {
/* 133 */       return true;
/*     */     }
/* 135 */     return isWeb(new BlockPos(player.posX + 0.3D, player.posY + 0.5D, player.posZ - 0.3D));
/*     */   }
/*     */   
/*     */   private static boolean isWeb(BlockPos pos) {
/* 139 */     return (mc.world.getBlockState(pos).getBlock() == Blocks.WEB && checkEntity(pos));
/*     */   }
/*     */   
/*     */   private boolean isSelf(BlockPos pos) {
/* 143 */     if (!((Boolean)this.checkSelf.getValue()).booleanValue()) {
/* 144 */       return false;
/*     */     }
/* 146 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 147 */       if (entity != mc.player)
/* 148 */         continue;  return true;
/*     */     } 
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean checkEntity(BlockPos pos) {
/* 154 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 155 */       if (!(entity instanceof EntityPlayer) || entity == mc.player)
/* 156 */         continue;  return true;
/*     */     } 
/* 158 */     return false;
/*     */   }
/*     */   
/*     */   private void placeWeb(BlockPos pos) {
/* 162 */     if (this.progress >= ((Integer)this.multiPlace.getValue()).intValue() || PlayerUtil.getDistance(pos) > ((Double)this.range.getValue()).doubleValue()) {
/*     */       return;
/*     */     }
/* 165 */     if (!mc.world.isAirBlock(pos.up())) {
/*     */       return;
/*     */     }
/* 168 */     if (!canPlace(pos)) {
/*     */       return;
/*     */     }
/* 171 */     if (isSelf(pos)) {
/*     */       return;
/*     */     }
/* 174 */     if (BurrowUtil.findHotbarBlock(BlockWeb.class) == -1) {
/*     */       return;
/*     */     }
/* 177 */     int old = mc.player.inventory.currentItem;
/* 178 */     switchTo(BurrowUtil.findHotbarBlock(BlockWeb.class));
/* 179 */     BlockUtil.placeBlock(pos, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 180 */     this.progress++;
/* 181 */     switchTo(old);
/* 182 */     this.timer.reset();
/*     */   }
/*     */   
/*     */   private void switchTo(int slot) {
/* 186 */     if (slot > -1 && slot < 9 && (
/* 187 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 188 */       if (((Boolean)this.silentSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/* 190 */       { mc.player.inventory.currentItem = slot;
/* 191 */         mc.playerController.updateController(); }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canPlace(BlockPos pos) {
/* 198 */     if (!BlockUtil.canBlockFacing(pos)) {
/* 199 */       return false;
/*     */     }
/* 201 */     if (!BlockUtil.canReplace(pos)) {
/* 202 */       return false;
/*     */     }
/* 204 */     return strictPlaceCheck(pos);
/*     */   }
/*     */   
/*     */   private boolean strictPlaceCheck(BlockPos pos) {
/* 208 */     if (!((Boolean)this.strict.getValue()).booleanValue() && ((Boolean)this.raytrace.getValue()).booleanValue()) {
/* 209 */       return true;
/*     */     }
/* 211 */     for (EnumFacing side : BlockUtil.getPlacableFacings(pos, true, ((Boolean)this.raytrace.getValue()).booleanValue())) {
/* 212 */       if (!BlockUtil.canClick(pos.offset(side)))
/* 213 */         continue;  return true;
/*     */     } 
/* 215 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoWeb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
