//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.DeathEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.block.BlockSlab;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AutoSelfFill", category = Category.Combat)
/*     */ public class AutoSelfFill extends Module {
/*     */   IntegerSetting delay;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting ps;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting obsidian;
/*     */   BooleanSetting echest;
/*     */   BooleanSetting web;
/*     */   
/*  27 */   public AutoSelfFill() { this.delay = registerInteger("Delay", 10, 0, 50);
/*  28 */     this.rotate = registerBoolean("Rotate", true);
/*  29 */     this.packet = registerBoolean("Packet Place", true);
/*  30 */     this.ps = registerBoolean("Packet Switch", true);
/*  31 */     this.swing = registerBoolean("Swing", true);
/*  32 */     this.obsidian = registerBoolean("Obsidian", true);
/*  33 */     this.echest = registerBoolean("Ender Chest", true);
/*  34 */     this.web = registerBoolean("Web", true);
/*  35 */     this.skull = registerBoolean("Skull", true);
/*  36 */     this.plate = registerBoolean("Slab", true);
/*  37 */     this.upPlate = registerBoolean("Up Slab", true);
/*  38 */     this.trapdoor = registerBoolean("Trapdoor", true);
/*  39 */     this.new_slot = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     this.deathEventListener = new Listener(event -> { if (event.player == mc.player) disable();  }new java.util.function.Predicate[0]); }
/*     */   BooleanSetting skull; BooleanSetting plate; BooleanSetting upPlate; BooleanSetting trapdoor; int new_slot; int waited; boolean door; boolean block; @EventHandler
/*     */   private final Listener<DeathEvent> deathEventListener; public void onUpdate() { if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */       return; 
/*     */     this.waited = 0;
/*     */     if (BlockUtil.isAir(PlayerUtil.getPlayerPos()) && mc.player.onGround && intersectsWithEntity(PlayerUtil.getPlayerPos()))
/*  55 */       placeBlock();  } public void placeBlock() { this.new_slot = find_in_hotbar();
/*  56 */     if (this.new_slot == -1)
/*  57 */       return;  int oldslot = mc.player.inventory.currentItem;
/*  58 */     switchTo(this.new_slot);
/*  59 */     if (this.door) {
/*  60 */       placeTrapdoor();
/*  61 */     } else if (((Boolean)this.upPlate.getValue()).booleanValue() && this.new_slot == BurrowUtil.findHotbarBlock(BlockSlab.class)) {
/*  62 */       burrowUp();
/*  63 */     } else if (this.block) {
/*  64 */       burrow();
/*     */     } else {
/*  66 */       BurrowUtil.placeBlock(PlayerUtil.getPlayerPos(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */     } 
/*  68 */     if (((Boolean)this.ps.getValue()).booleanValue())
/*  69 */     { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(mc.player.inventory.currentItem)); }
/*  70 */     else { switchTo(oldslot); }
/*     */      }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/*  75 */     if (mc.player.inventory.currentItem != slot && slot > -1 && slot < 9)
/*     */     {
/*  77 */       if (((Boolean)this.ps.getValue()).booleanValue()) {
/*  78 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.new_slot));
/*     */       } else {
/*  80 */         mc.player.inventory.currentItem = slot;
/*  81 */         mc.playerController.updateController();
/*     */       }  } 
/*     */   }
/*     */   
/*     */   private int find_in_hotbar() {
/*  86 */     this.door = this.block = false;
/*  87 */     int newHand = -1;
/*  88 */     if (((Boolean)this.trapdoor.getValue()).booleanValue()) {
/*  89 */       newHand = BurrowUtil.findHotbarBlock(BlockTrapDoor.class);
/*  90 */       if (newHand != -1) this.door = true; 
/*     */     } 
/*  92 */     if (newHand == -1 && ((Boolean)this.skull.getValue()).booleanValue()) newHand = InventoryUtil.findSkullSlot(); 
/*  93 */     if (newHand == -1 && ((Boolean)this.web.getValue()).booleanValue()) newHand = BurrowUtil.findHotbarBlock(BlockWeb.class); 
/*  94 */     if (newHand == -1 && ((Boolean)this.plate.getValue()).booleanValue()) newHand = BurrowUtil.findHotbarBlock(BlockSlab.class); 
/*  95 */     if (newHand == -1 && ((Boolean)this.obsidian.getValue()).booleanValue()) {
/*  96 */       newHand = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  97 */       if (newHand != -1) this.block = true; 
/*     */     } 
/*  99 */     if (newHand == -1 && ((Boolean)this.echest.getValue()).booleanValue()) {
/* 100 */       newHand = BurrowUtil.findHotbarBlock(BlockEnderChest.class);
/* 101 */       if (newHand != -1) this.block = true; 
/*     */     } 
/* 103 */     return newHand;
/*     */   }
/*     */   
/*     */   private void placeTrapdoor() {
/* 107 */     BlockPos originalPos = PlayerUtil.getPlayerPos();
/*     */     
/* 109 */     EnumFacing facing = BurrowUtil.getTrapdoorFacing(originalPos);
/* 110 */     if (facing == null) {
/*     */       return;
/*     */     }
/* 113 */     BlockPos neighbour = originalPos.offset(facing);
/* 114 */     EnumFacing opposite = facing.getOpposite();
/*     */     
/* 116 */     double x = mc.player.posX;
/* 117 */     double y = (int)mc.player.posY;
/* 118 */     double z = mc.player.posZ;
/* 119 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y + 0.20000000298023224D, z, mc.player.onGround));
/* 120 */     BurrowUtil.rightClickBlock(neighbour, opposite, new Vec3d(0.5D, 0.8D, 0.5D), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 121 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y, z, mc.player.onGround));
/*     */   }
/*     */   
/*     */   private void burrow() {
/* 125 */     BlockPos originalPos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
/* 126 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.42D, mc.player.posZ, true));
/* 127 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.75D, mc.player.posZ, true));
/* 128 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.01D, mc.player.posZ, true));
/* 129 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.16D, mc.player.posZ, true));
/* 130 */     BurrowUtil.placeBlock(originalPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 131 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.01D, mc.player.posZ, false));
/*     */   } private void burrowUp() {
/*     */     BlockPos neighbour;
/*     */     EnumFacing opposite;
/* 135 */     BlockPos originalPos = PlayerUtil.getPlayerPos();
/*     */ 
/*     */     
/* 138 */     if (!mc.world.isAirBlock(originalPos.south())) {
/* 139 */       neighbour = originalPos.offset(EnumFacing.SOUTH);
/* 140 */       opposite = EnumFacing.SOUTH.getOpposite();
/* 141 */     } else if (!mc.world.isAirBlock(originalPos.north())) {
/* 142 */       neighbour = originalPos.offset(EnumFacing.NORTH);
/* 143 */       opposite = EnumFacing.NORTH.getOpposite();
/* 144 */     } else if (!mc.world.isAirBlock(originalPos.east())) {
/* 145 */       neighbour = originalPos.offset(EnumFacing.EAST);
/* 146 */       opposite = EnumFacing.EAST.getOpposite();
/* 147 */     } else if (!mc.world.isAirBlock(originalPos.west())) {
/* 148 */       neighbour = originalPos.offset(EnumFacing.WEST);
/* 149 */       opposite = EnumFacing.WEST.getOpposite();
/*     */     } else {
/*     */       return;
/*     */     } 
/* 153 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.42D, mc.player.posZ, true));
/* 154 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.75D, mc.player.posZ, true));
/* 155 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.01D, mc.player.posZ, true));
/* 156 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.16D, mc.player.posZ, true));
/* 157 */     BurrowUtil.rightClickBlock(neighbour, opposite, new Vec3d(0.5D, 0.8D, 0.5D), ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue());
/* 158 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.01D, mc.player.posZ, false));
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 162 */     for (Entity entity : mc.world.loadedEntityList) {
/* 163 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && 
/* 164 */         entity != mc.player && (
/* 165 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 166 */         return true; 
/*     */     } 
/* 168 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoSelfFill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
