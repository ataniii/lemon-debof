//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.player.InvStack;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemArmor;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ 
/*     */ @Declaration(name = "AutoArmor", category = Category.Combat)
/*     */ public class AutoArmor extends Module {
/*     */   IntegerSetting delay;
/*     */   BooleanSetting noDesync;
/*     */   BooleanSetting illegalSync;
/*     */   IntegerSetting checkDelay;
/*     */   BooleanSetting strict;
/*     */   BooleanSetting stackArmor;
/*     */   IntegerSetting slot;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting check;
/*     */   BooleanSetting armorSaver;
/*     */   BooleanSetting pauseWhenSafe;
/*     */   IntegerSetting depletion;
/*     */   BooleanSetting allowMend;
/*     */   IntegerSetting repair;
/*     */   Timing rightClickTimer;
/*     */   Timing timer;
/*     */   private boolean sleep;
/*     */   @EventHandler
/*     */   private final Listener<PlayerInteractEvent.RightClickItem> listener;
/*     */   
/*  39 */   public AutoArmor() { this.delay = registerInteger("Delay", 1, 1, 10);
/*  40 */     this.noDesync = registerBoolean("No Desync", true);
/*  41 */     this.illegalSync = registerBoolean("Illegal Sync", true);
/*  42 */     this.checkDelay = registerInteger("Check Delay", 1, 0, 20, () -> (Boolean)this.noDesync.getValue());
/*  43 */     this.strict = registerBoolean("Strict", false);
/*  44 */     this.stackArmor = registerBoolean("Stack Armor", false);
/*  45 */     this.slot = registerInteger("Swap Slot", 1, 1, 9, () -> (Boolean)this.stackArmor.getValue());
/*  46 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> (Boolean)this.stackArmor.getValue());
/*  47 */     this.check = registerBoolean("Switch Check", true, () -> (Boolean)this.stackArmor.getValue());
/*  48 */     this.armorSaver = registerBoolean("Armor Saver", false);
/*  49 */     this.pauseWhenSafe = registerBoolean("Pause When Safe", false);
/*  50 */     this.depletion = registerInteger("Depletion", 20, 0, 99, () -> (Boolean)this.armorSaver.getValue());
/*  51 */     this.allowMend = registerBoolean("Allow Mend", false);
/*  52 */     this.repair = registerInteger("Repair", 80, 0, 100);
/*     */     
/*  54 */     this.rightClickTimer = new Timing();
/*  55 */     this.timer = new Timing();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     this.listener = new Listener(event -> { if (event.getEntityPlayer() != mc.player) return;  if (event.getItemStack().getItem() != Items.EXPERIENCE_BOTTLE) return;  this.rightClickTimer.reset(); }new java.util.function.Predicate[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void swapSlot(int source, int target) {
/* 223 */     ItemStack sourceStack = mc.player.inventoryContainer.getSlot(source).getStack();
/* 224 */     boolean stacked = (sourceStack.getCount() > 1);
/* 225 */     if (stacked) { swapStack(source, target); }
/* 226 */     else { swap(source, target); }
/* 227 */      this.sleep = true;
/*     */   }
/*     */   public void onUpdate() { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (mc.player.ticksExisted % ((Integer)this.delay.getValue()).intValue() != 0 || checkDesync()) return;  if (((Boolean)this.strict.getValue()).booleanValue() && (mc.player.motionX != 0.0D || mc.player.motionZ != 0.0D)) return;  if (((Boolean)this.pauseWhenSafe.getValue()).booleanValue()) { List<Entity> proximity = (List<Entity>)mc.world.loadedEntityList.stream().filter(e -> ((e instanceof EntityPlayer && !e.equals(mc.player) && mc.player.getDistance(e) <= 6.0F) || (e instanceof net.minecraft.entity.item.EntityEnderCrystal && mc.player.getDistance(e) <= 12.0F))).collect(Collectors.toList()); if (proximity.isEmpty()) return;  }  boolean isMending = ModuleManager.isModuleEnabled(AutoMend.class); if (((Boolean)this.allowMend.getValue()).booleanValue() && !this.rightClickTimer.passedMs(500L)) { for (int i = 0; i < mc.player.inventory.armorInventory.size(); i++) { ItemStack armorPiece = (ItemStack)mc.player.inventory.armorInventory.get(i); if (armorPiece.isEmpty) return;  boolean mending = false; for (Map.Entry<Enchantment, Integer> entry : (Iterable<Map.Entry<Enchantment, Integer>>)EnchantmentHelper.getEnchantments(armorPiece).entrySet()) { if (((Enchantment)entry.getKey()).getName().contains("mending")) { mending = true; break; }  }  if (mending && !armorPiece.isEmpty()) { long freeSlots = mc.player.inventory.mainInventory.stream().filter(is -> (is.isEmpty() || is.getItem() == Items.AIR)).map(is -> Integer.valueOf(mc.player.inventory.getSlotFor(is))).count(); if (freeSlots <= 0L) return;  if (armorPiece.getItemDamage() != 0) { shiftClickSpot(8 - i); return; }  }  }  return; }  if (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory)) return;  AtomicBoolean hasSwapped = new AtomicBoolean(false); if (this.sleep) { this.sleep = false; return; }  Set<InvStack> replacements = new HashSet<>(); for (int slot = 0; slot < 45; slot++) { if (slot <= 4 || slot >= 9) { InvStack invStack = new InvStack(slot, mc.player.inventoryContainer.getSlot(slot).getStack()); if (invStack.stack.getItem() instanceof ItemArmor || invStack.stack.getItem() instanceof net.minecraft.item.ItemElytra) replacements.add(invStack);  }  }  List<InvStack> armors = (List<InvStack>)replacements.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).filter(invStack -> (!((Boolean)this.armorSaver.getValue()).booleanValue() || invStack.stack.getItem().getDurabilityForDisplay(invStack.stack) < ((Integer)this.depletion.getValue()).intValue())).sorted(Comparator.comparingInt(invStack -> invStack.slot)).sorted(Comparator.comparingInt(invStack -> ((ItemArmor)invStack.stack.getItem()).damageReduceAmount)).collect(Collectors.toList()); boolean wasEmpty = armors.isEmpty(); if (wasEmpty) armors = (List<InvStack>)replacements.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).sorted(Comparator.comparingInt(invStack -> invStack.slot)).sorted(Comparator.comparingInt(invStack -> ((ItemArmor)invStack.stack.getItem()).damageReduceAmount)).collect(Collectors.toList());  ItemStack currentHeadItem = mc.player.inventory.getStackInSlot(39); ItemStack currentChestItem = mc.player.inventory.getStackInSlot(38); ItemStack currentLegsItem = mc.player.inventory.getStackInSlot(37); ItemStack currentFeetItem = mc.player.inventory.getStackInSlot(36); boolean saveHead = (!wasEmpty && currentHeadItem.getCount() == 1 && ((Boolean)this.armorSaver.getValue()).booleanValue() && getItemDamage(5) <= ((Integer)this.depletion.getValue()).intValue()); boolean saveChest = (!wasEmpty && currentChestItem.getCount() == 1 && ((Boolean)this.armorSaver.getValue()).booleanValue() && getItemDamage(6) <= ((Integer)this.depletion.getValue()).intValue()); boolean saveLegs = (!wasEmpty && currentLegsItem.getCount() == 1 && ((Boolean)this.armorSaver.getValue()).booleanValue() && getItemDamage(7) <= ((Integer)this.depletion.getValue()).intValue()); boolean saveFeet = (!wasEmpty && currentFeetItem.getCount() == 1 && ((Boolean)this.armorSaver.getValue()).booleanValue() && getItemDamage(8) <= ((Integer)this.depletion.getValue()).intValue()); boolean replaceHead = (currentHeadItem.isEmpty || saveHead || (isMending && getItemDamage(5) >= ((Integer)this.repair.getValue()).intValue())); boolean replaceChest = (currentChestItem.isEmpty || saveChest || (isMending && getItemDamage(6) >= ((Integer)this.repair.getValue()).intValue())); boolean replaceLegs = (currentLegsItem.isEmpty || saveLegs || (isMending && getItemDamage(7) >= ((Integer)this.repair.getValue()).intValue())); boolean replaceFeet = (currentFeetItem.isEmpty || saveFeet || (isMending && getItemDamage(8) >= ((Integer)this.repair.getValue()).intValue())); if (replaceHead && !hasSwapped.get()) armors.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).filter(invStack -> ((ItemArmor)invStack.stack.getItem()).armorType.equals(EntityEquipmentSlot.HEAD)).filter(invStack -> (!saveHead || getItemDamage(invStack.slot) > ((Integer)this.depletion.getValue()).intValue())).filter(invStack -> (!isMending || getItemDamage(invStack.slot) <= ((Integer)this.repair.getValue()).intValue())).findFirst().ifPresent(invStack -> { swapSlot(invStack.slot, 5); hasSwapped.set(true); });  if (replaceChest || (currentChestItem.getItem() instanceof net.minecraft.item.ItemElytra && !hasSwapped.get()))
/*     */       armors.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).filter(invStack -> ((ItemArmor)invStack.stack.getItem()).armorType.equals(EntityEquipmentSlot.CHEST)).filter(invStack -> (!saveChest || getItemDamage(invStack.slot) > ((Integer)this.depletion.getValue()).intValue())).filter(invStack -> (!isMending || getItemDamage(invStack.slot) <= ((Integer)this.repair.getValue()).intValue())).findFirst().ifPresent(invStack -> { swapSlot(invStack.slot, 6); hasSwapped.set(true); });  if (replaceLegs && !hasSwapped.get())
/*     */       armors.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).filter(invStack -> ((ItemArmor)invStack.stack.getItem()).armorType.equals(EntityEquipmentSlot.LEGS)).filter(invStack -> (!saveLegs || getItemDamage(invStack.slot) > ((Integer)this.depletion.getValue()).intValue())).filter(invStack -> (!isMending || getItemDamage(invStack.slot) <= ((Integer)this.repair.getValue()).intValue())).findFirst().ifPresent(invStack -> { swapSlot(invStack.slot, 7); hasSwapped.set(true); });  if (replaceFeet && !hasSwapped.get())
/* 232 */       armors.stream().filter(invStack -> invStack.stack.getItem() instanceof ItemArmor).filter(invStack -> ((ItemArmor)invStack.stack.getItem()).armorType.equals(EntityEquipmentSlot.FEET)).filter(invStack -> (!saveFeet || getItemDamage(invStack.slot) > ((Integer)this.depletion.getValue()).intValue())).filter(invStack -> (!isMending || getItemDamage(invStack.slot) <= ((Integer)this.repair.getValue()).intValue())).findFirst().ifPresent(invStack -> { swapSlot(invStack.slot, 8); hasSwapped.set(true); });  } private int getItemDamage(int slot) { ItemStack itemStack = mc.player.inventoryContainer.getSlot(slot).getStack(); float green = (itemStack.getMaxDamage() - itemStack.getItemDamage()) / itemStack.getMaxDamage(); float red = 1.0F - green; return 100 - (int)(red * 100.0F); } private void swapStack(int slotFrom, int slotTo) { if (!((Boolean)this.stackArmor.getValue()).booleanValue())
/* 233 */       return;  if (mc.player.inventoryContainer.getSlot(slotTo).getStack() != ItemStack.EMPTY) mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotTo, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player); 
/* 234 */     int oldslot = mc.player.inventory.currentItem;
/* 235 */     if (slotFrom < 36) {
/* 236 */       swapToHotbar(slotFrom);
/* 237 */       switchTo(((Integer)this.slot.getValue()).intValue() - 1);
/*     */     } else {
/* 239 */       switchTo(slotFrom - 36);
/*     */     } 
/* 241 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
/* 242 */     switchTo(oldslot);
/* 243 */     mc.playerController.updateController();
/* 244 */     if (slotFrom < 36) swapToHotbar(slotFrom);
/*     */      }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkDesync() {
/* 250 */     if ((((Boolean)this.noDesync.getValue()).booleanValue() && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer)) || (mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory && this.timer
/*     */       
/* 252 */       .passedMs((((Integer)this.checkDelay.getValue()).intValue() * 50)))) {
/*     */       
/* 254 */       int bestSlot = -1;
/* 255 */       int clientValue = 0;
/* 256 */       boolean foundType = false;
/* 257 */       int armorValue = mc.player.getTotalArmorValue();
/* 258 */       for (int i = 5; i < 9; i++) {
/*     */ 
/*     */         
/* 261 */         ItemStack stack = mc.player.inventoryContainer.getSlot(i).getStack();
/* 262 */         if (stack.isEmpty() && !foundType) {
/* 263 */           bestSlot = i;
/* 264 */           foundType = true;
/*     */         }
/* 266 */         else if (stack.getItem() instanceof ItemArmor) {
/* 267 */           ItemArmor itemArmor = (ItemArmor)stack.getItem();
/* 268 */           clientValue += itemArmor.damageReduceAmount;
/*     */         } 
/*     */       } 
/*     */       
/* 272 */       if (clientValue != armorValue && this.timer.passedMs((((Integer)this.delay.getValue()).intValue() * 50))) {
/* 273 */         if (((Boolean)this.illegalSync.getValue()).booleanValue()) {
/* 274 */           InventoryUtil.illegalSync();
/*     */         }
/* 276 */         else if (bestSlot != -1 && getSlot(mc.player.inventory.getItemStack()) == fromSlot(bestSlot)) {
/* 277 */           Item item = get(bestSlot).getItem();
/* 278 */           clickLocked(bestSlot, bestSlot, item, item);
/*     */         } else {
/* 280 */           Item item = get(20).getItem();
/* 281 */           clickLocked(20, 20, item, item);
/*     */         } 
/* 283 */         this.timer.reset();
/* 284 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 288 */     return false;
/*     */   }
/*     */   
/*     */   public static void clickLocked(int slot, int to, Item inSlot, Item inTo) {
/* 292 */     Locks.acquire(Locks.WINDOW_CLICK_LOCK, () -> {
/*     */           if ((slot == -1 || get(slot).getItem() == inSlot) && get(to).getItem() == inTo) {
/*     */             boolean multi = (slot >= 0);
/*     */             if (multi) {
/*     */               click(slot);
/*     */             }
/*     */             click(to);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static void click(int slot) {
/* 305 */     mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ItemStack get(int slot) {
/* 311 */     if (slot == -2)
/*     */     {
/* 313 */       return mc.player.inventory.getItemStack();
/*     */     }
/*     */     
/* 316 */     return (ItemStack)mc.player.inventoryContainer.getInventory().get(slot);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityEquipmentSlot fromSlot(int slot) {
/* 321 */     switch (slot) {
/*     */       
/*     */       case 5:
/* 324 */         return EntityEquipmentSlot.HEAD;
/*     */       case 6:
/* 326 */         return EntityEquipmentSlot.CHEST;
/*     */       case 7:
/* 328 */         return EntityEquipmentSlot.LEGS;
/*     */       case 8:
/* 330 */         return EntityEquipmentSlot.FEET;
/*     */     } 
/* 332 */     ItemStack stack = get(slot);
/* 333 */     return getSlot(stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityEquipmentSlot getSlot(ItemStack stack) {
/* 338 */     if (!stack.isEmpty()) {
/*     */       
/* 340 */       if (stack.getItem() instanceof ItemArmor) {
/*     */         
/* 342 */         ItemArmor armor = (ItemArmor)stack.getItem();
/* 343 */         return armor.getEquipmentSlot();
/*     */       } 
/* 345 */       if (stack.getItem() instanceof net.minecraft.item.ItemElytra)
/*     */       {
/* 347 */         return EntityEquipmentSlot.CHEST;
/*     */       }
/*     */     } 
/*     */     
/* 351 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void swapToHotbar(int InvSlot) {
/* 356 */     if (((Integer)this.slot.getValue()).intValue() == 1) { mc.playerController.windowClick(0, InvSlot, 0, ClickType.SWAP, (EntityPlayer)mc.player); }
/*     */     else
/* 358 */     { mc.playerController.windowClick(0, InvSlot, 0, ClickType.SWAP, (EntityPlayer)mc.player);
/* 359 */       mc.playerController.windowClick(0, ((Integer)this.slot.getValue()).intValue() + 35, 0, ClickType.SWAP, (EntityPlayer)mc.player);
/* 360 */       mc.playerController.windowClick(0, InvSlot, 0, ClickType.SWAP, (EntityPlayer)mc.player); }
/*     */     
/* 362 */     mc.playerController.updateController();
/*     */   }
/*     */   
/*     */   private void swap(int slotFrom, int slotTo) {
/* 366 */     if ((mc.player.inventoryContainer.getSlot(slotTo).getStack()).isEmpty) {
/* 367 */       mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotFrom, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */     } else {
/* 369 */       boolean hasEmpty = false;
/* 370 */       for (int l_I = 0; l_I < 36; l_I++) {
/* 371 */         ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);
/* 372 */         if (l_Stack.isEmpty) {
/* 373 */           hasEmpty = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 377 */       if (hasEmpty) {
/* 378 */         mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotTo, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/* 379 */         mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotFrom, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */       } else {
/* 381 */         mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotFrom, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 382 */         mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotTo, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 383 */         mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slotFrom, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */       } 
/*     */     } 
/* 386 */     mc.playerController.updateController();
/*     */   }
/*     */   
/*     */   private void shiftClickSpot(int source) {
/* 390 */     mc.playerController.windowClick(mc.player.inventoryContainer.windowId, source, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 395 */     if (slot > -1 && slot < 9 && (
/* 396 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 397 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 398 */       else { mc.player.inventory.currentItem = slot; }
/* 399 */        mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
