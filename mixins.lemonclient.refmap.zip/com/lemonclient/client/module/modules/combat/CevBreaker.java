//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "CevBreaker", category = Category.Combat)
/*     */ public class CevBreaker extends Module {
/*     */   public static CevBreaker INSTANCE;
/*     */   ModeSetting page;
/*     */   IntegerSetting delay;
/*     */   BooleanSetting helpBlock;
/*     */   DoubleSetting maxRange;
/*     */   BooleanSetting down;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting strictFacing;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting bypassSwitch;
/*     */   BooleanSetting instantMine;
/*     */   BooleanSetting pickBypass;
/*     */   BooleanSetting strict;
/*     */   BooleanSetting packetCrystal;
/*     */   BooleanSetting crystalBypass;
/*     */   IntegerSetting breakDelay;
/*     */   ModeSetting breakCrystal;
/*     */   BooleanSetting airCheck;
/*     */   BooleanSetting antiWeakness;
/*     */   public boolean working;
/*     */   boolean offhand;
/*     */   boolean start;
/*     */   boolean anyCrystal;
/*     */   int blockSlot;
/*     */   int crystalSlot;
/*     */   int pickSlot;
/*     */   long time;
/*     */   EnumFacing facing;
/*     */   Timing timer;
/*     */   Timing breakTimer;
/*     */   BlockPos[] side;
/*     */   BlockPos placePos;
/*     */   int lastSlot;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> postSendListener;
/*     */   
/*  59 */   public CevBreaker() { this.page = registerMode("Page", Arrays.asList(new String[] { "General", "Place" }, ), "General");
/*     */     
/*  61 */     this.delay = registerInteger("Delay", 50, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  62 */     this.helpBlock = registerBoolean("Help Block", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  63 */     this.maxRange = registerDouble("Max Range", 5.0D, 0.0D, 10.0D, () -> Boolean.valueOf((((Boolean)this.helpBlock.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  64 */     this.down = registerBoolean("Down Block", true, () -> Boolean.valueOf((((Boolean)this.helpBlock.getValue()).booleanValue() && ((String)this.page.getValue()).equals("General"))));
/*  65 */     this.packet = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  66 */     this.rotate = registerBoolean("Rotate", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  67 */     this.strictFacing = registerBoolean("Strict Facing", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  68 */     this.swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  69 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  70 */     this.bypassSwitch = registerBoolean("Bypass Switch", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  71 */     this.instantMine = registerBoolean("Instant Mine", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  72 */     this.pickBypass = registerBoolean("Pick Bypass", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  73 */     this.strict = registerBoolean("Strict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  74 */     this.packetCrystal = registerBoolean("Packet Crystal", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  75 */     this.crystalBypass = registerBoolean("Crystal Bypass", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  76 */     this.breakDelay = registerInteger("Break Delay", 50, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  77 */     this.breakCrystal = registerMode("Break Crystal", Arrays.asList(new String[] { "Vanilla", "Packet" }, ), "Packet", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  78 */     this.airCheck = registerBoolean("Air Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  79 */     this.antiWeakness = registerBoolean("AntiWeakness", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.timer = new Timing();
/*  86 */     this.breakTimer = new Timing();
/*  87 */     this.side = new BlockPos[] { new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     this.postSendListener = new Listener(event -> { if (mc.world == null || mc.player == null) return;  if (event.getPacket() instanceof CPacketHeldItemChange) { int slot = ((CPacketHeldItemChange)event.getPacket()).getSlotId(); if (slot != this.lastSlot) { this.lastSlot = slot; if (((Boolean)this.strict.getValue()).booleanValue()) { EnumFacing facing = BlockUtil.getRayTraceFacing(this.placePos, this.facing); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.placePos, facing)); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, facing)); if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  this.time = System.currentTimeMillis() + calcBreakTime(); }  }  }  }new java.util.function.Predicate[0]); INSTANCE = this; }
/*     */   public void onEnable() { if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.BLOCK || mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getBlock() == Blocks.BEDROCK) { disable(); return; }  this.placePos = mc.objectMouseOver.getBlockPos(); this.start = this.offhand = false; getItem(); doBreak(); this.timer.reset(); }
/*     */   public void fast() { this.working = false; if (mc.world == null || mc.player == null || this.placePos == null || mc.player.isDead) { disable(); return; }  if (!mc.world.isAirBlock(this.placePos.up()) || !mc.world.isAirBlock(this.placePos.up().up())) { disable(); return; }  getItem(); if (!this.anyCrystal || this.blockSlot == -1 || this.pickSlot == -1) { disable(); return; }  if (this.crystalSlot == -1) return;  if (mc.world.isAirBlock(this.placePos.down()) && mc.world.isAirBlock(this.placePos.north()) && mc.world.isAirBlock(this.placePos.west()) && mc.world.isAirBlock(this.placePos.east()) && mc.world.isAirBlock(this.placePos.south())) { helpBlock(this.placePos); return; }  if (AntiRegear.INSTANCE.working || AntiBurrow.INSTANCE.mining) return;  BlockPos instantPos = null; if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos;  if (instantPos != null) { if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ))) return;  if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ)))
/*     */         return;  if (mc.world.getBlockState(instantPos).getBlock() == Blocks.WEB)
/*     */         return;  }  this.working = true; if (!isPos2(instantPos, this.placePos))
/*     */       doBreak();  if (!this.start && mc.world.isAirBlock(this.placePos)) { this.time = System.currentTimeMillis() + (((Boolean)this.instantMine.getValue()).booleanValue() ? 0L : calcBreakTime()); this.start = true; }  Entity crystal = getCrystal(); if (mc.world.getBlockState(this.placePos).getBlock() instanceof net.minecraft.block.BlockAir) { breakCrystalPiston(crystal); this.breakTimer.reset(); }  if (this.time > System.currentTimeMillis())
/*     */       return;  if (this.start && this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) { run(this.blockSlot, ((Boolean)this.bypassSwitch.getValue()).booleanValue(), false, () -> BurrowUtil.placeBlock(this.placePos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue())); run(this.crystalSlot, ((Boolean)this.crystalBypass.getValue()).booleanValue(), true, () -> placeCrystal(this.offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND)); run(this.pickSlot, ((Boolean)this.pickBypass.getValue()).booleanValue(), false, () -> { this.facing = EnumFacing.UP; if (((Boolean)this.strictFacing.getValue()).booleanValue())
/*     */               this.facing = BlockUtil.getRayTraceFacing(this.placePos, this.facing);  mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, this.facing)); if (!((Boolean)this.instantMine.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.placePos, this.facing)); mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.placePos, this.facing)); this.time = System.currentTimeMillis() + calcBreakTime(); }  if (((Boolean)this.swing.getValue()).booleanValue())
/*     */               mc.player.swingArm(EnumHand.MAIN_HAND);  }); if (!((Boolean)this.airCheck.getValue()).booleanValue() || BlockUtil.isAir(this.placePos))
/*     */         breakCrystalPiston(getCrystal());  this.timer.reset(); }  }
/*     */   private void helpBlock(BlockPos pos) { NonNullList<BlockPos> nonNullList = NonNullList.create(); for (BlockPos side : this.side)
/*     */       nonNullList.add(pos.add((Vec3i)side));  if (((Boolean)this.down.getValue()).booleanValue())
/*     */       nonNullList.add(pos.down());  BlockPos finalPos = nonNullList.stream().filter(p -> (mc.player.getDistanceSq(p) <= ((Double)this.maxRange.getValue()).doubleValue() * ((Double)this.maxRange.getValue()).doubleValue())).max(Comparator.comparing(p -> Double.valueOf(mc.player.getDistanceSq(p)))).orElse(null); run(this.blockSlot, ((Boolean)this.bypassSwitch.getValue()).booleanValue(), false, () -> BurrowUtil.placeBlock(finalPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue())); }
/*     */   private void getItem() { this.blockSlot = this.crystalSlot = this.pickSlot = -1; this.anyCrystal = false; if (mc.player.getHeldItemOffhand().getItem() instanceof net.minecraft.item.ItemEndCrystal) { this.crystalSlot = 11; this.offhand = true; }  for (int i = 0; i < 36; i++) { ItemStack stack = mc.player.inventory.getStackInSlot(i); if (stack != ItemStack.EMPTY && stack.getItem() instanceof net.minecraft.item.ItemEndCrystal) { this.anyCrystal = true; if (((Boolean)this.crystalBypass.getValue()).booleanValue() || i < 9)
/*     */           this.crystalSlot = i;  break; }  }  this.blockSlot = BurrowUtil.findHotbarBlock(BlockObsidian.class); this.pickSlot = findItem(); }
/*     */   private void breakCrystalPiston(Entity crystal) { if (crystal == null)
/*     */       return;  if (!this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue()))
/*     */       return;  this.breakTimer.reset(); int newSlot = -1; if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS))
/*     */       for (int i = 0; i < 9; i++) { ItemStack stack = (Wrapper.getPlayer()).inventory.getStackInSlot(i); if (stack != ItemStack.EMPTY) { if (stack.getItem() instanceof net.minecraft.item.ItemSword) { newSlot = i; break; }  if (stack.getItem() instanceof net.minecraft.item.ItemTool)
/* 301 */             newSlot = i;  }  }   run(newSlot, ((Boolean)this.pickBypass.getValue()).booleanValue(), false, () -> { if (((String)this.breakCrystal.getValue()).equalsIgnoreCase("Vanilla")) { CrystalUtil.breakCrystal(crystal, ((Boolean)this.swing.getValue()).booleanValue()); } else if (((String)this.breakCrystal.getValue()).equalsIgnoreCase("Packet")) { CrystalUtil.breakCrystalPacket(crystal, ((Boolean)this.swing.getValue()).booleanValue()); }  }); } private int calcBreakTime() { return getBreakTime() * 70; }
/*     */   private Entity getCrystal() { for (Entity t : mc.world.loadedEntityList) { if (t instanceof net.minecraft.entity.item.EntityEnderCrystal && t.getDistance(this.placePos.x + 0.5D, this.placePos.y + 1.5D, this.placePos.z + 0.5D) < 3.0D) return t;  }  return null; }
/*     */   private void doBreak() { if (this.placePos == null || mc.world.isAirBlock(this.placePos) || mc.world.getBlockState(this.placePos).getBlock() == Blocks.BEDROCK) return;  if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(EnumHand.MAIN_HAND);  mc.playerController.onPlayerDamageBlock(this.placePos, BlockUtil.getRayTraceFacing(this.placePos, EnumFacing.UP)); }
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) { if (pos1 == null || pos2 == null) return false;  return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z); }
/* 305 */   private void placeCrystal(EnumHand hand) { if (((Boolean)this.packetCrystal.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placePos, EnumFacing.UP, hand, 0.0F, 0.0F, 0.0F)); } else { mc.playerController.processRightClickBlock(mc.player, mc.world, this.placePos, EnumFacing.UP, (new Vec3d((Vec3i)this.placePos)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(EnumFacing.UP.getDirectionVec())), hand); }  if (((Boolean)this.swing.getValue()).booleanValue()) mc.player.swingArm(hand);  } private void run(int slot, boolean bypass, boolean update, Runnable runnable) { int oldslot = mc.player.inventory.currentItem; if (slot < 0 || slot == oldslot) { runnable.run(); return; }  if (bypass || slot > 8) { ItemStack itemStack = mc.player.inventory.getStackInSlot(slot); if (slot < 9) slot += 36;  mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, ItemStack.EMPTY, mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); runnable.run(); mc.player.connection.sendPacket((Packet)new CPacketClickWindow(0, slot, mc.player.inventory.currentItem, ClickType.SWAP, update ? itemStack : ItemStack.EMPTY, mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory))); } else { if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); } else { mc.player.inventory.currentItem = slot; }  runnable.run(); if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); } else { mc.player.inventory.currentItem = oldslot; }  }  } private int getBreakTime() { float hardness = 50.0F;
/* 306 */     float breakSpeed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState());
/* 307 */     if (breakSpeed < 0.0F)
/* 308 */       return -1; 
/* 309 */     float relativeDamage = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState()) / hardness / 30.0F;
/* 310 */     return (int)Math.ceil((0.7F / relativeDamage)); }
/*     */ 
/*     */   
/*     */   private int findItem() {
/* 314 */     int result = mc.player.inventory.currentItem;
/* 315 */     double speed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState(), mc.player.getHeldItemMainhand());
/* 316 */     for (int i = 0; i < (((Boolean)this.pickBypass.getValue()).booleanValue() ? 36 : 9); i++) {
/* 317 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 318 */       double stackSpeed = getSpeed(Blocks.OBSIDIAN.getBlockState().getBaseState(), stack);
/* 319 */       if (stackSpeed > speed) {
/* 320 */         speed = stackSpeed;
/* 321 */         result = i;
/*     */       } 
/*     */     } 
/*     */     
/* 325 */     return result;
/*     */   }
/*     */   private double getSpeed(IBlockState state, ItemStack stack) {
/* 328 */     double str = stack.getDestroySpeed(state);
/* 329 */     int effect = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
/* 330 */     return Math.max(str + ((str > 1.0D) ? ((effect * effect) + 1.0D) : 0.0D), 0.0D);
/*     */   }
/*     */   
/*     */   private float getSpeed(IBlockState blockState) {
/* 334 */     ItemStack itemStack = mc.player.inventory.getStackInSlot(this.pickSlot);
/*     */     
/* 336 */     float digSpeed = mc.player.inventory.getStackInSlot(this.pickSlot).getDestroySpeed(blockState); int efficiencyModifier;
/* 337 */     if (!itemStack.isEmpty() && digSpeed > 1.0D && (efficiencyModifier = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, itemStack)) > 0) {
/* 338 */       digSpeed += (float)(StrictMath.pow(efficiencyModifier, 2.0D) + 1.0D);
/*     */     }
/* 340 */     if (mc.player.isPotionActive(MobEffects.HASTE)) {
/* 341 */       digSpeed *= 1.0F + (mc.player.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
/*     */     }
/* 343 */     if (mc.player.isPotionActive(MobEffects.MINING_FATIGUE)) {
/*     */       float fatigueScale;
/* 345 */       switch (mc.player.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
/*     */         case 0:
/* 347 */           fatigueScale = 0.3F;
/*     */           break;
/*     */         
/*     */         case 1:
/* 351 */           fatigueScale = 0.09F;
/*     */           break;
/*     */         
/*     */         case 2:
/* 355 */           fatigueScale = 0.0027F;
/*     */           break;
/*     */         
/*     */         default:
/* 359 */           fatigueScale = 8.1E-4F;
/*     */           break;
/*     */       } 
/* 362 */       digSpeed *= fatigueScale;
/*     */     } 
/* 364 */     if (mc.player.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier((EntityLivingBase)mc.player)) {
/* 365 */       digSpeed /= 5.0F;
/*     */     }
/* 367 */     return digSpeed;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\CevBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
