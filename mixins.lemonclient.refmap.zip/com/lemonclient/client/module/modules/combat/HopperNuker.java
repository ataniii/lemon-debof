//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*    */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "HopperNuker", category = Category.Combat)
/*    */ public class HopperNuker extends Module {
/*    */   BooleanSetting packet;
/*    */   DoubleSetting range;
/*    */   BooleanSetting swing;
/*    */   private final List<BlockPos> selfPlaced;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> listener;
/*    */   
/*    */   public HopperNuker() {
/* 28 */     this.packet = registerBoolean("Packet Break", false);
/* 29 */     this.range = registerDouble("Range", 6.0D, 0.0D, 10.0D);
/* 30 */     this.swing = registerBoolean("Swing", true);
/* 31 */     this.selfPlaced = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     this.listener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) { CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock)event.getPacket(); ItemStack stack = mc.player.inventory.getCurrentItem(); if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) { Block block = ((ItemBlock)stack.getItem()).getBlock(); if (block == Blocks.HOPPER) this.selfPlaced.add(packet.getPos().offset(packet.getDirection()));  }  }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */   
/*    */   public void fast() {
/*    */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*    */       return; 
/*    */     List<BlockPos> sphere = EntityUtil.getSphere(PlayerUtil.getEyesPos(), (Double)this.range.getValue(), (Double)this.range.getValue(), false, false, 0);
/*    */     for (BlockPos pos : sphere) {
/*    */       if (mc.world.getBlockState(pos).getBlock() != Blocks.HOPPER || !(mc.world.getBlockState(pos.up()).getBlock() instanceof net.minecraft.block.BlockShulkerBox) || this.selfPlaced.contains(pos))
/*    */         continue; 
/*    */       if (((Boolean)this.swing.getValue()).booleanValue())
/*    */         mc.player.swingArm(EnumHand.MAIN_HAND); 
/*    */       if (((Boolean)this.packet.getValue()).booleanValue()) {
/*    */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
/*    */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
/*    */         continue;
/*    */       } 
/*    */       mc.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
/*    */     } 
/*    */     this.selfPlaced.removeIf(pos -> (mc.player.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D) > 8.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\HopperNuker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
