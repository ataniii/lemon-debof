//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "CevBlocker", category = Category.Combat)
/*     */ public class CevBlocker extends Module {
/*  26 */   ModeSetting time = registerMode("Time Mode", Arrays.asList(new String[] { "Tick", "onUpdate", "Both", "Fast" }, ), "Tick");
/*  27 */   BooleanSetting high = registerBoolean("High Cev", true);
/*  28 */   BooleanSetting pa = registerBoolean("Ignore Bedrock", true);
/*  29 */   BooleanSetting bevel = registerBoolean("Bevel", true);
/*  30 */   BooleanSetting packet = registerBoolean("Packet Place", true);
/*  31 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  32 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  33 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  34 */   private List<BlockPos> cevPositions = new ArrayList<>();
/*     */   
/*     */   private void switchTo(int slot, Runnable runnable) {
/*  37 */     int oldslot = mc.player.inventory.currentItem;
/*  38 */     if (slot < 0 || slot == oldslot) {
/*  39 */       runnable.run();
/*     */       return;
/*     */     } 
/*  42 */     if (slot < 9) {
/*  43 */       boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue();
/*  44 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*  45 */       else { mc.player.inventory.currentItem = slot; }
/*  46 */        runnable.run();
/*  47 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/*  48 */       else { mc.player.inventory.currentItem = oldslot; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  54 */     if (((String)this.time.getValue()).equals("onUpdate") || ((String)this.time.getValue()).equals("Both")) {
/*  55 */       doBlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onTick() {
/*  60 */     if (((String)this.time.getValue()).equals("Tick") || ((String)this.time.getValue()).equals("Both")) {
/*  61 */       doBlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void fast() {
/*  66 */     if (((String)this.time.getValue()).equals("Fast"))
/*  67 */       doBlock(); 
/*     */   }
/*     */   
/*     */   private void doBlock() {
/*  71 */     if (mc.world == null || mc.player == null) {
/*     */       return;
/*     */     }
/*  74 */     BlockPos[] highpos = { new BlockPos(0, 3, 0), new BlockPos(0, 4, 0), new BlockPos(1, 2, 0), new BlockPos(-1, 2, 0), new BlockPos(0, 2, 1), new BlockPos(0, 2, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     BlockPos[] hight2 = { new BlockPos(1, 2, 1), new BlockPos(1, 2, -1), new BlockPos(-1, 2, 1), new BlockPos(-1, 2, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     BlockPos[] offsets = { new BlockPos(0, 2, 0), new BlockPos(1, 1, 0), new BlockPos(-1, 1, 0), new BlockPos(0, 1, 1), new BlockPos(0, 1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     BlockPos[] offsets2 = { new BlockPos(1, 1, 1), new BlockPos(1, 1, -1), new BlockPos(-1, 1, 1), new BlockPos(-1, 1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     for (BlockPos offset : offsets) {
/* 105 */       check(offset);
/*     */     }
/* 107 */     if (((Boolean)this.high.getValue()).booleanValue()) {
/* 108 */       for (BlockPos offset : highpos) {
/* 109 */         check(offset);
/*     */       }
/*     */     }
/* 112 */     if (((Boolean)this.bevel.getValue()).booleanValue()) {
/* 113 */       for (BlockPos offset : offsets2) {
/* 114 */         check(offset);
/*     */       }
/* 116 */       if (((Boolean)this.high.getValue()).booleanValue()) {
/* 117 */         for (BlockPos offset : hight2) {
/* 118 */           check(offset);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 123 */     Iterator<BlockPos> iterator = this.cevPositions.iterator();
/* 124 */     while (iterator.hasNext()) {
/* 125 */       BlockPos pos = iterator.next();
/* 126 */       if (!Objects.isNull(getCrystal(pos)))
/* 127 */         continue;  int obby = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 128 */       if (obby == -1)
/* 129 */         return;  switchTo(obby, () -> {
/*     */             if (mc.world.isAirBlock(pos)) {
/*     */               BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()); BurrowUtil.placeBlock(pos.up(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */             } else {
/*     */               BurrowUtil.placeBlock(pos.up(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */             } 
/*     */           });
/* 136 */       iterator.remove();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void check(BlockPos offset) {
/* 141 */     BlockPos playerPos = PlayerUtil.getPlayerPos();
/* 142 */     BlockPos offsetPos = playerPos.add((Vec3i)offset);
/* 143 */     Entity crystal = getCrystal(offsetPos);
/* 144 */     if (Objects.isNull(crystal))
/* 145 */       return;  BlockPos crystalPos = EntityUtil.getEntityPos(crystal).down();
/* 146 */     if (((Boolean)this.pa.getValue()).booleanValue() && !mc.world.isAirBlock(crystalPos) && mc.world.getBlockState(crystalPos).getBlock() != Blocks.OBSIDIAN) {
/*     */       return;
/*     */     }
/* 149 */     if (!mc.world.isAirBlock(playerPos.up().up())) {
/* 150 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, playerPos.getY() + 0.2D, mc.player.posZ, false));
/*     */     }
/* 152 */     mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
/* 153 */     mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*     */     
/* 155 */     if (!this.cevPositions.contains(crystalPos)) this.cevPositions.add(crystalPos); 
/*     */   }
/*     */   private Entity getCrystal(BlockPos pos) {
/* 158 */     return mc.world.loadedEntityList.stream()
/* 159 */       .filter(e -> e instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 160 */       .filter(e -> EntityUtil.getEntityPos(e).down().equals(pos))
/* 161 */       .min(Comparator.comparing(this::getDistance)).orElse(null);
/*     */   }
/*     */   
/*     */   public double getDistance(Entity e) {
/* 165 */     return mc.player.getDistance(e);
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 169 */     this.cevPositions = new ArrayList<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\CevBlocker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
