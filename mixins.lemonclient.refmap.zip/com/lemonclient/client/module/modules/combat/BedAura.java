//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*      */ package com.lemonclient.client.module.modules.combat;
/*      */ import com.lemonclient.api.event.events.PacketEvent;
/*      */ import com.lemonclient.api.setting.values.BooleanSetting;
/*      */ import com.lemonclient.api.setting.values.DoubleSetting;
/*      */ import com.lemonclient.api.setting.values.IntegerSetting;
/*      */ import com.lemonclient.api.util.render.GSColor;
/*      */ import com.lemonclient.api.util.render.RenderUtil;
/*      */ import java.util.List;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityLivingBase;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ 
/*      */ @Declaration(name = "BedAura", category = Category.Combat, priority = 999)
/*      */ public class BedAura extends Module {
/*      */   ModeSetting page;
/*      */   BooleanSetting predict;
/*      */   BooleanSetting selfPredict;
/*      */   DoubleSetting resetRotate;
/*      */   BooleanSetting detect;
/*      */   IntegerSetting startTick;
/*      */   IntegerSetting addTick;
/*      */   IntegerSetting tickPredict;
/*      */   BooleanSetting calculateYPredict;
/*      */   IntegerSetting startDecrease;
/*      */   IntegerSetting exponentStartDecrease;
/*      */   IntegerSetting decreaseY;
/*      */   IntegerSetting exponentDecreaseY;
/*      */   BooleanSetting splitXZ;
/*      */   BooleanSetting manualOutHole;
/*      */   BooleanSetting aboveHoleManual;
/*      */   BooleanSetting stairPredict;
/*      */   IntegerSetting nStair;
/*      */   DoubleSetting speedActivationStair;
/*      */   ModeSetting targetMode;
/*      */   DoubleSetting smartHealth;
/*      */   BooleanSetting monster;
/*      */   BooleanSetting neutral;
/*      */   BooleanSetting animal;
/*      */   ModeSetting mode;
/*      */   BooleanSetting debug;
/*      */   BooleanSetting packetPlace;
/*      */   BooleanSetting placeSwing;
/*      */   BooleanSetting breakSwing;
/*      */   BooleanSetting packetSwing;
/*      */   
/*      */   public BedAura() {
/*   51 */     this.page = registerMode("Page", Arrays.asList(new String[] { "Target", "General", "Delay", "Base", "Calc", "SlowFacePlace", "Switch", "Render" }, ), "General");
/*      */     
/*   53 */     this.predict = registerBoolean("Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   54 */     this.selfPredict = registerBoolean("Predict Self", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   55 */     this.resetRotate = registerDouble("Reset Yaw Difference", 15.0D, 0.0D, 180.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   56 */     this.detect = registerBoolean("Detect Ping", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   57 */     this.startTick = registerInteger("Start Tick", 2, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   58 */     this.addTick = registerInteger("Add Tick", 4, 0, 10, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   59 */     this.tickPredict = registerInteger("Max Predict Ticks", 10, 0, 30, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Target") && !((Boolean)this.detect.getValue()).booleanValue())));
/*   60 */     this.calculateYPredict = registerBoolean("Calculate Y Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   61 */     this.startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   62 */     this.exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   63 */     this.decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   64 */     this.exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   65 */     this.splitXZ = registerBoolean("Split XZ", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   66 */     this.manualOutHole = registerBoolean("Manual Out Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   67 */     this.aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> Boolean.valueOf((((Boolean)this.manualOutHole.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   68 */     this.stairPredict = registerBoolean("Stair Predict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*   69 */     this.nStair = registerInteger("N Stair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*   70 */     this.speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*      */     
/*   72 */     this.targetMode = registerMode("Target", Arrays.asList(new String[] { "Nearest", "Damage", "Health", "Smart" }, ), "Nearest", () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   73 */     this.smartHealth = registerDouble("Smart Health", 16.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("General") && ((String)this.targetMode.getValue()).equals("Smart"))));
/*   74 */     this.monster = registerBoolean("Monsters", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   75 */     this.neutral = registerBoolean("Neutrals", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   76 */     this.animal = registerBoolean("Animals", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   77 */     this.mode = registerMode("Mode", Arrays.asList(new String[] { "PlaceBreak", "BreakPlace", "Test" }, ), "PlaceBreak", () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   78 */     this.debug = registerBoolean("Debug", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   79 */     this.packetPlace = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   80 */     this.placeSwing = registerBoolean("Place Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   81 */     this.breakSwing = registerBoolean("Break Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*   82 */     this.packetSwing = registerBoolean("Packet Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*      */     
/*   84 */     this.highVersion = registerBoolean("1.13", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Base")));
/*   85 */     this.placeInAir = registerBoolean("Place In Air", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Base")));
/*   86 */     this.base = registerBoolean("Place Base", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   87 */     this.allPossible = registerBoolean("Calc All Possible", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   88 */     this.detectBreak = registerBoolean("Detect Break", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   89 */     this.packetBase = registerBoolean("Packet Base Place", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   90 */     this.baseSwing = registerBoolean("Base Swing", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   91 */     this.toggleDmg = registerDouble("Toggle Damage", 8.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   92 */     this.baseDelay = registerInteger("Base Delay", 0, 0, 1000, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   93 */     this.baseMinDmg = registerDouble("Base MinDmg", 8.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   94 */     this.maxY = registerDouble("Max Y", 1.0D, 0.0D, 3.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*   95 */     this.maxSpeed = registerDouble("Max Target Speed", 10.0D, 0.0D, 50.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Base") && ((Boolean)this.base.getValue()).booleanValue() && !((Boolean)this.highVersion.getValue()).booleanValue())));
/*      */     
/*   97 */     this.calcDelay = registerInteger("Calc Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*   98 */     this.updateDelay = registerInteger("Update Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*   99 */     this.placeDelay = registerInteger("Place Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*  100 */     this.breakDelay = registerInteger("Break Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*  101 */     this.stuckPlaceDelay = registerInteger("Stuck Place Delay", 0, 0, 1000, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Delay") && ((String)this.mode.getValue()).equals("Test"))));
/*  102 */     this.stuckBreakDelay = registerInteger("Stuck Break Delay", 0, 0, 1000, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Delay") && ((String)this.mode.getValue()).equals("Test"))));
/*      */     
/*  104 */     this.range = registerDouble("Place Range", 5.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  105 */     this.yRange = registerDouble("Y Range", 2.5D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  106 */     this.enemyRange = registerInteger("Enemy Range", 10, 0, 16, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  107 */     this.maxEnemies = registerInteger("Max Calc Enemies", 5, 0, 25, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  108 */     this.handMode = registerMode("Hand", Arrays.asList(new String[] { "Main", "Off", "Auto" }, ), "Auto", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  109 */     this.autorotate = registerBoolean("Auto Rotate", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  110 */     this.pause = registerBoolean("Pause While Burrow", false, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Calc") && ((Boolean)this.autorotate.getValue()).booleanValue())));
/*  111 */     this.pitch = registerBoolean("Pitch Down", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Calc") && ((Boolean)this.autorotate.getValue()).booleanValue())));
/*  112 */     this.minDmg = registerDouble("Min Damage", 8.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  113 */     this.ignore = registerBoolean("Ignore Self Dmg", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  114 */     this.maxSelfDmg = registerDouble("Max Self Dmg", 10.0D, 1.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Calc") && !((Boolean)this.ignore.getValue()).booleanValue())));
/*  115 */     this.suicide = registerBoolean("Anti Suicide", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  116 */     this.balance = registerDouble("Health Balance", 2.5D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  117 */     this.facePlaceValue = registerInteger("FacePlace HP", 8, 0, 36, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  118 */     this.fpMinDmg = registerDouble("FP Min Damage", 1.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  119 */     this.forcePlace = registerBoolean("Force Place", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  120 */     this.autoSwitch = registerBoolean("Auto Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*  121 */     this.update = registerBoolean("Update", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*  122 */     this.silentSwitch = registerBoolean("Switch Back", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Switch") && ((Boolean)this.autoSwitch.getValue()).booleanValue())));
/*  123 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*  124 */     this.refill = registerBoolean("Refill Beds", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*  125 */     this.clickMode = registerMode("Click Mode", Arrays.asList(new String[] { "Quick", "Swap", "Pickup" }, ), "Quick", () -> Boolean.valueOf((((String)this.page.getValue()).equals("Switch") && ((Boolean)this.refill.getValue()).booleanValue())));
/*  126 */     this.refillMode = registerMode("Refill Mode", Arrays.asList(new String[] { "All", "Only" }, ), "All", () -> Boolean.valueOf((((String)this.page.getValue()).equals("Switch") && ((Boolean)this.refill.getValue()).booleanValue())));
/*  127 */     this.slotS = registerInteger("Slot", 1, 1, 9, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Switch") && ((Boolean)this.refill.getValue()).booleanValue())));
/*  128 */     this.force = registerBoolean("Force Refill", false, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Switch") && ((Boolean)this.refill.getValue()).booleanValue())));
/*      */     
/*  130 */     this.slowFP = registerBoolean("Slow Face Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SlowFacePlace")));
/*  131 */     this.slowPlaceDelay = registerInteger("SlowFP Place Delay", 500, 0, 1000, () -> Boolean.valueOf((((Boolean)this.slowFP.getValue()).booleanValue() && ((String)this.page.getValue()).equals("SlowFacePlace"))));
/*  132 */     this.slowBreakDelay = registerInteger("SlowFP Break Delay", 500, 0, 1000, () -> Boolean.valueOf((((Boolean)this.slowFP.getValue()).booleanValue() && ((String)this.page.getValue()).equals("SlowFacePlace"))));
/*  133 */     this.slowMinDmg = registerDouble("SlowFP Min Dmg", 0.05D, 0.0D, 36.0D, () -> Boolean.valueOf((((Boolean)this.slowFP.getValue()).booleanValue() && ((String)this.page.getValue()).equals("SlowFacePlace"))));
/*      */     
/*  135 */     this.showDamage = registerBoolean("Render Dmg", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  136 */     this.showSelfDamage = registerBoolean("Self Dmg", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.showDamage.getValue()).booleanValue())));
/*  137 */     this.color = registerColor("Hand Color", new GSColor(255, 0, 0, 50), () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  138 */     this.color2 = registerColor("Base Color", new GSColor(0, 255, 0, 50), () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  139 */     this.gradient = registerBoolean("Gradient", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  140 */     this.alpha = registerInteger("Alpha", 60, 0, 255, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  141 */     this.outline = registerBoolean("Outline", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  142 */     this.outAlpha = registerInteger("Outline Alpha", 120, 0, 255, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.outline.getValue()).booleanValue())));
/*  143 */     this.width = registerInteger("Width", 1, 1, 10, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.outline.getValue()).booleanValue())));
/*  144 */     this.anime = registerBoolean("Animation", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  145 */     this.movingPlaceSpeed = registerDouble("Moving Speed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.anime.getValue()).booleanValue())));
/*  146 */     this.reset = registerBoolean("Reset", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.anime.getValue()).booleanValue())));
/*  147 */     this.fade = registerBoolean("Fade", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  148 */     this.fadeAlpha = registerInteger("Fade Alpha", 50, 0, 255, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  149 */     this.lifeTime = registerInteger("Fade Time", 3000, 0, 5000, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.fade.getValue()).booleanValue())));
/*  150 */     this.renderTest = registerBoolean("Render Test", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  151 */     this.hudDisplay = registerMode("HUD", Arrays.asList(new String[] { "Target", "Damage", "Both", "None" }, ), "None", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  152 */     this.hudSelfDamage = registerBoolean("Show Self Damage", false, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && (((String)this.hudDisplay.getValue()).equals("Damage") || ((String)this.hudDisplay.getValue()).equals("Both")))));
/*  153 */     this.managerClassRenderBlocks = new managerClassRenderBlocks();
/*  154 */     this.playerSpeed = new HashMap<>();
/*  155 */     this.target = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  160 */     this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  161 */     this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  162 */     this.lastBestPlace = null;
/*  163 */     this.lastBestPos = null;
/*  164 */     this.basetiming = new Timing();
/*  165 */     this.calctiming = new Timing();
/*  166 */     this.placetiming = new Timing();
/*  167 */     this.breaktiming = new Timing();
/*  168 */     this.updatetiming = new Timing();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  173 */     this.sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketHeldItemChange) this.nowSlot = ((CPacketHeldItemChange)event.getPacket()).getSlotId();  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  187 */     this.sendListener = new Listener(event -> { if (this.rotation != null) { if (event.getPacket() instanceof CPacketPlayer.Rotation) { ((CPacketPlayer.Rotation)event.getPacket()).yaw = this.rotation.x; if (((Boolean)this.pitch.getValue()).booleanValue()) ((CPacketPlayer.Rotation)event.getPacket()).pitch = 90.0F;  }  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) { ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = this.rotation.x; if (((Boolean)this.pitch.getValue()).booleanValue()) ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = 90.0F;  }  if (event.getPacket() instanceof net.minecraft.network.play.client.CPacketVehicleMove) ((AccessorCPacketVehicleMove)event.getPacket()).setYaw(this.rotation.x);  }  }new java.util.function.Predicate[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  204 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (this.rotation == null || event.getPhase() != Phase.PRE) return;  PlayerPacket packet = new PlayerPacket(this, new Vec2f(this.rotation.x, ((Boolean)this.pitch.getValue()).booleanValue() ? 90.0F : (PlayerPacketManager.INSTANCE.getServerSideRotation()).y)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*      */   }
/*      */   BooleanSetting highVersion; BooleanSetting placeInAir; BooleanSetting base; BooleanSetting allPossible; BooleanSetting detectBreak; BooleanSetting packetBase; BooleanSetting baseSwing; DoubleSetting toggleDmg; IntegerSetting baseDelay; DoubleSetting baseMinDmg; DoubleSetting maxY; DoubleSetting maxSpeed; IntegerSetting calcDelay; IntegerSetting updateDelay; IntegerSetting placeDelay; IntegerSetting breakDelay; IntegerSetting stuckPlaceDelay; IntegerSetting stuckBreakDelay; DoubleSetting range; DoubleSetting yRange; IntegerSetting enemyRange; IntegerSetting maxEnemies; ModeSetting handMode; BooleanSetting autorotate; BooleanSetting pause; BooleanSetting pitch; DoubleSetting minDmg; BooleanSetting ignore; DoubleSetting maxSelfDmg; BooleanSetting suicide; DoubleSetting balance; IntegerSetting facePlaceValue; DoubleSetting fpMinDmg; BooleanSetting forcePlace; BooleanSetting autoSwitch; BooleanSetting update; BooleanSetting silentSwitch; BooleanSetting packetSwitch; BooleanSetting refill; ModeSetting clickMode; ModeSetting refillMode; IntegerSetting slotS; BooleanSetting force; BooleanSetting slowFP; IntegerSetting slowPlaceDelay; IntegerSetting slowBreakDelay; DoubleSetting slowMinDmg; BooleanSetting showDamage; BooleanSetting showSelfDamage; ColorSetting color; ColorSetting color2; BooleanSetting gradient; IntegerSetting alpha; BooleanSetting outline; IntegerSetting outAlpha; IntegerSetting width; BooleanSetting anime; DoubleSetting movingPlaceSpeed; BooleanSetting reset; BooleanSetting fade; IntegerSetting fadeAlpha; IntegerSetting lifeTime; BooleanSetting renderTest; ModeSetting hudDisplay; BooleanSetting hudSelfDamage; managerClassRenderBlocks managerClassRenderBlocks; HashMap<EntityPlayer, MoveRotation> playerSpeed; EntityInfo target; BlockPos headPos; BlockPos basePos; boolean canBasePlace; boolean burrow; float damage; float selfDamage; String face; Vec3d movingPlaceNow; Vec3d movingPosNow; BlockPos lastBestPlace; BlockPos lastBestPos; Timing basetiming; Timing calctiming; Timing placetiming; Timing breaktiming; Timing updatetiming; EnumHand hand; int slot; int maxPredict; Vec2f rotation; BlockPos[] sides; int nowSlot; @EventHandler
/*      */   private final Listener<PacketEvent.Send> postSendListener; @EventHandler
/*      */   private final Listener<PacketEvent.Send> sendListener; @EventHandler
/*      */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*      */   
/*      */   public void onUpdate() {
/*  212 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether()) {
/*  213 */       this.target = null;
/*  214 */       this.headPos = this.basePos = null;
/*  215 */       this.damage = this.selfDamage = 0.0F;
/*  216 */       this.rotation = null;
/*      */       
/*      */       return;
/*      */     } 
/*  220 */     for (EntityPlayer player : mc.world.playerEntities) {
/*  221 */       if (mc.player.getDistanceSq((Entity)player) > (((Integer)this.enemyRange.getValue()).intValue() * ((Integer)this.enemyRange.getValue()).intValue()))
/*  222 */         continue;  double lastYaw = 512.0D;
/*  223 */       int tick = ((Integer)this.startTick.getValue()).intValue();
/*  224 */       if (this.playerSpeed.get(player) != null) {
/*  225 */         MoveRotation info = this.playerSpeed.get(player);
/*  226 */         lastYaw = info.yaw;
/*  227 */         tick = info.tick + ((Integer)this.addTick.getValue()).intValue();
/*      */       } 
/*  229 */       if (tick > this.maxPredict) tick = this.maxPredict; 
/*  230 */       this.playerSpeed.put(player, new MoveRotation(player, lastYaw, tick));
/*      */     } 
/*      */     
/*  233 */     calc();
/*      */   }
/*      */ 
/*      */   
/*      */   public void fast() {
/*  238 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether()) {
/*      */       return;
/*      */     }
/*  241 */     if (this.updatetiming.passedMs(((Integer)this.updateDelay.getValue()).intValue())) {
/*  242 */       this.updatetiming.reset();
/*  243 */       if (((Boolean)this.pause.getValue()).booleanValue())
/*  244 */       { BlockPos pos = PlayerUtil.getPlayerFloorPos();
/*  245 */         this.burrow = (isBurrow(pos) && !isBurrow(pos.up())); }
/*  246 */       else { this.burrow = false; }
/*  247 */        this.maxPredict = ((Boolean)this.detect.getValue()).booleanValue() ? (int)((mc.getCurrentServerData() == null) ? 0L : ((mc.getCurrentServerData()).pingToServer * 2L / 50L)) : ((Integer)this.tickPredict.getValue()).intValue();
/*  248 */       this.managerClassRenderBlocks.update(((Integer)this.lifeTime.getValue()).intValue());
/*  249 */       if (((Boolean)this.base.getValue()).booleanValue() && this.basetiming.passedMs(((Integer)this.baseDelay.getValue()).intValue())) {
/*  250 */         this.canBasePlace = true;
/*  251 */         this.basetiming.reset();
/*      */       } 
/*      */     } 
/*      */     
/*  255 */     bedaura();
/*      */   }
/*      */   
/*      */   private boolean isBurrow(BlockPos pos) {
/*  259 */     if (!mc.player.boundingBox.intersects(mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos))) return false; 
/*  260 */     Block block = BlockUtil.getBlock(pos);
/*  261 */     return (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK || block == Blocks.ENDER_CHEST);
/*      */   }
/*      */   
/*      */   private void bedaura() {
/*  265 */     if (((Boolean)this.renderTest.getValue()).booleanValue() || this.headPos == null || this.basePos == null)
/*  266 */       return;  if (isBed(this.headPos) || isBed(this.basePos)) breakBed(false);
/*      */     
/*  268 */     if (((String)this.mode.getValue()).equals("PlaceBreak") || this.target.defaultPlayer == null) {
/*  269 */       place(false);
/*  270 */       breakBed(false);
/*  271 */     } else if (((String)this.mode.getValue()).equals("BreakPlace")) {
/*  272 */       breakBed(false);
/*  273 */       place(false);
/*      */     }
/*  275 */     else if (stuck(this.target)) {
/*  276 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendDeleteMessage("true", "ba", 1); 
/*  277 */       breakBed(true);
/*  278 */       place(true);
/*      */     } else {
/*  280 */       if (((Boolean)this.debug.getValue()).booleanValue()) MessageBus.sendDeleteMessage("false", "ba", 1); 
/*  281 */       place(false);
/*  282 */       breakBed(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void calc() {
/*  288 */     if (this.calctiming.passedMs(((Integer)this.calcDelay.getValue()).intValue())) {
/*  289 */       this.calctiming.reset();
/*      */       
/*  291 */       this.target = null;
/*  292 */       this.headPos = this.basePos = null;
/*  293 */       this.damage = this.selfDamage = 0.0F;
/*  294 */       this.rotation = null;
/*      */       
/*  296 */       boolean offhand = (!((String)this.handMode.getValue()).equals("Main") && mc.player.getHeldItemOffhand().getItem() == Items.BED);
/*  297 */       if (!offhand && !((String)this.handMode.getValue()).equals("Off")) {
/*  298 */         if (((Boolean)this.refill.getValue()).booleanValue()) refill_bed(); 
/*  299 */         this.slot = BurrowUtil.findHotbarBlock(ItemBed.class);
/*  300 */         if (this.slot == -1)
/*      */           return; 
/*  302 */       }  this.hand = offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
/*      */       
/*  304 */       EntityInfo self = new EntityInfo((EntityPlayer)mc.player, ((Boolean)this.selfPredict.getValue()).booleanValue());
/*  305 */       PlaceInfo placeInfo = getPlaceInfo(self, findBlocksExcluding((((Boolean)this.highVersion.getValue()).booleanValue() || (((Boolean)this.base.getValue()).booleanValue() && this.canBasePlace))));
/*      */       
/*  307 */       if (placeInfo == null) {
/*  308 */         List<Entity> entityList = new ArrayList<>();
/*  309 */         for (Entity entity1 : mc.world.loadedEntityList) {
/*  310 */           if (mc.player.getDistance(entity1) > ((Integer)this.enemyRange.getValue()).intValue() || EntityUtil.isDead(entity1))
/*      */             continue; 
/*  312 */           if (((Boolean)this.monster.getValue()).booleanValue() && EntityUtil.isMobAggressive(entity1))
/*  313 */             entityList.add(entity1); 
/*  314 */           if (((Boolean)this.neutral.getValue()).booleanValue() && EntityUtil.isNeutralMob(entity1))
/*  315 */             entityList.add(entity1); 
/*  316 */           if (((Boolean)this.animal.getValue()).booleanValue() && EntityUtil.isPassive(entity1))
/*  317 */             entityList.add(entity1); 
/*      */         } 
/*  319 */         EntityInfo entity = getNearestEntity(entityList);
/*  320 */         if (entity == null) {
/*  321 */           if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  322 */             this.lastBestPlace = null;
/*  323 */             this.lastBestPos = null;
/*  324 */             this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  325 */             this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*      */           } 
/*      */           return;
/*      */         } 
/*  329 */         placeInfo = calculatePlacement(entity, self, findBlocksExcluding(((Boolean)this.highVersion.getValue()).booleanValue()));
/*  330 */         this.target = placeInfo.target;
/*      */       } else {
/*  332 */         this.target = placeInfo.target;
/*  333 */         if (ModuleManager.isModuleEnabled("AutoEz"))
/*  334 */           AutoEz.INSTANCE.addTargetedPlayer(this.target.defaultPlayer.getName()); 
/*  335 */         if (((Boolean)this.base.getValue()).booleanValue() && placeInfo.basePos != null) {
/*  336 */           this.canBasePlace = false;
/*  337 */           int obbySlot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  338 */           int oldSlot = mc.player.inventory.currentItem;
/*  339 */           boolean same = (obbySlot == oldSlot);
/*  340 */           if (!same)
/*  341 */           { switchTo(obbySlot);
/*  342 */             BurrowUtil.placeBlock(placeInfo.basePos, EnumHand.MAIN_HAND, false, ((Boolean)this.packetBase.getValue()).booleanValue(), false, ((Boolean)this.baseSwing.getValue()).booleanValue());
/*  343 */             switchTo(oldSlot); }
/*  344 */           else { BurrowUtil.placeBlock(placeInfo.basePos, EnumHand.MAIN_HAND, false, ((Boolean)this.packetBase.getValue()).booleanValue(), false, ((Boolean)this.baseSwing.getValue()).booleanValue()); }
/*      */         
/*      */         } 
/*      */       } 
/*  348 */       BlockPos bedPos = placeInfo.placePos;
/*  349 */       if (bedPos == null)
/*      */         return; 
/*  351 */       this.damage = placeInfo.damage;
/*  352 */       this.selfDamage = placeInfo.selfDamage;
/*      */       
/*  354 */       this.headPos = bedPos;
/*      */       
/*  356 */       switch (RotationUtil.getFacing((PlayerPacketManager.INSTANCE.getServerSideRotation()).x)) {
/*      */         case SOUTH:
/*  358 */           this.face = "SOUTH";
/*  359 */           this.rotation = new Vec2f(0.0F, 90.0F);
/*  360 */           bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z - 1);
/*      */           break;
/*      */         
/*      */         case WEST:
/*  364 */           this.face = "WEST";
/*  365 */           this.rotation = new Vec2f(90.0F, 90.0F);
/*  366 */           bedPos = new BlockPos(this.headPos.x + 1, this.headPos.y, this.headPos.z);
/*      */           break;
/*      */         
/*      */         case NORTH:
/*  370 */           this.face = "NORTH";
/*  371 */           this.rotation = new Vec2f(180.0F, 90.0F);
/*  372 */           bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z + 1);
/*      */           break;
/*      */         
/*      */         case EAST:
/*  376 */           this.face = "EAST";
/*  377 */           this.rotation = new Vec2f(-90.0F, 90.0F);
/*  378 */           bedPos = new BlockPos(this.headPos.x - 1, this.headPos.y, this.headPos.z);
/*      */           break;
/*      */       } 
/*      */       
/*  382 */       if (!block(bedPos, true, true)) {
/*  383 */         if (((Boolean)this.autorotate.getValue()).booleanValue() && !this.burrow) {
/*  384 */           if (block(this.headPos.east(), true, true)) {
/*  385 */             this.face = "WEST";
/*  386 */             this.rotation = new Vec2f(90.0F, 90.0F);
/*  387 */             bedPos = new BlockPos(this.headPos.x + 1, this.headPos.y, this.headPos.z);
/*  388 */           } else if (block(this.headPos.north(), true, true)) {
/*  389 */             this.face = "SOUTH";
/*  390 */             this.rotation = new Vec2f(0.0F, 90.0F);
/*  391 */             bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z - 1);
/*  392 */           } else if (block(this.headPos.west(), true, true)) {
/*  393 */             this.face = "EAST";
/*  394 */             this.rotation = new Vec2f(-90.0F, 90.0F);
/*  395 */             bedPos = new BlockPos(this.headPos.x - 1, this.headPos.y, this.headPos.z);
/*  396 */           } else if (block(this.headPos.south(), true, true)) {
/*  397 */             this.face = "NORTH";
/*  398 */             this.rotation = new Vec2f(180.0F, 90.0F);
/*  399 */             bedPos = new BlockPos(this.headPos.x, this.headPos.y, this.headPos.z + 1);
/*      */           } else {
/*  401 */             this.target = null;
/*  402 */             this.headPos = this.basePos = null;
/*  403 */             this.damage = this.selfDamage = 0.0F;
/*  404 */             this.rotation = null;
/*      */             return;
/*      */           } 
/*      */         } else {
/*  408 */           this.target = null;
/*  409 */           this.headPos = this.basePos = null;
/*  410 */           this.damage = this.selfDamage = 0.0F;
/*  411 */           this.rotation = null;
/*      */           return;
/*      */         } 
/*      */       }
/*  415 */       this.headPos = this.headPos.up();
/*  416 */       this.basePos = bedPos.up();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void place(boolean stuck) {
/*  421 */     if (this.placetiming.passedMs(getPlaceDelay(stuck))) {
/*  422 */       BlockPos neighbour = this.basePos.down();
/*  423 */       EnumFacing opposite = EnumFacing.DOWN.getOpposite();
/*      */       
/*  425 */       Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*  426 */       if (BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) && !ColorMain.INSTANCE.sneaking)
/*  427 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING)); 
/*  428 */       run(() -> { if (((Boolean)this.packetPlace.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(neighbour, EnumFacing.UP, this.hand, 0.5F, 1.0F, 0.5F)); } else { mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, EnumFacing.UP, hitVec, this.hand); }  }this.slot);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  433 */       if (((Boolean)this.placeSwing.getValue()).booleanValue()) swing(this.hand); 
/*  434 */       this.placetiming.reset();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void run(Runnable runnable, int slot) {
/*  439 */     if (this.hand == EnumHand.OFF_HAND) {
/*  440 */       runnable.run();
/*      */       
/*      */       return;
/*      */     } 
/*  444 */     if (slot != this.nowSlot)
/*  445 */     { if (((Boolean)this.autoSwitch.getValue()).booleanValue()) {
/*  446 */         int oldSlot = mc.player.inventory.currentItem;
/*  447 */         switchTo(slot);
/*  448 */         runnable.run();
/*  449 */         if (((Boolean)this.silentSwitch.getValue()).booleanValue()) switchTo(oldSlot); 
/*      */       }  }
/*  451 */     else { runnable.run(); }
/*      */   
/*      */   }
/*      */   
/*  455 */   private void breakBed(boolean stuck) { if (this.breaktiming.passedMs(getBreakDelay(stuck))) {
/*  456 */       EnumFacing side = EnumFacing.UP;
/*  457 */       Vec3d facing = getHitVecOffset(side);
/*  458 */       if (((ColorMain)ModuleManager.getModule(ColorMain.class)).sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/*  459 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.basePos, side, this.hand, (float)facing.x, (float)facing.y, (float)facing.z));
/*  460 */       if (isBed(this.headPos) && !isBed(this.basePos)) mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.headPos, side, this.hand, (float)facing.x, (float)facing.y, (float)facing.z)); 
/*  461 */       if (((Boolean)this.breakSwing.getValue()).booleanValue()) swing(this.hand); 
/*  462 */       this.breaktiming.reset();
/*      */     }  } private PlaceInfo getPlaceInfo(EntityInfo self, List<BlockPos> posList) { EntityPlayer entityPlayer; PlaceInfo best; List<EntityPlayer> players;
/*      */     EntityPlayer target, player;
/*      */     PlaceInfo placeInfo1;
/*      */     double health;
/*  467 */     PlaceInfo placeInfo = null;
/*  468 */     List<EntityPlayer> playerList = PlayerUtil.getNearPlayers(((Integer)this.enemyRange.getValue()).intValue(), ((Integer)this.maxEnemies.getValue()).intValue());
/*  469 */     switch ((String)this.targetMode.getValue()) {
/*      */       case "Nearest":
/*  471 */         entityPlayer = playerList.stream().min(Comparator.comparing(p -> Float.valueOf(mc.player.getDistance((Entity)p)))).orElse(null);
/*  472 */         if (entityPlayer != null) {
/*  473 */           EntityInfo entityInfo = new EntityInfo(entityPlayer, ((Boolean)this.predict.getValue()).booleanValue());
/*  474 */           placeInfo = calculateBestPlacement(entityInfo, self, posList);
/*      */         } 
/*      */         break;
/*      */       
/*      */       case "Damage":
/*  479 */         best = null;
/*  480 */         for (EntityPlayer entityPlayer1 : playerList) {
/*  481 */           if (entityPlayer1 != null) {
/*  482 */             EntityInfo entityInfo = new EntityInfo(entityPlayer1, ((Boolean)this.predict.getValue()).booleanValue());
/*  483 */             PlaceInfo info = calculateBestPlacement(entityInfo, self, posList);
/*  484 */             if (best == null || info.damage > best.damage) {
/*  485 */               best = info;
/*      */             }
/*      */           } 
/*      */         } 
/*  489 */         placeInfo = best;
/*      */         break;
/*      */       
/*      */       case "Health":
/*  493 */         health = 37.0D;
/*  494 */         player = null;
/*  495 */         for (EntityPlayer entityPlayer1 : playerList) {
/*  496 */           if (player == null || health > (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount())) {
/*  497 */             player = entityPlayer1;
/*  498 */             health = (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount());
/*      */           } 
/*      */         } 
/*  501 */         if (player != null) {
/*  502 */           placeInfo = calculateBestPlacement(new EntityInfo(player, ((Boolean)this.predict.getValue()).booleanValue()), self, posList);
/*      */         }
/*      */         break;
/*      */       
/*      */       case "Smart":
/*  507 */         players = new ArrayList<>();
/*  508 */         for (EntityPlayer entityPlayer1 : playerList) {
/*  509 */           if (((Double)this.smartHealth.getValue()).doubleValue() >= (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount())) {
/*  510 */             players.add(entityPlayer1);
/*      */           }
/*      */         } 
/*  513 */         target = players.stream().min(Comparator.comparing(p -> Float.valueOf(p.getHealth() + p.getAbsorptionAmount()))).orElse(null);
/*  514 */         placeInfo1 = null;
/*  515 */         if (target != null) {
/*  516 */           EntityInfo entityInfo = new EntityInfo(target, ((Boolean)this.predict.getValue()).booleanValue());
/*  517 */           placeInfo1 = calculateBestPlacement(entityInfo, self, posList);
/*      */         } 
/*  519 */         if (placeInfo1 == null) {
/*  520 */           for (EntityPlayer entityPlayer1 : playerList) {
/*  521 */             if (entityPlayer1 != null) {
/*  522 */               EntityInfo entityInfo = new EntityInfo(entityPlayer1, ((Boolean)this.predict.getValue()).booleanValue());
/*  523 */               PlaceInfo info = calculateBestPlacement(entityInfo, self, posList);
/*  524 */               if (placeInfo1 == null || info.damage > placeInfo1.damage) {
/*  525 */                 placeInfo1 = info;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         }
/*  530 */         placeInfo = placeInfo1;
/*      */         break;
/*      */     } 
/*      */     
/*  534 */     return placeInfo; }
/*      */ 
/*      */   
/*      */   private List<BlockPos> findBlocksExcluding(boolean calcWithOutBase) {
/*  538 */     return (List<BlockPos>)EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), (Double)this.yRange.getValue(), false, false, 0).stream().filter(pos -> canPlaceBed(pos, !calcWithOutBase)).collect(Collectors.toList());
/*      */   }
/*      */   
/*      */   private PlaceInfo calculateBestPlacement(EntityInfo target, EntityInfo self, List<BlockPos> blocks) {
/*  542 */     PlaceInfo best = new PlaceInfo(target, null, (float)Math.min(Math.min(((Double)this.minDmg.getValue()).doubleValue(), ((Double)this.slowMinDmg.getValue()).doubleValue()), this.fpMinDmg.getMin()), -1.0F, null);
/*  543 */     if (target == null || self == null) return best; 
/*  544 */     for (BlockPos pos : blocks) {
/*  545 */       BlockPos basePos = null;
/*  546 */       boolean air = BlockUtil.canReplace(pos);
/*  547 */       boolean canPlace = (((Boolean)this.highVersion.getValue()).booleanValue() || (!air && !needBase(pos)));
/*  548 */       if (!canPlace) {
/*  549 */         if (!((Boolean)this.base.getValue()).booleanValue() || (
/*  550 */           best.damage >= ((Double)this.toggleDmg.getValue()).doubleValue() && best.basePos == null) || (
/*  551 */           pos.getY() + 1) > target.player.posY + ((Double)this.maxY.getValue()).doubleValue() || 
/*  552 */           BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1 || 
/*  553 */           LemonClient.speedUtil.getPlayerSpeed(target.defaultPlayer) > ((Double)this.maxSpeed.getValue()).doubleValue())
/*  554 */           continue;  basePos = getBestBasePos(pos);
/*  555 */         if (basePos == null)
/*      */           continue; 
/*  557 */       }  double x = pos.getX() + 0.5D;
/*  558 */       double y = pos.getY() + 1.5625D;
/*  559 */       double z = pos.getZ() + 0.5D;
/*  560 */       float targetDamage = DamageUtil.calculateDamage((EntityLivingBase)target.player, x, y, z, 5.0F, "Bed");
/*  561 */       if (targetDamage <= best.damage || (
/*  562 */         targetDamage < ((Double)this.baseMinDmg.getValue()).doubleValue() && !canPlace) || (
/*  563 */         (target.hp > ((Integer)this.facePlaceValue.getValue()).intValue()) ? (
/*  564 */         targetDamage < ((Double)this.minDmg.getValue()).doubleValue() && (targetDamage < ((Double)this.slowMinDmg.getValue()).doubleValue() || !((Boolean)this.slowFP.getValue()).booleanValue())) : (
/*  565 */         targetDamage < ((Double)this.fpMinDmg.getValue()).doubleValue())))
/*  566 */         continue;  float selfDamage = 0.0F;
/*  567 */       if (!self.player.isCreative()) {
/*  568 */         selfDamage = DamageUtil.calculateDamage((EntityLivingBase)self.player, x, y, z, 5.0F, "Bed");
/*  569 */         if (selfDamage + ((Double)this.balance.getValue()).doubleValue() > ((Double)this.maxSelfDmg.getValue()).doubleValue() && (
/*  570 */           (targetDamage >= target.hp) ? 
/*  571 */           !((Boolean)this.forcePlace.getValue()).booleanValue() : 
/*  572 */           !((Boolean)this.ignore.getValue()).booleanValue()))
/*      */           continue; 
/*  574 */         if (((Boolean)this.suicide.getValue()).booleanValue() && selfDamage + ((Double)this.balance.getValue()).doubleValue() >= self.hp)
/*      */           continue; 
/*  576 */       }  best = new PlaceInfo(target, pos, targetDamage, selfDamage, basePos);
/*      */     } 
/*      */     
/*  579 */     return best;
/*      */   }
/*      */   
/*      */   private PlaceInfo calculatePlacement(EntityInfo target, EntityInfo self, List<BlockPos> poslist) {
/*  583 */     PlaceInfo best = new PlaceInfo(target, null, (float)Math.min(Math.min(((Double)this.minDmg.getValue()).doubleValue(), ((Double)this.slowMinDmg.getValue()).doubleValue()), this.fpMinDmg.getMin()), -1.0F, null);
/*  584 */     if (target == null || self == null) return best; 
/*  585 */     for (BlockPos pos : poslist) {
/*  586 */       double x = pos.getX() + 0.5D;
/*  587 */       double y = pos.getY() + 1.5625D;
/*  588 */       double z = pos.getZ() + 0.5D;
/*  589 */       float targetDamage = DamageUtil.calculateDamage(target.entity, x, y, z, 5.0F, "Bed");
/*  590 */       float selfDamage = DamageUtil.calculateDamage((EntityLivingBase)self.player, x, y, z, 5.0F, "Bed");
/*  591 */       if (targetDamage < ((Double)this.minDmg.getValue()).doubleValue() && (targetDamage < ((Double)this.slowMinDmg.getValue()).doubleValue() || !((Boolean)this.slowFP.getValue()).booleanValue()) && targetDamage < ((Double)this.fpMinDmg.getValue()).doubleValue())
/*      */         continue; 
/*  593 */       if (!self.player.isCreative()) {
/*  594 */         if (selfDamage + ((Double)this.balance.getValue()).doubleValue() > ((Double)this.maxSelfDmg.getValue()).doubleValue() && !((Boolean)this.ignore.getValue()).booleanValue())
/*      */           continue; 
/*  596 */         if (((Boolean)this.suicide.getValue()).booleanValue() && selfDamage + ((Double)this.balance.getValue()).doubleValue() >= self.hp)
/*      */           continue; 
/*      */       } 
/*  599 */       if (targetDamage > best.damage) {
/*  600 */         best = new PlaceInfo(target, pos, targetDamage, selfDamage, null);
/*      */       }
/*      */     } 
/*      */     
/*  604 */     return best;
/*      */   }
/*      */   
/*      */   private boolean near(EntityInfo player) {
/*  608 */     boolean below = ((int)(player.defaultPlayer.posY + 0.5D) + 2 > this.headPos.y);
/*      */ 
/*      */     
/*  611 */     boolean near = ((player.defaultPlayer.getDistance(this.headPos.getX() + 0.5D, this.headPos.getY() + 0.25D, this.headPos.getZ() + 0.5D) < 2.5D || player.defaultPlayer.getDistance(this.basePos.getX() + 0.5D, this.basePos.getY() + 0.25D, this.basePos.getZ() + 0.5D) < 2.5D) && player.defaultPlayer.getDistance((Entity)mc.player) <= 7.5D);
/*      */     
/*  613 */     boolean predictBelow = (player.player.posY + 1.0D > this.headPos.y);
/*      */ 
/*      */     
/*  616 */     boolean predictNear = ((player.player.getDistance(this.headPos.getX() + 0.5D, this.headPos.getY() + 0.25D, this.headPos.getZ() + 0.5D) < 2.5D || player.player.getDistance(this.basePos.getX() + 0.5D, this.basePos.getY() + 0.25D, this.basePos.getZ() + 0.5D) < 2.5D) && player.player.getDistance((Entity)mc.player) <= 7.5D);
/*  617 */     return ((below && near) || (predictBelow && predictNear));
/*      */   }
/*      */   
/*      */   private boolean stuck(EntityPlayer player) {
/*  621 */     double distTraveledLastTickX = player.posX - player.prevPosX;
/*  622 */     double distTraveledLastTickZ = player.posZ - player.prevPosZ;
/*  623 */     double playerSpeed = distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ;
/*  624 */     return (player.posY - (int)player.posY > 0.3D || player.fallDistance > 0.4D || playerSpeed > 3.0D);
/*      */   }
/*      */   
/*      */   private boolean stuck(EntityInfo target) {
/*  628 */     EntityPlayer player = target.defaultPlayer;
/*  629 */     EntityPlayer predict = target.player;
/*  630 */     boolean inAir = false;
/*  631 */     for (Vec3d vec3d : new Vec3d[] { new Vec3d(0.25D, 0.0D, 0.25D), new Vec3d(0.25D, 0.0D, -0.25D), new Vec3d(-0.25D, 0.0D, 0.25D), new Vec3d(-0.25D, 0.0D, -0.25D) }) {
/*  632 */       BlockPos pos = new BlockPos(player.posX + vec3d.x, player.posY + 0.7D, player.posZ + vec3d.z);
/*  633 */       pos = pos.down();
/*  634 */       if (BlockUtil.canReplace(pos) || BlockUtil.getBlock(pos) == Blocks.BED) {
/*  635 */         inAir = true;
/*      */         break;
/*      */       } 
/*      */     } 
/*  639 */     double y = predict.posY - player.posY;
/*  640 */     return (near(target) && (stuck(player) || stuck(predict) || inAir || y > 0.3D || y < -0.3D));
/*      */   }
/*      */   
/*      */   private int getPlaceDelay(boolean stuck) {
/*  644 */     if (this.damage >= ((Double)this.minDmg.getValue()).doubleValue()) {
/*  645 */       if (stuck) return ((Integer)this.stuckPlaceDelay.getValue()).intValue(); 
/*  646 */       return ((Integer)this.placeDelay.getValue()).intValue();
/*      */     } 
/*  648 */     return ((Integer)this.slowPlaceDelay.getValue()).intValue();
/*      */   }
/*      */   
/*      */   private int getBreakDelay(boolean stuck) {
/*  652 */     if (this.damage >= ((Double)this.minDmg.getValue()).doubleValue()) {
/*  653 */       if (stuck) return ((Integer)this.stuckBreakDelay.getValue()).intValue(); 
/*  654 */       return ((Integer)this.breakDelay.getValue()).intValue();
/*      */     } 
/*  656 */     return ((Integer)this.slowBreakDelay.getValue()).intValue();
/*      */   }
/*      */   
/*      */   private EntityInfo getNearestEntity(List<Entity> list) {
/*  660 */     Entity entity = list.stream().filter(target -> target instanceof EntityLivingBase).min(Comparator.comparing(p -> Float.valueOf(mc.player.getDistance(p)))).orElse(null);
/*  661 */     return (entity == null) ? null : new EntityInfo((EntityLivingBase)entity);
/*      */   }
/*      */   
/*      */   private boolean canPlaceBed(BlockPos blockPos, boolean baseCheck) {
/*  665 */     if (!block(blockPos, (!((Boolean)this.highVersion.getValue()).booleanValue() || !((Boolean)this.allPossible.getValue()).booleanValue() || baseCheck), false)) return false; 
/*  666 */     if (((Boolean)this.autorotate.getValue()).booleanValue() && !this.burrow) {
/*  667 */       for (EnumFacing facing : EnumFacing.VALUES) {
/*  668 */         if (facing != EnumFacing.UP && facing != EnumFacing.DOWN) {
/*  669 */           BlockPos blockPos1 = blockPos.offset(facing);
/*  670 */           if (block(blockPos1, ((((Boolean)this.highVersion.getValue()).booleanValue() && !((Boolean)this.placeInAir.getValue()).booleanValue()) || baseCheck), true)) return true; 
/*      */         } 
/*  672 */       }  return false;
/*      */     } 
/*  674 */     BlockPos pos = blockPos.offset(mc.player.getHorizontalFacing(), -1);
/*  675 */     return (block(pos, ((((Boolean)this.highVersion.getValue()).booleanValue() && !((Boolean)this.placeInAir.getValue()).booleanValue()) || baseCheck), true) && inRange(pos.up()));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean canPlaceBase(BlockPos pos) {
/*  680 */     if (((Boolean)this.detectBreak.getValue()).booleanValue() && ColorMain.INSTANCE.breakList.contains(pos)) return false; 
/*  681 */     if (!inRange(pos)) return false; 
/*  682 */     if (BurrowUtil.getBedFacing(pos) == null) return false; 
/*  683 */     return (space(pos.up()) && !intersectsWithEntity(pos));
/*      */   }
/*      */   
/*      */   private boolean needBase(BlockPos pos) {
/*  687 */     for (BlockPos side : this.sides) {
/*  688 */       BlockPos blockPos = pos.add((Vec3i)side);
/*  689 */       if (space(blockPos.up()) && 
/*  690 */         !BlockUtil.canReplace(blockPos) && solid(pos)) return false; 
/*      */     } 
/*  692 */     return true;
/*      */   }
/*      */   
/*      */   private BlockPos getBestBasePos(BlockPos pos) {
/*  696 */     if (BlockUtil.canReplace(pos)) {
/*  697 */       if (!inRange(pos)) return null; 
/*  698 */       return pos;
/*      */     } 
/*      */     
/*  701 */     BlockPos bestPos = null;
/*  702 */     double bestRange = 1000.0D;
/*  703 */     if (!((Boolean)this.autorotate.getValue()).booleanValue() || this.burrow) {
/*  704 */       BlockPos base = pos.offset(mc.player.getHorizontalFacing());
/*  705 */       if (canPlaceBase(base)) return base; 
/*      */     } else {
/*  707 */       for (BlockPos side : this.sides) {
/*  708 */         BlockPos base = pos.add((Vec3i)side);
/*  709 */         if (canPlaceBase(base) && (
/*  710 */           bestPos == null || bestRange > mc.player.getDistanceSq(base))) {
/*  711 */           bestRange = mc.player.getDistanceSq(base);
/*  712 */           bestPos = base;
/*      */         } 
/*      */       } 
/*  715 */       return bestPos;
/*      */     } 
/*  717 */     return null;
/*      */   }
/*      */   
/*      */   private boolean intersectsWithEntity(BlockPos pos) {
/*  721 */     for (Entity entity : mc.world.loadedEntityList) {
/*  722 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/*  723 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true; 
/*      */     } 
/*  725 */     return false;
/*      */   }
/*      */   
/*      */   private boolean block(BlockPos pos, boolean baseCheck, boolean rangeCheck) {
/*  729 */     if (!space(pos.up())) return false; 
/*  730 */     if (BlockUtil.canReplace(pos))
/*  731 */     { if (baseCheck || !canPlaceBase(pos)) return false;  }
/*  732 */     else if (!((Boolean)this.highVersion.getValue()).booleanValue() && !solid(pos)) { return false; }
/*  733 */      return (!rangeCheck || inRange(pos.up()));
/*      */   }
/*      */   
/*      */   private boolean isBed(BlockPos pos) {
/*  737 */     Block block = mc.world.getBlockState(pos).getBlock();
/*  738 */     return (block == Blocks.BED || block instanceof net.minecraft.block.BlockBed);
/*      */   }
/*      */   
/*      */   private boolean space(BlockPos pos) {
/*  742 */     return (mc.world.isAirBlock(pos) || mc.world.getBlockState(pos).getBlock() == Blocks.BED);
/*      */   }
/*      */   
/*      */   private boolean solid(BlockPos pos) {
/*  746 */     return (!BlockUtil.isBlockUnSolid(pos) && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockBed) && mc.world.getBlockState(pos).isSideSolid((IBlockAccess)mc.world, pos, EnumFacing.UP) && (BlockUtil.getBlock(pos)).fullBlock);
/*      */   }
/*      */   
/*      */   private boolean inRange(BlockPos pos) {
/*  750 */     double x = pos.x - mc.player.posX;
/*  751 */     double z = pos.z - mc.player.posZ;
/*  752 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/*  753 */     double add = Math.sqrt(y * y) / 2.0D;
/*  754 */     return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue());
/*      */   }
/*      */   
/*      */   private static boolean isPos2(BlockPos pos1, BlockPos pos2) {
/*  758 */     if (pos1 == null || pos2 == null)
/*  759 */       return false; 
/*  760 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*      */   }
/*      */   
/*      */   public void refill_bed() {
/*  764 */     if (!(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer) || mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory) {
/*  765 */       int airSlot = isSpace();
/*  766 */       if (airSlot != -1) {
/*  767 */         for (int i = 9; i < 36; i++) {
/*  768 */           if (mc.player.inventory.getStackInSlot(i).getItem() == Items.BED) {
/*  769 */             if (((String)this.clickMode.getValue()).equalsIgnoreCase("Quick")) {
/*  770 */               if (mc.player.inventory.getStackInSlot(airSlot).getItem() != Items.AIR) mc.playerController.windowClick(mc.player.inventoryContainer.windowId, airSlot + 36, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player); 
/*  771 */               mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player); break;
/*  772 */             }  if (((String)this.clickMode.getValue()).equalsIgnoreCase("Swap")) {
/*  773 */               mc.playerController.windowClick(0, i, airSlot, ClickType.SWAP, (EntityPlayer)mc.player); break;
/*      */             } 
/*  775 */             mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*  776 */             mc.playerController.windowClick(mc.player.inventoryContainer.windowId, airSlot + 36, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private int isSpace() {
/*  786 */     int slot = -1;
/*  787 */     if (((Boolean)this.force.getValue()).booleanValue()) {
/*  788 */       if (((String)this.refillMode.getValue()).equals("Only")) {
/*  789 */         int slot1 = ((Integer)this.slotS.getValue()).intValue() - 1;
/*  790 */         if (mc.player.inventory.getStackInSlot(slot1).getItem() != Items.BED) {
/*  791 */           slot = slot1;
/*      */         }
/*      */       } else {
/*  794 */         for (int i = 0; i < 9; i++) {
/*  795 */           if (mc.player.inventory.getStackInSlot(i).getItem() != Items.BED) {
/*  796 */             slot = i;
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/*  801 */     } else if (((String)this.refillMode.getValue()).equals("Only")) {
/*  802 */       int slot1 = ((Integer)this.slotS.getValue()).intValue() - 1;
/*  803 */       if (mc.player.inventory.getStackInSlot(slot1).getItem() == Items.AIR) {
/*  804 */         slot = slot1;
/*      */       }
/*      */     } else {
/*  807 */       for (int i = 0; i < 9; i++) {
/*  808 */         if (mc.player.inventory.getStackInSlot(i).getItem() == Items.AIR) {
/*  809 */           slot = i;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  814 */     return slot;
/*      */   }
/*      */   
/*      */   private Vec3d getHitVecOffset(EnumFacing face) {
/*  818 */     Vec3i vec = face.getDirectionVec();
/*  819 */     return new Vec3d((vec.x * 0.5F + 0.5F), (vec.y * 0.5F + 0.5F), (vec.z * 0.5F + 0.5F));
/*      */   }
/*      */   
/*      */   private void switchTo(int slot) {
/*  823 */     if (slot > -1 && slot < 9) {
/*  824 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*  825 */       else { mc.player.inventory.currentItem = slot; }
/*  826 */        if (((Boolean)this.update.getValue()).booleanValue()) mc.playerController.updateController(); 
/*  827 */       mc.player.openContainer.detectAndSendChanges();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void swing(EnumHand hand) {
/*  832 */     if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(hand)); }
/*  833 */     else { mc.player.swingArm(hand); }
/*      */   
/*      */   }
/*      */   private boolean inNether() {
/*  837 */     return (mc.player.dimension == 0);
/*      */   }
/*      */   
/*      */   public void onEnable() {
/*  841 */     this.calctiming.reset();
/*  842 */     this.basetiming.reset();
/*  843 */     this.placetiming.reset();
/*  844 */     this.breaktiming.reset();
/*  845 */     this.updatetiming.reset();
/*  846 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  847 */       this.lastBestPlace = null;
/*  848 */       this.lastBestPos = null;
/*  849 */       this.managerClassRenderBlocks.blocks.clear();
/*  850 */       this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  851 */       this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void onDisable() {
/*  856 */     this.headPos = null;
/*  857 */     this.basePos = null;
/*  858 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/*  859 */       this.lastBestPlace = null;
/*  860 */       this.lastBestPos = null;
/*  861 */       this.managerClassRenderBlocks.blocks.clear();
/*  862 */       this.movingPlaceNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*  863 */       this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void onWorldRender(RenderEvent event) {
/*  869 */     if (mc.world == null)
/*      */       return; 
/*  871 */     this.managerClassRenderBlocks.render();
/*      */     
/*  873 */     if (this.headPos == null || this.basePos == null)
/*      */       return; 
/*  875 */     if (!((Boolean)this.anime.getValue()).booleanValue()) {
/*  876 */       drawRender();
/*      */     } else {
/*  878 */       this.lastBestPlace = this.headPos;
/*  879 */       this.lastBestPos = this.basePos;
/*      */     } 
/*      */     
/*  882 */     if (((Boolean)this.fade.getValue()).booleanValue()) {
/*  883 */       this.managerClassRenderBlocks.addRender(this.headPos, this.basePos);
/*      */     }
/*      */     
/*  886 */     if (((Boolean)this.anime.getValue()).booleanValue() && this.lastBestPlace != null && this.lastBestPos != null) {
/*  887 */       if (this.movingPlaceNow.y == -1.0D && this.movingPlaceNow.x == -1.0D && this.movingPlaceNow.z == -1.0D) {
/*  888 */         this.movingPlaceNow = new Vec3d(this.lastBestPlace.getX(), this.lastBestPlace.getY(), this.lastBestPlace.getZ());
/*      */       }
/*      */       
/*  891 */       if (this.movingPosNow.y == -1.0D && this.movingPosNow.x == -1.0D && this.movingPosNow.z == -1.0D) {
/*  892 */         this.movingPosNow = new Vec3d(this.lastBestPos.getX(), this.lastBestPos.getY(), this.lastBestPos.getZ());
/*      */       }
/*      */       
/*  895 */       this
/*      */ 
/*      */         
/*  898 */         .movingPlaceNow = new Vec3d(this.movingPlaceNow.x + (this.lastBestPlace.getX() - this.movingPlaceNow.x) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPlaceNow.y + (this.lastBestPlace.getY() - this.movingPlaceNow.y) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPlaceNow.z + (this.lastBestPlace.getZ() - this.movingPlaceNow.z) * ((Double)this.movingPlaceSpeed.getValue()).floatValue());
/*      */ 
/*      */       
/*  901 */       this
/*      */ 
/*      */         
/*  904 */         .movingPosNow = new Vec3d(this.movingPosNow.x + (this.lastBestPos.getX() - this.movingPosNow.x) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPosNow.y + (this.lastBestPos.getY() - this.movingPosNow.y) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPosNow.z + (this.lastBestPos.getZ() - this.movingPosNow.z) * ((Double)this.movingPlaceSpeed.getValue()).floatValue());
/*      */ 
/*      */ 
/*      */       
/*  908 */       drawBoxMain(this.movingPlaceNow.x, this.movingPlaceNow.y, this.movingPlaceNow.z, this.movingPosNow.x, this.movingPosNow.y, this.movingPosNow.z);
/*      */       
/*  910 */       if (Math.abs(this.movingPlaceNow.x - this.lastBestPlace.getX()) <= 0.125D && Math.abs(this.movingPlaceNow.y - this.lastBestPlace.getY()) <= 0.125D && Math.abs(this.movingPlaceNow.z - this.lastBestPlace.getZ()) <= 0.125D) {
/*  911 */         this.lastBestPlace = null;
/*      */       }
/*      */       
/*  914 */       if (Math.abs(this.movingPosNow.x - this.lastBestPos.getX()) <= 0.125D && Math.abs(this.movingPosNow.y - this.lastBestPos.getY()) <= 0.125D && Math.abs(this.movingPosNow.z - this.lastBestPos.getZ()) <= 0.125D) {
/*  915 */         this.lastBestPos = null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawAnimationRender(AxisAlignedBB box1, AxisAlignedBB box2) {
/*  923 */     AxisAlignedBB box, nBox1 = new AxisAlignedBB(box1.minX, box1.minY, box1.minZ, box1.minX + 1.0D, box1.minY + 0.5625D, box1.minZ + 1.0D), nBox2 = new AxisAlignedBB(box2.minX, box2.minY, box2.minZ, box2.minX + 1.0D, box2.minY + 0.5625D, box2.minZ + 1.0D);
/*      */     
/*  925 */     boolean x1 = (box1.minX < box2.minX);
/*  926 */     boolean z2 = (box1.minZ > box2.minZ);
/*  927 */     if (x1)
/*  928 */     { if (z2) { box = new AxisAlignedBB(box1.minX, box1.minY, box2.minZ, box2.minX + 1.0D, box2.minY + 0.5625D, box1.minZ + 1.0D); }
/*  929 */       else { box = new AxisAlignedBB(box1.minX, box1.minY, box1.minZ, box2.minX + 1.0D, box2.minY + 0.5625D, box2.minZ + 1.0D); }
/*      */        }
/*  931 */     else if (z2) { box = new AxisAlignedBB(box2.minX, box1.minY, box2.minZ, box1.minX + 1.0D, box2.minY + 0.5625D, box1.minZ + 1.0D); }
/*  932 */     else { box = new AxisAlignedBB(box2.minX, box1.minY, box1.minZ, box1.minX + 1.0D, box2.minY + 0.5625D, box2.minZ + 1.0D); }
/*      */     
/*  934 */     if ((new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue())).equals(new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()))) {
/*  935 */       RenderUtil.drawBox(box, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/*  936 */       if (((Boolean)this.outline.getValue()).booleanValue()) RenderUtil.drawBoundingBox(box, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255)); 
/*      */     } else {
/*  938 */       switch (this.face) {
/*      */         case "WEST":
/*  940 */           if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*  941 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 16);
/*  942 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 32);
/*  943 */             if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  944 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 16);
/*  945 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 32);
/*      */             }  break;
/*      */           } 
/*  948 */           RenderUtil.drawBox(nBox1, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 31);
/*  949 */           RenderUtil.drawBox(nBox2, false, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 47);
/*  950 */           if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  951 */             RenderUtil.drawBoundingBox(nBox1, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*  952 */             RenderUtil.drawBoundingBox(nBox2, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case "EAST":
/*  958 */           if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*  959 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 32);
/*  960 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 16);
/*  961 */             if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  962 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 32);
/*  963 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 16);
/*      */             }  break;
/*      */           } 
/*  966 */           RenderUtil.drawBox(nBox1, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 47);
/*  967 */           RenderUtil.drawBox(nBox2, false, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 31);
/*  968 */           if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  969 */             RenderUtil.drawBoundingBox(nBox1, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*  970 */             RenderUtil.drawBoundingBox(nBox2, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case "SOUTH":
/*  976 */           if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*  977 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 8);
/*  978 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 4);
/*  979 */             if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  980 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 8);
/*  981 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 4);
/*      */             }  break;
/*      */           } 
/*  984 */           RenderUtil.drawBox(nBox1, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 59);
/*  985 */           RenderUtil.drawBox(nBox2, false, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 55);
/*  986 */           if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  987 */             RenderUtil.drawBoundingBox(nBox1, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*  988 */             RenderUtil.drawBoundingBox(nBox2, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case "NORTH":
/*  994 */           if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*  995 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 4);
/*  996 */             RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 8);
/*  997 */             if (((Boolean)this.outline.getValue()).booleanValue()) {
/*  998 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 4);
/*  999 */               RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), 0, 8);
/*      */             }  break;
/*      */           } 
/* 1002 */           RenderUtil.drawBox(nBox1, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 55);
/* 1003 */           RenderUtil.drawBox(nBox2, false, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 59);
/* 1004 */           if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1005 */             RenderUtil.drawBoundingBox(nBox1, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/* 1006 */             RenderUtil.drawBoundingBox(nBox2, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1014 */     if (((Boolean)this.showDamage.getValue()).booleanValue()) {
/* 1015 */       String[] damageText = { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) };
/* 1016 */       if (((Boolean)this.showSelfDamage.getValue()).booleanValue()) {
/* 1017 */         damageText = new String[] { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) + "/" + String.format("%.1f", new Object[] { Float.valueOf(this.selfDamage) }) };
/*      */       }
/* 1019 */       RenderUtil.drawNametag(box1.minX + 0.5D, box1.minY + 0.28125D, box1.minZ + 0.5D, damageText, new GSColor(255, 255, 255), 1, 0.02666666666666667D, 0.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void drawFade(BlockPos render, BlockPos render2, int alpha, int outlineAlpha) {
/* 1024 */     if (render == null || render2 == null || alpha < 0 || outlineAlpha < 0)
/*      */       return; 
/* 1026 */     if ((new GSColor(this.color.getValue(), alpha)).equals(new GSColor(this.color2.getValue(), alpha))) {
/*      */       AxisAlignedBB box;
/* 1028 */       if (render.x - render2.x < 0 || render.z - render2.z < 0) { box = new AxisAlignedBB(render.x, render.y, render.z, (render2.getX() + 1), render2.getY() + 0.5625D, (render2.getZ() + 1)); }
/* 1029 */       else { box = new AxisAlignedBB(render2.x, render2.y, render2.z, (render.getX() + 1), render.getY() + 0.5625D, (render.getZ() + 1)); }
/* 1030 */        RenderUtil.drawBox(box, false, 0.5625D, new GSColor(this.color.getValue(), alpha), 63);
/* 1031 */       if (((Boolean)this.outline.getValue()).booleanValue()) RenderUtil.drawBoundingBox(box, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha));
/*      */     
/* 1033 */     } else if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*      */       AxisAlignedBB box;
/* 1035 */       if (render.x - render2.x < 0 || render.z - render2.z < 0) { box = new AxisAlignedBB(render.x, render.y, render.z, (render2.getX() + 1), render2.getY() + 0.5625D, (render2.getZ() + 1)); }
/* 1036 */       else { box = new AxisAlignedBB(render2.x, render2.y, render2.z, (render.getX() + 1), render.getY() + 0.5625D, (render.getZ() + 1)); }
/* 1037 */        if (render.x - render2.x < 0) {
/* 1038 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), alpha), 0, 16);
/* 1039 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), alpha), 0, 32);
/* 1040 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1041 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), 0, 16);
/* 1042 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), 0, 32);
/*      */         }
/*      */       
/* 1045 */       } else if (render.z - render2.z < 0) {
/* 1046 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), alpha), 0, 4);
/* 1047 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), alpha), 0, 8);
/* 1048 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1049 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), 0, 4);
/* 1050 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), 0, 8);
/*      */         } 
/* 1052 */       } else if (render.z - render2.z == 0) {
/* 1053 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), alpha), 0, 32);
/* 1054 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), alpha), 0, 16);
/* 1055 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1056 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), 0, 32);
/* 1057 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), 0, 16);
/*      */         } 
/*      */       } else {
/* 1060 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), alpha), 0, 8);
/* 1061 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), alpha), 0, 4);
/* 1062 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1063 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), 0, 8);
/* 1064 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), 0, 4);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1070 */     else if (render.x - render2.x < 0) {
/* 1071 */       RenderUtil.drawBox(render, 0.5625D, new GSColor(this.color.getValue(), alpha), 31);
/* 1072 */       RenderUtil.drawBox(render2, 0.5625D, new GSColor(this.color2.getValue(), alpha), 47);
/* 1073 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1074 */         RenderUtil.drawBoundingBoxDire(render, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), outlineAlpha, 31);
/* 1075 */         RenderUtil.drawBoundingBoxDire(render2, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), outlineAlpha, 47);
/*      */       }
/*      */     
/* 1078 */     } else if (render.z - render2.z < 0) {
/* 1079 */       RenderUtil.drawBox(render, 0.5625D, new GSColor(this.color.getValue(), alpha), 55);
/* 1080 */       RenderUtil.drawBox(render2, 0.5625D, new GSColor(this.color2.getValue(), alpha), 59);
/* 1081 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1082 */         RenderUtil.drawBoundingBoxDire(render, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), outlineAlpha, 55);
/* 1083 */         RenderUtil.drawBoundingBoxDire(render2, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), outlineAlpha, 59);
/*      */       } 
/* 1085 */     } else if (render.z - render2.z == 0) {
/* 1086 */       RenderUtil.drawBox(render, 0.5625D, new GSColor(this.color.getValue(), alpha), 47);
/* 1087 */       RenderUtil.drawBox(render2, 0.5625D, new GSColor(this.color2.getValue(), alpha), 31);
/* 1088 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1089 */         RenderUtil.drawBoundingBoxDire(render, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), outlineAlpha, 47);
/* 1090 */         RenderUtil.drawBoundingBoxDire(render2, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), outlineAlpha, 31);
/*      */       } 
/*      */     } else {
/* 1093 */       RenderUtil.drawBox(render, 0.5625D, new GSColor(this.color.getValue(), alpha), 59);
/* 1094 */       RenderUtil.drawBox(render2, 0.5625D, new GSColor(this.color2.getValue(), alpha), 55);
/* 1095 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1096 */         RenderUtil.drawBoundingBoxDire(render, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), outlineAlpha), outlineAlpha, 59);
/* 1097 */         RenderUtil.drawBoundingBoxDire(render2, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), outlineAlpha), outlineAlpha, 47);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void drawRender() {
/* 1107 */     if ((new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue())).equals(new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()))) {
/*      */       AxisAlignedBB box;
/* 1109 */       if (this.headPos.x - this.basePos.x < 0 || this.headPos.z - this.basePos.z < 0) { box = new AxisAlignedBB(this.headPos.x, this.headPos.y, this.headPos.z, (this.basePos.getX() + 1), this.basePos.getY() + 0.5625D, (this.basePos.getZ() + 1)); }
/* 1110 */       else { box = new AxisAlignedBB(this.basePos.x, this.basePos.y, this.basePos.z, (this.headPos.getX() + 1), this.headPos.getY() + 0.5625D, (this.headPos.getZ() + 1)); }
/* 1111 */        RenderUtil.drawBox(box, false, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/* 1112 */       if (((Boolean)this.outline.getValue()).booleanValue()) RenderUtil.drawBoundingBox(box, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255));
/*      */     
/* 1114 */     } else if (((Boolean)this.gradient.getValue()).booleanValue()) {
/*      */       AxisAlignedBB box;
/* 1116 */       if (this.headPos.x - this.basePos.x < 0 || this.headPos.z - this.basePos.z < 0) { box = new AxisAlignedBB(this.headPos.x, this.headPos.y, this.headPos.z, (this.basePos.getX() + 1), this.basePos.getY() + 0.5625D, (this.basePos.getZ() + 1)); }
/* 1117 */       else { box = new AxisAlignedBB(this.basePos.x, this.basePos.y, this.basePos.z, (this.headPos.getX() + 1), this.headPos.getY() + 0.5625D, (this.headPos.getZ() + 1)); }
/* 1118 */        if (this.headPos.x - this.basePos.x < 0) {
/* 1119 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 16);
/* 1120 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 32);
/* 1121 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1122 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255), 0, 16);
/* 1123 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), 255), 0, 32);
/*      */         }
/*      */       
/* 1126 */       } else if (this.headPos.z - this.basePos.z < 0) {
/* 1127 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 4);
/* 1128 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 8);
/* 1129 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1130 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255), 0, 4);
/* 1131 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), 255), 0, 8);
/*      */         } 
/* 1133 */       } else if (this.headPos.z - this.basePos.z == 0) {
/* 1134 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 32);
/* 1135 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 16);
/* 1136 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1137 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255), 0, 32);
/* 1138 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), 255), 0, 16);
/*      */         } 
/*      */       } else {
/* 1141 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 8);
/* 1142 */         RenderUtil.drawBoxDire(box, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 0, 4);
/* 1143 */         if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1144 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), 255), 0, 8);
/* 1145 */           RenderUtil.drawBoundingBoxDire(box, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), 255), 0, 4);
/*      */         }
/*      */       
/*      */       }
/*      */     
/* 1150 */     } else if (this.headPos.x - this.basePos.x < 0) {
/* 1151 */       RenderUtil.drawBox(this.headPos, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 31);
/* 1152 */       RenderUtil.drawBox(this.basePos, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 47);
/* 1153 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1154 */         RenderUtil.drawBoundingBoxDire(this.headPos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 31);
/* 1155 */         RenderUtil.drawBoundingBoxDire(this.basePos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 47);
/*      */       }
/*      */     
/* 1158 */     } else if (this.headPos.z - this.basePos.z < 0) {
/* 1159 */       RenderUtil.drawBox(this.headPos, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 55);
/* 1160 */       RenderUtil.drawBox(this.basePos, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 59);
/* 1161 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1162 */         RenderUtil.drawBoundingBoxDire(this.headPos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 55);
/* 1163 */         RenderUtil.drawBoundingBoxDire(this.basePos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 59);
/*      */       } 
/* 1165 */     } else if (this.headPos.z - this.basePos.z == 0) {
/* 1166 */       RenderUtil.drawBox(this.headPos, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 47);
/* 1167 */       RenderUtil.drawBox(this.basePos, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 31);
/* 1168 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1169 */         RenderUtil.drawBoundingBoxDire(this.headPos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 47);
/* 1170 */         RenderUtil.drawBoundingBoxDire(this.basePos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 31);
/*      */       } 
/*      */     } else {
/* 1173 */       RenderUtil.drawBox(this.headPos, 0.5625D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 59);
/* 1174 */       RenderUtil.drawBox(this.basePos, 0.5625D, new GSColor(this.color2.getValue(), ((Integer)this.alpha.getValue()).intValue()), 55);
/* 1175 */       if (((Boolean)this.outline.getValue()).booleanValue()) {
/* 1176 */         RenderUtil.drawBoundingBoxDire(this.headPos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 59);
/* 1177 */         RenderUtil.drawBoundingBoxDire(this.basePos, 0.5625D, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color2.getValue(), ((Integer)this.outAlpha.getValue()).intValue()), ((Integer)this.outAlpha.getValue()).intValue(), 55);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1185 */     if (((Boolean)this.showDamage.getValue()).booleanValue()) {
/* 1186 */       String[] damageText = { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) };
/* 1187 */       if (((Boolean)this.showSelfDamage.getValue()).booleanValue()) {
/* 1188 */         damageText = new String[] { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) + "/" + String.format("%.1f", new Object[] { Float.valueOf(this.selfDamage) }) };
/*      */       }
/* 1190 */       RenderUtil.drawNametag(this.headPos.getX() + 0.5D, this.headPos.getY() + 0.28125D, this.headPos.getZ() + 0.5D, damageText, new GSColor(255, 255, 255), 1, 0.02666666666666667D, 0.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   class renderBlock { private final BlockPos pos;
/*      */     private final BlockPos pos2;
/*      */     private long start;
/*      */     
/*      */     public renderBlock(BlockPos pos, BlockPos pos2) {
/* 1199 */       this.start = System.currentTimeMillis();
/* 1200 */       this.pos = pos;
/* 1201 */       this.pos2 = pos2;
/*      */     }
/*      */     
/*      */     void resetTime() {
/* 1205 */       this.start = System.currentTimeMillis();
/*      */     }
/*      */     
/*      */     void render() {
/* 1209 */       BedAura.this.drawBoxMain(this.pos, this.pos2, returnGradient(), returnOutlineGradient());
/*      */     }
/*      */ 
/*      */     
/*      */     public int returnGradient() {
/* 1214 */       long end = this.start + ((Integer)BedAura.this.lifeTime.getValue()).intValue();
/* 1215 */       int result = (int)((float)(end - System.currentTimeMillis()) / (float)(end - this.start) * 100.0F);
/* 1216 */       if (result < 0) {
/* 1217 */         result = 0;
/*      */       }
/* 1219 */       int startFade = ((Integer)BedAura.this.fadeAlpha.getValue()).intValue();
/* 1220 */       int endFade = 0;
/*      */       
/* 1222 */       return (int)((startFade - endFade) * result / 100.0D);
/*      */     }
/*      */     public int returnOutlineGradient() {
/* 1225 */       long end = this.start + ((Integer)BedAura.this.lifeTime.getValue()).intValue();
/* 1226 */       int result = (int)((float)(end - System.currentTimeMillis()) / (float)(end - this.start) * 100.0F);
/* 1227 */       if (result < 0) {
/* 1228 */         result = 0;
/*      */       }
/* 1230 */       int startFade = 255;
/* 1231 */       int endFade = 0;
/*      */       
/* 1233 */       return (int)((startFade - endFade) * result / 100.0D);
/*      */     } }
/*      */ 
/*      */   
/*      */   AxisAlignedBB getBox(double x, double y, double z) {
/* 1238 */     double maxX = x + 1.0D;
/* 1239 */     double maxZ = z + 1.0D;
/* 1240 */     return new AxisAlignedBB(x, y, z, maxX, y, maxZ);
/*      */   }
/*      */   
/*      */   void drawBoxMain(BlockPos pos, BlockPos pos2, int alpha, int outline) {
/* 1244 */     drawFade(pos, pos2, alpha, outline);
/*      */   }
/*      */   
/*      */   void drawBoxMain(double x, double y, double z, double x2, double y2, double z2) {
/* 1248 */     AxisAlignedBB box = getBox(x, y, z);
/* 1249 */     AxisAlignedBB box2 = getBox(x2, y2, z2);
/* 1250 */     box = new AxisAlignedBB(box.minX, box.maxY, box.minZ, box.maxX, box.maxY + 0.5625D, box.maxZ);
/* 1251 */     box2 = new AxisAlignedBB(box2.minX, box2.maxY, box2.minZ, box2.maxX, box2.maxY + 0.5625D, box2.maxZ);
/* 1252 */     drawAnimationRender(box, box2);
/*      */   }
/*      */   
/*      */   class managerClassRenderBlocks {
/* 1256 */     ArrayList<BedAura.renderBlock> blocks = new ArrayList<>();
/*      */     
/*      */     void update(int time) {
/* 1259 */       this.blocks.removeIf(e -> (System.currentTimeMillis() - e.start > time));
/*      */     }
/*      */     void render() {
/* 1262 */       this.blocks.forEach(e -> {
/*      */             if (BedAura.this.headPos != null && ((BedAura.isPos2(e.pos, BedAura.this.headPos) && BedAura.isPos2(e.pos2, BedAura.this.basePos)) || (BedAura.isPos2(e.pos2, BedAura.this.headPos) && BedAura.isPos2(e.pos, BedAura.this.basePos)))) {
/*      */               e.resetTime();
/*      */             } else {
/*      */               e.render();
/*      */             } 
/*      */           });
/*      */     }
/*      */     void addRender(BlockPos pos, BlockPos pos2) {
/* 1271 */       boolean render = true;
/* 1272 */       for (BedAura.renderBlock block : this.blocks) {
/* 1273 */         if ((BedAura.isPos2(block.pos, pos) && BedAura.isPos2(block.pos2, pos2)) || (BedAura.isPos2(block.pos2, pos2) && BedAura.isPos2(block.pos, pos))) {
/* 1274 */           render = false;
/* 1275 */           block.resetTime();
/*      */           break;
/*      */         } 
/*      */       } 
/* 1279 */       if (render) {
/* 1280 */         this.blocks.add(new BedAura.renderBlock(pos, pos2));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public String getHudInfo() {
/* 1286 */     Entity currentTarget = null;
/* 1287 */     if (this.target != null) {
/* 1288 */       currentTarget = (this.target.defaultPlayer == null) ? (Entity)this.target.entity : (Entity)this.target.defaultPlayer;
/*      */     }
/* 1290 */     boolean isNull = (currentTarget == null);
/* 1291 */     switch ((String)this.hudDisplay.getValue()) {
/*      */       case "Target":
/* 1293 */         return isNull ? ("[" + ChatFormatting.WHITE + "None" + ChatFormatting.GRAY + "]") : ("[" + ChatFormatting.WHITE + currentTarget
/* 1294 */           .getName() + ChatFormatting.GRAY + "]");
/*      */       
/*      */       case "Damage":
/* 1297 */         return "[" + ChatFormatting.WHITE + String.format("%.1f", new Object[] { Float.valueOf(this.damage)
/* 1298 */             }) + (((Boolean)this.hudSelfDamage.getValue()).booleanValue() ? (" Self: " + String.format("%.1f", new Object[] { Float.valueOf(this.selfDamage) })) : "") + ChatFormatting.GRAY + "]";
/*      */       
/*      */       case "Both":
/* 1301 */         return "[" + ChatFormatting.WHITE + (isNull ? "None" : currentTarget.getName()) + " " + 
/* 1302 */           String.format("%.1f", new Object[] { Float.valueOf(this.damage)
/* 1303 */             }) + (((Boolean)this.hudSelfDamage.getValue()).booleanValue() ? (" Self: " + String.format("%.1f", new Object[] { Float.valueOf(this.selfDamage) })) : "") + ChatFormatting.GRAY + "]";
/*      */     } 
/*      */     
/* 1306 */     return "";
/*      */   }
/*      */   class PlaceInfo { BedAura.EntityInfo target; BlockPos placePos;
/*      */     BlockPos basePos;
/*      */     float damage;
/*      */     float selfDamage;
/*      */     
/*      */     public PlaceInfo(BedAura.EntityInfo target, BlockPos placePos, float damage, float selfDamage, BlockPos basePos) {
/* 1314 */       this.target = target;
/* 1315 */       this.placePos = placePos;
/* 1316 */       this.damage = damage;
/* 1317 */       this.selfDamage = selfDamage;
/* 1318 */       this.basePos = basePos;
/*      */     } }
/*      */ 
/*      */   
/*      */   class EntityInfo {
/* 1323 */     EntityPlayer player = null; EntityPlayer defaultPlayer = null;
/* 1324 */     EntityLivingBase entity = null; double hp;
/*      */     
/*      */     public EntityInfo(EntityPlayer player, boolean predict) {
/* 1327 */       if (player == null)
/* 1328 */         return;  this.defaultPlayer = player;
/* 1329 */       this.player = predict ? PredictUtil.predictPlayer((EntityLivingBase)player, new PredictUtil.PredictSettings(((BedAura.MoveRotation)BedAura.this.playerSpeed.get(player)).tick, ((Boolean)BedAura.this.calculateYPredict.getValue()).booleanValue(), ((Integer)BedAura.this.startDecrease.getValue()).intValue(), ((Integer)BedAura.this.exponentStartDecrease.getValue()).intValue(), ((Integer)BedAura.this.decreaseY.getValue()).intValue(), ((Integer)BedAura.this.exponentDecreaseY.getValue()).intValue(), ((Boolean)BedAura.this.splitXZ.getValue()).booleanValue(), ((Boolean)BedAura.this.manualOutHole.getValue()).booleanValue(), ((Boolean)BedAura.this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)BedAura.this.stairPredict.getValue()).booleanValue(), ((Integer)BedAura.this.nStair.getValue()).intValue(), ((Double)BedAura.this.speedActivationStair.getValue()).doubleValue())) : player;
/* 1330 */       this.hp = (player.getHealth() + player.getAbsorptionAmount());
/*      */     }
/*      */     public EntityInfo(EntityLivingBase entity) {
/* 1333 */       if (entity == null)
/* 1334 */         return;  this.entity = entity;
/* 1335 */       this.hp = (entity.getHealth() + entity.getAbsorptionAmount());
/*      */     } }
/*      */   
/*      */   class MoveRotation {
/*      */     double yaw;
/*      */     double lastYaw;
/*      */     int tick;
/*      */     
/*      */     public MoveRotation(EntityPlayer player, double lastYaw, int tick) {
/* 1344 */       this.yaw = (RotationUtil.getRotationTo(player.getPositionVector(), new Vec3d(player.prevPosX, player.prevPosY, player.prevPosZ))).x;
/* 1345 */       this.lastYaw = lastYaw;
/* 1346 */       double difference = this.yaw - lastYaw;
/* 1347 */       if ((lastYaw != 512.0D && (difference > ((Double)BedAura.this.resetRotate.getValue()).doubleValue() || difference < -((Double)BedAura.this.resetRotate.getValue()).doubleValue())) || LemonClient.speedUtil.getPlayerSpeed(player) == 0.0D) {
/* 1348 */         this.tick = 0;
/*      */         return;
/*      */       } 
/* 1351 */       this.tick = tick;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\BedAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
