//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.event.Phase;
/*     */ import com.lemonclient.api.event.events.OnUpdateWalkingPlayerEvent;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.PlayerPacket;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.combat.DamageUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import me.zero.alpine.listener.EventHandler;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityXPOrb;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ 
/*     */ @Declaration(name = "AutoMend", category = Category.Combat)
/*     */ public class AutoMend extends Module {
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting silentSwitch;
/*     */   
/*     */   public AutoMend() {
/*  39 */     this.rotate = registerBoolean("Rotate", true);
/*  40 */     this.silentSwitch = registerBoolean("Packet Switch", true);
/*  41 */     this.delay = registerInteger("Delay", 0, 0, 1000);
/*  42 */     this.minDamage = registerInteger("Min Damage", 50, 1, 100);
/*  43 */     this.maxHeal = registerInteger("Repair To", 90, 1, 100);
/*  44 */     this.takeOff = registerBoolean("TakeOff", true);
/*  45 */     this.takeOffDelay = registerInteger("TakeOff Delay", 0, 0, 1000);
/*  46 */     this.predict = registerBoolean("Predict", true);
/*  47 */     this.crystal = registerBoolean("Crystal Check", true);
/*  48 */     this.biasDamage = registerDouble("Bias Damage", 1.0D, 0.0D, 3.0D);
/*  49 */     this.health = registerBoolean("Health Check", true);
/*  50 */     this.minHealth = registerInteger("Min Health", 16, 0, 36, () -> (Boolean)this.health.getValue());
/*  51 */     this.player = registerBoolean("Enemy Check", true);
/*  52 */     this.maxSpeed = registerDouble("Max Speed", 10.0D, 0.0D, 50.0D, () -> (Boolean)this.player.getValue());
/*     */     
/*  54 */     this.timer = new Timing();
/*  55 */     this.takeOffTimer = new Timing();
/*  56 */     this.toMend = Character.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (!((Boolean)this.rotate.getValue()).booleanValue()) return;  if (event.getPhase() != Phase.PRE) return;  PlayerPacket packet = new PlayerPacket(this, new Vec2f((PlayerPacketManager.INSTANCE.getServerSideRotation()).x, 90.0F)); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     this.sendListener = new Listener(event -> { if (!((Boolean)this.rotate.getValue()).booleanValue()) return;  if (event.getPacket() instanceof CPacketPlayer.Rotation) ((CPacketPlayer.Rotation)event.getPacket()).yaw = (PlayerPacketManager.INSTANCE.getServerSideRotation()).x;  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = (PlayerPacketManager.INSTANCE.getServerSideRotation()).x;  }new java.util.function.Predicate[0]);
/*     */   }
/*     */   
/*     */   IntegerSetting delay;
/*     */   IntegerSetting minDamage;
/*     */   IntegerSetting maxHeal;
/*     */   BooleanSetting takeOff;
/*     */   IntegerSetting takeOffDelay;
/*     */   BooleanSetting predict;
/*     */   BooleanSetting crystal;
/*     */   DoubleSetting biasDamage;
/*     */   BooleanSetting health;
/*     */   IntegerSetting minHealth;
/*     */   BooleanSetting player;
/*     */   DoubleSetting maxSpeed;
/*     */   int tookOff;
/*     */   Timing timer;
/*     */   Timing takeOffTimer;
/*     */   char toMend;
/*     */   @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener;
/*     */   
/*     */   public void onEnable() {
/*     */     this.tookOff = 0;
/*     */   }
/*     */   
/*     */   public void onTick() {
/*     */     if (mc.player == null || mc.world == null || mc.player.isDead || mc.player.ticksExisted < 10) {
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (((Boolean)this.crystal.getValue()).booleanValue() && crystalDamage()) {
/*     */       setDisabledMessage("Lethal crystal nearby");
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (((Boolean)this.health.getValue()).booleanValue() && mc.player.getHealth() + mc.player.getAbsorptionAmount() < ((Integer)this.minHealth.getValue()).intValue()) {
/*     */       setDisabledMessage("Low health");
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (((Boolean)this.player.getValue()).booleanValue() && checkNearbyPlayers()) {
/*     */       setDisabledMessage("Players nearby");
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (findXPSlot() == -1) {
/*     */       setDisabledMessage("No xp bottle found in hotbar");
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (checkFinished()) {
/*     */       setDisabledMessage("Finished mending armors");
/*     */       disable();
/*     */       return;
/*     */     } 
/*     */     if (!this.timer.passedMs(((Integer)this.delay.getValue()).intValue()))
/*     */       return; 
/*     */     this.timer.reset();
/*     */     int sumOfDamage = 0;
/*     */     NonNullList<ItemStack> nonNullList = mc.player.inventory.armorInventory;
/*     */     for (int i = 0; i < nonNullList.size(); i++) {
/*     */       ItemStack itemStack = nonNullList.get(i);
/*     */       if (!itemStack.isEmpty) {
/*     */         float damageOnArmor = (itemStack.getMaxDamage() - itemStack.getItemDamage());
/*     */         float damagePercent = 100.0F - 100.0F * (1.0F - damageOnArmor / itemStack.getMaxDamage());
/*     */         if (damagePercent <= ((Integer)this.maxHeal.getValue()).intValue()) {
/*     */           if (damagePercent <= ((Integer)this.minDamage.getValue()).intValue())
/*     */             this.toMend = (char)(this.toMend | (char)(1 << i)); 
/*     */           if (((Boolean)this.predict.getValue()).booleanValue())
/*     */             sumOfDamage += (int)((itemStack.getMaxDamage() * ((Integer)this.maxHeal.getValue()).intValue()) / 100.0F - (itemStack.getMaxDamage() - itemStack.getItemDamage())); 
/*     */         } else {
/*     */           this.toMend = (char)(this.toMend & (char)(1 << i ^ 0xFFFFFFFF));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     if (this.toMend > '\000')
/*     */       if (((Boolean)this.predict.getValue()).booleanValue()) {
/*     */         int totalXp = mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityXPOrb).filter(entity -> (entity.getDistanceSq((Entity)mc.player) <= 1.0D)).mapToInt(entity -> ((EntityXPOrb)entity).xpValue).sum();
/*     */         if (totalXp * 2 < sumOfDamage)
/*     */           mendArmor(); 
/*     */       } else {
/*     */         mendArmor();
/*     */       }  
/*     */   }
/*     */   
/*     */   private void run(int slot, Runnable runnable) {
/*     */     int oldslot = mc.player.inventory.currentItem;
/*     */     if (slot < 0 || slot == oldslot) {
/*     */       runnable.run();
/*     */       return;
/*     */     } 
/*     */     if (((Boolean)this.silentSwitch.getValue()).booleanValue()) {
/*     */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */     } else {
/*     */       mc.player.inventory.currentItem = slot;
/*     */     } 
/*     */     runnable.run();
/*     */     if (((Boolean)this.silentSwitch.getValue()).booleanValue()) {
/*     */       mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot));
/*     */     } else {
/*     */       mc.player.inventory.currentItem = oldslot;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mendArmor() {
/*     */     int newSlot = findXPSlot();
/*     */     if (newSlot == -1)
/*     */       return; 
/*     */     run(newSlot, () -> mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)));
/*     */     if (((Boolean)this.takeOff.getValue()).booleanValue())
/*     */       takeArmorOff(); 
/*     */   }
/*     */   
/*     */   private void takeArmorOff() {
/*     */     int slot = 5;
/*     */     while (slot <= 8) {
/*     */       ItemStack item = getArmor(slot);
/*     */       double max_dam = item.getMaxDamage();
/*     */       double dam_left = (item.getMaxDamage() - item.getItemDamage());
/*     */       double percent = dam_left / max_dam * 100.0D;
/*     */       if (percent >= ((Integer)this.maxHeal.getValue()).intValue() && item.getItem() != Items.AIR) {
/*     */         if (!notInInv(Items.AIR).booleanValue())
/*     */           return; 
/*     */         if (!this.takeOffTimer.passedMs(((Integer)this.takeOffDelay.getValue()).intValue()))
/*     */           return; 
/*     */         this.takeOffTimer.reset();
/*     */         boolean hasEmpty = false;
/*     */         for (int l_I = 0; l_I < 36; l_I++) {
/*     */           ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);
/*     */           if (l_Stack.isEmpty) {
/*     */             hasEmpty = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         if (hasEmpty) {
/*     */           mc.playerController.windowClick(0, slot, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.player);
/*     */         } else {
/*     */           for (int l_l = 1; l_l < 5; l_l++) {
/*     */             if ((mc.player.inventoryContainer.getSlot(l_l).getStack()).isEmpty) {
/*     */               mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */               mc.playerController.windowClick(mc.player.inventoryContainer.windowId, l_l, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       slot++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private ItemStack getArmor(int first) {
/*     */     return (ItemStack)mc.player.inventoryContainer.getInventory().get(first);
/*     */   }
/*     */   
/*     */   public Boolean notInInv(Item itemOfChoice) {
/*     */     int n = 0;
/*     */     if (itemOfChoice == mc.player.getHeldItemOffhand().getItem())
/*     */       return Boolean.valueOf(true); 
/*     */     for (int i = 35; i >= 0; i--) {
/*     */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/*     */       if (item == itemOfChoice)
/*     */         return Boolean.valueOf(true); 
/*     */       n++;
/*     */     } 
/*     */     return Boolean.valueOf((n <= 35));
/*     */   }
/*     */   
/*     */   private int findXPSlot() {
/*     */     int slot = -1;
/*     */     for (int i = 0; i < 9; i++) {
/*     */       if (mc.player.inventory.getStackInSlot(i).getItem() == Items.EXPERIENCE_BOTTLE) {
/*     */         slot = i;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     return slot;
/*     */   }
/*     */   
/*     */   private boolean crystalDamage() {
/*     */     for (Entity t : mc.world.loadedEntityList) {
/*     */       if (t instanceof EntityEnderCrystal && mc.player.getDistance(t) <= 12.0F && DamageUtil.calculateDamage((EntityLivingBase)mc.player, (EntityEnderCrystal)t) * ((Double)this.biasDamage.getValue()).doubleValue() >= mc.player.getHealth())
/*     */         return true; 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkNearbyPlayers() {
/*     */     AxisAlignedBB box = new AxisAlignedBB(mc.player.posX - 0.5D, mc.player.posY - 0.5D, mc.player.posZ - 0.5D, mc.player.posX + 0.5D, mc.player.posY + 2.5D, mc.player.posZ + 0.5D);
/*     */     for (EntityPlayer entity : mc.world.playerEntities) {
/*     */       if (EntityUtil.basicChecksEntity(entity) || mc.player.connection.getPlayerInfo(entity.getName()) == null || LemonClient.speedUtil.getPlayerSpeed(entity) >= ((Double)this.maxSpeed.getValue()).doubleValue())
/*     */         continue; 
/*     */       if (box.intersects(entity.getEntityBoundingBox()))
/*     */         return true; 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkFinished() {
/*     */     int finished = 0;
/*     */     int slot = 5;
/*     */     while (slot <= 8) {
/*     */       ItemStack item = getArmor(slot);
/*     */       if (getItemDamage(slot) >= ((Integer)this.maxHeal.getValue()).intValue() || item == ItemStack.EMPTY)
/*     */         finished++; 
/*     */       slot++;
/*     */     } 
/*     */     return (finished >= 4);
/*     */   }
/*     */   
/*     */   private int getItemDamage(int slot) {
/*     */     ItemStack itemStack = mc.player.inventoryContainer.getSlot(slot).getStack();
/*     */     float green = (itemStack.getMaxDamage() - itemStack.getItemDamage()) / itemStack.getMaxDamage();
/*     */     float red = 1.0F - green;
/*     */     return 100 - (int)(red * 100.0F);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoMend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
