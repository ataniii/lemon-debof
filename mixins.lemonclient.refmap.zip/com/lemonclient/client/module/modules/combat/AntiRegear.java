//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*    */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ @Declaration(name = "AntiRegear", category = Category.Combat)
/*    */ public class AntiRegear extends Module {
/*    */   public static AntiRegear INSTANCE;
/*    */   DoubleSetting reach;
/*    */   BooleanSetting packet;
/*    */   BooleanSetting swing;
/*    */   List<BlockPos> selfPlaced;
/*    */   public boolean working;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> listener;
/*    */   
/*    */   public AntiRegear() {
/* 30 */     this.reach = registerDouble("Range", 5.5D, 0.0D, 10.0D);
/* 31 */     this.packet = registerBoolean("Packet Break", false);
/* 32 */     this.swing = registerBoolean("Swing", true);
/* 33 */     this.selfPlaced = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     this.listener = new Listener(event -> { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) { CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock)event.getPacket(); if (mc.player.getHeldItem(packet.getHand()).getItem() instanceof net.minecraft.item.ItemShulkerBox) this.selfPlaced.add(packet.getPos().offset(packet.getDirection()));  }  }new java.util.function.Predicate[0]);
/*    */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   public void fast() {
/*    */     if (mc.world == null || mc.player == null || mc.player.isDead) {
/*    */       this.working = false;
/*    */       return;
/*    */     } 
/*    */     List<BlockPos> sphere = new ArrayList<>();
/*    */     for (EntityPlayer target : PlayerUtil.getNearPlayers(16.0D, 10)) {
/*    */       for (BlockPos pos : EntityUtil.getSphere(EntityUtil.getEntityPos((Entity)target), Double.valueOf(6.5D), Double.valueOf(6.5D), false, false, 0)) {
/*    */         if (!this.selfPlaced.contains(pos) && mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockShulkerBox && mc.player.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D) <= ((Double)this.reach.getValue()).doubleValue())
/*    */           sphere.add(pos); 
/*    */       } 
/*    */     } 
/*    */     this.working = !sphere.isEmpty();
/*    */     Iterator<BlockPos> iterator = sphere.iterator();
/*    */     if (iterator.hasNext()) {
/*    */       BlockPos pos = iterator.next();
/*    */       if (((Boolean)this.swing.getValue()).booleanValue())
/*    */         mc.player.swingArm(EnumHand.MAIN_HAND); 
/*    */       if (((Boolean)this.packet.getValue()).booleanValue()) {
/*    */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
/*    */         mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
/*    */       } else {
/*    */         mc.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
/*    */       } 
/*    */     } 
/*    */     this.selfPlaced.removeIf(pos -> !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockShulkerBox));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AntiRegear.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
