//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ @Declaration(name = "AutoTrap", category = Category.Combat)
/*     */ public class AutoTrap extends Module {
/*     */   IntegerSetting delay;
/*     */   IntegerSetting range;
/*     */   IntegerSetting bpt;
/*     */   BooleanSetting top;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting packet;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwitch;
/*     */   BooleanSetting check;
/*     */   BooleanSetting detect;
/*     */   BooleanSetting self;
/*     */   BooleanSetting bed;
/*     */   BooleanSetting pause;
/*     */   int ob;
/*     */   int waited;
/*     */   int placed;
/*     */   BlockPos trapPos;
/*     */   BlockPos player;
/*     */   List<BlockPos> posList;
/*     */   BlockPos[] sides;
/*     */   BlockPos[] blocks;
/*     */   BlockPos breakPos;
/*     */   private int obsidian;
/*     */   private int place;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.PostSend> listener;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Receive> receiveListener;
/*     */   
/*  36 */   public AutoTrap() { this.delay = registerInteger("Delay", 0, 0, 20);
/*  37 */     this.range = registerInteger("Range", 5, 0, 10);
/*  38 */     this.bpt = registerInteger("BlocksPerTick", 4, 0, 20);
/*  39 */     this.top = registerBoolean("Top+", false);
/*  40 */     this.rotate = registerBoolean("Rotate", false);
/*  41 */     this.packet = registerBoolean("Packet Place", false);
/*  42 */     this.swing = registerBoolean("Swing", false);
/*  43 */     this.packetSwitch = registerBoolean("Packet Switch", false);
/*  44 */     this.check = registerBoolean("Switch Check", true);
/*  45 */     this.detect = registerBoolean("Detect Break", false);
/*  46 */     this.self = registerBoolean("Self Break", false, () -> (Boolean)this.detect.getValue());
/*  47 */     this.bed = registerBoolean("Bedrock", false, () -> (Boolean)this.detect.getValue());
/*  48 */     this.pause = registerBoolean("BedrockHole", true);
/*     */ 
/*     */     
/*  51 */     this.posList = new ArrayList<>();
/*     */     
/*  53 */     this.sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     this.blocks = new BlockPos[] { new BlockPos(0, 1, 0), new BlockPos(0, 2, 0) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     this.obsidian = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     this.listener = new Listener(event -> { if (this.player == null || !((Boolean)this.self.getValue()).booleanValue()) return;  if (event.getPacket() instanceof CPacketPlayerDigging) { CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket(); if (packet.getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) { BlockPos ab = packet.getPosition(); this.breakPos = packet.getPosition(); if (ab.equals(this.player.add(0, 1, 0))) this.place = 17;  if (ab.equals(this.player.add(1, 1, 0))) this.place = 18;  if (ab.equals(this.player.add(-1, 1, 0))) this.place = 19;  if (ab.equals(this.player.add(0, 1, 1))) this.place = 20;  if (ab.equals(this.player.add(0, 1, -1))) this.place = 21;  if (ab.equals(this.player.add(0, 2, 0))) this.place = 22;  if (ab.equals(this.player.add(1, 0, 0))) this.place = 1;  if (ab.equals(this.player.add(-1, 0, 0))) this.place = 2;  if (ab.equals(this.player.add(0, 0, 1))) this.place = 3;  if (ab.equals(this.player.add(0, 0, -1))) this.place = 4;  if (ab.equals(this.player.add(2, 0, 0))) this.place = 5;  if (ab.equals(this.player.add(-2, 0, 0))) this.place = 6;  if (ab.equals(this.player.add(0, 0, 2))) this.place = 7;  if (ab.equals(this.player.add(0, 0, -2))) this.place = 8;  if (ab.equals(this.player.add(1, 1, 0))) this.place = 9;  if (ab.equals(this.player.add(-1, 1, 0))) this.place = 10;  if (ab.equals(this.player.add(0, 1, 1))) this.place = 11;  if (ab.equals(this.player.add(0, 1, -1))) this.place = 12;  if (ab.equals(this.player.add(1, 0, 1))) this.place = 13;  if (ab.equals(this.player.add(1, 0, -1))) this.place = 14;  if (ab.equals(this.player.add(-1, 0, 1))) this.place = 15;  if (ab.equals(this.player.add(-1, 0, -1))) this.place = 16;  }  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     this.receiveListener = new Listener(event -> { if (mc.world == null || mc.player == null || this.player == null) return;  if (event.getPacket() instanceof SPacketBlockBreakAnim) { SPacketBlockBreakAnim packet = (SPacketBlockBreakAnim)event.getPacket(); BlockPos ab = packet.getPosition(); this.breakPos = packet.getPosition(); if (ab.equals(this.player.add(0, 1, 0))) this.place = 17;  if (ab.equals(this.player.add(1, 0, 0))) this.place = 1;  if (ab.equals(this.player.add(-1, 0, 0))) this.place = 2;  if (ab.equals(this.player.add(0, 0, 1))) this.place = 3;  if (ab.equals(this.player.add(0, 0, -1))) this.place = 4;  if (ab.equals(this.player.add(2, 0, 0))) this.place = 5;  if (ab.equals(this.player.add(-2, 0, 0))) this.place = 6;  if (ab.equals(this.player.add(0, 0, 2))) this.place = 7;  if (ab.equals(this.player.add(0, 0, -2))) this.place = 8;  if (ab.equals(this.player.add(1, 1, 0))) this.place = 9;  if (ab.equals(this.player.add(-1, 1, 0))) this.place = 10;  if (ab.equals(this.player.add(0, 1, 1))) this.place = 11;  if (ab.equals(this.player.add(0, 1, -1))) this.place = 12;  if (ab.equals(this.player.add(1, 0, 1))) this.place = 13;  if (ab.equals(this.player.add(1, 0, -1))) this.place = 14;  if (ab.equals(this.player.add(-1, 0, 1))) this.place = 15;  if (ab.equals(this.player.add(-1, 0, -1))) this.place = 16;  }  }new java.util.function.Predicate[0]); }
/*     */   public static boolean isPlayerInHole(EntityPlayer target) { BlockPos blockPos = getLocalPlayerPosFloored(target); HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(blockPos, true, true, false); HoleUtil.HoleType holeType = holeInfo.getType(); return (holeType == HoleUtil.HoleType.SINGLE); }
/*     */   private void switchTo(int slot) { if (slot > -1 && slot < 9 && (!((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot))
/*     */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) {
/*     */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/*     */       } else {
/*     */         mc.player.inventory.currentItem = slot; mc.playerController.updateController();
/*     */       }   }
/*     */   public static BlockPos getLocalPlayerPosFloored(EntityPlayer target) { return new BlockPos(target.getPositionVector()); }
/*     */   public void onUpdate() { if (mc.world == null || mc.player == null || mc.player.isDead) {
/*     */       this.trapPos = null; this.posList.clear(); return;
/*     */     }  this.placed = 0; if (((Integer)this.delay.getValue()).intValue() > 0) {
/*     */       if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */         return;  this.waited = 0;
/*     */     }  if (BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1)
/*     */       return;  EntityPlayer target = PlayerUtil.getNearestPlayer(((Integer)this.range.getValue()).intValue()); if (target == null)
/*     */       return;  if (mc.player.getDistance((Entity)target) > ((Integer)this.range.getValue()).intValue() || !isPlayerInHole(target)) {
/*     */       this.posList.clear();
/*     */     } else {
/*     */       BlockPos pos = EntityUtil.getEntityPos((Entity)target); addBlock(pos);
/*     */     }  for (BlockPos block : this.posList) {
/*     */       if (this.placed > ((Integer)this.bpt.getValue()).intValue())
/*     */         return;  this.ob = BurrowUtil.findHotbarBlock(BlockObsidian.class); if (this.ob == -1)
/*     */         return;  if (!mc.world.isAirBlock(block) || intersectsWithEntity(block))
/*     */         continue;  int oldslot = mc.player.inventory.currentItem; switchTo(this.ob); BurrowUtil.placeBlock(block, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()); switchTo(oldslot);
/*     */       this.placed++;
/*     */     } 
/*     */     this.player = EntityUtil.getEntityPos((Entity)target).up();
/* 303 */     antiCity(this.player); } private IBlockState getBlock(BlockPos block) { if (block == null) return null; 
/* 304 */     return mc.world.getBlockState(block); }
/*     */   private boolean intersectsWithEntity(BlockPos pos) { for (Entity entity : mc.world.loadedEntityList) { if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox())) return true;  }  return false; }
/*     */   private void addBlock(BlockPos pos) { if (BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1) return;  List<BlockPos> blocklist = new ArrayList<>(); blocklist.add(pos.add(0, 2, 0)); if (((Boolean)this.top.getValue()).booleanValue()) blocklist.add(pos.add(0, 3, 0));  int obby = 0; for (BlockPos side : this.sides) { if (mc.world.getBlockState(pos.add((Vec3i)side)).getBlock() != Blocks.BEDROCK || ((Boolean)this.bed.getValue()).booleanValue()) { for (BlockPos blockPos : this.blocks) blocklist.add(pos.add((Vec3i)side).add((Vec3i)blockPos));  obby++; }  }  if (obby == 0 && !((Boolean)this.pause.getValue()).booleanValue()) return;  this.posList.addAll(blocklist); }
/*     */   private boolean noHard(Block block) { return (block != Blocks.BEDROCK || ((Boolean)this.bed.getValue()).booleanValue()); }
/* 308 */   public void antiCity(BlockPos pos) { this.obsidian = BurrowUtil.findHotbarBlock(BlockObsidian.class); if (this.obsidian == -1) return;  if (pos == null) return;  pos = new BlockPos(pos.x, pos.y + 0.2D, pos.z); if (this.breakPos != null) { if ((this.breakPos.equals(pos.add(1, 0, 0)) || this.breakPos.equals(pos.add(1, 1, 0))) && isAir(pos.add(1, 0, 0)) && isAir(pos.add(1, 1, 0))) if (this.breakPos.equals(pos.add(1, 0, 0))) { perform(pos.add(1, 1, 0)); } else { perform(pos.add(1, 0, 0)); }   if ((this.breakPos.equals(pos.add(-1, 0, 0)) || this.breakPos.equals(pos.add(-1, 1, 0))) && isAir(pos.add(-1, 0, 0)) && isAir(pos.add(-1, 1, 0))) if (this.breakPos.equals(pos.add(-1, 0, 0))) { perform(pos.add(-1, 1, 0)); } else { perform(pos.add(-1, 0, 0)); }   if ((this.breakPos.equals(pos.add(0, 0, 1)) || this.breakPos.equals(pos.add(0, 1, 1))) && isAir(pos.add(0, 0, 1)) && isAir(pos.add(0, 1, 1))) if (this.breakPos.equals(pos.add(0, 0, 1))) { perform(pos.add(0, 1, 1)); } else { perform(pos.add(0, 0, 1)); }   if ((this.breakPos.equals(pos.add(0, 0, -1)) || this.breakPos.equals(pos.add(0, 1, -1))) && isAir(pos.add(0, 0, -1)) && isAir(pos.add(0, 1, -1))) if (this.breakPos.equals(pos.add(0, 0, -1))) { perform(pos.add(0, 1, -1)); } else { perform(pos.add(0, 0, -1)); }   }  if (noHard(getBlock(pos.add(1, 0, 0)).getBlock())) { if (this.place == 1) { perform(pos.add(2, 0, 0)); perform(pos.add(1, 0, 1)); perform(pos.add(1, 0, -1)); perform(pos.add(1, 1, 0)); }  if (this.place == 5 || this.place == 9 || this.place == 13 || this.place == 14) perform(pos.add(1, 0, 0));  }  if (noHard(getBlock(pos.add(-1, 0, 0)).getBlock())) { if (this.place == 2) { perform(pos.add(-2, 0, 0)); perform(pos.add(-1, 0, 1)); perform(pos.add(-1, 0, -1)); perform(pos.add(-1, 1, 0)); }  if (this.place == 6 || this.place == 10 || this.place == 15 || this.place == 16) perform(pos.add(-1, 0, 0));  }  if (noHard(getBlock(pos.add(0, 0, 1)).getBlock())) { if (this.place == 3) { perform(pos.add(0, 0, 2)); perform(pos.add(1, 0, 1)); perform(pos.add(-1, 0, 1)); perform(pos.add(0, 1, 1)); }  if (this.place == 7 || this.place == 11 || this.place == 13 || this.place == 15) perform(pos.add(0, 0, 1));  }  if (noHard(getBlock(pos.add(0, 0, -1)).getBlock())) { if (this.place == 4) { perform(pos.add(0, 0, -2)); perform(pos.add(1, 0, -1)); perform(pos.add(-1, 0, -1)); perform(pos.add(0, 1, -1)); }  if (this.place == 8 || this.place == 12 || this.place == 14 || this.place == 16) perform(pos.add(0, 0, -1));  }  if (noHard(getBlock(pos.add(0, 1, 0)).getBlock())) { if (this.place == 17) { perform(pos.add(0, 2, 0)); perform(pos.add(0, 1, -1)); perform(pos.add(0, 1, 1)); perform(pos.add(1, 1, 0)); perform(pos.add(-1, 1, 0)); }  if (this.place == 9 || this.place == 10 || this.place == 11 || this.place == 12 || this.place > 17) perform(pos.add(0, 1, 0));  }  this.place = 0; } private void perform(BlockPos pos) { if (this.placed >= ((Integer)this.bpt.getValue()).intValue())
/* 309 */       return;  if (PlayerCheck(pos) || !CanPlace(pos)) {
/*     */       return;
/*     */     }
/* 312 */     int old = mc.player.inventory.currentItem;
/* 313 */     switchTo(this.obsidian);
/* 314 */     BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 315 */     switchTo(old);
/* 316 */     this.placed++; }
/*     */   
/*     */   public boolean CanPlace(BlockPos block) {
/* 319 */     for (EnumFacing face : EnumFacing.VALUES) {
/* 320 */       if (isReplaceable(block) && !BlockUtil.airBlocks.contains(getBlock(block.offset(face))) && mc.player.getDistanceSq(block) <= MathUtil.square(5.0D)) {
/* 321 */         return true;
/*     */       }
/*     */     } 
/* 324 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isReplaceable(BlockPos pos) {
/* 328 */     return BlockUtil.getState(pos).getMaterial().isReplaceable();
/*     */   }
/*     */   
/*     */   private boolean isAir(BlockPos block) {
/* 332 */     return (mc.world.getBlockState(block).getBlock() == Blocks.AIR);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean PlayerCheck(BlockPos pos) {
/* 337 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 338 */       if (entity instanceof EntityPlayer) {
/* 339 */         return true;
/*     */       }
/*     */     } 
/* 342 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
