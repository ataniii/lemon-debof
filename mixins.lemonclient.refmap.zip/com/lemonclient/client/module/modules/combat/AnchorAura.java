//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;@Declaration(name = "AnchorAura", category = Category.Combat, priority = 999)
/*     */ public class AnchorAura extends Module { ModeSetting page;
/*     */   BooleanSetting predict;
/*     */   BooleanSetting selfPredict;
/*     */   DoubleSetting resetRotate;
/*     */   BooleanSetting detect;
/*     */   IntegerSetting startTick;
/*     */   IntegerSetting addTick;
/*     */   IntegerSetting tickPredict;
/*     */   BooleanSetting calculateYPredict;
/*     */   IntegerSetting startDecrease;
/*     */   IntegerSetting exponentStartDecrease;
/*     */   IntegerSetting decreaseY;
/*     */   IntegerSetting exponentDecreaseY;
/*     */   BooleanSetting splitXZ;
/*     */   BooleanSetting manualOutHole;
/*     */   BooleanSetting aboveHoleManual;
/*     */   BooleanSetting stairPredict;
/*     */   IntegerSetting nStair;
/*     */   DoubleSetting speedActivationStair;
/*     */   ModeSetting targetMode;
/*     */   DoubleSetting smartHealth;
/*     */   BooleanSetting packetPlace;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting packetSwing;
/*     */   BooleanSetting rotate;
/*     */   IntegerSetting calcDelay;
/*     */   IntegerSetting updateDelay;
/*     */   IntegerSetting placeDelay;
/*     */   DoubleSetting range;
/*     */   DoubleSetting yRange;
/*     */   IntegerSetting enemyRange;
/*     */   IntegerSetting maxEnemies;
/*     */   BooleanSetting placeInAir;
/*     */   DoubleSetting minDmg;
/*     */   BooleanSetting ignore;
/*     */   DoubleSetting maxSelfDmg;
/*     */   BooleanSetting suicide;
/*     */   
/*     */   public AnchorAura() {
/*  41 */     this.page = registerMode("Page", Arrays.asList(new String[] { "Target", "General", "Delay", "Base", "Calc", "SlowFacePlace", "Switch", "Render" }, ), "General");
/*     */     
/*  43 */     this.predict = registerBoolean("Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  44 */     this.selfPredict = registerBoolean("Predict Self", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  45 */     this.resetRotate = registerDouble("Reset Yaw Difference", 15.0D, 0.0D, 180.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  46 */     this.detect = registerBoolean("Detect Ping", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  47 */     this.startTick = registerInteger("Start Tick", 2, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  48 */     this.addTick = registerInteger("Add Tick", 4, 0, 10, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  49 */     this.tickPredict = registerInteger("Max Predict Ticks", 10, 0, 30, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Target") && !((Boolean)this.detect.getValue()).booleanValue())));
/*  50 */     this.calculateYPredict = registerBoolean("Calculate Y Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  51 */     this.startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  52 */     this.exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  53 */     this.decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  54 */     this.exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  55 */     this.splitXZ = registerBoolean("Split XZ", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  56 */     this.manualOutHole = registerBoolean("Manual Out Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  57 */     this.aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> Boolean.valueOf((((Boolean)this.manualOutHole.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  58 */     this.stairPredict = registerBoolean("Stair Predict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  59 */     this.nStair = registerInteger("N Stair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  60 */     this.speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*     */     
/*  62 */     this.targetMode = registerMode("Target", Arrays.asList(new String[] { "Nearest", "Damage", "Health", "Smart" }, ), "Nearest", () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  63 */     this.smartHealth = registerDouble("Smart Health", 16.0D, 0.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("General") && ((String)this.targetMode.getValue()).equals("Smart"))));
/*  64 */     this.packetPlace = registerBoolean("Packet Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  65 */     this.swing = registerBoolean("Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  66 */     this.packetSwing = registerBoolean("Packet Swing", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*  67 */     this.rotate = registerBoolean("Rotate", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("General")));
/*     */     
/*  69 */     this.calcDelay = registerInteger("Calc Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*  70 */     this.updateDelay = registerInteger("Update Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*  71 */     this.placeDelay = registerInteger("Place Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Delay")));
/*     */     
/*  73 */     this.range = registerDouble("Place Range", 5.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  74 */     this.yRange = registerDouble("Y Range", 2.5D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  75 */     this.enemyRange = registerInteger("Enemy Range", 10, 0, 16, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  76 */     this.maxEnemies = registerInteger("Max Calc Enemies", 5, 0, 25, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  77 */     this.placeInAir = registerBoolean("Place In Air", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Base")));
/*  78 */     this.minDmg = registerDouble("Min Damage", 8.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  79 */     this.ignore = registerBoolean("Ignore Self Dmg", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  80 */     this.maxSelfDmg = registerDouble("Max Self Dmg", 10.0D, 1.0D, 36.0D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Calc") && !((Boolean)this.ignore.getValue()).booleanValue())));
/*  81 */     this.suicide = registerBoolean("Anti Suicide", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  82 */     this.balance = registerDouble("Health Balance", 2.5D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  83 */     this.facePlaceValue = registerInteger("FacePlace HP", 8, 0, 36, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  84 */     this.fpMinDmg = registerDouble("FP Min Damage", 1.0D, 0.0D, 36.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  85 */     this.forcePlace = registerBoolean("Force Place", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Calc")));
/*  86 */     this.update = registerBoolean("Update", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*  87 */     this.packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Switch")));
/*     */     
/*  89 */     this.slowFP = registerBoolean("Slow Face Place", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SlowFacePlace")));
/*  90 */     this.slowPlaceDelay = registerInteger("SlowFP Place Delay", 500, 0, 1000, () -> Boolean.valueOf((((Boolean)this.slowFP.getValue()).booleanValue() && ((String)this.page.getValue()).equals("SlowFacePlace"))));
/*  91 */     this.slowMinDmg = registerDouble("SlowFP Min Dmg", 0.05D, 0.0D, 36.0D, () -> Boolean.valueOf((((Boolean)this.slowFP.getValue()).booleanValue() && ((String)this.page.getValue()).equals("SlowFacePlace"))));
/*     */     
/*  93 */     this.showDamage = registerBoolean("Render Dmg", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  94 */     this.color = registerColor("Color", new GSColor(255, 0, 0, 50), () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  95 */     this.alpha = registerInteger("Alpha", 60, 0, 255, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  96 */     this.outAlpha = registerInteger("Outline Alpha", 120, 0, 255, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  97 */     this.width = registerInteger("Width", 1, 1, 10, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  98 */     this.anime = registerBoolean("Animation", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/*  99 */     this.movingPlaceSpeed = registerDouble("Moving Speed", 0.1D, 0.01D, 0.5D, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.anime.getValue()).booleanValue())));
/* 100 */     this.reset = registerBoolean("Reset", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Render") && ((Boolean)this.anime.getValue()).booleanValue())));
/* 101 */     this.hudDisplay = registerMode("HUD", Arrays.asList(new String[] { "Target", "Damage", "Both", "None" }, ), "None", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Render")));
/* 102 */     this.playerSpeed = new HashMap<>();
/* 103 */     this.target = null;
/*     */ 
/*     */     
/* 106 */     this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/* 107 */     this.lastBestPlace = null;
/* 108 */     this.lastBestPos = null;
/* 109 */     this.calctiming = new Timing();
/* 110 */     this.timing = new Timing();
/* 111 */     this.updatetiming = new Timing();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.postSendListener = new Listener(event -> { if (event.getPacket() instanceof CPacketHeldItemChange) this.nowSlot = ((CPacketHeldItemChange)event.getPacket()).getSlotId();  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     this.sendListener = new Listener(event -> { if (((Boolean)this.rotate.getValue()).booleanValue() && this.rotation != null) { if (event.getPacket() instanceof CPacketPlayer.Rotation) { ((CPacketPlayer.Rotation)event.getPacket()).yaw = this.rotation.x; ((CPacketPlayer.Rotation)event.getPacket()).pitch = this.rotation.y; }  if (event.getPacket() instanceof CPacketPlayer.PositionRotation) { ((CPacketPlayer.PositionRotation)event.getPacket()).yaw = this.rotation.x; ((CPacketPlayer.PositionRotation)event.getPacket()).pitch = this.rotation.y; }  }  }new java.util.function.Predicate[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     this.onUpdateWalkingPlayerEventListener = new Listener(event -> { if (!((Boolean)this.rotate.getValue()).booleanValue() || this.rotation == null || event.getPhase() != Phase.PRE) return;  PlayerPacket packet = new PlayerPacket(this, this.rotation); PlayerPacketManager.INSTANCE.addPacket(packet); }new java.util.function.Predicate[0]);
/*     */   } DoubleSetting balance; IntegerSetting facePlaceValue; DoubleSetting fpMinDmg; BooleanSetting forcePlace; BooleanSetting update; BooleanSetting packetSwitch; BooleanSetting slowFP; IntegerSetting slowPlaceDelay; DoubleSetting slowMinDmg; BooleanSetting showDamage; ColorSetting color; IntegerSetting alpha; IntegerSetting outAlpha; IntegerSetting width; BooleanSetting anime; DoubleSetting movingPlaceSpeed; BooleanSetting reset; ModeSetting hudDisplay; HashMap<EntityPlayer, MoveRotation> playerSpeed; EntityInfo target; BlockPos placePos; float damage; float selfDamage; Vec3d movingPosNow; BlockPos lastBestPlace; BlockPos lastBestPos; Timing calctiming; Timing timing; Timing updatetiming; int anchorSlot; int glowSlot; int maxPredict; Vec2f rotation; int nowSlot; @EventHandler
/*     */   private final Listener<PacketEvent.Send> postSendListener; @EventHandler
/*     */   private final Listener<PacketEvent.Send> sendListener; @EventHandler
/*     */   private final Listener<OnUpdateWalkingPlayerEvent> onUpdateWalkingPlayerEventListener; public static boolean isAnchor(ItemStack stack) {
/*     */     return (stack.getItem() instanceof ItemBlock && ((ItemBlock)stack.getItem()).getBlock() instanceof net.minecraft.block.BlockObsidian && stack.getDisplayName().equals("§f1.16 Respawn Anchor"));
/*     */   }
/*     */   public void onUpdate() {
/* 148 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether() || this.anchorSlot == -1 || this.glowSlot == -1) {
/* 149 */       this.target = null;
/* 150 */       this.placePos = null;
/* 151 */       this.damage = this.selfDamage = 0.0F;
/* 152 */       this.rotation = null;
/*     */       
/*     */       return;
/*     */     } 
/* 156 */     for (EntityPlayer player : mc.world.playerEntities) {
/* 157 */       if (mc.player.getDistanceSq((Entity)player) > (((Integer)this.enemyRange.getValue()).intValue() * ((Integer)this.enemyRange.getValue()).intValue()))
/* 158 */         continue;  double lastYaw = 512.0D;
/* 159 */       int tick = ((Integer)this.startTick.getValue()).intValue();
/* 160 */       if (this.playerSpeed.get(player) != null) {
/* 161 */         MoveRotation info = this.playerSpeed.get(player);
/* 162 */         lastYaw = info.yaw;
/* 163 */         tick = info.tick + ((Integer)this.addTick.getValue()).intValue();
/*     */       } 
/* 165 */       if (tick > this.maxPredict) tick = this.maxPredict; 
/* 166 */       this.playerSpeed.put(player, new MoveRotation(player, lastYaw, tick));
/*     */     } 
/*     */     
/* 169 */     calc();
/*     */   }
/*     */ 
/*     */   
/*     */   public void fast() {
/* 174 */     if (mc.player == null || mc.world == null || EntityUtil.isDead((Entity)mc.player) || inNether()) {
/*     */       return;
/*     */     }
/* 177 */     if (this.updatetiming.passedMs(((Integer)this.updateDelay.getValue()).intValue())) {
/* 178 */       this.updatetiming.reset();
/* 179 */       this.maxPredict = ((Boolean)this.detect.getValue()).booleanValue() ? (int)((mc.getCurrentServerData() == null) ? 0L : ((mc.getCurrentServerData()).pingToServer * 2L / 50L)) : ((Integer)this.tickPredict.getValue()).intValue();
/*     */     } 
/*     */     
/* 182 */     this.anchorSlot = this.glowSlot = -1;
/* 183 */     for (int i = 0; i < 9; i++) {
/* 184 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */       
/* 186 */       if (this.anchorSlot == -1 && isAnchor(stack)) {
/* 187 */         this.anchorSlot = i;
/*     */       }
/* 189 */       if (this.glowSlot == -1 && stack.getItem() instanceof ItemBlock && ((ItemBlock)stack.getItem()).getBlock() instanceof net.minecraft.block.BlockGlowstone) {
/* 190 */         this.glowSlot = i;
/*     */       }
/*     */     } 
/*     */     
/* 194 */     if (this.anchorSlot == -1 || this.glowSlot == -1)
/*     */       return; 
/* 196 */     bedaura();
/*     */   }
/*     */   
/*     */   private void bedaura() {
/* 200 */     if (this.placePos == null)
/* 201 */       return;  this.rotation = RotationUtil.getRotationTo(new Vec3d(this.placePos.x + 0.5D, this.placePos.y + 0.5D, this.placePos.z + 0.5D));
/* 202 */     place();
/*     */   }
/*     */   
/*     */   private void calc() {
/* 206 */     if (this.calctiming.passedMs(((Integer)this.calcDelay.getValue()).intValue())) {
/* 207 */       this.calctiming.reset();
/*     */       
/* 209 */       this.target = null;
/* 210 */       this.placePos = null;
/* 211 */       this.damage = this.selfDamage = 0.0F;
/* 212 */       this.rotation = null;
/*     */       
/* 214 */       EntityInfo self = new EntityInfo((EntityPlayer)mc.player, ((Boolean)this.selfPredict.getValue()).booleanValue());
/* 215 */       PlaceInfo placeInfo = getPlaceInfo(self, findBlocksExcluding());
/*     */       
/* 217 */       if (placeInfo == null)
/* 218 */         return;  this.target = placeInfo.target;
/* 219 */       if (ModuleManager.isModuleEnabled("AutoEz")) {
/* 220 */         AutoEz.INSTANCE.addTargetedPlayer(this.target.defaultPlayer.getName());
/*     */       }
/* 222 */       BlockPos bedPos = placeInfo.placePos;
/* 223 */       if (bedPos == null)
/*     */         return; 
/* 225 */       this.damage = placeInfo.damage;
/* 226 */       this.selfDamage = placeInfo.selfDamage;
/* 227 */       this.placePos = bedPos;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void place() {
/* 232 */     if (this.timing.passedMs(getPlaceDelay())) {
/* 233 */       EnumFacing side = BurrowUtil.getFirstFacing(this.placePos);
/* 234 */       if (side == null)
/* 235 */         if (((Boolean)this.placeInAir.getValue()).booleanValue()) { side = EnumFacing.DOWN; }
/*     */         else
/*     */         { return; }
/* 238 */           BlockPos neighbour = this.placePos.offset(side);
/* 239 */       EnumFacing opposite = side.getOpposite();
/*     */       
/* 241 */       Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 242 */       if (BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) && !ColorMain.INSTANCE.sneaking) {
/* 243 */         mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */       }
/* 245 */       int oldSlot = mc.player.inventory.currentItem;
/*     */       
/* 247 */       if (oldSlot != this.anchorSlot) switchTo(this.anchorSlot); 
/* 248 */       if (((Boolean)this.packetPlace.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(neighbour, EnumFacing.UP, EnumHand.MAIN_HAND, 0.5F, 1.0F, 0.5F)); }
/* 249 */       else { mc.playerController.processRightClickBlock(mc.player, mc.world, neighbour, EnumFacing.UP, hitVec, EnumHand.MAIN_HAND); }
/*     */       
/* 251 */       if (((ColorMain)ModuleManager.getModule(ColorMain.class)).sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */       
/* 253 */       side = EnumFacing.UP;
/* 254 */       Vec3d facing = getHitVecOffset(side);
/*     */       
/* 256 */       switchTo(this.glowSlot);
/* 257 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placePos, side, EnumHand.MAIN_HAND, (float)facing.x, (float)facing.y, (float)facing.z));
/*     */       
/* 259 */       if (oldSlot == this.glowSlot) { switchTo(this.anchorSlot); }
/* 260 */       else { switchTo(oldSlot); }
/*     */       
/* 262 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(this.placePos, side, EnumHand.MAIN_HAND, (float)facing.x, (float)facing.y, (float)facing.z));
/*     */       
/* 264 */       if (((Boolean)this.swing.getValue()).booleanValue()) swing(); 
/* 265 */       this.timing.reset();
/*     */     }  } private PlaceInfo getPlaceInfo(EntityInfo self, List<BlockPos> posList) { EntityPlayer entityPlayer; PlaceInfo best; List<EntityPlayer> players;
/*     */     EntityPlayer target, player;
/*     */     PlaceInfo placeInfo1;
/*     */     double health;
/* 270 */     PlaceInfo placeInfo = null;
/* 271 */     List<EntityPlayer> playerList = PlayerUtil.getNearPlayers(((Integer)this.enemyRange.getValue()).intValue(), ((Integer)this.maxEnemies.getValue()).intValue());
/* 272 */     switch ((String)this.targetMode.getValue()) {
/*     */       case "Nearest":
/* 274 */         entityPlayer = playerList.stream().min(Comparator.comparing(p -> Float.valueOf(mc.player.getDistance((Entity)p)))).orElse(null);
/* 275 */         if (entityPlayer != null) {
/* 276 */           EntityInfo entityInfo = new EntityInfo(entityPlayer, ((Boolean)this.predict.getValue()).booleanValue());
/* 277 */           placeInfo = calculateBestPlacement(entityInfo, self, posList);
/*     */         } 
/*     */         break;
/*     */       
/*     */       case "Damage":
/* 282 */         best = null;
/* 283 */         for (EntityPlayer entityPlayer1 : playerList) {
/* 284 */           if (entityPlayer1 != null) {
/* 285 */             EntityInfo entityInfo = new EntityInfo(entityPlayer1, ((Boolean)this.predict.getValue()).booleanValue());
/* 286 */             PlaceInfo info = calculateBestPlacement(entityInfo, self, posList);
/* 287 */             if (best == null || info.damage > best.damage) {
/* 288 */               best = info;
/*     */             }
/*     */           } 
/*     */         } 
/* 292 */         placeInfo = best;
/*     */         break;
/*     */       
/*     */       case "Health":
/* 296 */         health = 37.0D;
/* 297 */         player = null;
/* 298 */         for (EntityPlayer entityPlayer1 : playerList) {
/* 299 */           if (player == null || health > (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount())) {
/* 300 */             player = entityPlayer1;
/* 301 */             health = (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount());
/*     */           } 
/*     */         } 
/* 304 */         if (player != null) {
/* 305 */           placeInfo = calculateBestPlacement(new EntityInfo(player, ((Boolean)this.predict.getValue()).booleanValue()), self, posList);
/*     */         }
/*     */         break;
/*     */       
/*     */       case "Smart":
/* 310 */         players = new ArrayList<>();
/* 311 */         for (EntityPlayer entityPlayer1 : playerList) {
/* 312 */           if (((Double)this.smartHealth.getValue()).doubleValue() >= (entityPlayer1.getHealth() + entityPlayer1.getAbsorptionAmount())) {
/* 313 */             players.add(entityPlayer1);
/*     */           }
/*     */         } 
/* 316 */         target = players.stream().min(Comparator.comparing(p -> Float.valueOf(p.getHealth() + p.getAbsorptionAmount()))).orElse(null);
/* 317 */         placeInfo1 = null;
/* 318 */         if (target != null) {
/* 319 */           EntityInfo entityInfo = new EntityInfo(target, ((Boolean)this.predict.getValue()).booleanValue());
/* 320 */           placeInfo1 = calculateBestPlacement(entityInfo, self, posList);
/*     */         } 
/* 322 */         if (placeInfo1 == null) {
/* 323 */           for (EntityPlayer entityPlayer1 : playerList) {
/* 324 */             if (entityPlayer1 != null) {
/* 325 */               EntityInfo entityInfo = new EntityInfo(entityPlayer1, ((Boolean)this.predict.getValue()).booleanValue());
/* 326 */               PlaceInfo info = calculateBestPlacement(entityInfo, self, posList);
/* 327 */               if (placeInfo1 == null || info.damage > placeInfo1.damage) {
/* 328 */                 placeInfo1 = info;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/* 333 */         placeInfo = placeInfo1;
/*     */         break;
/*     */     } 
/*     */     
/* 337 */     return placeInfo; }
/*     */ 
/*     */   
/*     */   private List<BlockPos> findBlocksExcluding() {
/* 341 */     return (List<BlockPos>)EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), (Double)this.yRange.getValue(), false, false, 0).stream().filter(this::block).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private PlaceInfo calculateBestPlacement(EntityInfo target, EntityInfo self, List<BlockPos> blocks) {
/* 345 */     PlaceInfo best = new PlaceInfo(target, null, (float)Math.min(Math.min(((Double)this.minDmg.getValue()).doubleValue(), ((Double)this.slowMinDmg.getValue()).doubleValue()), this.fpMinDmg.getMin()), -1.0F);
/* 346 */     if (target == null || self == null) return best; 
/* 347 */     for (BlockPos pos : blocks) {
/* 348 */       double x = pos.getX() + 0.5D;
/* 349 */       double y = pos.getY() + 0.5D;
/* 350 */       double z = pos.getZ() + 0.5D;
/* 351 */       float targetDamage = DamageUtil.calculateDamage((EntityLivingBase)target.player, x, y, z, 5.0F, "Bed");
/* 352 */       if (targetDamage <= best.damage || (
/* 353 */         (target.hp > ((Integer)this.facePlaceValue.getValue()).intValue()) ? (
/* 354 */         targetDamage < ((Double)this.minDmg.getValue()).doubleValue() && (targetDamage < ((Double)this.slowMinDmg.getValue()).doubleValue() || !((Boolean)this.slowFP.getValue()).booleanValue())) : (
/* 355 */         targetDamage < ((Double)this.fpMinDmg.getValue()).doubleValue())))
/* 356 */         continue;  float selfDamage = 0.0F;
/* 357 */       if (!self.player.isCreative()) {
/* 358 */         selfDamage = DamageUtil.calculateDamage((EntityLivingBase)self.player, x, y, z, 5.0F, "Bed");
/* 359 */         if (selfDamage + ((Double)this.balance.getValue()).doubleValue() > ((Double)this.maxSelfDmg.getValue()).doubleValue() && (
/* 360 */           (targetDamage >= target.hp) ? 
/* 361 */           !((Boolean)this.forcePlace.getValue()).booleanValue() : 
/* 362 */           !((Boolean)this.ignore.getValue()).booleanValue()))
/*     */           continue; 
/* 364 */         if (((Boolean)this.suicide.getValue()).booleanValue() && selfDamage + ((Double)this.balance.getValue()).doubleValue() >= self.hp)
/*     */           continue; 
/* 366 */       }  best = new PlaceInfo(target, pos, targetDamage, selfDamage);
/*     */     } 
/*     */     
/* 369 */     return best;
/*     */   }
/*     */   
/*     */   private int getPlaceDelay() {
/* 373 */     if (this.damage >= ((Double)this.minDmg.getValue()).doubleValue()) return ((Integer)this.placeDelay.getValue()).intValue(); 
/* 374 */     return ((Integer)this.slowPlaceDelay.getValue()).intValue();
/*     */   }
/*     */   
/*     */   private boolean block(BlockPos pos) {
/* 378 */     return (BlockUtil.canReplace(pos) && inRange(pos));
/*     */   }
/*     */   
/*     */   private boolean inRange(BlockPos pos) {
/* 382 */     double x = pos.x - mc.player.posX;
/* 383 */     double z = pos.z - mc.player.posZ;
/* 384 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/* 385 */     double add = Math.sqrt(y * y) / 2.0D;
/* 386 */     return (x * x + z * z <= (((Double)this.range.getValue()).doubleValue() - add) * (((Double)this.range.getValue()).doubleValue() - add) && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue());
/*     */   }
/*     */   private Vec3d getHitVecOffset(EnumFacing face) {
/* 389 */     Vec3i vec = face.getDirectionVec();
/* 390 */     return new Vec3d((vec.x * 0.5F + 0.5F), (vec.y * 0.5F + 0.5F), (vec.z * 0.5F + 0.5F));
/*     */   }
/*     */   
/*     */   private void switchTo(int slot) {
/* 394 */     if (slot > -1 && slot < 9) {
/* 395 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 396 */       else { mc.player.inventory.currentItem = slot; }
/* 397 */        if (((Boolean)this.update.getValue()).booleanValue()) mc.playerController.updateController(); 
/* 398 */       mc.player.openContainer.detectAndSendChanges();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void swing() {
/* 403 */     if (((Boolean)this.packetSwing.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND)); }
/* 404 */     else { mc.player.swingArm(EnumHand.MAIN_HAND); }
/*     */   
/*     */   }
/*     */   private boolean inNether() {
/* 408 */     return (mc.player.dimension == -1);
/*     */   }
/*     */   
/*     */   public void onEnable() {
/* 412 */     this.calctiming.reset();
/* 413 */     this.timing.reset();
/* 414 */     this.updatetiming.reset();
/* 415 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/* 416 */       this.lastBestPlace = null;
/* 417 */       this.lastBestPos = null;
/* 418 */       this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 423 */     this.placePos = null;
/* 424 */     if (((Boolean)this.reset.getValue()).booleanValue()) {
/* 425 */       this.lastBestPlace = null;
/* 426 */       this.lastBestPos = null;
/* 427 */       this.movingPosNow = new Vec3d(-1.0D, -1.0D, -1.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/* 432 */     if (mc.world == null || mc.player == null) {
/*     */       return;
/*     */     }
/* 435 */     if (this.placePos != null) {
/* 436 */       if (((Boolean)this.anime.getValue()).booleanValue()) { this.lastBestPlace = this.placePos; }
/* 437 */       else { drawBoxMain(this.placePos.x, this.placePos.y, this.placePos.z); }
/*     */     
/*     */     }
/* 440 */     if (!((Boolean)this.anime.getValue()).booleanValue())
/* 441 */       return;  if (this.lastBestPlace != null) {
/* 442 */       if (this.movingPosNow.x == -1.0D && this.movingPosNow.y == -1.0D && this.movingPosNow.z == -1.0D) {
/* 443 */         this.movingPosNow = new Vec3d(this.lastBestPlace.getX(), this.lastBestPlace.getY(), this.lastBestPlace.getZ());
/*     */       }
/*     */       
/* 446 */       this
/*     */ 
/*     */         
/* 449 */         .movingPosNow = new Vec3d(this.movingPosNow.x + (this.lastBestPlace.getX() - this.movingPosNow.x) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPosNow.y + (this.lastBestPlace.getY() - this.movingPosNow.y) * ((Double)this.movingPlaceSpeed.getValue()).floatValue(), this.movingPosNow.z + (this.lastBestPlace.getZ() - this.movingPosNow.z) * ((Double)this.movingPlaceSpeed.getValue()).floatValue());
/*     */ 
/*     */ 
/*     */       
/* 453 */       if (Math.abs(this.movingPosNow.x - this.lastBestPlace.getX()) <= 0.125D && Math.abs(this.movingPosNow.y - this.lastBestPlace.getY()) <= 0.125D && Math.abs(this.movingPosNow.z - this.lastBestPlace.getZ()) <= 0.125D) {
/* 454 */         this.lastBestPlace = null;
/*     */       }
/*     */     } 
/*     */     
/* 458 */     if (this.movingPosNow.x != -1.0D && this.movingPosNow.y != -1.0D && this.movingPosNow.z != -1.0D) drawBoxMain(this.movingPosNow.x, this.movingPosNow.y, this.movingPosNow.z);
/*     */   
/*     */   }
/*     */   
/*     */   AxisAlignedBB getBox(double x, double y, double z) {
/* 463 */     double maxX = x + 1.0D;
/* 464 */     double maxZ = z + 1.0D;
/*     */     
/* 466 */     return new AxisAlignedBB(x, y, z, maxX, y + 1.0D, maxZ);
/*     */   }
/*     */   
/*     */   void drawBoxMain(double x, double y, double z) {
/* 470 */     AxisAlignedBB box = getBox(x, y, z);
/*     */     
/* 472 */     RenderUtil.drawBox(box, true, 1.0D, new GSColor(this.color.getValue(), ((Integer)this.alpha.getValue()).intValue()), 63);
/* 473 */     RenderUtil.drawBoundingBox(box, ((Integer)this.width.getValue()).intValue(), new GSColor(this.color.getValue(), ((Integer)this.outAlpha.getValue()).intValue()));
/*     */     
/* 475 */     if (((Boolean)this.showDamage.getValue()).booleanValue()) {
/* 476 */       box = getBox(x, y, z);
/* 477 */       String[] damageText = { String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) };
/* 478 */       RenderUtil.drawNametag(box.minX + 0.5D, box.minY + 0.5D, box.minZ + 0.5D, damageText, new GSColor(255, 255, 255), 1, 0.02666666666666667D, 0.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getHudInfo() {
/*     */     EntityPlayer entityPlayer;
/* 484 */     Entity currentTarget = null;
/* 485 */     if (this.target != null) {
/* 486 */       entityPlayer = this.target.defaultPlayer;
/*     */     }
/* 488 */     boolean isNull = (entityPlayer == null);
/* 489 */     switch ((String)this.hudDisplay.getValue()) {
/*     */       case "Target":
/* 491 */         return isNull ? ("[" + ChatFormatting.WHITE + "None" + ChatFormatting.GRAY + "]") : ("[" + ChatFormatting.WHITE + entityPlayer
/* 492 */           .getName() + ChatFormatting.GRAY + "]");
/*     */       
/*     */       case "Damage":
/* 495 */         return "[" + ChatFormatting.WHITE + String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) + ChatFormatting.GRAY + "]";
/*     */       
/*     */       case "Both":
/* 498 */         return "[" + ChatFormatting.WHITE + (isNull ? "None" : entityPlayer.getName()) + " " + 
/* 499 */           String.format("%.1f", new Object[] { Float.valueOf(this.damage) }) + ChatFormatting.GRAY + "]";
/*     */     } 
/*     */     
/* 502 */     return "";
/*     */   }
/*     */   class PlaceInfo { AnchorAura.EntityInfo target;
/*     */     BlockPos placePos;
/*     */     float damage;
/*     */     float selfDamage;
/*     */     
/*     */     public PlaceInfo(AnchorAura.EntityInfo target, BlockPos placePos, float damage, float selfDamage) {
/* 510 */       this.target = target;
/* 511 */       this.placePos = placePos;
/* 512 */       this.damage = damage;
/* 513 */       this.selfDamage = selfDamage;
/*     */     } }
/*     */ 
/*     */   
/*     */   class EntityInfo {
/* 518 */     EntityPlayer player = null; EntityPlayer defaultPlayer = null; double hp;
/*     */     
/*     */     public EntityInfo(EntityPlayer player, boolean predict) {
/* 521 */       if (player == null)
/* 522 */         return;  this.defaultPlayer = player;
/* 523 */       this.player = predict ? PredictUtil.predictPlayer((EntityLivingBase)player, new PredictUtil.PredictSettings(((AnchorAura.MoveRotation)AnchorAura.this.playerSpeed.get(player)).tick, ((Boolean)AnchorAura.this.calculateYPredict.getValue()).booleanValue(), ((Integer)AnchorAura.this.startDecrease.getValue()).intValue(), ((Integer)AnchorAura.this.exponentStartDecrease.getValue()).intValue(), ((Integer)AnchorAura.this.decreaseY.getValue()).intValue(), ((Integer)AnchorAura.this.exponentDecreaseY.getValue()).intValue(), ((Boolean)AnchorAura.this.splitXZ.getValue()).booleanValue(), ((Boolean)AnchorAura.this.manualOutHole.getValue()).booleanValue(), ((Boolean)AnchorAura.this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)AnchorAura.this.stairPredict.getValue()).booleanValue(), ((Integer)AnchorAura.this.nStair.getValue()).intValue(), ((Double)AnchorAura.this.speedActivationStair.getValue()).doubleValue())) : player;
/* 524 */       this.hp = (player.getHealth() + player.getAbsorptionAmount());
/*     */     } }
/*     */   
/*     */   class MoveRotation {
/*     */     double yaw;
/*     */     double lastYaw;
/*     */     int tick;
/*     */     
/*     */     public MoveRotation(EntityPlayer player, double lastYaw, int tick) {
/* 533 */       this.yaw = (RotationUtil.getRotationTo(player.getPositionVector(), new Vec3d(player.prevPosX, player.prevPosY, player.prevPosZ))).x;
/* 534 */       this.lastYaw = lastYaw;
/* 535 */       double difference = this.yaw - lastYaw;
/* 536 */       if ((lastYaw != 512.0D && (difference > ((Double)AnchorAura.this.resetRotate.getValue()).doubleValue() || difference < -((Double)AnchorAura.this.resetRotate.getValue()).doubleValue())) || LemonClient.speedUtil.getPlayerSpeed(player) == 0.0D) {
/* 537 */         this.tick = 0;
/*     */         return;
/*     */       } 
/* 540 */       this.tick = tick;
/*     */     }
/*     */   } }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AnchorAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
