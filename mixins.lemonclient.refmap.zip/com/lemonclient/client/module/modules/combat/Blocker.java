//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.UnmodifiableIterator;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlacementUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.SpoofRotationUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.combat.CrystalUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockRedstoneTorch;
/*     */ import net.minecraft.block.BlockSkull;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityFallingBlock;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "Blocker", category = Category.Combat)
/*     */ public class Blocker extends Module {
/*  41 */   ModeSetting time = registerMode("Time Mode", Arrays.asList(new String[] { "Tick", "onUpdate", "Both", "Fast" }, ), "Tick");
/*  42 */   ModeSetting breakType = registerMode("Type", Arrays.asList(new String[] { "Vanilla", "Packet" }, ), "Vanilla");
/*  43 */   BooleanSetting packet = registerBoolean("Packet Place", false);
/*  44 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  45 */   BooleanSetting rotate = registerBoolean("Rotate", true);
/*  46 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  47 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*  48 */   BooleanSetting anvilBlocker = registerBoolean("Anvil", true);
/*  49 */   BooleanSetting fallingBlocks = registerBoolean("Block FallingBlocks", true);
/*  50 */   BooleanSetting trap = registerBoolean("Trap", true, () -> (Boolean)this.fallingBlocks.getValue());
/*  51 */   ModeSetting fallingMode = registerMode("Block Mode", Arrays.asList(new String[] { "Break", "Torch", "Skull" }, ), "Break", () -> (Boolean)this.fallingBlocks.getValue());
/*  52 */   BooleanSetting pistonBlocker = registerBoolean("Break Piston", true);
/*  53 */   BooleanSetting pistonBlockerNew = registerBoolean("Block Piston", true);
/*  54 */   BooleanSetting antiFacePlace = registerBoolean("Shift AntiFacePlace", true);
/*  55 */   ModeSetting blockPlaced = registerMode("Block Place", Arrays.asList(new String[] { "Pressure", "String" }, ), "String", () -> (Boolean)this.antiFacePlace.getValue());
/*  56 */   IntegerSetting BlocksPerTick = registerInteger("Blocks Per Tick", 4, 0, 10);
/*  57 */   IntegerSetting tickDelay = registerInteger("Tick Delay", 5, 0, 10);
/*  58 */   DoubleSetting range = registerDouble("Range", 5.0D, 0.0D, 10.0D);
/*  59 */   DoubleSetting yrange = registerDouble("YRange", 5.0D, 0.0D, 10.0D);
/*  60 */   List<BlockPos> pistonList = new ArrayList<>();
/*  61 */   private int delayTimeTicks = 0;
/*     */   
/*  63 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/*  72 */     if (slot > -1 && slot < 9 && (
/*  73 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*  74 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/*  76 */       { mc.player.inventory.currentItem = slot; }
/*     */       
/*  78 */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  84 */     this.pistonList = new ArrayList<>();
/*  85 */     SpoofRotationUtil.ROTATION_UTIL.onEnable();
/*  86 */     PlacementUtil.onEnable();
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  90 */     SpoofRotationUtil.ROTATION_UTIL.onDisable();
/*  91 */     PlacementUtil.onDisable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  97 */     if (((String)this.time.getValue()).equals("onUpdate") || ((String)this.time.getValue()).equals("Both")) block();
/*     */   
/*     */   }
/*     */   
/*     */   public void onTick() {
/* 102 */     if (((String)this.time.getValue()).equals("Tick") || ((String)this.time.getValue()).equals("Both")) block();
/*     */   
/*     */   }
/*     */   
/*     */   public void fast() {
/* 107 */     if (((String)this.time.getValue()).equals("Fast")) block(); 
/*     */   }
/*     */   
/*     */   private void block() {
/* 111 */     if (mc.player == null || mc.world == null || mc.player.isDead) {
/* 112 */       this.pistonList.clear();
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     if (this.delayTimeTicks < ((Integer)this.tickDelay.getValue()).intValue()) {
/* 117 */       this.delayTimeTicks++;
/*     */     } else {
/* 119 */       SpoofRotationUtil.ROTATION_UTIL.shouldSpoofAngles(true);
/* 120 */       this.delayTimeTicks = 0;
/*     */       
/* 122 */       if (((Boolean)this.anvilBlocker.getValue()).booleanValue())
/* 123 */         blockAnvil(); 
/* 124 */       if (((Boolean)this.fallingBlocks.getValue()).booleanValue())
/* 125 */         blockFallingBlocks(); 
/* 126 */       if (((Boolean)this.pistonBlocker.getValue()).booleanValue())
/* 127 */         blockPiston(); 
/* 128 */       if (((Boolean)this.pistonBlockerNew.getValue()).booleanValue()) {
/* 129 */         blockPA();
/*     */       }
/* 131 */       if (((Boolean)this.antiFacePlace.getValue()).booleanValue() && mc.gameSettings.keyBindSneak.isPressed()) {
/* 132 */         antiFacePlace();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<BlockPos> posList() {
/* 138 */     return EntityUtil.getSphere(PlayerUtil.getPlayerPos(), (Double)this.range.getValue(), (Double)this.yrange.getValue(), false, false, 0);
/*     */   }
/*     */   
/*     */   private void antiFacePlace() {
/* 142 */     int blocksPlaced = 0;
/*     */     
/* 144 */     for (Vec3d surround : new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D) }) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       BlockPos pos = new BlockPos(mc.player.posX + surround.x, mc.player.posY, mc.player.posZ + surround.z); Block temp;
/* 151 */       if (temp = BlockUtil.getBlock(pos) instanceof BlockObsidian || temp == Blocks.BEDROCK) {
/*     */         
/* 153 */         if (blocksPlaced++ == 0) {
/* 154 */           InventoryUtil.getHotBarPressure((String)this.blockPlaced.getValue());
/*     */         }
/*     */         
/* 157 */         PlacementUtil.placeItem(new BlockPos(pos.getX(), pos.getY() + surround.y, pos.getZ()), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), Items.STRING.getClass());
/*     */         
/* 159 */         if (blocksPlaced == ((Integer)this.BlocksPerTick.getValue()).intValue())
/*     */           return; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void blockPA() {
/* 166 */     int slot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 167 */     if (slot == -1)
/* 168 */       return;  for (BlockPos pos : posList()) {
/* 169 */       if (!this.pistonList.contains(pos) && (mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockPistonBase || mc.world.getBlockState(pos).getBlock() == Blocks.PISTON || mc.world.getBlockState(pos).getBlock() == Blocks.STICKY_PISTON))
/* 170 */         this.pistonList.add(pos); 
/* 171 */     }  this.pistonList.removeIf(blockPos -> (mc.player.getDistanceSq(blockPos) > ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue()));
/* 172 */     if (!this.pistonList.isEmpty()) {
/* 173 */       int oldslot = mc.player.inventory.currentItem;
/* 174 */       switchTo(slot);
/* 175 */       for (BlockPos pos : this.pistonList) {
/* 176 */         BlockPos head = getHeadPos(pos);
/* 177 */         if (!BlockUtil.canReplace(pos) && !BlockUtil.canReplace(head))
/* 178 */           continue;  BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 179 */         BurrowUtil.placeBlock(head, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */       } 
/* 181 */       switchTo(oldslot);
/*     */     } 
/* 183 */     this.pistonList.removeIf(blockPos -> (mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN));
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockPos getHeadPos(BlockPos pos) {
/* 188 */     ImmutableMap<IProperty<?>, Comparable<?>> properties = mc.world.getBlockState(pos).getProperties();
/* 189 */     for (UnmodifiableIterator<IProperty> unmodifiableIterator = properties.keySet().iterator(); unmodifiableIterator.hasNext(); ) { IProperty<?> prop = unmodifiableIterator.next();
/* 190 */       if (prop.getValueClass() == EnumFacing.class && (prop.getName().equals("facing") || prop.getName().equals("rotation"))) {
/* 191 */         BlockPos pushPos = pos.offset((EnumFacing)properties.get(prop));
/* 192 */         for (BlockPos side : this.sides) {
/* 193 */           if (isPos2(pos.add((Vec3i)side), pushPos))
/* 194 */             return pos.add((Vec3i)side); 
/*     */         } 
/*     */       }  }
/*     */     
/* 198 */     return null;
/*     */   }
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 201 */     if (pos1 == null || pos2 == null)
/* 202 */       return false; 
/* 203 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void blockAnvil() {
/* 209 */     for (Entity t : mc.world.loadedEntityList) {
/*     */       
/* 211 */       if (t instanceof EntityFallingBlock) {
/* 212 */         Block ex = ((EntityFallingBlock)t).fallTile.getBlock();
/*     */         
/* 214 */         if (ex instanceof net.minecraft.block.BlockAnvil && (int)t.posX == (int)mc.player.posX && (int)t.posZ == (int)mc.player.posZ && 
/*     */ 
/*     */           
/* 217 */           BlockUtil.getBlock(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ) instanceof net.minecraft.block.BlockAir)
/*     */         {
/* 219 */           placeBlock(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void blockFallingBlocks() {
/* 227 */     for (Entity t : mc.world.loadedEntityList) {
/*     */       
/* 229 */       if (t instanceof EntityFallingBlock) {
/* 230 */         Block ex = ((EntityFallingBlock)t).fallTile.getBlock();
/*     */         
/* 232 */         if (!(ex instanceof net.minecraft.block.BlockAnvil) && (int)t.posX == (int)mc.player.posX && (int)t.posZ == (int)mc.player.posZ)
/*     */         {
/* 234 */           if ((int)t.posY > (int)mc.player.posY) {
/* 235 */             if (((Boolean)this.trap.getValue()).booleanValue()) placeBlock(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ)); 
/* 236 */             int slot = -1;
/* 237 */             switch ((String)this.fallingMode.getValue()) {
/*     */               case "Break":
/* 239 */                 mc.playerController.onPlayerDamageBlock(PlayerUtil.getPlayerPos(), EnumFacing.UP);
/*     */                 break;
/*     */               
/*     */               case "Torch":
/* 243 */                 slot = BurrowUtil.findHotbarBlock(BlockRedstoneTorch.class);
/*     */                 break;
/*     */               
/*     */               case "Skull":
/* 247 */                 slot = BurrowUtil.findHotbarBlock(BlockSkull.class);
/*     */                 break;
/*     */             } 
/*     */             
/* 251 */             if (slot != -1) {
/* 252 */               int oldslot = mc.player.inventory.currentItem;
/* 253 */               switchTo(slot);
/* 254 */               BurrowUtil.placeBlock(PlayerUtil.getPlayerPos(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 255 */               switchTo(oldslot);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void blockPiston() {
/* 266 */     for (Entity t : mc.world.loadedEntityList) {
/*     */       
/* 268 */       if (t instanceof net.minecraft.entity.item.EntityEnderCrystal && t.posX >= mc.player.posX - 1.5D && t.posX <= mc.player.posX + 1.5D && t.posZ >= mc.player.posZ - 1.5D && t.posZ <= mc.player.posZ + 1.5D)
/*     */       {
/*     */ 
/*     */         
/* 272 */         for (int i = -2; i < 3; i++) {
/* 273 */           for (int j = -2; j < 3; j++) {
/* 274 */             if (i == 0 || j == 0)
/*     */             {
/* 276 */               if (BlockUtil.getBlock(t.posX + i, t.posY, t.posZ + j) instanceof net.minecraft.block.BlockPistonBase)
/*     */               {
/* 278 */                 breakCrystalPiston(t);
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 288 */     if (!mc.world.isAirBlock(pos))
/*     */       return; 
/* 290 */     int oldslot = mc.player.inventory.currentItem;
/* 291 */     int obsidianSlot = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*     */     
/* 293 */     if (obsidianSlot == -1) {
/*     */       return;
/*     */     }
/* 296 */     switchTo(obsidianSlot);
/* 297 */     boolean isNull = true;
/* 298 */     if (BurrowUtil.getFirstFacing(pos) == null) {
/* 299 */       for (BlockPos side : this.sides) {
/* 300 */         BlockPos added = pos.add((Vec3i)side);
/* 301 */         if (!intersectsWithEntity(added) && BurrowUtil.getFirstFacing(added) != null) {
/* 302 */           BurrowUtil.placeBlock(added, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 303 */           isNull = false; break;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 307 */       isNull = false;
/* 308 */     }  if (!isNull) BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue()); 
/* 309 */     switchTo(oldslot);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 314 */     for (Entity entity : mc.world.loadedEntityList) {
/* 315 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 316 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 317 */         return true; 
/*     */     } 
/* 319 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void breakCrystalPiston(Entity crystal) {
/* 324 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 325 */       SpoofRotationUtil.ROTATION_UTIL.lookAtPacket(crystal.posX, crystal.posY, crystal.posZ, (EntityPlayer)mc.player);
/*     */     }
/* 327 */     if (((String)this.breakType.getValue()).equals("Vanilla")) {
/* 328 */       CrystalUtil.breakCrystal(crystal, ((Boolean)this.swing.getValue()).booleanValue());
/*     */     } else {
/* 330 */       CrystalUtil.breakCrystalPacket(crystal, ((Boolean)this.swing.getValue()).booleanValue());
/*     */     } 
/*     */     
/* 333 */     if (((Boolean)this.rotate.getValue()).booleanValue())
/* 334 */       SpoofRotationUtil.ROTATION_UTIL.resetRotation(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\Blocker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
