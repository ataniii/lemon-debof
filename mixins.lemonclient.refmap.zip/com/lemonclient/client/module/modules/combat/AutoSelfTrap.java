//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.PredictUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoSelfTrap", category = Category.Combat, priority = 999)
/*     */ public class AutoSelfTrap extends Module {
/*  32 */   BooleanSetting test = registerBoolean("Test", false);
/*  33 */   ModeSetting page = registerMode("Page", Arrays.asList(new String[] { "Target", "Place" }, ), "Target");
/*  34 */   ModeSetting target = registerMode("Target", Arrays.asList(new String[] { "Normal", "Predict", "Both" }, ), "Predict", () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  35 */   IntegerSetting tickPredict = registerInteger("Tick Predict", 8, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  36 */   BooleanSetting doublePredict = registerBoolean("Double Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  37 */   BooleanSetting calculateYPredict = registerBoolean("Calculate Y Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  38 */   IntegerSetting startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  39 */   IntegerSetting exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  40 */   IntegerSetting decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  41 */   IntegerSetting exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  42 */   BooleanSetting splitXZ = registerBoolean("Split XZ", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  43 */   BooleanSetting manualOutHole = registerBoolean("Manual Out Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  44 */   BooleanSetting aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> Boolean.valueOf((((Boolean)this.manualOutHole.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  45 */   BooleanSetting stairPredict = registerBoolean("Stair Predict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  46 */   IntegerSetting nStair = registerInteger("N Stair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  47 */   DoubleSetting speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  48 */   IntegerSetting delay = registerInteger("Calc Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  49 */   BooleanSetting yCheck = registerBoolean("Y Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  50 */   BooleanSetting smart = registerBoolean("Stuck Check", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.yCheck.getValue()).booleanValue())));
/*  51 */   BooleanSetting holeCheck = registerBoolean("InHole Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  52 */   IntegerSetting placeDelay = registerInteger("Place Delay", 50, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  53 */   IntegerSetting bpc = registerInteger("Block pre Tick", 6, 1, 20, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  54 */   DoubleSetting range = registerDouble("Range", 6.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  55 */   DoubleSetting yRange = registerDouble("Y Range", 2.5D, 0.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  56 */   DoubleSetting playerRange = registerDouble("Enemy Range", 3.0D, 0.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  57 */   DoubleSetting playerYRange = registerDouble("Enemy YRange", 3.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  58 */   BooleanSetting rotate = registerBoolean("Rotate", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  59 */   BooleanSetting packet = registerBoolean("Packet Place", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  60 */   BooleanSetting swing = registerBoolean("Swing", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  61 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  62 */   BooleanSetting check = registerBoolean("Switch Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  63 */   BooleanSetting doubleHole = registerBoolean("Double Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  64 */   BooleanSetting customHole = registerBoolean("Custom Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  65 */   BooleanSetting fourHole = registerBoolean("FourBlocks Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  66 */   List<BlockPos> posList = new ArrayList<>();
/*  67 */   Timing timer = new Timing();
/*  68 */   Timing placeTimer = new Timing();
/*     */   boolean self;
/*     */   int placed;
/*     */   int waited;
/*  72 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fast() {
/*  81 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  83 */     if (this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) {
/*  84 */       this.posList = calc();
/*  85 */       this.timer.reset();
/*     */     } 
/*  87 */     if (this.placeTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue())) {
/*  88 */       for (BlockPos pos : this.posList) {
/*  89 */         if (this.placed >= ((Integer)this.bpc.getValue()).intValue())
/*  90 */           break;  placeBlock(pos);
/*     */       } 
/*  92 */       this.placeTimer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/*  97 */     if (pos1 == null || pos2 == null)
/*  98 */       return false; 
/*  99 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   private List<BlockPos> calc() {
/* 103 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/* 104 */       return new ArrayList<>(); 
/* 105 */     this.waited = 0;
/* 106 */     this.placed = 0;
/* 107 */     List<BlockPos> holePos = new ArrayList<>();
/* 108 */     List<EntityPlayer> targets = new ArrayList<>(mc.world.playerEntities);
/* 109 */     targets.removeIf(player -> (EntityUtil.basicChecksEntity(player) || mc.player.getDistance((Entity)player) > ((Double)this.range.getValue()).doubleValue() + ((Double)this.playerRange.getValue()).doubleValue() || (((Boolean)this.holeCheck.getValue()).booleanValue() && inHole(player))));
/* 110 */     if (((Boolean)this.test.getValue()).booleanValue()) targets.add(mc.player); 
/* 111 */     List<EntityPlayer> listPlayer = new ArrayList<>();
/* 112 */     if (!((String)this.target.getValue()).equals("Predict")) listPlayer.addAll(targets); 
/* 113 */     if (!((String)this.target.getValue()).equals("Normal"))
/* 114 */       for (EntityPlayer player : targets) {
/* 115 */         listPlayer.add(PredictUtil.predictPlayer((EntityLivingBase)player, new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue())));
/* 116 */         if (((Boolean)this.doublePredict.getValue()).booleanValue()) listPlayer.add(PredictUtil.predictPlayer((EntityLivingBase)player, new PredictUtil.PredictSettings(((Integer)this.tickPredict.getValue()).intValue() * 2, ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue())));
/*     */       
/*     */       }  
/* 119 */     boolean fill = false;
/* 120 */     for (EntityPlayer target : listPlayer) {
/* 121 */       for (BlockPos pos : EntityUtil.getSphere(new BlockPos(target.posX, target.posY, target.posZ), Double.valueOf(((Double)this.playerRange.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.playerYRange.getValue()).doubleValue() + 1.0D), false, false, 0)) {
/* 122 */         if (isPos2(PlayerUtil.getPlayerPos(), pos))
/* 123 */           fill = true; 
/* 124 */         if (!checkInRange(target, pos))
/* 125 */           continue;  HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(pos, false, true, false);
/* 126 */         HoleUtil.HoleType holeType = holeInfo.getType();
/* 127 */         if (holeType == HoleUtil.HoleType.NONE || 
/* 128 */           mc.player.getDistanceSq(pos) > ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue())
/*     */           continue; 
/* 130 */         if (!mc.world.isAirBlock(pos) || !mc.world.isAirBlock(pos.up()) || !mc.world.isAirBlock(pos.up(2)))
/*     */           continue; 
/* 132 */         if (((Boolean)this.yCheck.getValue()).booleanValue() && target.posY <= pos.y)
/* 133 */           continue;  boolean cant = false;
/* 134 */         if (((Boolean)this.smart.getValue()).booleanValue())
/* 135 */           for (int high = 0; high < target.posY - pos.y; high++) {
/* 136 */             if (high != 0) {
/* 137 */               if (mc.player.posY > pos.y && 
/* 138 */                 !mc.world.isAirBlock(new BlockPos(pos.x, pos.y + high, pos.z))) {
/* 139 */                 cant = true;
/*     */               }
/* 141 */               if (mc.player.posY < pos.y) {
/* 142 */                 BlockPos newPos = new BlockPos(pos.x, pos.y + high, pos.z);
/* 143 */                 if (mc.world.isAirBlock(newPos) && (mc.world.isAirBlock(newPos.down()) || mc.world.isAirBlock(newPos.up())))
/* 144 */                   cant = true; 
/*     */               } 
/*     */             } 
/*     */           }  
/* 148 */         if (cant) {
/*     */           continue;
/*     */         }
/* 151 */         if (holeType == HoleUtil.HoleType.SINGLE) {
/* 152 */           holePos.add(pos);
/*     */         }
/* 154 */         if (((Boolean)this.doubleHole.getValue()).booleanValue() && holeType == HoleUtil.HoleType.DOUBLE) {
/* 155 */           holePos.add(pos);
/*     */         }
/* 157 */         if (((Boolean)this.customHole.getValue()).booleanValue() && holeType == HoleUtil.HoleType.CUSTOM) {
/* 158 */           holePos.add(pos);
/*     */         }
/* 160 */         if (((Boolean)this.fourHole.getValue()).booleanValue() && holeType == HoleUtil.HoleType.FOUR) {
/* 161 */           holePos.add(pos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     this.self = fill;
/* 167 */     holePos.removeIf(pos -> !checkPlaceRange(pos));
/* 168 */     return holePos;
/*     */   }
/*     */   
/*     */   private boolean checkInRange(EntityPlayer player, BlockPos pos) {
/* 172 */     BlockPos targetPos = new BlockPos(Math.floor(player.posX), Math.floor(player.posY), Math.floor(player.posZ));
/* 173 */     double x = targetPos.x - pos.x + 0.5D;
/* 174 */     double y = (targetPos.y - pos.y + 1);
/* 175 */     double z = targetPos.z - pos.z + 0.5D;
/* 176 */     if (!((Boolean)this.yCheck.getValue()).booleanValue()) {
/* 177 */       double y2 = targetPos.y - pos.y + 0.5D;
/* 178 */       if (y2 * y2 > ((Double)this.playerYRange.getValue()).doubleValue() * ((Double)this.playerYRange.getValue()).doubleValue())
/* 179 */         return false; 
/*     */     } 
/* 181 */     return (x * x <= ((Double)this.playerRange.getValue()).doubleValue() * ((Double)this.playerRange.getValue()).doubleValue() && y * y <= ((Double)this.playerYRange.getValue()).doubleValue() * ((Double)this.playerYRange.getValue()).doubleValue() && z * z <= ((Double)this.playerRange.getValue()).doubleValue() * ((Double)this.playerRange.getValue()).doubleValue());
/*     */   }
/*     */   
/*     */   private boolean checkPlaceRange(BlockPos pos) {
/* 185 */     BlockPos playerPos = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
/* 186 */     double x = playerPos.x - pos.x + 0.5D;
/* 187 */     double y = playerPos.y - pos.y + 0.5D;
/* 188 */     double z = playerPos.z - pos.z + 0.5D;
/* 189 */     return (x * x <= ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue() && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue() && z * z <= ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue());
/*     */   }
/*     */   public boolean inHole(EntityPlayer aimTarget) {
/* 192 */     HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(EntityUtil.getEntityPos((Entity)aimTarget), false, false, false);
/* 193 */     HoleUtil.HoleType holeType = holeInfo.getType();
/* 194 */     return (holeType != HoleUtil.HoleType.NONE);
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 198 */     for (Entity entity : mc.world.loadedEntityList) {
/* 199 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 200 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 201 */         return true; 
/*     */     } 
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlayer(BlockPos pos) {
/* 207 */     for (EntityPlayer entity : mc.world.playerEntities) {
/* 208 */       if (entity == mc.player && (
/* 209 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 210 */         return true; 
/*     */     } 
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void switchTo(int slot) {
/* 217 */     if (slot > -1 && slot < 9 && (
/* 218 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 219 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/* 221 */       { mc.player.inventory.currentItem = slot; }
/*     */       
/* 223 */       mc.playerController.updateController();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 228 */     boolean isPlayer = isPlayer(pos);
/* 229 */     if (isPlayer && BlockUtil.airBlocks.contains(mc.world.getBlockState(pos).getBlock())) {
/* 230 */       int obby = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 231 */       int oldslot = mc.player.inventory.currentItem;
/* 232 */       if (obby != -1) {
/* 233 */         BlockPos ori = pos.up();
/* 234 */         if (BurrowUtil.getFirstFacing(pos.up(2)) == null)
/* 235 */         { BlockPos e = null;
/* 236 */           boolean isNull = true;
/* 237 */           for (BlockPos side : this.sides) {
/* 238 */             BlockPos added = ori.up().add((Vec3i)side);
/* 239 */             if (!intersectsWithEntity(added) && BurrowUtil.getFirstFacing(added) != null) {
/* 240 */               e = added;
/* 241 */               isNull = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 245 */           if (isNull) {
/* 246 */             for (BlockPos side : this.sides) {
/* 247 */               BlockPos added = ori.add((Vec3i)side);
/* 248 */               if (!intersectsWithEntity(added) && !intersectsWithEntity(added.up())) {
/* 249 */                 switchTo(obby);
/* 250 */                 placeblock(added);
/* 251 */                 e = added.up(); break;
/*     */               } 
/*     */             } 
/*     */           } else {
/* 255 */             switchTo(obby);
/* 256 */           }  placeblock(e);
/* 257 */           switchTo(oldslot); }
/* 258 */         else { switchTo(obby); }
/* 259 */          placeblock(pos.up(2));
/* 260 */         switchTo(oldslot);
/*     */       } 
/*     */     } 
/* 263 */     this.placed++;
/*     */   }
/*     */   
/*     */   private void placeblock(BlockPos pos) {
/* 267 */     if (ColorMain.INSTANCE.breakList.contains(pos))
/* 268 */       return;  BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, EnumFacing facing, Vec3d hVec, boolean packet, boolean swing) {
/* 272 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(hVec).add((new Vec3d(facing.getDirectionVec())).scale(0.5D));
/*     */     
/* 274 */     if (packet) {
/* 275 */       rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, facing);
/*     */     } else {
/* 277 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, hitVec, EnumHand.MAIN_HAND);
/*     */     } 
/* 279 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction) {
/* 283 */     float f = (float)(vec.x - pos.getX());
/* 284 */     float f1 = (float)(vec.y - pos.getY());
/* 285 */     float f2 = (float)(vec.z - pos.getZ());
/* 286 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoSelfTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
