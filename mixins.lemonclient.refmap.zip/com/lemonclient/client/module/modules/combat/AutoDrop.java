//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ @Declaration(name = "AutoDrop", category = Category.Combat)
/*     */ public class AutoDrop extends Module {
/*  17 */   IntegerSetting delay = registerInteger("Drop Delay", 10, 0, 20);
/*     */   
/*  19 */   ModeSetting mode = registerMode("Sharpness", Arrays.asList(new String[] { "Sharp5", "Sharp32k", "Both" }, ), "Both");
/*     */   
/*  21 */   private final Timing timer = new Timing();
/*     */   
/*     */   public void onUpdate() {
/*  24 */     switch ((String)this.mode.getValue()) {
/*     */       case "Sharp32k":
/*  26 */         if (isSuperWeapon(mc.player.getHeldItemMainhand()) && this.timer
/*  27 */           .passedDs(((Integer)this.delay.getValue()).intValue())) {
/*  28 */           boolean holding32k = false;
/*  29 */           EntityItem entityItem = mc.player.dropItem(!holding32k);
/*  30 */           this.timer.reset();
/*     */           break;
/*     */         } 
/*     */       case "Both":
/*  34 */         if (checkSword(mc.player.getHeldItemMainhand()) && this.timer
/*  35 */           .passedDs(((Integer)this.delay.getValue()).intValue())) {
/*  36 */           boolean holding = false;
/*  37 */           EntityItem entityItem = mc.player.dropItem(!holding);
/*     */         } 
/*     */       case "Sharp5":
/*  40 */         if (checkSharpness5(mc.player.getHeldItemMainhand()) && this.timer
/*  41 */           .passedDs(((Integer)this.delay.getValue()).intValue())) {
/*  42 */           boolean holding5 = false;
/*  43 */           EntityItem entityItem = mc.player.dropItem(!holding5);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkSword(ItemStack stack) {
/*  50 */     if (stack.getTagCompound() == null)
/*  51 */       return false; 
/*  52 */     if (stack.getEnchantmentTagList().getTagType() == 0)
/*  53 */       return false; 
/*  54 */     NBTTagList enchants = (NBTTagList)stack.getTagCompound().getTag("ench");
/*  55 */     for (int i = 0; i < enchants.tagCount(); i++) {
/*  56 */       NBTTagCompound enchant = enchants.getCompoundTagAt(i);
/*  57 */       if (enchant.getInteger("id") == 16) {
/*  58 */         int lvl = enchant.getInteger("lvl");
/*  59 */         if (lvl > 4)
/*  60 */           return true; 
/*     */         break;
/*     */       } 
/*     */     } 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSuperWeapon(ItemStack item) {
/*  69 */     if (item == null)
/*  70 */       return false; 
/*  71 */     if (item.getTagCompound() == null)
/*  72 */       return false; 
/*  73 */     if (item.getEnchantmentTagList().getTagType() == 0)
/*  74 */       return false; 
/*  75 */     NBTTagList enchants = (NBTTagList)item.getTagCompound().getTag("ench");
/*  76 */     int i = 0;
/*  77 */     while (i < enchants.tagCount()) {
/*  78 */       NBTTagCompound enchant = enchants.getCompoundTagAt(i);
/*  79 */       if (enchant.getInteger("id") == 16) {
/*  80 */         int lvl = enchant.getInteger("lvl");
/*  81 */         if (lvl >= 16)
/*  82 */           return true; 
/*     */         break;
/*     */       } 
/*  85 */       i++;
/*     */     } 
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkSharpness5(ItemStack stack) {
/*  91 */     if (stack.getTagCompound() == null)
/*  92 */       return false; 
/*  93 */     if (stack.getEnchantmentTagList().getTagType() == 0)
/*  94 */       return false; 
/*  95 */     NBTTagList enchants = (NBTTagList)stack.getTagCompound().getTag("ench");
/*  96 */     for (int i = 0; i < enchants.tagCount(); i++) {
/*  97 */       NBTTagCompound enchant = enchants.getCompoundTagAt(i);
/*  98 */       if (enchant.getInteger("id") == 16) {
/*  99 */         int lvl = enchant.getInteger("lvl");
/* 100 */         if (lvl == 5)
/* 101 */           return true; 
/*     */         break;
/*     */       } 
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoDrop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
