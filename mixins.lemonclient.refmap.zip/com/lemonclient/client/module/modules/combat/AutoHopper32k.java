//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.misc.MessageBus;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoHopper32k", category = Category.Combat)
/*     */ public class AutoHopper32k
/*     */   extends Module
/*     */ {
/*     */   private static final int scale = 1;
/*  48 */   private static final RoundingMode roundingMode = RoundingMode.CEILING;
/*     */   
/*  50 */   BooleanSetting moveToHotbar = registerBoolean("Move 32k to Hotbar", true);
/*  51 */   DoubleSetting placeRange = registerDouble("Place range", 4.0D, 0.0D, 10.0D);
/*  52 */   IntegerSetting yOffset = registerInteger("Y Offset (Hopper)", 2, 0, 10);
/*  53 */   DoubleSetting targetRange = registerDouble("Target Range", 4.0D, 0.0D, 16.0D);
/*  54 */   BooleanSetting placeCloseToEnemy = registerBoolean("Place close to enemy", false);
/*  55 */   BooleanSetting placeObiOnTop = registerBoolean("Place Obi on Top", true);
/*  56 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  57 */   BooleanSetting packet = registerBoolean("Packet", false);
/*  58 */   BooleanSetting swing = registerBoolean("Swing", true);
/*  59 */   BooleanSetting silent = registerBoolean("Silent", true);
/*  60 */   BooleanSetting debugMessages = registerBoolean("Debug Messages", true);
/*     */   
/*     */   int oldslot;
/*     */   private int swordSlot;
/*     */   
/*     */   private double getWeight(BlockPos pos, EntityPlayer target) {
/*  66 */     double range = target.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D);
/*  67 */     if (range >= ((Double)this.targetRange.getValue()).doubleValue()) {
/*  68 */       int y = 256 - pos.getY();
/*  69 */       range += (y * 100);
/*     */     } 
/*  71 */     return range;
/*     */   }
/*     */   
/*     */   protected void onEnable() {
/*     */     BlockPos placeTarget;
/*  76 */     if (mc.player == null || mc.world == null || mc.player.isDead) {
/*  77 */       disable();
/*     */       return;
/*     */     } 
/*  80 */     this.oldslot = mc.player.inventory.currentItem;
/*     */     
/*  82 */     int hopperSlot = -1;
/*  83 */     int shulkerSlot = -1;
/*  84 */     int obiSlot = -1;
/*  85 */     this.swordSlot = -1;
/*     */     
/*  87 */     for (int i = 0; i < 9; i++) {
/*     */       
/*  89 */       if (hopperSlot != -1 && shulkerSlot != -1 && obiSlot != -1) {
/*     */         break;
/*     */       }
/*     */       
/*  93 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */       
/*  95 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
/*     */ 
/*     */ 
/*     */         
/*  99 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/*     */         
/* 101 */         if (block == Blocks.HOPPER) {
/* 102 */           hopperSlot = i;
/* 103 */         } else if (BlockUtil.shulkerList.contains(block)) {
/* 104 */           shulkerSlot = i;
/* 105 */         } else if (block == Blocks.OBSIDIAN) {
/* 106 */           obiSlot = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     if (hopperSlot == -1) {
/* 112 */       if (((Boolean)this.debugMessages.getValue()).booleanValue()) {
/* 113 */         MessageBus.sendClientPrefixMessage("Hopper missing, " + ((ColorMain)ModuleManager.getModule(ColorMain.class)).getModuleColor() + "AutoHopper32k" + ChatFormatting.GRAY + " disabling.", Notification.Type.ERROR);
/*     */       }
/* 115 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 119 */     if (shulkerSlot == -1) {
/* 120 */       if (((Boolean)this.debugMessages.getValue()).booleanValue()) {
/* 121 */         MessageBus.sendClientPrefixMessage("Shulker missing, " + ((ColorMain)ModuleManager.getModule(ColorMain.class)).getModuleColor() + "AutoHopper32k" + ChatFormatting.GRAY + " disabling.", Notification.Type.ERROR);
/*     */       }
/* 123 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 127 */     double range = ((Double)this.placeRange.getValue()).doubleValue();
/* 128 */     double yRange = ((Integer)this.yOffset.getValue()).intValue();
/*     */     
/* 130 */     List<BlockPos> placeTargetList = EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(range), Double.valueOf(yRange), false, false, 0);
/* 131 */     List<BlockPos> placeTargetMap = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 135 */     for (BlockPos placeTargetTest : placeTargetList) {
/* 136 */       if (isAreaPlaceable(placeTargetTest)) placeTargetMap.add(placeTargetTest);
/*     */     
/*     */     } 
/* 139 */     EntityPlayer targetPlayer = mc.world.playerEntities.stream().filter(e -> (e != mc.player && !SocialManager.isFriend(e.getName()))).min(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance((Entity)e)))).orElse(null);
/* 140 */     if (targetPlayer != null)
/* 141 */     { if (((Boolean)this.placeCloseToEnemy.getValue()).booleanValue()) { placeTarget = placeTargetMap.stream().min(Comparator.comparing(e -> Double.valueOf(BlockUtil.blockDistance(e.x, e.y, e.z, (Entity)targetPlayer)))).orElse(null); }
/* 142 */       else { placeTarget = placeTargetMap.stream().max(Comparator.comparing(e -> Double.valueOf(getWeight(e, targetPlayer)))).orElse(null); }  }
/* 143 */     else { placeTarget = placeTargetMap.stream().min(Comparator.comparing(e -> Double.valueOf(BlockUtil.blockDistance(e.x, e.y, e.z, (Entity)mc.player)))).orElse(null); }
/*     */     
/* 145 */     if (placeTarget == null) {
/* 146 */       if (((Boolean)this.debugMessages.getValue()).booleanValue()) {
/* 147 */         MessageBus.sendClientPrefixMessage("No valid position in range to place, " + ((ColorMain)ModuleManager.getModule(ColorMain.class)).getModuleColor() + "AutoHopper32k" + ChatFormatting.GRAY + " disabling.", Notification.Type.ERROR);
/*     */       }
/* 149 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 153 */     if (((Boolean)this.debugMessages.getValue()).booleanValue()) {
/* 154 */       MessageBus.sendClientPrefixMessage("AutoHopper32k Place Target: " + placeTarget.x + " " + placeTarget.y + " " + placeTarget.z + " Distance: " + BigDecimal.valueOf(mc.player.getPositionVector().distanceTo(new Vec3d((Vec3i)placeTarget))).setScale(1, roundingMode), Notification.Type.SUCCESS);
/*     */     }
/*     */     
/* 157 */     mc.player.inventory.currentItem = hopperSlot;
/* 158 */     BurrowUtil.placeBlockDown(placeTarget, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 159 */     mc.player.inventory.currentItem = shulkerSlot;
/* 160 */     BurrowUtil.placeBlockDown(placeTarget.add(0, 1, 0), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */ 
/*     */     
/* 163 */     if (((Boolean)this.placeObiOnTop.getValue()).booleanValue()) {
/* 164 */       int obsidian = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 165 */       if (obsidian != -1) {
/* 166 */         mc.player.inventory.currentItem = obsidian;
/* 167 */         BurrowUtil.placeBlockDown(placeTarget.add(0, 2, 0), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 168 */         if (!((Boolean)this.silent.getValue()).booleanValue()) mc.player.inventory.currentItem = shulkerSlot;
/*     */       
/*     */       } 
/*     */     } 
/* 172 */     if (((Boolean)this.silent.getValue()).booleanValue()) mc.player.inventory.currentItem = this.oldslot; 
/* 173 */     if (ColorMain.INSTANCE.sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 174 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(placeTarget, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 175 */     this.swordSlot = shulkerSlot + 32;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 182 */     if (mc.player == null || mc.world == null || mc.player.isDead) {
/* 183 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     if (!(mc.currentScreen instanceof GuiContainer)) {
/*     */       return;
/*     */     }
/*     */     
/* 191 */     if (!((Boolean)this.moveToHotbar.getValue()).booleanValue()) {
/* 192 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/* 196 */     if (this.swordSlot == -1) {
/*     */       return;
/*     */     }
/*     */     
/* 200 */     boolean swapReady = !(((GuiContainer)mc.currentScreen).inventorySlots.getSlot(0).getStack()).isEmpty;
/*     */     
/* 202 */     if (!(((GuiContainer)mc.currentScreen).inventorySlots.getSlot(this.swordSlot).getStack()).isEmpty) {
/* 203 */       swapReady = false;
/*     */     }
/*     */     
/* 206 */     if (swapReady) {
/* 207 */       mc.playerController.windowClick(((GuiContainer)mc.currentScreen).inventorySlots.windowId, 0, this.swordSlot - 32, ClickType.SWAP, (EntityPlayer)mc.player);
/* 208 */       disable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isAreaPlaceable(BlockPos blockPos) {
/* 214 */     return (canPlace(blockPos) && inRange(blockPos) && canPlace(blockPos.up()) && inRange(blockPos.up()) && (
/* 215 */       !((Boolean)this.placeObiOnTop.getValue()).booleanValue() || !canPlace(blockPos) || inRange(blockPos)));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canPlace(BlockPos pos) {
/* 220 */     return (!intersectsWithEntity(pos) && BlockUtil.canReplace(pos));
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 224 */     for (Entity entity : mc.world.loadedEntityList) {
/* 225 */       if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb) && !(entity instanceof net.minecraft.entity.item.EntityExpBottle) && !(entity instanceof net.minecraft.entity.projectile.EntityArrow) && (
/* 226 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 227 */         return true; 
/*     */     } 
/* 229 */     return false;
/*     */   }
/*     */   public boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 232 */     if (pos1 == null || pos2 == null)
/* 233 */       return false; 
/* 234 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   private boolean inRange(BlockPos pos) {
/* 238 */     double x = pos.x - mc.player.posX;
/* 239 */     double z = pos.z - mc.player.posZ;
/* 240 */     double y = (pos.y - (PlayerUtil.getEyesPos()).y);
/* 241 */     double add = Math.sqrt(y * y) / 2.0D;
/* 242 */     return (x * x + z * z <= (((Double)this.placeRange.getValue()).doubleValue() - add) * (((Double)this.placeRange.getValue()).doubleValue() - add) && y * y <= ((Double)this.placeRange.getValue()).doubleValue() * ((Double)this.placeRange.getValue()).doubleValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoHopper32k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
