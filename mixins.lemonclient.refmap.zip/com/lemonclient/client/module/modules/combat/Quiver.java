//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.potion.PotionUtils;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ @Declaration(name = "Quiver", category = Category.Combat)
/*    */ public class Quiver extends Module {
/* 19 */   IntegerSetting tickDelay = registerInteger("TickDelay", 3, 0, 8);
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 23 */     if (mc.player != null) {
/* 24 */       if (mc.player.inventory.getCurrentItem().getItem() instanceof net.minecraft.item.ItemBow && mc.player.isHandActive() && mc.player.getItemInUseMaxCount() >= ((Integer)this.tickDelay.getValue()).intValue()) {
/* 25 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(mc.player.cameraYaw, -90.0F, mc.player.onGround));
/* 26 */         mc.playerController.onStoppedUsingItem((EntityPlayer)mc.player);
/*    */       } 
/* 28 */       List<Integer> arrowSlots = getItemInventory(Items.TIPPED_ARROW);
/* 29 */       if (((Integer)arrowSlots.get(0)).intValue() == -1)
/* 30 */         return;  int speedSlot = -1;
/* 31 */       int strengthSlot = -1;
/* 32 */       for (Integer slot : arrowSlots) {
/*    */         
/* 34 */         if (PotionUtils.getPotionFromItem(mc.player.inventory.getStackInSlot(slot.intValue())).getRegistryName().getPath().contains("swiftness")) { speedSlot = slot.intValue(); continue; }
/* 35 */          if (((ResourceLocation)Objects.<ResourceLocation>requireNonNull(PotionUtils.getPotionFromItem(mc.player.inventory.getStackInSlot(slot.intValue())).getRegistryName())).getPath().contains("strength")) strengthSlot = slot.intValue(); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   public static List<Integer> getItemInventory(Item item) {
/* 40 */     List<Integer> ints = new ArrayList<>();
/* 41 */     for (int i = 9; i < 36; i++) {
/*    */       
/* 43 */       Item target = mc.player.inventory.getStackInSlot(i).getItem();
/*    */       
/* 45 */       if (item instanceof ItemBlock && ((ItemBlock)item).getBlock().equals(item)) ints.add(Integer.valueOf(i));
/*    */     
/*    */     } 
/* 48 */     if (ints.size() == 0) ints.add(Integer.valueOf(-1));
/*    */     
/* 50 */     return ints;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\Quiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
