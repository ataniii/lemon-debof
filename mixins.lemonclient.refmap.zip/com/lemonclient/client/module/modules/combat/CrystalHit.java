//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ import com.lemonclient.api.setting.values.BooleanSetting;
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.api.util.world.combat.CrystalUtil;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import java.util.Comparator;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.item.EntityEnderCrystal;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*    */ 
/*    */ @Declaration(name = "CrystalHit", category = Category.Combat)
/*    */ public class CrystalHit extends Module {
/* 18 */   IntegerSetting range = registerInteger("Range", 4, 0, 10);
/*    */   
/* 20 */   IntegerSetting delay = registerInteger("Delay", 0, 0, 40);
/*    */   
/* 22 */   BooleanSetting packet = registerBoolean("Packet Break", false);
/*    */   
/* 24 */   BooleanSetting swing = registerBoolean("Swing", false);
/*    */   
/* 26 */   BooleanSetting antiWeakness = registerBoolean("Anti Weakness", false);
/* 27 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/* 28 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*    */   
/* 30 */   BooleanSetting silent = registerBoolean("Silent Switch", false);
/*    */   
/*    */   private boolean isAttacking = false;
/*    */   
/* 34 */   private int oldSlot = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 41 */     EntityEnderCrystal crystal = mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityEnderCrystal).map(entity -> (EntityEnderCrystal)entity).min(Comparator.comparing(c -> Float.valueOf(mc.player.getDistance((Entity)c)))).orElse(null);
/* 42 */     if (crystal != null && mc.player.getDistance((Entity)crystal) <= ((Integer)this.range.getValue()).intValue()) {
/* 43 */       int delaytime = 0;
/* 44 */       if (delaytime >= ((Integer)this.delay.getValue()).intValue()) {
/* 45 */         if (((Boolean)this.antiWeakness.getValue()).booleanValue() && mc.player.isPotionActive(MobEffects.WEAKNESS)) {
/* 46 */           if (!this.isAttacking) {
/* 47 */             this.oldSlot = mc.player.inventory.currentItem;
/* 48 */             this.isAttacking = true;
/*    */           } 
/* 50 */           int newSlot = -1;
/* 51 */           for (int i = 0; i < 9; i++) {
/* 52 */             ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 53 */             if (stack != ItemStack.EMPTY) {
/* 54 */               if (stack.getItem() instanceof net.minecraft.item.ItemSword) {
/* 55 */                 newSlot = i; break;
/*    */               } 
/* 57 */               if (stack.getItem() instanceof net.minecraft.item.ItemTool) {
/* 58 */                 newSlot = i;
/*    */               }
/*    */             } 
/*    */           } 
/* 62 */           if (newSlot != -1)
/* 63 */             switchTo(newSlot); 
/*    */         } 
/* 65 */         if (!((Boolean)this.packet.getValue()).booleanValue())
/* 66 */         { CrystalUtil.breakCrystal((Entity)crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 67 */         else { CrystalUtil.breakCrystalPacket((Entity)crystal, ((Boolean)this.swing.getValue()).booleanValue()); }
/* 68 */          if (((Boolean)this.silent.getValue()).booleanValue())
/* 69 */           switchTo(this.oldSlot); 
/*    */       } 
/*    */     } else {
/* 72 */       if (this.oldSlot != -1) {
/* 73 */         mc.player.inventory.currentItem = this.oldSlot;
/* 74 */         this.oldSlot = -1;
/*    */       } 
/* 76 */       this.isAttacking = false;
/*    */     } 
/*    */   }
/*    */   
/*    */   private void switchTo(int slot) {
/* 81 */     if (slot > -1 && slot < 9 && (
/* 82 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/* 83 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*    */       else
/* 85 */       { mc.player.inventory.currentItem = slot; }
/*    */       
/* 87 */       mc.playerController.updateController();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\CrystalHit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
