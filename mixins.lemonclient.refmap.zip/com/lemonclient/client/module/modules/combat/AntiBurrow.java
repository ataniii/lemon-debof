//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ @Declaration(name = "AutoMineBurrow", category = Category.Combat)
/*     */ public class AntiBurrow extends Module {
/*     */   public static AntiBurrow INSTANCE;
/*     */   ModeSetting breakBlock;
/*     */   DoubleSetting balance;
/*     */   BooleanSetting up;
/*     */   BooleanSetting down;
/*     */   BooleanSetting first;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting ignore;
/*     */   BooleanSetting ignorePiston;
/*     */   BooleanSetting ignoreWeb;
/*     */   BooleanSetting fire;
/*     */   BooleanSetting sand;
/*     */   IntegerSetting range;
/*     */   BooleanSetting doubleMine;
/*     */   public double yaw;
/*     */   public double pitch;
/*     */   public boolean mining;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> listener;
/*     */   
/*  37 */   public AntiBurrow() { this.breakBlock = registerMode("Break Block", Arrays.asList(new String[] { "Normal", "Packet" }, ), "Packet");
/*  38 */     this.balance = registerDouble("Reduce", 0.24D, 0.0D, 0.5D);
/*  39 */     this.up = registerBoolean("Head", true);
/*  40 */     this.down = registerBoolean("Feet", true);
/*  41 */     this.first = registerBoolean("Head First", false, () -> (Boolean)this.up.getValue());
/*  42 */     this.swing = registerBoolean("Swing", true);
/*  43 */     this.rotate = registerBoolean("Rotate", false);
/*  44 */     this.ignore = registerBoolean("Ignore Bed", false);
/*  45 */     this.ignorePiston = registerBoolean("Ignore Piston", false);
/*  46 */     this.ignoreWeb = registerBoolean("Ignore Web", false);
/*  47 */     this.fire = registerBoolean("Fire", false);
/*  48 */     this.sand = registerBoolean("Falling Blocks", false);
/*  49 */     this.range = registerInteger("Range", 5, 0, 10);
/*  50 */     this.doubleMine = registerBoolean("Double Mine", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     this.listener = new Listener(event -> { if (!((Boolean)this.rotate.getValue()).booleanValue() || !this.mining) return;  if (event.getPacket() instanceof CPacketPlayer) { CPacketPlayer packet = (CPacketPlayer)event.getPacket(); packet.yaw = (float)this.yaw; packet.pitch = (float)this.pitch; }  }new java.util.function.Predicate[0]);
/*     */     INSTANCE = this; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos getCityPos(BlockPos pos) {
/*  94 */     EntityPlayer player = PlayerUtil.getNearestPlayer(((Integer)this.range.getValue()).intValue());
/*  95 */     if (player == null) return null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     Vec3d[] sides = { new Vec3d(((Double)this.balance.getValue()).doubleValue(), 0.0D, ((Double)this.balance.getValue()).doubleValue()), new Vec3d(-((Double)this.balance.getValue()).doubleValue(), 0.0D, ((Double)this.balance.getValue()).doubleValue()), new Vec3d(((Double)this.balance.getValue()).doubleValue(), 0.0D, -((Double)this.balance.getValue()).doubleValue()), new Vec3d(-((Double)this.balance.getValue()).doubleValue(), 0.0D, -((Double)this.balance.getValue()).doubleValue()) };
/*     */ 
/*     */     
/* 104 */     if (((Boolean)this.first.getValue()).booleanValue() && ((Boolean)this.up.getValue()).booleanValue()) {
/* 105 */       for (int x = 1; x > -1 && ((
/* 106 */         (Boolean)this.down.getValue()).booleanValue() || x != 0); x--) {
/* 107 */         for (Vec3d side : sides) {
/* 108 */           BlockPos burrowPos = new BlockPos(player.posX + side.x, player.posY + x, player.posZ + side.z);
/* 109 */           if (intersect(player, burrowPos) && 
/* 110 */             !isPos2(burrowPos, pos) && burrow(burrowPos)) return burrowPos; 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 114 */       for (int x = ((Boolean)this.down.getValue()).booleanValue() ? 0 : 1; x < 2 && ((
/* 115 */         (Boolean)this.up.getValue()).booleanValue() || x != 1); x++) {
/* 116 */         for (Vec3d side : sides) {
/* 117 */           BlockPos burrowPos = new BlockPos(player.posX + side.x, player.posY + x, player.posZ + side.z);
/* 118 */           if (intersect(player, burrowPos) && 
/* 119 */             !isPos2(burrowPos, pos) && burrow(burrowPos)) return burrowPos; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 123 */     return null;
/*     */   } public void onUpdate() { if (mc.world == null || mc.player == null || mc.player.isDead) return;  if (AntiRegear.INSTANCE.working) return;  BlockPos instantPos = null; if (ModuleManager.isModuleEnabled(PacketMine.class)) instantPos = PacketMine.INSTANCE.packetPos;  if (instantPos != null) { if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ))) return;  if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ))) return;  if (mc.world.getBlockState(instantPos).getBlock() == Blocks.WEB) return;  }  BlockPos pos = getCityPos((BlockPos)null); this.mining = (pos != null); if (!this.mining) return;  if (((Boolean)this.doubleMine.getValue()).booleanValue()) { BlockPos doublePos = null; if (ModuleManager.isModuleEnabled(PacketMine.class)) doublePos = PacketMine.INSTANCE.doublePos;  if (doublePos == null)
/* 125 */         doBreak(getCityPos(pos));  }  double[] rotate = EntityUtil.calculateLookAt(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, (Entity)mc.player); this.yaw = rotate[0]; this.pitch = rotate[1]; doBreak(pos); } public static final List<Block> airBlocks = Arrays.asList(new Block[] { Blocks.AIR, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.WATER, (Block)Blocks.FLOWING_WATER, (Block)Blocks.GRASS });
/*     */   
/*     */   private boolean burrow(BlockPos pos) {
/* 128 */     return (!airBlocks.contains(mc.world.getBlockState(pos).getBlock()) && 
/* 129 */       (BlockUtil.getBlock(pos)).blockHardness >= 0.0F && (
/* 130 */       !((Boolean)this.ignore.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.BED) && (
/* 131 */       !((Boolean)this.ignorePiston.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.PISTON_HEAD) && (
/* 132 */       !((Boolean)this.ignoreWeb.getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.WEB) && (((Boolean)this.fire
/* 133 */       .getValue()).booleanValue() || mc.world.getBlockState(pos).getBlock() != Blocks.FIRE) && (((Boolean)this.sand
/* 134 */       .getValue()).booleanValue() || (mc.world.getBlockState(pos).getBlock() != Blocks.SAND && mc.world.getBlockState(pos).getBlock() != Blocks.GRAVEL && mc.world.getBlockState(pos).getBlock() != Blocks.ANVIL && !(mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockConcretePowder))));
/*     */   }
/*     */   
/*     */   private void doBreak(BlockPos pos) {
/* 138 */     if (pos == null)
/* 139 */       return;  if (((Boolean)this.swing.getValue()).booleanValue()) {
/* 140 */       mc.player.swingArm(EnumHand.MAIN_HAND);
/*     */     }
/* 142 */     if (((String)this.breakBlock.getValue()).equals("Packet")) {
/* 143 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
/* 144 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.UP));
/*     */     } else {
/* 146 */       mc.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean intersect(EntityPlayer player, BlockPos pos) {
/* 151 */     return player.boundingBox.intersects(mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos));
/*     */   }
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 155 */     if (pos1 == null || pos2 == null)
/* 156 */       return false; 
/* 157 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AntiBurrow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
