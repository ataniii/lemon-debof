//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.client.module.modules.combat;
/*    */ 
/*    */ import com.lemonclient.api.setting.values.IntegerSetting;
/*    */ import com.lemonclient.client.module.Category;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import com.lemonclient.client.module.Module.Declaration;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.inventory.ClickType;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ @Declaration(name = "32kTotem", category = Category.Combat)
/*    */ public class Anti32kTotem extends Module {
/* 15 */   IntegerSetting slot = registerInteger("Slot", 1, 1, 9);
/*    */   
/*    */   public void fast() {
/* 18 */     if ((!(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiContainer) || mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory) && 
/* 19 */       mc.player.inventory.getStackInSlot(((Integer)this.slot.getValue()).intValue() - 1).getItem() != Items.TOTEM_OF_UNDYING) {
/* 20 */       for (int i = 9; i < 36; i++) {
/* 21 */         if (mc.player.inventory.getStackInSlot(i).getItem() == Items.TOTEM_OF_UNDYING) {
/* 22 */           mc.playerController.windowClick(0, i, ((Integer)this.slot.getValue()).intValue() - 1, ClickType.SWAP, (EntityPlayer)mc.player);
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHudInfo() {
/* 33 */     int totems = mc.player.inventory.mainInventory.stream().filter(itemStack -> (itemStack.getItem() == Items.TOTEM_OF_UNDYING)).mapToInt(ItemStack::getCount).sum();
/* 34 */     if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
/* 35 */       totems++;
/*    */     }
/* 37 */     return "[" + ChatFormatting.WHITE + "Totem " + totems + ChatFormatting.GRAY + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\Anti32kTotem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
