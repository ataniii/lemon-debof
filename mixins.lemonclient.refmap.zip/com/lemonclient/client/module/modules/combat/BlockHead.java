//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.modules.dev.PistonAura;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "BlockHead", category = Category.Combat)
/*     */ public class BlockHead extends Module {
/*  32 */   IntegerSetting delay = registerInteger("Delay", 0, 0, 20);
/*  33 */   DoubleSetting range = registerDouble("Range", 5.0D, 0.0D, 10.0D);
/*  34 */   IntegerSetting maxTarget = registerInteger("Max Target", 1, 1, 10);
/*  35 */   DoubleSetting maxSpeed = registerDouble("Max Target Speed", 10.0D, 0.0D, 50.0D);
/*  36 */   IntegerSetting bpt = registerInteger("BlocksPerTick", 4, 0, 20);
/*  37 */   BooleanSetting rotate = registerBoolean("Rotate", false);
/*  38 */   BooleanSetting packet = registerBoolean("Packet Place", false);
/*  39 */   BooleanSetting swing = registerBoolean("Swing", false);
/*  40 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true);
/*  41 */   BooleanSetting check = registerBoolean("Switch Check", true);
/*  42 */   BooleanSetting pause = registerBoolean("BedrockHole", true); int ob;
/*     */   
/*     */   public static boolean isPlayerInHole(EntityPlayer target) {
/*  45 */     BlockPos blockPos = getLocalPlayerPosFloored(target);
/*  46 */     HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(blockPos, true, true, false);
/*  47 */     HoleUtil.HoleType holeType = holeInfo.getType();
/*  48 */     return (holeType == HoleUtil.HoleType.SINGLE);
/*     */   }
/*     */   int waited; int placed;
/*     */   
/*     */   private void switchTo(int slot) {
/*  53 */     if (slot > -1 && slot < 9 && (
/*  54 */       !((Boolean)this.check.getValue()).booleanValue() || mc.player.inventory.currentItem != slot)) {
/*  55 */       if (((Boolean)this.packetSwitch.getValue()).booleanValue()) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/*     */       else
/*  57 */       { mc.player.inventory.currentItem = slot;
/*  58 */         mc.playerController.updateController(); }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static BlockPos getLocalPlayerPosFloored(EntityPlayer target) {
/*  65 */     return new BlockPos(target.getPositionVector());
/*     */   }
/*     */   
/*  68 */   BlockPos[] block = new BlockPos[] { new BlockPos(0, 0, 0), new BlockPos(0, 1, 0) };
/*     */ 
/*     */ 
/*     */   
/*  72 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, -1), new BlockPos(0, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/*  80 */     for (Entity entity : mc.world.loadedEntityList) {
/*  81 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && 
/*  82 */         !(entity instanceof net.minecraft.entity.item.EntityArmorStand) && (
/*  83 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/*  84 */         return true; 
/*     */     } 
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  91 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*  92 */       return;  this.placed = 0;
/*  93 */     if (this.waited++ < ((Integer)this.delay.getValue()).intValue())
/*     */       return; 
/*  95 */     this.waited = 0;
/*  96 */     this.ob = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/*  97 */     if (this.ob == -1)
/*  98 */       return;  int oldSlot = mc.player.inventory.currentItem;
/*  99 */     for (EntityPlayer target : PlayerUtil.getNearPlayers(((Double)this.range.getValue()).doubleValue(), ((Integer)this.maxTarget.getValue()).intValue())) {
/* 100 */       if (target == null || EntityUtil.isDead((Entity)target) || 
/* 101 */         LemonClient.speedUtil.getPlayerSpeed(target) > ((Double)this.maxSpeed.getValue()).doubleValue() || 
/* 102 */         !isPlayerInHole(target))
/* 103 */         continue;  BlockPos pos = new BlockPos(target.posX, target.posY + 0.5D, target.posZ);
/*     */       
/* 105 */       int bedrock = 0;
/* 106 */       for (BlockPos side : this.sides) {
/* 107 */         if (mc.world.getBlockState(pos.add((Vec3i)side)).getBlock() == Blocks.BEDROCK)
/* 108 */           bedrock++; 
/*     */       } 
/* 110 */       if (bedrock >= 4 && !((Boolean)this.pause.getValue()).booleanValue())
/*     */         continue; 
/* 112 */       if (!mc.world.isAirBlock(pos.up(2)) || 
/* 113 */         intersectsWithEntity(pos.up(2)))
/*     */         continue; 
/* 115 */       if (BurrowUtil.getFirstFacing(pos.up(2)) == null) {
/* 116 */         List<BlockPos> posList = new ArrayList<>(), list = new ArrayList<>();
/* 117 */         for (BlockPos blockPos1 : this.sides) {
/* 118 */           BlockPos crystalPos = pos.add((Vec3i)blockPos1);
/* 119 */           if (!PistonAura.INSTANCE.canPistonCrystal(crystalPos, pos))
/* 120 */             posList.add(crystalPos); 
/* 121 */           list.add(crystalPos);
/*     */         } 
/* 123 */         if (posList.isEmpty()) {
/* 124 */           for (BlockPos blockPos1 : this.sides) {
/* 125 */             BlockPos crystalPos = pos.add((Vec3i)blockPos1);
/* 126 */             if (!PistonAura.INSTANCE.canPistonCrystal(crystalPos.up(), pos))
/* 127 */               posList.add(crystalPos); 
/* 128 */             list.add(crystalPos);
/*     */           } 
/*     */         }
/* 131 */         if (posList.isEmpty()) posList.addAll(list); 
/* 132 */         BlockPos side = posList.stream().max(Comparator.comparing(PlayerUtil::getDistance)).orElse(null);
/* 133 */         if (side == null)
/*     */           continue; 
/* 135 */         for (BlockPos add : this.block) {
/* 136 */           if (this.placed > ((Integer)this.bpt.getValue()).intValue())
/*     */             return; 
/* 138 */           BlockPos obsi = side.up().add((Vec3i)add);
/* 139 */           if (!intersectsWithEntity(obsi) && BlockUtil.canReplace(obsi)) {
/* 140 */             switchTo(this.ob);
/* 141 */             BurrowUtil.placeBlock(obsi, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 142 */             switchTo(oldSlot);
/* 143 */             this.placed++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 148 */       if (this.placed > ((Integer)this.bpt.getValue()).intValue())
/* 149 */         return;  switchTo(this.ob);
/* 150 */       BurrowUtil.placeBlock(pos.up(2), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/* 151 */       switchTo(oldSlot);
/* 152 */       this.placed++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\BlockHead.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
