//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.event.events.PacketEvent;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.RotationUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*     */ import com.lemonclient.client.module.Module.Declaration;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.dev.BedCevBreaker;
/*     */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import me.zero.alpine.listener.Listener;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "AutoCity", category = Category.Combat)
/*     */ public class AutoCityDev extends Module {
/*     */   public static AutoCityDev INSTANCE;
/*     */   ModeSetting breakBlock;
/*     */   
/*     */   public AutoCityDev() {
/*  37 */     this.breakBlock = registerMode("Break Block", Arrays.asList(new String[] { "Normal", "Packet" }, ), "Packet");
/*  38 */     this.range = registerInteger("Range", 6, 0, 10);
/*  39 */     this.swing = registerBoolean("Swing", false);
/*  40 */     this.rotate = registerBoolean("Rotate", true);
/*  41 */     this.ignore = registerBoolean("Ignore Bed", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.listener = new Listener(event -> { if (!((Boolean)this.rotate.getValue()).booleanValue()) return;  if (event.getPacket() instanceof CPacketPlayer) { CPacketPlayer packet = (CPacketPlayer)event.getPacket(); packet.yaw = this.yaw; packet.pitch = this.pitch; }  }new java.util.function.Predicate[0]);
/*     */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   IntegerSetting range;
/*     */   BooleanSetting swing;
/*     */   BooleanSetting rotate;
/*     */   BooleanSetting ignore;
/*     */   public boolean working;
/*     */   float pitch;
/*     */   float yaw;
/*     */   BlockPos blockMine;
/*     */   @EventHandler
/*     */   private final Listener<PacketEvent.Send> listener;
/*     */   
/*     */   public void onUpdate() {
/*     */     if (mc.world == null || mc.player == null || mc.player.isDead)
/*     */       return; 
/*     */     this.working = false;
/*     */     if (AntiBurrow.INSTANCE.mining || AntiRegear.INSTANCE.working || CevBreaker.INSTANCE.working || BedCevBreaker.INSTANCE.working)
/*     */       return; 
/*     */     BlockPos instantPos = null;
/*     */     if (ModuleManager.isModuleEnabled(PacketMine.class))
/*     */       instantPos = PacketMine.INSTANCE.packetPos; 
/*     */     if (instantPos != null) {
/*     */       if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY + 2.0D, mc.player.posZ)))
/*     */         return; 
/*     */       if (instantPos.equals(new BlockPos(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ)))
/*     */         return; 
/*     */       if (mc.world.getBlockState(instantPos).getBlock() == Blocks.WEB)
/*     */         return; 
/*     */       if (this.blockMine != null && !isPos2(this.blockMine, instantPos))
/*     */         this.blockMine = null; 
/*     */     } else {
/*     */       this.blockMine = null;
/*     */     } 
/*     */     EntityPlayer aimTarget = PlayerUtil.getNearestPlayer((((Integer)this.range.getValue()).intValue() + 2));
/*     */     if (aimTarget == null)
/*     */       return; 
/*     */     BlockPos[] offsets = { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*     */     BlockPos playerPos = EntityUtil.getEntityPos((Entity)aimTarget);
/*     */     if (this.blockMine != null)
/*     */       if (mc.player.getDistance(this.blockMine.x + 0.5D, this.blockMine.y + 0.5D, this.blockMine.z + 0.5D) > ((Integer)this.range.getValue()).intValue()) {
/*     */         this.blockMine = null;
/*     */       } else {
/*     */         boolean same = false;
/*     */         for (BlockPos offset : offsets) {
/*     */           if (isPos2(playerPos.add((Vec3i)offset), this.blockMine))
/*     */             same = true; 
/*     */         } 
/*     */         if (!same)
/*     */           this.blockMine = null; 
/*     */       }  
/*     */     boolean hole = true;
/*     */     for (BlockPos offset : offsets) {
/*     */       BlockPos pos = playerPos.add((Vec3i)offset);
/*     */       IBlockState blockState = BlockUtil.getState(pos);
/*     */       if (BlockUtil.isAir(pos) || (((Boolean)this.ignore.getValue()).booleanValue() && blockState == Blocks.BED))
/*     */         hole = false; 
/*     */     } 
/*     */     if (!hole)
/*     */       return; 
/*     */     if (this.blockMine != null) {
/*     */       this.working = true;
/*     */       return;
/*     */     } 
/*     */     EnumFacing facing = RotationUtil.getFacing((PlayerPacketManager.INSTANCE.getServerSideRotation()).x);
/*     */     this.blockMine = playerPos.offset(facing, -1);
/*     */     if (mc.player.getDistance(this.blockMine.x + 0.5D, this.blockMine.y + 0.5D, this.blockMine.z + 0.5D) > ((Integer)this.range.getValue()).intValue() || (((Boolean)this.ignore.getValue()).booleanValue() && BlockUtil.getBlock(this.blockMine) == Blocks.BED) || (BlockUtil.getBlock(this.blockMine)).blockHardness < 0.0F) {
/*     */       List<BlockPos> posList = new ArrayList<>();
/*     */       for (BlockPos offset : offsets) {
/*     */         BlockPos pos = playerPos.add((Vec3i)offset);
/*     */         if (mc.player.getDistanceSq(pos) <= (((Integer)this.range.getValue()).intValue() * ((Integer)this.range.getValue()).intValue()) && BlockUtil.getBlock(pos) != Blocks.BEDROCK) {
/*     */           if (((Boolean)this.ignore.getValue()).booleanValue() && BlockUtil.getBlock(pos) == Blocks.BED)
/*     */             return; 
/*     */           if (mc.player.getDistance(pos.x + 0.5D, pos.y + 0.5D, pos.z + 0.5D) <= ((Integer)this.range.getValue()).intValue())
/*     */             posList.add(pos); 
/*     */         } 
/*     */       } 
/*     */       this.blockMine = posList.stream().min(Comparator.comparing(p -> Double.valueOf(mc.player.getDistance(p.x + 0.5D, p.y + 0.5D, p.z + 0.5D)))).orElse(null);
/*     */     } 
/*     */     if (this.blockMine == null)
/*     */       return; 
/*     */     this.working = true;
/*     */     if (((Boolean)this.swing.getValue()).booleanValue())
/*     */       mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */     if (((String)this.breakBlock.getValue()).equalsIgnoreCase("Packet")) {
/*     */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.blockMine, EnumFacing.UP));
/*     */       mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.blockMine, EnumFacing.UP));
/*     */     } else {
/*     */       mc.playerController.onPlayerDamageBlock(this.blockMine, EnumFacing.UP);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isPos2(BlockPos pos1, BlockPos pos2) {
/*     */     if (pos1 == null || pos2 == null)
/*     */       return false; 
/*     */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\AutoCityDev.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
