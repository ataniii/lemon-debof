//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.module.modules.combat;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.player.BurrowUtil;
/*     */ import com.lemonclient.api.util.player.InventoryUtil;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.player.PredictUtil;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.exploits.PacketMine;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockSlab;
/*     */ import net.minecraft.block.BlockTrapDoor;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ @Declaration(name = "HoleFill", category = Category.Combat, priority = 999)
/*     */ public class HoleFill extends Module {
/*  42 */   BooleanSetting test = registerBoolean("Test", false);
/*  43 */   ModeSetting page = registerMode("Page", Arrays.asList(new String[] { "Target", "Place", "HoleFill", "SelfFill" }, ), "Target");
/*  44 */   IntegerSetting maxTarget = registerInteger("Max Target", 10, 1, 50, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  45 */   IntegerSetting tickAdd = registerInteger("Tick Add", 8, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  46 */   IntegerSetting maxTick = registerInteger("Max Tick", 8, 0, 30, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  47 */   BooleanSetting calculateYPredict = registerBoolean("Calculate Y Predict", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  48 */   IntegerSetting startDecrease = registerInteger("Start Decrease", 39, 0, 200, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  49 */   IntegerSetting exponentStartDecrease = registerInteger("Exponent Start", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  50 */   IntegerSetting decreaseY = registerInteger("Decrease Y", 2, 1, 5, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  51 */   IntegerSetting exponentDecreaseY = registerInteger("Exponent Decrease Y", 1, 1, 3, () -> Boolean.valueOf((((Boolean)this.calculateYPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  52 */   BooleanSetting splitXZ = registerBoolean("Split XZ", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  53 */   BooleanSetting manualOutHole = registerBoolean("Manual Out Hole", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  54 */   BooleanSetting aboveHoleManual = registerBoolean("Above Hole Manual", false, () -> Boolean.valueOf((((Boolean)this.manualOutHole.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  55 */   BooleanSetting stairPredict = registerBoolean("Stair Predict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Target")));
/*  56 */   IntegerSetting nStair = registerInteger("N Stair", 2, 1, 4, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*  57 */   DoubleSetting speedActivationStair = registerDouble("Speed Activation Stair", 0.3D, 0.0D, 1.0D, () -> Boolean.valueOf((((Boolean)this.stairPredict.getValue()).booleanValue() && ((String)this.page.getValue()).equals("Target"))));
/*     */   
/*  59 */   IntegerSetting delay = registerInteger("Calc Delay", 0, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  60 */   BooleanSetting upPlate = registerBoolean("Up Slab", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  61 */   BooleanSetting selfFill = registerBoolean("Self Fill", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  62 */   BooleanSetting mine = registerBoolean("Mine SelfFill", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.selfFill.getValue()).booleanValue())));
/*  63 */   BooleanSetting selfTrap = registerBoolean("Self Trap", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  64 */   BooleanSetting yCheck = registerBoolean("Y Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  65 */   BooleanSetting web = registerBoolean("Web", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.yCheck.getValue()).booleanValue())));
/*  66 */   BooleanSetting above = registerBoolean("Above", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.yCheck.getValue()).booleanValue())));
/*  67 */   BooleanSetting raytraceCheck = registerBoolean("Raytrace Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  68 */   BooleanSetting holeCheck = registerBoolean("InHole Check", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  69 */   IntegerSetting placeDelay = registerInteger("Place Delay", 50, 0, 1000, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  70 */   IntegerSetting bpc = registerInteger("Block pre Tick", 6, 1, 20, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  71 */   DoubleSetting range = registerDouble("Range", 6.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  72 */   DoubleSetting yRange = registerDouble("Y Range", 2.5D, 0.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  73 */   DoubleSetting playerRange = registerDouble("Enemy Range", 3.0D, 0.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  74 */   DoubleSetting playerYRange = registerDouble("Enemy YRange", 3.0D, 0.0D, 10.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  75 */   DoubleSetting safety = registerDouble("Safety Range", 3.0D, 0.0D, 6.0D, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  76 */   BooleanSetting rotate = registerBoolean("Rotate", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  77 */   BooleanSetting strict = registerBoolean("Strict", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  78 */   BooleanSetting raytrace = registerBoolean("RayTrace", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  79 */   BooleanSetting onGround = registerBoolean("OnGround", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  80 */   BooleanSetting packet = registerBoolean("Packet Place", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  81 */   BooleanSetting swing = registerBoolean("Swing", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  82 */   BooleanSetting packetSwitch = registerBoolean("Packet Switch", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*     */   
/*  84 */   BooleanSetting render = registerBoolean("Render", false, () -> Boolean.valueOf(((String)this.page.getValue()).equals("Place")));
/*  85 */   BooleanSetting box = registerBoolean("Box", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue())));
/*  86 */   BooleanSetting outline = registerBoolean("Outline", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue())));
/*  87 */   IntegerSetting width = registerInteger("Width", 1, 1, 5, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  88 */   ColorSetting color = registerColor("Color", new GSColor(255, 0, 0), () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue())));
/*  89 */   IntegerSetting alpha = registerInteger("Alpha", 75, 0, 255, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.box.getValue()).booleanValue())));
/*  90 */   IntegerSetting outAlpha = registerInteger("Outline Alpha", 125, 0, 255, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.outline.getValue()).booleanValue())));
/*  91 */   BooleanSetting animate = registerBoolean("Animate", true, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue())));
/*  92 */   IntegerSetting time = registerInteger("Life Time", 1000, 0, 2500, () -> Boolean.valueOf((((String)this.page.getValue()).equals("Place") && ((Boolean)this.render.getValue()).booleanValue())));
/*     */   
/*  94 */   BooleanSetting hObby = registerBoolean("H-Obby", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*  95 */   BooleanSetting hEChest = registerBoolean("H-EChest", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*  96 */   BooleanSetting hWeb = registerBoolean("H-Web", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*  97 */   BooleanSetting hSlab = registerBoolean("H-Slab", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*  98 */   BooleanSetting hSkull = registerBoolean("H-Skull", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*  99 */   BooleanSetting hTrap = registerBoolean("H-Trapdoor", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("HoleFill")));
/*     */   
/* 101 */   BooleanSetting sObby = registerBoolean("S-Obby", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 102 */   BooleanSetting sEChest = registerBoolean("S-EChest", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 103 */   BooleanSetting sWeb = registerBoolean("S-Web", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 104 */   BooleanSetting sSlab = registerBoolean("S-Slab", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 105 */   BooleanSetting sSkull = registerBoolean("S-Skull", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 106 */   BooleanSetting sTrap = registerBoolean("S-Trapdoor", true, () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 107 */   ModeSetting jumpMode = registerMode("JumpMode", Arrays.asList(new String[] { "Normal", "Future", "Strict" }, ), "Normal", () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 108 */   ModeSetting rubberBand = registerMode("RubberBand", Arrays.asList(new String[] { "Cn", "Strict", "Future", "FutureStrict", "Troll", "Void", "Auto", "Test", "Custom" }, ), "Cn", () -> Boolean.valueOf(((String)this.page.getValue()).equals("SelfFill")));
/* 109 */   managerClassRenderBlocks managerRenderBlocks = new managerClassRenderBlocks();
/* 110 */   List<BlockPos> posList = new ArrayList<>();
/* 111 */   Timing timer = new Timing();
/* 112 */   Timing placeTimer = new Timing(); boolean trapdoor; boolean mined;
/*     */   boolean self;
/*     */   boolean placedSelf;
/*     */   int placed;
/*     */   BlockPos savePos;
/* 117 */   BlockPos[] sides = new BlockPos[] { new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fast() {
/* 126 */     if (mc.world == null || mc.player == null || (!mc.player.onGround && ((Boolean)this.onGround.getValue()).booleanValue()))
/*     */       return; 
/* 128 */     this.managerRenderBlocks.update(((Integer)this.time.getValue()).intValue());
/* 129 */     if (this.timer.passedMs(((Integer)this.delay.getValue()).intValue())) {
/* 130 */       this.posList = calc();
/* 131 */       this.timer.reset();
/*     */     } 
/*     */     
/* 134 */     if (this.placeTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue())) {
/* 135 */       for (BlockPos pos : this.posList) {
/* 136 */         if (this.placed >= ((Integer)this.bpc.getValue()).intValue())
/* 137 */           break;  placeBlock(pos);
/*     */       } 
/* 139 */       this.placeTimer.reset();
/*     */     } 
/*     */     
/* 142 */     if (((Boolean)this.mine.getValue()).booleanValue() && !this.self && this.placedSelf) {
/* 143 */       if (this.mined) {
/* 144 */         if (mc.world.isAirBlock(PlayerUtil.getPlayerPos())) {
/* 145 */           if (this.savePos != null) { mc.playerController.onPlayerDamageBlock(this.savePos, EnumFacing.UP); }
/*     */           
/* 147 */           else if (ModuleManager.isModuleEnabled(PacketMine.class))
/* 148 */           { PacketMine.INSTANCE.lastBlock = null; }
/*     */           
/* 150 */           this.mined = false;
/* 151 */           this.placedSelf = false;
/*     */         } 
/* 153 */       } else if (!mc.world.isAirBlock(PlayerUtil.getPlayerPos())) {
/* 154 */         BlockPos instantPos = null;
/* 155 */         if (ModuleManager.isModuleEnabled(PacketMine.class)) {
/* 156 */           instantPos = PacketMine.INSTANCE.packetPos;
/*     */         }
/* 158 */         this.savePos = instantPos;
/* 159 */         mc.playerController.onPlayerDamageBlock(PlayerUtil.getPlayerPos(), EnumFacing.UP);
/* 160 */         this.mined = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isPos2(BlockPos pos1, BlockPos pos2) {
/* 166 */     if (pos1 == null || pos2 == null)
/* 167 */       return false; 
/* 168 */     return (pos1.x == pos2.x && pos1.y == pos2.y && pos1.z == pos2.z);
/*     */   }
/*     */   
/*     */   private List<BlockPos> calc() {
/* 172 */     if (mc.world == null || mc.player == null || mc.player.isDead)
/* 173 */       return new ArrayList<>(); 
/* 174 */     this.placed = 0;
/* 175 */     List<HoleInfo> holeList = new ArrayList<>();
/* 176 */     for (BlockPos pos : EntityUtil.getSphere(PlayerUtil.getEyesPos(), Double.valueOf(((Double)this.range.getValue()).doubleValue() + 1.0D), Double.valueOf(((Double)this.yRange.getValue()).doubleValue() + 1.0D), false, false, 0)) {
/* 177 */       if (!BlockUtil.canReplace(pos) || !BlockUtil.canReplace(pos.up()))
/* 178 */         continue;  HoleUtil.HoleInfo holeInfo = HoleUtil.isHole(pos, false, true, false);
/* 179 */       HoleUtil.HoleType holeType = holeInfo.getType();
/* 180 */       if (holeType == HoleUtil.HoleType.NONE)
/* 181 */         continue;  AxisAlignedBB box = holeInfo.getCentre();
/* 182 */       holeList.add(new HoleInfo(pos, new AxisAlignedBB(box.minX - ((Double)this.playerRange.getValue()).doubleValue(), box.minY, box.minZ - ((Double)this.playerRange.getValue()).doubleValue(), box.maxX + ((Double)this.playerRange.getValue()).doubleValue(), box.maxY + ((Double)this.playerYRange.getValue()).doubleValue(), box.maxZ + ((Double)this.playerRange.getValue()).doubleValue())));
/*     */     } 
/*     */     
/* 185 */     List<BlockPos> holePos = new ArrayList<>();
/* 186 */     List<EntityPlayer> targets = (List<EntityPlayer>)PlayerUtil.getNearPlayers(((Double)this.range.getValue()).doubleValue() + ((Double)this.playerRange.getValue()).doubleValue(), this.maxTarget.getMax()).stream().filter(player -> (!((Boolean)this.holeCheck.getValue()).booleanValue() || !HoleUtil.isInHole((Entity)player, false, false, false))).collect(Collectors.toList());
/* 187 */     if (((Boolean)this.test.getValue()).booleanValue()) targets.add(mc.player); 
/* 188 */     List<EntityPlayer> listPlayer = new ArrayList<>();
/* 189 */     for (EntityPlayer player : targets) {
/* 190 */       int tick; for (tick = 0; tick <= ((Integer)this.maxTick.getValue()).intValue() + ((Integer)this.tickAdd.getValue()).intValue(); tick += ((Integer)this.tickAdd.getValue()).intValue()) {
/* 191 */         if (tick >= ((Integer)this.maxTick.getValue()).intValue()) tick = ((Integer)this.maxTick.getValue()).intValue(); 
/* 192 */         listPlayer.add(PredictUtil.predictPlayer((EntityLivingBase)player, new PredictUtil.PredictSettings(((Integer)this.maxTick.getValue()).intValue(), ((Boolean)this.calculateYPredict.getValue()).booleanValue(), ((Integer)this.startDecrease.getValue()).intValue(), ((Integer)this.exponentStartDecrease.getValue()).intValue(), ((Integer)this.decreaseY.getValue()).intValue(), ((Integer)this.exponentDecreaseY.getValue()).intValue(), ((Boolean)this.splitXZ.getValue()).booleanValue(), ((Boolean)this.manualOutHole.getValue()).booleanValue(), ((Boolean)this.aboveHoleManual.getValue()).booleanValue(), ((Boolean)this.stairPredict.getValue()).booleanValue(), ((Integer)this.nStair.getValue()).intValue(), ((Double)this.speedActivationStair.getValue()).doubleValue())));
/* 193 */         if (tick == ((Integer)this.maxTick.getValue()).intValue())
/*     */           break; 
/*     */       } 
/*     */     } 
/* 197 */     boolean fill = false;
/*     */     
/* 199 */     BlockPos selfPos = PlayerUtil.getPlayerPos();
/* 200 */     for (HoleInfo hole : holeList) {
/* 201 */       label70: for (EntityPlayer target : listPlayer) {
/* 202 */         if (!target.boundingBox.intersects(hole.box))
/*     */           continue; 
/* 204 */         if (((Boolean)this.yCheck.getValue()).booleanValue() && (int)(target.posY + 0.5D) != hole.pos.y + 1)
/* 205 */           if (target.posY < (hole.pos.y + 1))
/* 206 */           { if (((Boolean)this.web.getValue()).booleanValue() && target.isInWeb)
/* 207 */               continue;  } else if (((Boolean)this.above.getValue()).booleanValue())
/* 208 */           { boolean cancel = false;
/* 209 */             for (int high = (int)target.posY - hole.pos.y + 1; high > 0; high--) {
/* 210 */               BlockPos pos = hole.pos.up(high);
/* 211 */               if (!BlockUtil.canReplace(pos) && !BlockUtil.isBlockUnSolid(pos)) {
/* 212 */                 cancel = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 216 */             if (cancel) {
/*     */               continue;
/*     */             } }
/*     */            
/* 220 */         if (((Boolean)this.raytraceCheck.getValue()).booleanValue() && !CrystalUtil.calculateRaytrace(target, new BlockPos(hole.pos.x, target.posY + target.eyeHeight, hole.pos.z)))
/*     */           continue; 
/* 222 */         if (isPos2(selfPos, hole.pos)) { fill = true; break label70; }
/* 223 */          holePos.add(hole.pos);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 228 */     this.self = fill;
/* 229 */     List<BlockPos> self = EntityUtil.getSphere(PlayerUtil.getPlayerPos(), (Double)this.safety.getValue(), (Double)this.safety.getValue(), false, false, 0);
/* 230 */     holePos.removeIf(pos -> ((self.contains(pos) && !isPlayer(pos)) || !checkPlaceRange(pos)));
/* 231 */     return holePos;
/*     */   }
/*     */   
/*     */   private boolean checkPlaceRange(BlockPos pos) {
/* 235 */     BlockPos playerPos = new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
/* 236 */     double x = playerPos.x - pos.x + 0.5D;
/* 237 */     double y = playerPos.y - pos.y + 0.5D;
/* 238 */     double z = playerPos.z - pos.z + 0.5D;
/* 239 */     return (x * x <= ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue() && y * y <= ((Double)this.yRange.getValue()).doubleValue() * ((Double)this.yRange.getValue()).doubleValue() && z * z <= ((Double)this.range.getValue()).doubleValue() * ((Double)this.range.getValue()).doubleValue());
/*     */   }
/*     */   
/*     */   private boolean intersectsWithEntity(BlockPos pos) {
/* 243 */     for (Entity entity : mc.world.loadedEntityList) {
/* 244 */       if (!(entity instanceof net.minecraft.entity.item.EntityItem) && (
/* 245 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 246 */         return true; 
/*     */     } 
/* 248 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isPlayer(BlockPos pos) {
/* 252 */     for (EntityPlayer entity : mc.world.playerEntities) {
/* 253 */       if (entity == mc.player && (
/* 254 */         new AxisAlignedBB(pos)).intersects(entity.getEntityBoundingBox()))
/* 255 */         return true; 
/*     */     } 
/* 257 */     return false;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 261 */     if (pos == null)
/* 262 */       return;  boolean isPlayer = isPlayer(pos);
/* 263 */     if (isPlayer && ((Boolean)this.selfTrap.getValue()).booleanValue() && BlockUtil.canReplace(pos)) {
/* 264 */       int obby = BurrowUtil.findHotbarBlock(BlockObsidian.class);
/* 265 */       if (obby != -1) {
/* 266 */         switchTo(obby, () -> {
/*     */               BlockPos ori = pos.up();
/*     */               if (BurrowUtil.getFirstFacing(pos.up(2)) == null) {
/*     */                 BlockPos e = null;
/*     */                 boolean isNull = true;
/*     */                 for (BlockPos side : this.sides) {
/*     */                   BlockPos added = ori.up().add((Vec3i)side);
/*     */                   if (!intersectsWithEntity(added) && BurrowUtil.getFirstFacing(added) != null) {
/*     */                     e = added;
/*     */                     isNull = false;
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */                 if (isNull) {
/*     */                   for (BlockPos side : this.sides) {
/*     */                     BlockPos added = ori.add((Vec3i)side);
/*     */                     if (!intersectsWithEntity(added) && !intersectsWithEntity(added.up())) {
/*     */                       placeTrapBlock(added);
/*     */                       e = added.up();
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */                 placeTrapBlock(e);
/*     */               } 
/*     */               placeTrapBlock(pos.up(2));
/*     */             });
/*     */       }
/*     */     } 
/* 295 */     if (ColorMain.INSTANCE.breakList.contains(pos))
/* 296 */       return;  if ((isPlayer && !((Boolean)this.selfFill.getValue()).booleanValue()) || (intersectsWithEntity(pos) && !isPlayer) || !BlockUtil.canReplace(pos))
/* 297 */       return;  int slot = findRightBlock(isPlayer);
/* 298 */     if (slot == -1)
/* 299 */       return;  this.trapdoor = (slot == InventoryUtil.findFirstBlockSlot(BlockTrapDoor.class, 0, 8) || (((Boolean)this.upPlate.getValue()).booleanValue() && slot == BurrowUtil.findHotbarBlock(BlockSlab.class)));
/* 300 */     boolean jump = (slot == BurrowUtil.findHotbarBlock(BlockEnderChest.class) || slot == BurrowUtil.findHotbarBlock(BlockObsidian.class));
/* 301 */     EnumFacing side = this.trapdoor ? BurrowUtil.getTrapdoorFacing(pos) : BlockUtil.getFirstFacing(pos, ((Boolean)this.strict.getValue()).booleanValue(), ((Boolean)this.raytrace.getValue()).booleanValue());
/* 302 */     if (side == null)
/* 303 */       return;  BlockPos neighbour = pos.offset(side);
/* 304 */     EnumFacing opposite = side.getOpposite();
/* 305 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, this.trapdoor ? 0.8D : 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*     */     
/* 307 */     if ((BlockUtil.blackList.contains(mc.world.getBlockState(neighbour).getBlock()) || BlockUtil.shulkerList.contains(mc.world.getBlockState(neighbour).getBlock())) && !mc.player.isSneaking()) {
/* 308 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 309 */       mc.player.setSneaking(true);
/*     */     } 
/*     */     
/* 312 */     if (isPlayer) {
/* 313 */       this.placedSelf = true;
/* 314 */       if (this.trapdoor) {
/* 315 */         double x = mc.player.posX;
/* 316 */         double y = (int)mc.player.posY;
/* 317 */         double z = mc.player.posZ;
/* 318 */         if (slot == InventoryUtil.findFirstBlockSlot(BlockTrapDoor.class, 0, 8)) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y + 0.20000000298023224D, z, mc.player.onGround)); }
/* 319 */         else { jump(); }
/*     */         
/* 321 */         mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/* 322 */         BurrowUtil.rightClickBlock(neighbour, opposite, new Vec3d(0.5D, 0.8D, 0.5D), true, ((Boolean)this.swing.getValue()).booleanValue());
/* 323 */         if (slot == InventoryUtil.findFirstBlockSlot(BlockTrapDoor.class, 0, 8)) { mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y, z, mc.player.onGround)); }
/* 324 */         else { rubberBand(); }
/* 325 */          mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(mc.player.inventory.currentItem)); return;
/*     */       } 
/* 327 */       if (jump) jump(); 
/*     */     } 
/* 329 */     if (((Boolean)this.rotate.getValue()).booleanValue()) BurrowUtil.faceVector(hitVec, true); 
/* 330 */     switchTo(slot, () -> BurrowUtil.rightClickBlock(neighbour, hitVec, EnumHand.MAIN_HAND, opposite, ((Boolean)this.packet.getValue()).booleanValue(), ((Boolean)this.swing.getValue()).booleanValue()));
/* 331 */     if (isPlayer) rubberBand(); 
/* 332 */     this.managerRenderBlocks.addRender(pos);
/* 333 */     this.placed++;
/*     */   }
/*     */   
/*     */   private void switchTo(int slot, Runnable runnable) {
/* 337 */     int oldslot = mc.player.inventory.currentItem;
/* 338 */     if (slot < 0 || slot == oldslot) {
/* 339 */       runnable.run();
/*     */       return;
/*     */     } 
/* 342 */     if (slot < 9) {
/* 343 */       boolean packetSwitch = ((Boolean)this.packetSwitch.getValue()).booleanValue();
/* 344 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot)); }
/* 345 */       else { mc.player.inventory.currentItem = slot; }
/* 346 */        runnable.run();
/* 347 */       if (packetSwitch) { mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(oldslot)); }
/* 348 */       else { mc.player.inventory.currentItem = oldslot; }
/*     */     
/*     */     } 
/*     */   }
/*     */   public static BlockPos getFlooredPosition(Entity entity) {
/* 353 */     return new BlockPos(Math.floor(entity.posX), Math.round(entity.posY), Math.floor(entity.posZ));
/*     */   }
/*     */   private void placeTrapBlock(BlockPos pos) {
/* 356 */     if (ColorMain.INSTANCE.breakList.contains(pos))
/* 357 */       return;  BurrowUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false, ((Boolean)this.swing.getValue()).booleanValue());
/*     */   }
/*     */   
/*     */   private int findRightBlock(boolean selfFill) {
/* 361 */     int slot = -1;
/* 362 */     if (selfFill) {
/* 363 */       if (((Boolean)this.sTrap.getValue()).booleanValue()) slot = InventoryUtil.findFirstBlockSlot(BlockTrapDoor.class, 0, 8); 
/* 364 */       if (((Boolean)this.sSkull.getValue()).booleanValue() && slot == -1) slot = InventoryUtil.findSkullSlot(); 
/* 365 */       if (((Boolean)this.sWeb.getValue()).booleanValue() && slot == -1) slot = InventoryUtil.findFirstBlockSlot(BlockWeb.class, 0, 8); 
/* 366 */       if (((Boolean)this.sSlab.getValue()).booleanValue() && slot == -1) slot = BurrowUtil.findHotbarBlock(BlockSlab.class); 
/* 367 */       if (((Boolean)this.sEChest.getValue()).booleanValue() && slot == -1) slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class); 
/* 368 */       if (((Boolean)this.sObby.getValue()).booleanValue() && slot == -1) slot = BurrowUtil.findHotbarBlock(BlockObsidian.class); 
/*     */     } else {
/* 370 */       if (((Boolean)this.hObby.getValue()).booleanValue()) slot = BurrowUtil.findHotbarBlock(BlockObsidian.class); 
/* 371 */       if (((Boolean)this.hEChest.getValue()).booleanValue() && slot == -1) slot = BurrowUtil.findHotbarBlock(BlockEnderChest.class); 
/* 372 */       if (((Boolean)this.hSlab.getValue()).booleanValue() && slot == -1) slot = BurrowUtil.findHotbarBlock(BlockSlab.class); 
/* 373 */       if (((Boolean)this.hWeb.getValue()).booleanValue() && slot == -1) slot = InventoryUtil.findFirstBlockSlot(BlockWeb.class, 0, 8); 
/* 374 */       if (((Boolean)this.hSkull.getValue()).booleanValue() && slot == -1) slot = InventoryUtil.findSkullSlot(); 
/* 375 */       if (((Boolean)this.hTrap.getValue()).booleanValue()) slot = InventoryUtil.findFirstBlockSlot(BlockTrapDoor.class, 0, 8); 
/*     */     } 
/* 377 */     return slot;
/*     */   }
/*     */   
/*     */   public void onWorldRender(RenderEvent event) {
/* 381 */     this.managerRenderBlocks.render();
/*     */   }
/*     */   
/*     */   class managerClassRenderBlocks {
/* 385 */     ArrayList<HoleFill.renderBlock> blocks = new ArrayList<>();
/*     */     void update(int time) {
/* 387 */       this.blocks.removeIf(e -> (System.currentTimeMillis() - e.start > time));
/*     */     }
/*     */ 
/*     */     
/*     */     void render() {
/* 392 */       this.blocks.forEach(HoleFill.renderBlock::render);
/*     */     }
/*     */     
/*     */     void addRender(BlockPos pos) {
/* 396 */       boolean render = true;
/* 397 */       for (HoleFill.renderBlock block : this.blocks) {
/* 398 */         if (HoleFill.this.sameBlockPos(block.pos, pos)) {
/* 399 */           render = false;
/* 400 */           block.resetTime(); break;
/*     */         } 
/*     */       } 
/* 403 */       if (render)
/* 404 */         this.blocks.add(new HoleFill.renderBlock(pos)); 
/*     */     } }
/*     */   
/*     */   boolean sameBlockPos(BlockPos first, BlockPos second) {
/* 408 */     if (first == null || second == null)
/* 409 */       return false; 
/* 410 */     return (first.getX() == second.getX() && first.getY() == second.getY() && first.getZ() == second.getZ());
/*     */   }
/*     */   
/*     */   class renderBlock {
/*     */     private final BlockPos pos;
/*     */     private long start;
/*     */     
/*     */     public renderBlock(BlockPos pos) {
/* 418 */       this.start = System.currentTimeMillis();
/* 419 */       this.pos = pos;
/*     */     }
/*     */ 
/*     */     
/*     */     void resetTime() {
/* 424 */       this.start = System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void render() {
/* 430 */       AxisAlignedBB alignedBB = new AxisAlignedBB(this.pos);
/* 431 */       if (((Boolean)HoleFill.this.animate.getValue()).booleanValue()) alignedBB = alignedBB.grow(delta() * delta() * delta() / 2.0D - 1.0D); 
/* 432 */       if (((Boolean)HoleFill.this.box.getValue()).booleanValue()) RenderUtil.drawBox(alignedBB, true, 1.0D, new GSColor(HoleFill.this.color.getColor(), returnGradient()), 63); 
/* 433 */       if (((Boolean)HoleFill.this.outline.getValue()).booleanValue()) RenderUtil.drawBoundingBox(alignedBB, ((Integer)HoleFill.this.width.getValue()).intValue(), new GSColor(HoleFill.this.color.getColor(), returnOutGradient()));
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     public double delta() {
/* 439 */       long end = this.start + ((Integer)HoleFill.this.time.getValue()).intValue();
/* 440 */       double result = (end - System.currentTimeMillis()) / (end - this.start);
/* 441 */       if (result < 0.0D) result = 0.0D; 
/* 442 */       if (result > 1.0D) result = 1.0D; 
/* 443 */       return 1.0D - result;
/*     */     }
/*     */ 
/*     */     
/*     */     public int returnGradient() {
/* 448 */       return (int)(((Integer)HoleFill.this.alpha.getValue()).intValue() * delta());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int returnOutGradient() {
/* 454 */       return (int)(((Integer)HoleFill.this.outAlpha.getValue()).intValue() * delta());
/*     */     }
/*     */   }
/*     */   
/*     */   public static void back() {
/* 459 */     for (Entity crystal : mc.world.loadedEntityList.stream().filter(e -> (e instanceof net.minecraft.entity.item.EntityEnderCrystal && !e.isDead)).sorted(Comparator.comparing(e -> Float.valueOf(mc.player.getDistance(e)))).collect(Collectors.toList())) {
/* 460 */       if (crystal instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/* 461 */         mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
/* 462 */         mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean canGoTo(BlockPos pos) {
/* 468 */     return (isAir(pos) && isAir(pos.up()));
/*     */   }
/*     */   
/*     */   public static boolean isAir(Vec3d vec3d) {
/* 472 */     return isAir(new BlockPos(vec3d));
/*     */   }
/*     */   public static boolean isAir(BlockPos pos) {
/* 475 */     return BlockUtil.canReplace(pos);
/*     */   }
/*     */   
/*     */   public static Vec3d getEyesPos() {
/* 479 */     return new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */   
/*     */   private void jump() {
/* 483 */     switch ((String)this.jumpMode.getValue()) {
/*     */       case "Normal":
/* 485 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419999986886978D, mc.player.posZ, false));
/* 486 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7531999805212015D, mc.player.posZ, false));
/* 487 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.001335979112147D, mc.player.posZ, false));
/* 488 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.166109260938214D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Future":
/* 492 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419997486886978D, mc.player.posZ, false));
/* 493 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7500025D, mc.player.posZ, false));
/* 494 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.999995D, mc.player.posZ, false));
/* 495 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170005001788139D, mc.player.posZ, false));
/* 496 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.2426050013947485D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Strict":
/* 500 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419998586886978D, mc.player.posZ, false));
/* 501 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7500014D, mc.player.posZ, false));
/* 502 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.9999972D, mc.player.posZ, false));
/* 503 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170002801788139D, mc.player.posZ, false));
/* 504 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.170009801788139D, mc.player.posZ, false));
/*     */         break;
/*     */     }  } private void rubberBand() {
/*     */     double distance;
/*     */     BlockPos bestPos;
/*     */     int i;
/*     */     int j;
/* 511 */     switch ((String)this.rubberBand.getValue()) {
/*     */       case "Cn":
/* 513 */         distance = 0.0D;
/* 514 */         bestPos = null;
/* 515 */         for (BlockPos pos : BlockUtil.getBox(6.0F)) {
/* 516 */           if (!canGoTo(pos) || 
/* 517 */             mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 3.0D) {
/*     */             continue;
/*     */           }
/* 520 */           if (bestPos != null && mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) >= distance) {
/*     */             continue;
/*     */           }
/* 523 */           bestPos = pos;
/* 524 */           distance = mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
/*     */         } 
/*     */         
/* 527 */         if (bestPos != null) {
/* 528 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(bestPos.getX() + 0.5D, bestPos.getY(), bestPos.getZ() + 0.5D, false)); break;
/*     */         } 
/* 530 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Future":
/* 534 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.242609801394749D, mc.player.posZ, false));
/* 535 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 2.340028003576279D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "FutureStrict":
/* 539 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.315205001001358D, mc.player.posZ, false));
/* 540 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.315205001001358D, mc.player.posZ, false));
/* 541 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 2.485225002789497D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Troll":
/* 545 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 3.3400880035762786D, mc.player.posZ, false));
/* 546 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Strict":
/* 550 */         distance = 0.0D;
/* 551 */         bestPos = null;
/* 552 */         for (i = 0; i < 20; i++) {
/* 553 */           BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY + 0.5D + i, mc.player.posZ);
/* 554 */           if (canGoTo(pos) && 
/* 555 */             mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 5.0D && (
/* 556 */             bestPos == null || mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) < distance)) {
/* 557 */             bestPos = pos;
/* 558 */             distance = mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 563 */         if (bestPos != null) {
/* 564 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(bestPos.getX() + 0.5D, bestPos.getY(), bestPos.getZ() + 0.5D, false)); break;
/*     */         } 
/* 566 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Void":
/* 570 */         mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, -7.0D, mc.player.posZ, false));
/*     */         break;
/*     */       
/*     */       case "Auto":
/* 574 */         for (j = -10; j < 10; j++) {
/* 575 */           if (j == -1)
/* 576 */             j = 4; 
/* 577 */           if (mc.world.getBlockState(getFlooredPosition((Entity)mc.player).add(0, j, 0)).getBlock().equals(Blocks.AIR) && mc.world.getBlockState(getFlooredPosition((Entity)mc.player).add(0, j + 1, 0)).getBlock().equals(Blocks.AIR)) {
/* 578 */             BlockPos pos = getFlooredPosition((Entity)mc.player).add(0, j, 0);
/* 579 */             mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(pos.getX() + 0.3D, pos.getY(), pos.getZ() + 0.3D, false));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   static class HoleInfo {
/*     */     BlockPos pos;
/*     */     AxisAlignedBB box;
/*     */     
/*     */     public HoleInfo(BlockPos pos, AxisAlignedBB box) {
/* 592 */       this.pos = pos;
/* 593 */       this.box = box;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\modules\combat\HoleFill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
