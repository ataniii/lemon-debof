/*    */ package com.lemonclient.client.module;
/*    */ 
/*    */ public enum Category {
/*  4 */   Combat,
/*  5 */   Dev,
/*  6 */   Exploits,
/*  7 */   GUI,
/*  8 */   HUD,
/*  9 */   Misc,
/* 10 */   Movement,
/* 11 */   qwq,
/* 12 */   Render;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */