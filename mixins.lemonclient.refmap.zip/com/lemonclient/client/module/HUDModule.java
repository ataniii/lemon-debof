/*    */ package com.lemonclient.client.module;
/*    */ 
/*    */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*    */ import com.lukflug.panelstudio.base.IInterface;
/*    */ import com.lukflug.panelstudio.component.IFixedComponent;
/*    */ import com.lukflug.panelstudio.theme.ITheme;
/*    */ import java.awt.Point;
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HUDModule
/*    */   extends Module
/*    */ {
/*    */   public static final int LIST_BORDER = 1;
/*    */   protected IFixedComponent component;
/*    */   
/*    */   private Declaration getDeclaration() {
/* 25 */     return getClass().<Declaration>getAnnotation(Declaration.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 30 */   protected Point position = new Point(getDeclaration().posX(), getDeclaration().posZ());
/*    */   
/*    */   public abstract void populate(ITheme paramITheme);
/*    */   
/*    */   public IFixedComponent getComponent() {
/* 35 */     return this.component;
/*    */   }
/*    */   
/*    */   public void resetPosition() {
/* 39 */     this.component.setPosition((IInterface)LemonClientGUI.guiInterface, this.position);
/*    */   }
/*    */   
/*    */   @Retention(RetentionPolicy.RUNTIME)
/*    */   @Target({ElementType.TYPE})
/*    */   public static @interface Declaration {
/*    */     int posX();
/*    */     
/*    */     int posZ();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\module\HUDModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */