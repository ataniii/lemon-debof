/*     */ package com.lemonclient.client.clickgui;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.lukflug.panelstudio.config.IConfigList;
/*     */ import com.lukflug.panelstudio.config.IPanelConfig;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ 
/*     */ public class GuiConfig
/*     */   implements IConfigList
/*     */ {
/*     */   private final String fileLocation;
/*  26 */   private JsonObject panelObject = null;
/*     */   
/*     */   public GuiConfig(String fileLocation) {
/*  29 */     this.fileLocation = fileLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void begin(boolean loading) {
/*  34 */     if (loading) {
/*  35 */       Path path = Paths.get(this.fileLocation + "ClickGUI.json", new String[0]);
/*  36 */       if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/*  41 */         InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/*  42 */         JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*  43 */         if (mainObject.get("Panels") == null) {
/*     */           return;
/*     */         }
/*  46 */         this.panelObject = mainObject.get("Panels").getAsJsonObject();
/*  47 */         inputStream.close();
/*  48 */       } catch (IOException e) {
/*  49 */         e.printStackTrace();
/*     */       } 
/*     */     } else {
/*  52 */       this.panelObject = new JsonObject();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void end(boolean loading) {
/*  58 */     if (this.panelObject == null)
/*  59 */       return;  if (!loading) {
/*     */       try {
/*  61 */         Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/*  62 */         OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get(this.fileLocation + "ClickGUI.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/*  63 */         JsonObject mainObject = new JsonObject();
/*  64 */         mainObject.add("Panels", (JsonElement)this.panelObject);
/*  65 */         String jsonString = gson.toJson((new JsonParser()).parse(mainObject.toString()));
/*  66 */         fileOutputStreamWriter.write(jsonString);
/*  67 */         fileOutputStreamWriter.close();
/*  68 */       } catch (IOException e) {
/*  69 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*  72 */     this.panelObject = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPanelConfig addPanel(String title) {
/*  77 */     if (this.panelObject == null) return null; 
/*  78 */     JsonObject valueObject = new JsonObject();
/*  79 */     this.panelObject.add(title, (JsonElement)valueObject);
/*  80 */     return new GSPanelConfig(valueObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPanelConfig getPanel(String title) {
/*  85 */     if (this.panelObject == null) return null; 
/*  86 */     JsonElement configObject = this.panelObject.get(title);
/*  87 */     if (configObject != null && configObject.isJsonObject())
/*  88 */       return new GSPanelConfig(configObject.getAsJsonObject()); 
/*  89 */     return null;
/*     */   }
/*     */   
/*     */   private static class GSPanelConfig
/*     */     implements IPanelConfig
/*     */   {
/*     */     private final JsonObject configObject;
/*     */     
/*     */     public GSPanelConfig(JsonObject configObject) {
/*  98 */       this.configObject = configObject;
/*     */     }
/*     */ 
/*     */     
/*     */     public void savePositon(Point position) {
/* 103 */       this.configObject.add("PosX", (JsonElement)new JsonPrimitive(Integer.valueOf(position.x)));
/* 104 */       this.configObject.add("PosY", (JsonElement)new JsonPrimitive(Integer.valueOf(position.y)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void saveSize(Dimension size) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Point loadPosition() {
/* 114 */       Point point = new Point();
/* 115 */       JsonElement panelPosXObject = this.configObject.get("PosX");
/* 116 */       if (panelPosXObject != null && panelPosXObject.isJsonPrimitive())
/* 117 */       { point.x = panelPosXObject.getAsInt(); }
/* 118 */       else { return null; }
/* 119 */        JsonElement panelPosYObject = this.configObject.get("PosY");
/* 120 */       if (panelPosYObject != null && panelPosYObject.isJsonPrimitive())
/* 121 */       { point.y = panelPosYObject.getAsInt(); }
/* 122 */       else { return null; }
/* 123 */        return point;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dimension loadSize() {
/* 128 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void saveState(boolean state) {
/* 133 */       this.configObject.add("State", (JsonElement)new JsonPrimitive(Boolean.valueOf(state)));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean loadState() {
/* 138 */       JsonElement panelOpenObject = this.configObject.get("State");
/* 139 */       if (panelOpenObject != null && panelOpenObject.isJsonPrimitive()) {
/* 140 */         return panelOpenObject.getAsBoolean();
/*     */       }
/* 142 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\clickgui\GuiConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */