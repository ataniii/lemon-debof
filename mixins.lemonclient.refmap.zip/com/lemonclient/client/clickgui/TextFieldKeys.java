/*    */ package com.lemonclient.client.clickgui;
/*    */ 
/*    */ import com.lukflug.panelstudio.widget.ITextFieldKeys;
/*    */ 
/*    */ public class TextFieldKeys
/*    */   implements ITextFieldKeys
/*    */ {
/*    */   public boolean isBackspaceKey(int scancode) {
/*  9 */     return (scancode == 14);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeleteKey(int scancode) {
/* 14 */     return (scancode == 211);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInsertKey(int scancode) {
/* 19 */     return (scancode == 210);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLeftKey(int scancode) {
/* 24 */     return (scancode == 203);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRightKey(int scancode) {
/* 29 */     return (scancode == 205);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isHomeKey(int scancode) {
/* 34 */     return (scancode == 199);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEndKey(int scancode) {
/* 39 */     return (scancode == 207);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCopyKey(int scancode) {
/* 44 */     return (scancode == 46);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPasteKey(int scancode) {
/* 49 */     return (scancode == 47);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCutKey(int scancode) {
/* 54 */     return (scancode == 45);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAllKey(int scancode) {
/* 59 */     return (scancode == 30);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\clickgui\TextFieldKeys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */