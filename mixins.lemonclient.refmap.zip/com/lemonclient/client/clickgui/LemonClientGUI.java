//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.client.clickgui;
/*     */ import com.lemonclient.api.setting.Setting;
/*     */ import com.lemonclient.api.setting.SettingsManager;
/*     */ import com.lemonclient.api.setting.values.BooleanSetting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.DoubleSetting;
/*     */ import com.lemonclient.api.setting.values.IntegerSetting;
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.lemonclient.api.setting.values.StringSetting;
/*     */ import com.lemonclient.api.util.font.FontUtil;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.Category;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ClickGuiModule;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.lukflug.panelstudio.base.Animation;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IBoolean;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.base.IToggleable;
/*     */ import com.lukflug.panelstudio.base.SimpleToggleable;
/*     */ import com.lukflug.panelstudio.component.IComponent;
/*     */ import com.lukflug.panelstudio.component.IFixedComponent;
/*     */ import com.lukflug.panelstudio.component.IFixedComponentProxy;
/*     */ import com.lukflug.panelstudio.component.IScrollSize;
/*     */ import com.lukflug.panelstudio.container.IContainer;
/*     */ import com.lukflug.panelstudio.layout.CSGOLayout;
/*     */ import com.lukflug.panelstudio.layout.ChildUtil;
/*     */ import com.lukflug.panelstudio.layout.ComponentGenerator;
/*     */ import com.lukflug.panelstudio.layout.IComponentAdder;
/*     */ import com.lukflug.panelstudio.layout.PanelAdder;
/*     */ import com.lukflug.panelstudio.mc12.MinecraftGUI;
/*     */ import com.lukflug.panelstudio.popup.PopupTuple;
/*     */ import com.lukflug.panelstudio.setting.IBooleanSetting;
/*     */ import com.lukflug.panelstudio.setting.IColorSetting;
/*     */ import com.lukflug.panelstudio.setting.IKeybindSetting;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.setting.IModule;
/*     */ import com.lukflug.panelstudio.setting.INumberSetting;
/*     */ import com.lukflug.panelstudio.setting.ISetting;
/*     */ import com.lukflug.panelstudio.setting.IStringSetting;
/*     */ import com.lukflug.panelstudio.setting.Labeled;
/*     */ import com.lukflug.panelstudio.theme.ITextFieldRenderer;
/*     */ import com.lukflug.panelstudio.theme.ITheme;
/*     */ import com.lukflug.panelstudio.theme.ThemeTuple;
/*     */ import com.lukflug.panelstudio.widget.ITextFieldKeys;
/*     */ import com.lukflug.panelstudio.widget.TextField;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.util.Comparator;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.IntPredicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class LemonClientGUI extends MinecraftHUDGUI {
/*     */   public static LemonClientGUI INSTANCE;
/*     */   public static final int WIDTH = 100;
/*     */   public static final int HEIGHT = 12;
/*     */   public static final int FONT_HEIGHT = 9;
/*     */   public static final int DISTANCE = 10;
/*     */   
/*     */   public LemonClientGUI() {
/*  73 */     INSTANCE = this;
/*     */     
/*  75 */     final ClickGuiModule clickGuiModule = (ClickGuiModule)ModuleManager.getModule(ClickGuiModule.class);
/*  76 */     final ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/*     */ 
/*     */     
/*  79 */     guiInterface = new MinecraftGUI.GUIInterface(true)
/*     */       {
/*     */         public void drawString(Point pos, int height, String s, Color c) {
/*  82 */           GlStateManager.pushMatrix();
/*  83 */           GlStateManager.translate(pos.x, pos.y, 0.0F);
/*  84 */           double scale = height / (FontUtil.getFontHeight(((Boolean)colorMain.customFont.getValue()).booleanValue()) + (((Boolean)colorMain.customFont.getValue()).booleanValue() ? 1 : 0));
/*  85 */           end(false);
/*  86 */           FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), s, 0.0F, 0.0F, new GSColor(c));
/*  87 */           begin(false);
/*  88 */           GlStateManager.scale(scale, scale, 1.0D);
/*  89 */           GlStateManager.popMatrix();
/*     */         }
/*     */ 
/*     */         
/*     */         public int getFontWidth(int height, String s) {
/*  94 */           double scale = height / (FontUtil.getFontHeight(((Boolean)colorMain.customFont.getValue()).booleanValue()) + (((Boolean)colorMain.customFont.getValue()).booleanValue() ? 1 : 0));
/*  95 */           return (int)Math.round(FontUtil.getStringWidth(((Boolean)colorMain.customFont.getValue()).booleanValue(), s) * scale);
/*     */         }
/*     */ 
/*     */         
/*     */         public double getScreenWidth() {
/* 100 */           return super.getScreenWidth();
/*     */         }
/*     */ 
/*     */         
/*     */         public double getScreenHeight() {
/* 105 */           return super.getScreenHeight();
/*     */         }
/*     */ 
/*     */         
/*     */         public String getResourcePrefix() {
/* 110 */           return "lemonclient:gui/";
/*     */         }
/*     */       };
/* 113 */     this.clearTheme = (ITheme)new Theme(new GSColorScheme("clear", () -> Boolean.valueOf(true)), (Color)colorMain.Title.getValue(), (Color)colorMain.Enabled.getValue(), (Color)colorMain.Disabled.getValue(), (Color)colorMain.Background.getValue(), (Color)colorMain.Font.getValue(), (Color)colorMain.ScrollBar.getValue(), (Color)colorMain.Highlight.getValue(), () -> ((Boolean)clickGuiModule.gradient.getValue()).booleanValue(), 9, 3, 1, ": " + TextFormatting.GRAY);
/* 114 */     this.theme = (ITheme)(() -> this.clearTheme);
/*     */ 
/*     */     
/* 117 */     client = (() -> Arrays.<Category>stream(Category.values()).sorted(Comparator.comparing(Enum::toString)).map(()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     final SimpleToggleable guiToggle = new SimpleToggleable(false);
/* 193 */     SimpleToggleable simpleToggleable2 = new SimpleToggleable(false)
/*     */       {
/*     */         public boolean isOn() {
/* 196 */           if (guiToggle.isOn() && super.isOn()) return ((Boolean)clickGuiModule.showHUD.getValue()).booleanValue(); 
/* 197 */           return super.isOn();
/*     */         }
/*     */       };
/* 200 */     gui = new HUDGUI((IInterface)guiInterface, this.theme.getDescriptionRenderer(), (IPopupPositioner)new MousePositioner(new Point(10, 10)), (IToggleable)simpleToggleable1, (IToggleable)simpleToggleable2);
/* 201 */     final BiFunction<Context, Integer, Integer> scrollHeight = (context, componentHeight) -> ((String)clickGuiModule.scrolling.getValue()).equals("Screen") ? componentHeight : Integer.valueOf(Math.min(componentHeight.intValue(), Math.max(48, this.height - (context.getPos()).y - 12)));
/*     */ 
/*     */ 
/*     */     
/* 205 */     Supplier<Animation> animation = () -> new SettingsAnimation((), ());
/* 206 */     PopupTuple popupType = new PopupTuple((IPopupPositioner)new PanelPositioner(new Point(0, 0)), false, new IScrollSize()
/*     */         {
/*     */           public int getScrollHeight(Context context, int componentHeight) {
/* 209 */             return ((Integer)scrollHeight.apply(context, Integer.valueOf(componentHeight))).intValue();
/*     */           }
/*     */         });
/*     */     
/* 213 */     for (Module module : ModuleManager.getModules()) {
/* 214 */       if (module instanceof HUDModule) {
/* 215 */         ((HUDModule)module).populate(this.theme);
/* 216 */         gui.addHUDComponent(((HUDModule)module).getComponent(), new IToggleable()
/*     */             {
/*     */               public boolean isOn() {
/* 219 */                 return module.isEnabled();
/*     */               }
/*     */ 
/*     */               
/*     */               public void toggle() {
/* 224 */                 module.toggle();
/*     */               }
/* 226 */             },  animation.get(), this.theme, 2);
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     PanelAdder panelAdder1 = new PanelAdder(new IContainer<IFixedComponent>()
/*     */         {
/*     */           public boolean addComponent(final IFixedComponent component) {
/* 233 */             return LemonClientGUI.gui.addComponent((IFixedComponent)new IFixedComponentProxy<IFixedComponent>()
/*     */                 {
/*     */                   public void handleScroll(Context context, int diff) {
/* 236 */                     super.handleScroll(context, diff);
/* 237 */                     if (((String)clickGuiModule.scrolling.getValue()).equals("Screen")) {
/* 238 */                       Point p = getPosition((IInterface)LemonClientGUI.guiInterface);
/* 239 */                       p.translate(0, -diff);
/* 240 */                       setPosition((IInterface)LemonClientGUI.guiInterface, p);
/*     */                     } 
/*     */                   }
/*     */ 
/*     */                   
/*     */                   public IFixedComponent getComponent() {
/* 246 */                     return component;
/*     */                   }
/*     */                 });
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean addComponent(final IFixedComponent component, IBoolean visible) {
/* 253 */             return LemonClientGUI.gui.addComponent((IFixedComponent)new IFixedComponentProxy<IFixedComponent>()
/*     */                 {
/*     */                   public void handleScroll(Context context, int diff) {
/* 256 */                     super.handleScroll(context, diff);
/* 257 */                     if (((String)clickGuiModule.scrolling.getValue()).equals("Screen")) {
/* 258 */                       Point p = getPosition((IInterface)LemonClientGUI.guiInterface);
/* 259 */                       p.translate(0, -diff);
/* 260 */                       setPosition((IInterface)LemonClientGUI.guiInterface, p);
/*     */                     } 
/*     */                   }
/*     */ 
/*     */                   
/*     */                   public IFixedComponent getComponent() {
/* 266 */                     return component;
/*     */                   }
/*     */                 }visible);
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean removeComponent(IFixedComponent component) {
/* 273 */             return LemonClientGUI.gui.removeComponent(component);
/*     */           }
/*     */         }false, () -> !((Boolean)clickGuiModule.csgoLayout.getValue()).booleanValue(), title -> title)
/*     */       {
/*     */         protected IScrollSize getScrollSize(IResizable size) {
/* 278 */           return new IScrollSize()
/*     */             {
/*     */               public int getScrollHeight(Context context, int componentHeight) {
/* 281 */                 return ((Integer)scrollHeight.apply(context, Integer.valueOf(componentHeight))).intValue();
/*     */               }
/*     */             };
/*     */         }
/*     */       };
/* 286 */     ComponentGenerator componentGenerator = new ComponentGenerator(scancode -> (scancode == 211), character -> (character >= 32), new TextFieldKeys())
/*     */       {
/*     */         public IComponent getColorComponent(IColorSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/* 289 */           return (IComponent)new ColorPickerComponent(setting, theme);
/*     */         }
/*     */ 
/*     */         
/*     */         public IComponent getStringComponent(IStringSetting setting, Supplier<Animation> animation, IComponentAdder adder, ThemeTuple theme, int colorLevel, boolean isContainer) {
/* 294 */           return (IComponent)new TextField(setting, this.keys, 0, (IToggleable)new SimpleToggleable(false), theme.getTextRenderer(false, isContainer))
/*     */             {
/*     */               public boolean allowCharacter(char character) {
/* 297 */                 return (LemonClientGUI.null.this.charFilter.test(character) && character != '');
/*     */               }
/*     */             };
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 305 */     PanelLayout panelLayout = new PanelLayout(100, new Point(10, 10), 55, 22, animation, level -> ChildUtil.ChildMode.DOWN, level -> ChildUtil.ChildMode.DOWN, popupType);
/* 306 */     panelLayout.populateGUI((IComponentAdder)panelAdder1, (IComponentGenerator)componentGenerator, client, this.theme);
/*     */     
/* 308 */     PopupTuple colorPopup = new PopupTuple((IPopupPositioner)new CenteredPositioner(() -> new Rectangle(new Point(0, 0), guiInterface.getWindowSize())), true, new IScrollSize() {  });
/* 309 */     PanelAdder panelAdder2 = new PanelAdder((IContainer)gui, true, () -> ((Boolean)clickGuiModule.csgoLayout.getValue()).booleanValue(), title -> title);
/* 310 */     CSGOLayout cSGOLayout = new CSGOLayout((ILabeled)new Labeled("LemonClient", null, () -> true), new Point(100, 100), 480, 100, animation, "Enabled", true, true, 2, ChildUtil.ChildMode.DOWN, colorPopup)
/*     */       {
/*     */         public int getScrollHeight(Context context, int componentHeight) {
/* 313 */           return 320;
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isUpKey(int key) {
/* 318 */           return (key == 200);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isDownKey(int key) {
/* 323 */           return (key == 208);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isLeftKey(int key) {
/* 328 */           return (key == 203);
/*     */         }
/*     */ 
/*     */         
/*     */         protected boolean isRightKey(int key) {
/* 333 */           return (key == 205);
/*     */         }
/*     */       };
/* 336 */     cSGOLayout.populateGUI((IComponentAdder)panelAdder2, (IComponentGenerator)componentGenerator, client, this.theme);
/*     */   }
/*     */   public static final int HUD_BORDER = 2; public static IClient client; public static MinecraftGUI.GUIInterface guiInterface; public static HUDGUI gui; private final ITheme theme; private ITheme clearTheme;
/*     */   
/*     */   protected HUDGUI getGUI() {
/* 341 */     return gui;
/*     */   }
/*     */   
/*     */   private ISetting<?> createSetting(final Setting<?> setting) {
/* 345 */     if (setting instanceof BooleanSetting)
/* 346 */       return (ISetting<?>)new IBooleanSetting()
/*     */         {
/*     */           public String getDisplayName() {
/* 349 */             return setting.getName();
/*     */           }
/*     */ 
/*     */           
/*     */           public IBoolean isVisible() {
/* 354 */             return () -> setting.isVisible();
/*     */           }
/*     */ 
/*     */           
/*     */           public void toggle() {
/* 359 */             ((BooleanSetting)setting).setValue(Boolean.valueOf(!((Boolean)((BooleanSetting)setting).getValue()).booleanValue()));
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean isOn() {
/* 364 */             return ((Boolean)((BooleanSetting)setting).getValue()).booleanValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public Stream<ISetting<?>> getSubSettings() {
/* 369 */             if (setting.getSubSettings().count() == 0L) return null; 
/* 370 */             return setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/*     */           }
/*     */         }; 
/* 373 */     if (setting instanceof IntegerSetting)
/* 374 */       return (ISetting<?>)new INumberSetting()
/*     */         {
/*     */           public String getDisplayName() {
/* 377 */             return setting.getName();
/*     */           }
/*     */ 
/*     */           
/*     */           public IBoolean isVisible() {
/* 382 */             return () -> setting.isVisible();
/*     */           }
/*     */ 
/*     */           
/*     */           public double getNumber() {
/* 387 */             return ((Integer)((IntegerSetting)setting).getValue()).intValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public void setNumber(double value) {
/* 392 */             ((IntegerSetting)setting).setValue(Integer.valueOf((int)Math.round(value)));
/*     */           }
/*     */ 
/*     */           
/*     */           public double getMaximumValue() {
/* 397 */             return ((IntegerSetting)setting).getMax();
/*     */           }
/*     */ 
/*     */           
/*     */           public double getMinimumValue() {
/* 402 */             return ((IntegerSetting)setting).getMin();
/*     */           }
/*     */ 
/*     */           
/*     */           public int getPrecision() {
/* 407 */             return 0;
/*     */           }
/*     */ 
/*     */           
/*     */           public Stream<ISetting<?>> getSubSettings() {
/* 412 */             if (setting.getSubSettings().count() == 0L) return null; 
/* 413 */             return setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/*     */           }
/*     */         }; 
/* 416 */     if (setting instanceof DoubleSetting)
/* 417 */       return (ISetting<?>)new INumberSetting()
/*     */         {
/*     */           public String getDisplayName() {
/* 420 */             return setting.getName();
/*     */           }
/*     */ 
/*     */           
/*     */           public IBoolean isVisible() {
/* 425 */             return () -> setting.isVisible();
/*     */           }
/*     */ 
/*     */           
/*     */           public double getNumber() {
/* 430 */             return ((Double)((DoubleSetting)setting).getValue()).doubleValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public void setNumber(double value) {
/* 435 */             ((DoubleSetting)setting).setValue(Double.valueOf(value));
/*     */           }
/*     */ 
/*     */           
/*     */           public double getMaximumValue() {
/* 440 */             return ((DoubleSetting)setting).getMax();
/*     */           }
/*     */ 
/*     */           
/*     */           public double getMinimumValue() {
/* 445 */             return ((DoubleSetting)setting).getMin();
/*     */           }
/*     */ 
/*     */           
/*     */           public int getPrecision() {
/* 450 */             return 2;
/*     */           }
/*     */ 
/*     */           
/*     */           public Stream<ISetting<?>> getSubSettings() {
/* 455 */             if (setting.getSubSettings().count() == 0L) return null; 
/* 456 */             return setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/*     */           }
/*     */         }; 
/* 459 */     if (setting instanceof ModeSetting)
/* 460 */       return (ISetting<?>)new IEnumSetting()
/*     */         {
/*     */           private final ILabeled[] states;
/*     */           
/*     */           public String getDisplayName() {
/* 465 */             return setting.getName();
/*     */           }
/*     */ 
/*     */           
/*     */           public IBoolean isVisible() {
/* 470 */             return () -> setting.isVisible();
/*     */           }
/*     */ 
/*     */           
/*     */           public void increment() {
/* 475 */             ((ModeSetting)setting).increment();
/*     */           }
/*     */ 
/*     */           
/*     */           public void decrement() {
/* 480 */             ((ModeSetting)setting).decrement();
/*     */           }
/*     */ 
/*     */           
/*     */           public String getValueName() {
/* 485 */             return (String)((ModeSetting)setting).getValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public int getValueIndex() {
/* 490 */             return ((ModeSetting)setting).getModes().indexOf(getValueName());
/*     */           }
/*     */ 
/*     */           
/*     */           public void setValueIndex(int index) {
/* 495 */             ((ModeSetting)setting).setValue(((ModeSetting)setting).getModes().get(index));
/*     */           }
/*     */ 
/*     */           
/*     */           public ILabeled[] getAllowedValues() {
/* 500 */             return this.states;
/*     */           }
/*     */ 
/*     */           
/*     */           public Stream<ISetting<?>> getSubSettings() {
/* 505 */             if (setting.getSubSettings().count() == 0L) return null; 
/* 506 */             return setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/*     */           }
/*     */         }; 
/* 509 */     if (setting instanceof ColorSetting)
/* 510 */       return (ISetting<?>)new IColorSetting()
/*     */         {
/*     */           public String getDisplayName() {
/* 513 */             return TextFormatting.BOLD + setting.getName();
/*     */           }
/*     */ 
/*     */           
/*     */           public IBoolean isVisible() {
/* 518 */             return () -> setting.isVisible();
/*     */           }
/*     */ 
/*     */           
/*     */           public Color getValue() {
/* 523 */             return (Color)((ColorSetting)setting).getValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public void setValue(Color value) {
/* 528 */             ((ColorSetting)setting).setValue(new GSColor(value));
/*     */           }
/*     */ 
/*     */           
/*     */           public Color getColor() {
/* 533 */             return (Color)((ColorSetting)setting).getColor();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean getRainbow() {
/* 538 */             return ((ColorSetting)setting).getRainbow();
/*     */           }
/*     */ 
/*     */           
/*     */           public void setRainbow(boolean rainbow) {
/* 543 */             ((ColorSetting)setting).setRainbow(rainbow);
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean hasAlpha() {
/* 548 */             return ((ColorSetting)setting).alphaEnabled();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean allowsRainbow() {
/* 553 */             return ((ColorSetting)setting).rainbowEnabled();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean hasHSBModel() {
/* 558 */             return ((String)((ColorMain)ModuleManager.getModule(ColorMain.class)).colorModel.getValue()).equalsIgnoreCase("HSB");
/*     */           }
/*     */ 
/*     */           
/*     */           public Stream<ISetting<?>> getSubSettings() {
/* 563 */             Stream<ISetting<?>> temp = setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/* 564 */             return Stream.concat(temp, (Stream)Stream.of(new IBooleanSetting()
/*     */                   {
/*     */                     public String getDisplayName() {
/* 567 */                       return "Sync Color";
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public IBoolean isVisible() {
/* 572 */                       return () -> (setting != ((ColorMain)ModuleManager.getModule(ColorMain.class)).enabledColor);
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public void toggle() {
/* 577 */                       ((ColorSetting)setting).setValue(((ColorMain)ModuleManager.getModule(ColorMain.class)).enabledColor.getColor());
/* 578 */                       ((ColorSetting)setting).setRainbow(((ColorMain)ModuleManager.getModule(ColorMain.class)).enabledColor.getRainbow());
/*     */                     }
/*     */ 
/*     */                     
/*     */                     public boolean isOn() {
/* 583 */                       return ((ColorMain)ModuleManager.getModule(ColorMain.class)).enabledColor.getColor().equals(((ColorSetting)setting).getColor());
/*     */                     }
/*     */                   }));
/*     */           }
/*     */         }; 
/* 588 */     if (setting instanceof StringSetting) {
/* 589 */       return (ISetting<?>)new IStringSetting()
/*     */         {
/*     */           public String getValue() {
/* 592 */             return ((StringSetting)setting).getText();
/*     */           }
/*     */ 
/*     */           
/*     */           public void setValue(String string) {
/* 597 */             ((StringSetting)setting).setText(string);
/*     */           }
/*     */ 
/*     */           
/*     */           public String getDisplayName() {
/* 602 */             return setting.getName();
/*     */           }
/*     */         };
/*     */     }
/* 606 */     return new ISetting<Void>()
/*     */       {
/*     */         public String getDisplayName() {
/* 609 */           return setting.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public IBoolean isVisible() {
/* 614 */           return () -> setting.isVisible();
/*     */         }
/*     */ 
/*     */         
/*     */         public Void getSettingState() {
/* 619 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<Void> getSettingClass() {
/* 624 */           return Void.class;
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<ISetting<?>> getSubSettings() {
/* 629 */           if (setting.getSubSettings().count() == 0L) return null; 
/* 630 */           return setting.getSubSettings().map(subSetting -> LemonClientGUI.this.createSetting(subSetting));
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static void renderItem(ItemStack item, Point pos) {
/* 636 */     LemonClient.INSTANCE.gameSenseGUI.getInterface().end(false);
/* 637 */     GlStateManager.enableTexture2D();
/* 638 */     GlStateManager.depthMask(true);
/* 639 */     GL11.glPushAttrib(524288);
/* 640 */     GL11.glDisable(3089);
/* 641 */     GlStateManager.clear(256);
/* 642 */     GL11.glPopAttrib();
/* 643 */     GlStateManager.enableDepth();
/* 644 */     GlStateManager.disableAlpha();
/* 645 */     GlStateManager.pushMatrix();
/* 646 */     (Minecraft.getMinecraft().getRenderItem()).zLevel = -150.0F;
/* 647 */     RenderHelper.enableGUIStandardItemLighting();
/* 648 */     Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(item, pos.x, pos.y);
/* 649 */     Minecraft.getMinecraft().getRenderItem().renderItemOverlays((Minecraft.getMinecraft()).fontRenderer, item, pos.x, pos.y);
/* 650 */     RenderHelper.disableStandardItemLighting();
/* 651 */     (Minecraft.getMinecraft().getRenderItem()).zLevel = 0.0F;
/* 652 */     GlStateManager.popMatrix();
/* 653 */     GlStateManager.disableDepth();
/* 654 */     GlStateManager.depthMask(false);
/* 655 */     LemonClient.INSTANCE.gameSenseGUI.getInterface().begin(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderItemTest(ItemStack item, Point pos) {
/* 660 */     GlStateManager.enableTexture2D();
/* 661 */     GlStateManager.depthMask(true);
/* 662 */     GL11.glPushAttrib(524288);
/* 663 */     GL11.glDisable(3089);
/* 664 */     GlStateManager.clear(256);
/* 665 */     GL11.glPopAttrib();
/* 666 */     GlStateManager.enableDepth();
/* 667 */     GlStateManager.disableAlpha();
/* 668 */     GlStateManager.pushMatrix();
/* 669 */     (Minecraft.getMinecraft().getRenderItem()).zLevel = -150.0F;
/* 670 */     RenderHelper.enableGUIStandardItemLighting();
/* 671 */     Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(item, pos.x, pos.y);
/* 672 */     Minecraft.getMinecraft().getRenderItem().renderItemOverlays((Minecraft.getMinecraft()).fontRenderer, item, pos.x, pos.y);
/* 673 */     RenderHelper.disableStandardItemLighting();
/* 674 */     (Minecraft.getMinecraft().getRenderItem()).zLevel = 0.0F;
/* 675 */     GlStateManager.popMatrix();
/* 676 */     GlStateManager.disableDepth();
/* 677 */     GlStateManager.depthMask(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderEntity(EntityLivingBase entity, Point pos, int scale) {
/* 682 */     LemonClient.INSTANCE.gameSenseGUI.getInterface().end(false);
/* 683 */     GlStateManager.enableTexture2D();
/* 684 */     GlStateManager.depthMask(true);
/* 685 */     GL11.glPushAttrib(524288);
/* 686 */     GL11.glDisable(3089);
/* 687 */     GlStateManager.clear(256);
/* 688 */     GL11.glPopAttrib();
/* 689 */     GlStateManager.enableDepth();
/* 690 */     GlStateManager.disableAlpha();
/* 691 */     GlStateManager.pushMatrix();
/* 692 */     GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 693 */     GuiInventory.drawEntityOnScreen(pos.x, pos.y, scale, 28.0F, 60.0F, entity);
/* 694 */     GlStateManager.popMatrix();
/* 695 */     GlStateManager.disableDepth();
/* 696 */     GlStateManager.depthMask(false);
/* 697 */     LemonClient.INSTANCE.gameSenseGUI.getInterface().begin(false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MinecraftGUI.GUIInterface getInterface() {
/* 702 */     return guiInterface;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getScrollSpeed() {
/* 707 */     return ((Integer)((ClickGuiModule)ModuleManager.getModule(ClickGuiModule.class)).scrollSpeed.getValue()).intValue();
/*     */   }
/*     */   
/*     */   private static final class GSColorScheme
/*     */     implements IColorScheme {
/*     */     private final String configName;
/*     */     private final Supplier<Boolean> isVisible;
/*     */     
/*     */     public GSColorScheme(String configName, Supplier<Boolean> isVisible) {
/* 716 */       this.configName = configName;
/* 717 */       this.isVisible = isVisible;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void createSetting(ITheme theme, String name, String description, boolean hasAlpha, boolean allowsRainbow, Color color, boolean rainbow) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getColor(String name) {
/* 727 */       return new Color(255, 255, 255);
/*     */     }
/*     */   }
/*     */   
/*     */   public void refresh() {
/* 732 */     ClickGuiModule clickGuiModule = (ClickGuiModule)ModuleManager.getModule(ClickGuiModule.class);
/* 733 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 734 */     this.clearTheme = (ITheme)new Theme(new GSColorScheme("clear", () -> Boolean.valueOf(true)), (Color)colorMain.Title.getValue(), (Color)colorMain.Enabled.getValue(), (Color)colorMain.Disabled.getValue(), (Color)colorMain.Background.getValue(), (Color)colorMain.Font.getValue(), (Color)colorMain.ScrollBar.getValue(), (Color)colorMain.Highlight.getValue(), () -> ((Boolean)clickGuiModule.gradient.getValue()).booleanValue(), 9, 3, 1, ": " + TextFormatting.GRAY);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\clickgui\LemonClientGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
