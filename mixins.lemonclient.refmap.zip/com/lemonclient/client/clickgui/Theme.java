/*     */ package com.lemonclient.client.clickgui;
/*     */ import com.lukflug.panelstudio.base.Context;
/*     */ import com.lukflug.panelstudio.base.IInterface;
/*     */ import com.lukflug.panelstudio.setting.ILabeled;
/*     */ import com.lukflug.panelstudio.theme.IButtonRenderer;
/*     */ import com.lukflug.panelstudio.theme.ISwitchRenderer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class Theme extends ThemeBase {
/*     */   protected IBoolean gradient;
/*     */   protected int height;
/*     */   protected int padding;
/*     */   protected int border;
/*     */   protected String separator;
/*     */   Color title;
/*     */   
/*     */   public Theme(IColorScheme scheme, Color title, Color enable, Color disable, Color background, Color font, Color scrollBar, Color hgihlight, IBoolean gradient, int height, int padding, int border, String separator) {
/*  20 */     super(scheme);
/*  21 */     this.title = title;
/*  22 */     this.enable = enable;
/*  23 */     this.disable = disable;
/*  24 */     this.background = background;
/*  25 */     this.font = font;
/*  26 */     this.scrollBar = scrollBar;
/*  27 */     this.hgihlight = hgihlight;
/*  28 */     this.gradient = gradient;
/*  29 */     this.height = height;
/*  30 */     this.padding = padding;
/*  31 */     this.border = border;
/*  32 */     this.separator = separator;
/*     */   }
/*     */   Color enable; Color disable; Color background; Color font; Color scrollBar; Color hgihlight;
/*     */   protected void renderOverlay(Context context) {
/*  36 */     Color color = context.isHovered() ? new Color(0, 0, 0, 64) : new Color(0, 0, 0, 0);
/*  37 */     context.getInterface().fillRect(context.getRect(), color, color, color, color);
/*     */   }
/*     */   
/*     */   protected void renderBackground(Context context, boolean focus, int graphicalLevel) {
/*  41 */     if (graphicalLevel == 0) {
/*  42 */       Color color = getBackgroundColor(focus);
/*  43 */       context.getInterface().fillRect(context.getRect(), color, color, color, color);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void renderSmallButton(Context context, String title, int symbol, boolean focus) {
/*  48 */     Point[] points = new Point[3];
/*  49 */     int padding = ((context.getSize()).height <= 8) ? 2 : 4;
/*  50 */     Rectangle rect = new Rectangle((context.getPos()).x + padding / 2, (context.getPos()).y + padding / 2, (context.getSize()).height - 2 * padding / 2, (context.getSize()).height - 2 * padding / 2);
/*  51 */     if (title == null) rect.x += (context.getSize()).width / 2 - (context.getSize()).height / 2; 
/*  52 */     Color color = getFontColor(focus);
/*  53 */     switch (symbol) {
/*     */       case 1:
/*  55 */         context.getInterface().drawLine(new Point(rect.x, rect.y), new Point(rect.x + rect.width, rect.y + rect.height), color, color);
/*  56 */         context.getInterface().drawLine(new Point(rect.x, rect.y + rect.height), new Point(rect.x + rect.width, rect.y), color, color);
/*     */         break;
/*     */       case 2:
/*  59 */         context.getInterface().fillRect(new Rectangle(rect.x, rect.y + rect.height - 2, rect.width, 2), color, color, color, color);
/*     */         break;
/*     */       case 3:
/*  62 */         if (rect.width % 2 == 1) rect.width--; 
/*  63 */         if (rect.height % 2 == 1) rect.height--; 
/*  64 */         context.getInterface().fillRect(new Rectangle(rect.x + rect.width / 2 - 1, rect.y, 2, rect.height), color, color, color, color);
/*  65 */         context.getInterface().fillRect(new Rectangle(rect.x, rect.y + rect.height / 2 - 1, rect.width, 2), color, color, color, color);
/*     */         break;
/*     */       case 4:
/*  68 */         if (rect.height % 2 == 1) rect.height--; 
/*  69 */         points[2] = new Point(rect.x + rect.width, rect.y);
/*  70 */         points[1] = new Point(rect.x + rect.width, rect.y + rect.height);
/*  71 */         points[0] = new Point(rect.x, rect.y + rect.height / 2);
/*     */         break;
/*     */       case 5:
/*  74 */         if (rect.height % 2 == 1) rect.height--; 
/*  75 */         points[0] = new Point(rect.x, rect.y);
/*  76 */         points[1] = new Point(rect.x, rect.y + rect.height);
/*  77 */         points[2] = new Point(rect.x + rect.width, rect.y + rect.height / 2);
/*     */         break;
/*     */       case 6:
/*  80 */         if (rect.width % 2 == 1) rect.width--; 
/*  81 */         points[0] = new Point(rect.x, rect.y + rect.height);
/*  82 */         points[1] = new Point(rect.x + rect.width, rect.y + rect.height);
/*  83 */         points[2] = new Point(rect.x + rect.width / 2, rect.y);
/*     */         break;
/*     */       case 7:
/*  86 */         if (rect.width % 2 == 1) rect.width--; 
/*  87 */         points[2] = new Point(rect.x, rect.y);
/*  88 */         points[1] = new Point(rect.x + rect.width, rect.y);
/*  89 */         points[0] = new Point(rect.x + rect.width / 2, rect.y + rect.height);
/*     */         break;
/*     */     } 
/*  92 */     if (symbol >= 4 && symbol <= 7) {
/*  93 */       context.getInterface().fillTriangle(points[0], points[1], points[2], color, color, color);
/*     */     }
/*  95 */     if (title != null) context.getInterface().drawString(new Point((context.getPos()).x + ((symbol == 0) ? padding : (context.getSize()).height), (context.getPos()).y + padding), this.height, title, getFontColor(focus));
/*     */   
/*     */   }
/*     */   
/*     */   public IDescriptionRenderer getDescriptionRenderer() {
/* 100 */     return new IDescriptionRenderer()
/*     */       {
/*     */         public void renderDescription(IInterface inter, Point pos, String text) {
/* 103 */           Rectangle rect = new Rectangle(pos, new Dimension(inter.getFontWidth(Theme.this.height, text) + 2, Theme.this.height + 2));
/* 104 */           Color color = Theme.this.getBackgroundColor(true);
/* 105 */           inter.fillRect(rect, color, color, color, color);
/* 106 */           inter.drawString(new Point(pos.x + 1, pos.y + 1), Theme.this.height, text, Theme.this.getFontColor(true));
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IContainerRenderer getContainerRenderer(int logicalLevel, final int graphicalLevel, final boolean horizontal) {
/* 113 */     return new IContainerRenderer()
/*     */       {
/*     */         public void renderBackground(Context context, boolean focus) {
/* 116 */           Theme.this.renderBackground(context, focus, graphicalLevel);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getBorder() {
/* 121 */           return horizontal ? 0 : Theme.this.border;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getTop() {
/* 126 */           return horizontal ? 0 : Theme.this.border;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> IPanelRenderer<T> getPanelRenderer(Class<T> type, int logicalLevel, final int graphicalLevel) {
/* 133 */     return new IPanelRenderer<T>()
/*     */       {
/*     */         public void renderPanelOverlay(Context context, boolean focus, T state, boolean open) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void renderTitleOverlay(Context context, boolean focus, T state, boolean open) {
/* 140 */           if (graphicalLevel > 0) {
/* 141 */             Rectangle rect = context.getRect();
/* 142 */             rect = new Rectangle(rect.width - rect.height, 0, rect.height, rect.height);
/* 143 */             if (rect.width % 2 != 0) {
/* 144 */               rect.width--;
/* 145 */               rect.height--;
/* 146 */               rect.x++;
/*     */             } 
/* 148 */             Context subContext = new Context(context, rect.width, rect.getLocation(), true, true);
/* 149 */             subContext.setHeight(rect.height);
/* 150 */             if (open) { Theme.this.renderSmallButton(subContext, null, 7, focus); }
/* 151 */             else { Theme.this.renderSmallButton(subContext, null, 5, focus); }
/*     */           
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public <T> IScrollBarRenderer<T> getScrollBarRenderer(Class<T> type, int logicalLevel, final int graphicalLevel) {
/* 159 */     return new IScrollBarRenderer<T>()
/*     */       {
/*     */         public int renderScrollBar(Context context, boolean focus, T state, boolean horizontal, int height, int position) {
/* 162 */           Theme.this.renderBackground(context, focus, graphicalLevel);
/* 163 */           Color color = ITheme.combineColors(Theme.this.scrollBar, Theme.this.getBackgroundColor(focus));
/* 164 */           if (horizontal) {
/* 165 */             int a = (int)(position / height * (context.getSize()).width);
/* 166 */             int b = (int)((position + (context.getSize()).width) / height * (context.getSize()).width);
/* 167 */             context.getInterface().fillRect(new Rectangle((context.getPos()).x + a + 1, (context.getPos()).y + 1, b - a - 2, 2), color, color, color, color);
/* 168 */             context.getInterface().drawRect(new Rectangle((context.getPos()).x + a + 1, (context.getPos()).y + 1, b - a - 2, 2), color, color, color, color);
/*     */           } else {
/* 170 */             int a = (int)(position / height * (context.getSize()).height);
/* 171 */             int b = (int)((position + (context.getSize()).height) / height * (context.getSize()).height);
/* 172 */             context.getInterface().fillRect(new Rectangle((context.getPos()).x + 1, (context.getPos()).y + a + 1, 2, b - a - 2), color, color, color, color);
/* 173 */             context.getInterface().drawRect(new Rectangle((context.getPos()).x + 1, (context.getPos()).y + a + 1, 2, b - a - 2), color, color, color, color);
/*     */           } 
/* 175 */           if (horizontal) return (int)((((context.getInterface().getMouse()).x - (context.getPos()).x) * height) / (context.getSize()).width - (context.getSize()).width / 2.0D); 
/* 176 */           return (int)((((context.getInterface().getMouse()).y - (context.getPos()).y) * height) / (context.getSize()).height - (context.getSize()).height / 2.0D);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getThickness() {
/* 181 */           return 4;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> IEmptySpaceRenderer<T> getEmptySpaceRenderer(Class<T> type, int logicalLevel, final int graphicalLevel, boolean container) {
/* 188 */     return new IEmptySpaceRenderer<T>()
/*     */       {
/*     */         public void renderSpace(Context context, boolean focus, T state) {
/* 191 */           Theme.this.renderBackground(context, focus, graphicalLevel);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> IButtonRenderer<T> getButtonRenderer(final Class<T> type, int logicalLevel, final int graphicalLevel, final boolean container) {
/* 198 */     return new IButtonRenderer<T>()
/*     */       {
/*     */         public void renderButton(Context context, String title, boolean focus, T state) {
/* 201 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 202 */           if (container && graphicalLevel <= 0)
/* 203 */           { Color colorA = Theme.this.title, colorB = Theme.this.gradient.isOn() ? Theme.this.getBackgroundColor(effFocus) : colorA;
/* 204 */             context.getInterface().fillRect(context.getRect(), colorA, colorA, colorB, colorB); }
/* 205 */           else { Theme.this.renderBackground(context, effFocus, graphicalLevel); }
/* 206 */            Color color = Theme.this.getFontColor(effFocus);
/* 207 */           if (type == Boolean.class && ((Boolean)state).booleanValue()) { color = Theme.this.getMainColor(effFocus, true); }
/* 208 */           else if (type == Color.class) { color = (Color)state; }
/* 209 */            if (graphicalLevel > 0) Theme.this.renderOverlay(context); 
/* 210 */           if (type == String.class) { context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title + Theme.this.separator + state, color); }
/* 211 */           else { context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title, color); }
/*     */         
/*     */         }
/*     */         
/*     */         public int getDefaultHeight() {
/* 216 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IButtonRenderer<Void> getSmallButtonRenderer(final int symbol, final int logicalLevel, final int graphicalLevel, final boolean container) {
/* 223 */     return new IButtonRenderer<Void>()
/*     */       {
/*     */         public void renderButton(Context context, String title, boolean focus, Void state) {
/* 226 */           Theme.this.renderBackground(context, focus, graphicalLevel);
/* 227 */           Theme.this.renderOverlay(context);
/* 228 */           if (!container || logicalLevel <= 0) Theme.this.renderSmallButton(context, title, symbol, focus);
/*     */         
/*     */         }
/*     */         
/*     */         public int getDefaultHeight() {
/* 233 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IButtonRenderer<String> getKeybindRenderer(int logicalLevel, final int graphicalLevel, final boolean container) {
/* 240 */     return new IButtonRenderer<String>()
/*     */       {
/*     */         public void renderButton(Context context, String title, boolean focus, String state) {
/* 243 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 244 */           if (container && graphicalLevel <= 0)
/* 245 */           { Color colorA = Theme.this.title, colorB = Theme.this.gradient.isOn() ? Theme.this.getBackgroundColor(effFocus) : colorA;
/* 246 */             context.getInterface().fillRect(context.getRect(), colorA, colorA, colorB, colorB); }
/* 247 */           else { Theme.this.renderBackground(context, effFocus, graphicalLevel); }
/* 248 */            Color color = Theme.this.getFontColor(effFocus);
/* 249 */           if (effFocus) color = Theme.this.getMainColor(effFocus, true); 
/* 250 */           Theme.this.renderOverlay(context);
/* 251 */           context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title + Theme.this.separator + (focus ? "..." : state), color);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight() {
/* 256 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public ISliderRenderer getSliderRenderer(int logicalLevel, final int graphicalLevel, final boolean container) {
/* 263 */     return new ISliderRenderer()
/*     */       {
/*     */         public void renderSlider(Context context, String title, String state, boolean focus, double value) {
/* 266 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 267 */           Theme.this.renderBackground(context, effFocus, graphicalLevel);
/* 268 */           Color color = Theme.this.getFontColor(effFocus);
/* 269 */           Color colorA = Theme.this.getMainColor(effFocus, true);
/* 270 */           Rectangle rect = getSlideArea(context, title, state);
/* 271 */           int divider = (int)(rect.width * value);
/* 272 */           context.getInterface().fillRect(new Rectangle(rect.x, rect.y, divider, rect.height), colorA, colorA, colorA, colorA);
/* 273 */           Theme.this.renderOverlay(context);
/* 274 */           context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title + Theme.this.separator + state, color);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight() {
/* 279 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IRadioRenderer getRadioRenderer(int logicalLevel, final int graphicalLevel, boolean container) {
/* 286 */     return new IRadioRenderer()
/*     */       {
/*     */         public void renderItem(Context context, ILabeled[] items, boolean focus, int target, double state, boolean horizontal) {
/* 289 */           Theme.this.renderBackground(context, focus, graphicalLevel);
/* 290 */           for (int i = 0; i < items.length; i++) {
/* 291 */             Rectangle rect = getItemRect(context, items, i, horizontal);
/* 292 */             Context subContext = new Context(context.getInterface(), rect.width, rect.getLocation(), context.hasFocus(), context.onTop());
/* 293 */             subContext.setHeight(rect.height);
/* 294 */             Theme.this.renderOverlay(subContext);
/* 295 */             context.getInterface().drawString(new Point(rect.x + Theme.this.padding, rect.y + Theme.this.padding), Theme.this.height, items[i].getDisplayName(), (i == target) ? Theme.this.getMainColor(focus, true) : Theme.this.getFontColor(focus));
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight(ILabeled[] items, boolean horizontal) {
/* 301 */           return (horizontal ? 1 : items.length) * Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IResizeBorderRenderer getResizeRenderer() {
/* 308 */     return new IResizeBorderRenderer()
/*     */       {
/*     */         public void drawBorder(Context context, boolean focus) {
/* 311 */           Color color = Theme.this.getBackgroundColor(focus);
/* 312 */           Rectangle rect = context.getRect();
/* 313 */           context.getInterface().fillRect(new Rectangle(rect.x, rect.y, rect.width, getBorder()), color, color, color, color);
/* 314 */           context.getInterface().fillRect(new Rectangle(rect.x, rect.y + rect.height - getBorder(), rect.width, getBorder()), color, color, color, color);
/* 315 */           context.getInterface().fillRect(new Rectangle(rect.x, rect.y + getBorder(), getBorder(), rect.height - 2 * getBorder()), color, color, color, color);
/* 316 */           context.getInterface().fillRect(new Rectangle(rect.x + rect.width - getBorder(), rect.y + getBorder(), getBorder(), rect.height - 2 * getBorder()), color, color, color, color);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getBorder() {
/* 321 */           return 2;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public ITextFieldRenderer getTextRenderer(boolean embed, int logicalLevel, final int graphicalLevel, final boolean container) {
/* 328 */     return new ITextFieldRenderer()
/*     */       {
/*     */         public int renderTextField(Context context, String title, boolean focus, String content, int position, int select, int boxPosition, boolean insertMode) {
/* 331 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 332 */           Theme.this.renderBackground(context, effFocus, graphicalLevel);
/*     */           
/* 334 */           Color textColor = Theme.this.getFontColor(effFocus);
/* 335 */           Color highlightColor = Theme.this.hgihlight;
/* 336 */           Rectangle rect = getTextArea(context, title);
/* 337 */           int strlen = context.getInterface().getFontWidth(Theme.this.height, content.substring(0, position));
/* 338 */           context.getInterface().fillRect(rect, new Color(0, 0, 0, 64), new Color(0, 0, 0, 64), new Color(0, 0, 0, 64), new Color(0, 0, 0, 64));
/*     */           
/* 340 */           if (boxPosition < position)
/* 341 */           { int minPosition = boxPosition;
/* 342 */             while (minPosition < position && 
/* 343 */               context.getInterface().getFontWidth(Theme.this.height, content.substring(0, minPosition)) + rect.width - Theme.this.padding < strlen) {
/* 344 */               minPosition++;
/*     */             }
/* 346 */             if (boxPosition < minPosition) boxPosition = minPosition;  }
/* 347 */           else if (boxPosition > position) { boxPosition = position - 1; }
/* 348 */            int maxPosition = content.length();
/* 349 */           while (maxPosition > 0) {
/* 350 */             if (context.getInterface().getFontWidth(Theme.this.height, content.substring(maxPosition)) >= rect.width - Theme.this.padding) {
/* 351 */               maxPosition++;
/*     */               break;
/*     */             } 
/* 354 */             maxPosition--;
/*     */           } 
/* 356 */           if (boxPosition > maxPosition) { boxPosition = maxPosition; }
/* 357 */           else if (boxPosition < 0) { boxPosition = 0; }
/* 358 */            int offset = context.getInterface().getFontWidth(Theme.this.height, content.substring(0, boxPosition));
/*     */           
/* 360 */           int x1 = rect.x + Theme.this.padding / 2 - offset + strlen;
/* 361 */           int x2 = rect.x + Theme.this.padding / 2 - offset;
/* 362 */           if (position < content.length()) { x2 += context.getInterface().getFontWidth(Theme.this.height, content.substring(0, position + 1)); }
/* 363 */           else { x2 += context.getInterface().getFontWidth(Theme.this.height, content + "X"); }
/*     */           
/* 365 */           Theme.this.renderOverlay(context);
/* 366 */           context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding / 2), Theme.this.height, title + Theme.this.separator, textColor);
/*     */           
/* 368 */           context.getInterface().window(rect);
/* 369 */           if (select >= 0) {
/* 370 */             int x3 = rect.x + Theme.this.padding / 2 - offset + context.getInterface().getFontWidth(Theme.this.height, content.substring(0, select));
/* 371 */             context.getInterface().fillRect(new Rectangle(Math.min(x1, x3), rect.y + Theme.this.padding / 2, Math.abs(x3 - x1), Theme.this.height), highlightColor, highlightColor, highlightColor, highlightColor);
/*     */           } 
/* 373 */           context.getInterface().drawString(new Point(rect.x + Theme.this.padding / 2 - offset, rect.y + Theme.this.padding / 2), Theme.this.height, content, textColor);
/* 374 */           if (System.currentTimeMillis() / 500L % 2L == 0L && focus)
/* 375 */             if (insertMode) { context.getInterface().fillRect(new Rectangle(x1, rect.y + Theme.this.padding / 2 + Theme.this.height, x2 - x1, 1), textColor, textColor, textColor, textColor); }
/* 376 */             else { context.getInterface().fillRect(new Rectangle(x1, rect.y + Theme.this.padding / 2, 1, Theme.this.height), textColor, textColor, textColor, textColor); }
/*     */              
/* 378 */           context.getInterface().restore();
/* 379 */           return boxPosition;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight() {
/* 384 */           int height = Theme.this.getBaseHeight() - Theme.this.padding;
/* 385 */           if (height % 2 == 1) height++; 
/* 386 */           return height;
/*     */         }
/*     */ 
/*     */         
/*     */         public Rectangle getTextArea(Context context, String title) {
/* 391 */           Rectangle rect = context.getRect();
/* 392 */           int length = Theme.this.padding + context.getInterface().getFontWidth(Theme.this.height, title + Theme.this.separator);
/* 393 */           return new Rectangle(rect.x + length, rect.y, rect.width - length, rect.height);
/*     */         }
/*     */ 
/*     */         
/*     */         public int transformToCharPos(Context context, String title, String content, int boxPosition) {
/* 398 */           Rectangle rect = getTextArea(context, title);
/* 399 */           Point mouse = context.getInterface().getMouse();
/* 400 */           int offset = context.getInterface().getFontWidth(Theme.this.height, content.substring(0, boxPosition));
/* 401 */           if (rect.contains(mouse)) {
/* 402 */             for (int i = 1; i <= content.length(); i++) {
/* 403 */               if (rect.x + Theme.this.padding / 2 - offset + context.getInterface().getFontWidth(Theme.this.height, content.substring(0, i)) > mouse.x) {
/* 404 */                 return i - 1;
/*     */               }
/*     */             } 
/* 407 */             return content.length();
/*     */           } 
/* 409 */           return -1;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public ISwitchRenderer<Boolean> getToggleSwitchRenderer(int logicalLevel, final int graphicalLevel, final boolean container) {
/* 416 */     return new ISwitchRenderer<Boolean>()
/*     */       {
/*     */         public void renderButton(Context context, String title, boolean focus, Boolean state) {
/* 419 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 420 */           Theme.this.renderBackground(context, effFocus, graphicalLevel);
/* 421 */           Theme.this.renderOverlay(context);
/* 422 */           context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title + Theme.this.separator + (state.booleanValue() ? "On" : "Off"), Theme.this.getFontColor(focus));
/* 423 */           Color color = state.booleanValue() ? Theme.this.enable : Theme.this.disable;
/* 424 */           Color fillColor = ITheme.combineColors(color, Theme.this.getBackgroundColor(effFocus));
/* 425 */           Rectangle rect = state.booleanValue() ? getOnField(context) : getOffField(context);
/* 426 */           context.getInterface().fillRect(rect, fillColor, fillColor, fillColor, fillColor);
/* 427 */           rect = context.getRect();
/* 428 */           rect = new Rectangle(rect.x + rect.width - 2 * rect.height + 3 * Theme.this.padding, rect.y + Theme.this.padding, 2 * rect.height - 4 * Theme.this.padding, rect.height - 2 * Theme.this.padding);
/* 429 */           context.getInterface().drawRect(rect, color, color, color, color);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight() {
/* 434 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */ 
/*     */         
/*     */         public Rectangle getOnField(Context context) {
/* 439 */           Rectangle rect = context.getRect();
/* 440 */           return new Rectangle(rect.x + rect.width - rect.height + Theme.this.padding, rect.y + Theme.this.padding, rect.height - 2 * Theme.this.padding, rect.height - 2 * Theme.this.padding);
/*     */         }
/*     */ 
/*     */         
/*     */         public Rectangle getOffField(Context context) {
/* 445 */           Rectangle rect = context.getRect();
/* 446 */           return new Rectangle(rect.x + rect.width - 2 * rect.height + 3 * Theme.this.padding, rect.y + Theme.this.padding, rect.height - 2 * Theme.this.padding, rect.height - 2 * Theme.this.padding);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public ISwitchRenderer<String> getCycleSwitchRenderer(final int logicalLevel, final int graphicalLevel, final boolean container) {
/* 453 */     return new ISwitchRenderer<String>()
/*     */       {
/*     */         public void renderButton(Context context, String title, boolean focus, String state) {
/* 456 */           boolean effFocus = container ? context.hasFocus() : focus;
/* 457 */           Theme.this.renderBackground(context, effFocus, graphicalLevel);
/* 458 */           Context subContext = new Context(context, (context.getSize()).width - 2 * (context.getSize()).height, new Point(0, 0), true, true);
/* 459 */           subContext.setHeight((context.getSize()).height);
/* 460 */           Theme.this.renderOverlay(subContext);
/* 461 */           Color textColor = Theme.this.getFontColor(effFocus);
/* 462 */           context.getInterface().drawString(new Point((context.getPos()).x + Theme.this.padding, (context.getPos()).y + Theme.this.padding), Theme.this.height, title + Theme.this.separator + state, textColor);
/* 463 */           Rectangle rect = getOnField(context);
/* 464 */           subContext = new Context(context, rect.width, new Point(rect.x - (context.getPos()).x, 0), true, true);
/* 465 */           subContext.setHeight(rect.height);
/* 466 */           Theme.this.getSmallButtonRenderer(5, logicalLevel, graphicalLevel, container).renderButton(subContext, null, effFocus, null);
/* 467 */           rect = getOffField(context);
/* 468 */           subContext = new Context(context, rect.width, new Point(rect.x - (context.getPos()).x, 0), true, true);
/* 469 */           subContext.setHeight(rect.height);
/* 470 */           Theme.this.getSmallButtonRenderer(4, logicalLevel, graphicalLevel, false).renderButton(subContext, null, effFocus, null);
/*     */         }
/*     */ 
/*     */         
/*     */         public int getDefaultHeight() {
/* 475 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */ 
/*     */         
/*     */         public Rectangle getOnField(Context context) {
/* 480 */           Rectangle rect = context.getRect();
/* 481 */           return new Rectangle(rect.x + rect.width - rect.height, rect.y, rect.height, rect.height);
/*     */         }
/*     */ 
/*     */         
/*     */         public Rectangle getOffField(Context context) {
/* 486 */           Rectangle rect = context.getRect();
/* 487 */           return new Rectangle(rect.x + rect.width - 2 * rect.height, rect.y, rect.height, rect.height);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public IColorPickerRenderer getColorPickerRenderer() {
/* 494 */     return (IColorPickerRenderer)new StandardColorPicker()
/*     */       {
/*     */         public int getPadding() {
/* 497 */           return Theme.this.padding;
/*     */         }
/*     */ 
/*     */         
/*     */         public int getBaseHeight() {
/* 502 */           return Theme.this.getBaseHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBaseHeight() {
/* 509 */     return this.height + 2 * this.padding;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getMainColor(boolean focus, boolean active) {
/* 514 */     if (active) return this.enable; 
/* 515 */     return new Color(0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackgroundColor(boolean focus) {
/* 520 */     return this.background;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getFontColor(boolean focus) {
/* 525 */     return this.font;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\client\clickgui\Theme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */