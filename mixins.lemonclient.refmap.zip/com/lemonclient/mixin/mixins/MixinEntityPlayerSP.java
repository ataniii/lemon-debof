//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.mixin.mixins;
/*     */ 
/*     */ import com.lemonclient.api.event.events.EventPlayerIsHandActive;
/*     */ import com.lemonclient.api.event.events.MotionUpdateEvent;
/*     */ import com.lemonclient.api.event.events.OnUpdateWalkingPlayerEvent;
/*     */ import com.lemonclient.api.event.events.PlayerMoveEvent;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.manager.managers.PlayerPacketManager;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.dev.AntiPush;
/*     */ import com.lemonclient.client.module.modules.exploits.Portal;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({EntityPlayerSP.class})
/*     */ public abstract class MixinEntityPlayerSP
/*     */   extends AbstractClientPlayer
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   public NetHandlerPlayClient connection;
/*     */   @Shadow
/*     */   protected Minecraft mc;
/*     */   @Shadow
/*     */   private boolean prevOnGround;
/*     */   @Shadow
/*     */   private float lastReportedYaw;
/*     */   @Shadow
/*     */   private float lastReportedPitch;
/*     */   @Shadow
/*     */   private int positionUpdateTicks;
/*     */   
/*     */   public MixinEntityPlayerSP() {
/*  59 */     super((World)(Minecraft.getMinecraft()).world, (Minecraft.getMinecraft()).session.getProfile()); } @Shadow private double lastReportedPosX; @Shadow private double lastReportedPosY; @Shadow
/*     */   private double lastReportedPosZ; @Shadow
/*     */   private boolean autoJumpEnabled; @Shadow
/*     */   private boolean serverSprintState; @Shadow
/*     */   private boolean serverSneakState; @Shadow
/*     */   public MovementInput movementInput; @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("HEAD")}, cancellable = true)
/*  65 */   public void OnPreUpdateWalkingPlayer(CallbackInfo p_Info) { MotionUpdateEvent l_Event = new MotionUpdateEvent(0);
/*  66 */     LemonClient.EVENT_BUS.post(l_Event);
/*  67 */     if (l_Event.isCancelled())
/*  68 */       p_Info.cancel();  }
/*     */ 
/*     */   
/*     */   @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("RETURN")}, cancellable = true)
/*     */   public void OnPostUpdateWalkingPlayer(CallbackInfo p_Info) {
/*  73 */     MotionUpdateEvent l_Event = new MotionUpdateEvent(1);
/*  74 */     LemonClient.EVENT_BUS.post(l_Event);
/*  75 */     if (l_Event.isCancelled()) {
/*  76 */       p_Info.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Shadow
/*     */   protected abstract boolean isCurrentViewEntity();
/*     */   
/*     */   @Inject(method = {"pushOutOfBlocks"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void pushOutOfBlocks(double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
/*  85 */     if (ModuleManager.isModuleEnabled(AntiPush.class)) {
/*  86 */       cir.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(method = {"isHandActive"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void isHandActive(CallbackInfoReturnable<Boolean> info) {
/*  93 */     EventPlayerIsHandActive event = new EventPlayerIsHandActive();
/*  94 */     LemonClient.EVENT_BUS.post(event);
/*     */     
/*  96 */     if (event.isCancelled()) {
/*     */       
/*  98 */       info.cancel();
/*  99 */       info.setReturnValue(Boolean.valueOf(false));
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"Lnet/minecraft/client/entity/EntityPlayerSP;setServerBrand(Ljava/lang/String;)V"}, at = {@At("HEAD")})
/*     */   public void getBrand(String serverBrand, CallbackInfo callbackInfo) {
/* 105 */     if (LemonClient.serverUtil != null) {
/* 106 */       LemonClient.serverUtil.setServerBrand(serverBrand);
/*     */     }
/*     */   }
/*     */   
/*     */   @Redirect(method = {"move"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"))
/*     */   public void move(AbstractClientPlayer player, MoverType type, double x, double y, double z) {
/* 112 */     PlayerMoveEvent moveEvent = new PlayerMoveEvent(type, x, y, z);
/* 113 */     if (type != MoverType.PLAYER && type != MoverType.SELF && ModuleManager.isModuleEnabled(AntiPush.class)) {
/* 114 */       moveEvent.cancel();
/*     */     } else {
/* 116 */       LemonClient.EVENT_BUS.post(moveEvent);
/* 117 */       move(type, moveEvent.getX(), moveEvent.getY(), moveEvent.getZ());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(method = {"onUpdate"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;onUpdateWalkingPlayer()V", shift = At.Shift.AFTER)})
/*     */   private void onUpdateInvokeOnUpdateWalkingPlayer(CallbackInfo ci) {
/* 124 */     Vec3d serverSidePos = PlayerPacketManager.INSTANCE.getServerSidePosition();
/* 125 */     float serverSideRotationX = (PlayerPacketManager.INSTANCE.getServerSideRotation()).x;
/* 126 */     float serverSideRotationY = (PlayerPacketManager.INSTANCE.getServerSideRotation()).y;
/*     */     
/* 128 */     this.lastReportedPosX = serverSidePos.x;
/* 129 */     this.lastReportedPosY = serverSidePos.y;
/* 130 */     this.lastReportedPosZ = serverSidePos.z;
/*     */     
/* 132 */     this.lastReportedYaw = serverSideRotationX;
/* 133 */     this.lastReportedPitch = serverSideRotationY;
/*     */     
/* 135 */     this.rotationYawHead = serverSideRotationX;
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onUpdateWalkingPlayerPre(CallbackInfo callbackInfo) {
/* 141 */     Vec3d position = new Vec3d(this.posX, (getEntityBoundingBox()).minY, this.posZ);
/* 142 */     Vec2f rotation = new Vec2f(this.rotationYaw, this.rotationPitch);
/*     */     
/* 144 */     OnUpdateWalkingPlayerEvent event = new OnUpdateWalkingPlayerEvent(position, rotation);
/* 145 */     LemonClient.EVENT_BUS.post(event);
/*     */     
/* 147 */     event = event.nextPhase();
/* 148 */     LemonClient.EVENT_BUS.post(event);
/*     */     
/* 150 */     if (event.isCancelled()) {
/* 151 */       callbackInfo.cancel();
/*     */       
/* 153 */       boolean moving = (event.isMoving() || isMoving(position));
/* 154 */       boolean rotating = (event.isRotating() || isRotating(rotation));
/*     */ 
/*     */       
/* 157 */       position = event.getPosition();
/* 158 */       rotation = event.getRotation();
/*     */       
/* 160 */       this.positionUpdateTicks++;
/* 161 */       sendSprintPacket();
/* 162 */       sendSneakPacket();
/* 163 */       sendPlayerPacket(moving, rotating, position, rotation);
/*     */     } 
/*     */     
/* 166 */     event = event.nextPhase();
/* 167 */     LemonClient.EVENT_BUS.post(event);
/*     */   }
/*     */   
/*     */   private void sendSprintPacket() {
/* 171 */     boolean sprinting = isSprinting();
/*     */     
/* 173 */     if (sprinting != this.serverSprintState) {
/* 174 */       if (sprinting) {
/* 175 */         this.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SPRINTING));
/*     */       } else {
/* 177 */         this.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SPRINTING));
/*     */       } 
/* 179 */       this.serverSprintState = sprinting;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendSneakPacket() {
/* 184 */     boolean sneaking = isSneaking();
/*     */     
/* 186 */     if (sneaking != this.serverSneakState) {
/* 187 */       if (sneaking) {
/* 188 */         this.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.START_SNEAKING));
/*     */       } else {
/* 190 */         this.connection.sendPacket((Packet)new CPacketEntityAction((Entity)this, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */       } 
/* 192 */       this.serverSneakState = sneaking;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendPlayerPacket(boolean moving, boolean rotating, Vec3d position, Vec2f rotation) {
/* 197 */     if (!isCurrentViewEntity())
/*     */       return; 
/* 199 */     if (isRiding()) {
/* 200 */       this.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(this.motionX, -999.0D, this.motionZ, rotation.x, rotation.y, this.onGround));
/* 201 */       moving = false;
/* 202 */     } else if (moving && rotating) {
/* 203 */       this.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(position.x, position.y, position.z, rotation.x, rotation.y, this.onGround));
/* 204 */     } else if (moving) {
/* 205 */       this.connection.sendPacket((Packet)new CPacketPlayer.Position(position.x, position.y, position.z, this.onGround));
/* 206 */     } else if (rotating) {
/* 207 */       this.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotation.x, rotation.y, this.onGround));
/* 208 */     } else if (this.prevOnGround != this.onGround) {
/* 209 */       this.connection.sendPacket((Packet)new CPacketPlayer(this.onGround));
/*     */     } 
/*     */     
/* 212 */     if (moving) {
/* 213 */       this.lastReportedPosX = position.x;
/* 214 */       this.lastReportedPosY = position.y;
/* 215 */       this.lastReportedPosZ = position.z;
/* 216 */       this.positionUpdateTicks = 0;
/*     */     } 
/*     */     
/* 219 */     if (rotating) {
/* 220 */       this.lastReportedYaw = rotation.x;
/* 221 */       this.lastReportedPitch = rotation.y;
/*     */     } 
/*     */     
/* 224 */     this.prevOnGround = this.onGround;
/* 225 */     this.autoJumpEnabled = this.mc.gameSettings.autoJump;
/*     */   }
/*     */   
/*     */   private boolean isMoving(Vec3d position) {
/* 229 */     double xDiff = position.x - this.lastReportedPosX;
/* 230 */     double yDiff = position.y - this.lastReportedPosY;
/* 231 */     double zDiff = position.z - this.lastReportedPosZ;
/*     */     
/* 233 */     return (xDiff * xDiff + yDiff * yDiff + zDiff * zDiff > 9.0E-4D || this.positionUpdateTicks >= 20);
/*     */   }
/*     */   
/*     */   private boolean isRotating(Vec2f rotation) {
/* 237 */     double yawDiff = (rotation.x - this.lastReportedYaw);
/* 238 */     double pitchDiff = (rotation.y - this.lastReportedPitch);
/*     */     
/* 240 */     return (yawDiff != 0.0D || pitchDiff != 0.0D);
/*     */   }
/*     */   
/*     */   @Redirect(method = {"onLivingUpdate"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;closeScreen()V"))
/*     */   public void closeScreenHook(EntityPlayerSP entityPlayerSP) {
/* 245 */     Portal portal = (Portal)ModuleManager.getModule(Portal.class);
/* 246 */     if (!portal.isEnabled() || !((Boolean)portal.chat.getValue()).booleanValue())
/* 247 */       entityPlayerSP.closeScreen(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
