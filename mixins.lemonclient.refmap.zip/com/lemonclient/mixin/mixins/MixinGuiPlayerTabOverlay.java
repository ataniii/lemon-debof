//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.util.player.social.SocialManager;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import net.minecraft.client.gui.GuiPlayerTabOverlay;
/*    */ import net.minecraft.client.network.NetworkPlayerInfo;
/*    */ import net.minecraft.scoreboard.ScorePlayerTeam;
/*    */ import net.minecraft.scoreboard.Team;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({GuiPlayerTabOverlay.class})
/*    */ public class MixinGuiPlayerTabOverlay {
/*    */   @Inject(method = {"getPlayerName"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getPlayerNameHead(NetworkPlayerInfo networkPlayerInfoIn, CallbackInfoReturnable<String> callbackInfoReturnable) {
/* 19 */     callbackInfoReturnable.setReturnValue(getPlayerNameGS(networkPlayerInfoIn));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private String getPlayerNameGS(NetworkPlayerInfo networkPlayerInfoIn) {
/* 25 */     String displayName = (networkPlayerInfoIn.getDisplayName() != null) ? networkPlayerInfoIn.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName((Team)networkPlayerInfoIn.getPlayerTeam(), networkPlayerInfoIn.getGameProfile().getName());
/*    */     
/* 27 */     if (SocialManager.isFriend(displayName))
/* 28 */       return ((ColorMain)ModuleManager.getModule(ColorMain.class)).getFriendColor() + displayName; 
/* 29 */     if (SocialManager.isEnemy(displayName)) {
/* 30 */       return ((ColorMain)ModuleManager.getModule(ColorMain.class)).getEnemyColor() + displayName;
/*    */     }
/* 32 */     return displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinGuiPlayerTabOverlay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
