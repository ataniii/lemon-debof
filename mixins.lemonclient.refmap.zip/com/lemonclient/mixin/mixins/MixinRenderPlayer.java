//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.render.Nametags;
/*    */ import com.lemonclient.client.module.modules.render.NoRender;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderPlayer.class})
/*    */ public abstract class MixinRenderPlayer
/*    */ {
/*    */   @Inject(method = {"renderEntityName*"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void renderLivingLabel(AbstractClientPlayer entity, double x, double y, double z, String name, double distanceSq, CallbackInfo callbackInfo) {
/* 20 */     if (entity.getName().length() == 0) {
/* 21 */       callbackInfo.cancel();
/*    */     }
/* 23 */     if (ModuleManager.isModuleEnabled(Nametags.class)) {
/* 24 */       callbackInfo.cancel();
/*    */     }
/*    */     
/* 27 */     NoRender noRender = (NoRender)ModuleManager.getModule(NoRender.class);
/* 28 */     if (((Boolean)noRender.nameTag.getValue()).booleanValue())
/* 29 */       callbackInfo.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinRenderPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
