//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.movement.PlayerTweaks;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.util.MovementInput;
/*    */ import net.minecraft.util.MovementInputFromOptions;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ @Mixin(value = {MovementInputFromOptions.class}, priority = 10000)
/*    */ public abstract class MixinMovementInputFromOptions
/*    */   extends MovementInput
/*    */ {
/*    */   @Redirect(method = {"updatePlayerMoveState"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/settings/KeyBinding;isKeyDown()Z"))
/*    */   public boolean isKeyPressed(KeyBinding keyBinding) {
/* 20 */     int keyCode = keyBinding.getKeyCode();
/*    */     
/* 22 */     if (keyCode > 0 && keyCode < 256) {
/* 23 */       PlayerTweaks playerTweaks = (PlayerTweaks)ModuleManager.getModule(PlayerTweaks.class);
/*    */       
/* 25 */       if (playerTweaks.isEnabled() && ((Boolean)playerTweaks.guiMove.getValue()).booleanValue() && 
/* 26 */         (Minecraft.getMinecraft()).currentScreen != null && 
/* 27 */         !((Minecraft.getMinecraft()).currentScreen instanceof net.minecraft.client.gui.GuiChat)) {
/* 28 */         return Keyboard.isKeyDown(keyCode);
/*    */       }
/*    */     } 
/*    */     
/* 32 */     return keyBinding.isKeyDown();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinMovementInputFromOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
