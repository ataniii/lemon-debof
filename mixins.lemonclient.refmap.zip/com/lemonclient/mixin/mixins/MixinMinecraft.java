//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.mixin.mixins;
/*     */ 
/*     */ import club.minnced.discord.rpc.DiscordRPC;
/*     */ import com.lemonclient.api.config.SaveConfig;
/*     */ import com.lemonclient.api.util.player.Locks;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.misc.AntiSpam;
/*     */ import com.lemonclient.client.module.modules.misc.MultiTask;
/*     */ import com.lemonclient.mixin.mixins.accessor.AccessorEntityPlayerSP;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.util.EnumActionResult;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({Minecraft.class})
/*     */ public class MixinMinecraft {
/*     */   @Unique
/*  38 */   private final DiscordRPC lemonclient$discordRPC = DiscordRPC.INSTANCE;
/*     */   
/*     */   @Shadow
/*     */   public EntityPlayerSP player;
/*     */   
/*     */   @Shadow
/*     */   public PlayerControllerMP playerController;
/*     */   
/*     */   @Unique
/*     */   private boolean lemonclient$handActive = false;
/*     */   @Unique
/*     */   private boolean lemonclient$isHittingBlock = false;
/*     */   
/*     */   @Redirect(method = {"rightClickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;processRightClick(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;"))
/*     */   private EnumActionResult processRightClickHook(PlayerControllerMP pCMP, EntityPlayer player, World worldIn, EnumHand hand) {
/*     */     
/*  54 */     try { Locks.PLACE_SWITCH_LOCK.lock();
/*  55 */       return pCMP.processRightClick(player, worldIn, hand); }
/*  56 */     finally { Locks.PLACE_SWITCH_LOCK.unlock(); }
/*     */   
/*     */   }
/*     */   
/*     */   @Redirect(method = {"rightClickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;processRightClickBlock(Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;"))
/*     */   private EnumActionResult processRightClickBlockHook(PlayerControllerMP pCMP, EntityPlayerSP player, WorldClient worldIn, BlockPos pos, EnumFacing direction, Vec3d vec, EnumHand hand) {
/*     */     try {
/*  63 */       Locks.PLACE_SWITCH_LOCK.lock();
/*  64 */       return pCMP.processRightClickBlock(player, worldIn, pos, direction, vec, hand);
/*     */     } finally {
/*     */       
/*  67 */       Locks.PLACE_SWITCH_LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Redirect(method = {"rightClickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;interactWithEntity(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;"))
/*     */   private EnumActionResult interactWithEntityHook(PlayerControllerMP pCMP, EntityPlayer player, Entity target, EnumHand hand) {
/*     */     try {
/*  74 */       Locks.PLACE_SWITCH_LOCK.lock();
/*  75 */       return pCMP.interactWithEntity(player, target, hand);
/*     */     } finally {
/*  77 */       Locks.PLACE_SWITCH_LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Redirect(method = {"rightClickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;interactWithEntity(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/RayTraceResult;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;"))
/*     */   private EnumActionResult interactWithEntity2Hook(PlayerControllerMP pCMP, EntityPlayer player, Entity target, RayTraceResult ray, EnumHand hand) {
/*     */     try {
/*  84 */       Locks.PLACE_SWITCH_LOCK.lock();
/*  85 */       return pCMP.interactWithEntity(player, target, ray, hand);
/*     */     } finally {
/*  87 */       Locks.PLACE_SWITCH_LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   @Redirect(method = {"clickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;attackEntity(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;)V"))
/*     */   public void attackEntityHook(PlayerControllerMP playerControllerMP, EntityPlayer playerIn, Entity targetEntity) {
/*  92 */     Locks.acquire(Locks.PLACE_SWITCH_LOCK, () -> playerControllerMP.attackEntity(playerIn, targetEntity));
/*     */   }
/*     */   
/*     */   @Redirect(method = {"runTickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/InventoryPlayer;changeCurrentItem(I)V"))
/*     */   public void changeCurrentItemHook(InventoryPlayer inventoryPlayer, int direction) {
/*  97 */     Locks.acquire(Locks.PLACE_SWITCH_LOCK, () -> inventoryPlayer.changeCurrentItem(direction));
/*     */   }
/*     */   
/*     */   @Redirect(method = {"sendClickBlockToController"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;onPlayerDamageBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z"))
/*     */   public boolean onPlayerDamageBlockHook(PlayerControllerMP pCMP, BlockPos posBlock, EnumFacing directionFacing) {
/*     */     try {
/* 103 */       Locks.PLACE_SWITCH_LOCK.lock();
/* 104 */       return pCMP.onPlayerDamageBlock(posBlock, directionFacing);
/*     */     } finally {
/* 106 */       Locks.PLACE_SWITCH_LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"rightClickMouse"}, at = {@At("HEAD")})
/*     */   public void rightClickMousePre(CallbackInfo ci) {
/* 112 */     if (ModuleManager.isModuleEnabled(MultiTask.class)) {
/* 113 */       this.lemonclient$isHittingBlock = this.playerController.getIsHittingBlock();
/* 114 */       this.playerController.isHittingBlock = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"rightClickMouse"}, at = {@At("RETURN")})
/*     */   public void rightClickMousePost(CallbackInfo ci) {
/* 120 */     if (ModuleManager.isModuleEnabled(MultiTask.class) && !this.playerController.getIsHittingBlock()) {
/* 121 */       this.playerController.isHittingBlock = this.lemonclient$isHittingBlock;
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"sendClickBlockToController"}, at = {@At("HEAD")})
/*     */   public void sendClickBlockToControllerPre(boolean leftClick, CallbackInfo ci) {
/* 127 */     if (ModuleManager.isModuleEnabled(MultiTask.class)) {
/* 128 */       this.lemonclient$handActive = this.player.isHandActive();
/* 129 */       ((AccessorEntityPlayerSP)this.player).gsSetHandActive(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"sendClickBlockToController"}, at = {@At("RETURN")})
/*     */   public void sendClickBlockToControllerPost(boolean leftClick, CallbackInfo ci) {
/* 135 */     if (ModuleManager.isModuleEnabled(MultiTask.class) && !this.player.isHandActive()) {
/* 136 */       ((AccessorEntityPlayerSP)this.player).gsSetHandActive(this.lemonclient$handActive);
/*     */     }
/*     */   }
/*     */   
/*     */   @Redirect(method = {"run"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
/*     */   public void displayCrashReportHook(Minecraft minecraft, CrashReport crashReport) {
/* 142 */     lemonclient$removeIgnore();
/* 143 */     SaveConfig.init();
/* 144 */     this.lemonclient$discordRPC.Discord_Shutdown();
/* 145 */     this.lemonclient$discordRPC.Discord_ClearPresence();
/* 146 */     LemonClient.shutdown();
/*     */   }
/*     */   
/*     */   @Inject(method = {"shutdownMinecraftApplet"}, at = {@At("HEAD")})
/*     */   private void stopClient(CallbackInfo callbackInfo) {
/* 151 */     lemonclient$removeIgnore();
/* 152 */     SaveConfig.init();
/* 153 */     this.lemonclient$discordRPC.Discord_Shutdown();
/* 154 */     this.lemonclient$discordRPC.Discord_ClearPresence();
/* 155 */     LemonClient.shutdown();
/*     */   }
/*     */   
/*     */   @Inject(method = {"crashed"}, at = {@At("HEAD")})
/*     */   public void crashed(CrashReport crash, CallbackInfo callbackInfo) {
/* 160 */     lemonclient$removeIgnore();
/* 161 */     SaveConfig.init();
/* 162 */     this.lemonclient$discordRPC.Discord_Shutdown();
/* 163 */     this.lemonclient$discordRPC.Discord_ClearPresence();
/* 164 */     LemonClient.shutdown();
/*     */   }
/*     */   
/*     */   @Inject(method = {"shutdown"}, at = {@At("HEAD")})
/*     */   public void shutdown(CallbackInfo callbackInfo) {
/* 169 */     lemonclient$removeIgnore();
/* 170 */     SaveConfig.init();
/* 171 */     this.lemonclient$discordRPC.Discord_Shutdown();
/* 172 */     this.lemonclient$discordRPC.Discord_ClearPresence();
/* 173 */     LemonClient.shutdown();
/*     */   }
/*     */   
/*     */   @Unique
/*     */   public void lemonclient$removeIgnore() {
/* 178 */     AntiSpam antiSpam = (AntiSpam)ModuleManager.getModule(AntiSpam.class);
/* 179 */     for (String name : antiSpam.ignoredList)
/* 180 */       SocialManager.delIgnore(name); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinMinecraft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
