//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import net.minecraft.network.EnumConnectionState;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.network.handshake.client.C00Handshake;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({C00Handshake.class})
/*    */ public class MixinC00Handshake
/*    */ {
/*    */   @Shadow
/*    */   private int protocolVersion;
/*    */   @Shadow
/*    */   private String ip;
/*    */   @Shadow
/*    */   private int port;
/*    */   @Shadow
/*    */   private EnumConnectionState requestedState;
/*    */   
/*    */   @Inject(method = {"writePacketData"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void writePacketData(PacketBuffer buf, CallbackInfo info) {
/* 26 */     info.cancel();
/* 27 */     buf.writeVarInt(this.protocolVersion);
/* 28 */     buf.writeString(this.ip);
/* 29 */     buf.writeShort(this.port);
/* 30 */     buf.writeVarInt(this.requestedState.getId());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinC00Handshake.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
