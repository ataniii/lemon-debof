//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.BlockResetEvent;
/*    */ import com.lemonclient.api.event.events.DamageBlockEvent;
/*    */ import com.lemonclient.api.event.events.DestroyBlockEvent;
/*    */ import com.lemonclient.api.event.events.EventPlayerOnStoppedUsingItem;
/*    */ import com.lemonclient.api.event.events.ReachDistanceEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.exploits.PacketUtils;
/*    */ import com.lemonclient.client.module.modules.misc.noGlitchBlock;
/*    */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({PlayerControllerMP.class})
/*    */ public abstract class MixinPlayerControllerMP {
/*    */   @Shadow
/*    */   protected abstract void syncCurrentPlayItem();
/*    */   
/*    */   @Inject(method = {"resetBlockRemoving"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void resetBlockWrapper(CallbackInfo callbackInfo) {
/* 30 */     BlockResetEvent uwu = new BlockResetEvent();
/* 31 */     LemonClient.EVENT_BUS.post(uwu);
/* 32 */     if (uwu.isCancelled()) {
/* 33 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"onStoppedUsingItem"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onPlayerDestroyBlock(EntityPlayer playerIn, CallbackInfo info) {
/* 40 */     EventPlayerOnStoppedUsingItem event = new EventPlayerOnStoppedUsingItem();
/* 41 */     LemonClient.EVENT_BUS.post(event);
/* 42 */     if (event.isCancelled()) {
/* 43 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"onPlayerDamageBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
/* 49 */     DamageBlockEvent event = new DamageBlockEvent(posBlock, directionFacing);
/* 50 */     LemonClient.EVENT_BUS.post(event);
/* 51 */     if (event.isCancelled()) {
/* 52 */       callbackInfoReturnable.setReturnValue(Boolean.valueOf(false));
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"clickBlock"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void clickBlockHook(BlockPos pos, EnumFacing face, CallbackInfoReturnable<Boolean> info) {
/* 58 */     DamageBlockEvent event = new DamageBlockEvent(pos, face);
/* 59 */     LemonClient.EVENT_BUS.post(event);
/*    */   }
/*    */   
/*    */   @Inject(method = {"onPlayerDamageBlock"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onPlayerDamageBlockHook(BlockPos pos, EnumFacing face, CallbackInfoReturnable<Boolean> info) {
/* 64 */     DamageBlockEvent event = new DamageBlockEvent(pos, face);
/* 65 */     LemonClient.EVENT_BUS.post(event);
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"onPlayerDestroyBlock"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/world/World;playEvent(ILnet/minecraft/util/math/BlockPos;I)V")}, cancellable = true)
/*    */   private void onPlayerDestroyBlock(BlockPos pos, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
/* 71 */     noGlitchBlock noGlitchBlock = (noGlitchBlock)ModuleManager.getModule(noGlitchBlock.class);
/* 72 */     if (noGlitchBlock.isEnabled() && ((Boolean)noGlitchBlock.breakBlock.getValue()).booleanValue()) {
/* 73 */       callbackInfoReturnable.cancel();
/* 74 */       callbackInfoReturnable.setReturnValue(Boolean.valueOf(false));
/*    */     } 
/* 76 */     LemonClient.EVENT_BUS.post(new DestroyBlockEvent(pos));
/*    */   }
/*    */   
/*    */   @Inject(method = {"getBlockReachDistance"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private void getReachDistanceHook(CallbackInfoReturnable<Float> distance) {
/* 81 */     ReachDistanceEvent reachDistanceEvent = new ReachDistanceEvent(((Float)distance.getReturnValue()).floatValue());
/* 82 */     LemonClient.EVENT_BUS.post(reachDistanceEvent);
/*    */     
/* 84 */     distance.setReturnValue(Float.valueOf(reachDistanceEvent.getDistance()));
/*    */   }
/*    */   
/*    */   @Inject(method = {"onStoppedUsingItem"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onStoppedUsingItem(EntityPlayer playerIn, CallbackInfo ci) {
/* 89 */     PacketUtils packetUtils = (PacketUtils)ModuleManager.getModule(PacketUtils.class);
/*    */     
/* 91 */     if (packetUtils.isEnabled() && ((Boolean)packetUtils.packetUse.getValue()).booleanValue() && (((
/* 92 */       (Boolean)packetUtils.food.getValue()).booleanValue() && playerIn.getHeldItem(playerIn.getActiveHand()).getItem() instanceof net.minecraft.item.ItemFood) || (((Boolean)packetUtils.potion
/* 93 */       .getValue()).booleanValue() && playerIn.getHeldItem(playerIn.getActiveHand()).getItem() instanceof net.minecraft.item.ItemPotion) || ((Boolean)packetUtils.all
/* 94 */       .getValue()).booleanValue())) {
/* 95 */       syncCurrentPlayItem();
/* 96 */       if (((Boolean)packetUtils.cancel.getValue()).booleanValue()) playerIn.stopActiveHand(); 
/* 97 */       ci.cancel();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinPlayerControllerMP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
