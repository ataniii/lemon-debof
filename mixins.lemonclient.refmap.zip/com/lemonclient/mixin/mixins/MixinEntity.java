//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.mixin.mixins;
/*     */ 
/*     */ import com.lemonclient.api.event.events.EntityCollisionEvent;
/*     */ import com.lemonclient.api.event.events.StepEvent;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.World;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({Entity.class})
/*     */ public abstract class MixinEntity {
/*     */   @Shadow
/*     */   public double posX;
/*     */   @Shadow
/*     */   public double posY;
/*     */   @Shadow
/*     */   public double posZ;
/*     */   @Shadow
/*     */   public double motionX;
/*     */   @Shadow
/*     */   public double motionY;
/*     */   @Shadow
/*     */   public double motionZ;
/*     */   @Shadow
/*     */   public float rotationYaw;
/*     */   @Shadow
/*     */   public float rotationPitch;
/*     */   @Shadow
/*     */   public boolean onGround;
/*     */   @Shadow
/*     */   public World world;
/*     */   @Shadow
/*     */   public float stepHeight;
/*     */   @Shadow
/*     */   public boolean isDead;
/*     */   @Shadow
/*     */   public float width;
/*     */   @Shadow
/*     */   public float height;
/*     */   private Float prevHeight;
/*     */   
/*     */   @Shadow
/*     */   public abstract AxisAlignedBB getEntityBoundingBox();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean isSneaking();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */   @Inject(method = {"applyEntityCollision"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void velocity(Entity entityIn, CallbackInfo ci) {
/*  62 */     EntityCollisionEvent event = new EntityCollisionEvent();
/*  63 */     LemonClient.EVENT_BUS.post(event);
/*     */     
/*  65 */     if (event.isCancelled()) {
/*  66 */       ci.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(method = {"move"}, at = {@At(value = "INVOKE", target = "net/minecraft/entity/Entity.resetPositionToBB()V", ordinal = 1)})
/*     */   private void resetPositionToBBHook(MoverType type, double x, double y, double z, CallbackInfo info) {
/*  73 */     if (EntityPlayerSP.class.isInstance(this) && this.prevHeight != null) {
/*  74 */       this.stepHeight = this.prevHeight.floatValue();
/*  75 */       this.prevHeight = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"move"}, at = {@At("HEAD")})
/*     */   public void move(MoverType type, double tx, double ty, double tz, CallbackInfo ci) {
/*  84 */     Minecraft mc = Minecraft.getMinecraft();
/*     */     
/*  86 */     if (mc.getCurrentServerData() == null) {
/*     */       return;
/*     */     }
/*  89 */     double x = tx;
/*  90 */     double y = ty;
/*  91 */     double z = tz;
/*     */     
/*  93 */     if (ci.isCancelled()) {
/*     */       return;
/*     */     }
/*  96 */     AxisAlignedBB bb = mc.player.getEntityBoundingBox();
/*     */     
/*  98 */     if (!mc.player.noClip) {
/*  99 */       if (type.equals(MoverType.PISTON)) {
/*     */         return;
/*     */       }
/* 102 */       mc.world.profiler.startSection("move");
/*     */       
/* 104 */       if (mc.player.isInWeb) {
/*     */         return;
/*     */       }
/*     */       
/* 108 */       double d2 = x;
/* 109 */       double d3 = y;
/* 110 */       double d4 = z;
/*     */       
/* 112 */       if ((type == MoverType.SELF || type == MoverType.PLAYER) && mc.player.onGround && mc.player.isSneaking()) {
/* 113 */         for (double d5 = 0.05D; x != 0.0D && mc.world.getCollisionBoxes((Entity)mc.player, bb.offset(x, -mc.player.stepHeight, 0.0D)).isEmpty(); d2 = x) {
/* 114 */           if (x < 0.05D && x >= -0.05D) {
/* 115 */             x = 0.0D;
/* 116 */           } else if (x > 0.0D) {
/* 117 */             x -= 0.05D;
/*     */           } else {
/* 119 */             x += 0.05D;
/*     */           } 
/*     */         } 
/*     */         
/* 123 */         for (; z != 0.0D && mc.world.getCollisionBoxes((Entity)mc.player, bb.offset(0.0D, -mc.player.stepHeight, z)).isEmpty(); d4 = z) {
/* 124 */           if (z < 0.05D && z >= -0.05D) {
/* 125 */             z = 0.0D;
/* 126 */           } else if (z > 0.0D) {
/* 127 */             z -= 0.05D;
/*     */           } else {
/* 129 */             z += 0.05D;
/*     */           } 
/*     */         } 
/*     */         
/* 133 */         for (; x != 0.0D && z != 0.0D && mc.world.getCollisionBoxes((Entity)mc.player, bb.offset(x, -mc.player.stepHeight, z)).isEmpty(); d4 = z) {
/* 134 */           if (x < 0.05D && x >= -0.05D) {
/* 135 */             x = 0.0D;
/* 136 */           } else if (x > 0.0D) {
/* 137 */             x -= 0.05D;
/*     */           } else {
/* 139 */             x += 0.05D;
/*     */           } 
/*     */           
/* 142 */           d2 = x;
/*     */           
/* 144 */           if (z < 0.05D && z >= -0.05D) {
/* 145 */             z = 0.0D;
/* 146 */           } else if (z > 0.0D) {
/* 147 */             z -= 0.05D;
/*     */           } else {
/* 149 */             z += 0.05D;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 154 */       List<AxisAlignedBB> list1 = mc.world.getCollisionBoxes((Entity)mc.player, bb.expand(x, y, z));
/*     */       
/* 156 */       if (y != 0.0D) {
/* 157 */         int k = 0;
/*     */         
/* 159 */         for (int l = list1.size(); k < l; k++) {
/* 160 */           y = ((AxisAlignedBB)list1.get(k)).calculateYOffset(bb, y);
/*     */         }
/*     */         
/* 163 */         bb = bb.offset(0.0D, y, 0.0D);
/*     */       } 
/*     */       
/* 166 */       if (x != 0.0D) {
/* 167 */         int j5 = 0;
/*     */         
/* 169 */         for (int l5 = list1.size(); j5 < l5; j5++) {
/* 170 */           x = ((AxisAlignedBB)list1.get(j5)).calculateXOffset(bb, x);
/*     */         }
/*     */         
/* 173 */         if (x != 0.0D) {
/* 174 */           bb = bb.offset(x, 0.0D, 0.0D);
/*     */         }
/*     */       } 
/*     */       
/* 178 */       if (z != 0.0D) {
/* 179 */         int k5 = 0;
/*     */         
/* 181 */         for (int i6 = list1.size(); k5 < i6; k5++) {
/* 182 */           z = ((AxisAlignedBB)list1.get(k5)).calculateZOffset(bb, z);
/*     */         }
/*     */         
/* 185 */         if (z != 0.0D) {
/* 186 */           bb = bb.offset(0.0D, 0.0D, z);
/*     */         }
/*     */       } 
/*     */       
/* 190 */       boolean flag = (mc.player.onGround || (d3 != y && d3 < 0.0D));
/*     */       
/* 192 */       if (mc.player.stepHeight > 0.0F && flag && (d2 != x || d4 != z)) {
/* 193 */         double d14 = x;
/* 194 */         double d6 = y;
/* 195 */         double d7 = z;
/* 196 */         y = mc.player.stepHeight;
/* 197 */         List<AxisAlignedBB> list = mc.world.getCollisionBoxes((Entity)mc.player, bb.expand(d2, y, d4));
/* 198 */         AxisAlignedBB axisalignedbb2 = bb;
/* 199 */         AxisAlignedBB axisalignedbb3 = axisalignedbb2.expand(d2, 0.0D, d4);
/* 200 */         double d8 = y;
/* 201 */         int j1 = 0;
/*     */         
/* 203 */         for (int k1 = list.size(); j1 < k1; j1++) {
/* 204 */           d8 = ((AxisAlignedBB)list.get(j1)).calculateYOffset(axisalignedbb3, d8);
/*     */         }
/*     */         
/* 207 */         axisalignedbb2 = axisalignedbb2.offset(0.0D, d8, 0.0D);
/* 208 */         double d18 = d2;
/* 209 */         int l1 = 0;
/*     */         
/* 211 */         for (int i2 = list.size(); l1 < i2; l1++) {
/* 212 */           d18 = ((AxisAlignedBB)list.get(l1)).calculateXOffset(axisalignedbb2, d18);
/*     */         }
/*     */         
/* 215 */         axisalignedbb2 = axisalignedbb2.offset(d18, 0.0D, 0.0D);
/* 216 */         double d19 = d4;
/* 217 */         int j2 = 0;
/*     */         
/* 219 */         for (int k2 = list.size(); j2 < k2; j2++) {
/* 220 */           d19 = ((AxisAlignedBB)list.get(j2)).calculateZOffset(axisalignedbb2, d19);
/*     */         }
/*     */         
/* 223 */         axisalignedbb2 = axisalignedbb2.offset(0.0D, 0.0D, d19);
/* 224 */         AxisAlignedBB axisalignedbb4 = bb;
/* 225 */         double d20 = y;
/* 226 */         int l2 = 0;
/*     */         
/* 228 */         for (int i3 = list.size(); l2 < i3; l2++) {
/* 229 */           d20 = ((AxisAlignedBB)list.get(l2)).calculateYOffset(axisalignedbb4, d20);
/*     */         }
/*     */         
/* 232 */         axisalignedbb4 = axisalignedbb4.offset(0.0D, d20, 0.0D);
/* 233 */         double d21 = d2;
/* 234 */         int j3 = 0;
/*     */         
/* 236 */         for (int k3 = list.size(); j3 < k3; j3++) {
/* 237 */           d21 = ((AxisAlignedBB)list.get(j3)).calculateXOffset(axisalignedbb4, d21);
/*     */         }
/*     */         
/* 240 */         axisalignedbb4 = axisalignedbb4.offset(d21, 0.0D, 0.0D);
/* 241 */         double d22 = d4;
/* 242 */         int l3 = 0;
/*     */         
/* 244 */         for (int i4 = list.size(); l3 < i4; l3++) {
/* 245 */           d22 = ((AxisAlignedBB)list.get(l3)).calculateZOffset(axisalignedbb4, d22);
/*     */         }
/*     */         
/* 248 */         axisalignedbb4 = axisalignedbb4.offset(0.0D, 0.0D, d22);
/* 249 */         double d23 = d18 * d18 + d19 * d19;
/* 250 */         double d9 = d21 * d21 + d22 * d22;
/*     */         
/* 252 */         if (d23 > d9) {
/* 253 */           x = d18;
/* 254 */           z = d19;
/* 255 */           y = -d8;
/* 256 */           bb = axisalignedbb2;
/*     */         } else {
/* 258 */           x = d21;
/* 259 */           z = d22;
/* 260 */           y = -d20;
/* 261 */           bb = axisalignedbb4;
/*     */         } 
/*     */         
/* 264 */         int j4 = 0;
/*     */         
/* 266 */         for (int k4 = list.size(); j4 < k4; j4++) {
/* 267 */           y = ((AxisAlignedBB)list.get(j4)).calculateYOffset(bb, y);
/*     */         }
/*     */         
/* 270 */         bb = bb.offset(0.0D, y, 0.0D);
/*     */         
/* 272 */         if (d14 * d14 + d7 * d7 < x * x + z * z) {
/*     */           
/* 274 */           StepEvent event = new StepEvent(bb);
/* 275 */           LemonClient.EVENT_BUS.post(event);
/*     */           
/* 277 */           if (event.isCancelled())
/* 278 */             mc.player.stepHeight = 0.5F; 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
