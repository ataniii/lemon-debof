/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.RenderEntityEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.render.NoFallingBlocks;
/*    */ import net.minecraft.client.renderer.culling.ICamera;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderManager.class})
/*    */ public class MixinRenderManager
/*    */ {
/*    */   @Inject(method = {"renderEntity"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderEntityHead(Entity entityIn, double x, double y, double z, float yaw, float partialTicks, boolean p_188391_10_, CallbackInfo callbackInfo) {
/* 27 */     RenderEntityEvent.Head renderEntityHeadEvent = new RenderEntityEvent.Head(entityIn, RenderEntityEvent.Type.TEXTURE);
/*    */     
/* 29 */     LemonClient.EVENT_BUS.post(renderEntityHeadEvent);
/*    */     
/* 31 */     if (entityIn instanceof net.minecraft.entity.item.EntityEnderPearl || entityIn instanceof net.minecraft.entity.item.EntityXPOrb || entityIn instanceof net.minecraft.entity.item.EntityExpBottle || entityIn instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/* 32 */       RenderEntityEvent.Head renderEntityEvent = new RenderEntityEvent.Head(entityIn, RenderEntityEvent.Type.COLOR);
/*    */       
/* 34 */       LemonClient.EVENT_BUS.post(renderEntityEvent);
/*    */       
/* 36 */       if (renderEntityEvent.isCancelled()) {
/* 37 */         callbackInfo.cancel();
/*    */       }
/*    */     } 
/*    */     
/* 41 */     if (renderEntityHeadEvent.isCancelled()) {
/* 42 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"shouldRender"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onShouldRender(Entity entity, ICamera camera, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
/* 49 */     if (ModuleManager.isModuleEnabled(NoFallingBlocks.class) && 
/* 50 */       entity instanceof net.minecraft.entity.item.EntityFallingBlock)
/* 51 */       cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderEntity"}, at = {@At("RETURN")}, cancellable = true)
/*    */   public void renderEntityReturn(Entity entityIn, double x, double y, double z, float yaw, float partialTicks, boolean p_188391_10_, CallbackInfo callbackInfo) {
/* 56 */     RenderEntityEvent.Return renderEntityReturnEvent = new RenderEntityEvent.Return(entityIn, RenderEntityEvent.Type.TEXTURE);
/*    */     
/* 58 */     LemonClient.EVENT_BUS.post(renderEntityReturnEvent);
/*    */     
/* 60 */     if (entityIn instanceof net.minecraft.entity.item.EntityEnderPearl || entityIn instanceof net.minecraft.entity.item.EntityXPOrb || entityIn instanceof net.minecraft.entity.item.EntityExpBottle || entityIn instanceof net.minecraft.entity.item.EntityEnderCrystal) {
/* 61 */       RenderEntityEvent.Return renderEntityEvent = new RenderEntityEvent.Return(entityIn, RenderEntityEvent.Type.COLOR);
/*    */       
/* 63 */       LemonClient.EVENT_BUS.post(renderEntityEvent);
/*    */       
/* 65 */       if (renderEntityEvent.isCancelled()) {
/* 66 */         callbackInfo.cancel();
/*    */       }
/*    */     } 
/*    */     
/* 70 */     if (renderEntityReturnEvent.isCancelled())
/* 71 */       callbackInfo.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinRenderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */