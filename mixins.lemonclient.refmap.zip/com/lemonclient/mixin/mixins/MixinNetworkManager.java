/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.misc.NoKick;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({NetworkManager.class})
/*    */ public class MixinNetworkManager
/*    */ {
/*    */   @Inject(method = {"sendPacket(Lnet/minecraft/network/Packet;)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void preSendPacket(Packet<?> packet, CallbackInfo callbackInfo) {
/* 22 */     PacketEvent.Send event = new PacketEvent.Send(packet);
/* 23 */     LemonClient.EVENT_BUS.post(event);
/*    */     
/* 25 */     if (event.isCancelled()) {
/* 26 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"channelRead0"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void preChannelRead(ChannelHandlerContext context, Packet<?> packet, CallbackInfo callbackInfo) {
/* 32 */     PacketEvent.Receive event = new PacketEvent.Receive(packet);
/* 33 */     LemonClient.EVENT_BUS.post(event);
/*    */     
/* 35 */     if (event.isCancelled()) {
/* 36 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"sendPacket(Lnet/minecraft/network/Packet;)V"}, at = {@At("TAIL")}, cancellable = true)
/*    */   private void postSendPacket(Packet<?> packet, CallbackInfo callbackInfo) {
/* 42 */     PacketEvent.PostSend event = new PacketEvent.PostSend(packet);
/* 43 */     LemonClient.EVENT_BUS.post(event);
/*    */     
/* 45 */     if (event.isCancelled()) {
/* 46 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"channelRead0"}, at = {@At("TAIL")}, cancellable = true)
/*    */   private void postChannelRead(ChannelHandlerContext context, Packet<?> packet, CallbackInfo callbackInfo) {
/* 52 */     PacketEvent.PostReceive event = new PacketEvent.PostReceive(packet);
/* 53 */     LemonClient.EVENT_BUS.post(event);
/*    */     
/* 55 */     if (event.isCancelled()) {
/* 56 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"exceptionCaught"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void exceptionCaught(ChannelHandlerContext p_exceptionCaught_1_, Throwable p_exceptionCaught_2_, CallbackInfo callbackInfo) {
/* 62 */     NoKick noKick = (NoKick)ModuleManager.getModule(NoKick.class);
/*    */     
/* 64 */     if (p_exceptionCaught_2_ instanceof java.io.IOException && noKick.isEnabled() && ((Boolean)noKick.noPacketKick.getValue()).booleanValue())
/* 65 */       callbackInfo.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */