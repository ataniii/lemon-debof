//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.MapPeek;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({GuiContainer.class})
/*    */ public class MixinContainerGui
/*    */   extends GuiScreen {
/* 14 */   MapPeek peek = new MapPeek();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"drawScreen(IIF)V"}, at = {@At("RETURN")})
/*    */   public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo info) {
/*    */     try {
/* 24 */       this.peek.draw(mouseX, mouseY, (GuiContainer)this.mc.currentScreen);
/* 25 */     } catch (Exception e) {
/*    */       
/* 27 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinContainerGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
