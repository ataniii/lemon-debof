package com.lemonclient.mixin.mixins.accessor;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Minecraft.class})
public interface AccessorMinecraft {
  @Accessor("timer")
  Timer getTimer();
  
  @Accessor("rightClickDelayTimer")
  int getRightClickDelayTimer();
  
  @Accessor("rightClickDelayTimer")
  void setRightClickDelayTimer(int paramInt);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\accessor\AccessorMinecraft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */