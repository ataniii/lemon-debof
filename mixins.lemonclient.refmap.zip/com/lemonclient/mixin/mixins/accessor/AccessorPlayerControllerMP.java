package com.lemonclient.mixin.mixins.accessor;

import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({PlayerControllerMP.class})
public interface AccessorPlayerControllerMP {
  @Accessor("blockHitDelay")
  int getBlockHitDelay();
  
  @Accessor("blockHitDelay")
  void setBlockHitDelay(int paramInt);
  
  @Accessor("isHittingBlock")
  void setIsHittingBlock(boolean paramBoolean);
  
  @Accessor("currentPlayerItem")
  int getCurrentPlayerItem();
  
  @Invoker("syncCurrentPlayItem")
  void invokeSyncCurrentPlayItem();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\accessor\AccessorPlayerControllerMP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */