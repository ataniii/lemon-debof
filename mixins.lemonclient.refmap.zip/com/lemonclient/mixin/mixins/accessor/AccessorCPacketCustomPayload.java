package com.lemonclient.mixin.mixins.accessor;

import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({CPacketCustomPayload.class})
public interface AccessorCPacketCustomPayload {
  @Accessor("data")
  void setData(PacketBuffer paramPacketBuffer);
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\accessor\AccessorCPacketCustomPayload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */