/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.DrawBlockDamageEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.render.BlockHighlight;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.RenderGlobal;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({RenderGlobal.class})
/*    */ public class MixinRenderGlobal
/*    */ {
/*    */   @Inject(method = {"drawSelectionBox"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void drawSelectionBox(EntityPlayer player, RayTraceResult movingObjectPositionIn, int execute, float partialTicks, CallbackInfo callbackInfo) {
/* 23 */     if (ModuleManager.isModuleEnabled(BlockHighlight.class)) {
/* 24 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"drawBlockDamageTexture"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void drawBlockDamageTexture(Tessellator tessellatorIn, BufferBuilder bufferBuilderIn, Entity entityIn, float partialTicks, CallbackInfo callbackInfo) {
/* 30 */     DrawBlockDamageEvent drawBlockDamageEvent = new DrawBlockDamageEvent();
/*    */     
/* 32 */     LemonClient.EVENT_BUS.post(drawBlockDamageEvent);
/*    */     
/* 34 */     if (drawBlockDamageEvent.isCancelled())
/* 35 */       callbackInfo.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinRenderGlobal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */