//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.misc.ChatModifier;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.gui.GuiNewChat;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ @Mixin({GuiNewChat.class})
/*    */ public abstract class MixinGuiNewChat
/*    */ {
/*    */   @Redirect(method = {"drawChat"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"))
/*    */   private void drawRectBackgroundClean(int left, int top, int right, int bottom, int color) {
/* 16 */     ChatModifier chatModifier = (ChatModifier)ModuleManager.getModule(ChatModifier.class);
/*    */     
/* 18 */     if (!chatModifier.isEnabled() || !((Boolean)chatModifier.clearBkg.getValue()).booleanValue())
/* 19 */       Gui.drawRect(left, top, right, bottom, color); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinGuiNewChat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
