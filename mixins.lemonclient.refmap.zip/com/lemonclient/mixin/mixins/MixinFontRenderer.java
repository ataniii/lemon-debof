//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.util.font.FontUtil;
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*    */ import com.lemonclient.client.module.modules.misc.NameProtect;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ @Mixin({FontRenderer.class})
/*    */ public class MixinFontRenderer {
/*    */   @Redirect(method = {"drawStringWithShadow"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;drawString(Ljava/lang/String;FFIZ)I"))
/*    */   public int drawCustomFontStringWithShadow(FontRenderer fontRenderer, String text, float x, float y, int color, boolean dropShadow) {
/* 17 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/* 18 */     if (((Boolean)colorMain.highlightSelf.getValue()).booleanValue()) text = colorMain.highlight(text); 
/* 19 */     if (NameProtect.INSTANCE.isEnabled()) text = NameProtect.INSTANCE.replaceName(text); 
/* 20 */     return ((Boolean)colorMain.textFont.getValue()).booleanValue() ? (int)FontUtil.drawStringWithShadow(true, text, (int)x, (int)y, new GSColor(color)) : fontRenderer.drawString(text, x, y, color, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinFontRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
