//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.PlayerJumpEvent;
/*    */ import com.lemonclient.api.event.events.WaterPushEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.exploits.Portal;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Constant;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyConstant;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({EntityPlayer.class})
/*    */ public abstract class MixinEntityPlayer
/*    */ {
/*    */   @ModifyConstant(method = {"getPortalCooldown"}, constant = {@Constant(intValue = 10)})
/*    */   private int getPortalCooldownHook(int n) {
/* 24 */     int intValue = n;
/* 25 */     Portal portal = (Portal)ModuleManager.getModule(Portal.class);
/* 26 */     if (portal.isEnabled() && ((Boolean)portal.fastPortal.getValue()).booleanValue()) {
/* 27 */       intValue = ((Integer)portal.cooldown.getValue()).intValue();
/*    */     }
/* 29 */     return intValue;
/*    */   } @Shadow
/*    */   public abstract String getName();
/*    */   @Inject(method = {"jump"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onJump(CallbackInfo callbackInfo) {
/* 34 */     if ((Minecraft.getMinecraft()).player.getName() == getName()) {
/* 35 */       LemonClient.EVENT_BUS.post(new PlayerJumpEvent());
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"isPushedByWater"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onPushedByWater(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
/* 41 */     WaterPushEvent event = new WaterPushEvent();
/* 42 */     LemonClient.EVENT_BUS.post(event);
/* 43 */     if (event.isCancelled())
/* 44 */       callbackInfoReturnable.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinEntityPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
