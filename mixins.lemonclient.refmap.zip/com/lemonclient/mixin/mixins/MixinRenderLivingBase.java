//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.mixin.mixins;
/*     */ 
/*     */ import com.lemonclient.api.event.events.NewRenderEntityEvent;
/*     */ import com.lemonclient.api.event.events.RenderEntityEvent;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.render.NoRender;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ @Mixin({RenderLivingBase.class})
/*     */ public abstract class MixinRenderLivingBase<T extends EntityLivingBase> extends Render<T> {
/*     */   @Shadow
/*     */   protected ModelBase mainModel;
/*     */   protected final Minecraft mc;
/*     */   private boolean isClustered;
/*     */   
/*  29 */   public MixinRenderLivingBase(RenderManager renderManagerIn, ModelBase modelBaseIn, float shadowSizeIn) { super(renderManagerIn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     this.mc = Minecraft.getMinecraft(); this.mainModel = modelBaseIn; this.shadowSize = shadowSizeIn; } protected MixinRenderLivingBase() { super(null); this.mc = Minecraft.getMinecraft(); }
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"renderModel"}, at = {@At("HEAD")}, cancellable = true)
/*     */   void doRender(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, CallbackInfo ci) {
/*  43 */     NewRenderEntityEvent event = new NewRenderEntityEvent(this.mainModel, (Entity)entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor);
/*  44 */     if (!bindEntityTexture((Entity)entityIn)) {
/*     */       return;
/*     */     }
/*     */     
/*  48 */     NoRender noRender = (NoRender)ModuleManager.getModule(NoRender.class);
/*     */     
/*  50 */     if (noRender.isEnabled() && ((Boolean)noRender.noCluster.getValue()).booleanValue() && this.mc.player.getDistance((Entity)entityIn) < 1.0F && entityIn != this.mc.player) {
/*  51 */       GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*  52 */       this.isClustered = true;
/*  53 */       if (noRender.incrementNoClusterRender()) {
/*  54 */         ci.cancel();
/*     */       }
/*     */     } else {
/*  57 */       this.isClustered = false;
/*     */     } 
/*     */     
/*  60 */     RenderEntityEvent.Head renderEntityHeadEvent = new RenderEntityEvent.Head((Entity)entityIn, RenderEntityEvent.Type.COLOR);
/*     */     
/*  62 */     LemonClient.EVENT_BUS.post(renderEntityHeadEvent);
/*     */ 
/*     */     
/*  65 */     GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*  66 */     LemonClient.EVENT_BUS.post(event);
/*  67 */     GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*     */     
/*  69 */     if (event.isCancelled()) {
/*  70 */       ci.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderModel"}, at = {@At("HEAD")}, cancellable = true)
/*     */   protected void renderModel(T entitylivingbaseIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, CallbackInfo callbackInfo) {
/*  76 */     if (!bindEntityTexture((Entity)entitylivingbaseIn)) {
/*     */       return;
/*     */     }
/*     */     
/*  80 */     NoRender noRender = (NoRender)ModuleManager.getModule(NoRender.class);
/*     */     
/*  82 */     if (noRender.isEnabled() && ((Boolean)noRender.noCluster.getValue()).booleanValue() && this.mc.player.getDistance((Entity)entitylivingbaseIn) < 1.0F && entitylivingbaseIn != this.mc.player) {
/*  83 */       GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*  84 */       this.isClustered = true;
/*  85 */       if (noRender.incrementNoClusterRender()) {
/*  86 */         callbackInfo.cancel();
/*     */       }
/*     */     } else {
/*  89 */       this.isClustered = false;
/*     */     } 
/*     */     
/*  92 */     RenderEntityEvent.Head renderEntityHeadEvent = new RenderEntityEvent.Head((Entity)entitylivingbaseIn, RenderEntityEvent.Type.COLOR);
/*     */     
/*  94 */     LemonClient.EVENT_BUS.post(renderEntityHeadEvent);
/*     */     
/*  96 */     if (renderEntityHeadEvent.isCancelled()) {
/*  97 */       callbackInfo.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderModel"}, at = {@At("RETURN")}, cancellable = true)
/*     */   protected void renderModelReturn(T entitylivingbaseIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, CallbackInfo callbackInfo) {
/* 103 */     RenderEntityEvent.Return renderEntityReturnEvent = new RenderEntityEvent.Return((Entity)entitylivingbaseIn, RenderEntityEvent.Type.COLOR);
/*     */     
/* 105 */     LemonClient.EVENT_BUS.post(renderEntityReturnEvent);
/*     */     
/* 107 */     if (!renderEntityReturnEvent.isCancelled()) {
/* 108 */       callbackInfo.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderLayers"}, at = {@At("HEAD")}, cancellable = true)
/*     */   protected void renderLayers(T entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scaleIn, CallbackInfo callbackInfo) {
/* 114 */     if (this.isClustered && 
/* 115 */       !((NoRender)ModuleManager.getModule(NoRender.class)).getNoClusterRender()) {
/* 116 */       callbackInfo.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(method = {"setBrightness"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;glTexEnvi(III)V", ordinal = 6))
/*     */   protected void glTexEnvi0(int target, int parameterName, int parameter) {
/* 127 */     if (!this.isClustered) {
/* 128 */       GlStateManager.glTexEnvi(target, parameterName, parameter);
/*     */     }
/*     */   }
/*     */   
/*     */   @Redirect(method = {"setBrightness"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;glTexEnvi(III)V", ordinal = 7))
/*     */   protected void glTexEnvi1(int target, int parameterName, int parameter) {
/* 134 */     if (!this.isClustered) {
/* 135 */       GlStateManager.glTexEnvi(target, parameterName, parameter);
/*     */     }
/*     */   }
/*     */   
/*     */   @Redirect(method = {"setBrightness"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;glTexEnvi(III)V", ordinal = 8))
/*     */   protected void glTexEnvi2(int target, int parameterName, int parameter) {
/* 141 */     if (!this.isClustered)
/* 142 */       GlStateManager.glTexEnvi(target, parameterName, parameter); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinRenderLivingBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
