//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.api.event.events.DeathEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import com.lemonclient.client.manager.managers.TotemPopManager;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.network.NetHandlerPlayClient;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.play.server.SPacketEntityMetadata;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({NetHandlerPlayClient.class})
/*    */ public class MixinNetHandlerPlayClient {
/*    */   @Inject(method = {"handleEntityMetadata"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private void handleEntityMetadataHook(SPacketEntityMetadata sPacketEntityMetadata, CallbackInfo callbackInfo) {
/*    */     Entity getEntityByID;
/*    */     EntityPlayer entityPlayer;
/* 22 */     if ((Minecraft.getMinecraft()).world != null && getEntityByID = (Minecraft.getMinecraft()).world.getEntityByID(sPacketEntityMetadata.getEntityId()) instanceof EntityPlayer && (entityPlayer = (EntityPlayer)getEntityByID).getHealth() <= 0.0F) {
/* 23 */       LemonClient.EVENT_BUS.post(new DeathEvent(entityPlayer));
/* 24 */       if (TotemPopManager.INSTANCE.sendMsgs)
/* 25 */         TotemPopManager.INSTANCE.death(entityPlayer); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinNetHandlerPlayClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
