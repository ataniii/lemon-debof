//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.render.ShulkerViewer;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin({GuiScreen.class})
/*    */ public class MixinGuiScreen
/*    */ {
/*    */   @Inject(method = {"renderToolTip"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderToolTip(ItemStack stack, int x, int y, CallbackInfo callbackInfo) {
/* 18 */     ShulkerViewer shulkerViewer = (ShulkerViewer)ModuleManager.getModule(ShulkerViewer.class);
/*    */     
/* 20 */     if (shulkerViewer.isEnabled() && stack.getItem() instanceof net.minecraft.item.ItemShulkerBox && 
/* 21 */       stack.getTagCompound() != null && stack.getTagCompound().hasKey("BlockEntityTag", 10) && 
/* 22 */       stack.getTagCompound().getCompoundTag("BlockEntityTag").hasKey("Items", 9)) {
/* 23 */       callbackInfo.cancel();
/* 24 */       shulkerViewer.renderShulkerPreview(stack, x + 6, y - 33, 162, 66);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinGuiScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
