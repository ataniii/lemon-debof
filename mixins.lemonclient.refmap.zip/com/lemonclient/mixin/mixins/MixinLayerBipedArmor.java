//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.mixin.mixins;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.render.NoRender;
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
/*    */ import net.minecraft.inventory.EntityEquipmentSlot;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({LayerBipedArmor.class})
/*    */ public class MixinLayerBipedArmor
/*    */ {
/*    */   @Inject(method = {"setModelSlotVisible"}, at = {@At("HEAD")}, cancellable = true)
/*    */   protected void setModelSlotVisible(ModelBiped model, EntityEquipmentSlot slotIn, CallbackInfo callbackInfo) {
/* 18 */     NoRender noRender = (NoRender)ModuleManager.getModule(NoRender.class);
/*    */     
/* 20 */     if (noRender.isEnabled() && ((Boolean)noRender.armor.getValue()).booleanValue()) {
/* 21 */       callbackInfo.cancel();
/* 22 */       switch (slotIn) {
/*    */         case HEAD:
/* 24 */           model.bipedHead.showModel = false;
/* 25 */           model.bipedHeadwear.showModel = false;
/*    */         
/*    */         case CHEST:
/* 28 */           model.bipedBody.showModel = false;
/* 29 */           model.bipedRightArm.showModel = false;
/* 30 */           model.bipedLeftArm.showModel = false;
/*    */         
/*    */         case LEGS:
/* 33 */           model.bipedBody.showModel = false;
/* 34 */           model.bipedRightLeg.showModel = false;
/* 35 */           model.bipedLeftLeg.showModel = false;
/*    */         
/*    */         case FEET:
/* 38 */           model.bipedRightLeg.showModel = false;
/* 39 */           model.bipedLeftLeg.showModel = false;
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\mixins\MixinLayerBipedArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
