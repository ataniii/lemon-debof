/*    */ package com.lemonclient.mixin;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import java.util.Map;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.MCVersion;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.Name;
/*    */ import org.spongepowered.asm.launch.MixinBootstrap;
/*    */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ 
/*    */ @Name("Lemon Client")
/*    */ @MCVersion("1.12.2")
/*    */ public class LemonClientMixinLoader implements IFMLLoadingPlugin {
/*    */   public LemonClientMixinLoader() {
/* 17 */     LemonClient.LOGGER.info("Mixins initialized");
/* 18 */     MixinBootstrap.init();
/* 19 */     Mixins.addConfiguration("mixins.lemonclient.json");
/* 20 */     MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
/* 21 */     LemonClient.LOGGER.info(MixinEnvironment.getDefaultEnvironment().getObfuscationContext());
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getASMTransformerClass() {
/* 26 */     return new String[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModContainerClass() {
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getSetupClass() {
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void injectData(Map<String, Object> data) {
/* 42 */     boolean isObfuscatedEnvironment = ((Boolean)data.get("runtimeDeobfuscationEnabled")).booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccessTransformerClass() {
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\mixin\LemonClientMixinLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */