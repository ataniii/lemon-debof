/*    */ package com.lemonclient.api.setting;
/*    */ 
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ public abstract class Setting<T>
/*    */ {
/*    */   private T value;
/*    */   private final String name;
/*    */   private final String configName;
/*    */   private final Module module;
/*    */   private Supplier<Boolean> isVisible;
/* 17 */   private final List<Setting<?>> subSettings = new ArrayList<>();
/*    */   
/*    */   public Setting(T value, String name, String configName, Module module, Supplier<Boolean> isVisible) {
/* 20 */     this.value = value;
/* 21 */     this.name = name;
/* 22 */     this.configName = configName;
/* 23 */     this.module = module;
/* 24 */     this.isVisible = isVisible;
/*    */   }
/*    */   
/*    */   public void setVisible(Supplier<Boolean> vis) {
/* 28 */     this.isVisible = vis;
/*    */   }
/*    */   
/*    */   public Setting(T value, String name, Module module) {
/* 32 */     this(value, name, name.replace(" ", ""), module, () -> Boolean.valueOf(true));
/*    */   }
/*    */   
/*    */   public T getValue() {
/* 36 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(T value) {
/* 40 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getConfigName() {
/* 48 */     return this.configName;
/*    */   }
/*    */   
/*    */   public Module getModule() {
/* 52 */     return this.module;
/*    */   }
/*    */   
/*    */   public boolean isVisible() {
/* 56 */     return ((Boolean)this.isVisible.get()).booleanValue();
/*    */   }
/*    */   
/*    */   public Stream<Setting<?>> getSubSettings() {
/* 60 */     return this.subSettings.stream();
/*    */   }
/*    */   
/*    */   public void addSubSetting(Setting<?> setting) {
/* 64 */     this.subSettings.add(setting);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\Setting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */