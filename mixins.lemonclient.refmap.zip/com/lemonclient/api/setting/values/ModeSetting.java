/*    */ package com.lemonclient.api.setting.values;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class ModeSetting
/*    */   extends Setting<String> {
/*    */   private final List<String> modes;
/*    */   
/*    */   public ModeSetting(String name, Module module, String value, List<String> modes) {
/* 13 */     super(value, name, module);
/* 14 */     this.modes = modes;
/*    */   }
/*    */   
/*    */   public ModeSetting(String name, String configName, Module module, String value, Supplier<Boolean> isVisible, List<String> modes) {
/* 18 */     super(value, name, configName, module, isVisible);
/* 19 */     this.modes = modes;
/*    */   }
/*    */   
/*    */   public List<String> getModes() {
/* 23 */     return this.modes;
/*    */   }
/*    */   
/*    */   public void increment() {
/* 27 */     int modeIndex = this.modes.indexOf(getValue());
/* 28 */     modeIndex = (modeIndex + 1) % this.modes.size();
/* 29 */     setValue(this.modes.get(modeIndex));
/*    */   }
/*    */   
/*    */   public void decrement() {
/* 33 */     int modeIndex = this.modes.indexOf(getValue());
/* 34 */     modeIndex--;
/* 35 */     if (modeIndex < 0) modeIndex = this.modes.size() - 1; 
/* 36 */     setValue(this.modes.get(modeIndex));
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\ModeSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */