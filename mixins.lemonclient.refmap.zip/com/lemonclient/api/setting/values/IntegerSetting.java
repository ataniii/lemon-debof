/*    */ package com.lemonclient.api.setting.values;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class IntegerSetting
/*    */   extends Setting<Integer> {
/*    */   private final int min;
/*    */   private final int max;
/*    */   
/*    */   public IntegerSetting(String name, Module module, int value, int min, int max) {
/* 13 */     super(Integer.valueOf(value), name, module);
/* 14 */     this.min = min;
/* 15 */     this.max = max;
/*    */   }
/*    */   
/*    */   public IntegerSetting(String name, String configName, Module module, Supplier<Boolean> isVisible, int value, int min, int max) {
/* 19 */     super(Integer.valueOf(value), name, configName, module, isVisible);
/* 20 */     this.min = min;
/* 21 */     this.max = max;
/*    */   }
/*    */   
/*    */   public int getMin() {
/* 25 */     return this.min;
/*    */   }
/*    */   
/*    */   public int getMax() {
/* 29 */     return this.max;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\IntegerSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */