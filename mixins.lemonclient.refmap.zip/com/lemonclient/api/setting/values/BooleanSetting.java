/*    */ package com.lemonclient.api.setting.values;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class BooleanSetting
/*    */   extends Setting<Boolean>
/*    */ {
/*    */   public BooleanSetting(String name, Module module, boolean value) {
/* 11 */     super(Boolean.valueOf(value), name, module);
/*    */   }
/*    */   
/*    */   public BooleanSetting(String name, String configName, Module module, Supplier<Boolean> isVisible, boolean value) {
/* 15 */     super(Boolean.valueOf(value), name, configName, module, isVisible);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\BooleanSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */