/*    */ package com.lemonclient.api.setting.values;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.client.module.Module;
/*    */ 
/*    */ public class StringSetting
/*    */   extends Setting<String> {
/*    */   private String text;
/*    */   
/*    */   public StringSetting(String name, Module parent, String text) {
/* 11 */     super(text, name, parent);
/* 12 */     this.text = text;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 16 */     return this.text;
/*    */   }
/*    */   
/*    */   public void setText(String text) {
/* 20 */     this.text = text;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\StringSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */