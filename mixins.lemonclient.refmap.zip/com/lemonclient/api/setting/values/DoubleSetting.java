/*    */ package com.lemonclient.api.setting.values;
/*    */ 
/*    */ import com.lemonclient.api.setting.Setting;
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ public class DoubleSetting
/*    */   extends Setting<Double>
/*    */ {
/*    */   private final double min;
/*    */   private final double max;
/*    */   
/*    */   public DoubleSetting(String name, Module module, double value, double min, double max) {
/* 14 */     super(Double.valueOf(value), name, module);
/* 15 */     this.min = min;
/* 16 */     this.max = max;
/*    */   }
/*    */   
/*    */   public DoubleSetting(String name, String configName, Module module, Supplier<Boolean> isVisible, double value, double min, double max) {
/* 20 */     super(Double.valueOf(value), name, configName, module, isVisible);
/* 21 */     this.min = min;
/* 22 */     this.max = max;
/*    */   }
/*    */   
/*    */   public double getMin() {
/* 26 */     return this.min;
/*    */   }
/*    */   
/*    */   public double getMax() {
/* 30 */     return this.max;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\DoubleSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */