/*     */ package com.lemonclient.api.setting.values;
/*     */ 
/*     */ import com.lemonclient.api.setting.Setting;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.awt.Color;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ public class ColorSetting
/*     */   extends Setting<GSColor> {
/*     */   private boolean rainbow = false;
/*     */   
/*     */   public ColorSetting(String name, Module module, boolean rainbow, GSColor value) {
/*  16 */     super(value, name, module);
/*  17 */     this.rainbow = rainbow;
/*  18 */     this.rainbowEnabled = true;
/*  19 */     this.alphaEnabled = false;
/*     */   }
/*     */   private final boolean rainbowEnabled; private final boolean alphaEnabled;
/*     */   public ColorSetting(String name, Module module, boolean rainbow, GSColor value, boolean alphaEnabled) {
/*  23 */     super(value, name, module);
/*  24 */     this.rainbow = rainbow;
/*  25 */     this.rainbowEnabled = true;
/*  26 */     this.alphaEnabled = alphaEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public ColorSetting(String name, String configName, Module module, Supplier<Boolean> isVisible, boolean rainbow, boolean rainbowEnabled, boolean alphaEnabled, GSColor value) {
/*  31 */     super(value, name, configName, module, isVisible);
/*  32 */     this.rainbow = rainbow;
/*  33 */     this.rainbowEnabled = rainbowEnabled;
/*  34 */     this.alphaEnabled = alphaEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public GSColor getValue() {
/*  39 */     if (this.rainbow) {
/*  40 */       switch ((String)ColorMain.INSTANCE.rainbowMode.getValue()) { case "Sin":
/*  41 */           return getRainbowSin(0, 0, 1.0D, 1, 1.0D, 0, false);
/*  42 */         case "Tan": return getRainbowTan(0, 0, 1.0D, 1, 1.0D, 0, false);
/*  43 */         case "Sec": return getRainbowSec(0, 0, 1.0D, 1, 1.0D, 0, false);
/*  44 */         case "CoTan": return getRainbowCoTan(0, 0, 1.0D, 1, 1.0D, 0, false);
/*  45 */         case "CoSec": return getRainbowCoSec(0, 0, 1.0D, 1, 1.0D, 0, false); }
/*  46 */        return getRainbowColor(0, 0, 0, false);
/*     */     } 
/*  48 */     return (GSColor)super.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static GSColor getRainbowColor(int incr, int multiply, int start, boolean stop) {
/*  53 */     return GSColor.fromHSB((float)(((stop ? start : System.currentTimeMillis()) + (incr * multiply)) % 11520L) / 11520.0F * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowColor(double incr) {
/*  57 */     return GSColor.fromHSB((float)(incr % 11520.0D / 11520.0D) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowSin(int incr, int multiply, double height, int multiplyHeight, double millSin, int start, boolean stop) {
/*  61 */     return GSColor.fromHSB((float)(height * multiplyHeight * Math.sin(((stop ? start : System.currentTimeMillis()) + incr / millSin * multiply) % 11520.0D / 11520.0D)) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowTan(int incr, int multiply, double height, int multiplyHeight, double millSin, int start, boolean stop) {
/*  65 */     return GSColor.fromHSB((float)(height * multiplyHeight * Math.tan(((stop ? start : System.currentTimeMillis()) + incr / millSin * multiply % 11520.0D) / 11520.0D)) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowSec(int incr, int multiply, double height, int multiplyHeight, double millSin, int start, boolean stop) {
/*  69 */     return GSColor.fromHSB((float)(height * multiplyHeight * 1.0D / Math.sin(((stop ? start : System.currentTimeMillis()) + incr / millSin * multiply) % 11520.0D / 11520.0D)) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowCoSec(int incr, int multiply, double height, int multiplyHeight, double millSin, int start, boolean stop) {
/*  73 */     return GSColor.fromHSB((float)(height * multiplyHeight * 1.0D / Math.cos(((stop ? start : System.currentTimeMillis()) + incr / millSin * multiply) % 11520.0D / 11520.0D)) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public static GSColor getRainbowCoTan(int incr, int multiply, double height, int multiplyHeight, double millSin, int start, boolean stop) {
/*  77 */     return GSColor.fromHSB((float)(height * multiplyHeight * Math.tan(((stop ? start : System.currentTimeMillis()) + incr / millSin * multiply) % 11520.0D / 11520.0D)) * ((Double)((ColorMain)ModuleManager.getModule(ColorMain.class)).rainbowSpeed.getValue()).floatValue(), 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(GSColor value) {
/*  82 */     super.setValue(new GSColor((Color)value));
/*     */   }
/*     */   
/*     */   public GSColor getColor() {
/*  86 */     return (GSColor)super.getValue();
/*     */   }
/*     */   
/*     */   public boolean getRainbow() {
/*  90 */     return this.rainbow;
/*     */   }
/*     */   
/*     */   public void setRainbow(boolean rainbow) {
/*  94 */     this.rainbow = rainbow;
/*     */   }
/*     */   
/*     */   public boolean rainbowEnabled() {
/*  98 */     return this.rainbowEnabled;
/*     */   }
/*     */   
/*     */   public boolean alphaEnabled() {
/* 102 */     return this.alphaEnabled;
/*     */   }
/*     */   
/*     */   public long toLong() {
/* 106 */     long temp = (getColor().getRGB() & 0xFFFFFF);
/* 107 */     if (this.rainbowEnabled) temp += ((this.rainbow ? 1 : 0) << 24); 
/* 108 */     if (this.alphaEnabled) temp += getColor().getAlpha() << 32L; 
/* 109 */     return temp;
/*     */   }
/*     */   
/*     */   public void fromLong(long number) {
/* 113 */     if (this.rainbowEnabled) { this.rainbow = ((number & 0x1000000L) != 0L); }
/* 114 */     else { this.rainbow = false; }
/* 115 */      setValue(new GSColor((int)(number & 0xFFFFFFL)));
/* 116 */     if (this.alphaEnabled) setValue(new GSColor(getColor(), (int)((number & 0xFF00000000L) >> 32L))); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\values\ColorSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */