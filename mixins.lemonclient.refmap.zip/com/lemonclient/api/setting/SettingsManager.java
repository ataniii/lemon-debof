/*    */ package com.lemonclient.api.setting;
/*    */ 
/*    */ import com.lemonclient.client.module.Module;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ public class SettingsManager
/*    */ {
/* 11 */   private static final ArrayList<Setting> settings = new ArrayList<>();
/*    */   
/*    */   public static void addSetting(Setting setting) {
/* 14 */     settings.add(setting);
/*    */   }
/*    */   
/*    */   public static ArrayList<Setting> getSettings() {
/* 18 */     return settings;
/*    */   }
/*    */   
/*    */   public static List<Setting> getSettingsForModule(Module module) {
/* 22 */     return (List<Setting>)settings.stream().filter(setting -> setting.getModule().equals(module)).collect(Collectors.toList());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\setting\SettingsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */