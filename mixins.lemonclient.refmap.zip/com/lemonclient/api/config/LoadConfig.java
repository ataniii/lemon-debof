/*     */ package com.lemonclient.api.config;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.lemonclient.api.setting.Setting;
/*     */ import com.lemonclient.api.setting.SettingsManager;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.setting.values.StringSetting;
/*     */ import com.lemonclient.api.util.font.CFontRenderer;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.clickgui.GuiConfig;
/*     */ import com.lemonclient.client.clickgui.LemonClientGUI;
/*     */ import com.lemonclient.client.command.CommandManager;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lukflug.panelstudio.config.IConfigList;
/*     */ import java.awt.Font;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ 
/*     */ public class LoadConfig {
/*     */   private static final String fileName = "LemonClient/";
/*     */   
/*     */   public static void init() {
/*     */     try {
/*  32 */       loadModules();
/*  33 */       loadEnabledModules();
/*  34 */       loadModuleKeybinds();
/*  35 */       loadDrawnModules();
/*  36 */       loadToggleMessageModules();
/*  37 */       loadCommandPrefix();
/*  38 */       loadCustomFont();
/*  39 */       loadFriendsList();
/*  40 */       loadIgnoressList();
/*  41 */       loadEnemiesList();
/*  42 */       loadClickGUIPositions();
/*  43 */     } catch (Exception exception) {}
/*     */   }
/*     */   private static final String moduleName = "Modules/"; private static final String mainName = "Main/";
/*     */   private static final String miscName = "Misc/";
/*     */   
/*     */   private static void loadModules() {
/*  49 */     String moduleLocation = "LemonClient/Modules/";
/*     */     
/*  51 */     for (Module module : ModuleManager.getModules()) {
/*     */       try {
/*  53 */         loadModuleDirect(moduleLocation, module);
/*  54 */       } catch (IOException e) {
/*  55 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   } private static void loadModuleDirect(String moduleLocation, Module module) throws IOException {
/*     */     JsonObject moduleObject;
/*  60 */     if (!Files.exists(Paths.get(moduleLocation + module.getName() + ".json", new String[0]), new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/*  64 */     InputStream inputStream = Files.newInputStream(Paths.get(moduleLocation + module.getName() + ".json", new String[0]), new java.nio.file.OpenOption[0]);
/*     */     
/*     */     try {
/*  67 */       moduleObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*  68 */     } catch (IllegalStateException e) {
/*     */       return;
/*     */     } 
/*     */     
/*  72 */     if (moduleObject.get("Module") == null) {
/*     */       return;
/*     */     }
/*     */     
/*  76 */     JsonObject settingObject = moduleObject.get("Settings").getAsJsonObject();
/*  77 */     for (Setting setting : SettingsManager.getSettingsForModule(module)) {
/*  78 */       JsonElement dataObject = settingObject.get(setting.getConfigName());
/*     */       try {
/*  80 */         if (dataObject != null && dataObject.isJsonPrimitive()) {
/*  81 */           if (setting instanceof com.lemonclient.api.setting.values.BooleanSetting) {
/*  82 */             setting.setValue(Boolean.valueOf(dataObject.getAsBoolean())); continue;
/*  83 */           }  if (setting instanceof com.lemonclient.api.setting.values.IntegerSetting) {
/*  84 */             setting.setValue(Integer.valueOf(dataObject.getAsInt())); continue;
/*  85 */           }  if (setting instanceof com.lemonclient.api.setting.values.DoubleSetting) {
/*  86 */             setting.setValue(Double.valueOf(dataObject.getAsDouble())); continue;
/*  87 */           }  if (setting instanceof ColorSetting) {
/*  88 */             ((ColorSetting)setting).fromLong(dataObject.getAsLong()); continue;
/*  89 */           }  if (setting instanceof com.lemonclient.api.setting.values.ModeSetting) {
/*  90 */             setting.setValue(dataObject.getAsString()); continue;
/*  91 */           }  if (setting instanceof StringSetting) {
/*  92 */             setting.setValue(dataObject.getAsString());
/*  93 */             ((StringSetting)setting).setText(dataObject.getAsString());
/*     */           } 
/*     */         } 
/*  96 */       } catch (NumberFormatException numberFormatException) {}
/*     */     } 
/*     */     
/*  99 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadEnabledModules() throws IOException {
/* 103 */     String enabledLocation = "LemonClient/Main/";
/*     */     
/* 105 */     Path path = Paths.get(enabledLocation + "Toggle.json", new String[0]);
/* 106 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 110 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 111 */     JsonObject moduleObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 113 */     if (moduleObject.get("Modules") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     JsonObject settingObject = moduleObject.get("Modules").getAsJsonObject();
/* 118 */     for (Module module : ModuleManager.getModules()) {
/* 119 */       JsonElement dataObject = settingObject.get(module.getName());
/*     */       
/* 121 */       if (dataObject != null && dataObject.isJsonPrimitive() && 
/* 122 */         dataObject.getAsBoolean()) {
/*     */         try {
/* 124 */           module.enable();
/* 125 */         } catch (NullPointerException nullPointerException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 130 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadModuleKeybinds() throws IOException {
/* 134 */     String bindLocation = "LemonClient/Main/";
/*     */     
/* 136 */     Path path = Paths.get(bindLocation + "Bind.json", new String[0]);
/* 137 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 141 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 142 */     JsonObject moduleObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 144 */     if (moduleObject.get("Modules") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 148 */     JsonObject settingObject = moduleObject.get("Modules").getAsJsonObject();
/* 149 */     for (Module module : ModuleManager.getModules()) {
/* 150 */       JsonElement dataObject = settingObject.get(module.getName());
/*     */       
/* 152 */       if (dataObject != null && dataObject.isJsonPrimitive()) {
/* 153 */         module.setBind(dataObject.getAsInt());
/*     */       }
/*     */     } 
/* 156 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadDrawnModules() throws IOException {
/* 160 */     String drawnLocation = "LemonClient/Main/";
/*     */     
/* 162 */     Path path = Paths.get(drawnLocation + "Drawn.json", new String[0]);
/* 163 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 167 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 168 */     JsonObject moduleObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 170 */     if (moduleObject.get("Modules") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 174 */     JsonObject settingObject = moduleObject.get("Modules").getAsJsonObject();
/* 175 */     for (Module module : ModuleManager.getModules()) {
/* 176 */       JsonElement dataObject = settingObject.get(module.getName());
/*     */       
/* 178 */       if (dataObject != null && dataObject.isJsonPrimitive()) {
/* 179 */         module.setDrawn(dataObject.getAsBoolean());
/*     */       }
/*     */     } 
/* 182 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadToggleMessageModules() throws IOException {
/* 186 */     String toggleMessageLocation = "LemonClient/Main/";
/*     */     
/* 188 */     Path path = Paths.get(toggleMessageLocation + "ToggleMessages.json", new String[0]);
/* 189 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 193 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 194 */     JsonObject moduleObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 196 */     if (moduleObject.get("Modules") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 200 */     JsonObject toggleObject = moduleObject.get("Modules").getAsJsonObject();
/* 201 */     for (Module module : ModuleManager.getModules()) {
/* 202 */       JsonElement dataObject = toggleObject.get(module.getName());
/*     */       
/* 204 */       if (dataObject != null && dataObject.isJsonPrimitive()) {
/* 205 */         module.setToggleMsg(dataObject.getAsBoolean());
/*     */       }
/*     */     } 
/* 208 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadCommandPrefix() throws IOException {
/* 212 */     String prefixLocation = "LemonClient/Main/";
/*     */     
/* 214 */     Path path = Paths.get(prefixLocation + "CommandPrefix.json", new String[0]);
/* 215 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 219 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 220 */     JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 222 */     if (mainObject.get("Prefix") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 226 */     JsonElement prefixObject = mainObject.get("Prefix");
/*     */     
/* 228 */     if (prefixObject != null && prefixObject.isJsonPrimitive()) {
/* 229 */       CommandManager.setCommandPrefix(prefixObject.getAsString());
/*     */     }
/* 231 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadCustomFont() throws IOException {
/* 235 */     String fontLocation = "LemonClient/Misc/";
/*     */     
/* 237 */     Path path = Paths.get(fontLocation + "CustomFont.json", new String[0]);
/* 238 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 242 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 243 */     JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 245 */     if (mainObject.get("Font Name") == null || mainObject.get("Font Size") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 249 */     JsonElement fontNameObject = mainObject.get("Font Name");
/*     */     
/* 251 */     String name = null;
/*     */     
/* 253 */     if (fontNameObject != null && fontNameObject.isJsonPrimitive()) {
/* 254 */       name = fontNameObject.getAsString();
/*     */     }
/*     */     
/* 257 */     JsonElement fontSizeObject = mainObject.get("Font Size");
/*     */     
/* 259 */     int size = -1;
/*     */     
/* 261 */     if (fontSizeObject != null && fontSizeObject.isJsonPrimitive()) {
/* 262 */       size = fontSizeObject.getAsInt();
/*     */     }
/*     */     
/* 265 */     JsonElement antiAliasObject = mainObject.get("Anti Alias");
/*     */     
/* 267 */     boolean alias = true;
/*     */     
/* 269 */     if (antiAliasObject != null && antiAliasObject.isJsonPrimitive()) {
/* 270 */       alias = antiAliasObject.getAsBoolean();
/*     */     }
/*     */     
/* 273 */     JsonElement MetricsObject = mainObject.get("Fractional Metrics");
/*     */     
/* 275 */     boolean metrics = false;
/*     */     
/* 277 */     if (MetricsObject != null && MetricsObject.isJsonPrimitive()) {
/* 278 */       metrics = MetricsObject.getAsBoolean();
/*     */     }
/*     */ 
/*     */     
/* 282 */     if (name != null && size != -1) {
/* 283 */       LemonClient.INSTANCE.cFontRenderer = new CFontRenderer(new Font(name, 0, size), false, true);
/* 284 */       LemonClient.INSTANCE.cFontRenderer.setFont(new Font(name, 0, size));
/* 285 */       LemonClient.INSTANCE.cFontRenderer.setAntiAlias(alias);
/* 286 */       LemonClient.INSTANCE.cFontRenderer.setFractionalMetrics(metrics);
/* 287 */       LemonClient.INSTANCE.cFontRenderer.setFontName(name);
/* 288 */       LemonClient.INSTANCE.cFontRenderer.setFontSize(size);
/*     */     } 
/* 290 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadFriendsList() throws IOException {
/* 294 */     String friendLocation = "LemonClient/Misc/";
/*     */     
/* 296 */     Path path = Paths.get(friendLocation + "Friends.json", new String[0]);
/* 297 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 301 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 302 */     JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 304 */     if (mainObject.get("Friends") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 308 */     JsonArray friendObject = mainObject.get("Friends").getAsJsonArray();
/*     */     
/* 310 */     friendObject.forEach(object -> SocialManager.addFriend(object.getAsString()));
/* 311 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadIgnoressList() throws IOException {
/* 315 */     String friendLocation = "LemonClient/Misc/";
/*     */     
/* 317 */     Path path = Paths.get(friendLocation + "Ignores.json", new String[0]);
/* 318 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 322 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 323 */     JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 325 */     if (mainObject.get("Ignores") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 329 */     JsonArray friendObject = mainObject.get("Ignores").getAsJsonArray();
/*     */     
/* 331 */     friendObject.forEach(object -> SocialManager.addIgnore(object.getAsString()));
/* 332 */     inputStream.close();
/*     */   }
/*     */   
/*     */   private static void loadEnemiesList() throws IOException {
/* 336 */     String enemyLocation = "LemonClient/Misc/";
/*     */     
/* 338 */     Path path = Paths.get(enemyLocation + "Enemies.json", new String[0]);
/* 339 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/*     */     
/* 343 */     InputStream inputStream = Files.newInputStream(path, new java.nio.file.OpenOption[0]);
/* 344 */     JsonObject mainObject = (new JsonParser()).parse(new InputStreamReader(inputStream)).getAsJsonObject();
/*     */     
/* 346 */     if (mainObject.get("Enemies") == null) {
/*     */       return;
/*     */     }
/*     */     
/* 350 */     JsonArray enemyObject = mainObject.get("Enemies").getAsJsonArray();
/*     */     
/* 352 */     enemyObject.forEach(object -> SocialManager.addEnemy(object.getAsString()));
/* 353 */     inputStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void loadClickGUIPositions() {
/* 358 */     LemonClientGUI.gui.loadConfig((IConfigList)new GuiConfig("LemonClient/Main/"));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\config\LoadConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */