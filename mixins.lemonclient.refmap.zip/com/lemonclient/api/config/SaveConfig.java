/*     */ package com.lemonclient.api.config;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.lemonclient.api.setting.Setting;
/*     */ import com.lemonclient.api.setting.values.ColorSetting;
/*     */ import com.lemonclient.api.util.player.social.Enemy;
/*     */ import com.lemonclient.api.util.player.social.Friend;
/*     */ import com.lemonclient.api.util.player.social.Ignore;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import com.lemonclient.client.clickgui.GuiConfig;
/*     */ import com.lemonclient.client.module.Module;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ 
/*     */ public class SaveConfig {
/*     */   public static final String fileName = "LemonClient/";
/*     */   private static final String moduleName = "Modules/";
/*     */   
/*     */   public static void init() {
/*     */     try {
/*  34 */       saveConfig();
/*  35 */       saveModules();
/*  36 */       saveEnabledModules();
/*  37 */       saveModuleKeyBinds();
/*  38 */       saveDrawnModules();
/*  39 */       saveToggleMessagesModules();
/*  40 */       saveCommandPrefix();
/*  41 */       saveCustomFont();
/*  42 */       saveFriendsList();
/*  43 */       saveEnemiesList();
/*  44 */       saveIgnoresList();
/*  45 */       saveClickGUIPositions();
/*  46 */     } catch (IOException e) {
/*  47 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   private static final String mainName = "Main/"; private static final String miscName = "Misc/";
/*     */   private static void saveConfig() throws IOException {
/*  52 */     Path path = Paths.get("LemonClient/", new String[0]);
/*  53 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*  54 */       Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
/*     */     }
/*  56 */     Path path1 = Paths.get("LemonClient/Modules/", new String[0]);
/*  57 */     if (!Files.exists(path1, new java.nio.file.LinkOption[0])) {
/*  58 */       Files.createDirectories(path1, (FileAttribute<?>[])new FileAttribute[0]);
/*     */     }
/*  60 */     Path path2 = Paths.get("LemonClient/Main/", new String[0]);
/*  61 */     if (!Files.exists(path2, new java.nio.file.LinkOption[0])) {
/*  62 */       Files.createDirectories(path2, (FileAttribute<?>[])new FileAttribute[0]);
/*     */     }
/*  64 */     Path path3 = Paths.get("LemonClient/Misc/", new String[0]);
/*  65 */     if (!Files.exists(path3, new java.nio.file.LinkOption[0])) {
/*  66 */       Files.createDirectories(path3, (FileAttribute<?>[])new FileAttribute[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void registerFiles(String location, String name) throws IOException {
/*  71 */     Path path = Paths.get("LemonClient/" + location + name + ".json", new String[0]);
/*  72 */     if (Files.exists(path, new java.nio.file.LinkOption[0])) {
/*  73 */       File file = new File("LemonClient/" + location + name + ".json");
/*  74 */       file.delete();
/*     */     } 
/*  76 */     Files.createFile(path, (FileAttribute<?>[])new FileAttribute[0]);
/*     */   }
/*     */   private static void saveModules() throws IOException {
/*  79 */     for (Module module : ModuleManager.getModules()) {
/*     */       try {
/*  81 */         saveModuleDirect(module);
/*  82 */       } catch (IOException e) {
/*  83 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void saveModuleDirect(Module module) throws IOException {
/*  89 */     registerFiles("Modules/", module.getName());
/*     */     
/*  91 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/*  92 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Modules/" + module.getName() + ".json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/*  93 */     JsonObject moduleObject = new JsonObject();
/*  94 */     JsonObject settingObject = new JsonObject();
/*  95 */     moduleObject.add("Module", (JsonElement)new JsonPrimitive(module.getName()));
/*     */     
/*  97 */     for (Setting setting : SettingsManager.getSettingsForModule(module)) {
/*  98 */       if (setting instanceof BooleanSetting) {
/*  99 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive((Boolean)((BooleanSetting)setting).getValue())); continue;
/* 100 */       }  if (setting instanceof IntegerSetting) {
/* 101 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive((Number)((IntegerSetting)setting).getValue())); continue;
/* 102 */       }  if (setting instanceof DoubleSetting) {
/* 103 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive((Number)((DoubleSetting)setting).getValue())); continue;
/* 104 */       }  if (setting instanceof ColorSetting) {
/* 105 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive(Long.valueOf(((ColorSetting)setting).toLong()))); continue;
/* 106 */       }  if (setting instanceof ModeSetting) {
/* 107 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive((String)((ModeSetting)setting).getValue())); continue;
/* 108 */       }  if (setting instanceof StringSetting) {
/* 109 */         settingObject.add(setting.getConfigName(), (JsonElement)new JsonPrimitive(((StringSetting)setting).getText()));
/*     */       }
/*     */     } 
/* 112 */     moduleObject.add("Settings", (JsonElement)settingObject);
/* 113 */     String jsonString = gson.toJson((new JsonParser()).parse(moduleObject.toString()));
/* 114 */     fileOutputStreamWriter.write(jsonString);
/* 115 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveEnabledModules() throws IOException {
/* 120 */     registerFiles("Main/", "Toggle");
/*     */     
/* 122 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 123 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Main/Toggle.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 124 */     JsonObject moduleObject = new JsonObject();
/* 125 */     JsonObject enabledObject = new JsonObject();
/*     */     
/* 127 */     for (Module module : ModuleManager.getModules())
/*     */     {
/* 129 */       enabledObject.add(module.getName(), (JsonElement)new JsonPrimitive(Boolean.valueOf(module.isEnabled())));
/*     */     }
/* 131 */     moduleObject.add("Modules", (JsonElement)enabledObject);
/* 132 */     String jsonString = gson.toJson((new JsonParser()).parse(moduleObject.toString()));
/* 133 */     fileOutputStreamWriter.write(jsonString);
/* 134 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveModuleKeyBinds() throws IOException {
/* 139 */     registerFiles("Main/", "Bind");
/*     */     
/* 141 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 142 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Main/Bind.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 143 */     JsonObject moduleObject = new JsonObject();
/* 144 */     JsonObject bindObject = new JsonObject();
/*     */     
/* 146 */     for (Module module : ModuleManager.getModules())
/*     */     {
/* 148 */       bindObject.add(module.getName(), (JsonElement)new JsonPrimitive(Integer.valueOf(module.getBind())));
/*     */     }
/* 150 */     moduleObject.add("Modules", (JsonElement)bindObject);
/* 151 */     String jsonString = gson.toJson((new JsonParser()).parse(moduleObject.toString()));
/* 152 */     fileOutputStreamWriter.write(jsonString);
/* 153 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveDrawnModules() throws IOException {
/* 158 */     registerFiles("Main/", "Drawn");
/*     */     
/* 160 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 161 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Main/Drawn.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 162 */     JsonObject moduleObject = new JsonObject();
/* 163 */     JsonObject drawnObject = new JsonObject();
/*     */     
/* 165 */     for (Module module : ModuleManager.getModules())
/*     */     {
/* 167 */       drawnObject.add(module.getName(), (JsonElement)new JsonPrimitive(Boolean.valueOf(module.isDrawn())));
/*     */     }
/* 169 */     moduleObject.add("Modules", (JsonElement)drawnObject);
/* 170 */     String jsonString = gson.toJson((new JsonParser()).parse(moduleObject.toString()));
/* 171 */     fileOutputStreamWriter.write(jsonString);
/* 172 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveToggleMessagesModules() throws IOException {
/* 177 */     registerFiles("Main/", "ToggleMessages");
/*     */     
/* 179 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 180 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Main/ToggleMessages.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 181 */     JsonObject moduleObject = new JsonObject();
/* 182 */     JsonObject toggleMessagesObject = new JsonObject();
/*     */     
/* 184 */     for (Module module : ModuleManager.getModules())
/*     */     {
/* 186 */       toggleMessagesObject.add(module.getName(), (JsonElement)new JsonPrimitive(Boolean.valueOf(module.isToggleMsg())));
/*     */     }
/* 188 */     moduleObject.add("Modules", (JsonElement)toggleMessagesObject);
/* 189 */     String jsonString = gson.toJson((new JsonParser()).parse(moduleObject.toString()));
/* 190 */     fileOutputStreamWriter.write(jsonString);
/* 191 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveCommandPrefix() throws IOException {
/* 196 */     registerFiles("Main/", "CommandPrefix");
/*     */     
/* 198 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 199 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Main/CommandPrefix.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 200 */     JsonObject prefixObject = new JsonObject();
/*     */     
/* 202 */     prefixObject.add("Prefix", (JsonElement)new JsonPrimitive(CommandManager.getCommandPrefix()));
/* 203 */     String jsonString = gson.toJson((new JsonParser()).parse(prefixObject.toString()));
/* 204 */     fileOutputStreamWriter.write(jsonString);
/* 205 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveCustomFont() throws IOException {
/* 210 */     registerFiles("Misc/", "CustomFont");
/*     */     
/* 212 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 213 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Misc/CustomFont.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 214 */     JsonObject fontObject = new JsonObject();
/*     */     
/* 216 */     fontObject.add("Font Name", (JsonElement)new JsonPrimitive(LemonClient.INSTANCE.cFontRenderer.getFontName()));
/* 217 */     fontObject.add("Font Size", (JsonElement)new JsonPrimitive(Integer.valueOf(LemonClient.INSTANCE.cFontRenderer.getFontSize())));
/* 218 */     fontObject.add("Anti Alias", (JsonElement)new JsonPrimitive(Boolean.valueOf(LemonClient.INSTANCE.cFontRenderer.getAntiAlias())));
/* 219 */     fontObject.add("Fractional Metrics", (JsonElement)new JsonPrimitive(Boolean.valueOf(LemonClient.INSTANCE.cFontRenderer.getFractionalMetrics())));
/* 220 */     String jsonString = gson.toJson((new JsonParser()).parse(fontObject.toString()));
/* 221 */     fileOutputStreamWriter.write(jsonString);
/* 222 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveFriendsList() throws IOException {
/* 227 */     registerFiles("Misc/", "Friends");
/*     */     
/* 229 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 230 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Misc/Friends.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 231 */     JsonObject mainObject = new JsonObject();
/* 232 */     JsonArray friendArray = new JsonArray();
/*     */     
/* 234 */     for (Friend friend : SocialManager.getFriends()) {
/* 235 */       friendArray.add(friend.getName());
/*     */     }
/* 237 */     mainObject.add("Friends", (JsonElement)friendArray);
/* 238 */     String jsonString = gson.toJson((new JsonParser()).parse(mainObject.toString()));
/* 239 */     fileOutputStreamWriter.write(jsonString);
/* 240 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveEnemiesList() throws IOException {
/* 245 */     registerFiles("Misc/", "Enemies");
/*     */     
/* 247 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 248 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Misc/Enemies.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 249 */     JsonObject mainObject = new JsonObject();
/* 250 */     JsonArray enemyArray = new JsonArray();
/*     */     
/* 252 */     for (Enemy enemy : SocialManager.getEnemies()) {
/* 253 */       enemyArray.add(enemy.getName());
/*     */     }
/* 255 */     mainObject.add("Enemies", (JsonElement)enemyArray);
/* 256 */     String jsonString = gson.toJson((new JsonParser()).parse(mainObject.toString()));
/* 257 */     fileOutputStreamWriter.write(jsonString);
/* 258 */     fileOutputStreamWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void saveIgnoresList() throws IOException {
/* 263 */     registerFiles("Misc/", "Ignores");
/*     */     
/* 265 */     Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 266 */     OutputStreamWriter fileOutputStreamWriter = new OutputStreamWriter(Files.newOutputStream(Paths.get("LemonClient/Misc/Ignores.json", new String[0]), new java.nio.file.OpenOption[0]), StandardCharsets.UTF_8);
/* 267 */     JsonObject mainObject = new JsonObject();
/* 268 */     JsonArray ignoreArray = new JsonArray();
/*     */     
/* 270 */     for (Ignore ignore : SocialManager.getIgnores()) {
/* 271 */       ignoreArray.add(ignore.getName());
/*     */     }
/* 273 */     mainObject.add("Ignores", (JsonElement)ignoreArray);
/* 274 */     String jsonString = gson.toJson((new JsonParser()).parse(mainObject.toString()));
/* 275 */     fileOutputStreamWriter.write(jsonString);
/* 276 */     fileOutputStreamWriter.close();
/*     */   }
/*     */   
/*     */   private static void saveClickGUIPositions() throws IOException {
/* 280 */     registerFiles("Main/", "ClickGUI");
/* 281 */     LemonClientGUI.gui.saveConfig((IConfigList)new GuiConfig("LemonClient/Main/"));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\config\SaveConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */