//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.misc;
/*     */ import com.lemonclient.api.util.chat.ChatUtil;
/*     */ import com.lemonclient.api.util.chat.Notification;
/*     */ import com.lemonclient.api.util.chat.NotificationManager;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.lemonclient.client.module.modules.hud.Notifications;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ public class MessageBus {
/*  17 */   public static String watermark = ChatFormatting.GREEN + "[" + ChatFormatting.YELLOW + "Lemon" + ChatFormatting.GREEN + "] " + ChatFormatting.RESET;
/*  18 */   public static ChatFormatting messageFormatting = ChatFormatting.GRAY;
/*     */   
/*  20 */   protected static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static void printDebug(String text, Boolean error) {
/*  23 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/*  24 */     sendClientPrefixMessage((error.booleanValue() ? (String)colorMain.getDisabledColor() : (String)colorMain.getEnabledColor()) + text, error.booleanValue() ? Notification.Type.ERROR : Notification.Type.INFO);
/*     */   }
/*     */   public static void sendClientPrefixMessage(String message, Notification.Type type) {
/*  27 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  29 */     TextComponentString string1 = new TextComponentString(watermark + messageFormatting + message);
/*     */     
/*  31 */     Notifications notifications = (Notifications)ModuleManager.getModule(Notifications.class);
/*  32 */     if (notifications.isEnabled()) {
/*  33 */       NotificationManager.add(new Notification(TextFormatting.GRAY + message, type));
/*  34 */       if (((Boolean)notifications.disableChat.getValue()).booleanValue())
/*     */         return; 
/*  36 */     }  mc.player.sendMessage((ITextComponent)string1);
/*     */   }
/*     */   
/*     */   public static void sendMessage(String message, Notification.Type type, String uniqueWord, int senderID, boolean notification) {
/*  40 */     if (notification) { sendClientDeleteMessage(message, type, uniqueWord, senderID); }
/*  41 */     else { sendDeleteMessage(message, uniqueWord, senderID); }
/*     */   
/*     */   }
/*     */   public static void sendClientDeleteMessage(String message, Notification.Type type, String uniqueWord, int senderID) {
/*  45 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  47 */     Notifications notifications = (Notifications)ModuleManager.getModule(Notifications.class);
/*  48 */     if (notifications.isEnabled()) {
/*  49 */       NotificationManager.add(new Notification(TextFormatting.GRAY + message, type));
/*  50 */       if (((Boolean)notifications.disableChat.getValue()).booleanValue())
/*     */         return; 
/*  52 */     }  ChatUtil.sendDeleteMessage(watermark + messageFormatting + message, uniqueWord, senderID);
/*     */   }
/*     */   
/*     */   public static void sendDeleteMessage(String message, String uniqueWord, int senderID) {
/*  56 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  58 */     ChatUtil.sendDeleteMessage(watermark + messageFormatting + message, uniqueWord, senderID);
/*     */   }
/*     */   public static void sendCommandMessage(String message, boolean prefix) {
/*  61 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  63 */     String watermark1 = prefix ? watermark : "";
/*  64 */     ChatUtil.sendDeleteMessage(watermark1 + messageFormatting + message, "Command", 6);
/*     */   }
/*     */   
/*     */   public static void sendMessage(String message, boolean prefix) {
/*  68 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  70 */     String watermark1 = prefix ? watermark : "";
/*  71 */     TextComponentString string = new TextComponentString(watermark1 + messageFormatting + message);
/*  72 */     mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)string, getIdFromString(message));
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getIdFromString(String name) {
/*  77 */     StringBuilder s = new StringBuilder();
/*     */     
/*  79 */     name = name.replace("禮", "e");
/*     */     
/*  81 */     String blacklist = "[^a-z]";
/*     */     
/*  83 */     for (int i = 0; i < name.length(); i++) {
/*  84 */       s.append(Integer.parseInt(String.valueOf(name.charAt(i)).replaceAll(blacklist, "e"), 36));
/*     */     }
/*     */     try {
/*  87 */       s = new StringBuilder(s.substring(0, 8));
/*  88 */     } catch (StringIndexOutOfBoundsException ignored) {
/*  89 */       s = new StringBuilder(2147483647);
/*     */     } 
/*     */     
/*  92 */     return Integer.MAX_VALUE - Integer.parseInt(s.toString().toLowerCase());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void sendClientRawMessage(String message) {
/*  97 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/*  99 */     TextComponentString string = new TextComponentString(messageFormatting + message);
/* 100 */     mc.player.sendMessage((ITextComponent)string);
/*     */   }
/*     */   
/*     */   public static void sendServerMessage(String message) {
/* 104 */     if (mc.world == null || mc.player == null)
/*     */       return; 
/* 106 */     mc.player.connection.sendPacket((Packet)new CPacketChatMessage(message));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\MessageBus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
