//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class Wrapper {
/*    */   public static EntityPlayerSP getPlayer() {
/*  9 */     EntityPlayerSP player = (Minecraft.getMinecraft()).player;
/* 10 */     return player;
/*    */   }
/*    */   public static Minecraft getMinecraft() {
/* 13 */     Minecraft minecraft = Minecraft.getMinecraft();
/* 14 */     return minecraft;
/*    */   }
/*    */   public static World getWorld() {
/* 17 */     return (World)(Minecraft.getMinecraft()).world;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\Wrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
