/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Arrays;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ public class IconUtil
/*    */ {
/* 12 */   public static final IconUtil INSTANCE = new IconUtil();
/*    */   
/*    */   public ByteBuffer readImageToBuffer(InputStream inputStream) throws IOException {
/* 15 */     BufferedImage bufferedimage = ImageIO.read(inputStream);
/* 16 */     int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), null, 0, bufferedimage.getWidth());
/* 17 */     ByteBuffer bytebuffer = ByteBuffer.allocate(4 * aint.length);
/* 18 */     Arrays.stream(aint).map(i -> i << 8 | i >> 24 & 0xFF).forEach(bytebuffer::putInt);
/* 19 */     bytebuffer.flip();
/* 20 */     return bytebuffer;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\IconUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */