/*   */ package com.lemonclient.api.util.misc;
/*   */ 
/*   */ public class EnumUtils
/*   */ {
/*   */   public static <T extends Enum<T>> T next(T value) {
/* 6 */     Enum[] arrayOfEnum = value.getDeclaringClass().getEnumConstants();
/* 7 */     return (T)arrayOfEnum[(value.ordinal() + 1) % arrayOfEnum.length];
/*   */   }
/*   */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\EnumUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */