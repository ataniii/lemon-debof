//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.misc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class MathUtil
/*     */ {
/*  15 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*  16 */   public static Random rnd = new Random();
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getRandom(int min, int max) {
/*  21 */     return rnd.nextInt(max - min + 1) + min;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList moveItemToFirst(ArrayList<?> list, int index) {
/*  26 */     ArrayList newlist = new ArrayList();
/*  27 */     newlist.add(list.get(index));
/*  28 */     for (int i = 0; i < list.size(); i++) {
/*     */ 
/*     */       
/*  31 */       if (i != index)
/*     */       {
/*  33 */         newlist.add(list.get(index)); } 
/*     */     } 
/*  35 */     return new ArrayList(list);
/*     */   }
/*     */   
/*     */   public static float[] calcAngle(Vec3d from, Vec3d to) {
/*  39 */     double difX = to.x - from.x;
/*  40 */     double difY = (to.y - from.y) * -1.0D;
/*  41 */     double difZ = to.z - from.z;
/*  42 */     double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
/*  43 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */   
/*     */   public static Vec2f calcAngleRotate(Vec3d from, Vec3d to) {
/*  47 */     double difX = to.x - from.x;
/*  48 */     double difY = (to.y - from.y) * -1.0D;
/*  49 */     double difZ = to.z - from.z;
/*  50 */     double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
/*  51 */     return new Vec2f((float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float square(float v1) {
/*  56 */     return v1 * v1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double square(Double v1) {
/*  61 */     return v1.doubleValue() * v1.doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double calculateDistanceWithPartialTicks(double n, double n2, float renderPartialTicks) {
/*  66 */     return n2 + (n - n2) * mc.getRenderPartialTicks();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d interpolateEntityClose(Entity entity, float renderPartialTicks) {
/*  71 */     return new Vec3d(
/*  72 */         calculateDistanceWithPartialTicks(entity.posX, entity.lastTickPosX, renderPartialTicks) - (mc.getRenderManager()).renderPosX, 
/*  73 */         calculateDistanceWithPartialTicks(entity.posY, entity.lastTickPosY, renderPartialTicks) - (mc.getRenderManager()).renderPosY, 
/*  74 */         calculateDistanceWithPartialTicks(entity.posZ, entity.lastTickPosZ, renderPartialTicks) - (mc.getRenderManager()).renderPosZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double radToDeg(double rad) {
/*  79 */     return rad * 57.295780181884766D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double degToRad(double deg) {
/*  84 */     return deg * 0.01745329238474369D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d direction(float yaw) {
/*  89 */     return new Vec3d(Math.cos(degToRad((yaw + 90.0F))), 0.0D, Math.sin(degToRad((yaw + 90.0F))));
/*     */   }
/*     */ 
/*     */   
/*     */   public static double round(double value, int places) {
/*  94 */     if (places < 0)
/*     */     {
/*  96 */       return value;
/*     */     }
/*  98 */     return (new BigDecimal(value)).setScale(places, RoundingMode.HALF_UP).doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float clamp(float val, float min, float max) {
/* 103 */     if (val <= min)
/*     */     {
/* 105 */       val = min;
/*     */     }
/* 107 */     if (val >= max)
/*     */     {
/* 109 */       val = max;
/*     */     }
/* 111 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float wrap(float val) {
/* 116 */     val %= 360.0F;
/* 117 */     if (val >= 180.0F)
/* 118 */       val -= 360.0F; 
/* 119 */     if (val < -180.0F)
/* 120 */       val += 360.0F; 
/* 121 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double map(double value, double a, double b, double c, double d) {
/* 128 */     value = (value - a) / (b - a);
/*     */     
/* 130 */     return c + value * (d - c);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double linear(double from, double to, double incline) {
/* 135 */     return (from < to - incline) ? (from + incline) : ((from > to + incline) ? (from - incline) : to);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double parabolic(double from, double to, double incline) {
/* 140 */     return from + (to - from) / incline;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getDistance(Vec3d pos, double x, double y, double z) {
/* 145 */     double deltaX = pos.x - x;
/* 146 */     double deltaY = pos.y - y;
/* 147 */     double deltaZ = pos.z - z;
/* 148 */     return MathHelper.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double[] calcIntersection(double[] line, double[] line2) {
/* 153 */     double a1 = line[3] - line[1];
/* 154 */     double b1 = line[0] - line[2];
/* 155 */     double c1 = a1 * line[0] + b1 * line[1];
/*     */     
/* 157 */     double a2 = line2[3] - line2[1];
/* 158 */     double b2 = line2[0] - line2[2];
/* 159 */     double c2 = a2 * line2[0] + b2 * line2[1];
/*     */     
/* 161 */     double delta = a1 * b2 - a2 * b1;
/*     */     
/* 163 */     return new double[] { (b2 * c1 - b1 * c2) / delta, (a1 * c2 - a2 * c1) / delta };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateAngle(double x1, double y1, double x2, double y2) {
/* 169 */     double angle = Math.toDegrees(Math.atan2(x2 - x1, y2 - y1));
/*     */     
/* 171 */     angle += Math.ceil(-angle / 360.0D) * 360.0D;
/*     */     
/* 173 */     return angle;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
