/*    */ package com.lemonclient.api.util.misc;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ public class MultiThreading {
/*    */   private static final ExecutorService SERVICE;
/*  8 */   private static final AtomicInteger threadCounter = new AtomicInteger(0); static {
/*  9 */     SERVICE = Executors.newCachedThreadPool(task -> new Thread(task, "Lemon Thread " + threadCounter.getAndIncrement()) {  }
/*    */       );
/*    */   } public static void runAsync(Runnable task) {
/* 12 */     SERVICE.execute(task);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\MultiThreading.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */