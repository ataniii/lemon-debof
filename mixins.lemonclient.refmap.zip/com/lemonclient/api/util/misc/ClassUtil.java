/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassUtil
/*    */ {
/*    */   public static ArrayList<Class<?>> findClassesInPath(String classPath) {
/* 16 */     ArrayList<Class<?>> foundClasses = new ArrayList<>();
/* 17 */     String resource = ClassUtil.class.getClassLoader().getResource(classPath.replace(".", "/")).getPath();
/*    */     
/* 19 */     if (resource.contains("!")) {
/*    */       
/*    */       try {
/* 22 */         ZipInputStream file = new ZipInputStream((new URL(resource.substring(0, resource.lastIndexOf('!')))).openStream());
/*    */         
/*    */         ZipEntry entry;
/* 25 */         while ((entry = file.getNextEntry()) != null) {
/* 26 */           String name = entry.getName();
/*    */           
/* 28 */           if (name.startsWith(classPath.replace(".", "/") + "/") && name.endsWith(".class")) {
/*    */             
/*    */             try {
/* 31 */               Class<?> clazz = Class.forName(name.substring(0, name.length() - 6).replace("/", "."));
/* 32 */               foundClasses.add(clazz);
/* 33 */             } catch (ClassNotFoundException e) {
/* 34 */               e.printStackTrace();
/*    */             } 
/*    */           }
/*    */         } 
/* 38 */       } catch (IOException e) {
/* 39 */         e.printStackTrace();
/*    */       } 
/*    */     } else {
/*    */       
/*    */       try {
/* 44 */         URL classPathURL = ClassUtil.class.getClassLoader().getResource(classPath.replace(".", "/"));
/*    */         
/* 46 */         if (classPathURL != null) {
/*    */           
/* 48 */           File file = new File(classPathURL.getFile());
/*    */           
/* 50 */           if (file.exists()) {
/* 51 */             String[] classNamesFound = file.list();
/*    */             
/* 53 */             if (classNamesFound != null)
/*    */             {
/* 55 */               for (String className : classNamesFound) {
/*    */                 
/* 57 */                 if (className.endsWith(".class")) {
/* 58 */                   foundClasses.add(Class.forName(classPath + "." + className.substring(0, className.length() - 6)));
/*    */                 }
/*    */               } 
/*    */             }
/*    */           } 
/*    */         } 
/* 64 */       } catch (Exception e) {
/* 65 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 69 */     foundClasses.sort(Comparator.comparing(Class::getName));
/* 70 */     return foundClasses;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\ClassUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */