//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.misc;
/*     */ 
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.misc.ShulkerBypass;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.block.material.MapColor;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.storage.MapData;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class MapPeek {
/*  27 */   private final Minecraft mc = Minecraft.getMinecraft();
/*  28 */   private List<List<String>> pages = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public static List<List<String>> getTextInBook(ItemStack item) {
/*  32 */     List<String> pages = new ArrayList<>();
/*  33 */     NBTTagCompound nbt = item.getTagCompound();
/*     */     
/*  35 */     if (nbt != null && nbt.hasKey("pages")) {
/*     */       
/*  37 */       NBTTagList nbt2 = nbt.getTagList("pages", 8);
/*     */       
/*  39 */       nbt2.forEach(b -> pages.add(((NBTTagString)b).getString()));
/*     */     } 
/*     */     
/*  42 */     List<List<String>> finalPages = new ArrayList<>();
/*     */     
/*  44 */     for (String s : pages) {
/*     */       
/*  46 */       String buffer = "";
/*  47 */       List<String> pageBuffer = new ArrayList<>();
/*  48 */       char[] chars = s.toCharArray();
/*     */       
/*  50 */       for (char c : chars) {
/*     */         
/*  52 */         if ((Minecraft.getMinecraft()).fontRenderer.getStringWidth(buffer) > 114 || buffer.endsWith("\n")) {
/*     */           
/*  54 */           pageBuffer.add(buffer.replace("\n", ""));
/*  55 */           buffer = "";
/*     */         } 
/*     */         
/*  58 */         buffer = buffer + c;
/*     */       } 
/*     */       
/*  61 */       pageBuffer.add(buffer);
/*  62 */       finalPages.add(pageBuffer);
/*     */     } 
/*     */     
/*  65 */     return finalPages;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(int mouseX, int mouseY, GuiContainer screen) {
/*     */     try {
/*  72 */       this.pages = null;
/*  73 */       Slot slot = screen.getSlotUnderMouse();
/*  74 */       if (slot == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  79 */       if (ModuleManager.isModuleEnabled("Peek") && ShulkerBypass.books)
/*     */       {
/*  81 */         drawBookToolTip(slot, mouseX, mouseY);
/*     */       }
/*     */       
/*  84 */       if (ModuleManager.isModuleEnabled("Peek") && ShulkerBypass.maps) {
/*     */         
/*  86 */         if (slot.getStack().getItem() != Items.FILLED_MAP) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/*  91 */         MapData data = Items.FILLED_MAP.getMapData(slot.getStack(), (World)this.mc.world);
/*  92 */         byte[] colors = ((MapData)Objects.requireNonNull((T)data)).colors;
/*     */         
/*  94 */         GL11.glPushMatrix();
/*  95 */         GL11.glScaled(0.5D, 0.5D, 0.5D);
/*  96 */         GL11.glTranslated(0.0D, 0.0D, 300.0D);
/*     */         
/*  98 */         int x = mouseX * 2 + 30;
/*  99 */         int y = mouseY * 2 - 164;
/*     */         
/* 101 */         renderTooltipBox(x - 12, y + 12, 128, 128);
/*     */         
/* 103 */         for (int b : colors) {
/*     */           
/* 105 */           if (b / 4 != 0)
/*     */           {
/* 107 */             GuiScreen.drawRect(x, y, x + 1, y + 1, MapColor.COLORS[(b & 0xFF) / 4].getMapColor(b & 0xFF & 0x3));
/*     */           }
/*     */           
/* 110 */           if (x - mouseX * 2 + 30 == 127) {
/*     */             
/* 112 */             x = mouseX * 2 + 30;
/* 113 */             y++;
/*     */           } else {
/*     */             
/* 116 */             x++;
/*     */           } 
/*     */         } 
/*     */         
/* 120 */         GL11.glScaled(2.0D, 2.0D, 2.0D);
/* 121 */         GL11.glPopMatrix();
/*     */       } 
/* 123 */     } catch (Exception e) {
/*     */       
/* 125 */       System.out.println("oopsie poopsie");
/* 126 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawBookToolTip(Slot slot, int mX, int mY) {
/* 132 */     if (slot.getStack().getItem() == Items.WRITABLE_BOOK || slot.getStack().getItem() == Items.WRITTEN_BOOK) {
/*     */       
/* 134 */       if (this.pages == null)
/*     */       {
/* 136 */         this.pages = getTextInBook(slot.getStack());
/*     */       }
/*     */       
/* 139 */       if (!this.pages.isEmpty()) {
/*     */         
/* 141 */         int lenght = this.mc.fontRenderer.getStringWidth("Page: 1/" + this.pages.size());
/*     */         
/* 143 */         renderTooltipBox(mX + 56 - lenght / 2, mY - ((List)this.pages.get(0)).size() * 10 - 19, 5, lenght);
/* 144 */         renderTooltipBox(mX, mY - ((List)this.pages.get(0)).size() * 10 - 6, ((List)this.pages.get(0)).size() * 10 - 2, 120);
/* 145 */         this.mc.fontRenderer.drawStringWithShadow("Page: 1/" + this.pages.size(), (mX + 68 - lenght / 2), (mY - ((List)this.pages.get(0)).size() * 10 - 32), -1);
/*     */         
/* 147 */         int count = 0;
/*     */         
/* 149 */         for (Iterator<String> pagesIter = ((List)this.pages.get(0)).iterator(); pagesIter.hasNext(); count++) {
/*     */           
/* 151 */           String s = pagesIter.next();
/* 152 */           this.mc.fontRenderer.drawStringWithShadow(s, (mX + 12), (mY - 18 - ((List)this.pages.get(0)).size() * 10 + count * 10), 49344);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderTooltipBox(int x1, int y1, int x2, int y2) {
/* 160 */     GlStateManager.disableRescaleNormal();
/*     */     
/* 162 */     RenderHelper.disableStandardItemLighting();
/*     */     
/* 164 */     GlStateManager.disableLighting();
/* 165 */     GlStateManager.disableDepth();
/* 166 */     GlStateManager.translate(0.0F, 0.0F, 300.0F);
/*     */     
/* 168 */     int int_5 = x1 + 12;
/* 169 */     int int_6 = y1 - 12;
/*     */     
/* 171 */     GuiScreen.drawRect(int_5 - 3, int_6 - 4, int_5 + y2 + 3, int_6 - 3, -267386864);
/* 172 */     GuiScreen.drawRect(int_5 - 3, int_6 + x2 + 3, int_5 + y2 + 3, int_6 + x2 + 4, -267386864);
/* 173 */     GuiScreen.drawRect(int_5 - 3, int_6 - 3, int_5 + y2 + 3, int_6 + x2 + 3, -267386864);
/* 174 */     GuiScreen.drawRect(int_5 - 4, int_6 - 3, int_5 - 3, int_6 + x2 + 3, -267386864);
/* 175 */     GuiScreen.drawRect(int_5 + y2 + 3, int_6 - 3, int_5 + y2 + 4, int_6 + x2 + 3, -267386864);
/* 176 */     GuiScreen.drawRect(int_5 - 3, int_6 - 3 + 1, int_5 - 3 + 1, int_6 + x2 + 3 - 1, 1347420415);
/* 177 */     GuiScreen.drawRect(int_5 + y2 + 2, int_6 - 3 + 1, int_5 + y2 + 3, int_6 + x2 + 3 - 1, 1347420415);
/* 178 */     GuiScreen.drawRect(int_5 - 3, int_6 - 3, int_5 + y2 + 3, int_6 - 3 + 1, 1347420415);
/* 179 */     GuiScreen.drawRect(int_5 - 3, int_6 + x2 + 2, int_5 + y2 + 3, int_6 + x2 + 3, 1344798847);
/*     */     
/* 181 */     GlStateManager.enableLighting();
/* 182 */     GlStateManager.enableDepth();
/* 183 */     RenderHelper.enableStandardItemLighting();
/* 184 */     GlStateManager.enableRescaleNormal();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\MapPeek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
