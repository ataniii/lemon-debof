/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import java.util.function.ToIntFunction;
/*    */ 
/*    */ public class CollectionUtils
/*    */ {
/*    */   public static <T> T maxOrNull(Iterable<T> iterable, ToIntFunction<T> block) {
/*  8 */     int value = Integer.MIN_VALUE;
/*  9 */     T maxElement = null;
/*    */     
/* 11 */     for (T element : iterable) {
/* 12 */       int newValue = block.applyAsInt(element);
/*    */       
/* 14 */       if (newValue > value) {
/* 15 */         value = newValue;
/* 16 */         maxElement = element;
/*    */       } 
/*    */     } 
/*    */     
/* 20 */     return maxElement;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\CollectionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */