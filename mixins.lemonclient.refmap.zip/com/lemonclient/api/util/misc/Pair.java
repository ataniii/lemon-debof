/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ public class Pair<T, S>
/*    */ {
/*    */   T key;
/*    */   S value;
/*    */   
/*    */   public Pair(T key, S value) {
/*  9 */     this.key = key;
/* 10 */     this.value = value;
/*    */   }
/*    */   
/*    */   public T getKey() {
/* 14 */     return this.key;
/*    */   }
/*    */   
/*    */   public S getValue() {
/* 18 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setKey(T key) {
/* 22 */     this.key = key;
/*    */   }
/*    */   
/*    */   public void setValue(S value) {
/* 26 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */