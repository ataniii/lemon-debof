/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Timer
/*    */ {
/*  8 */   private long current = System.currentTimeMillis();
/*    */ 
/*    */   
/*    */   public boolean hasReached(long delay) {
/* 12 */     return (System.currentTimeMillis() - this.current >= delay);
/*    */   }
/*    */   
/*    */   public boolean hasReached(long delay, boolean reset) {
/* 16 */     if (reset)
/* 17 */       reset(); 
/* 18 */     return (System.currentTimeMillis() - this.current >= delay);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 22 */     this.current = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public long getTimePassed() {
/* 26 */     return System.currentTimeMillis() - this.current;
/*    */   }
/*    */   
/*    */   public boolean sleep(long time) {
/* 30 */     if (time() >= time) {
/* 31 */       reset();
/* 32 */       return true;
/*    */     } 
/* 34 */     return false;
/*    */   }
/*    */   public void setTimer(long time) {
/* 37 */     this.current = time;
/*    */   }
/*    */   public long time() {
/* 40 */     return System.currentTimeMillis() - this.current;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\Timer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */