//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.misc;
/*     */ import com.lemonclient.api.util.player.PlayerUtil;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class CrystalUtil {
/*  24 */   public static Minecraft mc = Minecraft.getMinecraft();
/*     */   public static void placeCrystal(BlockPos pos, boolean rotate) {
/*  26 */     boolean offhand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL);
/*  27 */     BlockPos obsPos = pos.down();
/*  28 */     RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX() + 0.5D, pos.getY() - 0.5D, pos.getZ() + 0.5D));
/*  29 */     EnumFacing facing = (result == null || result.sideHit == null) ? EnumFacing.UP : result.sideHit;
/*  30 */     EnumFacing opposite = facing.getOpposite();
/*  31 */     Vec3d vec = (new Vec3d((Vec3i)obsPos)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(opposite.getDirectionVec()));
/*  32 */     if (rotate) {
/*  33 */       BlockUtil.faceVector(vec);
/*     */     }
/*  35 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(obsPos, facing, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/*  36 */     mc.player.swingArm(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*     */   }
/*     */   public static boolean placeCrystal(BlockPos pos, EnumHand hand, boolean packet, boolean rotate, boolean swing) {
/*  39 */     EnumFacing facing = EnumFacing.UP;
/*  40 */     EnumFacing opposite = facing.getOpposite();
/*  41 */     Vec3d vec = (new Vec3d((Vec3i)pos)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(opposite.getDirectionVec()));
/*  42 */     if (rotate) {
/*  43 */       BlockUtil.faceVector(vec);
/*     */     }
/*  45 */     if (packet) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F)); }
/*  46 */     else { mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, vec, hand); }
/*  47 */      if (swing) mc.player.swingArm(hand); 
/*  48 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isNull(RayTraceResult result, Entity entity) {
/*  52 */     return (result == null || result.sideHit == null || result.entityHit == entity);
/*     */   }
/*     */   
/*     */   public static boolean calculateRaytrace(Entity entity) {
/*  56 */     if (entity == null) return true; 
/*  57 */     Vec3d vec = PlayerUtil.getEyeVec();
/*  58 */     Vec3d vec3d = entity.getPositionVector();
/*  59 */     RayTraceResult result = mc.world.rayTraceBlocks(vec, vec3d);
/*  60 */     if (isNull(result, entity)) return true; 
/*  61 */     double x = entity.boundingBox.maxX - entity.boundingBox.minX;
/*  62 */     double y = entity.boundingBox.maxY - entity.boundingBox.minY;
/*  63 */     double z = entity.boundingBox.maxZ - entity.boundingBox.minZ; double addX;
/*  64 */     for (addX = -x; addX <= x; addX += x) {
/*  65 */       double addY; for (addY = 0.0D; addY <= y; addY += y) {
/*  66 */         double addZ; for (addZ = -z; addZ <= z; addZ += z) {
/*  67 */           result = mc.world.rayTraceBlocks(vec, vec3d.add(addX, addY, addZ));
/*  68 */           if (isNull(result, entity)) return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isNull(RayTraceResult result, BlockPos pos) {
/*  76 */     if (result == null || result.getBlockPos() == pos) return true; 
/*  77 */     if (result.typeOfHit == RayTraceResult.Type.ENTITY) {
/*  78 */       double distance = mc.player.getDistance(result.entityHit);
/*  79 */       return (distance <= PlayerUtil.getDistanceI(pos));
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean calculateRaytrace(BlockPos pos) {
/*  85 */     Vec3d vec = PlayerUtil.getEyeVec();
/*  86 */     Vec3d vec3d = new Vec3d((Vec3i)pos);
/*  87 */     RayTraceResult result = mc.world.rayTraceBlocks(vec, vec3d);
/*  88 */     if (isNull(result, pos)) return true; 
/*  89 */     double x = 0.5D, y = 0.5D, z = 0.5D; double addX;
/*  90 */     for (addX = 0.0D; addX <= 1.0D; addX += x) {
/*  91 */       double addY; for (addY = 0.0D; addY <= 1.0D; addY += y) {
/*  92 */         double addZ; for (addZ = 0.0D; addZ <= 1.0D; addZ += z) {
/*  93 */           result = mc.world.rayTraceBlocks(vec, vec3d.add(addX, addY, addZ));
/*  94 */           if (isNull(result, pos)) return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean calculateRaytrace(EntityPlayer player, BlockPos pos) {
/* 102 */     Vec3d vec = new Vec3d(player.posX, player.posY + player.getEyeHeight(), player.posZ);
/* 103 */     Vec3d vec3d = new Vec3d((Vec3i)pos);
/* 104 */     RayTraceResult result = mc.world.rayTraceBlocks(vec, vec3d);
/* 105 */     if (isNull(result, pos)) return true; 
/* 106 */     double x = 0.5D, y = 0.5D, z = 0.5D; double addX;
/* 107 */     for (addX = 0.0D; addX <= 1.0D; addX += x) {
/* 108 */       double addY; for (addY = 0.0D; addY <= 1.0D; addY += y) {
/* 109 */         double addZ; for (addZ = 0.0D; addZ <= 1.0D; addZ += z) {
/* 110 */           result = mc.world.rayTraceBlocks(vec, vec3d.add(addX, addY, addZ));
/* 111 */           if (isNull(result, pos)) return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     return false;
/*     */   }
/*     */   
/* 118 */   private static final List<Block> valid = Arrays.asList(new Block[] { Blocks.OBSIDIAN, Blocks.BEDROCK, Blocks.ENDER_CHEST, Blocks.ANVIL });
/*     */   
/*     */   public static RayTraceResult rayTraceBlocks(Vec3d start, Vec3d end) {
/* 121 */     return rayTraceBlocks(start, end, false, false, false);
/*     */   }
/*     */   
/*     */   public static RayTraceResult rayTraceBlocks(Vec3d vec31, Vec3d vec32, boolean stopOnLiquid, boolean ignoreBlockWithoutBoundingBox, boolean returnLastUnCollidableBlock) {
/* 125 */     if (!Double.isNaN(vec31.x) && !Double.isNaN(vec31.y) && !Double.isNaN(vec31.z)) {
/* 126 */       if (!Double.isNaN(vec32.x) && !Double.isNaN(vec32.y) && !Double.isNaN(vec32.z)) {
/*     */ 
/*     */         
/* 129 */         int i = MathHelper.floor(vec32.x);
/* 130 */         int j = MathHelper.floor(vec32.y);
/* 131 */         int k = MathHelper.floor(vec32.z);
/* 132 */         int l = MathHelper.floor(vec31.x); int i1, j1;
/* 133 */         BlockPos blockpos = new BlockPos(l, i1 = MathHelper.floor(vec31.y), j1 = MathHelper.floor(vec31.z));
/* 134 */         IBlockState iblockstate = mc.world.getBlockState(blockpos);
/* 135 */         Block block = iblockstate.getBlock();
/* 136 */         if (!valid.contains(block)) {
/* 137 */           block = Blocks.AIR;
/* 138 */           iblockstate = Blocks.AIR.getBlockState().getBaseState();
/*     */         } 
/* 140 */         if ((!ignoreBlockWithoutBoundingBox || iblockstate.getCollisionBoundingBox((IBlockAccess)mc.world, blockpos) != Block.NULL_AABB) && block.canCollideCheck(iblockstate, stopOnLiquid)) {
/* 141 */           return iblockstate.collisionRayTrace((World)mc.world, blockpos, vec31, vec32);
/*     */         }
/* 143 */         RayTraceResult raytraceresult2 = null;
/* 144 */         int k1 = 200;
/* 145 */         while (k1-- >= 0) {
/*     */           EnumFacing enumfacing;
/* 147 */           if (Double.isNaN(vec31.x) || Double.isNaN(vec31.y) || Double.isNaN(vec31.z)) {
/* 148 */             return null;
/*     */           }
/* 150 */           if (l == i && i1 == j && j1 == k) {
/* 151 */             return returnLastUnCollidableBlock ? raytraceresult2 : null;
/*     */           }
/* 153 */           boolean flag2 = true;
/* 154 */           boolean flag = true;
/* 155 */           boolean flag1 = true;
/* 156 */           double d0 = 999.0D;
/* 157 */           double d1 = 999.0D;
/* 158 */           double d2 = 999.0D;
/* 159 */           if (i > l) {
/* 160 */             d0 = l + 1.0D;
/* 161 */           } else if (i < l) {
/* 162 */             d0 = l + 0.0D;
/*     */           } else {
/* 164 */             flag2 = false;
/*     */           } 
/* 166 */           if (j > i1) {
/* 167 */             d1 = i1 + 1.0D;
/* 168 */           } else if (j < i1) {
/* 169 */             d1 = i1 + 0.0D;
/*     */           } else {
/* 171 */             flag = false;
/*     */           } 
/* 173 */           if (k > j1) {
/* 174 */             d2 = j1 + 1.0D;
/* 175 */           } else if (k < j1) {
/* 176 */             d2 = j1 + 0.0D;
/*     */           } else {
/* 178 */             flag1 = false;
/*     */           } 
/* 180 */           double d3 = 999.0D;
/* 181 */           double d4 = 999.0D;
/* 182 */           double d5 = 999.0D;
/* 183 */           double d6 = vec32.x - vec31.x;
/* 184 */           double d7 = vec32.y - vec31.y;
/* 185 */           double d8 = vec32.z - vec31.z;
/* 186 */           if (flag2) {
/* 187 */             d3 = (d0 - vec31.x) / d6;
/*     */           }
/* 189 */           if (flag) {
/* 190 */             d4 = (d1 - vec31.y) / d7;
/*     */           }
/* 192 */           if (flag1) {
/* 193 */             d5 = (d2 - vec31.z) / d8;
/*     */           }
/* 195 */           if (d3 == -0.0D) {
/* 196 */             d3 = -1.0E-4D;
/*     */           }
/* 198 */           if (d4 == -0.0D) {
/* 199 */             d4 = -1.0E-4D;
/*     */           }
/* 201 */           if (d5 == -0.0D) {
/* 202 */             d5 = -1.0E-4D;
/*     */           }
/* 204 */           if (d3 < d4 && d3 < d5) {
/* 205 */             enumfacing = (i > l) ? EnumFacing.WEST : EnumFacing.EAST;
/* 206 */             vec31 = new Vec3d(d0, vec31.y + d7 * d3, vec31.z + d8 * d3);
/* 207 */           } else if (d4 < d5) {
/* 208 */             enumfacing = (j > i1) ? EnumFacing.DOWN : EnumFacing.UP;
/* 209 */             vec31 = new Vec3d(vec31.x + d6 * d4, d1, vec31.z + d8 * d4);
/*     */           } else {
/* 211 */             enumfacing = (k > j1) ? EnumFacing.NORTH : EnumFacing.SOUTH;
/* 212 */             vec31 = new Vec3d(vec31.x + d6 * d5, vec31.y + d7 * d5, d2);
/*     */           } 
/* 214 */           l = MathHelper.floor(vec31.x) - ((enumfacing == EnumFacing.EAST) ? 1 : 0);
/* 215 */           i1 = MathHelper.floor(vec31.y) - ((enumfacing == EnumFacing.UP) ? 1 : 0);
/* 216 */           j1 = MathHelper.floor(vec31.z) - ((enumfacing == EnumFacing.SOUTH) ? 1 : 0);
/* 217 */           blockpos = new BlockPos(l, i1, j1);
/* 218 */           IBlockState iblockstate1 = mc.world.getBlockState(blockpos);
/* 219 */           Block block1 = iblockstate1.getBlock();
/* 220 */           if (!valid.contains(block1)) {
/* 221 */             block1 = Blocks.AIR;
/* 222 */             iblockstate1 = Blocks.AIR.getBlockState().getBaseState();
/*     */           } 
/* 224 */           if (ignoreBlockWithoutBoundingBox && iblockstate1.getMaterial() != Material.PORTAL && iblockstate1.getCollisionBoundingBox((IBlockAccess)mc.world, blockpos) == Block.NULL_AABB)
/* 225 */             continue;  if (block1.canCollideCheck(iblockstate1, stopOnLiquid)) {
/* 226 */             return iblockstate1.collisionRayTrace((World)mc.world, blockpos, vec31, vec32);
/*     */           }
/* 228 */           raytraceresult2 = new RayTraceResult(RayTraceResult.Type.MISS, vec31, enumfacing, blockpos);
/*     */         } 
/* 230 */         return returnLastUnCollidableBlock ? raytraceresult2 : null;
/*     */       } 
/* 232 */       return null;
/*     */     } 
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos pos) {
/* 238 */     return (BlockUtil.getBlock(pos.add(0, 1, 0)) == Blocks.AIR && 
/* 239 */       BlockUtil.getBlock(pos.add(0, 2, 0)) == Blocks.AIR);
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos pos, float r, int h, boolean hollow, boolean sphere, int plus_y) {
/* 243 */     ArrayList<BlockPos> circleBlocks = new ArrayList<>();
/* 244 */     int cx = pos.getX();
/* 245 */     int cy = pos.getY();
/* 246 */     int cz = pos.getZ();
/* 247 */     int x = cx - (int)r;
/* 248 */     while (x <= cx + r) {
/* 249 */       int z = cz - (int)r;
/* 250 */       while (z <= cz + r) {
/* 251 */         int y = sphere ? (cy - (int)r) : cy;
/*     */         while (true) {
/* 253 */           float f = y;
/* 254 */           float f2 = sphere ? (cy + r) : (cy + h);
/* 255 */           if (f >= f2)
/* 256 */             break;  double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/* 257 */           if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 258 */             BlockPos l = new BlockPos(x, y + plus_y, z);
/* 259 */             circleBlocks.add(l);
/*     */           } 
/* 261 */           y++;
/*     */         } 
/* 263 */         z++;
/*     */       } 
/* 265 */       x++;
/*     */     } 
/* 267 */     return circleBlocks;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos blockPos, boolean specialEntityCheck, boolean onepointThirteen) {
/* 271 */     BlockPos boost = blockPos.add(0, 1, 0);
/* 272 */     BlockPos boost2 = blockPos.add(0, 2, 0);
/*     */     try {
/* 274 */       if (!onepointThirteen) {
/* 275 */         if (mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN) {
/* 276 */           return false;
/*     */         }
/* 278 */         if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR || mc.world.getBlockState(boost2).getBlock() != Blocks.AIR) {
/* 279 */           return false;
/*     */         }
/* 281 */         if (!specialEntityCheck) {
/* 282 */           return (mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/*     */         }
/* 284 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost))) {
/* 285 */           if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 286 */             continue;  return false;
/*     */         } 
/* 288 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2))) {
/* 289 */           if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 290 */             continue;  return false;
/*     */         } 
/*     */       } else {
/* 293 */         if (mc.world.getBlockState(blockPos).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN) {
/* 294 */           return false;
/*     */         }
/* 296 */         if (mc.world.getBlockState(boost).getBlock() != Blocks.AIR) {
/* 297 */           return false;
/*     */         }
/* 299 */         if (!specialEntityCheck) {
/* 300 */           return mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty();
/*     */         }
/* 302 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost))) {
/* 303 */           if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 304 */             continue;  return false;
/*     */         } 
/*     */       } 
/* 307 */     } catch (Exception e) {
/* 308 */       e.printStackTrace();
/* 309 */       return false;
/*     */     } 
/* 311 */     return true;
/*     */   }
/*     */   
/*     */   public static void breakCrystal(BlockPos pos, boolean swing) {
/* 315 */     if (pos == null)
/* 316 */       return;  for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 317 */       if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 318 */         continue;  breakCrystal(entity, swing);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void breakCrystalPacket(BlockPos pos, boolean swing) {
/* 324 */     if (pos == null)
/* 325 */       return;  for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 326 */       if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 327 */         continue;  breakCrystalPacket(entity, swing);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void breakCrystal(Entity crystal, boolean swing) {
/* 333 */     mc.playerController.attackEntity((EntityPlayer)mc.player, crystal);
/* 334 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */   }
/*     */   
/*     */   public static void breakCrystalPacket(Entity crystal, boolean swing) {
/* 338 */     mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
/* 339 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\CrystalUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
