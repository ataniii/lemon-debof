/*     */ package com.lemonclient.api.util.misc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionUtil
/*     */ {
/*     */   public static void addToClassPath(URLClassLoader classLoader, File file) throws Exception {
/*  16 */     URL url = file.toURI().toURL();
/*  17 */     addToClassPath(classLoader, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addToClassPath(URLClassLoader classLoader, URL url) throws Exception {
/*  24 */     Method method = URLClassLoader.class.getDeclaredMethod("addURL", new Class[] { URL.class });
/*  25 */     method.setAccessible(true);
/*  26 */     method.invoke(classLoader, new Object[] { url });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void iterateSuperClasses(Class<?> clazz, Consumer<Class<?>> consumer) {
/*  32 */     while (clazz != Object.class) {
/*     */       
/*  34 */       consumer.accept(clazz);
/*  35 */       clazz = clazz.getSuperclass();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getField(Class<?> clazz, Object instance, int index) {
/*     */     try {
/*  44 */       Field field = clazz.getDeclaredFields()[index];
/*  45 */       field.setAccessible(true);
/*  46 */       return (T)field.get(instance);
/*     */     }
/*  48 */     catch (Exception e) {
/*     */       
/*  50 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setField(Class<?> clazz, Object instance, int index, Object value) {
/*     */     try {
/*  61 */       Field field = clazz.getDeclaredFields()[index];
/*  62 */       field.setAccessible(true);
/*  63 */       field.set(instance, value);
/*     */     }
/*  65 */     catch (Exception e) {
/*     */       
/*  67 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Field getField(Class<?> clazz, String... mappings) throws NoSuchFieldException {
/*  74 */     for (String s : mappings) {
/*     */ 
/*     */       
/*     */       try {
/*  78 */         return clazz.getDeclaredField(s);
/*     */       }
/*  80 */       catch (NoSuchFieldException noSuchFieldException) {}
/*     */     } 
/*     */     
/*  83 */     throw new NoSuchFieldException("No Such field: " + clazz.getName() + "-> " + 
/*  84 */         Arrays.toString(mappings));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethodNoParameters(Class<?> clazz, String... mappings) {
/*  90 */     for (String s : mappings) {
/*     */ 
/*     */       
/*     */       try {
/*  94 */         return clazz.getDeclaredMethod(s, new Class[0]);
/*     */       }
/*  96 */       catch (NoSuchMethodException noSuchMethodException) {}
/*     */     } 
/*     */     
/*  99 */     throw new RuntimeException("Couldn't find: " + 
/* 100 */         Arrays.toString(mappings));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethod(Class<?> clazz, String notch, String searge, String mcp, Class<?>... parameterTypes) {
/*     */     try {
/* 111 */       return clazz.getMethod(searge, parameterTypes);
/*     */     }
/* 113 */     catch (NoSuchMethodException e) {
/*     */ 
/*     */       
/*     */       try {
/* 117 */         return clazz.getMethod(notch, parameterTypes);
/*     */       }
/* 119 */       catch (NoSuchMethodException ex) {
/*     */ 
/*     */         
/*     */         try {
/* 123 */           return clazz.getMethod(mcp, parameterTypes);
/*     */         }
/* 125 */         catch (NoSuchMethodException exc) {
/*     */           
/* 127 */           throw new RuntimeException(exc);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getSimpleName(String name) {
/* 135 */     return name.substring(name.lastIndexOf(".") + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\ReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */