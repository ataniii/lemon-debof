/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyBoardClass
/*    */ {
/*    */   public static int getKeyFromChar(char character) {
/*  8 */     character = Character.toUpperCase(character);
/*  9 */     switch (character) {
/*    */       case 'A':
/* 11 */         return 30;
/*    */       case 'B':
/* 13 */         return 48;
/*    */       case 'C':
/* 15 */         return 46;
/*    */       case 'D':
/* 17 */         return 32;
/*    */       case 'E':
/* 19 */         return 18;
/*    */       case 'F':
/* 21 */         return 33;
/*    */       case 'G':
/* 23 */         return 34;
/*    */       case 'H':
/* 25 */         return 35;
/*    */       case 'I':
/* 27 */         return 23;
/*    */       case 'L':
/* 29 */         return 38;
/*    */       case 'M':
/* 31 */         return 50;
/*    */       case 'N':
/* 33 */         return 49;
/*    */       case 'O':
/* 35 */         return 24;
/*    */       case 'P':
/* 37 */         return 25;
/*    */       case 'Q':
/* 39 */         return 16;
/*    */       case 'R':
/* 41 */         return 19;
/*    */       case 'S':
/* 43 */         return 31;
/*    */       case 'T':
/* 45 */         return 20;
/*    */       case 'U':
/* 47 */         return 22;
/*    */       case 'V':
/* 49 */         return 47;
/*    */       case 'W':
/* 51 */         return 17;
/*    */       case 'X':
/* 53 */         return 45;
/*    */       case 'Y':
/* 55 */         return 21;
/*    */       case 'Z':
/* 57 */         return 44;
/*    */       case '0':
/* 59 */         return 11;
/*    */       case '1':
/* 61 */         return 2;
/*    */       case '2':
/* 63 */         return 3;
/*    */       case '3':
/* 65 */         return 4;
/*    */       case '4':
/* 67 */         return 5;
/*    */       case '5':
/* 69 */         return 6;
/*    */       case '6':
/* 71 */         return 7;
/*    */       case '7':
/* 73 */         return 8;
/*    */       case '8':
/* 75 */         return 9;
/*    */       case '9':
/* 77 */         return 10;
/*    */       case '.':
/* 79 */         return 51;
/*    */       case ',':
/* 81 */         return 146;
/*    */       case '\\':
/* 83 */         return 43;
/*    */       case '\'':
/* 85 */         return 40;
/*    */       case '-':
/* 87 */         return 12;
/*    */     } 
/* 89 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\KeyBoardClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */