/*    */ package com.lemonclient.api.util.misc;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipOutputStream;
/*    */ 
/*    */ public final class ZipUtils {
/*    */   public static void zip(File source, File dest) {
/* 12 */     List<String> list = new ArrayList<>();
/* 13 */     createFileList(source, source, list);
/*    */     try {
/* 15 */       ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(dest));
/* 16 */       for (String file : list) {
/* 17 */         ZipEntry ze = new ZipEntry(file);
/* 18 */         FileInputStream in = new FileInputStream(file);
/* 19 */         byte[] buffer = new byte[1024];
/* 20 */         zos.putNextEntry(ze);
/*    */         while (true) {
/* 22 */           int len = in.read(buffer);
/* 23 */           if (len <= 0)
/* 24 */             break;  zos.write(buffer, 0, len);
/*    */         } 
/* 26 */         in.close();
/* 27 */         zos.closeEntry();
/*    */       } 
/* 29 */       zos.close();
/* 30 */     } catch (FileNotFoundException e) {
/* 31 */       e.printStackTrace();
/* 32 */     } catch (IOException e) {
/* 33 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void createFileList(File file, File source, List<String> list) {
/* 38 */     if (file.isFile()) {
/* 39 */       list.add(file.getPath());
/* 40 */     } else if (file.isDirectory()) {
/* 41 */       for (String subfile : file.list())
/* 42 */         createFileList(new File(file, subfile), source, list); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\ZipUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */