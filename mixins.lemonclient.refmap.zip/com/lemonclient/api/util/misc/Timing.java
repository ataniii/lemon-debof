/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ public class Timing {
/*  4 */   private long time = -1L;
/*    */   
/*    */   public boolean passedS(double s) {
/*  7 */     return passedMs((long)s * 1000L);
/*    */   }
/*    */   
/*    */   public boolean passedDms(double dms) {
/* 11 */     return passedMs((long)dms * 10L);
/*    */   }
/*    */   
/*    */   public boolean passedDs(double ds) {
/* 15 */     return passedMs((long)ds * 100L);
/*    */   }
/*    */   
/*    */   public boolean passedMs(long ms) {
/* 19 */     return passedNS(convertToNS(ms));
/*    */   }
/*    */   
/*    */   public boolean passedNS(long ns) {
/* 23 */     return (System.nanoTime() - this.time >= ns);
/*    */   }
/*    */   
/*    */   public boolean passedX(double dms) {
/* 27 */     return (getMs(System.nanoTime() - this.time) >= (long)(dms * 3.0D));
/*    */   }
/*    */   
/*    */   public long getPassedTimeMs() {
/* 31 */     return getMs(System.nanoTime() - this.time);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 35 */     this.time = System.nanoTime();
/*    */   }
/*    */   
/*    */   public void set() {
/* 39 */     this.time = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void setMs(long ms) {
/* 43 */     this.time = System.nanoTime() - convertToNS(ms);
/*    */   }
/*    */   
/*    */   public long getTime() {
/* 47 */     return System.nanoTime() - this.time;
/*    */   }
/*    */   public void setTime(long set) {
/* 50 */     this.time = System.nanoTime() - set;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getMs(long time) {
/* 55 */     return time / 1000000L;
/*    */   }
/*    */   
/*    */   public long convertToNS(long time) {
/* 59 */     return time * 1000000L;
/*    */   }
/*    */   
/*    */   public boolean passedTick(double tick) {
/* 63 */     return passedMs((long)tick * 50L);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\Timing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */