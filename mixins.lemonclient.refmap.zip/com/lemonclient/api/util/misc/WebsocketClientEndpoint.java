/*    */ package com.lemonclient.api.util.misc;
/*    */ import java.net.URI;
/*    */ import shaded.websocket.ClientEndpoint;
/*    */ import shaded.websocket.RemoteEndpoint;
/*    */ import shaded.websocket.Session;
/*    */ import shaded.websocket.WebSocketContainer;
/*    */ 
/*    */ @ClientEndpoint
/*    */ public class WebsocketClientEndpoint {
/* 10 */   Session userSession = null;
/*    */   private MessageHandler messageHandler;
/*    */   
/*    */   public int getUserSession() {
/* 14 */     return (this.userSession == null) ? 0 : 1;
/*    */   }
/*    */   public void close() {
/*    */     try {
/* 18 */       if (this.userSession != null)
/* 19 */         this.userSession.close(); 
/* 20 */     } catch (IOException|NullPointerException iOException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebsocketClientEndpoint(URI endpointURI) {
/*    */     try {
/* 28 */       Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/* 29 */       WebSocketContainer container = ContainerProvider.getWebSocketContainer();
/* 30 */       this.userSession = container.connectToServer(this, endpointURI);
/* 31 */     } catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */   
/*    */   @OnOpen
/*    */   public void onOpen(Session userSession) {
/* 37 */     System.out.println("opening websocket");
/* 38 */     this.userSession = userSession;
/*    */   }
/*    */   
/*    */   @OnClose
/*    */   public void onClose(Session userSession, CloseReason reason) {
/* 43 */     System.out.println("closing websocket");
/* 44 */     this.userSession = null;
/*    */   }
/*    */   
/*    */   @OnMessage
/*    */   public void onMessage(String message) {
/* 49 */     if (this.messageHandler != null) {
/* 50 */       this.messageHandler.handleMessage(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMessageHandler(MessageHandler msgHandler) {
/* 55 */     this.messageHandler = msgHandler;
/*    */   }
/*    */   
/*    */   public void sendMessage(String message) {
/* 59 */     RemoteEndpoint.Async remoteEndpoint = this.userSession.getAsyncRemote();
/* 60 */     remoteEndpoint.sendText(message);
/*    */   }
/*    */   
/*    */   public static interface MessageHandler {
/*    */     void handleMessage(String param1String);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\WebsocketClientEndpoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */