//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mapping
/*    */ {
/*    */   public static boolean isObfuscated() {
/*    */     try {
/* 29 */       return (Minecraft.class.getDeclaredField("instance") == null);
/*    */     }
/* 31 */     catch (Exception e) {
/* 32 */       return true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 37 */   public static final String tickLength = isObfuscated() ? "tickLength" : "tickLength";
/* 38 */   public static final String timer = isObfuscated() ? "timer" : "timer";
/* 39 */   public static final String placedBlockDirection = isObfuscated() ? "placedBlockDirection" : "placedBlockDirection";
/* 40 */   public static final String playerPosLookYaw = isObfuscated() ? "yaw" : "yaw";
/* 41 */   public static final String playerPosLookPitch = isObfuscated() ? "pitch" : "pitch";
/* 42 */   public static final String isInWeb = isObfuscated() ? "isInWeb" : "isInWeb";
/* 43 */   public static final String cPacketPlayerYaw = isObfuscated() ? "yaw" : "yaw";
/* 44 */   public static final String cPacketPlayerPitch = isObfuscated() ? "pitch" : "pitch";
/* 45 */   public static final String renderManagerRenderPosX = isObfuscated() ? "renderPosX" : "renderPosX";
/* 46 */   public static final String renderManagerRenderPosY = isObfuscated() ? "renderPosY" : "renderPosY";
/* 47 */   public static final String renderManagerRenderPosZ = isObfuscated() ? "renderPosZ" : "renderPosZ";
/* 48 */   public static final String rightClickDelayTimer = isObfuscated() ? "rightClickDelayTimer" : "rightClickDelayTimer";
/* 49 */   public static final String sPacketEntityVelocityMotionX = isObfuscated() ? "motionX" : "motionX";
/* 50 */   public static final String sPacketEntityVelocityMotionY = isObfuscated() ? "motionY" : "motionY";
/* 51 */   public static final String sPacketEntityVelocityMotionZ = isObfuscated() ? "motionZ" : "motionZ";
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\Mapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
