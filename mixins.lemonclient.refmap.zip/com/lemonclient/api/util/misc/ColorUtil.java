/*     */ package com.lemonclient.api.util.misc;
/*     */ 
/*     */ import com.lemonclient.api.setting.values.ModeSetting;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.awt.Color;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ 
/*     */ public class ColorUtil
/*     */ {
/*  13 */   public static List<String> colors = Arrays.asList(new String[] { "Black", "Dark Green", "Dark Red", "Gold", "Dark Gray", "Green", "Red", "Yellow", "Dark Blue", "Dark Aqua", "Dark Purple", "Gray", "Blue", "Aqua", "Light Purple", "White" });
/*     */   
/*     */   public static TextFormatting settingToTextFormatting(ModeSetting setting) {
/*  16 */     if (((String)setting.getValue()).equalsIgnoreCase("Black")) {
/*  17 */       return TextFormatting.BLACK;
/*     */     }
/*  19 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Green")) {
/*  20 */       return TextFormatting.DARK_GREEN;
/*     */     }
/*  22 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Red")) {
/*  23 */       return TextFormatting.DARK_RED;
/*     */     }
/*  25 */     if (((String)setting.getValue()).equalsIgnoreCase("Gold")) {
/*  26 */       return TextFormatting.GOLD;
/*     */     }
/*  28 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Gray")) {
/*  29 */       return TextFormatting.DARK_GRAY;
/*     */     }
/*  31 */     if (((String)setting.getValue()).equalsIgnoreCase("Green")) {
/*  32 */       return TextFormatting.GREEN;
/*     */     }
/*  34 */     if (((String)setting.getValue()).equalsIgnoreCase("Red")) {
/*  35 */       return TextFormatting.RED;
/*     */     }
/*  37 */     if (((String)setting.getValue()).equalsIgnoreCase("Yellow")) {
/*  38 */       return TextFormatting.YELLOW;
/*     */     }
/*  40 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Blue")) {
/*  41 */       return TextFormatting.DARK_BLUE;
/*     */     }
/*  43 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Aqua")) {
/*  44 */       return TextFormatting.DARK_AQUA;
/*     */     }
/*  46 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Purple")) {
/*  47 */       return TextFormatting.DARK_PURPLE;
/*     */     }
/*  49 */     if (((String)setting.getValue()).equalsIgnoreCase("Gray")) {
/*  50 */       return TextFormatting.GRAY;
/*     */     }
/*  52 */     if (((String)setting.getValue()).equalsIgnoreCase("Blue")) {
/*  53 */       return TextFormatting.BLUE;
/*     */     }
/*  55 */     if (((String)setting.getValue()).equalsIgnoreCase("Light Purple")) {
/*  56 */       return TextFormatting.LIGHT_PURPLE;
/*     */     }
/*  58 */     if (((String)setting.getValue()).equalsIgnoreCase("White")) {
/*  59 */       return TextFormatting.WHITE;
/*     */     }
/*  61 */     if (((String)setting.getValue()).equalsIgnoreCase("Aqua")) {
/*  62 */       return TextFormatting.AQUA;
/*     */     }
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   public static ChatFormatting textToChatFormatting(ModeSetting setting) {
/*  68 */     if (((String)setting.getValue()).equalsIgnoreCase("Black")) {
/*  69 */       return ChatFormatting.BLACK;
/*     */     }
/*  71 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Green")) {
/*  72 */       return ChatFormatting.DARK_GREEN;
/*     */     }
/*  74 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Red")) {
/*  75 */       return ChatFormatting.DARK_RED;
/*     */     }
/*  77 */     if (((String)setting.getValue()).equalsIgnoreCase("Gold")) {
/*  78 */       return ChatFormatting.GOLD;
/*     */     }
/*  80 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Gray")) {
/*  81 */       return ChatFormatting.DARK_GRAY;
/*     */     }
/*  83 */     if (((String)setting.getValue()).equalsIgnoreCase("Green")) {
/*  84 */       return ChatFormatting.GREEN;
/*     */     }
/*  86 */     if (((String)setting.getValue()).equalsIgnoreCase("Red")) {
/*  87 */       return ChatFormatting.RED;
/*     */     }
/*  89 */     if (((String)setting.getValue()).equalsIgnoreCase("Yellow")) {
/*  90 */       return ChatFormatting.YELLOW;
/*     */     }
/*  92 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Blue")) {
/*  93 */       return ChatFormatting.DARK_BLUE;
/*     */     }
/*  95 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Aqua")) {
/*  96 */       return ChatFormatting.DARK_AQUA;
/*     */     }
/*  98 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Purple")) {
/*  99 */       return ChatFormatting.DARK_PURPLE;
/*     */     }
/* 101 */     if (((String)setting.getValue()).equalsIgnoreCase("Gray")) {
/* 102 */       return ChatFormatting.GRAY;
/*     */     }
/* 104 */     if (((String)setting.getValue()).equalsIgnoreCase("Blue")) {
/* 105 */       return ChatFormatting.BLUE;
/*     */     }
/* 107 */     if (((String)setting.getValue()).equalsIgnoreCase("Light Purple")) {
/* 108 */       return ChatFormatting.LIGHT_PURPLE;
/*     */     }
/* 110 */     if (((String)setting.getValue()).equalsIgnoreCase("White")) {
/* 111 */       return ChatFormatting.WHITE;
/*     */     }
/* 113 */     if (((String)setting.getValue()).equalsIgnoreCase("Aqua")) {
/* 114 */       return ChatFormatting.AQUA;
/*     */     }
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public static Color settingToColor(ModeSetting setting) {
/* 120 */     if (((String)setting.getValue()).equalsIgnoreCase("Black")) {
/* 121 */       return Color.BLACK;
/*     */     }
/* 123 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Green")) {
/* 124 */       return Color.GREEN.darker();
/*     */     }
/* 126 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Red")) {
/* 127 */       return Color.RED.darker();
/*     */     }
/* 129 */     if (((String)setting.getValue()).equalsIgnoreCase("Gold")) {
/* 130 */       return Color.yellow.darker();
/*     */     }
/* 132 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Gray")) {
/* 133 */       return Color.DARK_GRAY;
/*     */     }
/* 135 */     if (((String)setting.getValue()).equalsIgnoreCase("Green")) {
/* 136 */       return Color.green;
/*     */     }
/* 138 */     if (((String)setting.getValue()).equalsIgnoreCase("Red")) {
/* 139 */       return Color.red;
/*     */     }
/* 141 */     if (((String)setting.getValue()).equalsIgnoreCase("Yellow")) {
/* 142 */       return Color.yellow;
/*     */     }
/* 144 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Blue")) {
/* 145 */       return Color.blue.darker();
/*     */     }
/* 147 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Aqua")) {
/* 148 */       return Color.CYAN.darker();
/*     */     }
/* 150 */     if (((String)setting.getValue()).equalsIgnoreCase("Dark Purple")) {
/* 151 */       return Color.MAGENTA.darker();
/*     */     }
/* 153 */     if (((String)setting.getValue()).equalsIgnoreCase("Gray")) {
/* 154 */       return Color.GRAY;
/*     */     }
/* 156 */     if (((String)setting.getValue()).equalsIgnoreCase("Blue")) {
/* 157 */       return Color.blue;
/*     */     }
/* 159 */     if (((String)setting.getValue()).equalsIgnoreCase("Light Purple")) {
/* 160 */       return Color.magenta;
/*     */     }
/* 162 */     if (((String)setting.getValue()).equalsIgnoreCase("White")) {
/* 163 */       return Color.WHITE;
/*     */     }
/* 165 */     if (((String)setting.getValue()).equalsIgnoreCase("Aqua")) {
/* 166 */       return Color.cyan;
/*     */     }
/* 168 */     return Color.WHITE;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */