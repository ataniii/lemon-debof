//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.misc;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.network.NetHandlerPlayClient;
/*    */ 
/*    */ public class ServerUtil
/*    */ {
/* 10 */   static Minecraft mc = Minecraft.getMinecraft();
/*    */   private static String serverBrand;
/*    */   private static Timing timer;
/*    */   private static float[] tpsCounts;
/*    */   private static long lastUpdate;
/* 15 */   private static String format = "%.3f";
/*    */   private static float TPS;
/*    */   
/*    */   public static float getTpsFactor() {
/* 19 */     return 20.0F / TPS;
/*    */   }
/*    */   
/*    */   public static long serverRespondingTime() {
/* 23 */     return timer.getPassedTimeMs();
/*    */   }
/*    */   
/*    */   public static String getServerBrand() {
/* 27 */     return serverBrand;
/*    */   }
/*    */   
/*    */   public boolean isServerNotResponding() {
/* 31 */     return timer.passedMs(500L);
/*    */   }
/*    */   
/*    */   public ServerUtil() {
/* 35 */     tpsCounts = new float[10];
/* 36 */     format = "%.3f";
/* 37 */     timer = new Timing();
/* 38 */     TPS = 20.0F;
/* 39 */     lastUpdate = -1L;
/* 40 */     serverBrand = "";
/*    */   }
/*    */   
/*    */   public void update() {
/* 44 */     long currentTimeMillis = System.currentTimeMillis();
/* 45 */     if (lastUpdate == -1L) {
/* 46 */       lastUpdate = currentTimeMillis;
/*    */       return;
/*    */     } 
/* 49 */     float n = (float)(currentTimeMillis - lastUpdate) / 20.0F;
/* 50 */     if (n == 0.0F) {
/* 51 */       n = 50.0F;
/*    */     }
/*    */     float n2;
/* 54 */     if ((n2 = 1000.0F / n) > 20.0F) {
/* 55 */       n2 = 20.0F;
/*    */     }
/* 57 */     System.arraycopy(ServerUtil.tpsCounts, 0, ServerUtil.tpsCounts, 1, ServerUtil.tpsCounts.length - 1);
/* 58 */     ServerUtil.tpsCounts[0] = n2;
/* 59 */     double n3 = 0.0D;
/* 60 */     float[] tpsCounts = ServerUtil.tpsCounts;
/* 61 */     for (int length = tpsCounts.length, i = 0; i < length; i++) {
/* 62 */       n3 += tpsCounts[i];
/*    */     }
/*    */     double number;
/* 65 */     if ((number = n3 / tpsCounts.length) > 20.0D) {
/* 66 */       number = 20.0D;
/*    */     }
/* 68 */     TPS = Float.parseFloat(String.format(format, new Object[] { Double.valueOf(number) }));
/* 69 */     lastUpdate = currentTimeMillis;
/*    */   }
/*    */   
/*    */   public static int getPing() {
/* 73 */     if (mc.world == null || mc.player == null)
/* 74 */       return 0; 
/*    */     try {
/* 76 */       return ((NetHandlerPlayClient)Objects.<NetHandlerPlayClient>requireNonNull(mc.getConnection())).getPlayerInfo(mc.getConnection().getGameProfile().getId()).getResponseTime();
/*    */     }
/* 78 */     catch (Exception ex) {
/* 79 */       return 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static float getTPS() {
/* 84 */     return TPS;
/*    */   }
/*    */   
/*    */   public void setServerBrand(String serverBrand) {
/* 88 */     serverBrand = serverBrand;
/*    */   }
/*    */   
/*    */   public static void reset() {
/* 92 */     Arrays.fill(tpsCounts, 20.0F);
/* 93 */     TPS = 20.0F;
/*    */   }
/*    */   
/*    */   public static void onPacketReceived() {
/* 97 */     timer.reset();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\misc\ServerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
