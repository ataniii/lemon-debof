/*    */ package com.lemonclient.api.util.chat;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ 
/*    */ public class SubscriberImpl
/*    */   implements Subscriber
/*    */ {
/* 11 */   protected final List<Listener<?>> listeners = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<Listener<?>> getListeners() {
/* 16 */     return this.listeners;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\SubscriberImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */