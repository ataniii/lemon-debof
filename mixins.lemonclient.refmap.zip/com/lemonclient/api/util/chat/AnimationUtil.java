/*     */ package com.lemonclient.api.util.chat;
/*     */ 
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ 
/*     */ public class AnimationUtil {
/*     */   private static final float defaultSpeed = 0.125F;
/*   7 */   private final Timing timerUtil = new Timing();
/*     */   
/*     */   public static float moveTowards(float current, float end, float smoothSpeed, float minSpeed, boolean back) {
/*  10 */     float movement = (end - current) * smoothSpeed;
/*  11 */     if (movement > 0.0F) {
/*  12 */       movement = Math.max(minSpeed, movement);
/*  13 */       movement = Math.min(end - current, movement);
/*     */     }
/*  15 */     else if (movement < 0.0F) {
/*  16 */       movement = Math.min(-minSpeed, movement);
/*  17 */       movement = Math.max(end - current, movement);
/*     */     } 
/*  19 */     if (back) {
/*  20 */       return movement - current;
/*     */     }
/*  22 */     return current + movement;
/*     */   }
/*     */   
/*     */   public static double moveTowards(double target, double current, double speed) {
/*  26 */     boolean larger = (target > current);
/*  27 */     double dif = Math.max(target, current) - Math.min(target, current);
/*  28 */     double factor = dif * speed;
/*  29 */     if (factor < 0.1D) {
/*  30 */       factor = 0.1D;
/*     */     }
/*  32 */     if (larger) {
/*  33 */       current += factor;
/*     */     } else {
/*     */       
/*  36 */       current -= factor;
/*     */     } 
/*  38 */     return current;
/*     */   }
/*     */   
/*     */   public static double expand(double target, double current, double speed) {
/*  42 */     if (current > target) {
/*  43 */       current = target;
/*     */     }
/*  45 */     if (current < -target) {
/*  46 */       current = -target;
/*     */     }
/*  48 */     current += speed;
/*  49 */     return current;
/*     */   }
/*     */   
/*     */   public static float calculateCompensation(float target, float current, long delta, double speed) {
/*  53 */     float diff = current - target;
/*  54 */     if (delta < 1L) {
/*  55 */       delta = 1L;
/*     */     }
/*  57 */     if (delta > 1000L) {
/*  58 */       delta = 16L;
/*     */     }
/*  60 */     if (diff > speed) {
/*  61 */       double xD = Math.max(speed * delta / 16.0D, 0.5D);
/*  62 */       if ((current = (float)(current - xD)) < target) {
/*  63 */         current = target;
/*     */       }
/*  65 */     } else if (diff < -speed) {
/*  66 */       double xD = Math.max(speed * delta / 16.0D, 0.5D);
/*  67 */       if ((current = (float)(current + xD)) > target) {
/*  68 */         current = target;
/*     */       }
/*     */     } else {
/*  71 */       current = target;
/*     */     } 
/*  73 */     return current;
/*     */   }
/*     */   
/*     */   public float moveUD(float current, float end, float minSpeed) {
/*  77 */     return moveUD(current, end, 0.125F, minSpeed);
/*     */   }
/*     */   
/*     */   public double animate(double target, double current, double speed) {
/*  81 */     if (this.timerUtil.passedMs(4L)) {
/*  82 */       boolean larger = (target > current);
/*  83 */       if (speed < 0.0D) { speed = 0.0D; }
/*  84 */       else if (speed > 1.0D) { speed = 1.0D; }
/*     */       
/*  86 */       double dif = Math.max(target, current) - Math.min(target, current);
/*  87 */       double factor = dif * speed;
/*  88 */       if (factor < 0.1D) {
/*  89 */         factor = 0.1D;
/*     */       }
/*     */       
/*  92 */       current = larger ? (current + factor) : (current - factor);
/*  93 */       this.timerUtil.reset();
/*     */     } 
/*  95 */     return current;
/*     */   }
/*     */   
/*     */   public double animates(double target, double current, double speed) {
/*  99 */     if (this.timerUtil.passedMs(1L)) {
/*     */       
/* 101 */       boolean larger = (target > current), bl = larger;
/* 102 */       if (speed < 0.0D) {
/* 103 */         speed = 0.0D;
/* 104 */       } else if (speed > 1.0D) {
/* 105 */         speed = 1.0D;
/*     */       } 
/* 107 */       double dif = Math.max(target, current) - Math.min(target, current);
/* 108 */       double factor = dif * speed;
/* 109 */       if (factor < 0.1D) {
/* 110 */         factor = 0.1D;
/*     */       }
/*     */       
/* 113 */       current = larger ? (current += factor) : (current -= factor);
/* 114 */       this.timerUtil.reset();
/*     */     } 
/* 116 */     return current;
/*     */   }
/*     */ 
/*     */   
/*     */   public float animate(float target, float current, float speed) {
/* 121 */     if (this.timerUtil.passedMs(4L)) {
/* 122 */       boolean larger = (target > current);
/* 123 */       if (speed < 0.0F) {
/* 124 */         speed = 0.0F;
/* 125 */       } else if (speed > 1.0D) {
/* 126 */         speed = 1.0F;
/*     */       } 
/* 128 */       float dif = Math.max(target, current) - Math.min(target, current);
/* 129 */       float factor = dif * speed;
/* 130 */       if (factor < 0.01F) {
/* 131 */         factor = 0.01F;
/*     */       }
/* 133 */       current = larger ? (current + factor) : (current - factor);
/* 134 */       this.timerUtil.reset();
/*     */     } 
/*     */     
/* 137 */     if (Math.abs(current - target) < 0.2D) return target; 
/* 138 */     return current;
/*     */   }
/*     */   
/*     */   public float moveUD(float current, float end, float smoothSpeed, float minSpeed) {
/* 142 */     float movement = 0.0F;
/* 143 */     if (this.timerUtil.passedMs(4L)) {
/* 144 */       movement = (end - current) * smoothSpeed;
/* 145 */       if (movement > 0.0F) {
/* 146 */         movement = Math.max(minSpeed, movement);
/* 147 */         movement = Math.min(end - current, movement);
/* 148 */       } else if (movement < 0.0F) {
/* 149 */         movement = Math.min(-minSpeed, movement);
/* 150 */         movement = Math.max(end - current, movement);
/*     */       } 
/* 152 */       this.timerUtil.reset();
/*     */     } 
/* 154 */     return current + movement;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\AnimationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */