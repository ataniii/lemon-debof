/*    */ package com.lemonclient.api.util.chat.notification;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public abstract class Notification
/*    */ {
/*    */   protected final NotificationType type;
/*    */   protected final String title;
/*    */   protected final String message;
/*    */   protected long start;
/*    */   protected final long fadedIn;
/*    */   protected final long fadeOut;
/*    */   protected final long end;
/*    */   
/*    */   public Notification(NotificationType type, String title, String message, int length) {
/* 16 */     this.type = type;
/* 17 */     this.title = title;
/* 18 */     this.message = message;
/* 19 */     this.fadedIn = 100L * length;
/* 20 */     this.fadeOut = this.fadedIn + 150L * length;
/* 21 */     this.end = this.fadeOut + this.fadedIn;
/*    */   }
/*    */   
/*    */   public void show() {
/* 25 */     this.start = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public boolean isShown() {
/* 29 */     return (getTime() <= this.end);
/*    */   }
/*    */   
/*    */   protected long getTime() {
/* 33 */     return System.currentTimeMillis() - this.start;
/*    */   }
/*    */   
/*    */   protected int getOffset(double maxWidth) {
/* 37 */     if (getTime() < this.fadedIn) {
/* 38 */       return (int)(Math.tanh(getTime() / this.fadedIn * 3.0D) * maxWidth);
/*    */     }
/* 40 */     if (getTime() > this.fadeOut) {
/* 41 */       return (int)(Math.tanh(3.0D - (getTime() - this.fadeOut) / (this.end - this.fadeOut) * 3.0D) * maxWidth);
/*    */     }
/* 43 */     return (int)maxWidth;
/*    */   }
/*    */   
/*    */   protected Color getDefaultTypeColor() {
/* 47 */     if (this.type == NotificationType.INFO) {
/* 48 */       return Color.BLUE;
/*    */     }
/* 50 */     if (this.type == NotificationType.WARNING) {
/* 51 */       return new Color(218, 165, 32);
/*    */     }
/* 53 */     if (this.type == NotificationType.LOAD) {
/* 54 */       return new Color(255, 255, 150);
/*    */     }
/* 56 */     if (this.type == NotificationType.WELCOME) {
/* 57 */       return new Color(255, 255, 75);
/*    */     }
/* 59 */     return Color.RED;
/*    */   }
/*    */   
/*    */   public abstract void render(int paramInt1, int paramInt2);
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\Notification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */