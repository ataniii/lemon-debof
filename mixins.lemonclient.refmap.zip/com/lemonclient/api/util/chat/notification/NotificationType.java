/*    */ package com.lemonclient.api.util.chat.notification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NotificationType
/*    */ {
/*  9 */   INFO,
/* 10 */   WARNING,
/* 11 */   WELCOME,
/* 12 */   LOAD,
/* 13 */   ERROR;
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\NotificationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */