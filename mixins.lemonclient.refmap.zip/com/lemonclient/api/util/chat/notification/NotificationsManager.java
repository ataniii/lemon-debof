//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.chat.notification;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ 
/*    */ 
/*    */ public class NotificationsManager
/*    */ {
/*    */   public static final LinkedBlockingQueue<Notification> pendingNotifications;
/*    */   private static Notification currentNotification;
/* 13 */   public static ArrayList<Notifications> notifications = new ArrayList<>();
/*    */   
/*    */   public static void show(Notification notification) {
/* 16 */     pendingNotifications.add(notification);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void show(Notifications notification) {
/* 21 */     notifications.add(notification);
/*    */   }
/*    */   
/*    */   public static void update() {
/* 25 */     if (currentNotification != null && !currentNotification.isShown()) {
/* 26 */       currentNotification = null;
/*    */     }
/* 28 */     if (currentNotification == null && !pendingNotifications.isEmpty()) {
/* 29 */       (currentNotification = pendingNotifications.poll()).show();
/*    */     }
/*    */   }
/*    */   
/*    */   public static void render() {
/*    */     try {
/* 35 */       int divider = (Minecraft.getMinecraft()).gameSettings.guiScale;
/* 36 */       int width = (Minecraft.getMinecraft()).displayWidth / divider;
/* 37 */       int height = (Minecraft.getMinecraft()).displayHeight / divider;
/* 38 */       update();
/* 39 */       if (currentNotification != null) {
/* 40 */         currentNotification.render(width, height);
/*    */       }
/*    */     }
/* 43 */     catch (Exception exception) {}
/*    */   }
/*    */   
/*    */   static {
/* 47 */     pendingNotifications = new LinkedBlockingQueue<>();
/* 48 */     currentNotification = null;
/*    */   }
/*    */   
/*    */   public static void drawNotifications() {
/*    */     try {
/* 53 */       ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
/*    */       
/* 55 */       double lastY = (res.getScaledHeight() - 25), startY = lastY;
/* 56 */       for (int i = 0; i < notifications.size(); i++) {
/* 57 */         Notifications not = notifications.get(i);
/* 58 */         if (not.shouldDelete()) {
/* 59 */           notifications.remove(not);
/* 60 */           for (int cao = 0; cao > not.width; cao--) {
/* 61 */             not.animationX = cao - not.width;
/*    */           }
/* 63 */           startY += not.getHeight() + 3.0D;
/*    */         } 
/* 65 */         not.draw(startY, lastY);
/* 66 */         for (int number = 0; number < not.width; number++) {
/* 67 */           not.animationX = number + not.width;
/*    */         }
/* 69 */         startY -= not.getHeight() + 2.0D;
/*    */       }
/*    */     
/* 72 */     } catch (Throwable throwable) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\NotificationsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
