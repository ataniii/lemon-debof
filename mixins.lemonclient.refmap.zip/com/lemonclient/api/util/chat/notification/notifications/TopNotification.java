/*     */ package com.lemonclient.api.util.chat.notification.notifications;
/*     */ 
/*     */ import com.lemonclient.api.util.chat.notification.Notification;
/*     */ import com.lemonclient.api.util.chat.notification.NotificationType;
/*     */ import com.lemonclient.api.util.font.CFontRenderer;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.LemonClient;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class TopNotification
/*     */   extends Notification {
/*     */   public Map<Integer, Integer> offsetDirLeft;
/*     */   public Map<Integer, Integer> offsetDirRight;
/*     */   public int arrAmount;
/*     */   public boolean shouldAdd;
/*     */   public int delaydir;
/*     */   
/*     */   public TopNotification(NotificationType type, String title, String message, int length) {
/*  23 */     super(type, title, message, length);
/*  24 */     this.offsetDirLeft = new HashMap<>();
/*  25 */     this.offsetDirRight = new HashMap<>();
/*  26 */     this.arrAmount = 0;
/*  27 */     this.shouldAdd = true;
/*  28 */     this.delaydir = 0;
/*     */   }
/*     */   
/*     */   public void render(int RealDisplayWidth, int RealDisplayHeight) {
/*  32 */     CFontRenderer font = LemonClient.INSTANCE.cFontRenderer;
/*  33 */     this.delaydir++;
/*  34 */     int height = font.getHeight() * 4;
/*  35 */     int width = RealDisplayWidth / 4;
/*  36 */     int offset = getOffset(width);
/*  37 */     Color color = (this.type == NotificationType.INFO) ? Color.BLACK : getDefaultTypeColor();
/*  38 */     boolean shouldEffect = (offset >= width - 5);
/*  39 */     int cx = RealDisplayWidth / 2;
/*  40 */     int cy = RealDisplayHeight / 8;
/*  41 */     int x = cx - offset;
/*  42 */     int dWidth = offset * 2;
/*  43 */     if (shouldEffect) {
/*  44 */       if (this.shouldAdd) {
/*  45 */         this.offsetDirLeft.put(Integer.valueOf(this.arrAmount), Integer.valueOf(-16 - 10 * this.arrAmount));
/*  46 */         this.offsetDirRight.put(Integer.valueOf(this.arrAmount), Integer.valueOf(-16 - 10 * this.arrAmount));
/*  47 */         this.arrAmount++;
/*  48 */         if (this.arrAmount >= 3) {
/*  49 */           this.arrAmount = 0;
/*  50 */           this.shouldAdd = false;
/*     */         } 
/*     */       } 
/*  53 */       GL11.glLineWidth(2.0F);
/*  54 */       for (Map.Entry<Integer, Integer> offsetdir : this.offsetDirLeft.entrySet()) {
/*  55 */         int value = ((Integer)offsetdir.getValue()).intValue();
/*  56 */         int alpha = calculateAlphaChangeColor(255, 10, 50, value).intValue();
/*  57 */         RenderUtil.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha));
/*  58 */         drawC(x - value, cy, height, height);
/*     */       } 
/*  60 */       for (Map.Entry<Integer, Integer> offsetdir : this.offsetDirRight.entrySet()) {
/*  61 */         int value = ((Integer)offsetdir.getValue()).intValue();
/*  62 */         int alpha = calculateAlphaChangeColor(255, 10, 50, value).intValue();
/*  63 */         RenderUtil.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha));
/*  64 */         drawBC(x + dWidth + value, cy, height, height);
/*     */       } 
/*     */     } 
/*  67 */     int delay = 3;
/*  68 */     if (this.delaydir >= 3) {
/*  69 */       this.delaydir = 0;
/*  70 */       for (Map.Entry<Integer, Integer> offsetdir2 : this.offsetDirLeft.entrySet()) {
/*  71 */         if (((Integer)offsetdir2.getValue()).intValue() >= 50) {
/*  72 */           offsetdir2.setValue(Integer.valueOf(-16));
/*     */           continue;
/*     */         } 
/*  75 */         offsetdir2.setValue(Integer.valueOf(((Integer)offsetdir2.getValue()).intValue() + 1));
/*     */       } 
/*     */       
/*  78 */       for (Map.Entry<Integer, Integer> offsetdir2 : this.offsetDirRight.entrySet()) {
/*  79 */         if (((Integer)offsetdir2.getValue()).intValue() >= 50) {
/*  80 */           offsetdir2.setValue(Integer.valueOf(-16));
/*     */           continue;
/*     */         } 
/*  83 */         offsetdir2.setValue(Integer.valueOf(((Integer)offsetdir2.getValue()).intValue() + 1));
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     RenderUtil.drawRect(x, cy, dWidth, height, color);
/*  88 */     RenderUtil.drawTriangle(x, cy, (x - 15 - 1), cy + height / 2.0D, x, (cy + height), color);
/*  89 */     RenderUtil.drawTriangle((x + dWidth), (cy + height), (x + 15 + dWidth), cy + height / 2.0D, (x + dWidth), cy, color);
/*  90 */     int fx = x + dWidth / 2;
/*  91 */     int alpha2 = calculateAlphaChangeColor(10, 255, width, offset).intValue();
/*  92 */     font.drawString(this.title, fx - font.getStringWidth(this.title) / 2.0F, (cy + 3), new GSColor(255, 255, 255, alpha2));
/*  93 */     font.drawString(this.message, fx - font.getStringWidth(this.message) / 2.0F, (cy + font.getHeight() + 8), new GSColor(255, 255, 255, alpha2));
/*  94 */     if (!this.shouldAdd && !shouldEffect) {
/*  95 */       this.offsetDirLeft.remove(Integer.valueOf(this.arrAmount));
/*  96 */       this.offsetDirRight.remove(Integer.valueOf(this.arrAmount));
/*  97 */       this.arrAmount++;
/*  98 */       if (this.arrAmount >= 3) {
/*  99 */         this.arrAmount = 0;
/* 100 */         this.shouldAdd = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Integer calculateAlphaChangeColor(int oldAlpha, int newAlpha, int step, int currentStep) {
/* 106 */     return Integer.valueOf(Math.max(0, Math.min(255, oldAlpha + (newAlpha - oldAlpha) * Math.max(0, Math.min(step, currentStep)) / step)));
/*     */   }
/*     */   
/*     */   public void drawBC(int cx, int cy, int height, int margin) {
/* 110 */     GL11.glDisable(3553);
/* 111 */     GL11.glEnable(3042);
/* 112 */     GL11.glBegin(3);
/* 113 */     GL11.glVertex2d(cx, cy);
/* 114 */     GL11.glVertex2d((cx + margin), cy + height / 2.0D);
/* 115 */     GL11.glVertex2d(cx, (cy + height));
/* 116 */     GL11.glEnd();
/* 117 */     GL11.glEnable(3553);
/* 118 */     GL11.glDisable(3042);
/*     */   }
/*     */   
/*     */   public void drawC(int cx, int cy, int height, int margin) {
/* 122 */     GL11.glDisable(3553);
/* 123 */     GL11.glEnable(3042);
/* 124 */     GL11.glBegin(3);
/* 125 */     GL11.glVertex2d(cx, cy);
/* 126 */     GL11.glVertex2d((cx - margin), cy + height / 2.0D);
/* 127 */     GL11.glVertex2d(cx, (cy + height));
/* 128 */     GL11.glEnd();
/* 129 */     GL11.glEnable(3553);
/* 130 */     GL11.glDisable(3042);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\notifications\TopNotification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */