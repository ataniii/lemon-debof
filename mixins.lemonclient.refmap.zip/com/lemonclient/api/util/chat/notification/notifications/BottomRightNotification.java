//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.chat.notification.notifications;
/*    */ 
/*    */ import com.lemonclient.api.util.chat.notification.Notification;
/*    */ import com.lemonclient.api.util.chat.notification.NotificationType;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ 
/*    */ public class BottomRightNotification extends Notification {
/*    */   public BottomRightNotification(NotificationType type, String title, String message, int length) {
/* 12 */     super(type, title, message, length);
/*    */   }
/*    */   public void render(int RealDisplayWidth, int RealDisplayHeight) {
/*    */     Color color2;
/* 16 */     int width = 120;
/* 17 */     int height = 30;
/* 18 */     int offset = getOffset(120.0D);
/* 19 */     Color color = new Color(0, 0, 0, 220);
/*    */     
/* 21 */     if (this.type == NotificationType.INFO) {
/* 22 */       color2 = new Color(0, 26, 169);
/*    */     }
/* 24 */     else if (this.type == NotificationType.WARNING) {
/* 25 */       color2 = new Color(204, 193, 0);
/*    */     }
/* 27 */     else if (this.type == NotificationType.WELCOME) {
/* 28 */       color2 = new Color(255, 255, 75);
/*    */     }
/* 30 */     else if (this.type == NotificationType.LOAD) {
/* 31 */       color2 = new Color(255, 255, 150);
/*    */     } else {
/*    */       
/* 34 */       color2 = new Color(204, 0, 18);
/* 35 */       int i = Math.max(0, Math.min(255, (int)(Math.sin(getTime() / 100.0D) * 255.0D / 2.0D + 127.5D)));
/* 36 */       color = new Color(i, 0, 0, 220);
/*    */     } 
/* 38 */     FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRenderer;
/* 39 */     Gui.drawRect(RealDisplayWidth - offset, RealDisplayHeight - 5 - 30, RealDisplayWidth, RealDisplayHeight - 5, color.getRGB());
/* 40 */     Gui.drawRect(RealDisplayWidth - offset, RealDisplayHeight - 5 - 30, RealDisplayWidth - offset + 4, RealDisplayHeight - 5, color2.getRGB());
/* 41 */     fontRenderer.drawString(this.title, RealDisplayWidth - offset + 8, RealDisplayHeight - 2 - 30, -1);
/* 42 */     fontRenderer.drawString(this.message, RealDisplayWidth - offset + 8, RealDisplayHeight - 15, -1);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\notifications\BottomRightNotification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
