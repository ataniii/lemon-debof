//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.chat.notification;
/*     */ 
/*     */ import com.lemonclient.api.util.misc.Timing;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Notifications
/*     */ {
/*     */   public Notifications(String message, Type type) {
/*  28 */     this.timer = new Timing();
/*  29 */     this.message = message;
/*  30 */     this.timer.reset();
/*  31 */     this.width = ((Minecraft.getMinecraft()).fontRenderer.getStringWidth(message) + 35);
/*  32 */     this.height = 20.0D;
/*  33 */     this.animationX = this.width;
/*  34 */     this.stayTime = 1000L;
/*  35 */     this.posY = -1.0D;
/*  36 */     this.t = type;
/*  37 */     if (type.equals(Type.INFO)) {
/*  38 */       this.color = -14342875;
/*     */     }
/*  40 */     else if (type.equals(Type.ERROR)) {
/*  41 */       this.color = (new Color(36, 36, 36)).getRGB();
/*     */     }
/*  43 */     else if (type.equals(Type.SUCCESS)) {
/*  44 */       this.color = (new Color(36, 36, 36)).getRGB();
/*     */     }
/*  46 */     else if (type.equals(Type.DISABLE)) {
/*  47 */       this.color = (new Color(36, 36, 36)).getRGB();
/*     */     }
/*  49 */     else if (type.equals(Type.WARNING)) {
/*  50 */       this.color = -14342875;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int reAlpha(int color, float alpha) {
/*  55 */     Color c = new Color(color);
/*  56 */     float r = 0.003921569F * c.getRed();
/*  57 */     float g = 0.003921569F * c.getGreen();
/*  58 */     float b = 0.003921569F * c.getBlue();
/*  59 */     return (new Color(r, g, b, alpha)).getRGB();
/*     */   }
/*     */   
/*     */   public void draw(double getY, double lastY) {
/*  63 */     this.width = ((Minecraft.getMinecraft()).fontRenderer.getStringWidth(this.message) + 25);
/*  64 */     this.height = 22.0D;
/*  65 */     this.lastY = lastY;
/*  66 */     this.animationX = getAnimationState(this.animationX, isFinished() ? this.width : 0.0D, 450.0D);
/*  67 */     if (this.posY == -1.0D) {
/*  68 */       this.posY = getY;
/*     */     } else {
/*     */       
/*  71 */       this.posY = getAnimationState(this.posY, getY, 350.0D);
/*     */     } 
/*  73 */     ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
/*  74 */     int x1 = (int)(res.getScaledWidth() - this.width + this.animationX / 2.0D);
/*  75 */     int x2 = (int)(res.getScaledWidth() + this.animationX / 2.0D);
/*  76 */     int y1 = (int)this.posY - 22;
/*  77 */     int y2 = (int)(y1 + this.height);
/*  78 */     RenderUtil.drawRect(x1, y1, x2, y2, reAlpha(this.color, 0.85F));
/*  79 */     RenderUtil.drawRect(x1, (y2 - 1), (float)(x1 + Math.min((x2 - x1) * (System.currentTimeMillis() - this.timer.getPassedTimeMs()) / this.stayTime, (x2 - x1))), y2, reAlpha(-1, 0.85F));
/*  80 */     switch (this.t) {
/*     */       case ERROR:
/*  82 */         (Minecraft.getMinecraft()).fontRenderer.drawString(ICON_NOTIFY_ERROR, x1 + 5, y1 + 7, -65794);
/*     */         break;
/*     */       
/*     */       case INFO:
/*  86 */         (Minecraft.getMinecraft()).fontRenderer.drawString(ICON_NOTIFY_INFO, x1 + 5, y1 + 7, -65794);
/*     */         break;
/*     */       
/*     */       case SUCCESS:
/*  90 */         (Minecraft.getMinecraft()).fontRenderer.drawString(ICON_NOTIFY_SUCCESS, x1 + 5, y1 + 7, -65794);
/*     */         break;
/*     */       
/*     */       case WARNING:
/*  94 */         (Minecraft.getMinecraft()).fontRenderer.drawString(ICON_NOTIFY_WARN, x1 + 5, y1 + 7, -65794);
/*     */         break;
/*     */       
/*     */       case DISABLE:
/*  98 */         (Minecraft.getMinecraft()).fontRenderer.drawString(ICON_NOTIFY_DISABLED, x1 + 5, y1 + 7, -65794);
/*     */         break;
/*     */     } 
/*     */     
/* 102 */     y1++;
/* 103 */     if (this.message.contains(" Enabled")) {
/* 104 */       (Minecraft.getMinecraft()).fontRenderer.drawString(this.message, x1 + 19, (int)(y1 + this.height / 4.0D), -1);
/* 105 */       (Minecraft.getMinecraft()).fontRenderer.drawString(" Enabled", x1 + 20 + (Minecraft.getMinecraft()).fontRenderer.getStringWidth(this.message), (int)(y1 + this.height / 4.0D), -9868951);
/*     */     }
/* 107 */     else if (this.message.contains(" Disabled")) {
/* 108 */       (Minecraft.getMinecraft()).fontRenderer.drawString(this.message, x1 + 19, (int)(y1 + this.height / 4.0D), -1);
/* 109 */       (Minecraft.getMinecraft()).fontRenderer.drawString(" Disabled", x1 + 20 + (Minecraft.getMinecraft()).fontRenderer.getStringWidth(this.message), (int)(y1 + this.height / 4.0D), -9868951);
/*     */     } else {
/*     */       
/* 112 */       (Minecraft.getMinecraft()).fontRenderer.drawString(this.message, x1 + 20, (int)(y1 + this.height / 4.0D), -1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean shouldDelete() {
/* 117 */     return (isFinished() && this.animationX >= this.width);
/*     */   }
/*     */   
/*     */   public boolean isFinished() {
/* 121 */     return (this.timer.passedMs(this.stayTime) && this.posY == this.lastY);
/*     */   }
/*     */   
/*     */   public double getHeight() {
/* 125 */     return this.height;
/*     */   }
/*     */   
/*     */   public double getAnimationState(double animation, double finalState, double speed) {
/* 129 */     float add = (float)((Minecraft.getMinecraft()).timer.tickLength * speed * speed);
/* 130 */     if (animation < finalState) {
/* 131 */       if (animation + add < finalState) {
/* 132 */         animation += add;
/*     */       } else {
/*     */         
/* 135 */         animation = finalState;
/*     */       }
/*     */     
/* 138 */     } else if (animation - add > finalState) {
/* 139 */       animation -= add;
/*     */     } else {
/*     */       
/* 142 */       animation = finalState;
/*     */     } 
/* 144 */     return animation;
/*     */   }
/*     */ 
/*     */   
/* 148 */   public static String ICON_NOTIFY_INFO = "ℹ";
/* 149 */   public static String ICON_NOTIFY_SUCCESS = "✓";
/* 150 */   public static String ICON_NOTIFY_WARN = "⚠";
/* 151 */   public static String ICON_NOTIFY_ERROR = "⚠"; public Timing timer; public Type t; public long stayTime; public String message; public double lastY;
/* 152 */   public static String ICON_NOTIFY_DISABLED = "✗"; public double posY; public double width;
/*     */   public double height;
/*     */   public double animationX;
/*     */   public int color;
/*     */   
/* 157 */   public enum Type { SUCCESS,
/* 158 */     INFO,
/* 159 */     WARNING,
/* 160 */     ERROR,
/* 161 */     DISABLE; }
/*     */ 
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\notification\Notifications.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
