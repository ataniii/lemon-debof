//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.chat;
/*    */ 
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import java.util.Arrays;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listenable;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LagCompensator
/*    */   implements Listenable
/*    */ {
/*    */   public static LagCompensator INSTANCE;
/* 18 */   private final float[] tickRates = new float[20];
/* 19 */   private int nextIndex = 0; private long timeLastTimeUpdate;
/*    */   
/*    */   public LagCompensator() {
/* 22 */     this.packetEventListener = new Listener(event -> { if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate) INSTANCE.onTimeUpdate();  }new java.util.function.Predicate[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 30 */     LemonClient.EVENT_BUS.subscribe(this);
/* 31 */     reset();
/*    */   } @EventHandler
/*    */   Listener<PacketEvent.Receive> packetEventListener;
/*    */   public void reset() {
/* 35 */     this.nextIndex = 0;
/* 36 */     this.timeLastTimeUpdate = -1L;
/* 37 */     Arrays.fill(this.tickRates, 0.0F);
/*    */   }
/*    */   
/*    */   public float getTickRate() {
/* 41 */     float numTicks = 0.0F;
/* 42 */     float sumTickRates = 0.0F;
/* 43 */     for (float tickRate : this.tickRates) {
/* 44 */       if (tickRate > 0.0F) {
/* 45 */         sumTickRates += tickRate;
/* 46 */         numTicks++;
/*    */       } 
/*    */     } 
/* 49 */     return MathHelper.clamp(sumTickRates / numTicks, 0.0F, 20.0F);
/*    */   }
/*    */   
/*    */   public void onTimeUpdate() {
/* 53 */     if (this.timeLastTimeUpdate != -1L) {
/* 54 */       float timeElapsed = (float)(System.currentTimeMillis() - this.timeLastTimeUpdate) / 1000.0F;
/* 55 */       this.tickRates[this.nextIndex % this.tickRates.length] = MathHelper.clamp(20.0F / timeElapsed, 0.0F, 20.0F);
/* 56 */       this.nextIndex++;
/*    */     } 
/* 58 */     this.timeLastTimeUpdate = System.currentTimeMillis();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\LagCompensator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
