//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.chat;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiNewChat;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ 
/*     */ public class ChatUtil
/*     */   extends SubscriberImpl {
/*  13 */   public static Minecraft mc = Minecraft.getMinecraft();
/*  14 */   private static final Map<Integer, Map<String, Integer>> message_ids = new ConcurrentHashMap<>(); static {
/*  15 */     counter = new SkippingCounter(1337, i -> (i.intValue() != -1));
/*     */   }
/*     */   private static final SkippingCounter counter;
/*     */   public void clear() {
/*  19 */     if (mc.ingameGUI != null)
/*     */     {
/*  21 */       message_ids.values().forEach(m -> m.values().forEach(()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  26 */     message_ids.clear();
/*  27 */     counter.reset();
/*     */   }
/*     */   
/*     */   public static void sendMessage(String message) {
/*  31 */     sendMessage(message, 0);
/*     */   }
/*     */   
/*     */   public static void sendClientMessage(String append, String modulename) {
/*  35 */     sendDeleteMessage(append, modulename, 1000);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void sendMessage(String message, int id) {
/*  40 */     sendComponent((ITextComponent)new TextComponentString((message == null) ? "null" : message), id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendComponent(ITextComponent component) {
/*  46 */     sendComponent(component, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void sendComponent(ITextComponent c, int id) {
/*  51 */     applyIfPresent(g -> g.printChatMessageWithOptionalDeletion(c, id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendDeleteMessageScheduled(String message, String uniqueWord, int senderID) {
/*  62 */     Integer id = ((Map<String, Integer>)message_ids.computeIfAbsent(Integer.valueOf(senderID), v -> new ConcurrentHashMap<>())).computeIfAbsent(uniqueWord, v -> Integer.valueOf(counter.next()));
/*     */     
/*  64 */     mc.addScheduledTask(() -> sendMessage(message, id.intValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendDeleteMessage(String message, String uniqueWord, int senderID) {
/*  74 */     Integer id = ((Map<String, Integer>)message_ids.computeIfAbsent(Integer.valueOf(senderID), v -> new ConcurrentHashMap<>())).computeIfAbsent(uniqueWord, v -> Integer.valueOf(counter.next()));
/*     */     
/*  76 */     sendMessage(message, id.intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteMessage(String uniqueWord, int senderID) {
/*  81 */     Map<String, Integer> map = message_ids.get(Integer.valueOf(senderID));
/*  82 */     if (map != null) {
/*     */       
/*  84 */       Integer id = map.remove(uniqueWord);
/*  85 */       if (id != null)
/*     */       {
/*  87 */         deleteMessage(id.intValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void deleteMessage(int id) {
/*  93 */     applyIfPresent(g -> g.deleteChatLine(id));
/*     */   }
/*     */   
/*     */   public static void applyIfPresent(Consumer<GuiNewChat> consumer) {
/*  97 */     GuiNewChat chat = getChatGui();
/*  98 */     if (chat != null)
/*     */     {
/* 100 */       consumer.accept(chat);
/*     */     }
/*     */   }
/*     */   
/*     */   public static GuiNewChat getChatGui() {
/* 105 */     if (mc.ingameGUI != null)
/*     */     {
/* 107 */       return mc.ingameGUI.getChatGUI();
/*     */     }
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\ChatUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
