/*    */ package com.lemonclient.api.util.chat;
/*    */ 
/*    */ import com.lemonclient.client.module.ModuleManager;
/*    */ import com.lemonclient.client.module.modules.hud.Notifications;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class NotificationManager
/*    */ {
/*  9 */   public static ArrayList<Notification> notifications = new ArrayList<>();
/*    */   
/*    */   public static void add(Notification notify) {
/* 12 */     Notifications notification = (Notifications)ModuleManager.getModule(Notifications.class);
/* 13 */     int max = ((Integer)notification.max.getValue()).intValue();
/* 14 */     if (max != 0 && notifications.size() >= max) {
/* 15 */       switch ((String)notification.mode.getValue()) {
/*    */         case "Remove":
/* 17 */           notifications.remove(notifications.get(0));
/*    */           break;
/*    */         
/*    */         case "Cancel":
/*    */           return;
/*    */       } 
/*    */     
/*    */     }
/* 25 */     notify.y = (notifications.size() * 25);
/* 26 */     notifications.add(notify);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void draw() {
/* 31 */     if (NotificationManager.notifications.isEmpty())
/* 32 */       return;  Notification remove = null;
/* 33 */     for (Notification notify : NotificationManager.notifications) {
/* 34 */       if (notify.x == 0.0F) notify.in = !notify.in; 
/* 35 */       if (Math.abs(notify.x - notify.width) < 0.1D && !notify.in) remove = notify; 
/* 36 */       Notifications notifications = (Notifications)ModuleManager.getModule(Notifications.class);
/* 37 */       if (notify.in) { notify.x = notify.animationUtils.animate(0.0F, notify.x, ((Double)notifications.xSpeed.getValue()).floatValue()); }
/* 38 */       else { notify.x = (float)notify.animationUtils.animate(notify.width, notify.x, ((Double)notifications.xSpeed.getValue()).floatValue()); }
/* 39 */        notify.onRender();
/*    */     } 
/* 41 */     if (remove != null)
/* 42 */       NotificationManager.notifications.remove(remove); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\NotificationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */