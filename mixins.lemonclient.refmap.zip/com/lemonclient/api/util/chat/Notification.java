//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.chat;
/*     */ 
/*     */ import com.lemonclient.api.util.font.FontUtil;
/*     */ import com.lemonclient.api.util.misc.Wrapper;
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import com.lemonclient.api.util.render.RenderUtil;
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import com.lemonclient.client.module.modules.hud.Notifications;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ public class Notification
/*     */ {
/*     */   public String text;
/*     */   public double width;
/*  18 */   public double height = 30.0D;
/*     */   
/*     */   public float x;
/*     */   
/*     */   public String mark;
/*     */   Type type;
/*  24 */   AnimationUtil animationUtils = new AnimationUtil(); public float y; public float position; public boolean in = true;
/*  25 */   AnimationUtil yAnimationUtils = new AnimationUtil();
/*     */   
/*     */   public Notification(String text, Type type) {
/*  28 */     String mark = "";
/*  29 */     this.type = type;
/*  30 */     if (((Boolean)((Notifications)ModuleManager.getModule(Notifications.class)).mark.getValue()).booleanValue()) {
/*  31 */       switch (this.type) {
/*     */         case ERROR:
/*  33 */           mark = TextFormatting.DARK_RED + ICON_NOTIFY_ERROR + " ";
/*     */           break;
/*     */         
/*     */         case INFO:
/*  37 */           mark = TextFormatting.YELLOW + ICON_NOTIFY_INFO + " ";
/*     */           break;
/*     */         
/*     */         case SUCCESS:
/*  41 */           mark = TextFormatting.GREEN + ICON_NOTIFY_SUCCESS + " ";
/*     */           break;
/*     */         
/*     */         case WARNING:
/*  45 */           mark = TextFormatting.RED + ICON_NOTIFY_WARN + " ";
/*     */           break;
/*     */         
/*     */         case DISABLE:
/*  49 */           mark = TextFormatting.RED + ICON_NOTIFY_DISABLED + " ";
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  54 */     this.text = text;
/*  55 */     this.mark = mark;
/*  56 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/*  57 */     this.width = (FontUtil.getStringWidth(((Boolean)colorMain.customFont.getValue()).booleanValue(), this.text) + 25);
/*  58 */     this.x = (float)this.width;
/*     */   }
/*     */   
/*     */   public void onRender() {
/*  62 */     int i = 0;
/*  63 */     for (Notification notification1 : NotificationManager.notifications) {
/*  64 */       if (notification1 == this)
/*  65 */         break;  i++;
/*     */     } 
/*     */     
/*  68 */     Notifications notification = (Notifications)ModuleManager.getModule(Notifications.class);
/*  69 */     this.y = this.yAnimationUtils.animate((float)(i * (this.height + 5.0D)), this.y, ((Double)notification.ySpeed.getValue()).floatValue());
/*  70 */     ScaledResolution sr = new ScaledResolution(Wrapper.getMinecraft());
/*  71 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/*  72 */     int color = getColor(notification.backGround.getValue());
/*  73 */     Color outlineColor = getOutColor(notification.backGround.getValue());
/*     */     
/*  75 */     switch (this.type) {
/*     */       case ERROR:
/*  77 */         color = getColor(notification.errorBackGround.getValue());
/*  78 */         outlineColor = getOutColor(notification.errorBackGround.getValue());
/*     */         break;
/*     */       
/*     */       case SUCCESS:
/*  82 */         color = getColor(notification.successBackGround.getValue());
/*  83 */         outlineColor = getOutColor(notification.successBackGround.getValue());
/*     */         break;
/*     */       
/*     */       case WARNING:
/*  87 */         color = getColor(notification.warningBackGround.getValue());
/*  88 */         outlineColor = getOutColor(notification.warningBackGround.getValue());
/*     */         break;
/*     */       
/*     */       case DISABLE:
/*  92 */         color = getColor(notification.disableBackGround.getValue());
/*  93 */         outlineColor = getOutColor(notification.disableBackGround.getValue());
/*     */         break;
/*     */     } 
/*     */     
/*  97 */     RenderUtil.drawRectS((sr.getScaledWidth() + this.x) - this.width, ((sr
/*  98 */         .getScaledHeight() - 50) - this.y) - this.height, sr
/*  99 */         .getScaledWidth() + this.x, (sr
/* 100 */         .getScaledHeight() - 50) - this.y, color);
/*     */     
/* 102 */     if (((Boolean)notification.outline.getValue()).booleanValue()) {
/* 103 */       RenderUtil.drawRectSOutline((sr.getScaledWidth() + this.x) - this.width, ((sr
/* 104 */           .getScaledHeight() - 50) - this.y) - this.height, (sr
/* 105 */           .getScaledWidth() + this.x), ((sr
/* 106 */           .getScaledHeight() - 50) - this.y), outlineColor);
/*     */     }
/*     */     
/* 109 */     FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), this.text, this.mark, (int)((sr.getScaledWidth() + this.x) - this.width + 10.0D), (int)(sr.getScaledHeight() - 50.0F - this.y - 18.0F), new GSColor(204, 204, 204, 232));
/*     */   }
/*     */   private int getColor(GSColor color) {
/* 112 */     Notifications notifications = (Notifications)ModuleManager.getModule(Notifications.class);
/* 113 */     return (new Color(color.getRed(), color.getGreen(), color.getBlue(), ((Integer)notifications.alpha.getValue()).intValue())).getRGB();
/*     */   }
/*     */   
/*     */   private Color getOutColor(GSColor color) {
/* 117 */     Notifications notifications = (Notifications)ModuleManager.getModule(Notifications.class);
/* 118 */     return new Color(color.getRed(), color.getGreen(), color.getBlue(), ((Integer)notifications.outlineAlpha.getValue()).intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public static String ICON_NOTIFY_INFO = "ℹ";
/* 128 */   public static String ICON_NOTIFY_SUCCESS = "✓";
/* 129 */   public static String ICON_NOTIFY_WARN = "⚠";
/* 130 */   public static String ICON_NOTIFY_ERROR = "⚠";
/* 131 */   public static String ICON_NOTIFY_DISABLED = "✗";
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 136 */     SUCCESS,
/* 137 */     INFO,
/* 138 */     WARNING,
/* 139 */     ERROR,
/* 140 */     DISABLE;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\Notification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
