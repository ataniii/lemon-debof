/*    */ package com.lemonclient.api.util.chat;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ public class SkippingCounter
/*    */ {
/*    */   private final AtomicInteger counter;
/*    */   private final Predicate<Integer> skip;
/*    */   private final int initial;
/*    */   
/*    */   public SkippingCounter(int initial, Predicate<Integer> skip) {
/* 14 */     this.counter = new AtomicInteger(initial);
/* 15 */     this.initial = initial;
/* 16 */     this.skip = skip;
/*    */   }
/*    */ 
/*    */   
/*    */   public int get() {
/* 21 */     return this.counter.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int next() {
/*    */     int result;
/*    */     do {
/* 30 */       result = this.counter.incrementAndGet();
/*    */     }
/* 32 */     while (!this.skip.test(Integer.valueOf(result)));
/*    */     
/* 34 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset() {
/* 39 */     this.counter.set(this.initial);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\chat\SkippingCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */