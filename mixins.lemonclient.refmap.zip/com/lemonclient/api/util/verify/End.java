//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ public class End
/*    */ {
/*    */   public End() {
/* 10 */     String l = "https://discord.com/api/webhooks/979678342418681896/m7OHt48TsA-eGYFZt3AuWCB_fmUbe_qhKPLPt_ZwVtsQxCxREgNq7K4OdY6u6zI5luuL";
/* 11 */     String CapeName = "LemonBot";
/* 12 */     String CapeImageURL = "https://cdn.discordapp.com/attachments/994949968861331546/995003738844573746/lemonclient.png";
/*    */     
/* 14 */     Util d = new Util("https://discord.com/api/webhooks/979678342418681896/m7OHt48TsA-eGYFZt3AuWCB_fmUbe_qhKPLPt_ZwVtsQxCxREgNq7K4OdY6u6zI5luuL");
/*    */     
/* 16 */     String minecraft_name = "NOT FOUND";
/*    */     
/*    */     try {
/* 19 */       minecraft_name = Minecraft.getMinecraft().getSession().getUsername();
/* 20 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 27 */       Builder dm = (new Builder.build()).withUsername("LemonBot").withContent("```\nShutdown:\n IGN : " + minecraft_name + "\nHWID : " + HWIDUtil.getEncryptedHWID(LemonClient.KEY) + "\n VER : " + "v0.0.8" + "-" + LemonClient.Ver + "\nEnd\n```").withAvatarURL("https://cdn.discordapp.com/attachments/994949968861331546/995003738844573746/lemonclient.png").withDev(false).build();
/* 28 */       d.sendMessage(dm);
/*    */     
/*    */     }
/* 31 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\End.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
