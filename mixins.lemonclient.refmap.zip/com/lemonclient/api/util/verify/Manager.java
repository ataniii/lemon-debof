//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class Manager
/*    */ {
/*    */   public Manager() {
/*  9 */     String l = "https://discord.com/api/webhooks/994970843585191936/A96adkb6HbXDqpZoQRnhYwd3jJAdTrlckn2Mm7HrCfn0jCn6eRV7KQuktB_OGwUiN3n2";
/* 10 */     String CapeName = "Crocodile";
/* 11 */     String CapeImageURL = "https://cdn.discordapp.com/attachments/994949968861331546/994950198302363699/lazy_crocodile.png";
/*    */     
/* 13 */     Util d = new Util("https://discord.com/api/webhooks/994970843585191936/A96adkb6HbXDqpZoQRnhYwd3jJAdTrlckn2Mm7HrCfn0jCn6eRV7KQuktB_OGwUiN3n2");
/*    */     
/* 15 */     String minecraft_name = "NOT FOUND";
/*    */     
/*    */     try {
/* 18 */       minecraft_name = Minecraft.getMinecraft().getSession().getUsername();
/* 19 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 26 */       Builder dm = (new Builder.build()).withUsername("Crocodile").withContent("```\n IGN : " + minecraft_name + "\nHWID : " + HWIDUtil.getEncryptedHWID(LemonClient.KEY) + "\n VER : " + LemonClient.Ver + "\n```").withAvatarURL("https://cdn.discordapp.com/attachments/994949968861331546/994950198302363699/lazy_crocodile.png").withDev(false).build();
/* 27 */       d.sendMessage(dm);
/*    */     
/*    */     }
/* 30 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\Manager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
