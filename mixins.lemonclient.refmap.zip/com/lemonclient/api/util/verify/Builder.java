/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.google.gson.annotations.SerializedName;
/*    */ 
/*    */ public class Builder
/*    */ {
/*    */   String username;
/*    */   String content;
/*    */   @SerializedName("avatar_url")
/*    */   String avatarUrl;
/*    */   @SerializedName("tts")
/*    */   boolean textToSpeech;
/*    */   
/*    */   public Builder() {
/* 15 */     this(null, "", null, false);
/*    */   }
/*    */   public Builder(String username, String content, String avatar_url, boolean tts) {
/* 18 */     capeUsername(username);
/* 19 */     setCape(content);
/* 20 */     checkCapeUrl(avatar_url);
/* 21 */     isDev(tts);
/*    */   }
/*    */   
/*    */   public void capeUsername(String username) {
/* 25 */     if (username != null) {
/* 26 */       this.username = username.substring(0, Math.min(31, username.length()));
/*    */     } else {
/* 28 */       this.username = null;
/*    */     } 
/*    */   }
/*    */   public void setCape(String content) {
/* 32 */     this.content = content;
/*    */   }
/*    */   public void checkCapeUrl(String avatarUrl) {
/* 35 */     this.avatarUrl = avatarUrl;
/*    */   }
/*    */   public void isDev(boolean textToSpeech) {
/* 38 */     this.textToSpeech = textToSpeech;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class build
/*    */   {
/* 45 */     private final Builder message = new Builder();
/*    */ 
/*    */     
/*    */     public build withUsername(String username) {
/* 49 */       this.message.capeUsername(username);
/* 50 */       return this;
/*    */     }
/*    */     
/*    */     public build withContent(String content) {
/* 54 */       this.message.setCape(content);
/* 55 */       return this;
/*    */     }
/*    */     
/*    */     public build withAvatarURL(String avatarURL) {
/* 59 */       this.message.checkCapeUrl(avatarURL);
/* 60 */       return this;
/*    */     }
/*    */     
/*    */     public build withDev(boolean tts) {
/* 64 */       this.message.isDev(tts);
/* 65 */       return this;
/*    */     }
/*    */     
/*    */     public Builder build() {
/* 69 */       return this.message;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\Builder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */