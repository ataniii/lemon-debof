/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.google.common.hash.Hashing;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.util.Arrays;
/*    */ import java.util.Base64;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HWIDUtil
/*    */ {
/*    */   public static byte[] rawHWID() throws NoSuchAlgorithmException {
/* 22 */     String main = System.getenv("PROCESS_IDENTIFIER") + System.getenv("PROCESSOR_LEVEL") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS") + System.getenv("COMPUTERNAME");
/* 23 */     byte[] bytes = main.getBytes(StandardCharsets.UTF_8);
/* 24 */     MessageDigest messageDigest = MessageDigest.getInstance("MD5");
/* 25 */     return messageDigest.digest(bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String Encrypt(String strToEncrypt, String secret) {
/*    */     try {
/* 31 */       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
/* 32 */       cipher.init(1, getKey(secret));
/* 33 */       return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
/*    */     }
/* 35 */     catch (Exception e) {
/*    */       
/* 37 */       System.out.println("Error while encrypting: " + e);
/*    */       
/* 39 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static SecretKeySpec getKey(String myKey) {
/*    */     try {
/* 46 */       byte[] key = myKey.getBytes(StandardCharsets.UTF_8);
/* 47 */       MessageDigest sha = MessageDigest.getInstance("SHA-1");
/* 48 */       key = sha.digest(key);
/* 49 */       key = Arrays.copyOf(key, 16);
/* 50 */       return new SecretKeySpec(key, "AES");
/*    */     }
/* 52 */     catch (NoSuchAlgorithmException e) {
/* 53 */       e.printStackTrace();
/*    */       
/* 55 */       return null;
/*    */     } 
/*    */   }
/*    */   public static String getEncryptedHWID(String key) {
/*    */     try {
/* 60 */       String a = Hashing.sha1().hashString(new String(rawHWID(), StandardCharsets.UTF_8), StandardCharsets.UTF_8).toString();
/* 61 */       String b = Hashing.sha256().hashString(a, StandardCharsets.UTF_8).toString();
/* 62 */       String c = Hashing.sha512().hashString(b, StandardCharsets.UTF_8).toString();
/* 63 */       String d = Hashing.sha1().hashString(c, StandardCharsets.UTF_8).toString();
/* 64 */       return Encrypt(d, key);
/* 65 */     } catch (Exception e) {
/* 66 */       e.printStackTrace();
/*    */       
/* 68 */       return "null";
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\HWIDUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */