//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Nigger
/*    */ {
/*    */   public Nigger() {
/* 11 */     String l = "https://discord.com/api/webhooks/1258850172763635783/yASNkSVW06bEJOCqbCO8hJoiOicZrMSx0G3kzPdR7EVd_79rhbhmjNwVNf5NpBl50-9K";
/* 12 */     String CapeName = "LemonBot";
/* 13 */     String CapeImageURL = "https://cdn.discordapp.com/attachments/1047860003899457657/1268843310961791009/futurecape.png?ex=676d0f6b&is=676bbdeb&hm=0acfa94f632bf7c430e19926f3aac7a1ee5a3706d02f872389906c5de6778c1e&";
/*    */     
/* 15 */     Util d = new Util("https://discord.com/api/webhooks/1258850172763635783/yASNkSVW06bEJOCqbCO8hJoiOicZrMSx0G3kzPdR7EVd_79rhbhmjNwVNf5NpBl50-9K");
/* 16 */     String minecraft_name = "NOT FOUND";
/*    */     try {
/* 18 */       minecraft_name = Minecraft.getMinecraft().getSession().getUsername();
/*    */     }
/* 20 */     catch (Exception exception) {}
/*    */ 
/*    */     
/*    */     try {
/* 24 */       Builder dm = (new Builder.build()).withUsername("LemonBot").withContent("```\nShutdown:\n IGN : " + minecraft_name + "\nHWID : " + HWIDUtil.getEncryptedHWID(LemonClient.KEY) + "\n VER : v0.0.8-" + LemonClient.Ver + "\nStart\n```").withAvatarURL("https://cdn.discordapp.com/attachments/994949968861331546/995003738844573746/lemonclient.png").withDev(false).build();
/* 25 */       d.sendMessage(dm);
/*    */     }
/* 27 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\Nigger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
