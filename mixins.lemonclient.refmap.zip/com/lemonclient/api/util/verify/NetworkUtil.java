/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraftforge.fml.common.FMLLog;
/*    */ 
/*    */ public class NetworkUtil {
/*    */   public static List<String> getHWIDList() {
/* 12 */     ArrayList<String> HWIDList = new ArrayList<>();
/*    */     
/*    */     try {
/* 15 */       URL url = new URL("https://pastebin.com/raw/srEweZC4");
/* 16 */       BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream())); String inputLine;
/* 17 */       while ((inputLine = in.readLine()) != null) {
/* 18 */         HWIDList.add(inputLine);
/*    */       }
/*    */     }
/* 21 */     catch (Exception e) {
/*    */       
/*    */       try {
/* 24 */         URL url = new URL("https://pastebin.com/raw/srEweZC4");
/* 25 */         BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream())); String inputLine;
/* 26 */         while ((inputLine = in.readLine()) != null) {
/* 27 */           HWIDList.add(inputLine);
/*    */         }
/*    */       }
/* 30 */       catch (Exception ec) {
/* 31 */         FMLLog.log.info("Load HWID Failed!");
/*    */       } 
/*    */     } 
/* 34 */     return HWIDList;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\NetworkUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */