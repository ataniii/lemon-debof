/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ public class NoStackTraceThrowable
/*    */   extends RuntimeException
/*    */ {
/*    */   public NoStackTraceThrowable(String msg) {
/*  7 */     super(msg);
/*  8 */     setStackTrace(new StackTraceElement[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 13 */     return "Oh no!";
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized Throwable fillInStackTrace() {
/* 18 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\NoStackTraceThrowable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */