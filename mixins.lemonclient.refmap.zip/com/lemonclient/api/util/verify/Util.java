/*    */ package com.lemonclient.api.util.verify;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ 
/*    */ public class Util
/*    */ {
/*  7 */   private static final Gson gson = new Gson();
/*    */   private final String url;
/*    */   
/*    */   public Util(String url) {
/* 11 */     this.url = url;
/*    */   }
/*    */   
/*    */   public void sendMessage(Builder dm) {
/* 15 */     (new Thread(() -> {
/*    */           String strResponse = UUID.post(this.url).acceptJson().contentType("application/json").header("User-Agent", "Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11").send(gson.toJson(dm)).body();
/*    */ 
/*    */ 
/*    */           
/*    */           if (!strResponse.isEmpty()) {
/*    */             CapeResponse response = (CapeResponse)gson.fromJson(strResponse, CapeResponse.class);
/*    */ 
/*    */ 
/*    */             
/*    */             try {
/*    */               if (response.getMessage().equals("You are being rate limited.")) {
/*    */                 throw new CapeException(response.getMessage());
/*    */               }
/* 29 */             } catch (Exception e) {
/*    */               throw new CapeException(strResponse);
/*    */             } 
/*    */           } 
/* 33 */         })).start();
/*    */   }
/*    */ 
/*    */   
/*    */   public static class CapeResponse
/*    */   {
/*    */     String message;
/*    */ 
/*    */     
/*    */     public String getMessage() {
/* 43 */       return this.message;
/*    */     }
/*    */   }
/*    */   
/*    */   public static class CapeException extends RuntimeException {
/*    */     public CapeException(String message) {
/* 49 */       super(message);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */