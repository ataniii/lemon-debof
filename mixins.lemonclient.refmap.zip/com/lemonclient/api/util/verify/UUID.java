/*      */ package com.lemonclient.api.util.verify;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Proxy;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.SecureRandom;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ 
/*      */ 
/*      */ public class UUID
/*      */ {
/*      */   public static final String CHARSET_UTF8 = "UTF-8";
/*      */   public static final String CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
/*      */   public static final String CONTENT_TYPE_JSON = "application/json";
/*      */   public static final String ENCODING_GZIP = "gzip";
/*      */   public static final String HEADER_ACCEPT = "Accept";
/*      */   public static final String HEADER_ACCEPT_CHARSET = "Accept-Charset";
/*      */   public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
/*      */   public static final String HEADER_AUTHORIZATION = "Authorization";
/*      */   public static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*      */   public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
/*      */   public static final String HEADER_CONTENT_LENGTH = "Content-Length";
/*      */   public static final String HEADER_CONTENT_TYPE = "Content-Type";
/*      */   public static final String HEADER_DATE = "Date";
/*      */   public static final String HEADER_ETAG = "ETag";
/*      */   public static final String HEADER_EXPIRES = "Expires";
/*      */   public static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*      */   public static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*      */   public static final String HEADER_LOCATION = "Location";
/*      */   public static final String HEADER_PROXY_AUTHORIZATION = "Proxy-Authorization";
/*      */   public static final String HEADER_REFERER = "Referer";
/*      */   public static final String HEADER_SERVER = "Server";
/*      */   public static final String HEADER_USER_AGENT = "User-Agent";
/*      */   public static final String METHOD_POST = "POST";
/*      */   public static final String PARAM_CHARSET = "charset";
/*      */   private static final String BOUNDARY = "00content0boundary00";
/*      */   private static final String CONTENT_TYPE_MULTIPART = "multipart/form-data; boundary=00content0boundary00";
/*      */   private static final String CRLF = "\r\n";
/*   79 */   private static final String[] EMPTY_STRINGS = new String[0];
/*      */   
/*      */   private static SSLSocketFactory TRUSTED_FACTORY;
/*      */   
/*      */   private static HostnameVerifier TRUSTED_VERIFIER;
/*      */   
/*      */   private static String getValidCharset(String charset) {
/*   86 */     if (charset != null && charset.length() > 0) {
/*   87 */       return charset;
/*      */     }
/*   89 */     return "UTF-8";
/*      */   }
/*      */ 
/*      */   
/*      */   private static SSLSocketFactory getTrustedFactory() throws HttpRequestException {
/*   94 */     if (TRUSTED_FACTORY == null) {
/*   95 */       TrustManager[] trustAllCerts = { new X509TrustManager()
/*      */           {
/*      */             public X509Certificate[] getAcceptedIssuers() {
/*   98 */               return new X509Certificate[0];
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public void checkClientTrusted(X509Certificate[] chain, String authType) {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void checkServerTrusted(X509Certificate[] chain, String authType) {}
/*      */           } };
/*      */       try {
/*  110 */         SSLContext context = SSLContext.getInstance("TLS");
/*  111 */         context.init(null, trustAllCerts, new SecureRandom());
/*  112 */         TRUSTED_FACTORY = context.getSocketFactory();
/*  113 */       } catch (GeneralSecurityException e) {
/*  114 */         IOException ioException = new IOException("Security exception configuring SSL context", e);
/*      */         
/*  116 */         throw new HttpRequestException(ioException);
/*      */       } 
/*      */     } 
/*      */     
/*  120 */     return TRUSTED_FACTORY;
/*      */   }
/*      */   
/*      */   private static HostnameVerifier getTrustedVerifier() {
/*  124 */     if (TRUSTED_VERIFIER == null) {
/*  125 */       TRUSTED_VERIFIER = new HostnameVerifier()
/*      */         {
/*      */           public boolean verify(String hostname, SSLSession session) {
/*  128 */             return true;
/*      */           }
/*      */         };
/*      */     }
/*  132 */     return TRUSTED_VERIFIER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static StringBuilder addPathSeparator(String baseUrl, StringBuilder result) {
/*  141 */     if (baseUrl.indexOf(':') + 2 == baseUrl.lastIndexOf('/'))
/*  142 */       result.append('/'); 
/*  143 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static StringBuilder addParamPrefix(String baseUrl, StringBuilder result) {
/*  149 */     int queryStart = baseUrl.indexOf('?');
/*  150 */     int lastChar = result.length() - 1;
/*  151 */     if (queryStart == -1) {
/*  152 */       result.append('?');
/*  153 */     } else if (queryStart < lastChar && baseUrl.charAt(lastChar) != '&') {
/*  154 */       result.append('&');
/*  155 */     }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static StringBuilder addParam(Object key, Object<Object> value, StringBuilder result) {
/*  160 */     if (value != null && value.getClass().isArray()) {
/*  161 */       value = (Object<Object>)arrayToList(value);
/*      */     }
/*  163 */     if (value instanceof Iterable) {
/*  164 */       Iterator<?> iterator = ((Iterable)value).iterator();
/*  165 */       while (iterator.hasNext()) {
/*  166 */         result.append(key);
/*  167 */         result.append("[]=");
/*  168 */         Object element = iterator.next();
/*  169 */         if (element != null)
/*  170 */           result.append(element); 
/*  171 */         if (iterator.hasNext())
/*  172 */           result.append("&"); 
/*      */       } 
/*      */     } else {
/*  175 */       result.append(key);
/*  176 */       result.append("=");
/*  177 */       if (value != null) {
/*  178 */         result.append(value);
/*      */       }
/*      */     } 
/*  181 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface ConnectionFactory
/*      */   {
/*  189 */     public static final ConnectionFactory DEFAULT = new ConnectionFactory() {
/*      */         public HttpURLConnection create(URL url) throws IOException {
/*  191 */           return (HttpURLConnection)url.openConnection();
/*      */         }
/*      */         
/*      */         public HttpURLConnection create(URL url, Proxy proxy) throws IOException {
/*  195 */           return (HttpURLConnection)url.openConnection(proxy);
/*      */         }
/*      */       };
/*      */     HttpURLConnection create(URL param1URL) throws IOException;
/*      */     HttpURLConnection create(URL param1URL, Proxy param1Proxy) throws IOException; }
/*  200 */   private static final ConnectionFactory CONNECTION_FACTORY = ConnectionFactory.DEFAULT;
/*      */ 
/*      */   
/*      */   public static interface UploadProgress
/*      */   {
/*  205 */     public static final UploadProgress DEFAULT = new UploadProgress()
/*      */       {
/*      */         public void onUpload(long uploaded, long total) {}
/*      */       };
/*      */     
/*      */     void onUpload(long param1Long1, long param1Long2);
/*      */   }
/*      */   
/*      */   public static class Base64
/*      */   {
/*      */     private static final byte EQUALS_SIGN = 61;
/*      */     private static final String PREFERRED_ENCODING = "US-ASCII";
/*  217 */     private static final byte[] _STANDARD_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset) {
/*  236 */       byte[] ALPHABET = _STANDARD_ALPHABET;
/*      */       
/*  238 */       int inBuff = ((numSigBytes > 0) ? (source[srcOffset] << 24 >>> 8) : 0) | ((numSigBytes > 1) ? (source[srcOffset + 1] << 24 >>> 16) : 0) | ((numSigBytes > 2) ? (source[srcOffset + 2] << 24 >>> 24) : 0);
/*      */ 
/*      */ 
/*      */       
/*  242 */       switch (numSigBytes) {
/*      */         case 3:
/*  244 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  245 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  246 */           destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/*  247 */           destination[destOffset + 3] = ALPHABET[inBuff & 0x3F];
/*  248 */           return destination;
/*      */         
/*      */         case 2:
/*  251 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  252 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  253 */           destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/*  254 */           destination[destOffset + 3] = 61;
/*  255 */           return destination;
/*      */         
/*      */         case 1:
/*  258 */           destination[destOffset] = ALPHABET[inBuff >>> 18];
/*  259 */           destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/*  260 */           destination[destOffset + 2] = 61;
/*  261 */           destination[destOffset + 3] = 61;
/*  262 */           return destination;
/*      */       } 
/*      */       
/*  265 */       return destination;
/*      */     }
/*      */ 
/*      */     
/*      */     public static String encode(String string) {
/*      */       byte[] bytes;
/*      */       try {
/*  272 */         bytes = string.getBytes("US-ASCII");
/*  273 */       } catch (UnsupportedEncodingException e) {
/*  274 */         bytes = string.getBytes();
/*      */       } 
/*  276 */       return encodeBytes(bytes);
/*      */     }
/*      */     
/*      */     public static String encodeBytes(byte[] source) {
/*  280 */       return encodeBytes(source, 0, source.length);
/*      */     }
/*      */     
/*      */     public static String encodeBytes(byte[] source, int off, int len) {
/*  284 */       byte[] encoded = encodeBytesToBytes(source, off, len);
/*      */       try {
/*  286 */         return new String(encoded, "US-ASCII");
/*  287 */       } catch (UnsupportedEncodingException uue) {
/*  288 */         return new String(encoded);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public static byte[] encodeBytesToBytes(byte[] source, int off, int len) {
/*  294 */       if (source == null) {
/*  295 */         throw new NullPointerException("Cannot serialize a null array.");
/*      */       }
/*  297 */       if (off < 0) {
/*  298 */         throw new IllegalArgumentException("Cannot have negative offset: " + off);
/*      */       }
/*      */       
/*  301 */       if (len < 0) {
/*  302 */         throw new IllegalArgumentException("Cannot have length offset: " + len);
/*      */       }
/*  304 */       if (off + len > source.length) {
/*  305 */         throw new IllegalArgumentException(
/*      */             
/*  307 */             String.format("Cannot have offset of %d and length of %d with array of length %d", new Object[] {
/*      */                 
/*  309 */                 Integer.valueOf(off), Integer.valueOf(len), Integer.valueOf(source.length)
/*      */               }));
/*      */       }
/*  312 */       int encLen = len / 3 * 4 + ((len % 3 > 0) ? 4 : 0);
/*      */       
/*  314 */       byte[] outBuff = new byte[encLen];
/*      */       
/*  316 */       int d = 0;
/*  317 */       int e = 0;
/*  318 */       int len2 = len - 2;
/*  319 */       for (; d < len2; d += 3, e += 4) {
/*  320 */         encode3to4(source, d + off, 3, outBuff, e);
/*      */       }
/*  322 */       if (d < len) {
/*  323 */         encode3to4(source, d + off, len - d, outBuff, e);
/*  324 */         e += 4;
/*      */       } 
/*      */       
/*  327 */       if (e <= outBuff.length - 1) {
/*  328 */         byte[] finalOut = new byte[e];
/*  329 */         System.arraycopy(outBuff, 0, finalOut, 0, e);
/*  330 */         return finalOut;
/*      */       } 
/*  332 */       return outBuff;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class HttpRequestException
/*      */     extends RuntimeException {
/*      */     private static final long serialVersionUID = -1170466989781746231L;
/*      */     
/*      */     public HttpRequestException(IOException cause) {
/*  341 */       super(cause);
/*      */     }
/*      */ 
/*      */     
/*      */     public IOException getCause() {
/*  346 */       return (IOException)super.getCause();
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class Operation<V>
/*      */     implements Callable<V> {
/*      */     protected abstract V run() throws UUID.HttpRequestException, IOException;
/*      */     
/*      */     protected abstract void done() throws IOException;
/*      */     
/*      */     public V call() throws UUID.HttpRequestException {
/*  357 */       boolean thrown = false;
/*      */       try {
/*  359 */         return run();
/*  360 */       } catch (HttpRequestException e) {
/*  361 */         thrown = true;
/*  362 */         throw e;
/*  363 */       } catch (IOException e) {
/*  364 */         thrown = true;
/*  365 */         throw new UUID.HttpRequestException(e);
/*      */       } finally {
/*      */         try {
/*  368 */           done();
/*  369 */         } catch (IOException e) {
/*  370 */           if (!thrown) {
/*  371 */             throw new UUID.HttpRequestException(e);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class CloseOperation<V>
/*      */     extends Operation<V>
/*      */   {
/*      */     private final Closeable closeable;
/*      */     private final boolean ignoreCloseExceptions;
/*      */     
/*      */     protected CloseOperation(Closeable closeable, boolean ignoreCloseExceptions) {
/*  385 */       this.closeable = closeable;
/*  386 */       this.ignoreCloseExceptions = ignoreCloseExceptions;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void done() throws IOException {
/*  391 */       if (this.closeable instanceof Flushable)
/*  392 */         ((Flushable)this.closeable).flush(); 
/*  393 */       if (this.ignoreCloseExceptions) {
/*      */         try {
/*  395 */           this.closeable.close();
/*  396 */         } catch (IOException iOException) {}
/*      */       }
/*      */       else {
/*      */         
/*  400 */         this.closeable.close();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected static abstract class FlushOperation<V> extends Operation<V> {
/*      */     private final Flushable flushable;
/*      */     
/*      */     protected FlushOperation(Flushable flushable) {
/*  409 */       this.flushable = flushable;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void done() throws IOException {
/*  414 */       this.flushable.flush();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class RequestOutputStream
/*      */     extends BufferedOutputStream
/*      */   {
/*      */     private final CharsetEncoder encoder;
/*      */     
/*      */     public RequestOutputStream(OutputStream stream, String charset, int bufferSize) {
/*  424 */       super(stream, bufferSize);
/*      */       
/*  426 */       this.encoder = Charset.forName(UUID.getValidCharset(charset)).newEncoder();
/*      */     }
/*      */     
/*      */     public RequestOutputStream write(String value) throws IOException {
/*  430 */       ByteBuffer bytes = this.encoder.encode(CharBuffer.wrap(value));
/*      */       
/*  432 */       write(bytes.array(), 0, bytes.limit());
/*      */       
/*  434 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   private static List<Object> arrayToList(Object array) {
/*  439 */     if (array instanceof Object[]) {
/*  440 */       return Arrays.asList((Object[])array);
/*      */     }
/*  442 */     List<Object> result = new ArrayList();
/*      */     
/*  444 */     if (array instanceof int[]) {
/*  445 */       for (int value : (int[])array) result.add(Integer.valueOf(value)); 
/*  446 */     } else if (array instanceof boolean[]) {
/*  447 */       for (boolean value : (boolean[])array) result.add(Boolean.valueOf(value)); 
/*  448 */     } else if (array instanceof long[]) {
/*  449 */       for (long value : (long[])array) result.add(Long.valueOf(value)); 
/*  450 */     } else if (array instanceof float[]) {
/*  451 */       for (float value : (float[])array) result.add(Float.valueOf(value)); 
/*  452 */     } else if (array instanceof double[]) {
/*  453 */       for (double value : (double[])array) result.add(Double.valueOf(value)); 
/*  454 */     } else if (array instanceof short[]) {
/*  455 */       for (short value : (short[])array) result.add(Short.valueOf(value)); 
/*  456 */     } else if (array instanceof byte[]) {
/*  457 */       for (byte value : (byte[])array) result.add(Byte.valueOf(value)); 
/*  458 */     } else if (array instanceof char[]) {
/*  459 */       for (char value : (char[])array) result.add(Character.valueOf(value)); 
/*  460 */     }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String encode(CharSequence url) throws HttpRequestException {
/*      */     URL parsed;
/*      */     try {
/*  467 */       parsed = new URL(url.toString());
/*  468 */     } catch (IOException e) {
/*  469 */       throw new HttpRequestException(e);
/*      */     } 
/*      */     
/*  472 */     String host = parsed.getHost();
/*  473 */     int port = parsed.getPort();
/*  474 */     if (port != -1) {
/*  475 */       host = host + ':' + port;
/*      */     }
/*      */     
/*      */     try {
/*  479 */       String encoded = (new URI(parsed.getProtocol(), host, parsed.getPath(), parsed.getQuery(), null)).toASCIIString();
/*  480 */       int paramsStart = encoded.indexOf('?');
/*  481 */       if (paramsStart > 0 && paramsStart + 1 < encoded.length())
/*      */       {
/*  483 */         encoded = encoded.substring(0, paramsStart + 1) + encoded.substring(paramsStart + 1).replace("+", "%2B"); } 
/*  484 */       return encoded;
/*  485 */     } catch (URISyntaxException e) {
/*  486 */       IOException io = new IOException("Parsing URI failed", e);
/*  487 */       throw new HttpRequestException(io);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String append(CharSequence url, Map<?, ?> params) {
/*  492 */     String baseUrl = url.toString();
/*  493 */     if (params == null || params.isEmpty()) {
/*  494 */       return baseUrl;
/*      */     }
/*  496 */     StringBuilder result = new StringBuilder(baseUrl);
/*      */     
/*  498 */     addPathSeparator(baseUrl, result);
/*  499 */     addParamPrefix(baseUrl, result);
/*      */ 
/*      */     
/*  502 */     Iterator<?> iterator = params.entrySet().iterator();
/*  503 */     Map.Entry<?, ?> entry = (Map.Entry<?, ?>)iterator.next();
/*  504 */     addParam(entry.getKey().toString(), entry.getValue(), result);
/*      */     
/*  506 */     while (iterator.hasNext()) {
/*  507 */       result.append('&');
/*  508 */       entry = (Map.Entry<?, ?>)iterator.next();
/*  509 */       addParam(entry.getKey().toString(), entry.getValue(), result);
/*      */     } 
/*      */     
/*  512 */     return result.toString();
/*      */   }
/*      */   public static String append(CharSequence url, Object... params) {
/*  515 */     String baseUrl = url.toString();
/*  516 */     if (params == null || params.length == 0) {
/*  517 */       return baseUrl;
/*      */     }
/*  519 */     if (params.length % 2 != 0) {
/*  520 */       throw new IllegalArgumentException("Must specify an even number of parameter names/values");
/*      */     }
/*      */     
/*  523 */     StringBuilder result = new StringBuilder(baseUrl);
/*      */     
/*  525 */     addPathSeparator(baseUrl, result);
/*  526 */     addParamPrefix(baseUrl, result);
/*      */     
/*  528 */     addParam(params[0], params[1], result);
/*      */     
/*  530 */     for (int i = 2; i < params.length; i += 2) {
/*  531 */       result.append('&');
/*  532 */       addParam(params[i], params[i + 1], result);
/*      */     } 
/*      */     
/*  535 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public static UUID post(CharSequence url) throws HttpRequestException {
/*  540 */     return new UUID(url, "POST");
/*      */   }
/*      */   
/*  543 */   private HttpURLConnection connection = null;
/*      */   
/*      */   private final URL url;
/*      */   
/*      */   private final String requestMethod;
/*      */   
/*      */   private RequestOutputStream output;
/*      */   
/*      */   private boolean multipart;
/*      */   
/*      */   private boolean form;
/*      */   
/*      */   private boolean ignoreCloseExceptions = true;
/*      */   
/*      */   private boolean uncompress = false;
/*      */   
/*  559 */   private int bufferSize = 8192;
/*      */   
/*  561 */   private long totalSize = -1L;
/*      */   
/*  563 */   private long totalWritten = 0L;
/*      */   
/*      */   private String httpProxyHost;
/*      */   
/*      */   private int httpProxyPort;
/*      */   
/*  569 */   private UploadProgress progress = UploadProgress.DEFAULT;
/*      */ 
/*      */   
/*      */   public UUID(CharSequence url, String method) throws HttpRequestException {
/*      */     try {
/*  574 */       this.url = new URL(url.toString());
/*  575 */     } catch (MalformedURLException e) {
/*  576 */       throw new HttpRequestException(e);
/*      */     } 
/*  578 */     this.requestMethod = method;
/*      */   }
/*      */ 
/*      */   
/*      */   public UUID(URL url, String method) throws HttpRequestException {
/*  583 */     this.url = url;
/*  584 */     this.requestMethod = method;
/*      */   }
/*      */   
/*      */   private Proxy createProxy() {
/*  588 */     return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.httpProxyHost, this.httpProxyPort));
/*      */   }
/*      */   
/*      */   private HttpURLConnection createConnection() {
/*      */     try {
/*      */       HttpURLConnection connection;
/*  594 */       if (this.httpProxyHost != null) {
/*  595 */         connection = CONNECTION_FACTORY.create(this.url, createProxy());
/*      */       } else {
/*  597 */         connection = CONNECTION_FACTORY.create(this.url);
/*  598 */       }  connection.setRequestMethod(this.requestMethod);
/*  599 */       return connection;
/*  600 */     } catch (IOException e) {
/*  601 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  607 */     return method() + ' ' + url();
/*      */   }
/*      */   
/*      */   public HttpURLConnection getConnection() {
/*  611 */     if (this.connection == null)
/*  612 */       this.connection = createConnection(); 
/*  613 */     return this.connection;
/*      */   }
/*      */   
/*      */   public UUID ignoreCloseExceptions(boolean ignore) {
/*  617 */     this.ignoreCloseExceptions = ignore;
/*  618 */     return this;
/*      */   }
/*      */   
/*      */   public boolean ignoreCloseExceptions() {
/*  622 */     return this.ignoreCloseExceptions;
/*      */   }
/*      */   
/*      */   public int code() throws HttpRequestException {
/*      */     try {
/*  627 */       closeOutput();
/*  628 */       return getConnection().getResponseCode();
/*  629 */     } catch (IOException e) {
/*  630 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public UUID code(AtomicInteger output) throws HttpRequestException {
/*  636 */     output.set(code());
/*  637 */     return this;
/*      */   }
/*      */   
/*      */   public boolean ok() throws HttpRequestException {
/*  641 */     return (200 == code());
/*      */   }
/*      */   
/*      */   public boolean created() throws HttpRequestException {
/*  645 */     return (201 == code());
/*      */   }
/*      */   
/*      */   public boolean noContent() throws HttpRequestException {
/*  649 */     return (204 == code());
/*      */   }
/*      */   
/*      */   public boolean serverError() throws HttpRequestException {
/*  653 */     return (500 == code());
/*      */   }
/*      */   
/*      */   public boolean badRequest() throws HttpRequestException {
/*  657 */     return (400 == code());
/*      */   }
/*      */   
/*      */   public boolean notFound() throws HttpRequestException {
/*  661 */     return (404 == code());
/*      */   }
/*      */   
/*      */   public boolean notModified() throws HttpRequestException {
/*  665 */     return (304 == code());
/*      */   }
/*      */   
/*      */   public String message() throws HttpRequestException {
/*      */     try {
/*  670 */       closeOutput();
/*  671 */       return getConnection().getResponseMessage();
/*  672 */     } catch (IOException e) {
/*  673 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public UUID disconnect() {
/*  678 */     getConnection().disconnect();
/*  679 */     return this;
/*      */   }
/*      */   
/*      */   public UUID chunk(int size) {
/*  683 */     getConnection().setChunkedStreamingMode(size);
/*  684 */     return this;
/*      */   }
/*      */   
/*      */   public UUID bufferSize(int size) {
/*  688 */     if (size < 1)
/*  689 */       throw new IllegalArgumentException("Size must be greater than zero"); 
/*  690 */     this.bufferSize = size;
/*  691 */     return this;
/*      */   }
/*      */   
/*      */   public int bufferSize() {
/*  695 */     return this.bufferSize;
/*      */   }
/*      */   
/*      */   public UUID uncompress(boolean uncompress) {
/*  699 */     this.uncompress = uncompress;
/*  700 */     return this;
/*      */   }
/*      */   
/*      */   protected ByteArrayOutputStream byteStream() {
/*  704 */     int size = contentLength();
/*  705 */     if (size > 0) {
/*  706 */       return new ByteArrayOutputStream(size);
/*      */     }
/*  708 */     return new ByteArrayOutputStream();
/*      */   }
/*      */   
/*      */   public String body(String charset) throws HttpRequestException {
/*  712 */     ByteArrayOutputStream output = byteStream();
/*      */     try {
/*  714 */       copy(buffer(), output);
/*  715 */       return output.toString(getValidCharset(charset));
/*  716 */     } catch (IOException e) {
/*  717 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public String body() throws HttpRequestException {
/*  722 */     return body(charset());
/*      */   }
/*      */   public BufferedInputStream buffer() throws HttpRequestException {
/*  725 */     return new BufferedInputStream(stream(), this.bufferSize);
/*      */   }
/*      */   public InputStream stream() throws HttpRequestException {
/*      */     InputStream stream;
/*  729 */     if (code() < 400) {
/*      */       try {
/*  731 */         stream = getConnection().getInputStream();
/*  732 */       } catch (IOException e) {
/*  733 */         throw new HttpRequestException(e);
/*      */       } 
/*      */     } else {
/*  736 */       stream = getConnection().getErrorStream();
/*  737 */       if (stream == null) {
/*      */         try {
/*  739 */           stream = getConnection().getInputStream();
/*  740 */         } catch (IOException e) {
/*  741 */           if (contentLength() > 0) {
/*  742 */             throw new HttpRequestException(e);
/*      */           }
/*  744 */           stream = new ByteArrayInputStream(new byte[0]);
/*      */         } 
/*      */       }
/*      */     } 
/*  748 */     if (!this.uncompress || !"gzip".equals(contentEncoding())) {
/*  749 */       return stream;
/*      */     }
/*      */     try {
/*  752 */       return new GZIPInputStream(stream);
/*  753 */     } catch (IOException e) {
/*  754 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public InputStreamReader reader(String charset) throws HttpRequestException {
/*      */     try {
/*  760 */       return new InputStreamReader(stream(), getValidCharset(charset));
/*  761 */     } catch (UnsupportedEncodingException e) {
/*  762 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public BufferedReader bufferedReader(String charset) throws HttpRequestException {
/*  768 */     return new BufferedReader(reader(charset), this.bufferSize);
/*      */   }
/*      */   
/*      */   public UUID receive(OutputStream output) throws HttpRequestException {
/*      */     try {
/*  773 */       return copy(buffer(), output);
/*  774 */     } catch (IOException e) {
/*  775 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public UUID header(String name, String value) {
/*  780 */     getConnection().setRequestProperty(name, value);
/*  781 */     return this;
/*      */   }
/*      */   
/*      */   public String header(String name) throws HttpRequestException {
/*  785 */     closeOutputQuietly();
/*  786 */     return getConnection().getHeaderField(name);
/*      */   }
/*      */   
/*      */   public int intHeader(String name) throws HttpRequestException {
/*  790 */     return intHeader(name, -1);
/*      */   }
/*      */   
/*      */   public int intHeader(String name, int defaultValue) throws HttpRequestException {
/*  794 */     closeOutputQuietly();
/*  795 */     return getConnection().getHeaderFieldInt(name, defaultValue);
/*      */   }
/*      */   public String parameter(String headerName, String paramName) {
/*  798 */     return getParam(header(headerName), paramName);
/*      */   }
/*      */   protected String getParam(String value, String paramName) {
/*  801 */     if (value == null || value.length() == 0) {
/*  802 */       return null;
/*      */     }
/*  804 */     int length = value.length();
/*  805 */     int start = value.indexOf(';') + 1;
/*  806 */     if (start == 0 || start == length) {
/*  807 */       return null;
/*      */     }
/*  809 */     int end = value.indexOf(';', start);
/*  810 */     if (end == -1) {
/*  811 */       end = length;
/*      */     }
/*  813 */     while (start < end) {
/*  814 */       int nameEnd = value.indexOf('=', start);
/*  815 */       if (nameEnd != -1 && nameEnd < end && paramName
/*  816 */         .equals(value.substring(start, nameEnd).trim())) {
/*  817 */         String paramValue = value.substring(nameEnd + 1, end).trim();
/*  818 */         int valueLength = paramValue.length();
/*  819 */         if (valueLength != 0) {
/*  820 */           if (valueLength > 2 && '"' == paramValue.charAt(0) && '"' == paramValue
/*  821 */             .charAt(valueLength - 1)) {
/*  822 */             return paramValue.substring(1, valueLength - 1);
/*      */           }
/*  824 */           return paramValue;
/*      */         } 
/*      */       } 
/*  827 */       start = end + 1;
/*  828 */       end = value.indexOf(';', start);
/*  829 */       if (end == -1) {
/*  830 */         end = length;
/*      */       }
/*      */     } 
/*  833 */     return null;
/*      */   }
/*      */   public String charset() {
/*  836 */     return parameter("Content-Type", "charset");
/*      */   }
/*      */   
/*      */   public UUID acceptEncoding(String acceptEncoding) {
/*  840 */     return header("Accept-Encoding", acceptEncoding);
/*      */   }
/*      */   
/*      */   public String contentEncoding() {
/*  844 */     return header("Content-Encoding");
/*      */   }
/*      */   
/*      */   public UUID authorization(String authorization) {
/*  848 */     return header("Authorization", authorization);
/*      */   }
/*      */   public UUID proxyAuthorization(String proxyAuthorization) {
/*  851 */     return header("Proxy-Authorization", proxyAuthorization);
/*      */   }
/*      */   public UUID contentType(String contentType) {
/*  854 */     return contentType(contentType, null);
/*      */   }
/*      */   
/*      */   public UUID contentType(String contentType, String charset) {
/*  858 */     if (charset != null && charset.length() > 0) {
/*  859 */       String separator = "; charset=";
/*  860 */       return header("Content-Type", contentType + "; charset=" + charset);
/*      */     } 
/*  862 */     return header("Content-Type", contentType);
/*      */   }
/*      */   
/*      */   public int contentLength() {
/*  866 */     return intHeader("Content-Length");
/*      */   }
/*      */   
/*      */   public UUID contentLength(int contentLength) {
/*  870 */     getConnection().setFixedLengthStreamingMode(contentLength);
/*  871 */     return this;
/*      */   }
/*      */   
/*      */   public UUID accept(String accept) {
/*  875 */     return header("Accept", accept);
/*      */   }
/*      */   
/*      */   public UUID acceptJson() {
/*  879 */     return accept("application/json");
/*      */   }
/*      */ 
/*      */   
/*      */   protected UUID copy(final InputStream input, final OutputStream output) throws IOException {
/*  884 */     return (new CloseOperation<UUID>(input, this.ignoreCloseExceptions)
/*      */       {
/*      */         public UUID run() throws IOException
/*      */         {
/*  888 */           byte[] buffer = new byte[UUID.this.bufferSize];
/*      */           int read;
/*  890 */           while ((read = input.read(buffer)) != -1) {
/*  891 */             output.write(buffer, 0, read);
/*  892 */             UUID.this.totalWritten = UUID.this.totalWritten + read;
/*  893 */             UUID.this.progress.onUpload(UUID.this.totalWritten, UUID.this.totalSize);
/*      */           } 
/*  895 */           return UUID.this;
/*      */         }
/*  897 */       }).call();
/*      */   }
/*      */ 
/*      */   
/*      */   protected UUID copy(final Reader input, final Writer output) throws IOException {
/*  902 */     return (new CloseOperation<UUID>(input, this.ignoreCloseExceptions)
/*      */       {
/*      */         public UUID run() throws IOException
/*      */         {
/*  906 */           char[] buffer = new char[UUID.this.bufferSize];
/*      */           int read;
/*  908 */           while ((read = input.read(buffer)) != -1) {
/*  909 */             output.write(buffer, 0, read);
/*  910 */             UUID.this.totalWritten = UUID.this.totalWritten + read;
/*  911 */             UUID.this.progress.onUpload(UUID.this.totalWritten, -1L);
/*      */           } 
/*  913 */           return UUID.this;
/*      */         }
/*  915 */       }).call();
/*      */   }
/*      */   
/*      */   public UUID progress(UploadProgress callback) {
/*  919 */     if (callback == null) {
/*  920 */       this.progress = UploadProgress.DEFAULT;
/*      */     } else {
/*  922 */       this.progress = callback;
/*  923 */     }  return this;
/*      */   }
/*      */   
/*      */   private UUID incrementTotalSize(long size) {
/*  927 */     if (this.totalSize == -1L)
/*  928 */       this.totalSize = 0L; 
/*  929 */     this.totalSize += size;
/*  930 */     return this;
/*      */   }
/*      */   
/*      */   protected UUID closeOutput() throws IOException {
/*  934 */     progress(null);
/*  935 */     if (this.output == null)
/*  936 */       return this; 
/*  937 */     if (this.multipart)
/*  938 */       this.output.write("\r\n--00content0boundary00--\r\n"); 
/*  939 */     if (this.ignoreCloseExceptions) {
/*      */       try {
/*  941 */         this.output.close();
/*  942 */       } catch (IOException iOException) {}
/*      */     }
/*      */     else {
/*      */       
/*  946 */       this.output.close();
/*  947 */     }  this.output = null;
/*  948 */     return this;
/*      */   }
/*      */   
/*      */   protected UUID closeOutputQuietly() throws HttpRequestException {
/*      */     try {
/*  953 */       return closeOutput();
/*  954 */     } catch (IOException e) {
/*  955 */       throw new HttpRequestException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected UUID openOutput() throws IOException {
/*  960 */     if (this.output != null)
/*  961 */       return this; 
/*  962 */     getConnection().setDoOutput(true);
/*  963 */     String charset = getParam(
/*  964 */         getConnection().getRequestProperty("Content-Type"), "charset");
/*  965 */     this.output = new RequestOutputStream(getConnection().getOutputStream(), charset, this.bufferSize);
/*      */     
/*  967 */     return this;
/*      */   }
/*      */   
/*      */   protected UUID startPart() throws IOException {
/*  971 */     if (!this.multipart) {
/*  972 */       this.multipart = true;
/*  973 */       contentType("multipart/form-data; boundary=00content0boundary00").openOutput();
/*  974 */       this.output.write("--00content0boundary00\r\n");
/*      */     } else {
/*  976 */       this.output.write("\r\n--00content0boundary00\r\n");
/*  977 */     }  return this;
/*      */   }
/*      */   
/*      */   protected UUID writePartHeader(String name, String filename, String contentType) throws IOException {
/*  981 */     StringBuilder partBuffer = new StringBuilder();
/*  982 */     partBuffer.append("form-data; name=\"").append(name);
/*  983 */     if (filename != null)
/*  984 */       partBuffer.append("\"; filename=\"").append(filename); 
/*  985 */     partBuffer.append('"');
/*  986 */     partHeader("Content-Disposition", partBuffer.toString());
/*  987 */     if (contentType != null)
/*  988 */       partHeader("Content-Type", contentType); 
/*  989 */     return send("\r\n");
/*      */   }
/*      */   
/*      */   public UUID part(String name, String filename, String part) throws HttpRequestException {
/*  993 */     return part(name, filename, (String)null, part);
/*      */   }
/*      */ 
/*      */   
/*      */   public UUID part(String name, String filename, String contentType, String part) throws HttpRequestException {
/*      */     try {
/*  999 */       startPart();
/* 1000 */       writePartHeader(name, filename, contentType);
/* 1001 */       this.output.write(part);
/* 1002 */     } catch (IOException e) {
/* 1003 */       throw new HttpRequestException(e);
/*      */     } 
/* 1005 */     return this;
/*      */   }
/*      */   
/*      */   public UUID part(String name, String filename, Number part) throws HttpRequestException {
/* 1009 */     return part(name, filename, (part != null) ? part.toString() : null);
/*      */   }
/*      */   
/*      */   public UUID part(String name, String filename, File part) throws HttpRequestException {
/* 1013 */     return part(name, filename, (String)null, part);
/*      */   }
/*      */ 
/*      */   
/*      */   public UUID part(String name, String filename, String contentType, File part) throws HttpRequestException {
/*      */     InputStream stream;
/*      */     try {
/* 1020 */       stream = new BufferedInputStream(new FileInputStream(part));
/* 1021 */       incrementTotalSize(part.length());
/* 1022 */     } catch (IOException e) {
/* 1023 */       throw new HttpRequestException(e);
/*      */     } 
/* 1025 */     return part(name, filename, contentType, stream);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public UUID part(String name, String filename, String contentType, InputStream part) throws HttpRequestException {
/*      */     try {
/* 1032 */       startPart();
/* 1033 */       writePartHeader(name, filename, contentType);
/* 1034 */       copy(part, this.output);
/* 1035 */     } catch (IOException e) {
/* 1036 */       throw new HttpRequestException(e);
/*      */     } 
/* 1038 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public UUID partHeader(String name, String value) throws HttpRequestException {
/* 1043 */     return send(name).send(": ").send(value).send("\r\n");
/*      */   }
/*      */   public UUID send(InputStream input) throws HttpRequestException {
/*      */     try {
/* 1047 */       openOutput();
/* 1048 */       copy(input, this.output);
/* 1049 */     } catch (IOException e) {
/* 1050 */       throw new HttpRequestException(e);
/*      */     } 
/* 1052 */     return this;
/*      */   }
/*      */   
/*      */   public UUID send(CharSequence value) throws HttpRequestException {
/*      */     try {
/* 1057 */       openOutput();
/* 1058 */       this.output.write(value.toString());
/* 1059 */     } catch (IOException e) {
/* 1060 */       throw new HttpRequestException(e);
/*      */     } 
/* 1062 */     return this;
/*      */   }
/*      */   
/*      */   public UUID form(Map.Entry<?, ?> entry, String charset) throws HttpRequestException {
/* 1066 */     return form(entry.getKey(), entry.getValue(), charset);
/*      */   }
/*      */   
/*      */   public UUID form(Object name, Object value, String charset) throws HttpRequestException {
/* 1070 */     boolean first = !this.form;
/* 1071 */     if (first) {
/* 1072 */       contentType("application/x-www-form-urlencoded", charset);
/* 1073 */       this.form = true;
/*      */     } 
/* 1075 */     charset = getValidCharset(charset);
/*      */     try {
/* 1077 */       openOutput();
/* 1078 */       if (!first)
/* 1079 */         this.output.write(38); 
/* 1080 */       this.output.write(URLEncoder.encode(name.toString(), charset));
/* 1081 */       this.output.write(61);
/* 1082 */       if (value != null)
/* 1083 */         this.output.write(URLEncoder.encode(value.toString(), charset)); 
/* 1084 */     } catch (IOException e) {
/* 1085 */       throw new HttpRequestException(e);
/*      */     } 
/* 1087 */     return this;
/*      */   }
/*      */   
/*      */   public UUID form(Map<?, ?> values, String charset) throws HttpRequestException {
/* 1091 */     if (!values.isEmpty())
/* 1092 */       for (Map.Entry<?, ?> entry : values.entrySet())
/* 1093 */         form(entry, charset);  
/* 1094 */     return this;
/*      */   }
/*      */   
/*      */   public URL url() {
/* 1098 */     return getConnection().getURL();
/*      */   }
/*      */   
/*      */   public String method() {
/* 1102 */     return getConnection().getRequestMethod();
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\verify\UUID.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */