//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ public class FramebufferShader
/*    */   extends Shader {
/*    */   protected Framebuffer framebuffer;
/*    */   protected float red;
/*    */   protected float green;
/*    */   protected float blue;
/*    */   protected float alpha;
/*    */   protected float radius;
/*    */   protected float quality;
/*    */   protected boolean entityShadows;
/* 22 */   protected Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   public FramebufferShader(String fragmentShader) {
/* 25 */     super(fragmentShader);
/* 26 */     this.alpha = 1.0F;
/* 27 */     this.radius = 2.0F;
/* 28 */     this.quality = 1.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public void startDraw(float partialTicks) {
/* 33 */     GlStateManager.enableAlpha();
/* 34 */     GlStateManager.pushMatrix();
/* 35 */     GlStateManager.pushAttrib();
/* 36 */     (this.framebuffer = setupFrameBuffer(this.framebuffer)).framebufferClear();
/* 37 */     this.framebuffer.bindFramebuffer(true);
/* 38 */     this.entityShadows = this.mc.gameSettings.entityShadows;
/* 39 */     this.mc.gameSettings.entityShadows = false;
/* 40 */     this.mc.entityRenderer.setupCameraTransform(partialTicks, 0);
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate) {
/* 44 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 45 */     this.framebuffer.unbindFramebuffer();
/* 46 */     GL11.glEnable(3042);
/* 47 */     GL11.glBlendFunc(770, 771);
/* 48 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 49 */     this.red = color.getRed() / 255.0F;
/* 50 */     this.green = color.getGreen() / 255.0F;
/* 51 */     this.blue = color.getBlue() / 255.0F;
/* 52 */     this.alpha = color.getAlpha() / 255.0F;
/* 53 */     this.radius = radius;
/* 54 */     this.quality = quality;
/* 55 */     this.mc.entityRenderer.disableLightmap();
/* 56 */     RenderHelper.disableStandardItemLighting();
/* 57 */     startShader(duplicate);
/* 58 */     this.mc.entityRenderer.setupOverlayRendering();
/* 59 */     drawFramebuffer(this.framebuffer);
/* 60 */     stopShader();
/* 61 */     this.mc.entityRenderer.disableLightmap();
/* 62 */     GlStateManager.popMatrix();
/* 63 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public Framebuffer setupFrameBuffer(Framebuffer frameBuffer) {
/* 67 */     if (frameBuffer == null) {
/* 68 */       return new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
/*    */     }
/* 70 */     if (frameBuffer.framebufferWidth != this.mc.displayWidth || frameBuffer.framebufferHeight != this.mc.displayHeight) {
/* 71 */       frameBuffer.deleteFramebuffer();
/* 72 */       frameBuffer = new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
/*    */     } 
/* 74 */     return frameBuffer;
/*    */   }
/*    */   
/*    */   public void drawFramebuffer(Framebuffer framebuffer) {
/* 78 */     ScaledResolution scaledResolution = new ScaledResolution(this.mc);
/* 79 */     GL11.glBindTexture(3553, framebuffer.framebufferTexture);
/* 80 */     GL11.glBegin(7);
/* 81 */     GL11.glTexCoord2d(0.0D, 1.0D);
/* 82 */     GL11.glVertex2d(0.0D, 0.0D);
/* 83 */     GL11.glTexCoord2d(0.0D, 0.0D);
/* 84 */     GL11.glVertex2d(0.0D, scaledResolution.getScaledHeight());
/* 85 */     GL11.glTexCoord2d(1.0D, 0.0D);
/* 86 */     GL11.glVertex2d(scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
/* 87 */     GL11.glTexCoord2d(1.0D, 1.0D);
/* 88 */     GL11.glVertex2d(scaledResolution.getScaledWidth(), 0.0D);
/* 89 */     GL11.glEnd();
/* 90 */     GL20.glUseProgram(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\FramebufferShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
