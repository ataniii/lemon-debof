/*     */ package com.lemonclient.api.util.render.shaders;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.lwjgl.opengl.ARBShaderObjects;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public class Shader
/*     */ {
/*     */   protected int program;
/*     */   protected Map<String, Integer> uniformsMap;
/*     */   
/*     */   public Shader(String fragmentShader) {
/*     */     int vertexShaderID, fragmentShaderID;
/*     */     try {
/*  20 */       InputStream vertexStream = getClass().getResourceAsStream("/assets/lemonclient/shaders/vertex.vert");
/*  21 */       vertexShaderID = createShader(IOUtils.toString(vertexStream), 35633);
/*  22 */       IOUtils.closeQuietly(vertexStream);
/*  23 */       InputStream fragmentStream = getClass().getResourceAsStream("/assets/lemonclient/shaders/fragment/" + fragmentShader);
/*  24 */       fragmentShaderID = createShader(IOUtils.toString(fragmentStream), 35632);
/*  25 */       IOUtils.closeQuietly(fragmentStream);
/*     */     }
/*  27 */     catch (Exception e) {
/*  28 */       e.printStackTrace();
/*     */       return;
/*     */     } 
/*  31 */     if (vertexShaderID == 0 || fragmentShaderID == 0) {
/*     */       return;
/*     */     }
/*  34 */     this.program = ARBShaderObjects.glCreateProgramObjectARB();
/*  35 */     if (this.program == 0) {
/*     */       return;
/*     */     }
/*  38 */     ARBShaderObjects.glAttachObjectARB(this.program, vertexShaderID);
/*  39 */     ARBShaderObjects.glAttachObjectARB(this.program, fragmentShaderID);
/*  40 */     ARBShaderObjects.glLinkProgramARB(this.program);
/*  41 */     ARBShaderObjects.glValidateProgramARB(this.program);
/*     */   }
/*     */   
/*     */   public void startShader(float duplicate) {
/*  45 */     GL11.glPushMatrix();
/*  46 */     GL20.glUseProgram(this.program);
/*  47 */     if (this.uniformsMap == null) {
/*  48 */       this.uniformsMap = new HashMap<>();
/*  49 */       setupUniforms();
/*     */     } 
/*  51 */     updateUniforms(duplicate);
/*     */   }
/*     */   
/*     */   public void stopShader() {
/*  55 */     GL20.glUseProgram(0);
/*  56 */     GL11.glPopMatrix();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupUniforms() {}
/*     */ 
/*     */   
/*     */   public void updateUniforms(float duplicate) {}
/*     */ 
/*     */   
/*     */   private int createShader(String shaderSource, int shaderType) {
/*  68 */     int shader = 0;
/*     */     try {
/*  70 */       shader = ARBShaderObjects.glCreateShaderObjectARB(shaderType);
/*  71 */       if (shader == 0) {
/*  72 */         return 0;
/*     */       }
/*  74 */       ARBShaderObjects.glShaderSourceARB(shader, shaderSource);
/*  75 */       ARBShaderObjects.glCompileShaderARB(shader);
/*  76 */       if (ARBShaderObjects.glGetObjectParameteriARB(shader, 35713) == 0) {
/*  77 */         throw new RuntimeException("Error creating shader: " + getLogInfo(shader));
/*     */       }
/*  79 */       return shader;
/*     */     }
/*  81 */     catch (Exception e) {
/*  82 */       ARBShaderObjects.glDeleteObjectARB(shader);
/*  83 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getLogInfo(int i) {
/*  88 */     return ARBShaderObjects.glGetInfoLogARB(i, ARBShaderObjects.glGetObjectParameteriARB(i, 35716));
/*     */   }
/*     */   
/*     */   public void setUniform(String uniformName, int location) {
/*  92 */     this.uniformsMap.put(uniformName, Integer.valueOf(location));
/*     */   }
/*     */   
/*     */   public void setupUniform(String uniformName) {
/*  96 */     setUniform(uniformName, GL20.glGetUniformLocation(this.program, uniformName));
/*     */   }
/*     */   
/*     */   public int getUniform(String uniformName) {
/* 100 */     return ((Integer)this.uniformsMap.get(uniformName)).intValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\Shader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */