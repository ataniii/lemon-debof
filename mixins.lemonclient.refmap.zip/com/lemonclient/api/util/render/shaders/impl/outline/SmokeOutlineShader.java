//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class SmokeOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public SmokeOutlineShader() {
/*  20 */     super("smokeOutline.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("divider");
/*  27 */     setupUniform("radius");
/*  28 */     setupUniform("maxSample");
/*  29 */     setupUniform("alpha0");
/*  30 */     setupUniform("resolution");
/*  31 */     setupUniform("time");
/*  32 */     setupUniform("first");
/*  33 */     setupUniform("second");
/*  34 */     setupUniform("third");
/*  35 */     setupUniform("oct");
/*     */   }
/*     */   
/*     */   public void updateUniforms(Color first, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color second, Color third, int oct) {
/*  39 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  40 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  41 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  42 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  43 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  44 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  45 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  46 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  47 */     GL20.glUniform4f(getUniform("first"), first.getRed() / 255.0F * 5.0F, first.getGreen() / 255.0F * 5.0F, first.getBlue() / 255.0F * 5.0F, first.getAlpha() / 255.0F);
/*  48 */     GL20.glUniform3f(getUniform("second"), second.getRed() / 255.0F * 5.0F, second.getGreen() / 255.0F * 5.0F, second.getBlue() / 255.0F * 5.0F);
/*  49 */     GL20.glUniform3f(getUniform("third"), third.getRed() / 255.0F * 5.0F, third.getGreen() / 255.0F * 5.0F, third.getBlue() / 255.0F * 5.0F);
/*  50 */     GL20.glUniform1i(getUniform("oct"), oct);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color second, Color third, int oct) {
/*  55 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  56 */     this.framebuffer.unbindFramebuffer();
/*  57 */     GL11.glEnable(3042);
/*  58 */     GL11.glBlendFunc(770, 771);
/*  59 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  60 */     this.mc.entityRenderer.disableLightmap();
/*  61 */     RenderHelper.disableStandardItemLighting();
/*  62 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, second, third, oct);
/*  63 */     this.mc.entityRenderer.setupOverlayRendering();
/*  64 */     drawFramebuffer(this.framebuffer);
/*  65 */     stopShader();
/*  66 */     this.mc.entityRenderer.disableLightmap();
/*  67 */     GlStateManager.popMatrix();
/*  68 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color second, Color third, int oct, Predicate<Boolean> fill) {
/*  72 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  73 */     this.framebuffer.unbindFramebuffer();
/*  74 */     GL11.glEnable(3042);
/*  75 */     GL11.glBlendFunc(770, 771);
/*  76 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  77 */     this.mc.entityRenderer.disableLightmap();
/*  78 */     RenderHelper.disableStandardItemLighting();
/*  79 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, second, third, oct);
/*  80 */     this.mc.entityRenderer.setupOverlayRendering();
/*  81 */     drawFramebuffer(this.framebuffer);
/*  82 */     fill.test(Boolean.valueOf(false));
/*  83 */     drawFramebuffer(this.framebuffer);
/*  84 */     stopShader();
/*  85 */     this.mc.entityRenderer.disableLightmap();
/*  86 */     GlStateManager.popMatrix();
/*  87 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color second, Color third, int oct) {
/*  91 */     GL11.glPushMatrix();
/*  92 */     GL20.glUseProgram(this.program);
/*  93 */     if (this.uniformsMap == null) {
/*  94 */       this.uniformsMap = new HashMap<>();
/*  95 */       setupUniforms();
/*     */     } 
/*  97 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, second, third, oct);
/*     */   }
/*     */ 
/*     */   
/* 101 */   public static final SmokeOutlineShader INSTANCE = new SmokeOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 105 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\SmokeOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
