//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlowShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public FlowShader() {
/* 19 */     super("flow.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("color");
/* 26 */     setupUniform("iterations");
/* 27 */     setupUniform("formuparam2");
/* 28 */     setupUniform("stepsize");
/* 29 */     setupUniform("volsteps");
/* 30 */     setupUniform("zoom");
/* 31 */     setupUniform("tile");
/* 32 */     setupUniform("distfading");
/* 33 */     setupUniform("saturation");
/* 34 */     setupUniform("fadeBol");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/* 38 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 39 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 40 */     GL20.glUniform4f(getUniform("color"), red, green, blue, alpha);
/* 41 */     GL20.glUniform1i(getUniform("iterations"), iteractions);
/* 42 */     GL20.glUniform1f(getUniform("formuparam2"), formuparam2);
/* 43 */     GL20.glUniform1i(getUniform("volsteps"), (int)volumSteps);
/* 44 */     GL20.glUniform1f(getUniform("stepsize"), stepSize);
/* 45 */     GL20.glUniform1f(getUniform("zoom"), zoom);
/* 46 */     GL20.glUniform1f(getUniform("tile"), title);
/* 47 */     GL20.glUniform1f(getUniform("distfading"), distfading);
/* 48 */     GL20.glUniform1f(getUniform("saturation"), saturation);
/*    */     
/* 50 */     GL20.glUniform1i(getUniform("fadeBol"), fade);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/* 56 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 57 */     this.framebuffer.unbindFramebuffer();
/* 58 */     GL11.glEnable(3042);
/* 59 */     GL11.glBlendFunc(770, 771);
/* 60 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 61 */     this.radius = radius;
/* 62 */     this.quality = quality;
/* 63 */     this.mc.entityRenderer.disableLightmap();
/* 64 */     RenderHelper.disableStandardItemLighting();
/* 65 */     GL11.glPushMatrix();
/* 66 */     startShader(duplicate, red, green, blue, alpha, iteractions, formuparam2, zoom, volumSteps, stepSize, title, distfading, saturation, cloud, fade);
/* 67 */     this.mc.entityRenderer.setupOverlayRendering();
/* 68 */     drawFramebuffer(this.framebuffer);
/* 69 */     stopShader();
/* 70 */     this.mc.entityRenderer.disableLightmap();
/* 71 */     GlStateManager.popMatrix();
/* 72 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/* 76 */     GL20.glUseProgram(this.program);
/* 77 */     if (this.uniformsMap == null) {
/* 78 */       this.uniformsMap = new HashMap<>();
/* 79 */       setupUniforms();
/*    */     } 
/* 81 */     updateUniforms(duplicate, red, green, blue, alpha, iteractions, formuparam2, zoom, volumSteps, stepSize, title, distfading, saturation, cloud, fade);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 86 */   public static final FlowShader INSTANCE = new FlowShader();
/*    */   public float time;
/*    */   
/*    */   public void update(double speed) {
/* 90 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\FlowShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
