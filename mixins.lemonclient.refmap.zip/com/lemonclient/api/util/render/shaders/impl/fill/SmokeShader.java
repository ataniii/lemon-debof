//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SmokeShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public SmokeShader() {
/* 19 */     super("smoke.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("first");
/* 26 */     setupUniform("second");
/* 27 */     setupUniform("third");
/* 28 */     setupUniform("oct");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, Color first, Color second, Color third, int oct) {
/* 32 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 33 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 34 */     GL20.glUniform4f(getUniform("first"), first.getRed() / 255.0F * 5.0F, first.getGreen() / 255.0F * 5.0F, first.getBlue() / 255.0F * 5.0F, first.getAlpha() / 255.0F);
/* 35 */     GL20.glUniform3f(getUniform("second"), second.getRed() / 255.0F * 5.0F, second.getGreen() / 255.0F * 5.0F, second.getBlue() / 255.0F * 5.0F);
/* 36 */     GL20.glUniform3f(getUniform("third"), third.getRed() / 255.0F * 5.0F, third.getGreen() / 255.0F * 5.0F, third.getBlue() / 255.0F * 5.0F);
/* 37 */     GL20.glUniform1i(getUniform("oct"), oct);
/*    */   }
/*    */   
/* 40 */   public static final SmokeShader INSTANCE = new SmokeShader();
/*    */   public float time;
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate, Color first, Color second, Color third, int oct) {
/* 44 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 45 */     this.framebuffer.unbindFramebuffer();
/* 46 */     GL11.glEnable(3042);
/* 47 */     GL11.glBlendFunc(770, 771);
/* 48 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 49 */     this.red = color.getRed() / 255.0F;
/* 50 */     this.green = color.getGreen() / 255.0F;
/* 51 */     this.blue = color.getBlue() / 255.0F;
/* 52 */     this.alpha = color.getAlpha() / 255.0F;
/* 53 */     this.radius = radius;
/* 54 */     this.quality = quality;
/* 55 */     this.mc.entityRenderer.disableLightmap();
/* 56 */     RenderHelper.disableStandardItemLighting();
/* 57 */     GL11.glPushMatrix();
/* 58 */     startShader(duplicate, first, second, third, oct);
/* 59 */     this.mc.entityRenderer.setupOverlayRendering();
/* 60 */     drawFramebuffer(this.framebuffer);
/* 61 */     stopShader();
/* 62 */     this.mc.entityRenderer.disableLightmap();
/* 63 */     GlStateManager.popMatrix();
/* 64 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, Color first, Color second, Color third, int oct) {
/* 68 */     GL20.glUseProgram(this.program);
/* 69 */     if (this.uniformsMap == null) {
/* 70 */       this.uniformsMap = new HashMap<>();
/* 71 */       setupUniforms();
/*    */     } 
/* 73 */     updateUniforms(duplicate, first, second, third, oct);
/*    */   }
/*    */   
/*    */   public void update(double speed) {
/* 77 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\SmokeShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
