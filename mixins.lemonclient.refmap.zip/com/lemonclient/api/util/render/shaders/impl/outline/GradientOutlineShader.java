//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class GradientOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public GradientOutlineShader() {
/*  20 */     super("outlineGradient.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("color");
/*  27 */     setupUniform("divider");
/*  28 */     setupUniform("radius");
/*  29 */     setupUniform("maxSample");
/*  30 */     setupUniform("alpha0");
/*  31 */     setupUniform("resolution");
/*  32 */     setupUniform("time");
/*  33 */     setupUniform("moreGradient");
/*  34 */     setupUniform("Creepy");
/*  35 */     setupUniform("alpha");
/*  36 */     setupUniform("NUM_OCTAVES");
/*     */   }
/*     */   
/*     */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/*  40 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  41 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  42 */     GL20.glUniform3f(getUniform("color"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
/*  43 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  44 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  45 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  46 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  47 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  48 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  49 */     GL20.glUniform1f(getUniform("moreGradient"), moreGradient);
/*  50 */     GL20.glUniform1f(getUniform("Creepy"), creepy);
/*  51 */     GL20.glUniform1f(getUniform("alpha"), alpha);
/*  52 */     GL20.glUniform1i(getUniform("NUM_OCTAVES"), numOctaves);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/*  57 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  58 */     this.framebuffer.unbindFramebuffer();
/*  59 */     GL11.glEnable(3042);
/*  60 */     GL11.glBlendFunc(770, 771);
/*  61 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  62 */     this.mc.entityRenderer.disableLightmap();
/*  63 */     RenderHelper.disableStandardItemLighting();
/*  64 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, moreGradient, creepy, alpha, numOctaves);
/*  65 */     this.mc.entityRenderer.setupOverlayRendering();
/*  66 */     drawFramebuffer(this.framebuffer);
/*  67 */     stopShader();
/*  68 */     this.mc.entityRenderer.disableLightmap();
/*  69 */     GlStateManager.popMatrix();
/*  70 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float moreGradient, float creepy, float alpha, int numOctaves, Predicate<Boolean> fill) {
/*  74 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  75 */     this.framebuffer.unbindFramebuffer();
/*  76 */     GL11.glEnable(3042);
/*  77 */     GL11.glBlendFunc(770, 771);
/*  78 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  79 */     this.mc.entityRenderer.disableLightmap();
/*  80 */     RenderHelper.disableStandardItemLighting();
/*  81 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, moreGradient, creepy, alpha, numOctaves);
/*  82 */     this.mc.entityRenderer.setupOverlayRendering();
/*  83 */     drawFramebuffer(this.framebuffer);
/*  84 */     fill.test(Boolean.valueOf(false));
/*  85 */     drawFramebuffer(this.framebuffer);
/*  86 */     stopShader();
/*  87 */     this.mc.entityRenderer.disableLightmap();
/*  88 */     GlStateManager.popMatrix();
/*  89 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/*  93 */     GL11.glPushMatrix();
/*  94 */     GL20.glUseProgram(this.program);
/*  95 */     if (this.uniformsMap == null) {
/*  96 */       this.uniformsMap = new HashMap<>();
/*  97 */       setupUniforms();
/*     */     } 
/*  99 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, moreGradient, creepy, alpha, numOctaves);
/*     */   }
/*     */ 
/*     */   
/* 103 */   public static final GradientOutlineShader INSTANCE = new GradientOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 107 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\GradientOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
