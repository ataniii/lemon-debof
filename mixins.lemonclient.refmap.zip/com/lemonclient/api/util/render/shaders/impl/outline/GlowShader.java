//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ public final class GlowShader
/*    */   extends FramebufferShader
/*    */ {
/* 16 */   public float time = 0.0F;
/*    */   
/*    */   public GlowShader() {
/* 19 */     super("glow.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("texture");
/* 24 */     setupUniform("texelSize");
/* 25 */     setupUniform("color");
/* 26 */     setupUniform("divider");
/* 27 */     setupUniform("radius");
/* 28 */     setupUniform("maxSample");
/* 29 */     setupUniform("alpha0");
/*    */   }
/*    */   
/*    */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alpha) {
/* 33 */     GL20.glUniform1i(getUniform("texture"), 0);
/* 34 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/* 35 */     GL20.glUniform3f(getUniform("color"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
/* 36 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/* 37 */     GL20.glUniform1f(getUniform("radius"), radius);
/* 38 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/* 39 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alpha / 255.0F));
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alpha) {
/* 43 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 44 */     this.framebuffer.unbindFramebuffer();
/* 45 */     GL11.glEnable(3042);
/* 46 */     GL11.glBlendFunc(770, 771);
/* 47 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 48 */     this.mc.entityRenderer.disableLightmap();
/* 49 */     RenderHelper.disableStandardItemLighting();
/* 50 */     startShader(color, radius, quality, gradientAlpha, alpha);
/* 51 */     this.mc.entityRenderer.setupOverlayRendering();
/* 52 */     drawFramebuffer(this.framebuffer);
/* 53 */     stopShader();
/* 54 */     this.mc.entityRenderer.disableLightmap();
/* 55 */     GlStateManager.popMatrix();
/* 56 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alpha, Predicate<Boolean> fill) {
/* 60 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 61 */     this.framebuffer.unbindFramebuffer();
/* 62 */     GL11.glEnable(3042);
/* 63 */     GL11.glBlendFunc(770, 771);
/* 64 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 65 */     this.mc.entityRenderer.disableLightmap();
/* 66 */     RenderHelper.disableStandardItemLighting();
/* 67 */     startShader(color, radius, quality, gradientAlpha, alpha);
/* 68 */     this.mc.entityRenderer.setupOverlayRendering();
/* 69 */     drawFramebuffer(this.framebuffer);
/* 70 */     fill.test(Boolean.valueOf(true));
/* 71 */     drawFramebuffer(this.framebuffer);
/* 72 */     stopShader();
/* 73 */     this.mc.entityRenderer.disableLightmap();
/* 74 */     GlStateManager.popMatrix();
/* 75 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alpha) {
/* 79 */     GL11.glPushMatrix();
/* 80 */     GL20.glUseProgram(this.program);
/* 81 */     if (this.uniformsMap == null) {
/* 82 */       this.uniformsMap = new HashMap<>();
/* 83 */       setupUniforms();
/*    */     } 
/* 85 */     updateUniforms(color, radius, quality, gradientAlpha, alpha);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 90 */   public static final GlowShader INSTANCE = new GlowShader();
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\GlowShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
