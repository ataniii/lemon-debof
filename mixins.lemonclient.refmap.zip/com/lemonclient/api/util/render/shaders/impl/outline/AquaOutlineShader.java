//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class AquaOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public AquaOutlineShader() {
/*  20 */     super("aquaOutline.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("divider");
/*  27 */     setupUniform("radius");
/*  28 */     setupUniform("maxSample");
/*  29 */     setupUniform("alpha0");
/*  30 */     setupUniform("resolution");
/*  31 */     setupUniform("time");
/*  32 */     setupUniform("rgba");
/*  33 */     setupUniform("lines");
/*  34 */     setupUniform("tau");
/*     */   }
/*     */   
/*     */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, int lines, double tau) {
/*  38 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  39 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  40 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  41 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  42 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  43 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  44 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  45 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  46 */     GL20.glUniform4f(getUniform("rgba"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  47 */     GL20.glUniform1i(getUniform("lines"), lines);
/*  48 */     GL20.glUniform1f(getUniform("tau"), (float)tau);
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, int lines, double tau) {
/*  52 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  53 */     this.framebuffer.unbindFramebuffer();
/*  54 */     GL11.glEnable(3042);
/*  55 */     GL11.glBlendFunc(770, 771);
/*  56 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  57 */     this.mc.entityRenderer.disableLightmap();
/*  58 */     RenderHelper.disableStandardItemLighting();
/*  59 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, lines, tau);
/*  60 */     this.mc.entityRenderer.setupOverlayRendering();
/*  61 */     drawFramebuffer(this.framebuffer);
/*  62 */     stopShader();
/*  63 */     this.mc.entityRenderer.disableLightmap();
/*  64 */     GlStateManager.popMatrix();
/*  65 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, int lines, double tau, Predicate<Boolean> fill) {
/*  69 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  70 */     this.framebuffer.unbindFramebuffer();
/*  71 */     GL11.glEnable(3042);
/*  72 */     GL11.glBlendFunc(770, 771);
/*  73 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  74 */     this.mc.entityRenderer.disableLightmap();
/*  75 */     RenderHelper.disableStandardItemLighting();
/*  76 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, lines, tau);
/*  77 */     drawFramebuffer(this.framebuffer);
/*  78 */     fill.test(Boolean.valueOf(false));
/*  79 */     drawFramebuffer(this.framebuffer);
/*  80 */     this.mc.entityRenderer.setupOverlayRendering();
/*  81 */     stopShader();
/*  82 */     this.mc.entityRenderer.disableLightmap();
/*  83 */     GlStateManager.popMatrix();
/*  84 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, int lines, double tau) {
/*  88 */     GL11.glPushMatrix();
/*  89 */     GL20.glUseProgram(this.program);
/*  90 */     if (this.uniformsMap == null) {
/*  91 */       this.uniformsMap = new HashMap<>();
/*  92 */       setupUniforms();
/*     */     } 
/*  94 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, lines, tau);
/*     */   }
/*     */ 
/*     */   
/*  98 */   public static final AquaOutlineShader INSTANCE = new AquaOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 102 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\AquaOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
