//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PhobosShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public PhobosShader() {
/* 19 */     super("phobos.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("color");
/* 26 */     setupUniform("texelSize");
/* 27 */     setupUniform("texture");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, Color color, int lines, double tau) {
/* 31 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 32 */     GL20.glUniform1i(getUniform("texture"), 0);
/* 33 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 34 */     GL20.glUniform4f(getUniform("color"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 35 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * this.radius * this.quality, 1.0F / this.mc.displayHeight * this.radius * this.quality);
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate, int lines, double tau) {
/* 39 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 40 */     this.framebuffer.unbindFramebuffer();
/* 41 */     GL11.glEnable(3042);
/* 42 */     GL11.glBlendFunc(770, 771);
/* 43 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 44 */     this.red = color.getRed() / 255.0F;
/* 45 */     this.green = color.getGreen() / 255.0F;
/* 46 */     this.blue = color.getBlue() / 255.0F;
/* 47 */     this.alpha = color.getAlpha() / 255.0F;
/* 48 */     this.radius = radius;
/* 49 */     this.quality = quality;
/* 50 */     this.mc.entityRenderer.disableLightmap();
/* 51 */     RenderHelper.disableStandardItemLighting();
/* 52 */     GL11.glPushMatrix();
/* 53 */     startShader(duplicate, color, lines, tau);
/* 54 */     this.mc.entityRenderer.setupOverlayRendering();
/* 55 */     drawFramebuffer(this.framebuffer);
/* 56 */     stopShader();
/* 57 */     this.mc.entityRenderer.disableLightmap();
/* 58 */     GlStateManager.popMatrix();
/* 59 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, Color color, int lines, double tau) {
/* 63 */     GL20.glUseProgram(this.program);
/* 64 */     if (this.uniformsMap == null) {
/* 65 */       this.uniformsMap = new HashMap<>();
/* 66 */       setupUniforms();
/*    */     } 
/* 68 */     updateUniforms(duplicate, color, lines, tau);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 73 */   public static final PhobosShader INSTANCE = new PhobosShader();
/*    */   public float time;
/*    */   
/*    */   public void update(double speed) {
/* 77 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\PhobosShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
