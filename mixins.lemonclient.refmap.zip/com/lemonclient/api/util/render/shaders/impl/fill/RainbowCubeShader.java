//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RainbowCubeShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public RainbowCubeShader() {
/* 19 */     super("rainbowCube.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("alpha");
/* 26 */     setupUniform("WAVELENGTH");
/* 27 */     setupUniform("R");
/* 28 */     setupUniform("G");
/* 29 */     setupUniform("B");
/* 30 */     setupUniform("RSTART");
/* 31 */     setupUniform("GSTART");
/* 32 */     setupUniform("BSTART");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/* 36 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 37 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 38 */     GL20.glUniform1f(getUniform("alpha"), start.getAlpha() / 255.0F);
/* 39 */     GL20.glUniform1f(getUniform("WAVELENGTH"), wave);
/* 40 */     GL20.glUniform1i(getUniform("R"), start.getRed());
/* 41 */     GL20.glUniform1i(getUniform("G"), start.getGreen());
/* 42 */     GL20.glUniform1i(getUniform("B"), start.getBlue());
/* 43 */     GL20.glUniform1i(getUniform("RSTART"), rStart);
/* 44 */     GL20.glUniform1i(getUniform("GSTART"), gStart);
/* 45 */     GL20.glUniform1i(getUniform("BSTART"), bStart);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 50 */   public static final RainbowCubeShader INSTANCE = new RainbowCubeShader();
/*    */   public float time;
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/* 54 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 55 */     this.framebuffer.unbindFramebuffer();
/* 56 */     GL11.glEnable(3042);
/* 57 */     GL11.glBlendFunc(770, 771);
/* 58 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 59 */     this.red = color.getRed() / 255.0F;
/* 60 */     this.green = color.getGreen() / 255.0F;
/* 61 */     this.blue = color.getBlue() / 255.0F;
/* 62 */     this.alpha = color.getAlpha() / 255.0F;
/* 63 */     this.radius = radius;
/* 64 */     this.quality = quality;
/* 65 */     this.mc.entityRenderer.disableLightmap();
/* 66 */     RenderHelper.disableStandardItemLighting();
/* 67 */     GL11.glPushMatrix();
/* 68 */     startShader(duplicate, start, wave, rStart, gStart, bStart);
/* 69 */     this.mc.entityRenderer.setupOverlayRendering();
/* 70 */     drawFramebuffer(this.framebuffer);
/* 71 */     stopShader();
/* 72 */     this.mc.entityRenderer.disableLightmap();
/* 73 */     GlStateManager.popMatrix();
/* 74 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/* 78 */     GL20.glUseProgram(this.program);
/* 79 */     if (this.uniformsMap == null) {
/* 80 */       this.uniformsMap = new HashMap<>();
/* 81 */       setupUniforms();
/*    */     } 
/* 83 */     updateUniforms(duplicate, start, wave, rStart, gStart, bStart);
/*    */   }
/*    */   
/*    */   public void update(double speed) {
/* 87 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\RainbowCubeShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
