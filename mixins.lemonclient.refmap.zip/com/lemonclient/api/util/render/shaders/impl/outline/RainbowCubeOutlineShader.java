//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class RainbowCubeOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public RainbowCubeOutlineShader() {
/*  20 */     super("rainbowCubeOutline.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("color");
/*  27 */     setupUniform("divider");
/*  28 */     setupUniform("radius");
/*  29 */     setupUniform("maxSample");
/*  30 */     setupUniform("alpha0");
/*  31 */     setupUniform("resolution");
/*  32 */     setupUniform("time");
/*  33 */     setupUniform("WAVELENGTH");
/*  34 */     setupUniform("R");
/*  35 */     setupUniform("G");
/*  36 */     setupUniform("B");
/*  37 */     setupUniform("RSTART");
/*  38 */     setupUniform("GSTART");
/*  39 */     setupUniform("BSTART");
/*  40 */     setupUniform("alpha");
/*     */   }
/*     */   
/*     */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/*  44 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  45 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  46 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  47 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  48 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  49 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  50 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  51 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  52 */     GL20.glUniform1f(getUniform("alpha"), start.getAlpha() / 255.0F);
/*  53 */     GL20.glUniform1f(getUniform("WAVELENGTH"), wave);
/*  54 */     GL20.glUniform1i(getUniform("R"), start.getRed());
/*  55 */     GL20.glUniform1i(getUniform("G"), start.getGreen());
/*  56 */     GL20.glUniform1i(getUniform("B"), start.getBlue());
/*  57 */     GL20.glUniform1i(getUniform("RSTART"), rStart);
/*  58 */     GL20.glUniform1i(getUniform("GSTART"), gStart);
/*  59 */     GL20.glUniform1i(getUniform("BSTART"), bStart);
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/*  63 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  64 */     this.framebuffer.unbindFramebuffer();
/*  65 */     GL11.glEnable(3042);
/*  66 */     GL11.glBlendFunc(770, 771);
/*  67 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  68 */     this.mc.entityRenderer.disableLightmap();
/*  69 */     RenderHelper.disableStandardItemLighting();
/*  70 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, start, wave, rStart, gStart, bStart);
/*  71 */     this.mc.entityRenderer.setupOverlayRendering();
/*  72 */     drawFramebuffer(this.framebuffer);
/*  73 */     stopShader();
/*  74 */     this.mc.entityRenderer.disableLightmap();
/*  75 */     GlStateManager.popMatrix();
/*  76 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color start, int wave, int rStart, int gStart, int bStart, Predicate<Boolean> fill) {
/*  80 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  81 */     this.framebuffer.unbindFramebuffer();
/*  82 */     GL11.glEnable(3042);
/*  83 */     GL11.glBlendFunc(770, 771);
/*  84 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  85 */     this.mc.entityRenderer.disableLightmap();
/*  86 */     RenderHelper.disableStandardItemLighting();
/*  87 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, start, wave, rStart, gStart, bStart);
/*  88 */     this.mc.entityRenderer.setupOverlayRendering();
/*  89 */     drawFramebuffer(this.framebuffer);
/*  90 */     fill.test(Boolean.valueOf(false));
/*  91 */     drawFramebuffer(this.framebuffer);
/*  92 */     stopShader();
/*  93 */     this.mc.entityRenderer.disableLightmap();
/*  94 */     GlStateManager.popMatrix();
/*  95 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Color start, int wave, int rStart, int gStart, int bStart) {
/*  99 */     GL11.glPushMatrix();
/* 100 */     GL20.glUseProgram(this.program);
/* 101 */     if (this.uniformsMap == null) {
/* 102 */       this.uniformsMap = new HashMap<>();
/* 103 */       setupUniforms();
/*     */     } 
/* 105 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, start, wave, rStart, gStart, bStart);
/*     */   }
/*     */ 
/*     */   
/* 109 */   public static final RainbowCubeOutlineShader INSTANCE = new RainbowCubeOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 113 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\RainbowCubeOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
