//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GradientShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public GradientShader() {
/* 19 */     super("gradient.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("moreGradient");
/* 26 */     setupUniform("Creepy");
/* 27 */     setupUniform("alpha");
/* 28 */     setupUniform("NUM_OCTAVES");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/* 32 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 33 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 34 */     GL20.glUniform1f(getUniform("moreGradient"), moreGradient);
/* 35 */     GL20.glUniform1f(getUniform("Creepy"), creepy);
/* 36 */     GL20.glUniform1f(getUniform("alpha"), alpha);
/* 37 */     GL20.glUniform1i(getUniform("NUM_OCTAVES"), numOctaves);
/*    */   }
/*    */   
/* 40 */   public static final GradientShader INSTANCE = new GradientShader();
/*    */   public float time;
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/* 44 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 45 */     this.framebuffer.unbindFramebuffer();
/* 46 */     GL11.glEnable(3042);
/* 47 */     GL11.glBlendFunc(770, 771);
/* 48 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 49 */     this.red = color.getRed() / 255.0F;
/* 50 */     this.green = color.getGreen() / 255.0F;
/* 51 */     this.blue = color.getBlue() / 255.0F;
/* 52 */     this.radius = radius;
/* 53 */     this.quality = quality;
/* 54 */     this.mc.entityRenderer.disableLightmap();
/* 55 */     RenderHelper.disableStandardItemLighting();
/* 56 */     GL11.glPushMatrix();
/* 57 */     startShader(duplicate, moreGradient, creepy, alpha, numOctaves);
/* 58 */     this.mc.entityRenderer.setupOverlayRendering();
/* 59 */     drawFramebuffer(this.framebuffer);
/* 60 */     stopShader();
/* 61 */     this.mc.entityRenderer.disableLightmap();
/* 62 */     GlStateManager.popMatrix();
/* 63 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, float moreGradient, float creepy, float alpha, int numOctaves) {
/* 67 */     GL20.glUseProgram(this.program);
/* 68 */     if (this.uniformsMap == null) {
/* 69 */       this.uniformsMap = new HashMap<>();
/* 70 */       setupUniforms();
/*    */     } 
/* 72 */     updateUniforms(duplicate, moreGradient, creepy, alpha, numOctaves);
/*    */   }
/*    */   
/*    */   public void update(double speed) {
/* 76 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\GradientShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
