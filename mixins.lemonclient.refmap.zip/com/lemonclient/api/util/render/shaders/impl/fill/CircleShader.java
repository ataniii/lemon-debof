//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CircleShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public CircleShader() {
/* 19 */     super("circle.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 23 */     setupUniform("resolution");
/* 24 */     setupUniform("time");
/* 25 */     setupUniform("colors");
/* 26 */     setupUniform("PI");
/* 27 */     setupUniform("rad");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float duplicate, Color color, Double PI, Double rad) {
/* 31 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 32 */     GL20.glUniform1f(getUniform("time"), this.time);
/* 33 */     GL20.glUniform1f(getUniform("PI"), PI.floatValue());
/* 34 */     GL20.glUniform1f(getUniform("rad"), rad.floatValue());
/* 35 */     GL20.glUniform4f(getUniform("colors"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*    */   }
/*    */   
/*    */   public void stopDraw(float duplicate, Color color, Double PI, Double rad) {
/* 39 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 40 */     this.framebuffer.unbindFramebuffer();
/* 41 */     GL11.glEnable(3042);
/* 42 */     GL11.glBlendFunc(770, 771);
/* 43 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 44 */     this.mc.entityRenderer.disableLightmap();
/* 45 */     RenderHelper.disableStandardItemLighting();
/* 46 */     GL11.glPushMatrix();
/* 47 */     startShader(duplicate, color, PI, rad);
/* 48 */     this.mc.entityRenderer.setupOverlayRendering();
/* 49 */     drawFramebuffer(this.framebuffer);
/* 50 */     stopShader();
/* 51 */     this.mc.entityRenderer.disableLightmap();
/* 52 */     GlStateManager.popMatrix();
/* 53 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float duplicate, Color color, Double PI, Double rad) {
/* 57 */     GL20.glUseProgram(this.program);
/* 58 */     if (this.uniformsMap == null) {
/* 59 */       this.uniformsMap = new HashMap<>();
/* 60 */       setupUniforms();
/*    */     } 
/* 62 */     updateUniforms(duplicate, color, PI, rad);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 67 */   public static final CircleShader INSTANCE = new CircleShader();
/*    */   public float time;
/*    */   
/*    */   public void update(double speed) {
/* 71 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\CircleShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
