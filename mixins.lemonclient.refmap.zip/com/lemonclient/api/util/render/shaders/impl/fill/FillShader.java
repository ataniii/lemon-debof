//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.fill;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FillShader
/*    */   extends FramebufferShader
/*    */ {
/*    */   public FillShader() {
/* 18 */     super("fill.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 22 */     setupUniform("color");
/*    */   }
/*    */   
/*    */   public void updateUniforms(float red, float green, float blue, float alpha) {
/* 26 */     GL20.glUniform4f(getUniform("color"), red, green, blue, alpha);
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color) {
/* 30 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 31 */     this.framebuffer.unbindFramebuffer();
/* 32 */     GL11.glEnable(3042);
/* 33 */     GL11.glBlendFunc(770, 771);
/* 34 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 35 */     this.mc.entityRenderer.disableLightmap();
/* 36 */     RenderHelper.disableStandardItemLighting();
/* 37 */     GL11.glPushMatrix();
/* 38 */     startShader(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 39 */     this.mc.entityRenderer.setupOverlayRendering();
/* 40 */     drawFramebuffer(this.framebuffer);
/* 41 */     stopShader();
/* 42 */     this.mc.entityRenderer.disableLightmap();
/* 43 */     GlStateManager.popMatrix();
/* 44 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void startShader(float red, float green, float blue, float alpha) {
/* 48 */     GL20.glUseProgram(this.program);
/* 49 */     if (this.uniformsMap == null) {
/* 50 */       this.uniformsMap = new HashMap<>();
/* 51 */       setupUniforms();
/*    */     } 
/* 53 */     updateUniforms(red, green, blue, alpha);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public static final FillShader INSTANCE = new FillShader();
/*    */   public float time;
/*    */   
/*    */   public void update(double speed) {
/* 62 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\fill\FillShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
