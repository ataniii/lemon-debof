//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class CircleOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public CircleOutlineShader() {
/*  20 */     super("circleOutline.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("colors");
/*  27 */     setupUniform("divider");
/*  28 */     setupUniform("radius");
/*  29 */     setupUniform("maxSample");
/*  30 */     setupUniform("alpha0");
/*  31 */     setupUniform("resolution");
/*  32 */     setupUniform("time");
/*  33 */     setupUniform("PI");
/*  34 */     setupUniform("rad");
/*     */   }
/*     */   
/*     */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Double PI, Double rad) {
/*  38 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  39 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  40 */     GL20.glUniform3f(getUniform("colors"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
/*  41 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  42 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  43 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  44 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  45 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  46 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  47 */     GL20.glUniform1f(getUniform("PI"), PI.floatValue());
/*  48 */     GL20.glUniform1f(getUniform("rad"), rad.floatValue());
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Double PI, Double rad) {
/*  52 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  53 */     this.framebuffer.unbindFramebuffer();
/*  54 */     GL11.glEnable(3042);
/*  55 */     GL11.glBlendFunc(770, 771);
/*  56 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  57 */     this.mc.entityRenderer.disableLightmap();
/*  58 */     RenderHelper.disableStandardItemLighting();
/*  59 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, PI, rad);
/*  60 */     this.mc.entityRenderer.setupOverlayRendering();
/*  61 */     drawFramebuffer(this.framebuffer);
/*  62 */     stopShader();
/*  63 */     this.mc.entityRenderer.disableLightmap();
/*  64 */     GlStateManager.popMatrix();
/*  65 */     GlStateManager.popAttrib();
/*     */   }
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Double PI, Double rad, Predicate<Boolean> fill) {
/*  69 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  70 */     this.framebuffer.unbindFramebuffer();
/*  71 */     GL11.glEnable(3042);
/*  72 */     GL11.glBlendFunc(770, 771);
/*  73 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  74 */     this.mc.entityRenderer.disableLightmap();
/*  75 */     RenderHelper.disableStandardItemLighting();
/*  76 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, PI, rad);
/*  77 */     this.mc.entityRenderer.setupOverlayRendering();
/*  78 */     drawFramebuffer(this.framebuffer);
/*  79 */     fill.test(Boolean.valueOf(false));
/*  80 */     drawFramebuffer(this.framebuffer);
/*  81 */     stopShader();
/*  82 */     this.mc.entityRenderer.disableLightmap();
/*  83 */     GlStateManager.popMatrix();
/*  84 */     GlStateManager.popAttrib();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Double PI, Double rad) {
/*  89 */     GL11.glPushMatrix();
/*  90 */     GL20.glUseProgram(this.program);
/*  91 */     if (this.uniformsMap == null) {
/*  92 */       this.uniformsMap = new HashMap<>();
/*  93 */       setupUniforms();
/*     */     } 
/*  95 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, PI, rad);
/*     */   }
/*     */ 
/*     */   
/*  99 */   public static final CircleOutlineShader INSTANCE = new CircleOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 103 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\CircleOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
