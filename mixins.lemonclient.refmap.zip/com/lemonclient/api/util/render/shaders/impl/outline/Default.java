//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*    */ 
/*    */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL20;
/*    */ 
/*    */ 
/*    */ public final class Default
/*    */   extends FramebufferShader
/*    */ {
/* 17 */   public float time = 0.0F;
/*    */   
/*    */   public Default() {
/* 20 */     super("default.frag");
/*    */   }
/*    */   
/*    */   public void setupUniforms() {
/* 24 */     setupUniform("texture");
/* 25 */     setupUniform("texelSize");
/* 26 */     setupUniform("color");
/* 27 */     setupUniform("divider");
/* 28 */     setupUniform("radius");
/* 29 */     setupUniform("maxSample");
/* 30 */     setupUniform("alpha0");
/* 31 */     setupUniform("resolution");
/* 32 */     setupUniform("time");
/*    */   }
/*    */   
/*    */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate) {
/* 36 */     GL20.glUniform1i(getUniform("texture"), 0);
/* 37 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/* 38 */     GL20.glUniform3f(getUniform("color"), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
/* 39 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/* 40 */     GL20.glUniform1f(getUniform("radius"), radius);
/* 41 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/* 42 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/* 43 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/* 44 */     GL20.glUniform1f(getUniform("time"), this.time);
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate) {
/* 48 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 49 */     this.framebuffer.unbindFramebuffer();
/* 50 */     GL11.glEnable(3042);
/* 51 */     GL11.glBlendFunc(770, 771);
/* 52 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 53 */     this.mc.entityRenderer.disableLightmap();
/* 54 */     RenderHelper.disableStandardItemLighting();
/* 55 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate);
/* 56 */     this.mc.entityRenderer.setupOverlayRendering();
/* 57 */     drawFramebuffer(this.framebuffer);
/* 58 */     stopShader();
/* 59 */     this.mc.entityRenderer.disableLightmap();
/* 60 */     GlStateManager.popMatrix();
/* 61 */     GlStateManager.popAttrib();
/*    */   }
/*    */   
/*    */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, Predicate<Boolean> fill) {
/* 65 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/* 66 */     this.framebuffer.unbindFramebuffer();
/* 67 */     GL11.glEnable(3042);
/* 68 */     GL11.glBlendFunc(770, 771);
/* 69 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 70 */     this.mc.entityRenderer.disableLightmap();
/* 71 */     RenderHelper.disableStandardItemLighting();
/* 72 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate);
/* 73 */     this.mc.entityRenderer.setupOverlayRendering();
/* 74 */     drawFramebuffer(this.framebuffer);
/* 75 */     fill.test(Boolean.valueOf(false));
/* 76 */     drawFramebuffer(this.framebuffer);
/* 77 */     stopShader();
/* 78 */     this.mc.entityRenderer.disableLightmap();
/* 79 */     GlStateManager.popMatrix();
/* 80 */     GlStateManager.popAttrib();
/*    */   }
/*    */ 
/*    */   
/*    */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate) {
/* 85 */     GL11.glPushMatrix();
/* 86 */     GL20.glUseProgram(this.program);
/* 87 */     if (this.uniformsMap == null) {
/* 88 */       this.uniformsMap = new HashMap<>();
/* 89 */       setupUniforms();
/*    */     } 
/* 91 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate);
/*    */   }
/*    */ 
/*    */   
/* 95 */   public static final Default INSTANCE = new Default();
/*    */ 
/*    */   
/*    */   public void update(double speed) {
/* 99 */     this.time = (float)(this.time + speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\Default.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
