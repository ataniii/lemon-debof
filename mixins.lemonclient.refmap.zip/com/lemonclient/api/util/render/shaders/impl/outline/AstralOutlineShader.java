//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.shaders.impl.outline;
/*     */ 
/*     */ import com.lemonclient.api.util.render.shaders.FramebufferShader;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ public final class AstralOutlineShader
/*     */   extends FramebufferShader
/*     */ {
/*  17 */   public float time = 0.0F;
/*     */   
/*     */   public AstralOutlineShader() {
/*  20 */     super("astralOutline.frag");
/*     */   }
/*     */   
/*     */   public void setupUniforms() {
/*  24 */     setupUniform("texture");
/*  25 */     setupUniform("texelSize");
/*  26 */     setupUniform("color");
/*  27 */     setupUniform("divider");
/*  28 */     setupUniform("radius");
/*  29 */     setupUniform("maxSample");
/*  30 */     setupUniform("alpha0");
/*  31 */     setupUniform("time");
/*  32 */     setupUniform("iterations");
/*  33 */     setupUniform("formuparam2");
/*  34 */     setupUniform("stepsize");
/*  35 */     setupUniform("volsteps");
/*  36 */     setupUniform("zoom");
/*  37 */     setupUniform("tile");
/*  38 */     setupUniform("distfading");
/*  39 */     setupUniform("saturation");
/*  40 */     setupUniform("fadeBol");
/*  41 */     setupUniform("resolution");
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateUniforms(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/*  46 */     GL20.glUniform1i(getUniform("texture"), 0);
/*  47 */     GL20.glUniform2f(getUniform("texelSize"), 1.0F / this.mc.displayWidth * radius * quality, 1.0F / this.mc.displayHeight * radius * quality);
/*  48 */     GL20.glUniform1f(getUniform("divider"), 140.0F);
/*  49 */     GL20.glUniform1f(getUniform("radius"), radius);
/*  50 */     GL20.glUniform1f(getUniform("maxSample"), 10.0F);
/*  51 */     GL20.glUniform1f(getUniform("alpha0"), gradientAlpha ? -1.0F : (alphaOutline / 255.0F));
/*  52 */     GL20.glUniform2f(getUniform("resolution"), (new ScaledResolution(this.mc)).getScaledWidth() / duplicate, (new ScaledResolution(this.mc)).getScaledHeight() / duplicate);
/*  53 */     GL20.glUniform1f(getUniform("time"), this.time);
/*  54 */     GL20.glUniform4f(getUniform("color"), red, green, blue, alpha);
/*  55 */     GL20.glUniform1i(getUniform("iterations"), iteractions);
/*  56 */     GL20.glUniform1f(getUniform("formuparam2"), formuparam2);
/*  57 */     GL20.glUniform1i(getUniform("volsteps"), (int)volumSteps);
/*  58 */     GL20.glUniform1f(getUniform("stepsize"), stepSize);
/*  59 */     GL20.glUniform1f(getUniform("zoom"), zoom);
/*  60 */     GL20.glUniform1f(getUniform("tile"), title);
/*  61 */     GL20.glUniform1f(getUniform("distfading"), distfading);
/*  62 */     GL20.glUniform1f(getUniform("saturation"), saturation);
/*     */     
/*  64 */     GL20.glUniform1i(getUniform("fadeBol"), fade);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/*  69 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  70 */     this.framebuffer.unbindFramebuffer();
/*  71 */     GL11.glEnable(3042);
/*  72 */     GL11.glBlendFunc(770, 771);
/*  73 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  74 */     this.mc.entityRenderer.disableLightmap();
/*  75 */     RenderHelper.disableStandardItemLighting();
/*  76 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, red, green, blue, alpha, iteractions, formuparam2, zoom, volumSteps, stepSize, title, distfading, saturation, cloud, fade);
/*  77 */     this.mc.entityRenderer.setupOverlayRendering();
/*  78 */     drawFramebuffer(this.framebuffer);
/*  79 */     stopShader();
/*  80 */     this.mc.entityRenderer.disableLightmap();
/*  81 */     GlStateManager.popMatrix();
/*  82 */     GlStateManager.popAttrib();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopDraw(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade, Predicate<Boolean> fill) {
/*  88 */     this.mc.gameSettings.entityShadows = this.entityShadows;
/*  89 */     this.framebuffer.unbindFramebuffer();
/*  90 */     GL11.glEnable(3042);
/*  91 */     GL11.glBlendFunc(770, 771);
/*  92 */     this.mc.getFramebuffer().bindFramebuffer(true);
/*  93 */     this.mc.entityRenderer.disableLightmap();
/*  94 */     RenderHelper.disableStandardItemLighting();
/*  95 */     startShader(color, radius, quality, gradientAlpha, alphaOutline, duplicate, red, green, blue, alpha, iteractions, formuparam2, zoom, volumSteps, stepSize, title, distfading, saturation, cloud, fade);
/*  96 */     this.mc.entityRenderer.setupOverlayRendering();
/*  97 */     drawFramebuffer(this.framebuffer);
/*  98 */     fill.test(Boolean.valueOf(false));
/*  99 */     drawFramebuffer(this.framebuffer);
/* 100 */     stopShader();
/* 101 */     this.mc.entityRenderer.disableLightmap();
/* 102 */     GlStateManager.popMatrix();
/* 103 */     GlStateManager.popAttrib();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startShader(Color color, float radius, float quality, boolean gradientAlpha, int alphaOutline, float duplicate, float red, float green, float blue, float alpha, int iteractions, float formuparam2, float zoom, float volumSteps, float stepSize, float title, float distfading, float saturation, float cloud, int fade) {
/* 109 */     GL11.glPushMatrix();
/* 110 */     GL20.glUseProgram(this.program);
/* 111 */     if (this.uniformsMap == null) {
/* 112 */       this.uniformsMap = new HashMap<>();
/* 113 */       setupUniforms();
/*     */     } 
/* 115 */     updateUniforms(color, radius, quality, gradientAlpha, alphaOutline, duplicate, red, green, blue, alpha, iteractions, formuparam2, zoom, volumSteps, stepSize, title, distfading, saturation, cloud, fade);
/*     */   }
/*     */ 
/*     */   
/* 119 */   public static final AstralOutlineShader INSTANCE = new AstralOutlineShader();
/*     */ 
/*     */   
/*     */   public void update(double speed) {
/* 123 */     this.time = (float)(this.time + speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\shaders\impl\outline\AstralOutlineShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
