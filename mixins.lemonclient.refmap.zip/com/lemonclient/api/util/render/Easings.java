/*     */ package com.lemonclient.api.util.render;
/*     */ 
/*     */ public interface Easings {
/*   4 */   public static final String[] easings = new String[] { "none", "cubic", "quint", "quad", "quart", "expo", "sine", "circ" };
/*     */   
/*     */   static double toOutEasing(String easing, double value) {
/*   7 */     switch (easing) {
/*     */       case "cubic":
/*   9 */         return cubicOut(value);
/*     */       case "quint":
/*  11 */         return quintOut(value);
/*     */       case "quad":
/*  13 */         return quadOut(value);
/*     */       case "quart":
/*  15 */         return quartOut(value);
/*     */       case "expo":
/*  17 */         return expoOut(value);
/*     */       case "sine":
/*  19 */         return sineOut(value);
/*     */       case "circ":
/*  21 */         return circOut(value);
/*     */     } 
/*  23 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   static double toInEasing(String easing, double value) {
/*  28 */     switch (easing) {
/*     */       case "cubic":
/*  30 */         return cubicIn(value);
/*     */       case "quint":
/*  32 */         return quintIn(value);
/*     */       case "quad":
/*  34 */         return quadIn(value);
/*     */       case "quart":
/*  36 */         return quartIn(value);
/*     */       case "expo":
/*  38 */         return expoIn(value);
/*     */       case "sine":
/*  40 */         return sineIn(value);
/*     */       case "circ":
/*  42 */         return circIn(value);
/*     */     } 
/*  44 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   static double inOutEasing(String easing, double value) {
/*  49 */     switch (easing) {
/*     */       case "cubic":
/*  51 */         return cubicInOut(value);
/*     */       case "quint":
/*  53 */         return quintInOut(value);
/*     */       case "quad":
/*  55 */         return quadInOut(value);
/*     */       case "quart":
/*  57 */         return quartInOut(value);
/*     */       case "expo":
/*  59 */         return expoInOut(value);
/*     */       case "sine":
/*  61 */         return sineInOut(value);
/*     */       case "circ":
/*  63 */         return circInOut(value);
/*     */     } 
/*  65 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static double cubicIn(double value) {
/*  71 */     return value * value * value;
/*     */   }
/*     */   
/*     */   static double cubicOut(double value) {
/*  75 */     return 1.0D - Math.pow(1.0D - value, 3.0D);
/*     */   }
/*     */   
/*     */   static double cubicInOut(double value) {
/*  79 */     return (value < 0.5D) ? (4.0D * value * value * value) : (1.0D - Math.pow(-2.0D * value + 2.0D, 3.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   static double quintIn(double value) {
/*  84 */     return value * value * value * value * value;
/*     */   }
/*     */   
/*     */   static double quintOut(double value) {
/*  88 */     return 1.0D - Math.pow(1.0D - value, 5.0D);
/*     */   }
/*     */   
/*     */   static double quintInOut(double value) {
/*  92 */     return (value < 0.5D) ? (16.0D * value * value * value * value * value) : (1.0D - Math.pow(-2.0D * value + 2.0D, 5.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   static double quadIn(double value) {
/*  97 */     return value * value;
/*     */   }
/*     */   
/*     */   static double quadOut(double value) {
/* 101 */     return 1.0D - (1.0D - value) * (1.0D - value);
/*     */   }
/*     */   
/*     */   static double quadInOut(double value) {
/* 105 */     return (value < 0.5D) ? (2.0D * value * value) : (1.0D - Math.pow(-2.0D * value + 2.0D, 2.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   static double quartIn(double value) {
/* 110 */     return value * value * value * value;
/*     */   }
/*     */   
/*     */   static double quartOut(double value) {
/* 114 */     return 1.0D - Math.pow(1.0D - value, 4.0D);
/*     */   }
/*     */   
/*     */   static double quartInOut(double value) {
/* 118 */     return (value < 0.5D) ? (8.0D * value * value * value * value) : (1.0D - Math.pow(-2.0D * value + 2.0D, 4.0D) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   static double expoIn(double value) {
/* 123 */     return (value == 0.0D) ? 0.0D : Math.pow(2.0D, 10.0D * value - 10.0D);
/*     */   }
/*     */   
/*     */   static double expoOut(double value) {
/* 127 */     return (value == 1.0D) ? 1.0D : (1.0D - Math.pow(2.0D, -10.0D * value));
/*     */   }
/*     */   
/*     */   static double expoInOut(double value) {
/* 131 */     return (value == 0.0D) ? 0.0D : ((value == 1.0D) ? 1.0D : ((value < 0.5D) ? (Math.pow(2.0D, 20.0D * value - 10.0D) / 2.0D) : ((2.0D - Math.pow(2.0D, -20.0D * value + 10.0D)) / 2.0D)));
/*     */   }
/*     */ 
/*     */   
/*     */   static double sineIn(double value) {
/* 136 */     return 1.0D - Math.cos(value * Math.PI / 2.0D);
/*     */   }
/*     */   
/*     */   static double sineOut(double value) {
/* 140 */     return Math.sin(value * Math.PI / 2.0D);
/*     */   }
/*     */   
/*     */   static double sineInOut(double value) {
/* 144 */     return -(Math.cos(Math.PI * value) - 1.0D) / 2.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   static double circIn(double value) {
/* 149 */     return 1.0D - Math.sqrt(1.0D - Math.pow(value, 2.0D));
/*     */   }
/*     */   
/*     */   static double circOut(double value) {
/* 153 */     return Math.sqrt(1.0D - Math.pow(value - 1.0D, 2.0D));
/*     */   }
/*     */   
/*     */   static double circInOut(double value) {
/* 157 */     return (value < 0.5D) ? ((1.0D - Math.sqrt(1.0D - Math.pow(2.0D * value, 2.0D))) / 2.0D) : ((Math.sqrt(1.0D - Math.pow(-2.0D * value + 2.0D, 2.0D)) + 1.0D) / 2.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\Easings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */