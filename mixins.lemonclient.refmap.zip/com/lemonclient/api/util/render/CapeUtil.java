/*    */ package com.lemonclient.api.util.render;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class CapeUtil
/*    */ {
/* 12 */   private static final List<UUID> uuids = new ArrayList<>();
/*    */   
/*    */   public static void init() {
/*    */     try {
/* 16 */       URL capesList = new URL("https://raw.githubusercontent.com/OaDwH/CapeUUID/main/list.txt");
/* 17 */       BufferedReader in = new BufferedReader(new InputStreamReader(capesList.openStream()));
/*    */       String inputLine;
/* 19 */       while ((inputLine = in.readLine()) != null) {
/* 20 */         uuids.add(UUID.fromString(inputLine));
/*    */       }
/* 22 */     } catch (Exception e) {
/* 23 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static boolean hasCape(UUID id) {
/* 28 */     return uuids.contains(id);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\CapeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */