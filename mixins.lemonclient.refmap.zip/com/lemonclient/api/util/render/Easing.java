/*     */ package com.lemonclient.api.util.render;public interface Easing { public static final Easing LINEAR; public static final Easing QUAD_IN; public static final Easing QUAD_OUT; public static final Easing QUAD_IN_OUT; public static final Easing CUBIC_IN;
/*     */   
/*     */   static {
/*   4 */     LINEAR = ((t, b, c, d) -> c * t / d + b);
/*   5 */     QUAD_IN = ((t, b, c, d) -> c * (t /= d) * t + b);
/*   6 */     QUAD_OUT = ((t, b, c, d) -> -c * (t /= d) * (t - 2.0F) + b);
/*   7 */     QUAD_IN_OUT = ((t, b, c, d) -> ((t /= d / 2.0F) < 1.0F) ? (c / 2.0F * t * t + b) : (-c / 2.0F * (--t * (t - 2.0F) - 1.0F) + b));
/*     */ 
/*     */ 
/*     */     
/*  11 */     CUBIC_IN = ((t, b, c, d) -> c * (t /= d) * t * t + b);
/*  12 */     CUBIC_OUT = ((t, b, c, d) -> c * ((t = t / d - 1.0F) * t * t + 1.0F) + b);
/*  13 */     CUBIC_IN_OUT = ((t, b, c, d) -> ((t /= d / 2.0F) < 1.0F) ? (c / 2.0F * t * t * t + b) : (c / 2.0F * ((t -= 2.0F) * t * t + 2.0F) + b));
/*     */ 
/*     */ 
/*     */     
/*  17 */     QUARTIC_IN = ((t, b, c, d) -> c * (t /= d) * t * t * t + b);
/*  18 */     QUARTIC_OUT = ((t, b, c, d) -> -c * ((t = t / d - 1.0F) * t * t * t - 1.0F) + b);
/*  19 */     QUARTIC_IN_OUT = ((t, b, c, d) -> ((t /= d / 2.0F) < 1.0F) ? (c / 2.0F * t * t * t * t + b) : (-c / 2.0F * ((t -= 2.0F) * t * t * t - 2.0F) + b));
/*     */ 
/*     */ 
/*     */     
/*  23 */     QUINTIC_IN = ((t, b, c, d) -> c * (t /= d) * t * t * t * t + b);
/*  24 */     QUINTIC_OUT = ((t, b, c, d) -> c * ((t = t / d - 1.0F) * t * t * t * t + 1.0F) + b);
/*  25 */     QUINTIC_IN_OUT = ((t, b, c, d) -> ((t /= d / 2.0F) < 1.0F) ? (c / 2.0F * t * t * t * t * t + b) : (c / 2.0F * ((t -= 2.0F) * t * t * t * t + 2.0F) + b));
/*     */ 
/*     */ 
/*     */     
/*  29 */     SINE_IN = ((t, b, c, d) -> -c * (float)Math.cos((t / d) * 1.5707963267948966D) + c + b);
/*  30 */     SINE_OUT = ((t, b, c, d) -> c * (float)Math.sin((t / d) * 1.5707963267948966D) + b);
/*  31 */     SINE_IN_OUT = ((t, b, c, d) -> -c / 2.0F * ((float)Math.cos(Math.PI * t / d) - 1.0F) + b);
/*  32 */     EXPO_IN = ((t, b, c, d) -> (t == 0.0F) ? b : (c * (float)Math.pow(2.0D, (10.0F * (t / d - 1.0F))) + b));
/*  33 */     EXPO_OUT = ((t, b, c, d) -> (t == d) ? (b + c) : (c * (-((float)Math.pow(2.0D, (-10.0F * t / d))) + 1.0F) + b));
/*  34 */     EXPO_IN_OUT = ((t, b, c, d) -> (t == 0.0F) ? b : ((t == d) ? (b + c) : (((t /= d / 2.0F) < 1.0F) ? (c / 2.0F * (float)Math.pow(2.0D, (10.0F * (t - 1.0F))) + b) : (c / 2.0F * (-((float)Math.pow(2.0D, (-10.0F * --t))) + 2.0F) + b))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     CIRC_IN = ((t, b, c, d) -> -c * ((float)Math.sqrt((1.0F - (t /= d) * t)) - 1.0F) + b);
/*  41 */     CIRC_OUT = ((t, b, c, d) -> c * (float)Math.sqrt((1.0F - (t = t / d - 1.0F) * t)) + b);
/*  42 */     CIRC_IN_OUT = ((t, b, c, d) -> ((t /= d / 2.0F) < 1.0F) ? (-c / 2.0F * ((float)Math.sqrt((1.0F - t * t)) - 1.0F) + b) : (c / 2.0F * ((float)Math.sqrt((1.0F - (t -= 2.0F) * t)) + 1.0F) + b));
/*     */   }
/*     */   public static final Easing CUBIC_OUT; public static final Easing CUBIC_IN_OUT; public static final Easing QUARTIC_IN; public static final Easing QUARTIC_OUT; public static final Easing QUARTIC_IN_OUT; public static final Easing QUINTIC_IN; public static final Easing QUINTIC_OUT; public static final Easing QUINTIC_IN_OUT; public static final Easing SINE_IN; public static final Easing SINE_OUT; public static final Easing SINE_IN_OUT; public static final Easing EXPO_IN; public static final Easing EXPO_OUT; public static final Easing EXPO_IN_OUT; public static final Easing CIRC_IN; public static final Easing CIRC_OUT;
/*     */   public static final Easing CIRC_IN_OUT;
/*  46 */   public static final Elastic ELASTIC_IN = new ElasticIn();
/*  47 */   public static final Elastic ELASTIC_OUT = new ElasticOut();
/*  48 */   public static final Elastic ELASTIC_IN_OUT = new ElasticInOut();
/*  49 */   public static final Back BACK_IN = new BackIn();
/*  50 */   public static final Back BACK_OUT = new BackOut();
/*  51 */   public static final Back BACK_IN_OUT = new BackInOut(); public static final Easing BOUNCE_OUT; public static final Easing BOUNCE_IN; public static final Easing BOUNCE_IN_OUT; static {
/*  52 */     BOUNCE_OUT = ((t, b, c, d) -> ((t /= d) < 0.36363637F) ? (c * 7.5625F * t * t + b) : ((t < 0.72727275F) ? (c * (7.5625F * (t -= 0.54545456F) * t + 0.75F) + b) : ((t < 0.90909094F) ? (c * (7.5625F * (t -= 0.8181818F) * t + 0.9375F) + b) : (c * (7.5625F * (t -= 0.95454544F) * t + 0.984375F) + b))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     BOUNCE_IN = ((t, b, c, d) -> c - BOUNCE_OUT.ease(d - t, 0.0F, c, d) + b);
/*  59 */     BOUNCE_IN_OUT = ((t, b, c, d) -> (t < d / 2.0F) ? (BOUNCE_IN.ease(t * 2.0F, 0.0F, c, d) * 0.5F + b) : (BOUNCE_OUT.ease(t * 2.0F - d, 0.0F, c, d) * 0.5F + c * 0.5F + b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float ease(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Elastic
/*     */     implements Easing
/*     */   {
/*     */     private float amplitude;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float period;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Elastic(float amplitude, float period) {
/*  86 */       this.amplitude = amplitude;
/*  87 */       this.period = period;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Elastic() {
/*  94 */       this(-1.0F, 0.0F);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getPeriod() {
/* 103 */       return this.period;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setPeriod(float period) {
/* 112 */       this.period = period;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getAmplitude() {
/* 121 */       return this.amplitude;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setAmplitude(float amplitude) {
/* 130 */       this.amplitude = amplitude;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ElasticIn extends Elastic {
/*     */     public ElasticIn(float amplitude, float period) {
/* 136 */       super(amplitude, period);
/*     */     }
/*     */ 
/*     */     
/*     */     public ElasticIn() {}
/*     */ 
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 144 */       float s, a = getAmplitude();
/* 145 */       float p = getPeriod();
/* 146 */       if (time == 0.0F) return startTime; 
/* 147 */       if ((time /= endTime) == 1.0F) return startTime + change; 
/* 148 */       if (p == 0.0F) p = endTime * 0.3F;
/*     */       
/* 150 */       if (a < Math.abs(change))
/* 151 */       { a = change;
/* 152 */         s = p / 4.0F; }
/* 153 */       else { s = p / 6.2831855F * (float)Math.asin((change / a)); }
/* 154 */        return -(a * (float)Math.pow(2.0D, (10.0F * --time)) * (float)Math.sin((time * endTime - s) * 6.283185307179586D / p)) + startTime;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ElasticOut
/*     */     extends Elastic
/*     */   {
/*     */     public ElasticOut(float amplitude, float period) {
/* 163 */       super(amplitude, period);
/*     */     }
/*     */ 
/*     */     
/*     */     public ElasticOut() {}
/*     */ 
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 171 */       float s, a = getAmplitude();
/* 172 */       float p = getPeriod();
/* 173 */       if (time == 0.0F) return startTime; 
/* 174 */       if ((time /= endTime) == 1.0F) return startTime + change; 
/* 175 */       if (p == 0.0F) p = endTime * 0.3F;
/*     */       
/* 177 */       if (a < Math.abs(change))
/* 178 */       { a = change;
/* 179 */         s = p / 4.0F; }
/* 180 */       else { s = p / 6.2831855F * (float)Math.asin((change / a)); }
/* 181 */        return a * (float)Math.pow(2.0D, (-10.0F * time)) * (float)Math.sin((time * endTime - s) * 6.283185307179586D / p) + change + startTime;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ElasticInOut extends Elastic {
/*     */     public ElasticInOut(float amplitude, float period) {
/* 187 */       super(amplitude, period);
/*     */     }
/*     */ 
/*     */     
/*     */     public ElasticInOut() {}
/*     */ 
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 195 */       float s, a = getAmplitude();
/* 196 */       float p = getPeriod();
/* 197 */       if (time == 0.0F) return startTime; 
/* 198 */       if ((time /= endTime / 2.0F) == 2.0F) return startTime + change; 
/* 199 */       if (p == 0.0F) p = endTime * 0.45000002F;
/*     */       
/* 201 */       if (a < Math.abs(change))
/* 202 */       { a = change;
/* 203 */         s = p / 4.0F; }
/* 204 */       else { s = p / 6.2831855F * (float)Math.asin((change / a)); }
/* 205 */        if (time < 1.0F)
/* 206 */         return -0.5F * a * (float)Math.pow(2.0D, (10.0F * --time)) * (float)Math.sin((time * endTime - s) * 6.283185307179586D / p) + startTime; 
/* 207 */       return a * (float)Math.pow(2.0D, (-10.0F * --time)) * (float)Math.sin((time * endTime - s) * 6.283185307179586D / p) * 0.5F + change + startTime;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class Back
/*     */     implements Easing {
/*     */     public static final float DEFAULT_OVERSHOOT = 1.70158F;
/*     */     private float overshoot;
/*     */     
/*     */     public Back() {
/* 217 */       this(1.70158F);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Back(float overshoot) {
/* 228 */       this.overshoot = overshoot;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float getOvershoot() {
/* 237 */       return this.overshoot;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setOvershoot(float overshoot) {
/* 246 */       this.overshoot = overshoot;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BackIn
/*     */     extends Back
/*     */   {
/*     */     public BackIn() {}
/*     */     
/*     */     public BackIn(float overshoot) {
/* 256 */       super(overshoot);
/*     */     }
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 260 */       float s = getOvershoot();
/* 261 */       return change * (time /= endTime) * time * ((s + 1.0F) * time - s) + startTime;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BackOut
/*     */     extends Back
/*     */   {
/*     */     public BackOut() {}
/*     */     
/*     */     public BackOut(float overshoot) {
/* 271 */       super(overshoot);
/*     */     }
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 275 */       float s = getOvershoot();
/* 276 */       return change * ((time = time / endTime - 1.0F) * time * ((s + 1.0F) * time + s) + 1.0F) + startTime;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BackInOut
/*     */     extends Back
/*     */   {
/*     */     public BackInOut() {}
/*     */     
/*     */     public BackInOut(float overshoot) {
/* 286 */       super(overshoot);
/*     */     }
/*     */     
/*     */     public float ease(float time, float startTime, float change, float endTime) {
/* 290 */       float s = getOvershoot();
/* 291 */       if ((time /= endTime / 2.0F) < 1.0F) return change / 2.0F * time * time * (((s = (float)(s * 1.525D)) + 1.0F) * time - s) + startTime; 
/* 292 */       return change / 2.0F * ((time -= 2.0F) * time * (((s = (float)(s * 1.525D)) + 1.0F) * time + s) + 2.0F) + startTime;
/*     */     }
/*     */   } }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\Easing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */