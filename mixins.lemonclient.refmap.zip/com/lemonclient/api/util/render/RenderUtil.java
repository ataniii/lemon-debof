//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*      */ package com.lemonclient.api.util.render;
/*      */ 
/*      */ import com.lemonclient.api.setting.values.ColorSetting;
/*      */ import com.lemonclient.api.util.font.FontUtil;
/*      */ import com.lemonclient.api.util.world.EntityUtil;
/*      */ import com.lemonclient.client.module.ModuleManager;
/*      */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*      */ import com.lemonclient.client.module.modules.render.Nametags;
/*      */ import java.awt.Color;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.entity.EntityPlayerSP;
/*      */ import net.minecraft.client.gui.Gui;
/*      */ import net.minecraft.client.renderer.BufferBuilder;
/*      */ import net.minecraft.client.renderer.GlStateManager;
/*      */ import net.minecraft.client.renderer.Tessellator;
/*      */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.world.World;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.util.glu.Sphere;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RenderUtil
/*      */ {
/*   39 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*      */   
/*      */   public static void drawLine(double posx, double posy, double posz, double posx2, double posy2, double posz2, GSColor color) {
/*   42 */     drawLine(posx, posy, posz, posx2, posy2, posz2, color, 1.0F);
/*      */   }
/*      */   
/*      */   public static void drawRectOutline(double x, double y, double width, double height, Color color) {
/*   46 */     drawGradientRectOutline(x, y, width, height, GradientDirection.Normal, color, color);
/*      */   }
/*      */   public static void drawGradientRectOutline(double x, double y, double width, double height, GradientDirection direction, Color startColor, Color endColor) {
/*   49 */     GL11.glDisable(3553);
/*   50 */     GL11.glEnable(3042);
/*   51 */     GL11.glBlendFunc(770, 771);
/*   52 */     GL11.glShadeModel(7425);
/*   53 */     Color[] result = checkColorDirection(direction, startColor, endColor);
/*   54 */     GL11.glBegin(2);
/*   55 */     GL11.glColor4f(result[2].getRed() / 255.0F, result[2].getGreen() / 255.0F, result[2].getBlue() / 255.0F, result[2].getAlpha() / 255.0F);
/*   56 */     GL11.glVertex2d(x + width, y);
/*   57 */     GL11.glColor4f(result[3].getRed() / 255.0F, result[3].getGreen() / 255.0F, result[3].getBlue() / 255.0F, result[3].getAlpha() / 255.0F);
/*   58 */     GL11.glVertex2d(x, y);
/*   59 */     GL11.glColor4f(result[0].getRed() / 255.0F, result[0].getGreen() / 255.0F, result[0].getBlue() / 255.0F, result[0].getAlpha() / 255.0F);
/*   60 */     GL11.glVertex2d(x, y + height);
/*   61 */     GL11.glColor4f(result[1].getRed() / 255.0F, result[1].getGreen() / 255.0F, result[1].getBlue() / 255.0F, result[1].getAlpha() / 255.0F);
/*   62 */     GL11.glVertex2d(x + width, y + height);
/*   63 */     GL11.glEnd();
/*   64 */     GL11.glDisable(3042);
/*   65 */     GL11.glEnable(3553);
/*      */   }
/*      */   public static void drawTriangle(double x1, double y1, double x2, double y2, double x3, double y3, Color color) {
/*   68 */     GL11.glEnable(3042);
/*   69 */     GL11.glDisable(3553);
/*   70 */     GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
/*   71 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*   72 */     GL11.glBegin(6);
/*   73 */     GL11.glVertex2d(x1, y1);
/*   74 */     GL11.glVertex2d(x2, y2);
/*   75 */     GL11.glVertex2d(x3, y3);
/*   76 */     GL11.glEnd();
/*   77 */     GL11.glEnable(3553);
/*   78 */     GL11.glDisable(3042);
/*      */   }
/*      */   
/*      */   public static void drawRect(double x, double y, double width, double height, Color color) {
/*   82 */     drawGradientRect(x, y, width, height, GradientDirection.Normal, color, color);
/*      */   }
/*      */   
/*      */   public enum GradientDirection
/*      */   {
/*   87 */     LeftToRight,
/*   88 */     RightToLeft,
/*   89 */     UpToDown,
/*   90 */     DownToUp,
/*   91 */     Normal; }
/*      */   
/*      */   public static void setColor(Color color) {
/*   94 */     GL11.glColor4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*      */   }
/*      */   private static Color[] checkColorDirection(GradientDirection direction, Color start, Color end) {
/*   97 */     Color[] dir = new Color[4];
/*   98 */     if (direction == GradientDirection.Normal) {
/*   99 */       for (int a = 0; a < dir.length; a++) {
/*  100 */         dir[a] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*      */       }
/*      */     }
/*  103 */     else if (direction == GradientDirection.DownToUp) {
/*  104 */       dir[0] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  105 */       dir[1] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  106 */       dir[2] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  107 */       dir[3] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*      */     }
/*  109 */     else if (direction == GradientDirection.UpToDown) {
/*  110 */       dir[0] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  111 */       dir[1] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  112 */       dir[2] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  113 */       dir[3] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*      */     }
/*  115 */     else if (direction == GradientDirection.RightToLeft) {
/*  116 */       dir[0] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  117 */       dir[1] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  118 */       dir[2] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  119 */       dir[3] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*      */     }
/*  121 */     else if (direction == GradientDirection.LeftToRight) {
/*  122 */       dir[0] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*  123 */       dir[1] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  124 */       dir[2] = new Color(start.getRed(), start.getGreen(), start.getBlue(), start.getAlpha());
/*  125 */       dir[3] = new Color(end.getRed(), end.getGreen(), end.getBlue(), end.getAlpha());
/*      */     } else {
/*      */       
/*  128 */       for (int a = 0; a < dir.length; a++) {
/*  129 */         dir[a] = new Color(255, 255, 255);
/*      */       }
/*      */     } 
/*  132 */     return dir;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void drawGradientRect(double x, double y, double width, double height, GradientDirection direction, Color startColor, Color endColor) {
/*  137 */     GL11.glDisable(3553);
/*  138 */     GL11.glEnable(3042);
/*  139 */     GL11.glBlendFunc(770, 771);
/*  140 */     GL11.glShadeModel(7425);
/*  141 */     Color[] result = checkColorDirection(direction, startColor, endColor);
/*  142 */     GL11.glBegin(7);
/*  143 */     setColor(result[0]);
/*  144 */     GL11.glVertex2d(x + width, y);
/*  145 */     setColor(result[1]);
/*  146 */     GL11.glVertex2d(x, y);
/*  147 */     setColor(result[2]);
/*  148 */     GL11.glVertex2d(x, y + height);
/*  149 */     setColor(result[3]);
/*  150 */     GL11.glVertex2d(x + width, y + height);
/*  151 */     GL11.glEnd();
/*  152 */     GL11.glDisable(3042);
/*  153 */     GL11.glEnable(3553);
/*      */   }
/*      */   
/*      */   public static void drawRect(float x1, float y1, float x2, float y2, int color) {
/*  157 */     GL11.glPushMatrix();
/*  158 */     GL11.glEnable(3042);
/*  159 */     GL11.glDisable(3553);
/*  160 */     GL11.glBlendFunc(770, 771);
/*  161 */     GL11.glEnable(2848);
/*  162 */     GL11.glPushMatrix();
/*  163 */     color(color);
/*  164 */     GL11.glBegin(7);
/*  165 */     GL11.glVertex2d(x2, y1);
/*  166 */     GL11.glVertex2d(x1, y1);
/*  167 */     GL11.glVertex2d(x1, y2);
/*  168 */     GL11.glVertex2d(x2, y2);
/*  169 */     GL11.glEnd();
/*  170 */     GL11.glPopMatrix();
/*  171 */     GL11.glEnable(3553);
/*  172 */     GL11.glDisable(3042);
/*  173 */     GL11.glDisable(2848);
/*  174 */     GL11.glPopMatrix();
/*  175 */     Gui.drawRect(0, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */   public static void drawRectSOutline(double x, double y, double x2, double y2, Color color) {
/*  179 */     drawGradientRectSOutline(x, y, x2, y2, GradientDirection.Normal, color, color);
/*      */   }
/*      */   public static void drawGradientRectSOutline(double x, double y, double x2, double y2, GradientDirection direction, Color startColor, Color endColor) {
/*  182 */     GL11.glDisable(3553);
/*  183 */     GL11.glEnable(3042);
/*  184 */     GL11.glBlendFunc(770, 771);
/*  185 */     GL11.glShadeModel(7425);
/*  186 */     Color[] result = checkColorDirection(direction, startColor, endColor);
/*  187 */     GL11.glBegin(2);
/*  188 */     GL11.glColor4f(result[2].getRed() / 255.0F, result[2].getGreen() / 255.0F, result[2].getBlue() / 255.0F, result[2].getAlpha() / 255.0F);
/*  189 */     GL11.glVertex2d(x2, y);
/*  190 */     GL11.glColor4f(result[3].getRed() / 255.0F, result[3].getGreen() / 255.0F, result[3].getBlue() / 255.0F, result[3].getAlpha() / 255.0F);
/*  191 */     GL11.glVertex2d(x, y);
/*  192 */     GL11.glColor4f(result[0].getRed() / 255.0F, result[0].getGreen() / 255.0F, result[0].getBlue() / 255.0F, result[0].getAlpha() / 255.0F);
/*  193 */     GL11.glVertex2d(x, y2);
/*  194 */     GL11.glColor4f(result[1].getRed() / 255.0F, result[1].getGreen() / 255.0F, result[1].getBlue() / 255.0F, result[1].getAlpha() / 255.0F);
/*  195 */     GL11.glVertex2d(x2, y2);
/*  196 */     GL11.glEnd();
/*  197 */     GL11.glDisable(3042);
/*  198 */     GL11.glEnable(3553);
/*      */   }
/*      */   public static void drawRectS(double x1, double y1, float x2, float y2, int color) {
/*  201 */     GL11.glPushMatrix();
/*      */     
/*  203 */     GL11.glEnable(3042);
/*  204 */     GL11.glDisable(3553);
/*  205 */     GL11.glBlendFunc(770, 771);
/*  206 */     GL11.glEnable(2848);
/*  207 */     GL11.glPushMatrix();
/*  208 */     color(color);
/*  209 */     GL11.glBegin(7);
/*  210 */     GL11.glVertex2d(x2, y1);
/*  211 */     GL11.glVertex2d(x1, y1);
/*  212 */     GL11.glVertex2d(x1, y2);
/*  213 */     GL11.glVertex2d(x2, y2);
/*  214 */     GL11.glEnd();
/*  215 */     GL11.glPopMatrix();
/*  216 */     GL11.glEnable(3553);
/*  217 */     GL11.glDisable(3042);
/*  218 */     GL11.glDisable(2848);
/*  219 */     GL11.glPopMatrix();
/*  220 */     Gui.drawRect(0, 0, 0, 0, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void color(int color) {
/*  225 */     float f = (color >> 24 & 0xFF) / 255.0F;
/*  226 */     float f1 = (color >> 16 & 0xFF) / 255.0F;
/*  227 */     float f2 = (color >> 8 & 0xFF) / 255.0F;
/*  228 */     float f3 = (color & 0xFF) / 255.0F;
/*  229 */     GL11.glColor4f(f1, f2, f3, f);
/*      */   }
/*      */   public static void prepareGL() {
/*  232 */     GL11.glBlendFunc(770, 771);
/*  233 */     GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  234 */     GlStateManager.glLineWidth(Float.intBitsToFloat(Float.floatToIntBits(5.0675106F) ^ 0x7F22290C));
/*  235 */     GlStateManager.disableTexture2D();
/*  236 */     GlStateManager.depthMask(false);
/*  237 */     GlStateManager.enableBlend();
/*  238 */     GlStateManager.disableDepth();
/*  239 */     GlStateManager.disableLighting();
/*  240 */     GlStateManager.disableCull();
/*  241 */     GlStateManager.enableAlpha();
/*  242 */     GlStateManager.color(Float.intBitsToFloat(Float.floatToIntBits(11.925059F) ^ 0x7EBECD0B), Float.intBitsToFloat(Float.floatToIntBits(18.2283F) ^ 0x7E11D38F), Float.intBitsToFloat(Float.floatToIntBits(9.73656F) ^ 0x7E9BC8F3));
/*      */   }
/*      */   public static void releaseGL() {
/*  245 */     GlStateManager.enableCull();
/*  246 */     GlStateManager.depthMask(true);
/*  247 */     GlStateManager.enableTexture2D();
/*  248 */     GlStateManager.enableBlend();
/*  249 */     GlStateManager.enableDepth();
/*  250 */     GlStateManager.color(Float.intBitsToFloat(Float.floatToIntBits(12.552789F) ^ 0x7EC8D839), Float.intBitsToFloat(Float.floatToIntBits(7.122752F) ^ 0x7F63ED96), Float.intBitsToFloat(Float.floatToIntBits(5.4278784F) ^ 0x7F2DB12E));
/*  251 */     GL11.glColor4f(Float.intBitsToFloat(Float.floatToIntBits(10.5715685F) ^ 0x7EA92525), Float.intBitsToFloat(Float.floatToIntBits(4.9474883F) ^ 0x7F1E51D3), Float.intBitsToFloat(Float.floatToIntBits(4.9044757F) ^ 0x7F1CF177), Float.intBitsToFloat(Float.floatToIntBits(9.482457F) ^ 0x7E97B825));
/*      */   }
/*      */   
/*      */   public static void draw2DGradientRect(float left, float top, float right, float bottom, int leftBottomColor, int leftTopColor, int rightBottomColor, int rightTopColor) {
/*  255 */     float lba = (leftBottomColor >> 24 & 0xFF) / 255.0F;
/*  256 */     float lbr = (leftBottomColor >> 16 & 0xFF) / 255.0F;
/*  257 */     float lbg = (leftBottomColor >> 8 & 0xFF) / 255.0F;
/*  258 */     float lbb = (leftBottomColor & 0xFF) / 255.0F;
/*  259 */     float rba = (rightBottomColor >> 24 & 0xFF) / 255.0F;
/*  260 */     float rbr = (rightBottomColor >> 16 & 0xFF) / 255.0F;
/*  261 */     float rbg = (rightBottomColor >> 8 & 0xFF) / 255.0F;
/*  262 */     float rbb = (rightBottomColor & 0xFF) / 255.0F;
/*  263 */     float lta = (leftTopColor >> 24 & 0xFF) / 255.0F;
/*  264 */     float ltr = (leftTopColor >> 16 & 0xFF) / 255.0F;
/*  265 */     float ltg = (leftTopColor >> 8 & 0xFF) / 255.0F;
/*  266 */     float ltb = (leftTopColor & 0xFF) / 255.0F;
/*  267 */     float rta = (rightTopColor >> 24 & 0xFF) / 255.0F;
/*  268 */     float rtr = (rightTopColor >> 16 & 0xFF) / 255.0F;
/*  269 */     float rtg = (rightTopColor >> 8 & 0xFF) / 255.0F;
/*  270 */     float rtb = (rightTopColor & 0xFF) / 255.0F;
/*      */     
/*  272 */     GlStateManager.disableTexture2D();
/*  273 */     GlStateManager.enableBlend();
/*  274 */     GlStateManager.disableAlpha();
/*  275 */     GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  276 */     GlStateManager.shadeModel(7425);
/*  277 */     Tessellator tessellator = Tessellator.getInstance();
/*  278 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  279 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*  280 */     bufferbuilder.pos(right, top, 0.0D).color(rtr, rtg, rtb, rta).endVertex();
/*  281 */     bufferbuilder.pos(left, top, 0.0D).color(ltr, ltg, ltb, lta).endVertex();
/*  282 */     bufferbuilder.pos(left, bottom, 0.0D).color(lbr, lbg, lbb, lba).endVertex();
/*  283 */     bufferbuilder.pos(right, bottom, 0.0D).color(rbr, rbg, rbb, rba).endVertex();
/*  284 */     tessellator.draw();
/*  285 */     GlStateManager.shadeModel(7424);
/*  286 */     GlStateManager.disableBlend();
/*  287 */     GlStateManager.enableAlpha();
/*  288 */     GlStateManager.enableTexture2D();
/*      */   }
/*      */   public static void drawLine(double posx, double posy, double posz, double posx2, double posy2, double posz2, GSColor color, float width) {
/*  291 */     Tessellator tessellator = Tessellator.getInstance();
/*  292 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  293 */     GlStateManager.glLineWidth(width);
/*  294 */     color.glColor();
/*  295 */     bufferbuilder.begin(1, DefaultVertexFormats.POSITION);
/*  296 */     vertex(posx, posy, posz, bufferbuilder);
/*  297 */     vertex(posx2, posy2, posz2, bufferbuilder);
/*  298 */     tessellator.draw();
/*      */   }
/*      */   
/*      */   public static void draw2DRect(int posX, int posY, int width, int height, int zHeight, GSColor color) {
/*  302 */     Tessellator tessellator = Tessellator.getInstance();
/*  303 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  304 */     GlStateManager.enableBlend();
/*  305 */     GlStateManager.disableTexture2D();
/*  306 */     GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  307 */     color.glColor();
/*  308 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
/*  309 */     bufferbuilder.pos(posX, (posY + height), zHeight).endVertex();
/*  310 */     bufferbuilder.pos((posX + width), (posY + height), zHeight).endVertex();
/*  311 */     bufferbuilder.pos((posX + width), posY, zHeight).endVertex();
/*  312 */     bufferbuilder.pos(posX, posY, zHeight).endVertex();
/*  313 */     tessellator.draw();
/*  314 */     GlStateManager.enableTexture2D();
/*  315 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   private static void drawBorderedRect(double x, double y, double x1, GSColor inside, GSColor border) {
/*  319 */     Tessellator tessellator = Tessellator.getInstance();
/*  320 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  321 */     inside.glColor();
/*  322 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
/*  323 */     bufferbuilder.pos(x, 1.0D, 0.0D).endVertex();
/*  324 */     bufferbuilder.pos(x1, 1.0D, 0.0D).endVertex();
/*  325 */     bufferbuilder.pos(x1, y, 0.0D).endVertex();
/*  326 */     bufferbuilder.pos(x, y, 0.0D).endVertex();
/*  327 */     tessellator.draw();
/*  328 */     border.glColor();
/*  329 */     GlStateManager.glLineWidth(1.8F);
/*  330 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION);
/*  331 */     bufferbuilder.pos(x, y, 0.0D).endVertex();
/*  332 */     bufferbuilder.pos(x, 1.0D, 0.0D).endVertex();
/*  333 */     bufferbuilder.pos(x1, 1.0D, 0.0D).endVertex();
/*  334 */     bufferbuilder.pos(x1, y, 0.0D).endVertex();
/*  335 */     bufferbuilder.pos(x, y, 0.0D).endVertex();
/*  336 */     tessellator.draw();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void drawCircle(float x, float y, float z, Double radius, GSColor colour) {
/*  341 */     GlStateManager.disableCull();
/*  342 */     GlStateManager.disableAlpha();
/*  343 */     GlStateManager.shadeModel(7425);
/*  344 */     Tessellator tessellator = Tessellator.getInstance();
/*  345 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  346 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*      */     
/*  348 */     int alpha = 255 - colour.getAlpha();
/*      */     
/*  350 */     if (alpha == 0) alpha = 1;
/*      */     
/*  352 */     for (int i = 0; i < 361; i++) {
/*  353 */       bufferbuilder.pos(x + Math.sin(Math.toRadians(i)) * radius.doubleValue() - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z + Math.cos(Math.toRadians(i)) * radius.doubleValue() - (mc.getRenderManager()).viewerPosZ).color(colour.getRed() / 255.0F, colour.getGreen() / 255.0F, colour.getBlue() / 255.0F, alpha).endVertex();
/*      */     }
/*      */     
/*  356 */     tessellator.draw();
/*      */     
/*  358 */     GlStateManager.enableCull();
/*  359 */     GlStateManager.enableAlpha();
/*  360 */     GlStateManager.shadeModel(7424);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawCircle(float x, float y, float z, Double radius, int stepCircle, int alphaVal) {
/*  366 */     GlStateManager.disableCull();
/*  367 */     GlStateManager.disableAlpha();
/*  368 */     GlStateManager.shadeModel(7425);
/*  369 */     Tessellator tessellator = Tessellator.getInstance();
/*  370 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  371 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*      */     
/*  373 */     int alpha = 255 - alphaVal;
/*      */     
/*  375 */     if (alpha == 0) alpha = 1;
/*      */     
/*  377 */     for (int i = 0; i < 361; i++) {
/*  378 */       GSColor colour = ColorSetting.getRainbowColor((i % 180 * stepCircle));
/*  379 */       bufferbuilder.pos(x + Math.sin(Math.toRadians(i)) * radius.doubleValue() - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z + Math.cos(Math.toRadians(i)) * radius.doubleValue() - (mc.getRenderManager()).viewerPosZ).color(colour.getRed() / 255.0F, colour.getGreen() / 255.0F, colour.getBlue() / 255.0F, alpha).endVertex();
/*      */     } 
/*      */     
/*  382 */     tessellator.draw();
/*      */     
/*  384 */     GlStateManager.enableCull();
/*  385 */     GlStateManager.enableAlpha();
/*  386 */     GlStateManager.shadeModel(7424);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void drawBox(BlockPos blockPos, double height, GSColor color, int sides) {
/*  391 */     drawBox(blockPos.getX(), blockPos.getY(), blockPos.getZ(), 1.0D, height, 1.0D, color, color.getAlpha(), sides);
/*      */   }
/*      */   
/*      */   public static void drawBox(AxisAlignedBB bb, boolean check, double height, GSColor color, int sides) {
/*  395 */     drawBox(bb, check, height, color, color.getAlpha(), sides);
/*      */   }
/*      */   
/*      */   public static void drawBox(AxisAlignedBB bb, boolean check, double height, GSColor color, int alpha, int sides) {
/*  399 */     if (check) {
/*  400 */       drawBox(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, bb.maxY - bb.minY, bb.maxZ - bb.minZ, color, alpha, sides);
/*      */     } else {
/*  402 */       drawBox(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, height, bb.maxZ - bb.minZ, color, alpha, sides);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBox(double x, double y, double z, double w, double h, double d, GSColor color, int alpha, int sides) {
/*  407 */     GlStateManager.disableAlpha();
/*  408 */     Tessellator tessellator = Tessellator.getInstance();
/*  409 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  410 */     color.glColor();
/*  411 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*  412 */     doVerticies(new AxisAlignedBB(x, y, z, x + w, y + h, z + d), color, alpha, bufferbuilder, sides, false);
/*  413 */     tessellator.draw();
/*  414 */     GlStateManager.enableAlpha();
/*      */   }
/*      */   
/*      */   public static void drawBoxDire(AxisAlignedBB bb, double height, GSColor color, int alpha, int sides) {
/*  418 */     drawBoxDire(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, height, bb.maxZ - bb.minZ, color, alpha, sides);
/*  419 */     drawFixBoxDire(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, height, bb.maxZ - bb.minZ, color, alpha, sides);
/*      */   }
/*      */   
/*      */   public static void drawBoxDire(double x, double y, double z, double w, double h, double d, GSColor color, int alpha, int sides) {
/*  423 */     GlStateManager.disableAlpha();
/*  424 */     Tessellator tessellator = Tessellator.getInstance();
/*  425 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  426 */     color.glColor();
/*  427 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*  428 */     doVerticies(new AxisAlignedBB(x, y, z, x + w, y + h, z + d), color, alpha, bufferbuilder, sides);
/*  429 */     tessellator.draw();
/*  430 */     GlStateManager.enableAlpha();
/*      */   }
/*      */   
/*      */   public static void drawFixBoxDire(double x, double y, double z, double w, double h, double d, GSColor color, int alpha, int sides) {
/*  434 */     GlStateManager.disableAlpha();
/*  435 */     Tessellator tessellator = Tessellator.getInstance();
/*  436 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  437 */     color.glColor();
/*  438 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*  439 */     doFixVerticies(new AxisAlignedBB(x, y, z, x + w, y + h, z + d), color, alpha, bufferbuilder, sides);
/*  440 */     tessellator.draw();
/*  441 */     GlStateManager.enableAlpha();
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxDire(BlockPos pos, double height, double width, GSColor color, int alpha, int sides) {
/*  445 */     drawBoundingBoxDire(new AxisAlignedBB(pos), height, width, color, alpha, sides);
/*      */   }
/*      */   public static void drawBoundingBoxDire(AxisAlignedBB bb, double height, double width, GSColor color, int alpha, int sides) {
/*  448 */     drawBoundingBoxDire(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, height, bb.maxZ - bb.minZ, width, color, alpha, sides);
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxDire(double x, double y, double z, double w, double h, double d, double width, GSColor color, int alpha, int sides) {
/*  452 */     GlStateManager.disableAlpha();
/*  453 */     Tessellator tessellator = Tessellator.getInstance();
/*  454 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  455 */     GlStateManager.glLineWidth((float)width);
/*  456 */     color.glColor();
/*  457 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*  458 */     AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + w, y + h, z + d);
/*  459 */     if ((sides & 0x20) != 0) {
/*  460 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  461 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  462 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  463 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  464 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  465 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  466 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  467 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  468 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  469 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  470 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  471 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  472 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  473 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  474 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  475 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*      */     } 
/*  477 */     if ((sides & 0x10) != 0) {
/*  478 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  479 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  480 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  481 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  482 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  483 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  484 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  485 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  486 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  487 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  488 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  489 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  490 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  491 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  492 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  493 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/*  495 */     if ((sides & 0x4) != 0) {
/*  496 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  497 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  498 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  499 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  500 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  501 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  502 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  503 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  504 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, alpha, bufferbuilder);
/*  505 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  506 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  507 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  508 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  509 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  510 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  511 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/*  513 */     if ((sides & 0x8) != 0) {
/*  514 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  515 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  516 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  517 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  518 */       colorVertex(bb.minX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  519 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  520 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  521 */       colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  522 */       colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  523 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  524 */       colorVertex(bb.minX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  525 */       colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  526 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  527 */       colorVertex(bb.maxX, bb.minY, bb.minZ, color, alpha, bufferbuilder);
/*  528 */       colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  529 */       colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*      */     } 
/*  531 */     tessellator.draw();
/*  532 */     GlStateManager.enableAlpha();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB bb, double width, GSColor[] otherPos) {
/*  538 */     Tessellator tessellator = Tessellator.getInstance();
/*  539 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  540 */     GlStateManager.glLineWidth((float)width);
/*  541 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*  542 */     colorVertex(bb.minX, bb.minY, bb.minZ, otherPos[0], otherPos[0].getAlpha(), bufferbuilder);
/*  543 */     colorVertex(bb.minX, bb.minY, bb.maxZ, otherPos[1], otherPos[1].getAlpha(), bufferbuilder);
/*  544 */     colorVertex(bb.maxX, bb.minY, bb.maxZ, otherPos[2], otherPos[2].getAlpha(), bufferbuilder);
/*  545 */     colorVertex(bb.maxX, bb.minY, bb.minZ, otherPos[3], otherPos[3].getAlpha(), bufferbuilder);
/*  546 */     colorVertex(bb.minX, bb.minY, bb.minZ, otherPos[0], otherPos[0].getAlpha(), bufferbuilder);
/*  547 */     colorVertex(bb.minX, bb.maxY, bb.minZ, otherPos[4], otherPos[4].getAlpha(), bufferbuilder);
/*  548 */     colorVertex(bb.minX, bb.maxY, bb.maxZ, otherPos[5], otherPos[5].getAlpha(), bufferbuilder);
/*  549 */     colorVertex(bb.minX, bb.minY, bb.maxZ, otherPos[1], otherPos[1].getAlpha(), bufferbuilder);
/*  550 */     colorVertex(bb.maxX, bb.minY, bb.maxZ, otherPos[2], otherPos[2].getAlpha(), bufferbuilder);
/*  551 */     colorVertex(bb.maxX, bb.maxY, bb.maxZ, otherPos[6], otherPos[6].getAlpha(), bufferbuilder);
/*  552 */     colorVertex(bb.minX, bb.maxY, bb.maxZ, otherPos[5], otherPos[5].getAlpha(), bufferbuilder);
/*  553 */     colorVertex(bb.maxX, bb.maxY, bb.maxZ, otherPos[6], otherPos[6].getAlpha(), bufferbuilder);
/*  554 */     colorVertex(bb.maxX, bb.maxY, bb.minZ, otherPos[7], otherPos[7].getAlpha(), bufferbuilder);
/*  555 */     colorVertex(bb.maxX, bb.minY, bb.minZ, otherPos[3], otherPos[3].getAlpha(), bufferbuilder);
/*  556 */     colorVertex(bb.maxX, bb.maxY, bb.minZ, otherPos[7], otherPos[7].getAlpha(), bufferbuilder);
/*  557 */     colorVertex(bb.minX, bb.maxY, bb.minZ, otherPos[4], otherPos[4].getAlpha(), bufferbuilder);
/*  558 */     tessellator.draw();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB axisAlignedBB, double width, GSColor[] color, boolean five, int sides) {
/*  563 */     Tessellator tessellator = Tessellator.getInstance();
/*  564 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  565 */     GlStateManager.glLineWidth((float)width);
/*  566 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*      */     
/*  568 */     if ((sides & 0x20) != 0) {
/*  569 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  570 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  571 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*  572 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[6], color[6].getAlpha(), bufferbuilder);
/*  573 */       if (five) {
/*  574 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*      */       }
/*      */     } 
/*  577 */     if ((sides & 0x10) != 0) {
/*  578 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*  579 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  580 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*  581 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[4], color[4].getAlpha(), bufferbuilder);
/*  582 */       if (five)
/*  583 */         colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder); 
/*      */     } 
/*  585 */     if ((sides & 0x4) != 0) {
/*  586 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  587 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*  588 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[4], color[4].getAlpha(), bufferbuilder);
/*  589 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*  590 */       if (five)
/*  591 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder); 
/*      */     } 
/*  593 */     if ((sides & 0x8) != 0) {
/*  594 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  595 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  596 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[6], color[6].getAlpha(), bufferbuilder);
/*  597 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*  598 */       if (five)
/*  599 */         colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder); 
/*      */     } 
/*  601 */     if ((sides & 0x2) != 0) {
/*  602 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*  603 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[6], color[6].getAlpha(), bufferbuilder);
/*  604 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*  605 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[4], color[4].getAlpha(), bufferbuilder);
/*  606 */       if (five)
/*  607 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder); 
/*      */     } 
/*  609 */     if ((sides & 0x1) != 0) {
/*  610 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  611 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  612 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  613 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*  614 */       if (five)
/*  615 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder); 
/*      */     } 
/*  617 */     tessellator.draw();
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(BlockPos bp, double height, float width, GSColor color) {
/*  621 */     drawBoundingBox(getBoundingBox(bp, height), width, color, color.getAlpha());
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB bb, double width, GSColor color) {
/*  625 */     drawBoundingBox(bb, width, color, color.getAlpha());
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB bb, double width, GSColor color, int alpha) {
/*  629 */     Tessellator tessellator = Tessellator.getInstance();
/*  630 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  631 */     GlStateManager.glLineWidth((float)width);
/*  632 */     color.glColor();
/*  633 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*  634 */     colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  635 */     colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  636 */     colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  637 */     colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  638 */     colorVertex(bb.minX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  639 */     colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  640 */     colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  641 */     colorVertex(bb.minX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  642 */     colorVertex(bb.maxX, bb.minY, bb.maxZ, color, color.getAlpha(), bufferbuilder);
/*  643 */     colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  644 */     colorVertex(bb.minX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  645 */     colorVertex(bb.maxX, bb.maxY, bb.maxZ, color, alpha, bufferbuilder);
/*  646 */     colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  647 */     colorVertex(bb.maxX, bb.minY, bb.minZ, color, color.getAlpha(), bufferbuilder);
/*  648 */     colorVertex(bb.maxX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  649 */     colorVertex(bb.minX, bb.maxY, bb.minZ, color, alpha, bufferbuilder);
/*  650 */     tessellator.draw();
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxWithSides(BlockPos blockPos, double high, int width, GSColor color, int sides) {
/*  654 */     drawBoundingBoxWithSides(getBoundingBox(blockPos, high), width, color, color.getAlpha(), sides);
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxWithSides(BlockPos blockPos, int width, GSColor color, int sides) {
/*  658 */     drawBoundingBoxWithSides(getBoundingBox(blockPos, 1.0D), width, color, color.getAlpha(), sides);
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxWithSides(BlockPos blockPos, int width, GSColor color, int alpha, int sides) {
/*  662 */     drawBoundingBoxWithSides(getBoundingBox(blockPos, 1.0D), width, color, alpha, sides);
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxWithSides(AxisAlignedBB axisAlignedBB, int width, GSColor color, int sides) {
/*  666 */     drawBoundingBoxWithSides(axisAlignedBB, width, color, color.getAlpha(), sides);
/*      */   }
/*      */   
/*      */   public static void drawBoundingBoxWithSides(AxisAlignedBB axisAlignedBB, int width, GSColor color, int alpha, int sides) {
/*  670 */     Tessellator tessellator = Tessellator.getInstance();
/*  671 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  672 */     GlStateManager.glLineWidth(width);
/*  673 */     bufferbuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
/*  674 */     doVerticies(axisAlignedBB, color, alpha, bufferbuilder, sides, true);
/*  675 */     tessellator.draw();
/*      */   }
/*      */   public static void drawBoxProva2(AxisAlignedBB bb, GSColor[] color, int sides) {
/*  678 */     drawBoxProva(bb.minX, bb.minY, bb.minZ, bb.maxX - bb.minX, bb.maxY - bb.minY, bb.maxZ - bb.minZ, color, sides);
/*      */   }
/*      */   
/*      */   public static void drawBoxProva(double x, double y, double z, double w, double h, double d, GSColor[] color, int sides) {
/*  682 */     GlStateManager.disableAlpha();
/*  683 */     Tessellator tessellator = Tessellator.getInstance();
/*  684 */     BufferBuilder bufferbuilder = tessellator.getBuffer();
/*  685 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*  686 */     doVerticiesProva(new AxisAlignedBB(x, y, z, x + w, y + h, z + d), color, bufferbuilder, sides);
/*  687 */     tessellator.draw();
/*  688 */     GlStateManager.enableAlpha();
/*      */   }
/*      */   
/*      */   private static void doVerticiesProva(AxisAlignedBB axisAlignedBB, GSColor[] color, BufferBuilder bufferbuilder, int sides) {
/*  692 */     if ((sides & 0x20) != 0) {
/*  693 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  694 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  695 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*  696 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[6], color[6].getAlpha(), bufferbuilder);
/*      */     } 
/*      */     
/*  699 */     if ((sides & 0x10) != 0) {
/*  700 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*  701 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  702 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*  703 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[4], color[4].getAlpha(), bufferbuilder);
/*      */     } 
/*  705 */     if ((sides & 0x4) != 0) {
/*  706 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  707 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*  708 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[4], color[4].getAlpha(), bufferbuilder);
/*  709 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*      */     } 
/*  711 */     if ((sides & 0x8) != 0) {
/*  712 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  713 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  714 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[6], color[6].getAlpha(), bufferbuilder);
/*  715 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*      */     } 
/*  717 */     if ((sides & 0x2) != 0) {
/*  718 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[7], color[7].getAlpha(), bufferbuilder);
/*  719 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color[6], color[6].getAlpha(), bufferbuilder);
/*  720 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[5], color[5].getAlpha(), bufferbuilder);
/*  721 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color[4], color[4].getAlpha(), bufferbuilder);
/*      */     } 
/*  723 */     if ((sides & 0x1) != 0) {
/*  724 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color[3], color[3].getAlpha(), bufferbuilder);
/*  725 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[2], color[2].getAlpha(), bufferbuilder);
/*  726 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color[1], color[1].getAlpha(), bufferbuilder);
/*  727 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color[0], color[0].getAlpha(), bufferbuilder);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class Points {
/*  732 */     double[][] point = new double[10][2];
/*  733 */     private int count = 0;
/*      */     private final double xCenter;
/*      */     private final double zCenter;
/*      */     public final double yMin;
/*      */     public final double yMax;
/*      */     private final float rotation;
/*      */     
/*      */     public Points(double yMin, double yMax, double xCenter, double zCenter, float rotation) {
/*  741 */       this.yMin = yMin;
/*  742 */       this.yMax = yMax;
/*  743 */       this.xCenter = xCenter;
/*  744 */       this.zCenter = zCenter;
/*  745 */       this.rotation = rotation;
/*      */     }
/*      */     
/*      */     public void addPoints(double x, double z) {
/*  749 */       x -= this.xCenter;
/*  750 */       z -= this.zCenter;
/*  751 */       double rotateX = x * Math.cos(this.rotation) - z * Math.sin(this.rotation);
/*  752 */       double rotateZ = x * Math.sin(this.rotation) + z * Math.cos(this.rotation);
/*  753 */       rotateX += this.xCenter;
/*  754 */       rotateZ += this.zCenter;
/*  755 */       (new double[2])[0] = rotateX; (new double[2])[1] = rotateZ; this.point[this.count++] = new double[2];
/*      */     }
/*      */     
/*      */     public double[] getPoint(int index) {
/*  759 */       return this.point[index];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void drawBoxWithDirection(AxisAlignedBB bb, GSColor color, float rotation, float width, int mode) {
/*  764 */     double xCenter = bb.minX + (bb.maxX - bb.minX) / 2.0D;
/*  765 */     double zCenter = bb.minZ + (bb.maxZ - bb.minZ) / 2.0D;
/*      */     
/*  767 */     Points square = new Points(bb.minY, bb.maxY, xCenter, zCenter, rotation);
/*      */     
/*  769 */     if (mode == 0) {
/*  770 */       square.addPoints(bb.minX, bb.minZ);
/*  771 */       square.addPoints(bb.minX, bb.maxZ);
/*  772 */       square.addPoints(bb.maxX, bb.maxZ);
/*  773 */       square.addPoints(bb.maxX, bb.minZ);
/*      */     } 
/*      */     
/*  776 */     if (mode == 0) {
/*  777 */       drawDirection(square, color, width);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void drawDirection(Points square, GSColor color, float width) {
/*      */     int i;
/*  783 */     for (i = 0; i < 4; i++) {
/*  784 */       drawLine(square.getPoint(i)[0], square.yMin, square.getPoint(i)[1], square
/*  785 */           .getPoint((i + 1) % 4)[0], square.yMin, square.getPoint((i + 1) % 4)[1], color, width);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  790 */     for (i = 0; i < 4; i++) {
/*  791 */       drawLine(square.getPoint(i)[0], square.yMax, square.getPoint(i)[1], square
/*  792 */           .getPoint((i + 1) % 4)[0], square.yMax, square.getPoint((i + 1) % 4)[1], color, width);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  797 */     for (i = 0; i < 4; i++) {
/*  798 */       drawLine(square.getPoint(i)[0], square.yMin, square.getPoint(i)[1], square
/*  799 */           .getPoint(i)[0], square.yMax, square.getPoint(i)[1], color, width);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawSphere(double x, double y, double z, float size, int slices, int stacks, float lineWidth, GSColor color) {
/*  806 */     Sphere sphere = new Sphere();
/*  807 */     GlStateManager.glLineWidth(lineWidth);
/*  808 */     color.glColor();
/*  809 */     sphere.setDrawStyle(100013);
/*  810 */     GlStateManager.pushMatrix();
/*  811 */     GlStateManager.translate(x - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z - (mc.getRenderManager()).viewerPosZ);
/*  812 */     sphere.draw(size, slices, stacks);
/*  813 */     GlStateManager.popMatrix();
/*      */   }
/*      */   
/*      */   public static void drawNametag(Entity entity, String[] text, GSColor color, int type) {
/*  817 */     Vec3d pos = EntityUtil.getInterpolatedPos(entity, mc.getRenderPartialTicks());
/*  818 */     drawNametag(pos.x, pos.y + entity.height, pos.z, text, color, type, 0.0D, 0.0D);
/*      */   }
/*      */   public static double getDistance(double x, double y, double z) {
/*      */     EntityPlayerSP entityPlayerSP;
/*  822 */     Entity viewEntity = mc.getRenderViewEntity();
/*      */     
/*  824 */     if (viewEntity == null) entityPlayerSP = mc.player; 
/*  825 */     double d0 = ((Entity)entityPlayerSP).posX - x;
/*  826 */     double d1 = ((Entity)entityPlayerSP).posY - y;
/*  827 */     double d2 = ((Entity)entityPlayerSP).posZ - z;
/*  828 */     return MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
/*      */   }
/*      */   
/*      */   public static void drawNametag(double x, double y, double z, String[] text, GSColor color, int type, double customScale, double maxSize) {
/*  832 */     ColorMain colorMain = (ColorMain)ModuleManager.getModule(ColorMain.class);
/*  833 */     double dist = getDistance(x, y, z);
/*  834 */     double scale = 1.0D, offset = 0.0D;
/*  835 */     int start = 0;
/*  836 */     switch (type) {
/*      */       case 0:
/*  838 */         scale = dist / 20.0D * Math.pow(1.2589254D, 0.1D / ((dist < 25.0D) ? 0.5D : 2.0D));
/*  839 */         scale = Math.min(Math.max(scale, 0.5D), 5.0D);
/*  840 */         offset = (scale > 2.0D) ? (scale / 2.0D) : scale;
/*  841 */         scale /= 40.0D;
/*  842 */         start = 10;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  851 */         scale = customScale;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  856 */         scale = 0.0018D + customScale * dist;
/*  857 */         if (dist <= 8.0D) scale = 6.125D * customScale; 
/*  858 */         start = -8;
/*      */         break;
/*      */     } 
/*  861 */     if (maxSize != 0.0D && scale > maxSize) scale = maxSize; 
/*  862 */     GlStateManager.pushMatrix();
/*  863 */     GlStateManager.translate(x - (mc.getRenderManager()).viewerPosX, y + offset - (mc.getRenderManager()).viewerPosY, z - (mc.getRenderManager()).viewerPosZ);
/*  864 */     GlStateManager.rotate(-(mc.getRenderManager()).playerViewY, 0.0F, 1.0F, 0.0F);
/*  865 */     GlStateManager.rotate((mc.getRenderManager()).playerViewX, (mc.gameSettings.thirdPersonView == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/*  866 */     GlStateManager.scale(-scale, -scale, scale);
/*  867 */     if (type == 2) {
/*  868 */       Nametags nametags = (Nametags)ModuleManager.getModule(Nametags.class);
/*  869 */       double width = 0.0D;
/*  870 */       GSColor bcolor = new GSColor(0, 0, 0, 0);
/*      */       
/*  872 */       if (((Boolean)nametags.outline.getValue()).booleanValue()) {
/*  873 */         bcolor = color;
/*  874 */         if (((Boolean)nametags.customColor.getValue()).booleanValue()) {
/*  875 */           bcolor = nametags.borderColor.getValue();
/*      */         }
/*      */       } 
/*  878 */       for (String s : text) {
/*  879 */         double w = FontUtil.getStringWidth(((Boolean)colorMain.customFont.getValue()).booleanValue(), s) / 2.0D;
/*  880 */         if (w > width) {
/*  881 */           width = w;
/*      */         }
/*      */       } 
/*  884 */       drawBorderedRect(-width - 1.0D, -mc.fontRenderer.FONT_HEIGHT, width + 2.0D, new GSColor(0, 4, 0, ((Boolean)nametags.border.getValue()).booleanValue() ? 85 : 0), bcolor);
/*      */     } 
/*  886 */     GlStateManager.enableTexture2D();
/*  887 */     for (int i = 0; i < text.length; i++) {
/*  888 */       FontUtil.drawStringWithShadow(((Boolean)colorMain.customFont.getValue()).booleanValue(), text[i], (-FontUtil.getStringWidth(((Boolean)colorMain.customFont.getValue()).booleanValue(), text[i]) / 2), (i * (mc.fontRenderer.FONT_HEIGHT + 1) + start), color);
/*      */     }
/*  890 */     GlStateManager.disableTexture2D();
/*  891 */     if (type != 2) {
/*  892 */       GlStateManager.popMatrix();
/*      */     }
/*      */   }
/*      */   
/*      */   private static void vertex(double x, double y, double z, BufferBuilder bufferbuilder) {
/*  897 */     bufferbuilder.pos(x - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z - (mc.getRenderManager()).viewerPosZ).endVertex();
/*      */   }
/*      */   
/*      */   private static void colorVertex(double x, double y, double z, GSColor color, int alpha, BufferBuilder bufferbuilder) {
/*  901 */     bufferbuilder.pos(x - (mc.getRenderManager()).viewerPosX, y - (mc.getRenderManager()).viewerPosY, z - (mc.getRenderManager()).viewerPosZ).color(color.getRed(), color.getGreen(), color.getBlue(), alpha).endVertex();
/*      */   }
/*      */   
/*      */   private static AxisAlignedBB getBoundingBox(BlockPos bp, double height) {
/*  905 */     double x = bp.getX();
/*  906 */     double y = bp.getY();
/*  907 */     double z = bp.getZ();
/*  908 */     return new AxisAlignedBB(x, y, z, x + 1.0D, y + height, z + 1.0D);
/*      */   }
/*      */   
/*      */   private static void doVerticies(AxisAlignedBB axisAlignedBB, GSColor color, int alpha, BufferBuilder bufferbuilder, int sides, boolean five) {
/*  912 */     if ((sides & 0x20) != 0) {
/*  913 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  914 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  915 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  916 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  917 */       if (five)
/*  918 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder); 
/*      */     } 
/*  920 */     if ((sides & 0x10) != 0) {
/*  921 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  922 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  923 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  924 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  925 */       if (five)
/*  926 */         colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder); 
/*      */     } 
/*  928 */     if ((sides & 0x4) != 0) {
/*  929 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  930 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  931 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  932 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  933 */       if (five)
/*  934 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder); 
/*      */     } 
/*  936 */     if ((sides & 0x8) != 0) {
/*  937 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  938 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  939 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  940 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  941 */       if (five)
/*  942 */         colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder); 
/*      */     } 
/*  944 */     if ((sides & 0x2) != 0) {
/*  945 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  946 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  947 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  948 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  949 */       if (five)
/*  950 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder); 
/*      */     } 
/*  952 */     if ((sides & 0x1) != 0) {
/*  953 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  954 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  955 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  956 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  957 */       if (five)
/*  958 */         colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder); 
/*      */     } 
/*      */   }
/*      */   public static void doVerticies(AxisAlignedBB axisAlignedBB, GSColor color, int alpha, BufferBuilder bufferbuilder, int sides) {
/*  962 */     if ((sides & 0x20) != 0) {
/*  963 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  964 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  965 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  966 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  967 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  968 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  969 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  970 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  971 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  972 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  973 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  974 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/*      */     
/*  977 */     if ((sides & 0x10) != 0) {
/*  978 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  979 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  980 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  981 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  982 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  983 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  984 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  985 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  986 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*  987 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  988 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*  989 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/*  991 */     if ((sides & 0x4) != 0) {
/*  992 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  993 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  994 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  995 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  996 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*  997 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  998 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*  999 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1000 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1001 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1002 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1003 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/* 1005 */     if ((sides & 0x8) != 0) {
/* 1006 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1007 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1008 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1009 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1010 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1011 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1012 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1013 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1014 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1015 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1016 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1017 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void doFixVerticies(AxisAlignedBB axisAlignedBB, GSColor color, int alpha, BufferBuilder bufferbuilder, int sides) {
/* 1022 */     if ((sides & 0x20) != 0) {
/* 1023 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1024 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1025 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1026 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1027 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1028 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1029 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1030 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/*      */     } 
/*      */     
/* 1033 */     if ((sides & 0x10) != 0) {
/* 1034 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1035 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1036 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1037 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1038 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1039 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1040 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1041 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/* 1043 */     if ((sides & 0x4) != 0) {
/* 1044 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1045 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1046 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1047 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1048 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/* 1049 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1050 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, alpha, bufferbuilder);
/* 1051 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, color.getAlpha(), bufferbuilder);
/*      */     } 
/* 1053 */     if ((sides & 0x8) != 0) {
/* 1054 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1055 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1056 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1057 */       colorVertex(axisAlignedBB.maxX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1058 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/* 1059 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1060 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.maxZ, color, color.getAlpha(), bufferbuilder);
/* 1061 */       colorVertex(axisAlignedBB.minX, axisAlignedBB.maxY, axisAlignedBB.minZ, color, alpha, bufferbuilder);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void prepare() {
/* 1066 */     GL11.glHint(3154, 4354);
/* 1067 */     GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
/* 1068 */     GlStateManager.shadeModel(7425);
/* 1069 */     GlStateManager.depthMask(false);
/* 1070 */     GlStateManager.enableBlend();
/* 1071 */     GlStateManager.disableDepth();
/* 1072 */     GlStateManager.disableTexture2D();
/* 1073 */     GlStateManager.disableLighting();
/* 1074 */     GlStateManager.disableCull();
/* 1075 */     GlStateManager.enableAlpha();
/* 1076 */     GL11.glEnable(2848);
/* 1077 */     GL11.glEnable(34383);
/*      */   }
/*      */   
/*      */   public static void release() {
/* 1081 */     GL11.glDisable(34383);
/* 1082 */     GL11.glDisable(2848);
/* 1083 */     GlStateManager.enableAlpha();
/* 1084 */     GlStateManager.enableCull();
/* 1085 */     GlStateManager.enableTexture2D();
/* 1086 */     GlStateManager.enableDepth();
/* 1087 */     GlStateManager.disableBlend();
/* 1088 */     GlStateManager.depthMask(true);
/* 1089 */     GlStateManager.glLineWidth(1.0F);
/* 1090 */     GlStateManager.shadeModel(7424);
/* 1091 */     GL11.glHint(3154, 4352);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedPos(Entity entity, float partialTicks, boolean wrap) {
/* 1095 */     Vec3d amount = new Vec3d((entity.posX - entity.lastTickPosX) * partialTicks, (entity.posY - entity.lastTickPosY) * partialTicks, (entity.posZ - entity.lastTickPosZ) * partialTicks);
/* 1096 */     Vec3d vec = (new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ)).add(amount);
/* 1097 */     if (wrap) {
/* 1098 */       return vec.subtract((mc.getRenderManager()).renderPosX, (mc.getRenderManager()).renderPosY, (mc.getRenderManager()).renderPosZ);
/*      */     }
/* 1100 */     return vec;
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB getAxisAlignedBB(BlockPos pos, double size) {
/* 1104 */     AxisAlignedBB bb = mc.world.getBlockState(pos).getSelectedBoundingBox((World)mc.world, pos);
/* 1105 */     Vec3d center = bb.getCenter();
/* 1106 */     return new AxisAlignedBB(center.x - (bb.maxX - bb.minX) * size, center.y - (bb.maxY - bb.minX) * size, center.z - (bb.maxZ - bb.minZ) * size, center.x + (bb.maxX - bb.minX) * size, center.y + (bb.maxY - bb.minY) * size, center.z + (bb.maxZ - bb.minZ) * size);
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB getInterpolatedAxis(AxisAlignedBB bb) {
/* 1110 */     return new AxisAlignedBB(bb.minX - (mc.getRenderManager()).viewerPosX, bb.minY - (mc.getRenderManager()).viewerPosY, bb.minZ - (mc.getRenderManager()).viewerPosZ, bb.maxX - (mc.getRenderManager()).viewerPosX, bb.maxY - (mc.getRenderManager()).viewerPosY, bb.maxZ - (mc.getRenderManager()).viewerPosZ);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedRenderPos(Entity entity, float ticks) {
/* 1114 */     return interpolateEntity(entity, ticks).subtract((mc.getRenderManager()).renderPosX, (mc.getRenderManager()).renderPosY, (mc.getRenderManager()).renderPosZ);
/*      */   }
/*      */   
/*      */   public static Vec3d interpolateEntity(Entity entity, float time) {
/* 1118 */     return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * time, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * time, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * time);
/*      */   }
/*      */   
/*      */   public static double getInterpolatedDouble(double pre, double current, float partialTicks) {
/* 1122 */     return pre + (current - pre) * partialTicks;
/*      */   }
/*      */   
/*      */   public static float getInterpolatedFloat(float pre, float current, float partialTicks) {
/* 1126 */     return pre + (current - pre) * partialTicks;
/*      */   }
/*      */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
