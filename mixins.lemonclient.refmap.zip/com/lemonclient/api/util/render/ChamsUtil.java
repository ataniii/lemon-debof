//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.OpenGlHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class ChamsUtil
/*    */ {
/* 11 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   public static void createChamsPre() {
/* 14 */     mc.getRenderManager().setRenderShadow(false);
/* 15 */     mc.getRenderManager().setRenderOutlines(false);
/* 16 */     GlStateManager.pushMatrix();
/* 17 */     GlStateManager.depthMask(true);
/* 18 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/* 19 */     GL11.glEnable(32823);
/* 20 */     GL11.glDepthRange(0.0D, 0.01D);
/* 21 */     GlStateManager.popMatrix();
/*    */   }
/*    */   
/*    */   public static void createChamsPost() {
/* 25 */     boolean shadow = mc.getRenderManager().isRenderShadow();
/* 26 */     mc.getRenderManager().setRenderShadow(shadow);
/* 27 */     GlStateManager.pushMatrix();
/* 28 */     GlStateManager.depthMask(false);
/* 29 */     GL11.glDisable(32823);
/* 30 */     GL11.glDepthRange(0.0D, 1.0D);
/* 31 */     GlStateManager.popMatrix();
/*    */   }
/*    */   
/*    */   public static void createColorPre(GSColor color, boolean isPlayer) {
/* 35 */     mc.getRenderManager().setRenderShadow(false);
/* 36 */     mc.getRenderManager().setRenderOutlines(false);
/* 37 */     GlStateManager.pushMatrix();
/* 38 */     GlStateManager.depthMask(true);
/* 39 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/* 40 */     GL11.glEnable(32823);
/* 41 */     GL11.glDepthRange(0.0D, 0.01D);
/* 42 */     GL11.glDisable(3553);
/* 43 */     if (!isPlayer) {
/* 44 */       GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*    */     }
/* 46 */     color.glColor();
/* 47 */     GlStateManager.popMatrix();
/*    */   }
/*    */   
/*    */   public static void createColorPost(boolean isPlayer) {
/* 51 */     boolean shadow = mc.getRenderManager().isRenderShadow();
/* 52 */     mc.getRenderManager().setRenderShadow(shadow);
/* 53 */     GlStateManager.pushMatrix();
/* 54 */     GlStateManager.depthMask(false);
/* 55 */     if (!isPlayer) {
/* 56 */       GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*    */     }
/* 58 */     GL11.glDisable(32823);
/* 59 */     GL11.glDepthRange(0.0D, 1.0D);
/* 60 */     GL11.glEnable(3553);
/* 61 */     GlStateManager.popMatrix();
/*    */   }
/*    */   
/*    */   public static void createWirePre(GSColor color, int lineWidth, boolean isPlayer) {
/* 65 */     mc.getRenderManager().setRenderShadow(false);
/* 66 */     mc.getRenderManager().setRenderOutlines(false);
/* 67 */     GlStateManager.pushMatrix();
/* 68 */     GlStateManager.depthMask(true);
/* 69 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
/* 70 */     GL11.glPolygonMode(1032, 6913);
/* 71 */     GL11.glEnable(10754);
/* 72 */     GL11.glDepthRange(0.0D, 0.01D);
/* 73 */     GL11.glDisable(3553);
/* 74 */     GL11.glDisable(2896);
/* 75 */     GL11.glEnable(2848);
/* 76 */     GL11.glHint(3154, 4354);
/* 77 */     if (!isPlayer) {
/* 78 */       GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*    */     }
/* 80 */     GL11.glLineWidth(lineWidth);
/* 81 */     color.glColor();
/* 82 */     GlStateManager.popMatrix();
/*    */   }
/*    */   
/*    */   public static void createWirePost(boolean isPlayer) {
/* 86 */     boolean shadow = mc.getRenderManager().isRenderShadow();
/* 87 */     mc.getRenderManager().setRenderShadow(shadow);
/* 88 */     GlStateManager.pushMatrix();
/* 89 */     GlStateManager.depthMask(false);
/* 90 */     if (!isPlayer) {
/* 91 */       GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
/*    */     }
/* 93 */     GL11.glPolygonMode(1032, 6914);
/* 94 */     GL11.glDisable(10754);
/* 95 */     GL11.glDepthRange(0.0D, 1.0D);
/* 96 */     GL11.glEnable(3553);
/* 97 */     GL11.glEnable(2896);
/* 98 */     GL11.glDisable(2848);
/* 99 */     GlStateManager.popMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\ChamsUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
