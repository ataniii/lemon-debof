/*     */ package com.lemonclient.api.util.render;
/*     */ 
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.util.glu.GLU;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ 
/*     */ public final class GLUProjection
/*     */ {
/*     */   private static GLUProjection instance;
/*     */   private IntBuffer viewport;
/*     */   private FloatBuffer modelview;
/*     */   private FloatBuffer projection;
/*  15 */   private final FloatBuffer coords = BufferUtils.createFloatBuffer(3);
/*     */   
/*     */   private Vector3D frustumPos;
/*     */   
/*     */   private Vector3D[] frustum;
/*     */   
/*     */   private Vector3D[] invFrustum;
/*     */   private Vector3D viewVec;
/*     */   private double displayWidth;
/*     */   private double displayHeight;
/*     */   private double widthScale;
/*     */   private double heightScale;
/*     */   private double bra;
/*     */   private double bla;
/*     */   private double tra;
/*     */   private double tla;
/*     */   private Line tb;
/*     */   private Line bb;
/*     */   private Line lb;
/*     */   private Line rb;
/*     */   private float fovY;
/*     */   private float fovX;
/*     */   private Vector3D lookVec;
/*     */   
/*     */   public static GLUProjection getInstance() {
/*  40 */     if (instance == null) {
/*  41 */       instance = new GLUProjection();
/*     */     }
/*  43 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateMatrices(IntBuffer viewport, FloatBuffer modelview, FloatBuffer projection, double widthScale, double heightScale) {
/*  48 */     this.viewport = viewport;
/*  49 */     this.modelview = modelview;
/*  50 */     this.projection = projection;
/*  51 */     this.widthScale = widthScale;
/*  52 */     this.heightScale = heightScale;
/*  53 */     float fov = (float)Math.toDegrees(Math.atan(1.0D / this.projection.get(5)) * 2.0D);
/*  54 */     this.displayWidth = this.viewport.get(2);
/*  55 */     this.displayHeight = this.viewport.get(3);
/*  56 */     this.fovX = (float)Math.toDegrees(2.0D * Math.atan(this.displayWidth / this.displayHeight * Math.tan(Math.toRadians(this.fovY) / 2.0D)));
/*  57 */     Vector3D lv = new Vector3D(this.modelview.get(0), this.modelview.get(1), this.modelview.get(2));
/*  58 */     Vector3D uv = new Vector3D(this.modelview.get(4), this.modelview.get(5), this.modelview.get(6));
/*  59 */     Vector3D fv = new Vector3D(this.modelview.get(8), this.modelview.get(9), this.modelview.get(10));
/*  60 */     Vector3D nuv = new Vector3D(0.0D, 1.0D, 0.0D);
/*  61 */     Vector3D nlv = new Vector3D(1.0D, 0.0D, 0.0D);
/*  62 */     double yaw = Math.toDegrees(Math.atan2(nlv.cross(lv).length(), nlv.dot(lv))) + 180.0D;
/*  63 */     if (fv.x < 0.0D) {
/*  64 */       yaw = 360.0D - yaw;
/*     */     }
/*  66 */     double pitch = 0.0D;
/*  67 */     pitch = ((-fv.y > 0.0D && yaw >= 90.0D && yaw < 270.0D) || (fv.y > 0.0D && (yaw < 90.0D || yaw >= 270.0D))) ? Math.toDegrees(Math.atan2(nuv.cross(uv).length(), nuv.dot(uv))) : -Math.toDegrees(Math.atan2(nuv.cross(uv).length(), nuv.dot(uv)));
/*  68 */     this.lookVec = getRotationVector(yaw, pitch);
/*  69 */     Matrix4f modelviewMatrix = new Matrix4f();
/*  70 */     modelviewMatrix.load(this.modelview.asReadOnlyBuffer());
/*  71 */     modelviewMatrix.invert();
/*  72 */     this.frustumPos = new Vector3D(modelviewMatrix.m30, modelviewMatrix.m31, modelviewMatrix.m32);
/*  73 */     this.frustum = getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, yaw, pitch, fov, 1.0D, this.displayWidth / this.displayHeight);
/*  74 */     this.invFrustum = getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, yaw - 180.0D, -pitch, fov, 1.0D, this.displayWidth / this.displayHeight);
/*  75 */     this.viewVec = getRotationVector(yaw, pitch).normalized();
/*  76 */     this.bra = Math.toDegrees(Math.acos(this.displayHeight * heightScale / Math.sqrt(this.displayWidth * widthScale * this.displayWidth * widthScale + this.displayHeight * heightScale * this.displayHeight * heightScale)));
/*  77 */     this.bla = 360.0D - this.bra;
/*  78 */     this.tra = this.bla - 180.0D;
/*  79 */     this.tla = this.bra + 180.0D;
/*  80 */     this.rb = new Line(this.displayWidth * this.widthScale, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D);
/*  81 */     this.tb = new Line(0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
/*  82 */     this.lb = new Line(0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D);
/*  83 */     this.bb = new Line(0.0D, this.displayHeight * this.heightScale, 0.0D, 1.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Projection project(double x, double y, double z, ClampMode clampModeOutside, boolean extrudeInverted) {
/*  88 */     if (this.viewport == null || this.modelview == null || this.projection == null) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/*  89 */     Vector3D posVec = new Vector3D(x, y, z);
/*  90 */     boolean[] frustum = doFrustumCheck(this.frustum, this.frustumPos, x, y, z);
/*  91 */     boolean outsideFrustum = (frustum[0] || frustum[1] || frustum[2] || frustum[3]), bl = outsideFrustum;
/*  92 */     if (outsideFrustum) {
/*     */       
/*  94 */       boolean opposite = (posVec.sub(this.frustumPos).dot(this.viewVec) <= 0.0D);
/*  95 */       boolean[] invFrustum = doFrustumCheck(this.invFrustum, this.frustumPos, x, y, z);
/*  96 */       boolean outsideInvertedFrustum = (invFrustum[0] || invFrustum[1] || invFrustum[2] || invFrustum[3]), bl2 = outsideInvertedFrustum;
/*  97 */       if ((extrudeInverted && !outsideInvertedFrustum) || (outsideInvertedFrustum && clampModeOutside != ClampMode.NONE)) {
/*  98 */         if ((extrudeInverted && !outsideInvertedFrustum) || (clampModeOutside == ClampMode.DIRECT && outsideInvertedFrustum)) {
/*  99 */           double vecX = 0.0D;
/* 100 */           double vecY = 0.0D;
/* 101 */           if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords)) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 102 */           if (opposite) {
/* 103 */             vecX = this.displayWidth * this.widthScale - this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0D;
/* 104 */             vecY = this.displayHeight * this.heightScale - (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0D;
/*     */           } else {
/* 106 */             vecX = this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0D;
/* 107 */             vecY = (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0D;
/*     */           } 
/* 109 */           Vector3D vec = (new Vector3D(vecX, vecY, 0.0D)).snormalize();
/* 110 */           vecX = vec.x;
/* 111 */           vecY = vec.y;
/* 112 */           Line vectorLine = new Line(this.displayWidth * this.widthScale / 2.0D, this.displayHeight * this.heightScale / 2.0D, 0.0D, vecX, vecY, 0.0D);
/* 113 */           double angle = Math.toDegrees(Math.acos(vec.y / Math.sqrt(vec.x * vec.x + vec.y * vec.y)));
/* 114 */           if (vecX < 0.0D) {
/* 115 */             angle = 360.0D - angle;
/*     */           }
/* 117 */           Vector3D intersect = new Vector3D(0.0D, 0.0D, 0.0D);
/* 118 */           intersect = (angle >= this.bra && angle < this.tra) ? this.rb.intersect(vectorLine) : ((angle >= this.tra && angle < this.tla) ? this.tb.intersect(vectorLine) : ((angle >= this.tla && angle < this.bla) ? this.lb.intersect(vectorLine) : this.bb.intersect(vectorLine)));
/* 119 */           return new Projection(intersect.x, intersect.y, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */         } 
/* 121 */         if (clampModeOutside != ClampMode.ORTHOGONAL || !outsideInvertedFrustum) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 122 */         if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords)) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 123 */         double d3 = this.coords.get(0) * this.widthScale;
/* 124 */         double d4 = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 125 */         if (opposite) {
/* 126 */           d3 = this.displayWidth * this.widthScale - d3;
/* 127 */           d4 = this.displayHeight * this.heightScale - d4;
/*     */         } 
/* 129 */         if (d3 < 0.0D) {
/* 130 */           d3 = 0.0D;
/* 131 */         } else if (d3 > this.displayWidth * this.widthScale) {
/* 132 */           d3 = this.displayWidth * this.widthScale;
/*     */         } 
/* 134 */         if (d4 < 0.0D) {
/* 135 */           d4 = 0.0D;
/* 136 */           return new Projection(d3, d4, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */         } 
/* 138 */         if (d4 <= this.displayHeight * this.heightScale) return new Projection(d3, d4, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED); 
/* 139 */         d4 = this.displayHeight * this.heightScale;
/*     */         
/* 141 */         return new Projection(d3, d4, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */       } 
/* 143 */       if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords)) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 144 */       double d1 = this.coords.get(0) * this.widthScale;
/* 145 */       double d2 = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 146 */       if (!opposite) return new Projection(d1, d2, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED); 
/* 147 */       d1 = this.displayWidth * this.widthScale - d1;
/* 148 */       d2 = this.displayHeight * this.heightScale - d2;
/* 149 */       return new Projection(d1, d2, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */     } 
/* 151 */     if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords)) return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 152 */     double guiX = this.coords.get(0) * this.widthScale;
/* 153 */     double guiY = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 154 */     return new Projection(guiX, guiY, Projection.Type.INSIDE);
/*     */   }
/*     */   
/*     */   public boolean[] doFrustumCheck(Vector3D[] frustumCorners, Vector3D frustumPos, double x, double y, double z) {
/* 158 */     Vector3D point = new Vector3D(x, y, z);
/* 159 */     boolean c1 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[3], frustumCorners[0] }, point);
/* 160 */     boolean c2 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[0], frustumCorners[1] }, point);
/* 161 */     boolean c3 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[1], frustumCorners[2] }, point);
/* 162 */     boolean c4 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[2], frustumCorners[3] }, point);
/* 163 */     return new boolean[] { c1, c2, c3, c4 };
/*     */   }
/*     */   
/*     */   public boolean crossPlane(Vector3D[] plane, Vector3D point) {
/* 167 */     Vector3D z = new Vector3D(0.0D, 0.0D, 0.0D);
/* 168 */     Vector3D e0 = plane[1].sub(plane[0]);
/* 169 */     Vector3D e1 = plane[2].sub(plane[0]);
/* 170 */     Vector3D normal = e0.cross(e1).snormalize();
/* 171 */     double D = z.sub(normal).dot(plane[2]);
/* 172 */     double dist = normal.dot(point) + D;
/* 173 */     return (dist >= 0.0D);
/*     */   }
/*     */   
/*     */   public Vector3D[] getFrustum(double x, double y, double z, double rotationYaw, double rotationPitch, double fov, double farDistance, double aspectRatio) {
/* 177 */     double hFar = 2.0D * Math.tan(Math.toRadians(fov / 2.0D)) * farDistance;
/* 178 */     double wFar = hFar * aspectRatio;
/* 179 */     Vector3D view = getRotationVector(rotationYaw, rotationPitch).snormalize();
/* 180 */     Vector3D up = getRotationVector(rotationYaw, rotationPitch - 90.0D).snormalize();
/* 181 */     Vector3D right = getRotationVector(rotationYaw + 90.0D, 0.0D).snormalize();
/* 182 */     Vector3D camPos = new Vector3D(x, y, z);
/* 183 */     Vector3D view_camPos_product = view.add(camPos);
/* 184 */     Vector3D fc = new Vector3D(view_camPos_product.x * farDistance, view_camPos_product.y * farDistance, view_camPos_product.z * farDistance);
/* 185 */     Vector3D topLeftfrustum = new Vector3D(fc.x + up.x * hFar / 2.0D - right.x * wFar / 2.0D, fc.y + up.y * hFar / 2.0D - right.y * wFar / 2.0D, fc.z + up.z * hFar / 2.0D - right.z * wFar / 2.0D);
/* 186 */     Vector3D downLeftfrustum = new Vector3D(fc.x - up.x * hFar / 2.0D - right.x * wFar / 2.0D, fc.y - up.y * hFar / 2.0D - right.y * wFar / 2.0D, fc.z - up.z * hFar / 2.0D - right.z * wFar / 2.0D);
/* 187 */     Vector3D topRightfrustum = new Vector3D(fc.x + up.x * hFar / 2.0D + right.x * wFar / 2.0D, fc.y + up.y * hFar / 2.0D + right.y * wFar / 2.0D, fc.z + up.z * hFar / 2.0D + right.z * wFar / 2.0D);
/* 188 */     Vector3D downRightfrustum = new Vector3D(fc.x - up.x * hFar / 2.0D + right.x * wFar / 2.0D, fc.y - up.y * hFar / 2.0D + right.y * wFar / 2.0D, fc.z - up.z * hFar / 2.0D + right.z * wFar / 2.0D);
/* 189 */     return new Vector3D[] { topLeftfrustum, downLeftfrustum, downRightfrustum, topRightfrustum };
/*     */   }
/*     */   
/*     */   public Vector3D[] getFrustum() {
/* 193 */     return this.frustum;
/*     */   }
/*     */   
/*     */   public float getFovX() {
/* 197 */     return this.fovX;
/*     */   }
/*     */   
/*     */   public float getFovY() {
/* 201 */     return this.fovY;
/*     */   }
/*     */   
/*     */   public Vector3D getLookVector() {
/* 205 */     return this.lookVec;
/*     */   }
/*     */   
/*     */   public Vector3D getRotationVector(double rotYaw, double rotPitch) {
/* 209 */     double c = Math.cos(-rotYaw * 0.01745329238474369D - Math.PI);
/* 210 */     double s = Math.sin(-rotYaw * 0.01745329238474369D - Math.PI);
/* 211 */     double nc = -Math.cos(-rotPitch * 0.01745329238474369D);
/* 212 */     double ns = Math.sin(-rotPitch * 0.01745329238474369D);
/* 213 */     return new Vector3D(s * nc, ns, c * nc);
/*     */   }
/*     */   
/*     */   public enum ClampMode {
/* 217 */     ORTHOGONAL,
/* 218 */     DIRECT,
/* 219 */     NONE;
/*     */   }
/*     */   
/*     */   public static class Projection
/*     */   {
/*     */     private final double x;
/*     */     private final double y;
/*     */     private final Type t;
/*     */     
/*     */     public Projection(double x, double y, Type t) {
/* 229 */       this.x = x;
/* 230 */       this.y = y;
/* 231 */       this.t = t;
/*     */     }
/*     */     
/*     */     public double getX() {
/* 235 */       return this.x;
/*     */     }
/*     */     
/*     */     public double getY() {
/* 239 */       return this.y;
/*     */     }
/*     */     
/*     */     public Type getType() {
/* 243 */       return this.t;
/*     */     }
/*     */     
/*     */     public boolean isType(Type type) {
/* 247 */       return (this.t == type);
/*     */     }
/*     */     
/*     */     public enum Type {
/* 251 */       INSIDE,
/* 252 */       OUTSIDE,
/* 253 */       INVERTED,
/* 254 */       FAIL; } } public enum Type { INSIDE, OUTSIDE, INVERTED, FAIL; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Vector3D
/*     */   {
/*     */     public double x;
/*     */     public double y;
/*     */     public double z;
/*     */     
/*     */     public Vector3D(double x, double y, double z) {
/* 265 */       this.x = x;
/* 266 */       this.y = y;
/* 267 */       this.z = z;
/*     */     }
/*     */     
/*     */     public Vector3D add(Vector3D v) {
/* 271 */       return new Vector3D(this.x + v.x, this.y + v.y, this.z + v.z);
/*     */     }
/*     */     
/*     */     public Vector3D add(double x, double y, double z) {
/* 275 */       return new Vector3D(this.x + x, this.y + y, this.z + z);
/*     */     }
/*     */     
/*     */     public Vector3D sub(Vector3D v) {
/* 279 */       return new Vector3D(this.x - v.x, this.y - v.y, this.z - v.z);
/*     */     }
/*     */     
/*     */     public Vector3D sub(double x, double y, double z) {
/* 283 */       return new Vector3D(this.x - x, this.y - y, this.z - z);
/*     */     }
/*     */     
/*     */     public Vector3D normalized() {
/* 287 */       double len = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 288 */       return new Vector3D(this.x / len, this.y / len, this.z / len);
/*     */     }
/*     */     
/*     */     public double dot(Vector3D v) {
/* 292 */       return this.x * v.x + this.y * v.y + this.z * v.z;
/*     */     }
/*     */     
/*     */     public Vector3D cross(Vector3D v) {
/* 296 */       return new Vector3D(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
/*     */     }
/*     */     
/*     */     public Vector3D mul(double m) {
/* 300 */       return new Vector3D(this.x * m, this.y * m, this.z * m);
/*     */     }
/*     */     
/*     */     public Vector3D div(double d) {
/* 304 */       return new Vector3D(this.x / d, this.y / d, this.z / d);
/*     */     }
/*     */     
/*     */     public double length() {
/* 308 */       return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*     */     }
/*     */     
/*     */     public Vector3D sadd(Vector3D v) {
/* 312 */       this.x += v.x;
/* 313 */       this.y += v.y;
/* 314 */       this.z += v.z;
/* 315 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D sadd(double x, double y, double z) {
/* 319 */       this.x += x;
/* 320 */       this.y += y;
/* 321 */       this.z += z;
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D ssub(Vector3D v) {
/* 326 */       this.x -= v.x;
/* 327 */       this.y -= v.y;
/* 328 */       this.z -= v.z;
/* 329 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D ssub(double x, double y, double z) {
/* 333 */       this.x -= x;
/* 334 */       this.y -= y;
/* 335 */       this.z -= z;
/* 336 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D snormalize() {
/* 340 */       double len = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 341 */       this.x /= len;
/* 342 */       this.y /= len;
/* 343 */       this.z /= len;
/* 344 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D scross(Vector3D v) {
/* 348 */       this.x = this.y * v.z - this.z * v.y;
/* 349 */       this.y = this.z * v.x - this.x * v.z;
/* 350 */       this.z = this.x * v.y - this.y * v.x;
/* 351 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D smul(double m) {
/* 355 */       this.x *= m;
/* 356 */       this.y *= m;
/* 357 */       this.z *= m;
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     public Vector3D sdiv(double d) {
/* 362 */       this.x /= d;
/* 363 */       this.y /= d;
/* 364 */       this.z /= d;
/* 365 */       return this;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 369 */       return "(X: " + this.x + " Y: " + this.y + " Z: " + this.z + ")";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Line {
/* 374 */     public GLUProjection.Vector3D sourcePoint = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 375 */     public GLUProjection.Vector3D direction = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/*     */     
/*     */     public Line(double sx, double sy, double sz, double dx, double dy, double dz) {
/* 378 */       this.sourcePoint.x = sx;
/* 379 */       this.sourcePoint.y = sy;
/* 380 */       this.sourcePoint.z = sz;
/* 381 */       this.direction.x = dx;
/* 382 */       this.direction.y = dy;
/* 383 */       this.direction.z = dz;
/*     */     }
/*     */     
/*     */     public GLUProjection.Vector3D intersect(Line line) {
/* 387 */       double a = this.sourcePoint.x;
/* 388 */       double b = this.direction.x;
/* 389 */       double c = line.sourcePoint.x;
/* 390 */       double d = line.direction.x;
/* 391 */       double e = this.sourcePoint.y;
/* 392 */       double f = this.direction.y;
/* 393 */       double g = line.sourcePoint.y;
/* 394 */       double h = line.direction.y;
/* 395 */       double te = -(a * h - c * h - d * (e - g));
/* 396 */       double be = b * h - d * f;
/* 397 */       if (be == 0.0D) {
/* 398 */         return intersectXZ(line);
/*     */       }
/* 400 */       double t = te / be;
/* 401 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 402 */       this.sourcePoint.x += this.direction.x * t;
/* 403 */       this.sourcePoint.y += this.direction.y * t;
/* 404 */       this.sourcePoint.z += this.direction.z * t;
/* 405 */       return result;
/*     */     }
/*     */     
/*     */     private GLUProjection.Vector3D intersectXZ(Line line) {
/* 409 */       double a = this.sourcePoint.x;
/* 410 */       double b = this.direction.x;
/* 411 */       double c = line.sourcePoint.x;
/* 412 */       double d = line.direction.x;
/* 413 */       double e = this.sourcePoint.z;
/* 414 */       double f = this.direction.z;
/* 415 */       double g = line.sourcePoint.z;
/* 416 */       double h = line.direction.z;
/* 417 */       double te = -(a * h - c * h - d * (e - g));
/* 418 */       double be = b * h - d * f;
/* 419 */       if (be == 0.0D) {
/* 420 */         return intersectYZ(line);
/*     */       }
/* 422 */       double t = te / be;
/* 423 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 424 */       this.sourcePoint.x += this.direction.x * t;
/* 425 */       this.sourcePoint.y += this.direction.y * t;
/* 426 */       this.sourcePoint.z += this.direction.z * t;
/* 427 */       return result;
/*     */     }
/*     */     
/*     */     private GLUProjection.Vector3D intersectYZ(Line line) {
/* 431 */       double a = this.sourcePoint.y;
/* 432 */       double b = this.direction.y;
/* 433 */       double c = line.sourcePoint.y;
/* 434 */       double d = line.direction.y;
/* 435 */       double e = this.sourcePoint.z;
/* 436 */       double f = this.direction.z;
/* 437 */       double g = line.sourcePoint.z;
/* 438 */       double h = line.direction.z;
/* 439 */       double te = -(a * h - c * h - d * (e - g));
/* 440 */       double be = b * h - d * f;
/* 441 */       if (be == 0.0D) {
/* 442 */         return null;
/*     */       }
/* 444 */       double t = te / be;
/* 445 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 446 */       this.sourcePoint.x += this.direction.x * t;
/* 447 */       this.sourcePoint.y += this.direction.y * t;
/* 448 */       this.sourcePoint.z += this.direction.z * t;
/* 449 */       return result;
/*     */     }
/*     */     
/*     */     public GLUProjection.Vector3D intersectPlane(GLUProjection.Vector3D pointOnPlane, GLUProjection.Vector3D planeNormal) {
/* 453 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(this.sourcePoint.x, this.sourcePoint.y, this.sourcePoint.z);
/* 454 */       double d = pointOnPlane.sub(this.sourcePoint).dot(planeNormal) / this.direction.dot(planeNormal);
/* 455 */       result.sadd(this.direction.mul(d));
/* 456 */       if (this.direction.dot(planeNormal) == 0.0D) {
/* 457 */         return null;
/*     */       }
/* 459 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\GLUProjection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */