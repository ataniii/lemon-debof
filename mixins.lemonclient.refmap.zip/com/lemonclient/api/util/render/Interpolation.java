//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class Interpolation
/*    */ {
/*  7 */   public static Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   public static double getRenderPosX() {
/* 10 */     return (mc.getRenderManager()).renderPosX;
/*    */   }
/*    */ 
/*    */   
/*    */   public static double getRenderPosY() {
/* 15 */     return (mc.getRenderManager()).renderPosY;
/*    */   }
/*    */ 
/*    */   
/*    */   public static double getRenderPosZ() {
/* 20 */     return (mc.getRenderManager()).renderPosZ;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\Interpolation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
