/*     */ package com.lemonclient.api.util.render;
/*     */ 
/*     */ public class FadeUtils
/*     */ {
/*     */   protected long start;
/*     */   protected long length;
/*     */   
/*     */   public FadeUtils(long ms) {
/*   9 */     this.length = ms;
/*  10 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  14 */     this.start = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public boolean isEnd() {
/*  18 */     return (getTime() >= this.length);
/*     */   }
/*     */   
/*     */   public FadeUtils end() {
/*  22 */     this.start = System.currentTimeMillis() - this.length;
/*  23 */     return this;
/*     */   }
/*     */   
/*     */   protected long getTime() {
/*  27 */     return System.currentTimeMillis() - this.start;
/*     */   }
/*     */   
/*     */   public void setLength(long length) {
/*  31 */     this.length = length;
/*     */   }
/*     */   
/*     */   public long getLength() {
/*  35 */     return this.length;
/*     */   }
/*     */   
/*     */   public double getFadeOne() {
/*  39 */     return isEnd() ? 1.0D : (getTime() / this.length);
/*     */   }
/*     */   
/*     */   public double toDelta() {
/*  43 */     double value = toDelta(this.start) / this.length;
/*  44 */     if (value > 1.0D) value = 1.0D; 
/*  45 */     if (value < 0.0D) value = 0.0D; 
/*  46 */     return value;
/*     */   }
/*     */   
/*     */   public long toDelta(long start) {
/*  50 */     return System.currentTimeMillis() - start;
/*     */   }
/*     */   
/*     */   public double getFade(String fadeMode) {
/*  54 */     return getFade(fadeMode, getFadeOne());
/*     */   }
/*     */   
/*     */   public static double getFade(String fadeMode, double current) {
/*  58 */     switch (fadeMode) {
/*     */       case "FADE_IN":
/*  60 */         return getFadeInDefault(current);
/*     */       case "FADE_OUT":
/*  62 */         return getFadeOutDefault(current);
/*     */       case "FADE_EPS_IN":
/*  64 */         return getEpsEzFadeIn(current);
/*     */       case "FADE_EPS_OUT":
/*  66 */         return getEpsEzFadeOut(current);
/*     */       case "FADE_EASE_IN_QUAD":
/*  68 */         return easeInQuad(current);
/*     */       case "FADE_EASE_OUT_QUAD":
/*  70 */         return easeOutQuad(current);
/*     */     } 
/*  72 */     return current;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getFadeType(String fadeType, boolean FadeIn, double current) {
/*  77 */     switch (fadeType) {
/*     */       case "FADE_DEFAULT":
/*  79 */         return FadeIn ? getFadeInDefault(current) : getFadeOutDefault(current);
/*     */       case "FADE_EPS":
/*  81 */         return FadeIn ? getEpsEzFadeIn(current) : getEpsEzFadeOut(current);
/*     */       case "FADE_EASE_QUAD":
/*  83 */         return FadeIn ? easeInQuad(current) : easeOutQuad(current);
/*     */     } 
/*  85 */     return FadeIn ? current : (1.0D - current);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double checkOne(double one) {
/* 110 */     return Math.max(0.0D, Math.min(1.0D, one));
/*     */   }
/*     */   
/*     */   public static double getFadeInDefault(double current) {
/* 114 */     return Math.tanh(checkOne(current) * 3.0D);
/*     */   }
/*     */   
/*     */   public static double getFadeOutDefault(double current) {
/* 118 */     return 1.0D - getFadeInDefault(current);
/*     */   }
/*     */   
/*     */   public static double getEpsEzFadeIn(double current) {
/* 122 */     return 1.0D - getEpsEzFadeOut(current);
/*     */   }
/*     */   
/*     */   public static double getEpsEzFadeOut(double current) {
/* 126 */     return Math.cos(1.5707963267948966D * checkOne(current)) * Math.cos(2.5132741228718345D * checkOne(current));
/*     */   }
/*     */   
/*     */   public static double easeOutQuad(double current) {
/* 130 */     return 1.0D - easeInQuad(current);
/*     */   }
/*     */   
/*     */   public static double easeInQuad(double current) {
/* 134 */     return checkOne(current) * checkOne(current);
/*     */   }
/*     */   
/*     */   public double getEpsEzFadeInGUI() {
/* 138 */     if (isEnd()) {
/* 139 */       return 1.0D;
/*     */     }
/* 141 */     return Math.sin(getFadeOne());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\FadeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */