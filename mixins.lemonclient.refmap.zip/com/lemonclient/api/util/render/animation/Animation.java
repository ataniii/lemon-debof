//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.render.animation;
/*     */ 
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ public class Animation
/*     */ {
/*     */   private double start;
/*     */   private double end;
/*     */   private double speed;
/*     */   private double current;
/*     */   private double last;
/*  13 */   private double progress = 0.0D;
/*     */   
/*     */   private boolean backwards;
/*     */   
/*     */   private boolean reverseOnEnd;
/*     */   private boolean playing;
/*     */   private AnimationMode mode;
/*     */   
/*     */   public Animation(double start, double end, double speed, boolean backwards, AnimationMode mode) {
/*  22 */     this.start = start;
/*  23 */     this.end = end;
/*  24 */     this.speed = speed;
/*  25 */     this.backwards = backwards;
/*  26 */     this.current = start;
/*  27 */     this.last = start;
/*  28 */     this.mode = mode;
/*  29 */     this.playing = true;
/*     */   }
/*     */   
/*     */   public Animation(double start, double end, double speed, boolean backwards, boolean reverseOnEnd, AnimationMode mode) {
/*  33 */     this.start = start;
/*  34 */     this.end = end;
/*  35 */     this.speed = speed;
/*  36 */     this.backwards = backwards;
/*  37 */     this.reverseOnEnd = reverseOnEnd;
/*  38 */     this.current = start;
/*  39 */     this.last = start;
/*  40 */     this.mode = mode;
/*  41 */     this.playing = true;
/*     */   }
/*     */   
/*     */   public void add(float partialTicks) {
/*  45 */     if (this.playing) {
/*  46 */       this.last = this.current;
/*  47 */       if (this.mode == AnimationMode.LINEAR) {
/*  48 */         this.current += (this.backwards ? -1 : true) * this.speed;
/*  49 */       } else if (this.mode == AnimationMode.EXPONENTIAL) {
/*  50 */         for (int i = 0; i < 1.0F / partialTicks; i++) {
/*  51 */           this.current += this.speed;
/*  52 */           this.speed *= this.speed;
/*  53 */           if (this.speed > 0.0D && this.backwards) {
/*  54 */             this.speed *= -1.0D;
/*     */           }
/*     */         } 
/*     */       } 
/*  58 */       this.current = MathHelper.clamp(this.current, this.start, this.end);
/*  59 */       if (this.current >= this.end) {
/*  60 */         if (this.reverseOnEnd) {
/*  61 */           this.backwards = !this.backwards;
/*     */         } else {
/*  63 */           this.playing = false;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getStart() {
/*  71 */     return this.start;
/*     */   }
/*     */   
/*     */   public void setStart(double start) {
/*  75 */     this.start = start;
/*     */   }
/*     */   
/*     */   public double getEnd() {
/*  79 */     return this.end;
/*     */   }
/*     */   
/*     */   public void setEnd(double end) {
/*  83 */     this.end = end;
/*     */   }
/*     */   
/*     */   public double getSpeed() {
/*  87 */     return this.speed;
/*     */   }
/*     */   
/*     */   public void setSpeed(double speed) {
/*  91 */     this.speed = speed;
/*     */   }
/*     */   
/*     */   public double getCurrent() {
/*  95 */     return this.current;
/*     */   }
/*     */   
/*     */   public double getCurrent(float partialTicks) {
/*  99 */     return this.playing ? (this.last + (this.current - this.last) * partialTicks) : this.current;
/*     */   }
/*     */   
/*     */   public void setCurrent(double current) {
/* 103 */     this.current = current;
/*     */   }
/*     */   
/*     */   public AnimationMode getMode() {
/* 107 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(AnimationMode mode) {
/* 111 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public boolean isPlaying() {
/* 115 */     return this.playing;
/*     */   }
/*     */   
/*     */   public void play() {
/* 119 */     this.playing = true;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 123 */     this.playing = false;
/*     */   }
/*     */   
/*     */   public boolean isBackwards() {
/* 127 */     return this.backwards;
/*     */   }
/*     */   
/*     */   public void setBackwards(boolean backwards) {
/* 131 */     this.backwards = backwards;
/*     */   }
/*     */   
/*     */   public boolean isReverseOnEnd() {
/* 135 */     return this.reverseOnEnd;
/*     */   }
/*     */   
/*     */   public void setReverseOnEnd(boolean reverseOnEnd) {
/* 139 */     this.reverseOnEnd = reverseOnEnd;
/*     */   }
/*     */   
/*     */   public double getProgress() {
/* 143 */     return this.progress;
/*     */   }
/*     */   
/*     */   public void setProgress(double progress) {
/* 147 */     this.progress = progress;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\animation\Animation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
