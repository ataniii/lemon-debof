//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render.animation;
/*    */ 
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ public class TimeAnimation {
/*    */   private final long length;
/*    */   private final double start;
/*    */   private final double end;
/*    */   private double current;
/*    */   private double progress;
/*    */   private boolean playing;
/*    */   private boolean backwards;
/*    */   private boolean reverseOnEnd;
/*    */   private long lastTime;
/*    */   private double per;
/*    */   private AnimationMode mode;
/*    */   
/*    */   public TimeAnimation(long length, double start, double end, boolean backwards, AnimationMode mode) {
/*    */     double dif;
/*    */     boolean flag;
/*    */     int i;
/* 22 */     this.length = length;
/* 23 */     this.start = start;
/* 24 */     this.current = start;
/* 25 */     this.end = end;
/* 26 */     this.mode = mode;
/* 27 */     this.backwards = backwards;
/* 28 */     this.playing = true;
/* 29 */     switch (mode) {
/*    */       case LINEAR:
/* 31 */         this.per = (end - start) / length;
/*    */         break;
/*    */       case EXPONENTIAL:
/* 34 */         dif = end - start;
/* 35 */         flag = (dif < 0.0D);
/* 36 */         if (flag) dif *= -1.0D; 
/* 37 */         for (i = 0; i < length; i++) {
/* 38 */           dif = Math.sqrt(dif);
/*    */         }
/* 40 */         this.per = dif;
/*    */         break;
/*    */     } 
/* 43 */     this.lastTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void add() {
/* 47 */     if (this.playing) {
/* 48 */       if (this.mode == AnimationMode.LINEAR) {
/* 49 */         this.current = this.start + this.progress;
/* 50 */         this.progress += this.per * (System.currentTimeMillis() - this.lastTime);
/*    */       } 
/* 52 */       this.current = MathHelper.clamp(this.current, this.start, this.end);
/* 53 */       if (this.current >= this.end || (this.backwards && this.current <= this.start)) {
/* 54 */         if (this.reverseOnEnd) {
/* 55 */           reverse();
/* 56 */           this.reverseOnEnd = false;
/*    */         } else {
/* 58 */           this.playing = false;
/*    */         } 
/*    */       }
/*    */     } 
/* 62 */     this.lastTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public long getLength() {
/* 66 */     return this.length;
/*    */   }
/*    */   
/*    */   public double getStart() {
/* 70 */     return this.start;
/*    */   }
/*    */   
/*    */   public double getEnd() {
/* 74 */     return this.end;
/*    */   }
/*    */   
/*    */   public double getCurrent() {
/* 78 */     return this.current;
/*    */   }
/*    */   
/*    */   public AnimationMode getMode() {
/* 82 */     return this.mode;
/*    */   }
/*    */   
/*    */   public void setMode(AnimationMode mode) {
/* 86 */     this.mode = mode;
/*    */   }
/*    */   
/*    */   public void play() {
/* 90 */     this.playing = true;
/*    */   }
/*    */   
/*    */   public void stop() {
/* 94 */     this.playing = false;
/*    */   }
/*    */   
/*    */   public void reverse() {
/* 98 */     this.backwards = !this.backwards;
/* 99 */     this.per *= -1.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\animation\TimeAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
