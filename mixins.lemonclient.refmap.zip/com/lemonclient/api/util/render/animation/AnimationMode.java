/*   */ package com.lemonclient.api.util.render.animation;
/*   */ 
/*   */ public enum AnimationMode {
/* 4 */   LINEAR,
/* 5 */   EXPONENTIAL;
/*   */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\animation\AnimationMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */