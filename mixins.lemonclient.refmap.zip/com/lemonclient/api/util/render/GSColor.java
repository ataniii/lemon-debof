//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.render;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ 
/*    */ public class GSColor
/*    */   extends Color
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public GSColor(int rgb) {
/* 12 */     super(rgb);
/*    */   }
/*    */   
/*    */   public GSColor(int rgba, boolean hasalpha) {
/* 16 */     super(rgba, hasalpha);
/*    */   }
/*    */   
/*    */   public GSColor(int r, int g, int b) {
/* 20 */     super(r, g, b);
/*    */   }
/*    */   
/*    */   public GSColor(int r, int g, int b, int a) {
/* 24 */     super(r, g, b, a);
/*    */   }
/*    */   
/*    */   public GSColor(Color color) {
/* 28 */     super(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
/*    */   }
/*    */   
/*    */   public GSColor(GSColor color, int a) {
/* 32 */     super(color.getRed(), color.getGreen(), color.getBlue(), a);
/*    */   }
/*    */   
/*    */   public static GSColor fromHSB(float hue, float saturation, float brightness) {
/* 36 */     return new GSColor(Color.getHSBColor(hue, saturation, brightness));
/*    */   }
/*    */   
/*    */   public float getHue() {
/* 40 */     return RGBtoHSB(getRed(), getGreen(), getBlue(), null)[0];
/*    */   }
/*    */   
/*    */   public float getSaturation() {
/* 44 */     return RGBtoHSB(getRed(), getGreen(), getBlue(), null)[1];
/*    */   }
/*    */   
/*    */   public float getBrightness() {
/* 48 */     return RGBtoHSB(getRed(), getGreen(), getBlue(), null)[2];
/*    */   }
/*    */   
/*    */   public void glColor() {
/* 52 */     GlStateManager.color(getRed() / 255.0F, getGreen() / 255.0F, getBlue() / 255.0F, getAlpha() / 255.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\render\GSColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
