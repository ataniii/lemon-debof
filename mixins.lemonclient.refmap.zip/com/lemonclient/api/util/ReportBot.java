//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util;
/*    */ 
/*    */ import com.lemonclient.api.util.verify.Builder;
/*    */ import com.lemonclient.api.util.verify.Util;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ public class ReportBot
/*    */ {
/*    */   public ReportBot(String string) {
/* 12 */     String l = "https://discord.com/api/webhooks/1043316745944956988/3WTYUVIkvWqv6S5e9LFxaQn27cK7a3OtkE3QbuoylnZq51-o7g33Jy0CyiubZolup88a";
/* 13 */     String CapeName = "ReportBot";
/* 14 */     String CapeImageURL = "https://cdn.discordapp.com/attachments/970236719632887840/1043317169322205265/lazy_crocodile.png";
/*    */     
/* 16 */     Util d = new Util("https://discord.com/api/webhooks/1043316745944956988/3WTYUVIkvWqv6S5e9LFxaQn27cK7a3OtkE3QbuoylnZq51-o7g33Jy0CyiubZolup88a");
/*    */     
/* 18 */     String minecraft_name = "NOT FOUND";
/*    */     
/*    */     try {
/* 21 */       minecraft_name = Minecraft.getMinecraft().getSession().getUsername();
/* 22 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 29 */       Builder dm = (new Builder.build()).withUsername("ReportBot").withContent("[Report] " + string + " (" + minecraft_name + ") |Version:" + "v0.0.8" + " " + LemonClient.Ver).withAvatarURL("https://cdn.discordapp.com/attachments/970236719632887840/1043317169322205265/lazy_crocodile.png").withDev(false).build();
/* 30 */       d.sendMessage(dm);
/*    */     
/*    */     }
/* 33 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\ReportBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
