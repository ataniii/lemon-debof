//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class BurrowUtil {
/*  26 */   public static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static void placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking, boolean swing) {
/*  30 */     if (pos == null || !BlockUtil.isAir(pos))
/*  31 */       return;  EnumFacing side = getFirstFacing(pos);
/*  32 */     if (side == null) {
/*     */       return;
/*     */     }
/*  35 */     BlockPos neighbour = pos.offset(side);
/*  36 */     EnumFacing opposite = side.getOpposite();
/*     */     
/*  38 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*  39 */     boolean sneak = false;
/*  40 */     if (!ColorMain.INSTANCE.sneaking && BlockUtil.blackList.contains(BlockUtil.getBlock(neighbour))) {
/*  41 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*  42 */       mc.player.setSneaking(true);
/*  43 */       sneak = true;
/*     */     } 
/*     */     
/*  46 */     if (rotate) {
/*  47 */       faceVector(hitVec, true);
/*     */     }
/*     */     
/*  50 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet, swing);
/*  51 */     if (sneak) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/*  52 */     mc.rightClickDelayTimer = 4;
/*     */   }
/*     */   
/*     */   public static void placeBlockDown(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking, boolean swing) {
/*  56 */     if (pos == null || !BlockUtil.isAir(pos))
/*  57 */       return;  EnumFacing side = getFirstFacing(pos);
/*  58 */     if (side == null) side = EnumFacing.DOWN; 
/*  59 */     BlockPos neighbour = pos.offset(side);
/*  60 */     EnumFacing opposite = side.getOpposite();
/*     */     
/*  62 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*  63 */     boolean sneak = false;
/*  64 */     if (!ColorMain.INSTANCE.sneaking && BlockUtil.blackList.contains(BlockUtil.getBlock(neighbour))) {
/*  65 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*  66 */       mc.player.setSneaking(true);
/*  67 */       sneak = true;
/*     */     } 
/*     */     
/*  70 */     if (rotate) {
/*  71 */       faceVector(hitVec, true);
/*     */     }
/*     */     
/*  74 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet, swing);
/*  75 */     if (sneak) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/*  76 */     mc.rightClickDelayTimer = 4;
/*     */   }
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/*  80 */     if (pos == null) return null; 
/*  81 */     List<EnumFacing> facings = new ArrayList<>();
/*  82 */     for (EnumFacing side : EnumFacing.values()) {
/*  83 */       BlockPos neighbour = pos.offset(side);
/*  84 */       if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/*  85 */         IBlockState blockState = mc.world.getBlockState(neighbour);
/*  86 */         if (!blockState.getMaterial().isReplaceable()) {
/*  87 */           facings.add(side);
/*     */         }
/*     */       } 
/*     */     } 
/*  91 */     return facings;
/*     */   }
/*     */   
/*  94 */   static EnumFacing[] facing = new EnumFacing[] { EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.WEST, EnumFacing.EAST };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<EnumFacing> getTrapdoorPossibleSides(BlockPos pos) {
/* 102 */     if (pos == null) return null; 
/* 103 */     List<EnumFacing> facings = new ArrayList<>();
/* 104 */     for (EnumFacing side : facing) {
/* 105 */       BlockPos neighbour = pos.offset(side);
/* 106 */       if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/* 107 */         IBlockState blockState = mc.world.getBlockState(neighbour);
/* 108 */         if (!blockState.getMaterial().isReplaceable()) {
/* 109 */           facings.add(side);
/*     */         }
/*     */       } 
/*     */     } 
/* 113 */     return facings;
/*     */   }
/*     */   
/*     */   public static EnumFacing getFirstFacing(BlockPos pos) {
/* 117 */     if (pos == null) return null; 
/* 118 */     Iterator<EnumFacing> iterator = getPossibleSides(pos).iterator(); if (iterator.hasNext()) { EnumFacing facing = iterator.next();
/* 119 */       return facing; }
/*     */     
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   public static EnumFacing getBedFacing(BlockPos pos) {
/* 125 */     if (pos == null) return null; 
/* 126 */     for (EnumFacing facing : getPossibleSides(pos)) {
/* 127 */       if (facing == EnumFacing.UP)
/* 128 */         continue;  return facing;
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public static EnumFacing getTrapdoorFacing(BlockPos pos) {
/* 134 */     if (pos == null) return null; 
/* 135 */     Iterator<EnumFacing> iterator = getTrapdoorPossibleSides(pos).iterator(); if (iterator.hasNext()) { EnumFacing facing = iterator.next();
/* 136 */       return facing; }
/*     */     
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   public static Vec3d getEyesPos() {
/* 142 */     return new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */   
/*     */   public static float[] getLegitRotations(Vec3d vec) {
/* 146 */     Vec3d eyesPos = getEyesPos();
/* 147 */     double diffX = vec.x - eyesPos.x;
/* 148 */     double diffY = vec.y - eyesPos.y;
/* 149 */     double diffZ = vec.z - eyesPos.z;
/* 150 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*     */     
/* 152 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 153 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*     */     
/* 155 */     return new float[] { mc.player.rotationYaw + 
/* 156 */         MathHelper.wrapDegrees(yaw - mc.player.rotationYaw), mc.player.rotationPitch + 
/* 157 */         MathHelper.wrapDegrees(pitch - mc.player.rotationPitch) };
/*     */   }
/*     */ 
/*     */   
/*     */   public static void faceVector(Vec3d vec, boolean normalizeAngle) {
/* 162 */     float[] rotations = getLegitRotations(vec);
/* 163 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotations[0], normalizeAngle ? MathHelper.normalizeAngle((int)rotations[1], 360) : rotations[1], mc.player.onGround));
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet, boolean swing) {
/* 167 */     if (pos == null || vec == null || hand == null || direction == null)
/* 168 */       return;  if (packet) {
/* 169 */       float f = (float)(vec.x - pos.getX());
/* 170 */       float f1 = (float)(vec.y - pos.getY());
/* 171 */       float f2 = (float)(vec.z - pos.getZ());
/* 172 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     } else {
/* 174 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, direction, vec, hand);
/*     */     } 
/* 176 */     if (swing) {
/* 177 */       mc.player.swingArm(hand);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
/* 182 */     if (pos == null || vec == null || direction == null)
/* 183 */       return;  if (packet) { mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, 0.5F, 1.0F, 0.5F)); }
/* 184 */     else { mc.playerController.processRightClickBlock(mc.player, mc.world, pos, direction, vec, hand); }
/*     */   
/*     */   }
/*     */   public static void rightClickBlock(BlockPos pos, EnumFacing facing, Vec3d hVec, boolean packet, boolean swing) {
/* 188 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(hVec).add((new Vec3d(facing.getDirectionVec())).scale(0.5D));
/*     */     
/* 190 */     if (packet) {
/* 191 */       rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, facing);
/*     */     } else {
/* 193 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, hitVec, EnumHand.MAIN_HAND);
/*     */     } 
/* 195 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction) {
/* 199 */     float f = (float)(vec.x - pos.getX());
/* 200 */     float f1 = (float)(vec.y - pos.getY());
/* 201 */     float f2 = (float)(vec.z - pos.getZ());
/* 202 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static int findBlock(Class clazz, boolean inv) {
/* 207 */     int slot = findHotbarBlock(clazz);
/* 208 */     if (slot == -1 && inv) slot = findInventoryBlock(clazz); 
/* 209 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Class clazz) {
/* 213 */     for (int i = 0; i < 9; i++) {
/* 214 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 215 */       if (stack != ItemStack.EMPTY) {
/*     */ 
/*     */ 
/*     */         
/* 219 */         if (clazz.isInstance(stack.getItem())) {
/* 220 */           return i;
/*     */         }
/*     */         
/* 223 */         if (stack.getItem() instanceof ItemBlock) {
/* 224 */           Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 225 */           if (clazz.isInstance(block))
/* 226 */             return i; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 230 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Block blockIn) {
/* 234 */     for (int i = 0; i < 9; ) {
/* 235 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 236 */       if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock) || ((ItemBlock)stack.getItem()).getBlock() != blockIn) {
/*     */         i++; continue;
/* 238 */       }  return i;
/*     */     } 
/* 240 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findHotbarItem(Item input) {
/* 244 */     for (int i = 0; i < 9; ) {
/* 245 */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/* 246 */       if (Item.getIdFromItem(item) != Item.getIdFromItem(input)) { i++; continue; }
/* 247 */        return i;
/*     */     } 
/* 249 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int findInventoryItem(Item input) {
/* 254 */     for (int i = 0; i < 36; ) {
/* 255 */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/* 256 */       if (Item.getIdFromItem(item) != Item.getIdFromItem(input)) { i++; continue; }
/* 257 */        return i;
/*     */     } 
/* 259 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findInventoryBlock(Class clazz) {
/* 263 */     for (int i = 9; i < 36; i++) {
/* 264 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 265 */       if (stack != ItemStack.EMPTY) {
/*     */ 
/*     */ 
/*     */         
/* 269 */         if (clazz.isInstance(stack.getItem())) {
/* 270 */           return i;
/*     */         }
/*     */         
/* 273 */         if (stack.getItem() instanceof ItemBlock) {
/* 274 */           Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 275 */           if (clazz.isInstance(block))
/* 276 */             return i; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 280 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getCount(Class clazz) {
/* 284 */     int count = 0;
/* 285 */     for (int i = 0; i < 36; i++) {
/* 286 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 287 */       if (stack != ItemStack.EMPTY) {
/*     */ 
/*     */ 
/*     */         
/* 291 */         if (clazz.isInstance(stack.getItem())) {
/* 292 */           count += stack.getCount();
/*     */         }
/*     */         
/* 295 */         if (stack.getItem() instanceof ItemBlock) {
/* 296 */           Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 297 */           if (clazz.isInstance(block))
/* 298 */             count += stack.getCount(); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 302 */     return count;
/*     */   }
/*     */   
/*     */   public static void switchToSlot(int slot) {
/* 306 */     mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
/* 307 */     mc.player.inventory.currentItem = slot;
/* 308 */     mc.playerController.updateController();
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\BurrowUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
