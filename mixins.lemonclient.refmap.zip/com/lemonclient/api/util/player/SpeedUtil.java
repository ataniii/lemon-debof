//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class SpeedUtil
/*     */ {
/*  12 */   static Minecraft mc = Minecraft.getMinecraft();
/*     */   public static final double LAST_JUMP_INFO_DURATION_DEFAULT = 3.0D;
/*     */   public static boolean didJumpThisTick = false;
/*     */   public static boolean isJumping = false;
/*  16 */   public double firstJumpSpeed = 0.0D;
/*  17 */   public double lastJumpSpeed = 0.0D;
/*  18 */   public double percentJumpSpeedChanged = 0.0D;
/*  19 */   public double jumpSpeedChanged = 0.0D;
/*     */   public boolean didJumpLastTick = false;
/*  21 */   public long jumpInfoStartTime = 0L;
/*     */   public boolean wasFirstJump = true;
/*  23 */   public double speedometerCurrentSpeed = 0.0D;
/*  24 */   public HashMap<EntityPlayer, Info> playerInfo = new HashMap<>();
/*     */   
/*     */   public static void setDidJumpThisTick(boolean val) {
/*  27 */     didJumpThisTick = val;
/*     */   }
/*     */   
/*     */   public static void setIsJumping(boolean val) {
/*  31 */     isJumping = val;
/*     */   }
/*     */   
/*     */   public float lastJumpInfoTimeRemaining() {
/*  35 */     return (float)(Minecraft.getSystemTime() - this.jumpInfoStartTime) / 1000.0F;
/*     */   }
/*     */   
/*     */   public void update() {
/*  39 */     double distTraveledLastTickX = mc.player.posX - mc.player.prevPosX;
/*  40 */     double distTraveledLastTickZ = mc.player.posZ - mc.player.prevPosZ;
/*  41 */     this.speedometerCurrentSpeed = distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ;
/*  42 */     if (didJumpThisTick && (!mc.player.onGround || isJumping)) {
/*  43 */       if (!this.didJumpLastTick) {
/*  44 */         this.wasFirstJump = (this.lastJumpSpeed == 0.0D);
/*  45 */         this.percentJumpSpeedChanged = (this.speedometerCurrentSpeed != 0.0D) ? (this.speedometerCurrentSpeed / this.lastJumpSpeed - 1.0D) : -1.0D;
/*  46 */         this.jumpSpeedChanged = this.speedometerCurrentSpeed - this.lastJumpSpeed;
/*  47 */         this.jumpInfoStartTime = Minecraft.getSystemTime();
/*  48 */         this.lastJumpSpeed = this.speedometerCurrentSpeed;
/*  49 */         this.firstJumpSpeed = this.wasFirstJump ? this.lastJumpSpeed : 0.0D;
/*     */       } 
/*  51 */       this.didJumpLastTick = didJumpThisTick;
/*     */     } else {
/*  53 */       this.didJumpLastTick = false;
/*  54 */       this.lastJumpSpeed = 0.0D;
/*     */     } 
/*  56 */     updatePlayers();
/*     */   }
/*     */   
/*     */   public void updatePlayers() {
/*  60 */     for (EntityPlayer player : mc.world.playerEntities) {
/*  61 */       int distance = 20;
/*  62 */       if (mc.player.getDistanceSq((Entity)player) >= (distance * distance))
/*     */         continue; 
/*  64 */       Vec3d lastPos = null;
/*  65 */       if (this.playerInfo.get(player) != null) {
/*  66 */         Info info = this.playerInfo.get(player);
/*  67 */         lastPos = info.pos;
/*     */       } 
/*  69 */       this.playerInfo.put(player, new Info(player, lastPos));
/*     */     } 
/*     */   }
/*     */   
/*     */   public double getPlayerSpeed(EntityPlayer player) {
/*  74 */     if (player == null) return 0.0D; 
/*  75 */     if (this.playerInfo.get(player) == null) {
/*  76 */       return 0.0D;
/*     */     }
/*  78 */     return turnIntoKpH(((Info)this.playerInfo.get(player)).speed);
/*     */   }
/*     */   public Vec3d getPlayerLastPos(EntityPlayer player) {
/*  81 */     if (player == null) return null; 
/*  82 */     if (this.playerInfo.get(player) == null) return null; 
/*  83 */     return ((Info)this.playerInfo.get(player)).lastPos;
/*     */   }
/*     */   public double getPlayerMoveYaw(EntityPlayer player) {
/*  86 */     if (player == null) return 0.0D; 
/*  87 */     if (this.playerInfo.get(player) == null) return 0.0D; 
/*  88 */     return ((Info)this.playerInfo.get(player)).yaw;
/*     */   }
/*     */   public double turnIntoKpH(double input) {
/*  91 */     return MathHelper.sqrt(input) * 71.2729367892D;
/*     */   }
/*     */   
/*     */   public double getSpeedKpH() {
/*  95 */     double speedometerkphdouble = turnIntoKpH(this.speedometerCurrentSpeed);
/*  96 */     speedometerkphdouble = Math.round(10.0D * speedometerkphdouble) / 10.0D;
/*  97 */     return speedometerkphdouble;
/*     */   }
/*     */   
/*     */   public double getSpeedMpS() {
/* 101 */     double speedometerMpsdouble = turnIntoKpH(this.speedometerCurrentSpeed) / 3.6D;
/* 102 */     speedometerMpsdouble = Math.round(10.0D * speedometerMpsdouble) / 10.0D;
/* 103 */     return speedometerMpsdouble;
/*     */   }
/*     */   
/*     */   public static double calcSpeed(EntityPlayer player) {
/* 107 */     double distTraveledLastTickX = player.posX - player.prevPosX;
/* 108 */     double distTraveledLastTickZ = player.posZ - player.prevPosZ;
/* 109 */     return distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ;
/*     */   }
/*     */   
/*     */   public static class Info {
/*     */     double speed;
/*     */     Vec3d pos;
/*     */     
/*     */     public Info(EntityPlayer player, Vec3d lastPos) {
/* 117 */       this.speed = SpeedUtil.calcSpeed(player);
/* 118 */       this.pos = player.getPositionVector();
/* 119 */       this.yaw = (RotationUtil.getRotationTo(this.pos, new Vec3d(player.prevPosX, player.prevPosY, player.prevPosZ))).x;
/* 120 */       this.lastPos = lastPos;
/*     */     }
/*     */     
/*     */     Vec3d lastPos;
/*     */     double yaw;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\SpeedUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
