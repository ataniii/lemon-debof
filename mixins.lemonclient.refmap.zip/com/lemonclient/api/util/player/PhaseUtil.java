//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import com.lemonclient.api.util.world.MotionUtil;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ 
/*     */ 
/*     */ public class PhaseUtil
/*     */ {
/*  13 */   public static List<String> bound = Arrays.asList(new String[] { "Up", "Alternate", "Down", "Zero", "Min", "Forward", "Flat", "LimitJitter", "Constrict", "None" });
/*  14 */   public static String normal = "Forward";
/*     */   
/*  16 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static CPacketPlayer doBounds(String mode, boolean send) {
/*     */     double[] dir;
/*  21 */     CPacketPlayer.PositionRotation positionRotation = new CPacketPlayer.PositionRotation(0.0D, 0.0D, 0.0D, 0.0F, 0.0F, false);
/*     */     
/*  23 */     switch (mode) {
/*     */       
/*     */       case "Up":
/*  26 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Down":
/*  29 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY - 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Zero":
/*  32 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, 0.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Min":
/*  35 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 100.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Alternate":
/*  38 */         if (mc.player.ticksExisted % 2 == 0) {
/*  39 */           positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false); break;
/*     */         } 
/*  41 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY - 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Forward":
/*  44 */         dir = MotionUtil.forward(67.0D);
/*  45 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY + 33.4D, mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Flat":
/*  48 */         dir = MotionUtil.forward(100.0D);
/*  49 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY, mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Constrict":
/*  52 */         dir = MotionUtil.forward(67.0D);
/*  53 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY + ((mc.player.posY > 64.0D) ? -33.4D : 33.4D), mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */     } 
/*  56 */     mc.player.connection.sendPacket((Packet)positionRotation);
/*  57 */     return (CPacketPlayer)positionRotation;
/*     */   }
/*     */ 
/*     */   
/*     */   public static CPacketPlayer doBounds(String mode, int c) {
/*     */     double[] dir;
/*  63 */     CPacketPlayer.PositionRotation positionRotation = new CPacketPlayer.PositionRotation(0.0D, 0.0D, 0.0D, 0.0F, 0.0F, false);
/*     */     
/*  65 */     switch (mode) {
/*     */       
/*     */       case "Up":
/*  68 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Down":
/*  71 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY - 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Zero":
/*  74 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, 0.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Min":
/*  77 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 100.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Alternate":
/*  80 */         if (mc.player.ticksExisted % 2 == 0) {
/*  81 */           positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY + 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false); break;
/*     */         } 
/*  83 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX, mc.player.posY - 69420.0D, mc.player.posZ, mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Forward":
/*  86 */         dir = MotionUtil.forward(67.0D);
/*  87 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY + 33.4D, mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Flat":
/*  90 */         dir = MotionUtil.forward(100.0D);
/*  91 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY, mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */       case "Constrict":
/*  94 */         dir = MotionUtil.forward(67.0D);
/*  95 */         positionRotation = new CPacketPlayer.PositionRotation(mc.player.posX + dir[0], mc.player.posY + ((mc.player.posY > 64.0D) ? -33.4D : 33.4D), mc.player.posZ + dir[1], mc.player.rotationYaw, mc.player.rotationPitch, false);
/*     */         break;
/*     */     } 
/*  98 */     for (int i = 1; i < c; i++) {
/*  99 */       mc.player.connection.sendPacket((Packet)positionRotation);
/*     */     }
/* 101 */     return (CPacketPlayer)positionRotation;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PhaseUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
