/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import com.lemonclient.client.module.Module;
/*    */ import net.minecraft.util.math.Vec2f;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ 
/*    */ public class PlayerPacket
/*    */ {
/*    */   private final int priority;
/*    */   private final Vec3d position;
/*    */   private final Vec2f rotation;
/*    */   
/*    */   public PlayerPacket(Module module, Vec2f rotation) {
/* 15 */     this(module, (Vec3d)null, rotation);
/*    */   }
/*    */   
/*    */   public PlayerPacket(Module module, Vec3d position) {
/* 19 */     this(module, position, (Vec2f)null);
/*    */   }
/*    */   
/*    */   public PlayerPacket(Module module, Vec3d position, Vec2f rotation) {
/* 23 */     this(module.getPriority(), position, rotation);
/*    */   }
/*    */   
/*    */   private PlayerPacket(int priority, Vec3d position, Vec2f rotation) {
/* 27 */     this.priority = priority;
/* 28 */     this.position = position;
/* 29 */     this.rotation = rotation;
/*    */   }
/*    */   
/*    */   public int getPriority() {
/* 33 */     return this.priority;
/*    */   }
/*    */   
/*    */   public Vec3d getPosition() {
/* 37 */     return this.position;
/*    */   }
/*    */   
/*    */   public Vec2f getRotation() {
/* 41 */     return this.rotation;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PlayerPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */