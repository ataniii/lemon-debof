//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumActionResult;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class PlacementUtil {
/*  24 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*  26 */   private static int placementConnections = 0;
/*     */   private static boolean isSneaking = false;
/*     */   
/*     */   public static void onEnable() {
/*  30 */     placementConnections++;
/*     */   }
/*     */   
/*     */   public static void onDisable() {
/*  34 */     placementConnections--;
/*  35 */     if (placementConnections == 0 && 
/*  36 */       isSneaking) {
/*  37 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*  38 */       isSneaking = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void stopSneaking() {
/*  43 */     if (isSneaking) {
/*  44 */       isSneaking = false;
/*  45 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean placeBlock(BlockPos blockPos, EnumHand hand, boolean rotate, Class<? extends Block> blockToPlace) {
/*  50 */     int oldSlot = mc.player.inventory.currentItem;
/*  51 */     int newSlot = InventoryUtil.findFirstBlockSlot(blockToPlace, 0, 8);
/*     */     
/*  53 */     if (newSlot == -1) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     mc.player.inventory.currentItem = newSlot;
/*  58 */     boolean output = place(blockPos, hand, rotate);
/*  59 */     mc.player.inventory.currentItem = oldSlot;
/*     */     
/*  61 */     return output;
/*     */   }
/*     */   public static boolean placeItem(BlockPos blockPos, EnumHand hand, boolean rotate, Class<? extends Item> itemToPlace) {
/*  64 */     int oldSlot = mc.player.inventory.currentItem;
/*  65 */     int newSlot = InventoryUtil.findFirstItemSlot(itemToPlace, 0, 8);
/*     */     
/*  67 */     if (newSlot == -1) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     mc.player.inventory.currentItem = newSlot;
/*  72 */     boolean output = place(blockPos, hand, rotate);
/*  73 */     mc.player.inventory.currentItem = oldSlot;
/*     */     
/*  75 */     return output;
/*     */   }
/*     */   
/*     */   public static boolean place(BlockPos blockPos, EnumHand hand, boolean rotate) {
/*  79 */     return placeBlock(blockPos, hand, rotate, true, null);
/*     */   }
/*     */   
/*     */   public static boolean place(BlockPos blockPos, EnumHand hand, boolean rotate, ArrayList<EnumFacing> forceSide) {
/*  83 */     return placeBlock(blockPos, hand, rotate, true, forceSide);
/*     */   }
/*     */   
/*     */   public static boolean holeFill(BlockPos blockPos, EnumHand hand, boolean rotate, boolean swing, ArrayList<EnumFacing> forceSide) {
/*  87 */     return holeFillBlock(blockPos, hand, rotate, swing, forceSide);
/*     */   }
/*     */   public static boolean holeFillawa(BlockPos blockPos, EnumHand hand, boolean rotate, boolean swing) {
/*  90 */     return holeFillBlockawa(blockPos, hand, rotate, swing);
/*     */   }
/*     */   
/*     */   public static boolean place(BlockPos blockPos, EnumHand hand, boolean rotate, boolean checkAction) {
/*  94 */     return placeBlock(blockPos, hand, rotate, checkAction, null);
/*     */   }
/*     */   
/*     */   public static boolean holeFill(BlockPos blockPos, EnumHand hand, boolean rotate, boolean swing) {
/*  98 */     return holeFillBlock(blockPos, hand, rotate, swing, null);
/*     */   }
/*     */   
/*     */   public static CPacketPlayer.Rotation placeBlockGetRotate(BlockPos blockPos, EnumHand hand, boolean checkAction, ArrayList<EnumFacing> forceSide, boolean swingArm) {
/* 102 */     EntityPlayerSP player = mc.player;
/* 103 */     WorldClient world = mc.world;
/* 104 */     PlayerControllerMP playerController = mc.playerController;
/*     */     
/* 106 */     if (player == null || world == null || playerController == null) return null;
/*     */     
/* 108 */     if (!world.getBlockState(blockPos).getMaterial().isReplaceable()) {
/* 109 */       return null;
/*     */     }
/*     */     
/* 112 */     EnumFacing side = (forceSide != null) ? BlockUtil.getPlaceableSideExlude(blockPos, forceSide) : BlockUtil.getPlaceableSide(blockPos);
/*     */     
/* 114 */     if (side == null) {
/* 115 */       return null;
/*     */     }
/*     */     
/* 118 */     BlockPos neighbour = blockPos.offset(side);
/* 119 */     EnumFacing opposite = side.getOpposite();
/*     */     
/* 121 */     if (!BlockUtil.canBeClicked(neighbour)) {
/* 122 */       return null;
/*     */     }
/*     */     
/* 125 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 126 */     Block neighbourBlock = world.getBlockState(neighbour).getBlock();
/*     */     
/* 128 */     if ((!isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
/* 129 */       player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)player, CPacketEntityAction.Action.START_SNEAKING));
/* 130 */       isSneaking = true;
/*     */     } 
/*     */     
/* 133 */     EnumActionResult action = playerController.processRightClickBlock(player, world, neighbour, opposite, hitVec, hand);
/* 134 */     if (!checkAction || action == EnumActionResult.SUCCESS) {
/* 135 */       if (swingArm) {
/* 136 */         player.swingArm(hand);
/* 137 */         mc.rightClickDelayTimer = 4;
/*     */       } else {
/*     */         
/* 140 */         player.connection.sendPacket((Packet)new CPacketAnimation(hand));
/*     */       } 
/*     */     }
/*     */     
/* 144 */     return BlockUtil.getFaceVectorPacket(hitVec, Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */   public static boolean placeBlock(BlockPos blockPos, EnumHand hand, boolean rotate, boolean checkAction, ArrayList<EnumFacing> forceSide) {
/* 148 */     EntityPlayerSP player = mc.player;
/* 149 */     WorldClient world = mc.world;
/* 150 */     PlayerControllerMP playerController = mc.playerController;
/*     */     
/* 152 */     if (player == null || world == null || playerController == null) return false;
/*     */     
/* 154 */     if (!world.getBlockState(blockPos).getMaterial().isReplaceable()) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     EnumFacing side = (forceSide != null) ? BlockUtil.getPlaceableSideExlude(blockPos, forceSide) : BlockUtil.getPlaceableSide(blockPos);
/*     */     
/* 160 */     if (side == null) {
/* 161 */       return false;
/*     */     }
/*     */     
/* 164 */     BlockPos neighbour = blockPos.offset(side);
/* 165 */     EnumFacing opposite = side.getOpposite();
/*     */     
/* 167 */     if (!BlockUtil.canBeClicked(neighbour)) {
/* 168 */       return false;
/*     */     }
/*     */     
/* 171 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 172 */     Block neighbourBlock = world.getBlockState(neighbour).getBlock();
/*     */     
/* 174 */     if ((!isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
/* 175 */       player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)player, CPacketEntityAction.Action.START_SNEAKING));
/* 176 */       isSneaking = true;
/*     */     } 
/*     */     
/* 179 */     if (rotate) {
/* 180 */       BlockUtil.faceVectorPacketInstant(hitVec, Boolean.valueOf(true));
/*     */     }
/*     */     
/* 183 */     EnumActionResult action = playerController.processRightClickBlock(player, world, neighbour, opposite, hitVec, hand);
/* 184 */     if (!checkAction || action == EnumActionResult.SUCCESS) {
/* 185 */       player.swingArm(hand);
/* 186 */       mc.rightClickDelayTimer = 4;
/*     */     } 
/* 188 */     return (action == EnumActionResult.SUCCESS);
/*     */   }
/*     */   
/*     */   public static boolean holeFillBlock(BlockPos blockPos, EnumHand hand, boolean rotate, boolean swing, ArrayList<EnumFacing> forceSide) {
/* 192 */     EntityPlayerSP player = mc.player;
/* 193 */     WorldClient world = mc.world;
/* 194 */     PlayerControllerMP playerController = mc.playerController;
/*     */     
/* 196 */     if (player == null || world == null || playerController == null) return false;
/*     */     
/* 198 */     if (!world.getBlockState(blockPos).getMaterial().isReplaceable()) {
/* 199 */       return false;
/*     */     }
/*     */     
/* 202 */     EnumFacing side = (forceSide != null) ? BlockUtil.getPlaceableSideExlude(blockPos, forceSide) : BlockUtil.getPlaceableSide(blockPos);
/*     */     
/* 204 */     if (side == null) {
/* 205 */       return false;
/*     */     }
/*     */     
/* 208 */     BlockPos neighbour = blockPos.offset(side);
/* 209 */     EnumFacing opposite = side.getOpposite();
/*     */     
/* 211 */     if (!BlockUtil.canBeClicked(neighbour)) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 216 */     Block neighbourBlock = world.getBlockState(neighbour).getBlock();
/*     */     
/* 218 */     if ((!isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
/* 219 */       player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)player, CPacketEntityAction.Action.START_SNEAKING));
/* 220 */       isSneaking = true;
/*     */     } 
/* 222 */     if (rotate) {
/* 223 */       BlockUtil.faceVectorPacketInstant(hitVec, Boolean.valueOf(true));
/*     */     }
/*     */     
/* 226 */     EnumActionResult action = playerController.processRightClickBlock(player, world, neighbour, opposite, hitVec, hand);
/* 227 */     if (swing) {
/* 228 */       player.swingArm(hand);
/*     */     }
/* 230 */     return (action == EnumActionResult.SUCCESS); } public static boolean holeFillBlockawa(BlockPos blockPos, EnumHand hand, boolean rotate, boolean swing) {
/*     */     BlockPos neighbour;
/*     */     EnumFacing opposite;
/* 233 */     EntityPlayerSP player = mc.player;
/* 234 */     WorldClient world = mc.world;
/* 235 */     PlayerControllerMP playerController = mc.playerController;
/*     */     
/* 237 */     if (player == null || world == null || playerController == null) return false;
/*     */     
/* 239 */     if (!world.getBlockState(blockPos).getMaterial().isReplaceable()) {
/* 240 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 244 */     if (!mc.world.isAirBlock(blockPos.south())) {
/* 245 */       neighbour = blockPos.offset(EnumFacing.SOUTH);
/* 246 */       opposite = EnumFacing.SOUTH.getOpposite();
/* 247 */     } else if (!mc.world.isAirBlock(blockPos.north())) {
/* 248 */       neighbour = blockPos.offset(EnumFacing.NORTH);
/* 249 */       opposite = EnumFacing.NORTH.getOpposite();
/* 250 */     } else if (!mc.world.isAirBlock(blockPos.east())) {
/* 251 */       neighbour = blockPos.offset(EnumFacing.EAST);
/* 252 */       opposite = EnumFacing.EAST.getOpposite();
/* 253 */     } else if (!mc.world.isAirBlock(blockPos.west())) {
/* 254 */       neighbour = blockPos.offset(EnumFacing.WEST);
/* 255 */       opposite = EnumFacing.WEST.getOpposite();
/*     */     } else {
/* 257 */       return false;
/*     */     } 
/* 259 */     if (!BlockUtil.canBeClicked(neighbour)) {
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(new Vec3d(0.5D, 0.8D, 0.5D)).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 264 */     Block neighbourBlock = world.getBlockState(neighbour).getBlock();
/*     */     
/* 266 */     if ((!isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
/* 267 */       player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)player, CPacketEntityAction.Action.START_SNEAKING));
/* 268 */       isSneaking = true;
/*     */     } 
/* 270 */     if (rotate) {
/* 271 */       BlockUtil.faceVectorPacketInstant(hitVec, Boolean.valueOf(true));
/*     */     }
/*     */     
/* 274 */     EnumActionResult action = playerController.processRightClickBlock(player, world, neighbour, opposite, hitVec, hand);
/* 275 */     if (swing) {
/* 276 */       player.swingArm(hand);
/*     */     }
/* 278 */     return (action == EnumActionResult.SUCCESS);
/*     */   }
/*     */   public static boolean placePrecise(BlockPos blockPos, EnumHand hand, boolean rotate, Vec3d precise, EnumFacing forceSide, boolean onlyRotation, boolean support) {
/* 281 */     EntityPlayerSP player = mc.player;
/* 282 */     WorldClient world = mc.world;
/* 283 */     PlayerControllerMP playerController = mc.playerController;
/*     */     
/* 285 */     if (player == null || world == null || playerController == null) return false;
/*     */     
/* 287 */     if (!world.getBlockState(blockPos).getMaterial().isReplaceable()) {
/* 288 */       return false;
/*     */     }
/*     */     
/* 291 */     EnumFacing side = (forceSide == null) ? BlockUtil.getPlaceableSide(blockPos) : forceSide;
/*     */     
/* 293 */     if (side == null) {
/* 294 */       return false;
/*     */     }
/*     */     
/* 297 */     BlockPos neighbour = blockPos.offset(side);
/* 298 */     EnumFacing opposite = side.getOpposite();
/*     */     
/* 300 */     if (!BlockUtil.canBeClicked(neighbour)) {
/* 301 */       return false;
/*     */     }
/*     */     
/* 304 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 305 */     Block neighbourBlock = world.getBlockState(neighbour).getBlock();
/*     */     
/* 307 */     if ((!isSneaking && BlockUtil.blackList.contains(neighbourBlock)) || BlockUtil.shulkerList.contains(neighbourBlock)) {
/* 308 */       player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)player, CPacketEntityAction.Action.START_SNEAKING));
/* 309 */       isSneaking = true;
/*     */     } 
/* 311 */     if (rotate && !support) {
/* 312 */       BlockUtil.faceVectorPacketInstant((precise == null) ? hitVec : precise, Boolean.valueOf(true));
/*     */     }
/*     */     
/* 315 */     if (!onlyRotation) {
/* 316 */       EnumActionResult action = playerController.processRightClickBlock(player, world, neighbour, opposite, (precise == null) ? hitVec : precise, hand);
/* 317 */       if (action == EnumActionResult.SUCCESS) {
/* 318 */         player.swingArm(hand);
/* 319 */         mc.rightClickDelayTimer = 4;
/*     */       } 
/*     */       
/* 322 */       return (action == EnumActionResult.SUCCESS);
/* 323 */     }  return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PlacementUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
