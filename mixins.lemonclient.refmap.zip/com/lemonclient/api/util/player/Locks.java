/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ public class Locks
/*    */ {
/*  8 */   public static final Lock PLACE_SWITCH_LOCK = new ReentrantLock();
/*    */   
/* 10 */   public static final Lock WINDOW_CLICK_LOCK = new ReentrantLock();
/*    */ 
/*    */ 
/*    */   
/*    */   public static void acquire(Lock lock, Runnable runnable) {
/*    */     try {
/* 16 */       lock.lock();
/* 17 */       runnable.run();
/*    */     }
/*    */     finally {
/*    */       
/* 21 */       lock.unlock();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Runnable wrap(Lock lock, Runnable runnable) {
/* 27 */     return () -> acquire(lock, runnable);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\Locks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */