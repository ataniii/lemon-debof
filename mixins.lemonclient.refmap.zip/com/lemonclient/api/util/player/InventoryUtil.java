//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketClickWindow;
/*     */ import net.minecraft.potion.PotionUtils;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class InventoryUtil {
/*  26 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static void switchTo(int slot) {
/*  30 */     if (mc.player.inventory.currentItem != slot && slot > -1 && slot < 9) {
/*     */       
/*  32 */       mc.player.inventory.currentItem = slot;
/*  33 */       mc.playerController.syncCurrentPlayItem();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void switchToBypass(int slot) {
/*  39 */     Locks.acquire(Locks.WINDOW_CLICK_LOCK, () -> {
/*     */           if (mc.player.inventory.currentItem != slot && slot > -1 && slot < 9) {
/*     */             int lastSlot = mc.player.inventory.currentItem;
/*     */             int targetSlot = hotbarToInventory(slot);
/*     */             int currentSlot = hotbarToInventory(lastSlot);
/*     */             mc.playerController.windowClick(0, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */             mc.playerController.windowClick(0, currentSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */             mc.playerController.windowClick(0, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void switchToBypassAlt(int slot) {
/*  62 */     Locks.acquire(Locks.WINDOW_CLICK_LOCK, () -> {
/*     */           if (mc.player.inventory.currentItem != slot && slot > -1 && slot < 9) {
/*     */             Locks.acquire(Locks.WINDOW_CLICK_LOCK, ());
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void bypassSwitch(int slot) {
/*  77 */     if (slot >= 0)
/*     */     {
/*  79 */       mc.playerController.pickItem(slot);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static int hotbarToInventory(int slot) {
/*  85 */     if (slot == -2)
/*     */     {
/*  87 */       return 45;
/*     */     }
/*     */     
/*  90 */     if (slot > -1 && slot < 9)
/*     */     {
/*  92 */       return 36 + slot;
/*     */     }
/*     */     
/*  95 */     return slot;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void swap(int InvSlot, int newSlot) {
/* 100 */     mc.playerController.windowClick(0, InvSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 101 */     mc.playerController.windowClick(0, newSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/* 102 */     mc.playerController.windowClick(0, InvSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.player);
/*     */     
/* 104 */     mc.playerController.updateController();
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getHotBarPressure(String mode) {
/* 109 */     for (int i = 0; i < 9; i++) {
/* 110 */       if (mode.equals("Pressure")) {
/* 111 */         if (isPressure(mc.player.inventory.getStackInSlot(i)))
/* 112 */           return i; 
/* 113 */       } else if (isString(mc.player.inventory.getStackInSlot(i))) {
/* 114 */         return i;
/*     */       } 
/*     */     } 
/* 117 */     return -1;
/*     */   }
/*     */   
/*     */   public static boolean isString(ItemStack stack) {
/* 121 */     if (stack == ItemStack.EMPTY || stack.getItem() instanceof ItemBlock) {
/* 122 */       return false;
/*     */     }
/* 124 */     return (stack.getItem() == Items.STRING);
/*     */   }
/*     */   
/*     */   public static boolean isPressure(ItemStack stack) {
/* 128 */     if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock)) {
/* 129 */       return false;
/*     */     }
/* 131 */     return ((ItemBlock)stack.getItem()).getBlock() instanceof net.minecraft.block.BlockPressurePlate;
/*     */   }
/*     */   
/*     */   public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
/* 135 */     HashMap<Integer, ItemStack> fullInventorySlots = new HashMap<>();
/* 136 */     for (int current = 9; current <= 44; current++) {
/* 137 */       fullInventorySlots.put(Integer.valueOf(current), mc.player.inventoryContainer.getInventory().get(current));
/*     */     }
/* 139 */     return fullInventorySlots;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBlock(Item item, Class clazz) {
/* 144 */     if (item instanceof ItemBlock) {
/* 145 */       Block block = ((ItemBlock)item).getBlock();
/* 146 */       return clazz.isInstance(block);
/*     */     } 
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void click(int windowIdIn, int slotIdIn, int usedButtonIn, ClickType modeIn, ItemStack clickedItemIn, short actionNumberIn) {
/* 158 */     mc.player.connection.sendPacket((Packet)new CPacketClickWindow(windowIdIn, slotIdIn, usedButtonIn, modeIn, clickedItemIn, actionNumberIn));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int findCrystalBlockSlot() {
/* 169 */     int slot = -1;
/* 170 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */ 
/*     */     
/* 173 */     for (int i = 0; i < 9; i++) {
/* 174 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 176 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
/*     */ 
/*     */ 
/*     */         
/* 180 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 181 */         if ((block.getBlockState().getBlock()).blockHardness > 6.0F) {
/* 182 */           slot = i; break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 186 */     return slot;
/*     */   }
/*     */   
/* 189 */   public static final ItemStack ILLEGAL_STACK = new ItemStack(Item.getItemFromBlock(Blocks.BEDROCK));
/*     */   public static void illegalSync() {
/* 191 */     if (mc.player != null)
/* 192 */       click(0, 0, 0, ClickType.PICKUP, ILLEGAL_STACK, (short)0); 
/*     */   }
/*     */   
/*     */   public static int findObsidianSlot(boolean offHandActived, boolean activeBefore) {
/* 196 */     int slot = -1;
/* 197 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 199 */     for (int i = 0; i < 9; i++) {
/* 200 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 202 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
/*     */ 
/*     */ 
/*     */         
/* 206 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 207 */         if (block instanceof net.minecraft.block.BlockObsidian) {
/* 208 */           slot = i; break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 212 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findEChestSlot(boolean offHandActived, boolean activeBefore) {
/* 216 */     int slot = -1;
/* 217 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */ 
/*     */     
/* 220 */     for (int i = 0; i < 9; i++) {
/* 221 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 223 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
/*     */ 
/*     */ 
/*     */         
/* 227 */         Block block = ((ItemBlock)stack.getItem()).getBlock();
/* 228 */         if (block instanceof net.minecraft.block.BlockEnderChest) {
/* 229 */           slot = i; break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 233 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findSkullSlot() {
/* 237 */     int slot = -1;
/* 238 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 240 */     for (int i = 0; i < 9; i++) {
/* 241 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 243 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof net.minecraft.item.ItemSkull)
/* 244 */         return i; 
/*     */     } 
/* 246 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findTotemSlot(int lower, int upper) {
/* 250 */     int slot = -1;
/* 251 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/* 252 */     for (int i = lower; i <= upper; ) {
/* 253 */       ItemStack stack = nonNullList.get(i);
/* 254 */       if (stack == ItemStack.EMPTY || stack.getItem() != Items.TOTEM_OF_UNDYING) {
/*     */         i++; continue;
/*     */       } 
/* 257 */       slot = i;
/*     */     } 
/*     */     
/* 260 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findFirstItemSlot(Class<? extends Item> itemToFind, int lower, int upper) {
/* 264 */     int slot = -1;
/* 265 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 267 */     for (int i = lower; i <= upper; i++) {
/* 268 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 270 */       if (stack != ItemStack.EMPTY && itemToFind.isInstance(stack.getItem()))
/*     */       {
/*     */ 
/*     */         
/* 274 */         if (itemToFind.isInstance(stack.getItem())) {
/* 275 */           slot = i;
/*     */           break;
/*     */         }  } 
/*     */     } 
/* 279 */     return slot;
/*     */   }
/*     */   public static int findStackInventory(Item input, boolean withHotbar) {
/* 282 */     int i = withHotbar ? 0 : 9;
/* 283 */     while (i < 36) {
/* 284 */       Item item = mc.player.inventory.getStackInSlot(i).getItem();
/* 285 */       if (Item.getIdFromItem(input) == Item.getIdFromItem(item)) {
/* 286 */         return i + ((i < 9) ? 36 : 0);
/*     */       }
/* 288 */       i++;
/*     */     } 
/* 290 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getItemSlot(Item input) {
/* 294 */     if (mc.player == null) {
/* 295 */       return 0;
/*     */     }
/* 297 */     for (int i = 0; i < mc.player.inventoryContainer.getInventory().size(); i++) {
/* 298 */       if (i != 0 && i != 5 && i != 6 && i != 7 && 
/* 299 */         i != 8) {
/* 300 */         ItemStack s = (ItemStack)mc.player.inventoryContainer.getInventory().get(i);
/* 301 */         if (!s.isEmpty() && 
/* 302 */           s.getItem() == input) {
/* 303 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 309 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getItemInHotbar(Item p_Item) {
/* 313 */     for (int l_I = 0; l_I < 9; l_I++) {
/* 314 */       ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);
/* 315 */       if (l_Stack != ItemStack.EMPTY && l_Stack.getItem() == p_Item) {
/* 316 */         return l_I;
/*     */       }
/*     */     } 
/* 319 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getPotion(String potion) {
/* 323 */     for (int l_I = 0; l_I < 36; l_I++) {
/* 324 */       ItemStack l_Stack = mc.player.inventory.getStackInSlot(l_I);
/* 325 */       if (l_Stack != ItemStack.EMPTY && l_Stack.getItem() == Items.SPLASH_POTION && (
/* 326 */         (ResourceLocation)Objects.<ResourceLocation>requireNonNull(PotionUtils.getPotionFromItem(mc.player.inventory.getStackInSlot(l_I)).getRegistryName())).getPath().contains(potion))
/* 327 */         return l_I; 
/*     */     } 
/* 329 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findFirstBlockSlot(Class<? extends Block> blockToFind, int lower, int upper) {
/* 333 */     int slot = -1;
/* 334 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 336 */     for (int i = lower; i <= upper; i++) {
/* 337 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 339 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock)
/*     */       {
/*     */ 
/*     */         
/* 343 */         if (blockToFind.isInstance(((ItemBlock)stack.getItem()).getBlock())) {
/* 344 */           slot = i;
/*     */           break;
/*     */         }  } 
/*     */     } 
/* 348 */     return slot;
/*     */   }
/*     */   
/*     */   public static List<Integer> findAllItemSlots(Class<? extends Item> itemToFind) {
/* 352 */     List<Integer> slots = new ArrayList<>();
/* 353 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 355 */     for (int i = 0; i < 36; i++) {
/* 356 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 358 */       if (stack != ItemStack.EMPTY && itemToFind.isInstance(stack.getItem()))
/*     */       {
/*     */ 
/*     */         
/* 362 */         slots.add(Integer.valueOf(i)); } 
/*     */     } 
/* 364 */     return slots;
/*     */   }
/*     */   
/*     */   public static List<Integer> findAllBlockSlots(Class<? extends Block> blockToFind) {
/* 368 */     List<Integer> slots = new ArrayList<>();
/* 369 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 371 */     for (int i = 0; i < 36; i++) {
/* 372 */       ItemStack stack = nonNullList.get(i);
/*     */       
/* 374 */       if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock)
/*     */       {
/*     */ 
/*     */         
/* 378 */         if (blockToFind.isInstance(((ItemBlock)stack.getItem()).getBlock()))
/* 379 */           slots.add(Integer.valueOf(i)); 
/*     */       }
/*     */     } 
/* 382 */     return slots;
/*     */   }
/*     */   
/*     */   public static int findToolForBlockState(IBlockState iBlockState, int lower, int upper) {
/* 386 */     int slot = -1;
/* 387 */     NonNullList<ItemStack> nonNullList = mc.player.inventory.mainInventory;
/*     */     
/* 389 */     double foundMaxSpeed = 0.0D;
/* 390 */     for (int i = lower; i <= upper; i++) {
/* 391 */       ItemStack itemStack = nonNullList.get(i);
/*     */       
/* 393 */       if (itemStack != ItemStack.EMPTY) {
/*     */         
/* 395 */         float breakSpeed = itemStack.getDestroySpeed(iBlockState);
/*     */         
/* 397 */         int efficiencySpeed = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, itemStack);
/*     */         
/* 399 */         if (breakSpeed > 1.0F) {
/* 400 */           breakSpeed = (float)(breakSpeed + ((efficiencySpeed > 0) ? (Math.pow(efficiencySpeed, 2.0D) + 1.0D) : 0.0D));
/*     */           
/* 402 */           if (breakSpeed > foundMaxSpeed) {
/* 403 */             foundMaxSpeed = breakSpeed;
/* 404 */             slot = i;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 409 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getEmptyCounts() {
/* 413 */     if (mc.player == null) {
/* 414 */       return 0;
/*     */     }
/* 416 */     int count = 0;
/* 417 */     for (int i = 0; i <= 35; i++) {
/* 418 */       ItemStack stack = (ItemStack)mc.player.inventory.mainInventory.get(i);
/* 419 */       if (stack == ItemStack.EMPTY || stack.getItem() == Items.AIR)
/* 420 */         count++; 
/*     */     } 
/* 422 */     return count;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\InventoryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
