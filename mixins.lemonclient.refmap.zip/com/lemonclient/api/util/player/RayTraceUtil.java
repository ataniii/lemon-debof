//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RayTraceUtil
/*     */ {
/*  20 */   public static Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static float[] hitVecToPlaceVec(BlockPos pos, Vec3d hitVec) {
/*  23 */     float x = (float)(hitVec.x - pos.getX());
/*  24 */     float y = (float)(hitVec.y - pos.getY());
/*  25 */     float z = (float)(hitVec.z - pos.getZ());
/*     */     
/*  27 */     return new float[] { x, y, z };
/*     */   }
/*     */ 
/*     */   
/*     */   public static RayTraceResult getRayTraceResult(float yaw, float pitch) {
/*  32 */     return getRayTraceResult(yaw, pitch, mc.playerController.getBlockReachDistance());
/*     */   }
/*     */ 
/*     */   
/*     */   public static RayTraceResult getRayTraceResultWithEntity(float yaw, float pitch, Entity from) {
/*  37 */     return getRayTraceResult(yaw, pitch, mc.playerController.getBlockReachDistance(), from);
/*     */   }
/*     */ 
/*     */   
/*     */   public static RayTraceResult getRayTraceResult(float yaw, float pitch, float distance) {
/*  42 */     return getRayTraceResult(yaw, pitch, distance, (Entity)mc.player);
/*     */   }
/*     */ 
/*     */   
/*     */   public static RayTraceResult getRayTraceResult(float yaw, float pitch, float d, Entity from) {
/*  47 */     Vec3d vec3d = getEyePos(from);
/*  48 */     Vec3d lookVec = getVec3d(yaw, pitch);
/*  49 */     Vec3d rotations = vec3d.add(lookVec.x * d, lookVec.y * d, lookVec.z * d);
/*  50 */     return Optional.<RayTraceResult>ofNullable(mc.world
/*  51 */         .rayTraceBlocks(vec3d, rotations, false, false, false))
/*  52 */       .orElseGet(() -> new RayTraceResult(RayTraceResult.Type.MISS, new Vec3d(0.5D, 1.0D, 0.5D), EnumFacing.UP, BlockPos.ORIGIN));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vec3d getVec3d(float yaw, float pitch) {
/*  58 */     float vx = -MathHelper.sin(MathUtil.rad(yaw)) * MathHelper.cos(MathUtil.rad(pitch));
/*  59 */     float vz = MathHelper.cos(MathUtil.rad(yaw)) * MathHelper.cos(MathUtil.rad(pitch));
/*  60 */     float vy = -MathHelper.sin(MathUtil.rad(pitch));
/*  61 */     return new Vec3d(vx, vy, vz);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d getEyePos(Entity entity) {
/*  66 */     return new Vec3d(entity.posX, getEyeHeight(entity), entity.posZ);
/*     */   }
/*     */   
/*     */   public static double getEyeHeight(Entity entity) {
/*  70 */     return entity.posY + entity.getEyeHeight();
/*     */   }
/*     */   
/*     */   public static boolean canBeSeen(double x, double y, double z, Entity by) {
/*  74 */     return canBeSeen(new Vec3d(x, y, z), by.posX, by.posY, by.posZ, by.getEyeHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canBeSeen(Vec3d toSee, Entity by) {
/*  79 */     return canBeSeen(toSee, by.posX, by.posY, by.posZ, by.getEyeHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canBeSeen(Vec3d toSee, double x, double y, double z, float eyeHeight) {
/*  84 */     Vec3d start = new Vec3d(x, y + eyeHeight, z);
/*  85 */     return (mc.world.rayTraceBlocks(start, toSee, false, true, false) == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canBeSeen(Entity toSee, EntityLivingBase by) {
/*  90 */     return by.canEntityBeSeen(toSee);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean raytracePlaceCheck(Entity entity, BlockPos pos) {
/*  95 */     return (getFacing(entity, pos, false) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumFacing getFacing(Entity entity, BlockPos pos, boolean verticals) {
/* 102 */     for (EnumFacing facing : EnumFacing.values()) {
/*     */       
/* 104 */       RayTraceResult result = mc.world.rayTraceBlocks(
/* 105 */           getEyePos(entity), new Vec3d(pos
/*     */             
/* 107 */             .getX() + 0.5D + facing.getDirectionVec().getX() * 1.0D / 2.0D, pos
/* 108 */             .getY() + 0.5D + facing.getDirectionVec().getY() * 1.0D / 2.0D, pos
/* 109 */             .getZ() + 0.5D + facing.getDirectionVec().getZ() * 1.0D / 2.0D), false, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       if (result != null && result.typeOfHit == RayTraceResult.Type.BLOCK && result
/*     */         
/* 116 */         .getBlockPos().equals(pos))
/*     */       {
/* 118 */         return facing;
/*     */       }
/*     */     } 
/*     */     
/* 122 */     if (verticals) {
/*     */       
/* 124 */       if (pos.getY() > mc.player.posY + mc.player.getEyeHeight())
/*     */       {
/* 126 */         return EnumFacing.DOWN;
/*     */       }
/*     */       
/* 129 */       return EnumFacing.UP;
/*     */     } 
/*     */     
/* 132 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\RayTraceUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
