//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutableBlockPosHelper
/*    */ {
/* 10 */   public BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
/*    */ 
/*    */   
/*    */   public static BlockPos.MutableBlockPos set(BlockPos.MutableBlockPos mutablePos, double x, double y, double z) {
/* 14 */     return mutablePos.setPos(x, y, z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos set(BlockPos.MutableBlockPos mutablePos, BlockPos pos) {
/* 18 */     return mutablePos.setPos(pos.getX(), pos.getY(), pos.getZ());
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos set(BlockPos.MutableBlockPos mutablePos, BlockPos pos, double x, double y, double z) {
/* 22 */     return mutablePos.setPos(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos set(BlockPos.MutableBlockPos mutablePos, BlockPos pos, int x, int y, int z) {
/* 26 */     return mutablePos.setPos(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos set(BlockPos.MutableBlockPos mutablePos, int x, int y, int z) {
/* 30 */     return mutablePos.setPos(x, y, z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos setAndAdd(BlockPos.MutableBlockPos mutablePos, int x, int y, int z) {
/* 34 */     return mutablePos.setPos(mutablePos.getX() + x, mutablePos.getY() + y, mutablePos.getZ() + z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos setAndAdd(BlockPos.MutableBlockPos mutablePos, double x, double y, double z) {
/* 38 */     return mutablePos.setPos(mutablePos.getX() + x, mutablePos.getY() + y, mutablePos.getZ() + z);
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos setAndAdd(BlockPos.MutableBlockPos mutablePos, BlockPos pos) {
/* 42 */     return mutablePos.setPos(mutablePos.getX() + pos.getX(), mutablePos.getY() + pos.getY(), mutablePos.getZ() + pos.getZ());
/*    */   }
/*    */   
/*    */   public static BlockPos.MutableBlockPos setAndAdd(BlockPos.MutableBlockPos mutablePos, BlockPos pos, double x, double y, double z) {
/* 46 */     return mutablePos.setPos((mutablePos.getX() + pos.getX()) + x, (mutablePos.getY() + pos.getY()) + y, (mutablePos.getZ() + pos.getZ()) + z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos set(double x, double y, double z) {
/* 50 */     return this.mutablePos.setPos(x, y, z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos set(BlockPos pos) {
/* 54 */     return this.mutablePos.setPos(pos.getX(), pos.getY(), pos.getZ());
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos set(BlockPos pos, double x, double y, double z) {
/* 58 */     return this.mutablePos.setPos(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos set(BlockPos pos, int x, int y, int z) {
/* 62 */     return this.mutablePos.setPos(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos set(int x, int y, int z) {
/* 66 */     return this.mutablePos.setPos(x, y, z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos setAndAdd(int x, int y, int z) {
/* 70 */     return this.mutablePos.setPos(this.mutablePos.getX() + x, this.mutablePos.getY() + y, this.mutablePos.getZ() + z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos setAndAdd(double x, double y, double z) {
/* 74 */     return this.mutablePos.setPos(this.mutablePos.getX() + x, this.mutablePos.getY() + y, this.mutablePos.getZ() + z);
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos setAndAdd(BlockPos pos) {
/* 78 */     return this.mutablePos.setPos(this.mutablePos.getX() + pos.getX(), this.mutablePos.getY() + pos.getY(), this.mutablePos.getZ() + pos.getZ());
/*    */   }
/*    */   
/*    */   public BlockPos.MutableBlockPos setAndAdd(BlockPos pos, double x, double y, double z) {
/* 82 */     return this.mutablePos.setPos((this.mutablePos.getX() + pos.getX()) + x, (this.mutablePos.getY() + pos.getY()) + y, (this.mutablePos.getZ() + pos.getZ()) + z);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\MutableBlockPosHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
