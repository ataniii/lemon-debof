//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.player;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ 
/*    */ public class PositionUtil {
/*  7 */   Minecraft mc = Minecraft.getMinecraft();
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   private boolean onground;
/*    */   
/*    */   public void updatePosition() {
/* 14 */     this.x = this.mc.player.posX;
/* 15 */     this.y = this.mc.player.posY;
/* 16 */     this.z = this.mc.player.posZ;
/* 17 */     this.onground = this.mc.player.onGround;
/*    */   }
/*    */   
/*    */   public void restorePosition() {
/* 21 */     this.mc.player.posX = this.x;
/* 22 */     this.mc.player.posY = this.y;
/* 23 */     this.mc.player.posZ = this.z;
/* 24 */     this.mc.player.onGround = this.onground;
/*    */   }
/*    */   
/*    */   public void setPlayerPosition(double x, double y, double z) {
/* 28 */     this.mc.player.posX = x;
/* 29 */     this.mc.player.posY = y;
/* 30 */     this.mc.player.posZ = z;
/*    */   }
/*    */   
/*    */   public void setPlayerPosition(double x, double y, double z, boolean onground) {
/* 34 */     this.mc.player.posX = x;
/* 35 */     this.mc.player.posY = y;
/* 36 */     this.mc.player.posZ = z;
/* 37 */     this.mc.player.onGround = onground;
/*    */   }
/*    */   
/*    */   public void setPositionPacket(double x, double y, double z, boolean onGround, boolean setPos, boolean noLagBack) {
/* 41 */     this.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(x, y, z, onGround));
/* 42 */     if (setPos) {
/* 43 */       this.mc.player.setPosition(x, y, z);
/* 44 */       if (noLagBack) {
/* 45 */         updatePosition();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public double getX() {
/* 51 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(double x) {
/* 55 */     this.x = x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 59 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(double y) {
/* 63 */     this.y = y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 67 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setZ(double z) {
/* 71 */     this.z = z;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PositionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
