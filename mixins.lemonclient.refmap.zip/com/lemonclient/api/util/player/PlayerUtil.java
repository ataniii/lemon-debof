//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ 
/*     */ 
/*     */ public class PlayerUtil
/*     */ {
/*  27 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static void setPosition(double x, double y, double z) {
/*  31 */     mc.player.setPosition(x, y, z);
/*     */   }
/*     */   
/*     */   public static void setPosition(BlockPos pos) {
/*  35 */     mc.player.setPosition(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
/*     */   }
/*     */   
/*     */   public static Vec3d getMotionVector() {
/*  39 */     return new Vec3d(mc.player.motionX, mc.player.motionY, mc.player.motionZ);
/*     */   }
/*     */   
/*     */   public static void vClip(double d) {
/*  43 */     mc.player.setPosition(mc.player.posX, mc.player.posY + d, mc.player.posZ);
/*     */   }
/*     */   
/*     */   public static void move(double x, double y, double z) {
/*  47 */     mc.player.move(MoverType.SELF, x, y, z);
/*     */   }
/*     */   
/*     */   public static void setMotionVector(Vec3d vec) {
/*  51 */     mc.player.motionX = vec.x;
/*  52 */     mc.player.motionY = vec.y;
/*  53 */     mc.player.motionZ = vec.z;
/*     */   }
/*     */   public static boolean isInsideBlock() {
/*     */     try {
/*  57 */       AxisAlignedBB playerBoundingBox = mc.player.getEntityBoundingBox();
/*  58 */       for (int x = MathHelper.floor(playerBoundingBox.minX); x < MathHelper.floor(playerBoundingBox.maxX) + 1; x++) {
/*  59 */         for (int y = MathHelper.floor(playerBoundingBox.minY); y < MathHelper.floor(playerBoundingBox.maxY) + 1; y++) {
/*  60 */           for (int z = MathHelper.floor(playerBoundingBox.minZ); z < MathHelper.floor(playerBoundingBox.maxZ) + 1; z++) {
/*  61 */             Block block = mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
/*  62 */             if (!(block instanceof net.minecraft.block.BlockAir)) {
/*  63 */               AxisAlignedBB boundingBox = ((AxisAlignedBB)Objects.<AxisAlignedBB>requireNonNull(block.getCollisionBoundingBox(mc.world.getBlockState(new BlockPos(x, y, z)), (IBlockAccess)mc.world, new BlockPos(x, y, z)))).offset(x, y, z);
/*  64 */               if (block instanceof net.minecraft.block.BlockHopper) {
/*  65 */                 boundingBox = new AxisAlignedBB(x, y, z, (x + 1), (y + 1), (z + 1));
/*     */               }
/*  67 */               if (playerBoundingBox.intersects(boundingBox)) {
/*  68 */                 return true;
/*     */               }
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*  75 */     } catch (Exception e) {
/*  76 */       return false;
/*     */     } 
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static BlockPos getPlayerPos() {
/*  83 */     return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY + 0.5D), Math.floor(mc.player.posZ));
/*     */   }
/*     */   public static BlockPos getPlayerFloorPos() {
/*  86 */     return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
/*     */   }
/*     */   
/*     */   public static boolean isPlayerClipped() {
/*  90 */     return !mc.world.getCollisionBoxes((Entity)mc.player, mc.player.getEntityBoundingBox()).isEmpty();
/*     */   }
/*     */   
/*     */   public static void fakeJump() {
/*  94 */     fakeJump(5);
/*     */   }
/*     */   
/*     */   public static void fakeJump(int packets) {
/*  98 */     if (packets > 0 && packets != 5)
/*  99 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, true)); 
/* 100 */     if (packets > 1)
/* 101 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419999986887D, mc.player.posZ, true)); 
/* 102 */     if (packets > 2)
/* 103 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.7531999805212D, mc.player.posZ, true)); 
/* 104 */     if (packets > 3)
/* 105 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.0013359791121D, mc.player.posZ, true)); 
/* 106 */     if (packets > 4) {
/* 107 */       mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.1661092609382D, mc.player.posZ, true));
/*     */     }
/*     */   }
/*     */   
/*     */   public static double getDistance(Entity entity) {
/* 112 */     return mc.player.getDistance(entity);
/*     */   }
/*     */   
/*     */   public static double getDistance(BlockPos pos) {
/* 116 */     return mc.player.getDistance(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */   public static double getDistanceI(BlockPos pos) {
/* 119 */     return getEyeVec().distanceTo(new Vec3d(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D));
/*     */   }
/*     */   
/*     */   public static double getDistanceL(BlockPos pos) {
/* 123 */     double x = pos.x - mc.player.posX;
/* 124 */     double z = pos.z - mc.player.posZ;
/* 125 */     return Math.hypot(x, z);
/*     */   }
/*     */   
/*     */   public static BlockPos getEyesPos() {
/* 129 */     return new BlockPos(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */   
/*     */   public static Vec3d getEyeVec() {
/* 133 */     return new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityPlayer getNearestPlayer(double range) {
/* 140 */     List<EntityPlayer> playerList = (List<EntityPlayer>)mc.world.playerEntities.stream().filter(p -> (mc.player.getDistance((Entity)p) <= range)).filter(p -> !EntityUtil.basicChecksEntity(p)).filter(p -> (mc.player.entityId != p.entityId)).filter(p -> !EntityUtil.isDead((Entity)p)).collect(Collectors.toList());
/* 141 */     List<EntityPlayer> players = (List<EntityPlayer>)playerList.stream().filter(p -> SocialManager.isEnemy(p.getName())).collect(Collectors.toList());
/* 142 */     if (players.isEmpty()) players.addAll(playerList); 
/* 143 */     return players.stream().min(Comparator.comparing(mc.player::getDistance)).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityPlayer findLookingPlayer(double rangeMax) {
/* 149 */     ArrayList<EntityPlayer> listPlayer = new ArrayList<>();
/*     */     
/* 151 */     for (EntityPlayer playerSin : mc.world.playerEntities) {
/* 152 */       if (EntityUtil.basicChecksEntity(playerSin))
/*     */         continue; 
/* 154 */       if (mc.player.getDistance((Entity)playerSin) <= rangeMax) {
/* 155 */         listPlayer.add(playerSin);
/*     */       }
/*     */     } 
/*     */     
/* 159 */     EntityPlayer target = null;
/*     */     
/* 161 */     Vec3d positionEyes = mc.player.getPositionEyes(mc.getRenderPartialTicks());
/* 162 */     Vec3d rotationEyes = mc.player.getLook(mc.getRenderPartialTicks());
/*     */     
/* 164 */     int precision = 2;
/*     */     
/* 166 */     for (int i = 0; i < (int)rangeMax; i++) {
/*     */       
/* 168 */       for (int j = precision; j > 0; j--) {
/*     */         
/* 170 */         for (EntityPlayer targetTemp : listPlayer) {
/*     */           
/* 172 */           AxisAlignedBB playerBox = targetTemp.getEntityBoundingBox();
/*     */           
/* 174 */           double xArray = positionEyes.x + rotationEyes.x * i + rotationEyes.x / j;
/* 175 */           double yArray = positionEyes.y + rotationEyes.y * i + rotationEyes.y / j;
/* 176 */           double zArray = positionEyes.z + rotationEyes.z * i + rotationEyes.z / j;
/*     */           
/* 178 */           if (playerBox.maxY >= yArray && playerBox.minY <= yArray && playerBox.maxX >= xArray && playerBox.minX <= xArray && playerBox.maxZ >= zArray && playerBox.minZ <= zArray)
/*     */           {
/*     */ 
/*     */             
/* 182 */             target = targetTemp;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 188 */     return target;
/*     */   }
/*     */   
/*     */   public static List<EntityPlayer> getNearPlayers(double range, int count) {
/* 192 */     List<EntityPlayer> targetList = new ArrayList<>();
/* 193 */     List<EntityPlayer> list = new ArrayList<>();
/* 194 */     for (EntityPlayer player : mc.world.playerEntities) {
/* 195 */       if (mc.player.getDistance((Entity)player) > range || 
/* 196 */         EntityUtil.basicChecksEntity(player) || 
/* 197 */         EntityUtil.isDead((Entity)player))
/* 198 */         continue;  targetList.add(player);
/*     */     } 
/*     */     
/* 201 */     List<EntityPlayer> players = (List<EntityPlayer>)targetList.stream().filter(p -> SocialManager.isEnemy(p.getName())).collect(Collectors.toList());
/* 202 */     if (players.isEmpty()) players.addAll(targetList);
/*     */     
/* 204 */     players.stream().sorted(Comparator.comparing(PlayerUtil::getDistance)).forEach(list::add);
/* 205 */     return new ArrayList<>(list.subList(0, Math.min(count, list.size())));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float getHealth() {
/* 210 */     return mc.player.getHealth() + mc.player.getAbsorptionAmount();
/*     */   }
/*     */   
/*     */   public static void centerPlayer() {
/* 214 */     double newX = -2.0D;
/* 215 */     double newZ = -2.0D;
/* 216 */     int xRel = (mc.player.posX < 0.0D) ? -1 : 1;
/* 217 */     int zRel = (mc.player.posZ < 0.0D) ? -1 : 1;
/* 218 */     if (BlockUtil.getBlock(mc.player.posX, mc.player.posY - 1.0D, mc.player.posZ) instanceof net.minecraft.block.BlockAir) {
/* 219 */       if (Math.abs(mc.player.posX % 1.0D) * 100.0D <= 30.0D) {
/* 220 */         newX = Math.round(mc.player.posX - 0.3D * xRel) + 0.5D * -xRel;
/* 221 */       } else if (Math.abs(mc.player.posX % 1.0D) * 100.0D >= 70.0D) {
/* 222 */         newX = Math.round(mc.player.posX + 0.3D * xRel) - 0.5D * -xRel;
/*     */       } 
/* 224 */       if (Math.abs(mc.player.posZ % 1.0D) * 100.0D <= 30.0D) {
/* 225 */         newZ = Math.round(mc.player.posZ - 0.3D * zRel) + 0.5D * -zRel;
/* 226 */       } else if (Math.abs(mc.player.posZ % 1.0D) * 100.0D >= 70.0D) {
/* 227 */         newZ = Math.round(mc.player.posZ + 0.3D * zRel) - 0.5D * -zRel;
/*     */       } 
/*     */     } 
/*     */     
/* 231 */     if (newX == -2.0D) {
/* 232 */       if (mc.player.posX > Math.round(mc.player.posX)) {
/* 233 */         newX = Math.round(mc.player.posX) + 0.5D;
/*     */       
/*     */       }
/* 236 */       else if (mc.player.posX < Math.round(mc.player.posX)) {
/* 237 */         newX = Math.round(mc.player.posX) - 0.5D;
/*     */       } else {
/* 239 */         newX = mc.player.posX;
/*     */       } 
/*     */     }
/* 242 */     if (newZ == -2.0D) {
/* 243 */       if (mc.player.posZ > Math.round(mc.player.posZ)) {
/* 244 */         newZ = Math.round(mc.player.posZ) + 0.5D;
/* 245 */       } else if (mc.player.posZ < Math.round(mc.player.posZ)) {
/* 246 */         newZ = Math.round(mc.player.posZ) - 0.5D;
/*     */       } else {
/* 248 */         newZ = mc.player.posZ;
/*     */       } 
/*     */     }
/* 251 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(newX, mc.player.posY, newZ, true));
/* 252 */     mc.player.setPosition(newX, mc.player.posY, newZ);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PlayerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
