//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ 
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.api.util.world.EntityUtil;
/*     */ import com.lemonclient.api.util.world.HoleUtil;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class PredictUtil {
/*  20 */   static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static EntityPlayer predictPlayer(EntityLivingBase entity, PredictSettings settings) {
/*  24 */     double[] posVec = { entity.posX, entity.posY, entity.posZ };
/*     */ 
/*     */ 
/*     */     
/*  28 */     double motionX = entity.posX - entity.lastTickPosX;
/*  29 */     double motionY = entity.posY - entity.lastTickPosY;
/*  30 */     double motionZ = entity.posZ - entity.lastTickPosZ;
/*     */ 
/*     */     
/*  33 */     boolean isHole = false;
/*  34 */     if (settings.manualOutHole && motionY > 0.2D) {
/*  35 */       if (HoleUtil.isHole(EntityUtil.getPosition((Entity)entity), false, true, false).getType() != HoleUtil.HoleType.NONE && 
/*  36 */         BlockUtil.getBlock(EntityUtil.getPosition((Entity)entity).add(0, 2, 0)) instanceof net.minecraft.block.BlockAir) {
/*  37 */         isHole = true;
/*  38 */       } else if (settings.aboveHoleManual && HoleUtil.isHole(EntityUtil.getPosition((Entity)entity).add(0, -1, 0), false, true, false).getType() != HoleUtil.HoleType.NONE) {
/*  39 */         isHole = true;
/*     */       } 
/*  41 */       if (isHole) {
/*  42 */         posVec[1] = posVec[1] + 1.0D;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  47 */     boolean allowPredictStair = false;
/*  48 */     int stairPredicted = 0;
/*  49 */     if (settings.stairPredict) {
/*  50 */       allowPredictStair = (Math.hypot(motionX, motionZ) > settings.speedActivationStairs);
/*     */     }
/*     */     
/*  53 */     for (int i = 0; i < settings.tick; i++) {
/*     */       
/*  55 */       boolean predictedStair = false;
/*  56 */       if (settings.splitXZ) {
/*     */         
/*  58 */         double[] newPosVec = (double[])posVec.clone();
/*     */         
/*  60 */         newPosVec[0] = newPosVec[0] + motionX;
/*     */ 
/*     */         
/*  63 */         if (calculateRaytrace(posVec, newPosVec)) {
/*  64 */           posVec = (double[])newPosVec.clone();
/*  65 */         } else if (settings.stairPredict && allowPredictStair) {
/*  66 */           if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 1.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/*  67 */             posVec[1] = posVec[1] + 1.0D;
/*  68 */             predictedStair = true;
/*  69 */           } else if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 3.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/*  70 */             posVec[1] = posVec[1] + 2.0D;
/*  71 */             predictedStair = true;
/*     */           } 
/*     */         } 
/*     */         
/*  75 */         newPosVec = (double[])posVec.clone();
/*  76 */         newPosVec[2] = newPosVec[2] + motionZ;
/*     */ 
/*     */         
/*  79 */         if (calculateRaytrace(posVec, newPosVec)) {
/*  80 */           posVec = (double[])newPosVec.clone();
/*  81 */         } else if (settings.stairPredict && allowPredictStair) {
/*  82 */           if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 1.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/*  83 */             posVec[1] = posVec[1] + 1.0D;
/*  84 */             predictedStair = true;
/*  85 */           } else if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 3.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/*  86 */             posVec[1] = posVec[1] + 1.0D;
/*  87 */             predictedStair = true;
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/*  93 */         double[] newPosVec = (double[])posVec.clone();
/*  94 */         newPosVec[0] = newPosVec[0] + motionX;
/*  95 */         newPosVec[2] = newPosVec[2] + motionZ;
/*     */         
/*  97 */         if (calculateRaytrace(posVec, newPosVec)) {
/*  98 */           posVec = (double[])newPosVec.clone();
/*  99 */         } else if (settings.stairPredict && allowPredictStair) {
/* 100 */           if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 1.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/* 101 */             posVec[1] = posVec[1] + 1.0D;
/* 102 */             predictedStair = true;
/* 103 */           } else if (BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 2.0D, newPosVec[2])) && BlockUtil.isAirBlock(new BlockPos(newPosVec[0], newPosVec[1] + 3.0D, newPosVec[2])) && stairPredicted++ < settings.nStairs) {
/* 104 */             posVec[1] = posVec[1] + 1.0D;
/* 105 */             predictedStair = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 110 */       if (settings.calculateY && !isHole && !predictedStair) {
/* 111 */         double[] arrayOfDouble = (double[])posVec.clone();
/*     */         
/* 113 */         double decreasePow = settings.startDecrease / Math.pow(10.0D, settings.exponentStartDecrease);
/*     */         
/* 115 */         double decreasePowY = settings.decreaseY / Math.pow(10.0D, settings.exponentDecreaseY);
/*     */         
/* 117 */         if (entity.isInWater() || entity.isInLava() || entity.isElytraFlying()) {
/* 118 */           decreasePowY = 0.0D;
/* 119 */           arrayOfDouble[1] = arrayOfDouble[1] + motionY;
/*     */         } else {
/* 121 */           motionY += decreasePowY;
/*     */           
/* 123 */           if (Math.abs(motionY) > decreasePow) {
/* 124 */             motionY = decreasePowY;
/*     */           }
/*     */           
/* 127 */           arrayOfDouble[1] = arrayOfDouble[1] + -1.0D * motionY;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 145 */         if (calculateRaytrace(posVec, arrayOfDouble)) {
/* 146 */           posVec = (double[])arrayOfDouble.clone();
/*     */         } else {
/* 148 */           motionY -= decreasePowY;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     EntityOtherPlayerMP clonedPlayer = new EntityOtherPlayerMP((World)mc.world, new GameProfile(UUID.fromString("fdee323e-7f0c-4c15-8d1c-0f277442342a"), entity.getName()));
/* 170 */     clonedPlayer.setPosition(posVec[0], posVec[1], posVec[2]);
/* 171 */     if (entity instanceof EntityPlayer) clonedPlayer.inventory.copyInventory(((EntityPlayer)entity).inventory); 
/* 172 */     clonedPlayer.setHealth(entity.getHealth());
/* 173 */     clonedPlayer.prevPosX = entity.prevPosX;
/* 174 */     clonedPlayer.prevPosY = entity.prevPosY;
/* 175 */     clonedPlayer.prevPosZ = entity.prevPosZ;
/* 176 */     for (PotionEffect effect : entity.getActivePotionEffects()) {
/* 177 */       clonedPlayer.addPotionEffect(effect);
/*     */     }
/* 179 */     return (EntityPlayer)clonedPlayer;
/*     */   }
/*     */   
/*     */   public static boolean calculateRaytrace(double[] posVec, double[] newPosVec) {
/* 183 */     RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(posVec[0], posVec[1], posVec[2]), new Vec3d(newPosVec[0], newPosVec[1], newPosVec[2]));
/* 184 */     RayTraceResult result1 = mc.world.rayTraceBlocks(new Vec3d(posVec[0] + 0.3D, posVec[1], posVec[2] + 0.3D), new Vec3d(newPosVec[0] - 0.3D, newPosVec[1], newPosVec[2] - 0.3D));
/* 185 */     RayTraceResult result2 = mc.world.rayTraceBlocks(new Vec3d(posVec[0] + 0.3D, posVec[1], posVec[2] - 0.3D), new Vec3d(newPosVec[0] - 0.3D, newPosVec[1], newPosVec[2] + 0.3D));
/* 186 */     RayTraceResult result3 = mc.world.rayTraceBlocks(new Vec3d(posVec[0] - 0.3D, posVec[1], posVec[2] + 0.3D), new Vec3d(newPosVec[0] + 0.3D, newPosVec[1], newPosVec[2] - 0.3D));
/* 187 */     RayTraceResult result4 = mc.world.rayTraceBlocks(new Vec3d(posVec[0] - 0.3D, posVec[1], posVec[2] - 0.3D), new Vec3d(newPosVec[0] + 0.3D, newPosVec[1], newPosVec[2] + 0.3D));
/*     */     
/* 189 */     if (result == null || result.typeOfHit == RayTraceResult.Type.ENTITY) {
/* 190 */       return ((result1 == null || result1.typeOfHit == RayTraceResult.Type.ENTITY) && (result2 == null || result2.typeOfHit == RayTraceResult.Type.ENTITY) && (result3 == null || result3.typeOfHit == RayTraceResult.Type.ENTITY) && (result4 == null || result4.typeOfHit == RayTraceResult.Type.ENTITY));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 195 */     return false;
/*     */   }
/*     */   
/*     */   public static class PredictSettings
/*     */   {
/*     */     final int tick;
/*     */     final boolean calculateY;
/*     */     final int startDecrease;
/*     */     final int exponentStartDecrease;
/*     */     final int decreaseY;
/*     */     final int exponentDecreaseY;
/*     */     final boolean splitXZ;
/*     */     final boolean manualOutHole;
/*     */     final boolean aboveHoleManual;
/*     */     final boolean stairPredict;
/*     */     final int nStairs;
/*     */     final double speedActivationStairs;
/*     */     
/*     */     public PredictSettings(int tick, boolean calculateY, int startDecrease, int exponentStartDecrease, int decreaseY, int exponentDecreaseY, boolean splitXZ, boolean manualOutHole, boolean aboveHoleManual, boolean stairPredict, int nStairs, double speedActivationStairs) {
/* 214 */       this.tick = tick;
/* 215 */       this.calculateY = calculateY;
/* 216 */       this.startDecrease = startDecrease;
/* 217 */       this.exponentStartDecrease = exponentStartDecrease;
/* 218 */       this.decreaseY = decreaseY;
/* 219 */       this.exponentDecreaseY = exponentDecreaseY;
/* 220 */       this.splitXZ = splitXZ;
/* 221 */       this.manualOutHole = manualOutHole;
/* 222 */       this.aboveHoleManual = aboveHoleManual;
/* 223 */       this.stairPredict = stairPredict;
/* 224 */       this.nStairs = nStairs;
/* 225 */       this.speedActivationStairs = speedActivationStairs;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\PredictUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
