//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class MathUtil {
/*  13 */   public static Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static double length(Vec3d vec3d) {
/*  17 */     return Math.sqrt(lengthSQ(vec3d));
/*     */   }
/*     */   
/*     */   public static double multiply(double n) {
/*  21 */     return n * n;
/*     */   }
/*     */   
/*     */   public static float cos(float n) {
/*  25 */     return MathHelper.cos(n);
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAlignedRetarded(Vec3d vec3d, Vec3d vec3d2) {
/*  29 */     return (new BlockPos(vec3d)).equals(new BlockPos(vec3d2.x, vec3d.y, vec3d2.z));
/*     */   }
/*     */   
/*     */   public static double square(double n) {
/*  33 */     return n * n;
/*     */   }
/*     */   
/*     */   public static float rad(float angle) {
/*  37 */     return (float)(angle * Math.PI / 180.0D);
/*     */   }
/*     */   
/*     */   public static double getRandom(double n, double n2) {
/*  41 */     return MathHelper.clamp(n + random.nextDouble() * n2, n, n2);
/*     */   }
/*     */   
/*     */   public static double[] differentDirectionSpeed(double n) {
/*  45 */     Minecraft getMinecraft = Minecraft.getMinecraft();
/*  46 */     float moveForward = getMinecraft.player.movementInput.moveForward;
/*  47 */     float moveStrafe = getMinecraft.player.movementInput.moveStrafe;
/*  48 */     float n2 = getMinecraft.player.prevRotationYaw + (getMinecraft.player.rotationYaw - getMinecraft.player.prevRotationYaw) * getMinecraft.getRenderPartialTicks();
/*  49 */     if (moveForward != 0.0F) {
/*  50 */       if (moveStrafe > 0.0F) {
/*  51 */         n2 += ((moveForward > 0.0F) ? -45 : 45);
/*     */       }
/*  53 */       else if (moveStrafe < 0.0F) {
/*  54 */         n2 += ((moveForward > 0.0F) ? 45 : -45);
/*     */       } 
/*  56 */       moveStrafe = 0.0F;
/*  57 */       if (moveForward > 0.0F) {
/*  58 */         moveForward = 1.0F;
/*     */       }
/*  60 */       else if (moveForward < 0.0F) {
/*  61 */         moveForward = -1.0F;
/*     */       } 
/*     */     } 
/*  64 */     double sin = Math.sin(Math.toRadians((n2 + 90.0F)));
/*  65 */     double cos = Math.cos(Math.toRadians((n2 + 90.0F)));
/*  66 */     return new double[] { moveForward * n * cos + moveStrafe * n * sin, moveForward * n * sin - moveStrafe * n * cos };
/*     */   }
/*     */   
/*     */   public static Vec3d direction(float n) {
/*  70 */     return new Vec3d(Math.cos(degToRad((n + 90.0F))), 0.0D, Math.sin(degToRad((n + 90.0F))));
/*     */   }
/*     */   
/*     */   public static float round(float n, int newScale) {
/*  74 */     if (newScale < 0) {
/*  75 */       throw new IllegalArgumentException();
/*     */     }
/*  77 */     return BigDecimal.valueOf(n).setScale(newScale, RoundingMode.FLOOR).floatValue();
/*     */   }
/*     */   
/*     */   public static double clamp(double a, double n, double b) {
/*  81 */     return (a < n) ? n : Math.min(a, b);
/*     */   }
/*     */   
/*     */   public static double angleBetweenVecs(Vec3d vec3d, Vec3d vec3d2) {
/*  85 */     return -(Math.atan2(vec3d.x - vec3d2.x, vec3d.z - vec3d2.z) / Math.PI) * 360.0D / 2.0D + 180.0D;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getBlockBlocks(Entity entity) {
/*  89 */     ArrayList<Vec3d> list = new ArrayList<>();
/*  90 */     AxisAlignedBB getEntityBoundingBox = entity.getEntityBoundingBox();
/*  91 */     double posY = entity.posY;
/*  92 */     double round = round(getEntityBoundingBox.minX, 0);
/*  93 */     double round2 = round(getEntityBoundingBox.minZ, 0);
/*  94 */     double round3 = round(getEntityBoundingBox.maxX, 0);
/*  95 */     double round4 = round(getEntityBoundingBox.maxZ, 0);
/*  96 */     if (round != round3) {
/*  97 */       Vec3d e = new Vec3d(round, posY, round2);
/*  98 */       Vec3d e2 = new Vec3d(round3, posY, round2);
/*  99 */       BlockPos blockPos = new BlockPos(e);
/* 100 */       BlockPos blockPos2 = new BlockPos(e2);
/* 101 */       if (BlockUtil.isBlockUnSolid(blockPos) && BlockUtil.isBlockUnSolid(blockPos2)) {
/* 102 */         list.add(e);
/* 103 */         list.add(e2);
/*     */       } 
/* 105 */       if (round2 != round4) {
/* 106 */         Vec3d e3 = new Vec3d(round, posY, round4);
/* 107 */         Vec3d e4 = new Vec3d(round3, posY, round4);
/* 108 */         BlockPos blockPos3 = new BlockPos(e);
/* 109 */         BlockPos blockPos4 = new BlockPos(e2);
/* 110 */         if (BlockUtil.isBlockUnSolid(blockPos3) && BlockUtil.isBlockUnSolid(blockPos4)) {
/* 111 */           list.add(e3);
/* 112 */           list.add(e4);
/* 113 */           return list;
/*     */         } 
/*     */       } 
/* 116 */       if (list.isEmpty()) {
/* 117 */         list.add(entity.getPositionVector());
/*     */       }
/* 119 */       return list;
/*     */     } 
/* 121 */     if (round2 != round4) {
/* 122 */       Vec3d e5 = new Vec3d(round, posY, round2);
/* 123 */       Vec3d e6 = new Vec3d(round, posY, round4);
/* 124 */       BlockPos blockPos5 = new BlockPos(e5);
/* 125 */       BlockPos blockPos6 = new BlockPos(e6);
/* 126 */       if (BlockUtil.isBlockUnSolid(blockPos5) && BlockUtil.isBlockUnSolid(blockPos6)) {
/* 127 */         list.add(e5);
/* 128 */         list.add(e6);
/*     */       } 
/* 130 */       if (list.isEmpty()) {
/* 131 */         list.add(entity.getPositionVector());
/*     */       }
/* 133 */       return list;
/*     */     } 
/* 135 */     list.add(entity.getPositionVector());
/* 136 */     return list;
/*     */   }
/*     */   
/*     */   public static float sin(float n) {
/* 140 */     return MathHelper.sin(n);
/*     */   }
/*     */   
/*     */   public static int clamp(int a, int n, int b) {
/* 144 */     return (a < n) ? n : Math.min(a, b);
/*     */   }
/*     */   
/*     */   public static double square(float n) {
/* 148 */     return (n * n);
/*     */   }
/*     */   
/*     */   public static String getDirectionFromPlayer(double n, double n2) {
/* 152 */     double n3 = Math.toDegrees(Math.atan2(-(mc.player.posX - n), -(mc.player.posZ - n2))) + mc.player.rotationYaw;
/* 153 */     if (n3 < 0.0D) {
/* 154 */       n3 += 360.0D;
/*     */     }
/* 156 */     if (n3 > 315.0D || n3 <= 45.0D) {
/* 157 */       return "in front of you";
/*     */     }
/* 159 */     if (n3 > 45.0D && n3 <= 135.0D) {
/* 160 */       return "to your left";
/*     */     }
/* 162 */     if (n3 > 135.0D && n3 <= 225.0D) {
/* 163 */       return "behind you";
/*     */     }
/* 165 */     if (n3 > 225.0D && n3 <= 315.0D) {
/* 166 */       return "to your right";
/*     */     }
/* 168 */     return String.valueOf(ChatFormatting.OBFUSCATED + "living in your walls");
/*     */   }
/*     */   
/*     */   public static float roundFloat(double val, int newScale) {
/* 172 */     return BigDecimal.valueOf(val).setScale(newScale, RoundingMode.FLOOR).floatValue();
/*     */   }
/*     */   
/*     */   public static float wrap(float n) {
/* 176 */     float n2 = n % 360.0F;
/* 177 */     if (n2 >= 180.0F) {
/* 178 */       n2 -= 360.0F;
/*     */     }
/* 180 */     if (n2 < -180.0F) {
/* 181 */       n2 += 360.0F;
/*     */     }
/* 183 */     return n2;
/*     */   }
/*     */   
/*     */   public static Vec3d roundVec(Vec3d vec3d, int n) {
/* 187 */     return new Vec3d(round(vec3d.x, n), round(vec3d.y, n), round(vec3d.z, n));
/*     */   }
/*     */   
/*     */   public static double getIncremental(double n, double n2) {
/* 191 */     double n3 = 1.0D / n2;
/* 192 */     return Math.round(n * n3) / n3;
/*     */   }
/*     */   
/*     */   public static Vec3d calculateLine(Vec3d vec3d, Vec3d vec3d2, double n) {
/* 196 */     double sqrt = Math.sqrt(multiply(vec3d2.x - vec3d.x) + multiply(vec3d2.y - vec3d.y) + multiply(vec3d2.z - vec3d.z));
/* 197 */     return new Vec3d(vec3d.x + (vec3d2.x - vec3d.x) / sqrt * n, vec3d.y + (vec3d2.y - vec3d.y) / sqrt * n, vec3d.z + (vec3d2.z - vec3d.z) / sqrt * n);
/*     */   }
/*     */   
/*     */   public static double round(double val, int newScale) {
/* 201 */     if (newScale < 0) {
/* 202 */       throw new IllegalArgumentException();
/*     */     }
/* 204 */     return BigDecimal.valueOf(val).setScale(newScale, RoundingMode.FLOOR).doubleValue();
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAligned(Vec3d vec3d, Vec3d vec3d2) {
/* 208 */     return areVec3dsAlignedRetarded(vec3d, vec3d2);
/*     */   }
/*     */   
/*     */   public static String getTimeOfDay() {
/* 212 */     int value = Calendar.getInstance().get(11);
/* 213 */     if (value < 12) {
/* 214 */       return "Good Morning ";
/*     */     }
/* 216 */     if (value < 16) {
/* 217 */       return "Good Afternoon ";
/*     */     }
/* 219 */     if (value < 21) {
/* 220 */       return "Good Evening ";
/*     */     }
/* 222 */     return "Good Night ";
/*     */   }
/*     */   
/*     */   public static double[] directionSpeed(double n) {
/* 226 */     float moveForward = mc.player.movementInput.moveForward;
/* 227 */     float moveStrafe = mc.player.movementInput.moveStrafe;
/* 228 */     float n2 = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/* 229 */     if (moveForward != 0.0F) {
/* 230 */       if (moveStrafe > 0.0F) {
/* 231 */         n2 += ((moveForward > 0.0F) ? -45 : 45);
/*     */       }
/* 233 */       else if (moveStrafe < 0.0F) {
/* 234 */         n2 += ((moveForward > 0.0F) ? 45 : -45);
/*     */       } 
/* 236 */       moveStrafe = 0.0F;
/* 237 */       if (moveForward > 0.0F) {
/* 238 */         moveForward = 1.0F;
/*     */       }
/* 240 */       else if (moveForward < 0.0F) {
/* 241 */         moveForward = -1.0F;
/*     */       } 
/*     */     } 
/* 244 */     double sin = Math.sin(Math.toRadians((n2 + 90.0F)));
/* 245 */     double cos = Math.cos(Math.toRadians((n2 + 90.0F)));
/* 246 */     return new double[] { moveForward * n * cos + moveStrafe * n * sin, moveForward * n * sin - moveStrafe * n * cos };
/*     */   }
/*     */   
/*     */   public static Vec3d extrapolatePlayerPosition(EntityPlayer entityPlayer, int n) {
/* 250 */     Vec3d calculateLine = calculateLine(new Vec3d(entityPlayer.lastTickPosX, entityPlayer.lastTickPosY, entityPlayer.lastTickPosZ), new Vec3d(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ), (multiply(entityPlayer.motionX) + multiply(entityPlayer.motionY) + multiply(entityPlayer.motionZ)) * n);
/* 251 */     return new Vec3d(calculateLine.x, entityPlayer.posY, calculateLine.z);
/*     */   }
/*     */   
/*     */   public static Vec3d interpolateEntity(Entity entity, float n) {
/* 255 */     return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * n, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * n, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * n);
/*     */   }
/*     */   
/*     */   public static double wrapDegrees(double n) {
/* 259 */     return MathHelper.wrapDegrees(n);
/*     */   }
/*     */   
/*     */   public static float clamp(float a, float n, float b) {
/* 263 */     return (a < n) ? n : Math.min(a, b);
/*     */   }
/*     */   
/*     */   public static double radToDeg(double n) {
/* 267 */     return n * 57.295780181884766D;
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedRenderPos(Entity entity, float n) {
/* 271 */     return interpolateEntity(entity, n).subtract((Minecraft.getMinecraft().getRenderManager()).renderPosX, (Minecraft.getMinecraft().getRenderManager()).renderPosY, (Minecraft.getMinecraft().getRenderManager()).renderPosZ);
/*     */   }
/*     */   
/*     */   public static double lengthSQ(Vec3d vec3d) {
/* 275 */     return square(vec3d.x) + square(vec3d.y) + square(vec3d.z);
/*     */   }
/*     */   
/*     */   public static double dot(Vec3d vec3d, Vec3d vec3d2) {
/* 279 */     return vec3d.x * vec3d2.x + vec3d.y * vec3d2.y + vec3d.z * vec3d2.z;
/*     */   }
/*     */   
/*     */   public static float[] calcAngleNoY(Vec3d vec3d, Vec3d vec3d2) {
/* 283 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vec3d2.z - vec3d.z, vec3d2.x - vec3d.x)) - 90.0D) };
/*     */   }
/*     */   
/*     */   public static float[] calcAngle(Vec3d vec3d, Vec3d vec3d2) {
/* 287 */     double x = vec3d2.x - vec3d.x;
/* 288 */     double y = (vec3d2.y - vec3d.y) * -1.0D;
/* 289 */     double y2 = vec3d2.z - vec3d.z;
/* 290 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(y2, x)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(y, MathHelper.sqrt(x * x + y2 * y2)))) };
/*     */   }
/*     */ 
/*     */   
/* 294 */   private static final Random random = new Random();
/*     */ 
/*     */   
/*     */   public static float wrapDegrees(float n) {
/* 298 */     return MathHelper.wrapDegrees(n);
/*     */   }
/*     */   
/*     */   public static double degToRad(double n) {
/* 302 */     return n * 0.01745329238474369D;
/*     */   }
/*     */   
/*     */   public static float getRandom(float n, float n2) {
/* 306 */     return MathHelper.clamp(n + random.nextFloat() * n2, n, n2);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
