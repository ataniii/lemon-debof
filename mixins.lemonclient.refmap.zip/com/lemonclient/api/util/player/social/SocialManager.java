/*     */ package com.lemonclient.api.util.player.social;
/*     */ 
/*     */ import com.lemonclient.client.module.ModuleManager;
/*     */ import com.lemonclient.client.module.modules.qwq.Friends;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ public class SocialManager
/*     */ {
/*  10 */   private static final ArrayList<Friend> friends = new ArrayList<>();
/*  11 */   private static final ArrayList<Enemy> enemies = new ArrayList<>();
/*  12 */   private static final ArrayList<Ignore> ignores = new ArrayList<>();
/*     */   
/*     */   public static ArrayList<Friend> getFriends() {
/*  15 */     return friends;
/*     */   }
/*     */   
/*     */   public static ArrayList<Enemy> getEnemies() {
/*  19 */     return enemies;
/*     */   }
/*     */   
/*     */   public static ArrayList<Ignore> getIgnores() {
/*  23 */     return ignores;
/*     */   }
/*     */   
/*     */   public static ArrayList<String> getFriendsByName() {
/*  27 */     ArrayList<String> friendNames = new ArrayList<>();
/*     */     
/*  29 */     getFriends().forEach(friend -> friendNames.add(friend.getName()));
/*  30 */     return friendNames;
/*     */   }
/*     */   
/*     */   public static ArrayList<String> getEnemiesByName() {
/*  34 */     ArrayList<String> enemyNames = new ArrayList<>();
/*     */     
/*  36 */     getEnemies().forEach(enemy -> enemyNames.add(enemy.getName()));
/*  37 */     return enemyNames;
/*     */   }
/*     */   
/*     */   public static ArrayList<String> getIgnoresByName() {
/*  41 */     ArrayList<String> ignoreNames = new ArrayList<>();
/*     */     
/*  43 */     getIgnores().forEach(ignore -> ignoreNames.add(ignore.getName()));
/*  44 */     return ignoreNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isFriend(String name) {
/*  49 */     for (Friend friend : getFriends()) {
/*  50 */       if (friend.getName().equalsIgnoreCase(name) && ModuleManager.isModuleEnabled(Friends.class)) {
/*  51 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  55 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isOnFriendList(String name) {
/*  59 */     boolean value = false;
/*  60 */     for (Friend friend : getFriends()) {
/*  61 */       if (friend.getName().equalsIgnoreCase(name)) {
/*  62 */         value = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  66 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isEnemy(String name) {
/*  71 */     for (Enemy enemy : getEnemies()) {
/*  72 */       if (enemy.getName().equalsIgnoreCase(name)) {
/*  73 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  77 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isOnEnemyList(String name) {
/*  81 */     boolean value = false;
/*  82 */     for (Enemy enemy : getEnemies()) {
/*  83 */       if (enemy.getName().equalsIgnoreCase(name)) {
/*  84 */         value = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  88 */     return value;
/*     */   }
/*     */   
/*     */   public static boolean isIgnore(String name) {
/*  92 */     for (Ignore ignore : getIgnores()) {
/*  93 */       if (ignore.getName().equalsIgnoreCase(name)) {
/*  94 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  98 */     return false;
/*     */   }
/*     */   public static boolean isOnIgnoreList(String name) {
/* 101 */     boolean value = false;
/* 102 */     for (Ignore ignore : getIgnores()) {
/* 103 */       if (ignore.getName().equalsIgnoreCase(name)) {
/* 104 */         value = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 108 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Friend getFriend(String name) {
/* 114 */     for (Friend friend : getFriends()) {
/* 115 */       if (friend.getName().equalsIgnoreCase(name))
/* 116 */         return friend; 
/* 117 */     }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Enemy getEnemy(String name) {
/* 122 */     for (Enemy enemy : getEnemies()) {
/* 123 */       if (enemy.getName().equalsIgnoreCase(name))
/* 124 */         return enemy; 
/* 125 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ignore getIgnore(String name) {
/* 131 */     for (Ignore ignore : getIgnores()) {
/* 132 */       if (ignore.getName().equalsIgnoreCase(name))
/* 133 */         return ignore; 
/* 134 */     }  return null;
/*     */   }
/*     */   
/*     */   public static void addFriend(String name) {
/* 138 */     if (!isOnFriendList(name)) getFriends().add(new Friend(name)); 
/*     */   }
/*     */   
/*     */   public static void delFriend(String name) {
/* 142 */     getFriends().remove(getFriend(name));
/*     */   }
/*     */   
/*     */   public static void addEnemy(String name) {
/* 146 */     if (!isOnEnemyList(name)) getEnemies().add(new Enemy(name)); 
/*     */   }
/*     */   
/*     */   public static void delEnemy(String name) {
/* 150 */     getEnemies().remove(getEnemy(name));
/*     */   }
/*     */   
/*     */   public static void addIgnore(String name) {
/* 154 */     if (!isOnIgnoreList(name)) getIgnores().add(new Ignore(name)); 
/*     */   }
/*     */   
/*     */   public static void delIgnore(String name) {
/* 158 */     getIgnores().remove(getIgnore(name));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\social\SocialManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */