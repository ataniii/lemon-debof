/*    */ package com.lemonclient.api.util.player.social;
/*    */ 
/*    */ public class Enemy
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public Enemy(String name) {
/*  8 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 12 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\social\Enemy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */