/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.io.IOUtils;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameUtil
/*    */ {
/* 16 */   private static final Map<String, String> uuidNameCache = Maps.newConcurrentMap();
/*    */   
/*    */   public static String resolveName(String uuid) {
/* 19 */     uuid = uuid.replace("-", "");
/* 20 */     if (uuidNameCache.containsKey(uuid)) {
/* 21 */       return uuidNameCache.get(uuid);
/*    */     }
/*    */     
/* 24 */     String url = "https://api.mojang.com/user/profiles/" + uuid + "/names";
/*    */     try {
/* 26 */       String nameJson = IOUtils.toString(new URL(url));
/* 27 */       if (nameJson != null && nameJson.length() > 0) {
/* 28 */         JSONArray jsonArray = (JSONArray)JSONValue.parseWithException(nameJson);
/* 29 */         if (jsonArray != null) {
/* 30 */           JSONObject latestName = (JSONObject)jsonArray.get(jsonArray.size() - 1);
/* 31 */           if (latestName != null) {
/* 32 */             return latestName.get("name").toString();
/*    */           }
/*    */         } 
/*    */       } 
/* 36 */     } catch (IOException|org.json.simple.parser.ParseException iOException) {}
/*    */ 
/*    */     
/* 39 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\NameUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */