//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import com.lemonclient.api.event.events.PacketEvent;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import me.zero.alpine.listener.EventHandler;
/*    */ import me.zero.alpine.listener.Listenable;
/*    */ import me.zero.alpine.listener.Listener;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ 
/*    */ public class SpoofRotationUtil implements Listenable {
/* 16 */   private static final Minecraft mc = Minecraft.getMinecraft();
/* 17 */   public static final SpoofRotationUtil ROTATION_UTIL = new SpoofRotationUtil();
/*    */   
/* 19 */   private int rotationConnections = 0;
/*    */   
/*    */   private boolean shouldSpoofAngles;
/*    */   
/*    */   private boolean isSpoofingAngles;
/*    */   
/*    */   private double yaw;
/*    */   
/*    */   private double pitch;
/*    */   @EventHandler
/*    */   private final Listener<PacketEvent.Send> packetSendListener;
/*    */   
/*    */   public void onEnable() {
/* 32 */     this.rotationConnections++;
/* 33 */     if (this.rotationConnections == 1)
/* 34 */       LemonClient.EVENT_BUS.subscribe(this); 
/*    */   }
/*    */   
/*    */   public void onDisable() {
/* 38 */     this.rotationConnections--;
/* 39 */     if (this.rotationConnections == 0)
/* 40 */       LemonClient.EVENT_BUS.unsubscribe(this); 
/*    */   }
/*    */   
/*    */   public void lookAtPacket(double px, double py, double pz, EntityPlayer me) {
/* 44 */     double[] v = EntityUtil.calculateLookAt(px, py, pz, (Entity)me);
/* 45 */     setYawAndPitch((float)v[0], (float)v[1]);
/*    */   }
/*    */   
/*    */   public void setYawAndPitch(float yaw1, float pitch1) {
/* 49 */     this.yaw = yaw1;
/* 50 */     this.pitch = pitch1;
/* 51 */     this.isSpoofingAngles = true;
/*    */   }
/*    */   
/*    */   public void resetRotation() {
/* 55 */     if (this.isSpoofingAngles) {
/* 56 */       this.yaw = mc.player.rotationYaw;
/* 57 */       this.pitch = mc.player.rotationPitch;
/* 58 */       this.isSpoofingAngles = false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void shouldSpoofAngles(boolean e) {
/* 63 */     this.shouldSpoofAngles = e;
/*    */   }
/*    */   
/*    */   public boolean isSpoofingAngles() {
/* 67 */     return this.isSpoofingAngles;
/*    */   }
/*    */   private SpoofRotationUtil() {
/* 70 */     this.packetSendListener = new Listener(event -> { Packet packet = event.getPacket(); if (packet instanceof CPacketPlayer && this.shouldSpoofAngles && this.isSpoofingAngles) { ((CPacketPlayer)packet).yaw = (float)this.yaw; ((CPacketPlayer)packet).pitch = (float)this.pitch; }  }new java.util.function.Predicate[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\SpoofRotationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
