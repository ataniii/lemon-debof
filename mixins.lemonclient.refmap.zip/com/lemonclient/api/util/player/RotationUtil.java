//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.player;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class RotationUtil {
/*  12 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static EnumFacing getFacing(double rotationYaw) {
/*  15 */     return EnumFacing.byHorizontalIndex(MathHelper.floor(rotationYaw * 4.0D / 360.0D + 0.5D) & 0x3);
/*     */   }
/*     */   public static Vec2f getRotationTo(AxisAlignedBB box) {
/*  18 */     EntityPlayerSP player = mc.player;
/*  19 */     if (player == null) {
/*  20 */       return Vec2f.ZERO;
/*     */     }
/*     */     
/*  23 */     Vec3d eyePos = player.getPositionEyes(1.0F);
/*     */     
/*  25 */     if (player.getEntityBoundingBox().intersects(box)) {
/*  26 */       return getRotationTo(eyePos, box.getCenter());
/*     */     }
/*     */     
/*  29 */     double x = MathHelper.clamp(eyePos.x, box.minX, box.maxX);
/*  30 */     double y = MathHelper.clamp(eyePos.y, box.minY, box.maxY);
/*  31 */     double z = MathHelper.clamp(eyePos.z, box.minZ, box.maxZ);
/*     */     
/*  33 */     return getRotationTo(eyePos, new Vec3d(x, y, z));
/*     */   }
/*     */   
/*     */   public static Vec2f getRotationTo(Vec3d posTo) {
/*  37 */     EntityPlayerSP player = mc.player;
/*  38 */     return (player != null) ? getRotationTo(player.getPositionEyes(1.0F), posTo) : Vec2f.ZERO;
/*     */   }
/*     */   
/*     */   public static Vec2f getRotationTo(Vec3d posFrom, Vec3d posTo) {
/*  42 */     return getRotationFromVec(posTo.subtract(posFrom));
/*     */   }
/*     */   
/*     */   public static Vec2f getRotationFromVec(Vec3d vec) {
/*  46 */     double lengthXZ = Math.hypot(vec.x, vec.z);
/*  47 */     double yaw = normalizeAngle(Math.toDegrees(Math.atan2(vec.z, vec.x)) - 90.0D);
/*  48 */     double pitch = normalizeAngle(Math.toDegrees(-Math.atan2(vec.y, lengthXZ)));
/*     */     
/*  50 */     return new Vec2f((float)yaw, (float)pitch);
/*     */   }
/*     */   
/*     */   public static double normalizeAngle(double angle) {
/*  54 */     angle %= 360.0D;
/*     */     
/*  56 */     if (angle >= 180.0D) {
/*  57 */       angle -= 360.0D;
/*     */     }
/*     */     
/*  60 */     if (angle < -180.0D) {
/*  61 */       angle += 360.0D;
/*     */     }
/*     */     
/*  64 */     return angle;
/*     */   }
/*     */   
/*     */   public static float normalizeAngle(float angle) {
/*  68 */     angle %= 360.0F;
/*     */     
/*  70 */     if (angle >= 180.0F) {
/*  71 */       angle -= 360.0F;
/*     */     }
/*     */     
/*  74 */     if (angle < -180.0F) {
/*  75 */       angle += 360.0F;
/*     */     }
/*     */     
/*  78 */     return angle;
/*     */   }
/*     */   
/*     */   public static boolean isInFov(BlockPos pos) {
/*  82 */     return (pos != null && (mc.player.getDistanceSq(pos) < 4.0D || yawDist(pos) < (getHalvedfov() + 2.0F)));
/*     */   }
/*     */   
/*     */   public static boolean isInFov(Entity entity) {
/*  86 */     return (entity != null && (mc.player.getDistanceSq(entity) < 4.0D || yawDist(entity) < (getHalvedfov() + 2.0F)));
/*     */   }
/*     */   
/*     */   public static double yawDist(BlockPos pos) {
/*  90 */     if (pos != null) {
/*  91 */       Vec3d difference = (new Vec3d((Vec3i)pos)).subtract(mc.player.getPositionEyes(mc.getRenderPartialTicks()));
/*  92 */       double d = Math.abs(mc.player.rotationYaw - Math.toDegrees(Math.atan2(difference.z, difference.x)) - 90.0D) % 360.0D;
/*  93 */       return (d > 180.0D) ? (360.0D - d) : d;
/*     */     } 
/*  95 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static double yawDist(Entity e) {
/*  99 */     if (e != null) {
/* 100 */       Vec3d difference = e.getPositionVector().add(0.0D, (e.getEyeHeight() / 2.0F), 0.0D).subtract(mc.player.getPositionEyes(mc.getRenderPartialTicks()));
/* 101 */       double d = Math.abs(mc.player.rotationYaw - Math.toDegrees(Math.atan2(difference.z, difference.x)) - 90.0D) % 360.0D;
/* 102 */       return (d > 180.0D) ? (360.0D - d) : d;
/*     */     } 
/* 104 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static float transformYaw() {
/* 108 */     float yaw = mc.player.rotationYaw % 360.0F;
/* 109 */     if (mc.player.rotationYaw > 0.0F) {
/* 110 */       if (yaw > 180.0F) {
/* 111 */         yaw = -180.0F + yaw - 180.0F;
/*     */       }
/* 113 */     } else if (yaw < -180.0F) {
/* 114 */       yaw = 180.0F + yaw + 180.0F;
/*     */     } 
/* 116 */     if (yaw < 0.0F) {
/* 117 */       return 180.0F + yaw;
/*     */     }
/* 119 */     return -180.0F + yaw;
/*     */   }
/*     */   
/*     */   public static boolean isInFov(Vec3d vec3d, Vec3d other) {
/* 123 */     if ((mc.player.rotationPitch > 30.0F) ? (other.y > mc.player.posY) : (mc.player.rotationPitch < -30.0F && other.y < mc.player.posY)) {
/* 124 */       return true;
/*     */     }
/* 126 */     float angle = BlockUtil.calcAngleNoY(vec3d, other)[0] - transformYaw();
/* 127 */     if (angle < -270.0F) {
/* 128 */       return true;
/*     */     }
/* 130 */     float fov = mc.gameSettings.fovSetting / 2.0F;
/* 131 */     return (angle < fov + 10.0F && angle > -fov - 10.0F);
/*     */   }
/*     */   
/*     */   public static float getFov() {
/* 135 */     return mc.gameSettings.fovSetting;
/*     */   }
/*     */   
/*     */   public static float getHalvedfov() {
/* 139 */     return getFov() / 2.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\RotationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
