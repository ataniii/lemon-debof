/*    */ package com.lemonclient.api.util.player;
/*    */ 
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class InvStack
/*    */ {
/*    */   public final int slot;
/*    */   public final ItemStack stack;
/*    */   
/*    */   public InvStack(int slot, ItemStack stack) {
/* 11 */     this.slot = slot;
/* 12 */     this.stack = stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\player\InvStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */