/*     */ package com.lemonclient.api.util.log4j;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.directory.Attributes;
/*     */ import javax.naming.directory.SearchResult;
/*     */ 
/*     */ public enum EmptyJndiContext implements Context, DirContext {
/*   9 */   INSTANCE;
/*     */ 
/*     */   
/*     */   public Object lookup(Name name) {
/*  13 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object lookup(String name) {
/*  18 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(Name name, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(String name, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebind(Name name, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebind(String name, Object obj) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbind(Name name) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbind(String name) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rename(Name oldName, Name newName) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void rename(String oldName, String newName) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public NamingEnumeration<NameClassPair> list(Name name) {
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<NameClassPair> list(String name) {
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<Binding> listBindings(Name name) throws NamingException {
/*  73 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<Binding> listBindings(String name) throws NamingException {
/*  78 */     return panic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroySubcontext(Name name) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroySubcontext(String name) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Context createSubcontext(Name name) throws NamingException {
/*  93 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Context createSubcontext(String name) throws NamingException {
/*  98 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object lookupLink(Name name) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object lookupLink(String name) {
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public NameParser getNameParser(Name name) throws NamingException {
/* 113 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NameParser getNameParser(String name) throws NamingException {
/* 118 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Name composeName(Name name, Name prefix) throws NamingException {
/* 123 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public String composeName(String name, String prefix) throws NamingException {
/* 128 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object addToEnvironment(String propName, Object propVal) {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object removeFromEnvironment(String propName) {
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Hashtable<?, ?> getEnvironment() {
/* 143 */     return new Hashtable<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNameInNamespace() {
/* 153 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Attributes getAttributes(Name name) throws NamingException {
/* 159 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Attributes getAttributes(String name) throws NamingException {
/* 164 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Attributes getAttributes(Name name, String[] attrIds) throws NamingException {
/* 169 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public Attributes getAttributes(String name, String[] attrIds) throws NamingException {
/* 174 */     return panic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyAttributes(Name name, int mod_op, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyAttributes(String name, int mod_op, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyAttributes(Name name, ModificationItem[] mods) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyAttributes(String name, ModificationItem[] mods) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(Name name, Object obj, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(String name, Object obj, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebind(Name name, Object obj, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebind(String name, Object obj, Attributes attrs) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public DirContext createSubcontext(Name name, Attributes attrs) throws NamingException {
/* 219 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public DirContext createSubcontext(String name, Attributes attrs) throws NamingException {
/* 224 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public DirContext getSchema(Name name) throws NamingException {
/* 229 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public DirContext getSchema(String name) throws NamingException {
/* 234 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public DirContext getSchemaClassDefinition(Name name) throws NamingException {
/* 239 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public DirContext getSchemaClassDefinition(String name) throws NamingException {
/* 244 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(Name name, Attributes matchingAttributes, String[] attributesToReturn) throws NamingException {
/* 249 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(String name, Attributes matchingAttributes, String[] attributesToReturn) throws NamingException {
/* 254 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(Name name, Attributes matchingAttributes) throws NamingException {
/* 259 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(String name, Attributes matchingAttributes) throws NamingException {
/* 264 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(Name name, String filter, SearchControls cons) throws NamingException {
/* 269 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(String name, String filter, SearchControls cons) throws NamingException {
/* 274 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(Name name, String filterExpr, Object[] filterArgs, SearchControls cons) throws NamingException {
/* 279 */     return panic();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamingEnumeration<SearchResult> search(String name, String filterExpr, Object[] filterArgs, SearchControls cons) throws NamingException {
/* 284 */     return panic();
/*     */   }
/*     */   
/*     */   private static <T> T panic() throws NamingException {
/* 288 */     throw new NamingException("JNDI has been removed");
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\log4j\EmptyJndiContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */