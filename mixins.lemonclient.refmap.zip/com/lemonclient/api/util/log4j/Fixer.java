/*     */ package com.lemonclient.api.util.log4j;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import javax.naming.Context;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.core.appender.AbstractManager;
/*     */ import org.apache.logging.log4j.core.net.JndiManager;
/*     */ 
/*     */ public class Fixer
/*     */ {
/*     */   public static void doRuntimeTest(Logger logger) {
/*  17 */     logger.info("Fix4Log4J loaded.");
/*  18 */     logger.info("If you see stacktrace below, CLOSE EVERYTHING IMMEDIATELY!");
/*     */     
/*  20 */     String someRandomUri = randomUri();
/*  21 */     logger.info("Exploit Test: ${jndi:ldap://" + someRandomUri + "}");
/*     */   }
/*     */   
/*     */   private static String randomUri() {
/*  25 */     char[] buf = new char[81];
/*  26 */     Random rng = new SecureRandom();
/*     */     
/*  28 */     for (int i = 0; i < buf.length; i++) {
/*  29 */       buf[i] = (char)(97 + rng.nextInt(26));
/*     */     }
/*  31 */     buf[40] = ':';
/*     */     
/*  33 */     return new String(buf);
/*     */   }
/*     */   
/*     */   public static void disableJndiManager() {
/*     */     try {
/*  38 */       disableJndiManager0();
/*  39 */     } catch (Exception ex) {
/*  40 */       throw new ExceptionInInitializerError(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void disableJndiManager0() {
/*  46 */     JndiManager.getDefaultManager();
/*     */     
/*  48 */     Class<AbstractManager> mapHolder = AbstractManager.class;
/*     */     
/*  50 */     Arrays.<Field>stream(mapHolder.getDeclaredFields()).filter(f -> Modifier.isStatic(f.getModifiers()))
/*     */       
/*  52 */       .filter(f -> Map.class.isAssignableFrom(f.getType()))
/*     */       
/*  54 */       .map(f -> {
/*     */           try {
/*     */             f.setAccessible(true);
/*     */ 
/*     */             
/*     */             return (Map)f.get(null);
/*  60 */           } catch (IllegalAccessException e) {
/*     */             
/*     */             throw new ExceptionInInitializerError(e);
/*     */           } 
/*  64 */         }).forEach(map -> {
/*     */           if (map == null) {
/*     */             return;
/*     */           }
/*     */           map.forEach(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fixJndiManager(JndiManager jndiManager) throws ReflectiveOperationException {
/*  83 */     Arrays.<Field>stream(jndiManager.getClass().getDeclaredFields()).filter(f -> Context.class.isAssignableFrom(f.getType()))
/*     */       
/*  85 */       .forEach(f -> {
/*     */           try {
/*     */             f.setAccessible(true);
/*     */             
/*     */             removeFinalModifier(f);
/*     */             
/*     */             f.set(jndiManager, EmptyJndiContext.INSTANCE);
/*  92 */           } catch (IllegalAccessException e) {
/*     */             throw new ExceptionInInitializerError(e);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static void removeFinalModifier(Field field) throws IllegalAccessException {
/*     */     try {
/* 101 */       if (Modifier.isFinal(field.getModifiers())) {
/*     */         
/* 103 */         Field modifiersField = Field.class.getDeclaredField("modifiers");
/* 104 */         boolean doForceAccess = !modifiersField.isAccessible();
/* 105 */         if (doForceAccess) {
/* 106 */           modifiersField.setAccessible(true);
/*     */         }
/*     */         try {
/* 109 */           modifiersField.setInt(field, field.getModifiers() & 0xFFFFFFEF);
/*     */         } finally {
/* 111 */           if (doForceAccess) {
/* 112 */             modifiersField.setAccessible(false);
/*     */           }
/*     */         } 
/*     */       } 
/* 116 */     } catch (NoSuchFieldException noSuchFieldException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\log4j\Fixer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */