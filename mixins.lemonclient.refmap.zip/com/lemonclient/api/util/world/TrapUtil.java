//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import jdk.nashorn.internal.objects.NativeMath;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketAnimation;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrapUtil
/*     */ {
/*  30 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static void placeBlock(BlockPos pos) {
/*  33 */     for (EnumFacing side : EnumFacing.VALUES) {
/*  34 */       BlockPos neighbor = pos.offset(side);
/*  35 */       IBlockState neighborState = mc.world.getBlockState(neighbor);
/*  36 */       if (neighborState.getBlock().canCollideCheck(neighborState, false)) {
/*  37 */         boolean sneak = (!mc.player.isSneaking() && neighborState.getBlock().onBlockActivated((World)mc.world, pos, mc.world.getBlockState(pos), (EntityPlayer)mc.player, EnumHand.MAIN_HAND, side, 0.5F, 0.5F, 0.5F));
/*  38 */         if (sneak) {
/*  39 */           mc.getConnection().sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */         }
/*  41 */         mc.getConnection().sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(neighbor, side.getOpposite(), EnumHand.MAIN_HAND, 0.5F, 0.5F, 0.5F));
/*  42 */         mc.getConnection().sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
/*  43 */         if (sneak) {
/*  44 */           mc.getConnection().sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos pos, boolean checkSecond) {
/*  51 */     Chunk chunk = mc.world.getChunk(pos);
/*  52 */     Block block = chunk.getBlockState(pos).getBlock();
/*  53 */     if (block != Blocks.BEDROCK && block != Blocks.OBSIDIAN) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     BlockPos boost = pos.offset(EnumFacing.UP, 1);
/*  58 */     if (chunk.getBlockState(boost).getBlock() != Blocks.AIR || chunk.getBlockState(pos.offset(EnumFacing.UP, 2)).getBlock() != Blocks.AIR) {
/*  59 */       return false;
/*     */     }
/*     */     
/*  62 */     return mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost.getX(), boost.getY(), boost.getZ(), (boost.getX() + 1), (boost.getY() + (checkSecond ? 2 : 1)), (boost.getZ() + 1)), e -> !(e instanceof net.minecraft.entity.item.EntityEnderCrystal)).isEmpty();
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(float radius) {
/*  66 */     List<BlockPos> sphere = new ArrayList<>();
/*  67 */     BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
/*  68 */     int posX = pos.getX();
/*  69 */     int posY = pos.getY();
/*  70 */     int posZ = pos.getZ();
/*  71 */     for (int x = posX - (int)radius; x <= posX + radius; x++) {
/*  72 */       for (int z = posZ - (int)radius; z <= posZ + radius; z++) {
/*  73 */         for (int y = posY - (int)radius; y < posY + radius; y++) {
/*  74 */           if (((posX - x) * (posX - x) + (posZ - z) * (posZ - z) + (posY - y) * (posY - y)) < radius * radius) {
/*  75 */             sphere.add(new BlockPos(x, y, z));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  80 */     return sphere;
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean entityCheck) {
/*     */     try {
/*  85 */       Block block = mc.world.getBlockState(pos).getBlock();
/*  86 */       if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid) && !(block instanceof net.minecraft.block.BlockTallGrass) && !(block instanceof net.minecraft.block.BlockFire) && !(block instanceof net.minecraft.block.BlockDeadBush) && !(block instanceof net.minecraft.block.BlockSnow)) {
/*  87 */         return 0;
/*     */       }
/*     */       
/*  90 */       if (entityCheck) {
/*  91 */         for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/*  92 */           if (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb)) {
/*  93 */             return 1;
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/*  98 */       for (EnumFacing side : getPossibleSides(pos)) {
/*  99 */         if (canBeClicked(pos.offset(side))) {
/* 100 */           return 3;
/*     */         }
/*     */       } 
/*     */       
/* 104 */       return 2;
/* 105 */     } catch (Exception ex) {
/* 106 */       ex.printStackTrace();
/* 107 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/* 112 */     return getBlock(pos).canCollideCheck(getState(pos), false);
/*     */   }
/*     */   
/*     */   private static Block getBlock(BlockPos pos) {
/* 116 */     return getState(pos).getBlock();
/*     */   }
/*     */   
/*     */   private static IBlockState getState(BlockPos pos) {
/* 120 */     return mc.world.getBlockState(pos);
/*     */   }
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/* 124 */     List<EnumFacing> facings = new ArrayList<>(6);
/* 125 */     for (EnumFacing side : EnumFacing.values()) {
/* 126 */       BlockPos neighbour = pos.offset(side);
/* 127 */       if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/* 128 */         IBlockState blockState = mc.world.getBlockState(neighbour);
/* 129 */         if (!blockState.getMaterial().isReplaceable()) {
/* 130 */           facings.add(side);
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return facings;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getHelpingBlocks(Vec3d vec3d) {
/* 138 */     return new Vec3d[] { new Vec3d(vec3d.x, vec3d.y - 1.0D, vec3d.z), new Vec3d((vec3d.x != 0.0D) ? (vec3d.x * 2.0D) : vec3d.x, vec3d.y, (vec3d.x != 0.0D) ? vec3d.z : (vec3d.z * 2.0D)), new Vec3d((vec3d.x == 0.0D) ? (vec3d.x + 1.0D) : vec3d.x, vec3d.y, (vec3d.x == 0.0D) ? vec3d.z : (vec3d.z + 1.0D)), new Vec3d((vec3d.x == 0.0D) ? (vec3d.x - 1.0D) : vec3d.x, vec3d.y, (vec3d.x == 0.0D) ? vec3d.z : (vec3d.z - 1.0D)), new Vec3d(vec3d.x, vec3d.y + 1.0D, vec3d.z) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Vec3d> getOffsetList(int y, boolean floor) {
/* 148 */     List<Vec3d> offsets = new ArrayList<>(5);
/* 149 */     offsets.add(new Vec3d(-1.0D, y, 0.0D));
/* 150 */     offsets.add(new Vec3d(1.0D, y, 0.0D));
/* 151 */     offsets.add(new Vec3d(0.0D, y, -1.0D));
/* 152 */     offsets.add(new Vec3d(0.0D, y, 1.0D));
/*     */     
/* 154 */     if (floor) {
/* 155 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*     */     }
/*     */     
/* 158 */     return offsets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getOffsets(int y, boolean floor) {
/* 162 */     List<Vec3d> offsets = getOffsetList(y, floor);
/* 163 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 164 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
/* 168 */     List<Vec3d> list = getUnsafeBlocks(entity, height, floor);
/* 169 */     Vec3d[] array = new Vec3d[list.size()];
/* 170 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static boolean isSafe(Entity entity, int height, boolean floor) {
/* 174 */     return (getUnsafeBlocks(entity, height, floor).size() == 0);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
/* 178 */     return getUnsafeBlocksFromVec3d(entity.getPositionVector(), height, floor);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
/* 182 */     List<Vec3d> vec3ds = new ArrayList<>(5);
/* 183 */     for (Vec3d vector : getOffsets(height, floor)) {
/* 184 */       Block block = mc.world.getBlockState((new BlockPos(pos)).add(vector.x, vector.y, vector.z)).getBlock();
/* 185 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow) {
/* 186 */         vec3ds.add(vector);
/*     */       }
/*     */     } 
/* 189 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 193 */     List<Vec3d> offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
/* 194 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 195 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 199 */     List<Vec3d> offsets = new ArrayList<>(getOffsetList(1, false));
/* 200 */     offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
/* 201 */     if (antiScaffold) {
/* 202 */       offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
/*     */     }
/* 204 */     if (antiStep) {
/* 205 */       offsets.addAll(getOffsetList(2, false));
/*     */     }
/* 207 */     if (legs) {
/* 208 */       offsets.addAll(getOffsetList(0, false));
/*     */     }
/* 210 */     if (platform) {
/* 211 */       offsets.addAll(getOffsetList(-1, false));
/* 212 */       offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
/*     */     } 
/* 214 */     if (antiDrop) {
/* 215 */       offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
/*     */     }
/* 217 */     return offsets;
/*     */   }
/*     */   
/* 220 */   public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D) };
/*     */ 
/*     */ 
/*     */   
/* 224 */   public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 232 */   public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   public static final Vec3d[] OffsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D) };
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 260 */     return (getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0);
/*     */   }
/*     */   
/*     */   public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 264 */     return (getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace).size() == 0);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getBlockBlocks(Entity entity) {
/* 268 */     List<Vec3d> vec3ds = new ArrayList<>(8);
/* 269 */     AxisAlignedBB bb = entity.getEntityBoundingBox();
/* 270 */     double y = entity.posY;
/* 271 */     double minX = NativeMath.round(Double.valueOf(bb.minX), Integer.valueOf(0));
/* 272 */     double minZ = NativeMath.round(Double.valueOf(bb.minZ), Integer.valueOf(0));
/* 273 */     double maxX = NativeMath.round(Double.valueOf(bb.maxX), Integer.valueOf(0));
/* 274 */     double maxZ = NativeMath.round(Double.valueOf(bb.maxZ), Integer.valueOf(0));
/* 275 */     if (minX != maxX) {
/* 276 */       vec3ds.add(new Vec3d(minX, y, minZ));
/* 277 */       vec3ds.add(new Vec3d(maxX, y, minZ));
/* 278 */       if (minZ != maxZ) {
/* 279 */         vec3ds.add(new Vec3d(minX, y, maxZ));
/* 280 */         vec3ds.add(new Vec3d(maxX, y, maxZ));
/* 281 */         return vec3ds;
/*     */       } 
/* 283 */     } else if (minZ != maxZ) {
/* 284 */       vec3ds.add(new Vec3d(minX, y, minZ));
/* 285 */       vec3ds.add(new Vec3d(minX, y, maxZ));
/* 286 */       return vec3ds;
/*     */     } 
/* 288 */     vec3ds.add(entity.getPositionVector());
/* 289 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 293 */     List<Vec3d> placeTargets = new ArrayList<>();
/* 294 */     if (extension == 1) {
/* 295 */       placeTargets.addAll(targets(player.getPositionVector(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*     */     } else {
/* 297 */       int extend = 1;
/* 298 */       for (Vec3d vec3d : getBlockBlocks((Entity)player)) {
/* 299 */         if (extend > extension) {
/*     */           break;
/*     */         }
/* 302 */         placeTargets.addAll(targets(vec3d, antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/* 303 */         extend++;
/*     */       } 
/*     */     } 
/*     */     
/* 307 */     List<Vec3d> removeList = new ArrayList<>();
/* 308 */     for (Vec3d vec3d : placeTargets) {
/* 309 */       BlockPos pos = new BlockPos(vec3d);
/* 310 */       if (isPositionPlaceable(pos, raytrace) == -1) {
/* 311 */         removeList.add(vec3d);
/*     */       }
/*     */     } 
/*     */     
/* 315 */     for (Vec3d vec3d : removeList) {
/* 316 */       placeTargets.remove(vec3d);
/*     */     }
/*     */     
/* 319 */     return placeTargets;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 324 */     List<Vec3d> vec3ds = new ArrayList<>();
/* 325 */     if (!antiStep && getUnsafeBlocks((Entity)player, 2, false).size() == 4) {
/* 326 */       vec3ds.addAll(getUnsafeBlocks((Entity)player, 2, false));
/*     */     }
/* 328 */     Vec3d[] trapOffsets = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop);
/* 329 */     for (int i = 0; i < trapOffsets.length; i++) {
/* 330 */       Vec3d vector = trapOffsets[i];
/* 331 */       BlockPos targetPos = (new BlockPos(player.getPositionVector())).add(vector.x, vector.y, vector.z);
/* 332 */       Block block = mc.world.getBlockState(targetPos).getBlock();
/* 333 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow) {
/* 334 */         vec3ds.add(vector);
/*     */       }
/*     */     } 
/* 337 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 341 */     List<Vec3d> placeTargets = new ArrayList<>();
/* 342 */     if (antiDrop) {
/* 343 */       Collections.addAll(placeTargets, convertVec3ds(vec3d, antiDropOffsetList));
/*     */     }
/*     */     
/* 346 */     if (platform) {
/* 347 */       Collections.addAll(placeTargets, convertVec3ds(vec3d, platformOffsetList));
/*     */     }
/*     */     
/* 350 */     if (legs) {
/* 351 */       Collections.addAll(placeTargets, convertVec3ds(vec3d, legOffsetList));
/*     */     }
/*     */     
/* 354 */     Collections.addAll(placeTargets, convertVec3ds(vec3d, OffsetList));
/*     */     
/* 356 */     if (antiStep)
/* 357 */     { Collections.addAll(placeTargets, convertVec3ds(vec3d, antiStepOffsetList)); }
/*     */     else
/* 359 */     { List<Vec3d> vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
/* 360 */       if (vec3ds.size() == 4)
/* 361 */       { Iterator<Vec3d> iterator = vec3ds.iterator(); while (true) { if (iterator.hasNext()) { Vec3d vector = iterator.next();
/* 362 */             BlockPos position = (new BlockPos(vec3d)).add(vector.x, vector.y, vector.z);
/* 363 */             switch (isPositionPlaceable(position, raytrace)) {
/*     */               case 0:
/*     */                 break;
/*     */               case -1:
/*     */               case 1:
/*     */               case 2:
/*     */                 continue;
/*     */               case 3:
/* 371 */                 placeTargets.add(vec3d.add(vector));
/*     */                 break;
/*     */               default:
/*     */                 break;
/*     */             }  }
/*     */           else
/*     */           { break; }
/*     */           
/* 379 */           if (antiScaffold) {
/* 380 */             Collections.addAll(placeTargets, convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */           }
/* 382 */           return placeTargets; }  }  }  if (antiScaffold) Collections.addAll(placeTargets, convertVec3ds(vec3d, antiScaffoldOffsetList));  return placeTargets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
/* 386 */     Vec3d[] output = new Vec3d[input.length];
/* 387 */     int length = input.length;
/* 388 */     for (int i = 0; i < length; i++) {
/* 389 */       output[i] = vec3d.add(input[i]);
/*     */     }
/* 391 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\TrapUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
