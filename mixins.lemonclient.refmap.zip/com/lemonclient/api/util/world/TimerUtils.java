//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.world;
/*    */ 
/*    */ import com.lemonclient.api.util.misc.Mapping;
/*    */ import com.lemonclient.mixin.mixins.accessor.AccessorMinecraft;
/*    */ import com.lemonclient.mixin.mixins.accessor.AccessorTimer;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.util.Timer;
/*    */ 
/*    */ public class TimerUtils {
/*    */   private static int counter;
/* 14 */   private static final HashMap<Integer, Float> multipliers = new HashMap<>();
/*    */   
/*    */   public static void setTickLength(float speed) {
/* 17 */     Timer timer = ((AccessorMinecraft)Minecraft.getMinecraft()).getTimer();
/* 18 */     ((AccessorTimer)timer).setTickLength(speed);
/*    */   }
/*    */   
/*    */   public static float getTickLength() {
/* 22 */     Timer timer = ((AccessorMinecraft)Minecraft.getMinecraft()).getTimer();
/* 23 */     return ((AccessorTimer)timer).getTickLength();
/*    */   }
/*    */   
/*    */   public static void setSpeed(float speed) {
/* 27 */     Timer timer = ((AccessorMinecraft)Minecraft.getMinecraft()).getTimer();
/* 28 */     ((AccessorTimer)timer).setTickLength(50.0F / speed);
/*    */   }
/*    */   
/*    */   public static float getTimer() {
/* 32 */     Timer timer = ((AccessorMinecraft)Minecraft.getMinecraft()).getTimer();
/* 33 */     return 50.0F / ((AccessorTimer)timer).getTickLength();
/*    */   }
/*    */   
/*    */   public static void setTimerSpeed(float speed) {
/*    */     try {
/* 38 */       Field timer = Minecraft.class.getDeclaredField(Mapping.timer);
/* 39 */       timer.setAccessible(true);
/* 40 */       Field tickLength = Timer.class.getDeclaredField(Mapping.tickLength);
/* 41 */       tickLength.setAccessible(true);
/* 42 */       tickLength.setFloat(timer.get(Minecraft.getMinecraft()), 50.0F / speed);
/*    */     }
/* 44 */     catch (Exception e) {
/* 45 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   private static float getMultiplier() {
/* 49 */     float multiplier = 1.0F;
/* 50 */     for (Iterator<Float> iterator = multipliers.values().iterator(); iterator.hasNext(); ) { float f = ((Float)iterator.next()).floatValue(); multiplier *= f; }
/* 51 */      return multiplier;
/*    */   }
/*    */   
/*    */   public static int push(float multiplier) {
/* 55 */     multipliers.put(Integer.valueOf(++counter), Float.valueOf(multiplier));
/* 56 */     setSpeed(getMultiplier());
/* 57 */     return counter;
/*    */   }
/*    */   
/*    */   public static void pop(int counter) {
/* 61 */     multipliers.remove(Integer.valueOf(counter));
/* 62 */     setSpeed(getMultiplier());
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\TimerUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
