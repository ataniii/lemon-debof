//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import com.lemonclient.api.util.misc.Wrapper;
/*     */ import com.lemonclient.api.util.world.combat.CrystalUtil;
/*     */ import com.lemonclient.client.module.modules.gui.ColorMain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class BlockUtil {
/*  32 */   public static final List shulkerList = Arrays.asList(new Block[] { Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.SILVER_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX });
/*  33 */   public static final List blackList = Arrays.asList(new Object[] { Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.ANVIL, Blocks.WOODEN_BUTTON, Blocks.STONE_BUTTON, Blocks.UNPOWERED_COMPARATOR, Blocks.UNPOWERED_REPEATER, Blocks.POWERED_REPEATER, Blocks.POWERED_COMPARATOR, Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.JUNGLE_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE, Blocks.ACACIA_FENCE_GATE, Blocks.BREWING_STAND, Blocks.DISPENSER, Blocks.DROPPER, Blocks.LEVER, Blocks.NOTEBLOCK, Blocks.JUKEBOX, Blocks.BEACON, Blocks.BED, Blocks.FURNACE, Blocks.OAK_DOOR, Blocks.SPRUCE_DOOR, Blocks.BIRCH_DOOR, Blocks.JUNGLE_DOOR, Blocks.ACACIA_DOOR, Blocks.DARK_OAK_DOOR, Blocks.CAKE, Blocks.ENCHANTING_TABLE, Blocks.DRAGON_EGG, Blocks.HOPPER, Blocks.REPEATING_COMMAND_BLOCK, Blocks.COMMAND_BLOCK, Blocks.CHAIN_COMMAND_BLOCK, Blocks.CRAFTING_TABLE, Blocks.WALL_SIGN, Blocks.STANDING_SIGN, shulkerList });
/*  34 */   public static final List unSolidBlocks = Arrays.asList(new Object[] { Blocks.SNOW, Blocks.CARPET, Blocks.END_ROD, Blocks.SKULL, Blocks.FLOWER_POT, Blocks.TRIPWIRE, Blocks.TRIPWIRE_HOOK, Blocks.LADDER, Blocks.UNLIT_REDSTONE_TORCH, Blocks.REDSTONE_WIRE, Blocks.AIR, Blocks.PORTAL, Blocks.END_PORTAL, Blocks.WATER, Blocks.FLOWING_WATER, Blocks.LAVA, Blocks.FLOWING_LAVA, Blocks.SAPLING, Blocks.RED_FLOWER, Blocks.YELLOW_FLOWER, Blocks.BROWN_MUSHROOM, Blocks.RED_MUSHROOM, Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES, Blocks.BEETROOTS, Blocks.REEDS, Blocks.PUMPKIN_STEM, Blocks.MELON_STEM, Blocks.WATERLILY, Blocks.NETHER_WART, Blocks.COCOA, Blocks.CHORUS_FLOWER, Blocks.CHORUS_PLANT, Blocks.TALLGRASS, Blocks.DEADBUSH, Blocks.VINE, Blocks.FIRE, Blocks.RAIL, Blocks.ACTIVATOR_RAIL, Blocks.DETECTOR_RAIL, Blocks.GOLDEN_RAIL, Blocks.TORCH, Blocks.REDSTONE_TORCH, Blocks.WEB, Blocks.PISTON_HEAD, Blocks.PISTON_EXTENSION, Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.ANVIL, Blocks.WOODEN_BUTTON, Blocks.STONE_BUTTON, Blocks.UNPOWERED_COMPARATOR, Blocks.UNPOWERED_REPEATER, Blocks.POWERED_REPEATER, Blocks.POWERED_COMPARATOR, Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.JUNGLE_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE, Blocks.ACACIA_FENCE_GATE, Blocks.BREWING_STAND, Blocks.DISPENSER, Blocks.DROPPER, Blocks.LEVER, Blocks.NOTEBLOCK, Blocks.JUKEBOX, Blocks.BEACON, Blocks.BED, Blocks.FURNACE, Blocks.OAK_DOOR, Blocks.SPRUCE_DOOR, Blocks.BIRCH_DOOR, Blocks.JUNGLE_DOOR, Blocks.ACACIA_DOOR, Blocks.DARK_OAK_DOOR, Blocks.CAKE, Blocks.ENCHANTING_TABLE, Blocks.DRAGON_EGG, shulkerList });
/*     */   
/*  36 */   public static final List airBlocks = Arrays.asList(new Block[] { Blocks.AIR, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.WATER, (Block)Blocks.FLOWING_WATER, (Block)Blocks.FIRE, Blocks.VINE, Blocks.SNOW_LAYER, (Block)Blocks.TALLGRASS });
/*  37 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
/*  41 */     Vec3d[] output = new Vec3d[input.length];
/*  42 */     for (int i = 0; i < input.length; i++) {
/*  43 */       output[i] = vec3d.add(input[i]);
/*     */     }
/*  45 */     return output;
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(EntityPlayer entity, Vec3d[] input) {
/*  49 */     return convertVec3ds(entity.getPositionVector(), input);
/*     */   }
/*     */ 
/*     */   
/*     */   public static NonNullList<BlockPos> getBox(float range) {
/*  54 */     NonNullList<BlockPos> positions = NonNullList.create();
/*  55 */     positions.addAll(EntityUtil.getSphere(new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ)), Double.valueOf(range), Double.valueOf(0.0D), false, true, 0));
/*  56 */     return positions;
/*     */   }
/*     */   
/*     */   public static NonNullList<BlockPos> getBox(float range, BlockPos pos) {
/*  60 */     NonNullList<BlockPos> positions = NonNullList.create();
/*  61 */     positions.addAll(EntityUtil.getSphere(pos, Double.valueOf(range), Double.valueOf(0.0D), false, true, 0));
/*  62 */     return positions;
/*     */   }
/*     */   public static boolean isBlockUnSolid(BlockPos blockPos) {
/*  65 */     Block block = getBlock(blockPos);
/*  66 */     return (isBlockUnSolid(block) || !block.fullBlock);
/*     */   }
/*     */   
/*     */   public static boolean canOpen(BlockPos blockPos) {
/*  70 */     return canOpen(mc.world.getBlockState(blockPos).getBlock());
/*     */   }
/*     */   public static boolean isAir(BlockPos blockPos) {
/*  73 */     return isAir(mc.world.getBlockState(blockPos).getBlock());
/*     */   }
/*     */   
/*     */   public static boolean isAirBlock(BlockPos blockPos) {
/*  77 */     return isAirBlock(mc.world.getBlockState(blockPos).getBlock());
/*     */   }
/*     */   
/*     */   public static boolean raytraceCheck(BlockPos pos, float height) {
/*  81 */     return (mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX(), (pos.getY() + height), pos.getZ()), false, true, false) == null);
/*     */   }
/*     */   public static boolean canBePlace(BlockPos pos) {
/*  84 */     return (!checkPlayer(pos) && canReplace(pos));
/*     */   }
/*     */   
/*     */   public static boolean canBePlace(BlockPos pos, double distance) {
/*  88 */     if (mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > distance) {
/*  89 */       return false;
/*     */     }
/*  91 */     return (!checkPlayer(pos) && canReplace(pos));
/*     */   }
/*     */   public static boolean checkPlayer(BlockPos pos) {
/*  94 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/*  95 */       if (entity.isDead || entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb || entity instanceof net.minecraft.entity.item.EntityExpBottle || entity instanceof net.minecraft.entity.projectile.EntityArrow || entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/*  96 */         continue;  return true;
/*     */     } 
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public static EnumFacing getBestNeighboring(BlockPos pos, EnumFacing facing) {
/* 102 */     for (EnumFacing i : EnumFacing.VALUES) {
/* 103 */       if ((facing == null || !pos.offset(i).equals(pos.offset(facing, -1))) && i != EnumFacing.DOWN)
/* 104 */         for (EnumFacing side : getPlacableFacings(pos.offset(i), true, true)) {
/* 105 */           if (!canClick(pos.offset(i).offset(side)))
/* 106 */             continue;  return i;
/*     */         }  
/*     */     } 
/* 109 */     EnumFacing bestFacing = null;
/* 110 */     double distance = 0.0D;
/* 111 */     for (EnumFacing i : EnumFacing.VALUES) {
/* 112 */       if ((facing == null || !pos.offset(i).equals(pos.offset(facing, -1))) && i != EnumFacing.DOWN)
/* 113 */         for (EnumFacing side : getPlacableFacings(pos.offset(i), true, false)) {
/* 114 */           if (!canClick(pos.offset(i).offset(side)) || (bestFacing != null && mc.player.getDistanceSq(pos.offset(i)) >= distance))
/* 115 */             continue;  bestFacing = i;
/* 116 */           distance = mc.player.getDistanceSq(pos.offset(i));
/*     */         }  
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   public static double distanceToXZ(double x, double z) {
/* 123 */     double dx = mc.player.posX - x;
/* 124 */     double dz = mc.player.posZ - z;
/* 125 */     return Math.sqrt(dx * dx + dz * dz);
/*     */   }
/*     */   public static void placeBlock(BlockPos pos, boolean rotate, boolean packet, boolean strict, boolean raytrace, boolean swing) {
/* 128 */     placeBlock(pos, EnumHand.MAIN_HAND, rotate, packet, strict, raytrace, swing);
/*     */   }
/*     */   
/*     */   public static void placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean attackEntity, boolean strict, boolean raytrace, boolean swing) {
/* 132 */     if (attackEntity) CrystalUtil.breakCrystal(pos, swing); 
/* 133 */     placeBlock(pos, hand, rotate, packet, strict, raytrace, swing);
/*     */   }
/*     */   public static boolean canBlockFacing(BlockPos pos) {
/* 136 */     boolean airCheck = false;
/* 137 */     for (EnumFacing side : EnumFacing.values()) {
/* 138 */       if (canClick(pos.offset(side)))
/* 139 */         airCheck = true; 
/*     */     } 
/* 141 */     return airCheck;
/*     */   }
/*     */   public static boolean strictPlaceCheck(BlockPos pos, boolean strict, boolean raytrace) {
/* 144 */     if (!strict) {
/* 145 */       return true;
/*     */     }
/* 147 */     for (EnumFacing side : getPlacableFacings(pos, true, raytrace)) {
/* 148 */       if (!canClick(pos.offset(side)))
/* 149 */         continue;  return true;
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */   public static boolean canClick(BlockPos pos) {
/* 154 */     return mc.world.getBlockState(pos).getBlock().canCollideCheck(mc.world.getBlockState(pos), false);
/*     */   }
/*     */   
/*     */   public static void placeCrystal(BlockPos pos, boolean rotate) {
/* 158 */     boolean offhand = (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL);
/* 159 */     BlockPos obsPos = pos.down();
/* 160 */     RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX() + 0.5D, pos.getY() - 0.5D, pos.getZ() + 0.5D));
/* 161 */     EnumFacing facing = (result == null || result.sideHit == null) ? EnumFacing.UP : result.sideHit;
/* 162 */     EnumFacing opposite = facing.getOpposite();
/* 163 */     Vec3d vec = (new Vec3d((Vec3i)obsPos)).add(0.5D, 0.5D, 0.5D).add(new Vec3d(opposite.getDirectionVec()));
/* 164 */     if (rotate) {
/* 165 */       EntityUtil.faceVector(vec);
/*     */     }
/* 167 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(obsPos, facing, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/* 168 */     mc.player.swingArm(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/*     */   }
/*     */   public static boolean canPlaceCrystal(BlockPos pos, double distance) {
/* 171 */     if (mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > distance) {
/* 172 */       return false;
/*     */     }
/* 174 */     BlockPos obsPos = pos.down();
/* 175 */     BlockPos boost = obsPos.up();
/* 176 */     BlockPos boost2 = obsPos.up(2);
/* 177 */     return ((getBlock(obsPos) == Blocks.BEDROCK || getBlock(obsPos) == Blocks.OBSIDIAN) && getBlock(boost) == Blocks.AIR && getBlock(boost2) == Blocks.AIR && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/*     */   }
/*     */   public static boolean canPlaceCrystal(BlockPos pos) {
/* 180 */     BlockPos obsPos = pos.down();
/* 181 */     BlockPos boost = obsPos.up();
/* 182 */     BlockPos boost2 = obsPos.up(2);
/* 183 */     return ((getBlock(obsPos) == Blocks.BEDROCK || getBlock(obsPos) == Blocks.OBSIDIAN) && getBlock(boost) == Blocks.AIR && getBlock(boost2) == Blocks.AIR && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/*     */   }
/*     */   public static List<EnumFacing> getPlacableFacings(BlockPos pos, boolean strictDirection, boolean rayTrace) {
/* 186 */     ArrayList<EnumFacing> validFacings = new ArrayList<>();
/* 187 */     for (EnumFacing side : EnumFacing.values()) {
/* 188 */       if (!getRaytrace(pos, side))
/* 189 */         getPlaceFacing(pos, strictDirection, validFacings, side); 
/*     */     } 
/* 191 */     for (EnumFacing side : EnumFacing.values()) {
/* 192 */       if (!rayTrace || !getRaytrace(pos, side))
/* 193 */         getPlaceFacing(pos, strictDirection, validFacings, side); 
/*     */     } 
/* 195 */     return validFacings;
/*     */   }
/*     */   public static List<EnumFacing> getTrapPlacableFacings(BlockPos pos, boolean strictDirection, boolean rayTrace) {
/* 198 */     ArrayList<EnumFacing> validFacings = new ArrayList<>();
/* 199 */     for (EnumFacing side : facing) {
/* 200 */       if (!getRaytrace(pos, side))
/* 201 */         getPlaceFacing(pos, strictDirection, validFacings, side); 
/*     */     } 
/* 203 */     for (EnumFacing side : facing) {
/* 204 */       if (!rayTrace || !getRaytrace(pos, side))
/* 205 */         getPlaceFacing(pos, strictDirection, validFacings, side); 
/*     */     } 
/* 207 */     return validFacings;
/*     */   }
/*     */   
/*     */   private static boolean getRaytrace(BlockPos pos, EnumFacing side) {
/* 211 */     Vec3d testVec = (new Vec3d((Vec3i)pos)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(side.getDirectionVec())).scale(0.5D));
/* 212 */     RayTraceResult result = mc.world.rayTraceBlocks(mc.player.getPositionEyes(1.0F), testVec);
/* 213 */     return (result != null && result.typeOfHit != RayTraceResult.Type.MISS);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void getPlaceFacing(BlockPos pos, boolean strictDirection, ArrayList<EnumFacing> validFacings, EnumFacing side) {
/* 218 */     BlockPos neighbour = pos.offset(side);
/* 219 */     if (strictDirection) {
/* 220 */       Vec3d eyePos = mc.player.getPositionEyes(1.0F);
/* 221 */       Vec3d blockCenter = new Vec3d(neighbour.getX() + 0.5D, neighbour.getY() + 0.5D, neighbour.getZ() + 0.5D);
/* 222 */       IBlockState blockState2 = mc.world.getBlockState(neighbour);
/* 223 */       boolean isFullBox = (blockState2.getBlock() == Blocks.AIR || blockState2.isFullBlock());
/* 224 */       ArrayList<EnumFacing> validAxis = new ArrayList<>();
/* 225 */       validAxis.addAll(checkAxis(eyePos.x - blockCenter.x, EnumFacing.WEST, EnumFacing.EAST, !isFullBox));
/* 226 */       validAxis.addAll(checkAxis(eyePos.y - blockCenter.y, EnumFacing.DOWN, EnumFacing.UP, true));
/* 227 */       validAxis.addAll(checkAxis(eyePos.z - blockCenter.z, EnumFacing.NORTH, EnumFacing.SOUTH, !isFullBox));
/* 228 */       if (!validAxis.contains(side.getOpposite()))
/*     */         return; 
/*     */     } 
/*     */     IBlockState blockState;
/* 232 */     if (!(blockState = mc.world.getBlockState(neighbour)).getBlock().canCollideCheck(blockState, false) || blockState.getMaterial().isReplaceable()) {
/*     */       return;
/*     */     }
/* 235 */     validFacings.add(side);
/*     */   }
/*     */   
/*     */   public static ArrayList<EnumFacing> checkAxis(double diff, EnumFacing negativeSide, EnumFacing positiveSide, boolean bothIfInRange) {
/* 239 */     ArrayList<EnumFacing> valid = new ArrayList<>();
/* 240 */     if (diff < -0.5D) {
/* 241 */       valid.add(negativeSide);
/*     */     }
/* 243 */     if (diff > 0.5D) {
/* 244 */       valid.add(positiveSide);
/*     */     }
/* 246 */     if (bothIfInRange) {
/* 247 */       if (!valid.contains(negativeSide)) {
/* 248 */         valid.add(negativeSide);
/*     */       }
/* 250 */       if (!valid.contains(positiveSide)) {
/* 251 */         valid.add(positiveSide);
/*     */       }
/*     */     } 
/* 254 */     return valid;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceEnum(BlockPos pos, boolean strict, boolean raytrace) {
/* 258 */     if (!canBlockFacing(pos)) {
/* 259 */       return false;
/*     */     }
/* 261 */     return strictPlaceCheck(pos, strict, raytrace);
/*     */   }
/*     */   public static boolean checkEntity(BlockPos pos) {
/* 264 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 265 */       if (entity.isDead || entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb || entity instanceof net.minecraft.entity.item.EntityExpBottle || entity instanceof net.minecraft.entity.projectile.EntityArrow)
/* 266 */         continue;  return true;
/*     */     } 
/* 268 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean canPlace(BlockPos pos, double distance, boolean strict, boolean raytrace) {
/* 272 */     if (mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > distance) {
/* 273 */       return false;
/*     */     }
/* 275 */     if (!canBlockFacing(pos)) {
/* 276 */       return false;
/*     */     }
/* 278 */     if (!canReplace(pos)) {
/* 279 */       return false;
/*     */     }
/* 281 */     if (!strictPlaceCheck(pos, strict, raytrace)) {
/* 282 */       return false;
/*     */     }
/* 284 */     return !checkEntity(pos);
/*     */   }
/*     */   
/*     */   public static boolean canPlace(BlockPos pos, boolean strict, boolean raytrace) {
/* 288 */     if (mc.player.getDistance(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 6.0D) {
/* 289 */       return false;
/*     */     }
/* 291 */     if (!canBlockFacing(pos)) {
/* 292 */       return false;
/*     */     }
/* 294 */     if (!canReplace(pos)) {
/* 295 */       return false;
/*     */     }
/* 297 */     if (!strictPlaceCheck(pos, strict, raytrace)) {
/* 298 */       return false;
/*     */     }
/* 300 */     return !checkEntity(pos);
/*     */   }
/*     */   
/*     */   public static boolean canPlaceWithoutBase(BlockPos pos, boolean strict, boolean raytrace, boolean base) {
/* 304 */     if (!canBlockFacing(pos) && !base) {
/* 305 */       return false;
/*     */     }
/* 307 */     if (!canReplace(pos)) {
/* 308 */       return false;
/*     */     }
/* 310 */     if (!strictPlaceCheck(pos, strict, raytrace) && !base) {
/* 311 */       return false;
/*     */     }
/* 313 */     return !checkEntity(pos);
/*     */   }
/*     */   
/*     */   public static void placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean strict, boolean raytrace, boolean swing) {
/* 317 */     EnumFacing side = getFirstFacing(pos, strict, raytrace);
/* 318 */     if (side == null) {
/*     */       return;
/*     */     }
/* 321 */     BlockPos neighbour = pos.offset(side);
/* 322 */     EnumFacing opposite = side.getOpposite();
/* 323 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 324 */     boolean sneaking = false;
/* 325 */     if (!ColorMain.INSTANCE.sneaking && blackList.contains(getBlock(neighbour))) {
/* 326 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 327 */       sneaking = true;
/*     */     } 
/* 329 */     if (rotate) {
/* 330 */       faceVector(hitVec);
/*     */     }
/* 332 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet, swing);
/* 333 */     if (sneaking)
/* 334 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/*     */   }
/*     */   
/*     */   public static boolean placeBlockBoolean(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean strict, boolean raytrace, boolean swing) {
/* 338 */     EnumFacing side = getFirstFacing(pos, strict, raytrace);
/* 339 */     if (side == null) return false; 
/* 340 */     BlockPos neighbour = pos.offset(side);
/* 341 */     EnumFacing opposite = side.getOpposite();
/* 342 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/* 343 */     boolean sneaking = false;
/* 344 */     if (!ColorMain.INSTANCE.sneaking && blackList.contains(getBlock(neighbour))) {
/* 345 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/* 346 */       sneaking = true;
/*     */     } 
/* 348 */     if (rotate) faceVector(hitVec); 
/* 349 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet, swing);
/* 350 */     if (sneaking) mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING)); 
/* 351 */     return true;
/*     */   }
/*     */   public static void faceVector(Vec3d vec) {
/* 354 */     float[] rotations = EntityUtil.getLegitRotations(vec);
/* 355 */     EntityUtil.sendPlayerRot(rotations[0], rotations[1], mc.player.onGround);
/*     */   }
/*     */   public static boolean posHasCrystal(BlockPos pos) {
/* 358 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 359 */       if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal) || !(new BlockPos(entity.posX, entity.posY, entity.posZ)).equals(pos))
/* 360 */         continue;  return true;
/*     */     } 
/* 362 */     return false;
/*     */   }
/*     */   public static boolean canReplace(BlockPos pos) {
/* 365 */     if (pos == null) return false; 
/* 366 */     return (getState(pos).getMaterial().isReplaceable() || isAir(pos));
/*     */   }
/*     */   public static boolean canReplace(Vec3d vec3d) {
/* 369 */     if (vec3d == null) return false; 
/* 370 */     BlockPos pos = new BlockPos(vec3d);
/* 371 */     return (getState(pos).getMaterial().isReplaceable() || isAir(pos));
/*     */   }
/*     */   public static boolean isBlockUnSolid(Block block) {
/* 374 */     return unSolidBlocks.contains(block);
/*     */   }
/*     */   
/*     */   public static boolean canOpen(Block block) {
/* 378 */     return blackList.contains(block);
/*     */   }
/*     */   public static boolean isAir(Block block) {
/* 381 */     return airBlocks.contains(block);
/*     */   }
/*     */   public static boolean isAirBlock(Block block) {
/* 384 */     return (block == Blocks.AIR);
/*     */   }
/*     */   public static double blockDistance2d(double blockposx, double blockposz, Entity owo) {
/* 387 */     double deltaX = owo.posX - blockposx;
/* 388 */     double deltaZ = owo.posZ - blockposz;
/* 389 */     return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
/*     */   }
/*     */   public static EnumFacing getRayTraceFacing(BlockPos pos) {
/* 392 */     RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX() + 0.5D, pos.getY() - 0.5D, pos.getZ() + 0.5D));
/* 393 */     if (result == null || result.sideHit == null) {
/* 394 */       return EnumFacing.UP;
/*     */     }
/* 396 */     return result.sideHit;
/*     */   }
/*     */   
/*     */   public static EnumFacing getRayTraceFacing(BlockPos pos, EnumFacing facing) {
/* 400 */     RayTraceResult result = mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX() + 0.5D, pos.getY() - 0.5D, pos.getZ() + 0.5D));
/* 401 */     if (result == null || result.sideHit == null) {
/* 402 */       return facing;
/*     */     }
/* 404 */     return result.sideHit;
/*     */   }
/*     */   public static IBlockState getState(BlockPos pos) {
/* 407 */     return mc.world.getBlockState(pos);
/*     */   }
/*     */   public static float[] calcAngle(Vec3d from, Vec3d to) {
/* 410 */     double difX = to.x - from.x;
/* 411 */     double difY = (to.y - from.y) * -1.0D;
/* 412 */     double difZ = to.z - from.z;
/* 413 */     double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
/* 414 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */   
/*     */   public static CPacketPlayer.Rotation getFaceVectorPacket(Vec3d vec, Boolean roundAngles) {
/* 418 */     float[] rotations = getNeededRotations2(vec);
/*     */     
/* 420 */     CPacketPlayer.Rotation e = new CPacketPlayer.Rotation(rotations[0], roundAngles.booleanValue() ? MathHelper.normalizeAngle((int)rotations[1], 360) : rotations[1], mc.player.onGround);
/*     */     
/* 422 */     mc.player.connection.sendPacket((Packet)e);
/*     */     
/* 424 */     return e;
/*     */   }
/*     */   public static float[] calcAngleNoY(Vec3d from, Vec3d to) {
/* 427 */     double difX = to.x - from.x;
/* 428 */     double difZ = to.z - from.z;
/* 429 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D) };
/*     */   }
/*     */   
/*     */   public static BlockPos[] toBlockPos(Vec3d[] vec3ds) {
/* 433 */     BlockPos[] list = new BlockPos[vec3ds.length];
/* 434 */     for (int i = 0; i < vec3ds.length; i++) {
/* 435 */       list[i] = new BlockPos(vec3ds[i]);
/*     */     }
/* 437 */     return list;
/*     */   }
/*     */   
/*     */   public static boolean hasNeighbour(BlockPos blockPos) {
/* 441 */     boolean canPlace = false;
/* 442 */     for (EnumFacing side : EnumFacing.values()) {
/* 443 */       BlockPos neighbour = blockPos.offset(side);
/* 444 */       if (mc.world.getBlockState(neighbour).getMaterial().isReplaceable())
/* 445 */         canPlace = true; 
/*     */     } 
/* 447 */     return canPlace;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canPlaceBlock(BlockPos pos) {
/* 453 */     return ((getBlock(pos) == Blocks.AIR || 
/* 454 */       getBlock(pos) instanceof net.minecraft.block.BlockLiquid) && 
/* 455 */       hasNeighbour(pos) && 
/* 456 */       !blackList.contains(getBlock(pos)));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canPlaceBlockFuture(BlockPos pos) {
/* 461 */     return ((getBlock(pos) == Blocks.AIR || 
/* 462 */       getBlock(pos) instanceof net.minecraft.block.BlockLiquid) && 
/* 463 */       !blackList.contains(getBlock(pos)));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, EnumFacing facing, boolean packet) {
/* 468 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(facing.getDirectionVec())).scale(0.5D));
/*     */     
/* 470 */     if (packet) {
/*     */       
/* 472 */       rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, facing);
/*     */     } else {
/*     */       
/* 475 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, hitVec, EnumHand.MAIN_HAND);
/* 476 */       mc.player.swingArm(EnumHand.MAIN_HAND);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, EnumFacing facing, Vec3d hVec, boolean packet) {
/* 482 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(hVec).add((new Vec3d(facing.getDirectionVec())).scale(0.5D));
/*     */     
/* 484 */     if (packet) {
/*     */       
/* 486 */       rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, facing);
/*     */     } else {
/*     */       
/* 489 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, facing, hitVec, EnumHand.MAIN_HAND);
/* 490 */       mc.player.swingArm(EnumHand.MAIN_HAND);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction) {
/* 495 */     float f = (float)(vec.x - pos.getX());
/* 496 */     float f1 = (float)(vec.y - pos.getY());
/* 497 */     float f2 = (float)(vec.z - pos.getZ());
/* 498 */     mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     
/* 500 */     mc.rightClickDelayTimer = 4;
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet, boolean swing) {
/* 504 */     if (packet) {
/* 505 */       float f = (float)(vec.x - pos.getX());
/* 506 */       float f1 = (float)(vec.y - pos.getY());
/* 507 */       float f2 = (float)(vec.z - pos.getZ());
/* 508 */       mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     } else {
/* 510 */       mc.playerController.processRightClickBlock(mc.player, mc.world, pos, direction, vec, hand);
/*     */     } 
/* 512 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/* 513 */     mc.rightClickDelayTimer = 4;
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace) {
/* 517 */     return isPositionPlaceable(pos, rayTrace, true);
/*     */   }
/*     */   public static EnumFacing getFirstFacing(BlockPos pos, boolean strict, boolean raytrace) {
/* 520 */     if (!strict) {
/* 521 */       Iterator<EnumFacing> iterator = getPossibleSides(pos).iterator();
/* 522 */       if (iterator.hasNext()) {
/* 523 */         return iterator.next();
/*     */       }
/*     */     } else {
/* 526 */       for (EnumFacing side : getPlacableFacings(pos, true, raytrace)) {
/* 527 */         if (!canClick(pos.offset(side)))
/* 528 */           continue;  return side;
/*     */       } 
/*     */     } 
/* 531 */     return null;
/*     */   }
/*     */   public static EnumFacing getTrapFirstFacing(BlockPos pos, boolean strict, boolean raytrace) {
/* 534 */     if (!strict) {
/* 535 */       Iterator<EnumFacing> iterator = getTrapPossibleSides(pos).iterator();
/* 536 */       if (iterator.hasNext()) {
/* 537 */         return iterator.next();
/*     */       }
/*     */     } else {
/* 540 */       for (EnumFacing side : getTrapPlacableFacings(pos, true, raytrace)) {
/* 541 */         if (!canClick(pos.offset(side)))
/* 542 */           continue;  return side;
/*     */       } 
/*     */     } 
/* 545 */     return null;
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace, boolean entityCheck) {
/* 549 */     Block block = mc.world.getBlockState(pos).getBlock();
/* 550 */     if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid) && !(block instanceof net.minecraft.block.BlockTallGrass) && !(block instanceof net.minecraft.block.BlockFire) && !(block instanceof net.minecraft.block.BlockDeadBush) && !(block instanceof net.minecraft.block.BlockSnow)) {
/* 551 */       return 0;
/*     */     }
/* 553 */     if (!rayTracePlaceCheck(pos, rayTrace, 0.0F)) {
/* 554 */       return -1;
/*     */     }
/* 556 */     if (entityCheck) {
/* 557 */       for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 558 */         if (entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb)
/* 559 */           continue;  return 1;
/*     */       } 
/*     */     }
/* 562 */     for (EnumFacing side : getPossibleSides(pos)) {
/* 563 */       if (!canBeClicked(pos.offset(side)))
/* 564 */         continue;  return 3;
/*     */     } 
/* 566 */     return 2;
/*     */   }
/* 568 */   static EnumFacing[] facing = new EnumFacing[] { EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.WEST, EnumFacing.EAST };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/* 575 */     List<EnumFacing> facings = new ArrayList<>();
/* 576 */     if (mc.world == null || pos == null) {
/* 577 */       return facings;
/*     */     }
/* 579 */     for (EnumFacing side : EnumFacing.VALUES) {
/* 580 */       BlockPos neighbour = pos.offset(side);
/* 581 */       IBlockState blockState = mc.world.getBlockState(neighbour);
/* 582 */       if (blockState.getBlock().canCollideCheck(blockState, false) && !blockState.getMaterial().isReplaceable() && canBeClicked(neighbour))
/*     */       {
/* 584 */         facings.add(side); } 
/*     */     } 
/* 586 */     return facings;
/*     */   }
/*     */   public static List<EnumFacing> getTrapPossibleSides(BlockPos pos) {
/* 589 */     List<EnumFacing> facings = new ArrayList<>();
/* 590 */     if (mc.world == null || pos == null) {
/* 591 */       return facings;
/*     */     }
/* 593 */     for (EnumFacing side : facing) {
/* 594 */       BlockPos neighbour = pos.offset(side);
/* 595 */       IBlockState blockState = mc.world.getBlockState(neighbour);
/* 596 */       if (blockState != null && blockState.getBlock().canCollideCheck(blockState, false) && !blockState.getMaterial().isReplaceable())
/*     */       {
/* 598 */         facings.add(side); } 
/*     */     } 
/* 600 */     return facings;
/*     */   }
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck, float height) {
/* 603 */     return (!shouldCheck || mc.world.rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ), new Vec3d(pos.getX(), (pos.getY() + height), pos.getZ()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck) {
/* 607 */     return rayTracePlaceCheck(pos, shouldCheck, 1.0F);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos) {
/* 611 */     return rayTracePlaceCheck(pos, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Block getBlock(BlockPos pos) {
/* 616 */     return getState(pos).getBlock();
/*     */   }
/*     */   
/*     */   public static Block getBlock(double x, double y, double z) {
/* 620 */     return mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/* 624 */     return getBlock(pos).canCollideCheck(getState(pos), false);
/*     */   }
/*     */   public static boolean canBeClicked(Vec3d vec3d) {
/* 627 */     return getBlock(new BlockPos(vec3d)).canCollideCheck(getState(new BlockPos(vec3d)), false);
/*     */   }
/*     */   
/*     */   public static void faceVectorPacketInstant(Vec3d vec, Boolean roundAngles) {
/* 631 */     float[] rotations = getNeededRotations2(vec);
/*     */     
/* 633 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotations[0], roundAngles.booleanValue() ? MathHelper.normalizeAngle((int)rotations[1], 360) : rotations[1], mc.player.onGround));
/*     */   }
/*     */   
/*     */   public static void faceVectorPacketInstant2(Vec3d vec) {
/* 637 */     float[] rotations = getLegitRotations(vec);
/* 638 */     (Wrapper.getPlayer()).connection.sendPacket((Packet)new CPacketPlayer.Rotation(rotations[0], rotations[1], (Wrapper.getPlayer()).onGround));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float[] getLegitRotations(Vec3d vec) {
/* 643 */     Vec3d eyesPos = getEyesPos();
/* 644 */     double diffX = vec.x - eyesPos.x;
/* 645 */     double diffY = vec.y - eyesPos.y;
/* 646 */     double diffZ = vec.z - eyesPos.z;
/* 647 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/* 648 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 649 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/* 650 */     return new float[] { (Wrapper.getPlayer()).rotationYaw + MathHelper.wrapDegrees(yaw - (Wrapper.getPlayer()).rotationYaw), (Wrapper.getPlayer()).rotationPitch + MathHelper.wrapDegrees(pitch - (Wrapper.getPlayer()).rotationPitch) };
/*     */   }
/*     */   
/*     */   private static float[] getNeededRotations2(Vec3d vec) {
/* 654 */     Vec3d eyesPos = getEyesPos();
/*     */     
/* 656 */     double diffX = vec.x - eyesPos.x;
/* 657 */     double diffY = vec.y - eyesPos.y;
/* 658 */     double diffZ = vec.z - eyesPos.z;
/*     */     
/* 660 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*     */     
/* 662 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 663 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*     */     
/* 665 */     return new float[] { mc.player.rotationYaw + 
/* 666 */         MathHelper.wrapDegrees(yaw - mc.player.rotationYaw), mc.player.rotationPitch + 
/* 667 */         MathHelper.wrapDegrees(pitch - mc.player.rotationPitch) };
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d getEyesPos() {
/* 672 */     return new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/*     */   }
/*     */   
/*     */   public static double blockDistance(double blockposx, double blockposy, double blockposz, Entity owo) {
/* 676 */     double deltaX = owo.posX - blockposx;
/* 677 */     double deltaY = owo.posY - blockposy;
/* 678 */     double deltaZ = owo.posZ - blockposz;
/* 679 */     return Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getCircle(BlockPos loc, int y, float r, boolean hollow) {
/* 683 */     List<BlockPos> circleblocks = new ArrayList<>();
/* 684 */     int cx = loc.getX();
/* 685 */     int cz = loc.getZ();
/* 686 */     for (int x = cx - (int)r; x <= cx + r; x++) {
/* 687 */       for (int z = cz - (int)r; z <= cz + r; z++) {
/* 688 */         double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z));
/* 689 */         if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 690 */           BlockPos l = new BlockPos(x, y, z);
/* 691 */           circleblocks.add(l);
/*     */         } 
/*     */       } 
/*     */     } 
/* 695 */     return circleblocks;
/*     */   }
/*     */ 
/*     */   
/*     */   public static EnumFacing getPlaceableSide(BlockPos pos) {
/* 700 */     for (EnumFacing side : EnumFacing.values()) {
/*     */       
/* 702 */       BlockPos neighbour = pos.offset(side);
/*     */       
/* 704 */       if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/*     */ 
/*     */ 
/*     */         
/* 708 */         IBlockState blockState = mc.world.getBlockState(neighbour);
/* 709 */         if (!blockState.getMaterial().isReplaceable()) {
/* 710 */           return side;
/*     */         }
/*     */       } 
/*     */     } 
/* 714 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static EnumFacing getPlaceableSideExlude(BlockPos pos, ArrayList<EnumFacing> excluding) {
/* 719 */     for (EnumFacing side : EnumFacing.values()) {
/*     */       
/* 721 */       if (!excluding.contains(side)) {
/*     */         
/* 723 */         BlockPos neighbour = pos.offset(side);
/*     */         
/* 725 */         if (mc.world.getBlockState(neighbour).getBlock().canCollideCheck(mc.world.getBlockState(neighbour), false)) {
/*     */ 
/*     */ 
/*     */           
/* 729 */           IBlockState blockState = mc.world.getBlockState(neighbour);
/* 730 */           if (!blockState.getMaterial().isReplaceable()) {
/* 731 */             return side;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 736 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d getCenterOfBlock(double playerX, double playerY, double playerZ) {
/* 741 */     double newX = Math.floor(playerX) + 0.5D;
/* 742 */     double newY = Math.floor(playerY);
/* 743 */     double newZ = Math.floor(playerZ) + 0.5D;
/*     */     
/* 745 */     return new Vec3d(newX, newY, newZ);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\BlockUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
