//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class ItemUtil {
/*  11 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static boolean isArmorUnderPercent(EntityPlayer player, float percent) {
/*  14 */     for (int i = 3; i >= 0; i--) {
/*  15 */       ItemStack stack = (ItemStack)player.inventory.armorInventory.get(i);
/*  16 */       if (getDamageInPercent(stack) < percent) {
/*  17 */         return true;
/*     */       }
/*     */     } 
/*  20 */     return false;
/*     */   }
/*     */   
/*     */   public static int getItemFromHotbar(Class<?> clazz) {
/*  24 */     int slot = -1;
/*     */     
/*  26 */     for (int i = 8; i >= 0; i--) {
/*  27 */       if (mc.player.inventory.getStackInSlot(i).getItem().getClass() == clazz) {
/*  28 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  33 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getItemFromHotbar(Item item) {
/*  37 */     int slot = -1;
/*     */     
/*  39 */     for (int i = 8; i >= 0; i--) {
/*  40 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/*  41 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  46 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getBlockFromHotbar(Block block) {
/*  50 */     int slot = -1;
/*     */     
/*  52 */     for (int i = 8; i >= 0; i--) {
/*  53 */       if (mc.player.inventory.getStackInSlot(i).getItem() == Item.getItemFromBlock(block)) {
/*  54 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  59 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getItemSlot(Item item) {
/*  63 */     int slot = -1;
/*     */     
/*  65 */     for (int i = 44; i >= 0; i--) {
/*  66 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/*  67 */         if (i < 9) {
/*  68 */           i += 36;
/*     */         }
/*  70 */         slot = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  75 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getItemCount(Item item) {
/*  79 */     int count = 0;
/*     */     
/*  81 */     for (int i = 44; i >= 0; i--) {
/*  82 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*  83 */       if (stack.getItem() == item) {
/*  84 */         count += stack.getCount();
/*     */       }
/*     */     } 
/*     */     
/*  88 */     if (mc.player.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND).getItem() == item) {
/*  89 */       count += mc.player.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND).getCount();
/*     */     }
/*     */     
/*  92 */     return count;
/*     */   }
/*     */   
/*     */   public static int getRoundedDamage(ItemStack stack) {
/*  96 */     return (int)getDamageInPercent(stack);
/*     */   }
/*     */   
/*     */   public static boolean hasDurability(ItemStack stack) {
/* 100 */     Item item = stack.getItem();
/* 101 */     return (item instanceof net.minecraft.item.ItemArmor || item instanceof net.minecraft.item.ItemSword || item instanceof net.minecraft.item.ItemTool || item instanceof net.minecraft.item.ItemShield);
/*     */   }
/*     */   
/*     */   public static float getDamageInPercent(ItemStack stack) {
/* 105 */     float green = (stack.getMaxDamage() - stack.getItemDamage()) / stack.getMaxDamage();
/* 106 */     float red = 1.0F - green;
/* 107 */     return (100 - (int)(red * 100.0F));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\ItemUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
