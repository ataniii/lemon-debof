//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.world;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ 
/*    */ public class MotionUtil
/*    */ {
/*    */   public static boolean isMoving(EntityLivingBase entity) {
/* 13 */     return (entity.moveForward != 0.0F || entity.moveStrafing != 0.0F || entity.moveVertical != 0.0F || entity.motionY > -0.078D);
/*    */   }
/*    */   
/*    */   public static boolean moving(EntityLivingBase entity) {
/* 17 */     return (entity.moveForward != 0.0F || entity.moveStrafing != 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public static double getMotion(EntityPlayer entity) {
/* 22 */     return Math.abs(entity.motionX) + Math.abs(entity.motionZ);
/*    */   }
/*    */   
/*    */   public static void setSpeed(EntityLivingBase entity, double speed) {
/* 26 */     double[] dir = forward(speed);
/* 27 */     entity.motionX = dir[0];
/* 28 */     entity.motionZ = dir[1];
/*    */   }
/*    */   
/*    */   public static double getBaseMoveSpeed() {
/* 32 */     double result = 0.2873D;
/* 33 */     if ((Minecraft.getMinecraft()).player.isPotionActive(MobEffects.SPEED))
/* 34 */       result += 0.2873D * (((PotionEffect)Objects.<PotionEffect>requireNonNull((Minecraft.getMinecraft()).player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier() + 1) * 0.2D; 
/* 35 */     if ((Minecraft.getMinecraft()).player.isPotionActive(MobEffects.SLOWNESS)) {
/* 36 */       result -= 0.2873D * (((PotionEffect)Objects.<PotionEffect>requireNonNull((Minecraft.getMinecraft()).player.getActivePotionEffect(MobEffects.SLOWNESS))).getAmplifier() + 1) * 0.15D;
/*    */     }
/* 38 */     return result;
/*    */   }
/*    */   public static double[] forward(double speed) {
/* 41 */     float forward = (Minecraft.getMinecraft()).player.movementInput.moveForward;
/* 42 */     float side = (Minecraft.getMinecraft()).player.movementInput.moveStrafe;
/* 43 */     float yaw = (Minecraft.getMinecraft()).player.prevRotationYaw + ((Minecraft.getMinecraft()).player.rotationYaw - (Minecraft.getMinecraft()).player.prevRotationYaw) * Minecraft.getMinecraft().getRenderPartialTicks();
/* 44 */     if (forward != 0.0F) {
/* 45 */       if (side > 0.0F) {
/* 46 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 47 */       } else if (side < 0.0F) {
/* 48 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*    */       } 
/* 50 */       side = 0.0F;
/* 51 */       if (forward > 0.0F) {
/* 52 */         forward = 1.0F;
/* 53 */       } else if (forward < 0.0F) {
/* 54 */         forward = -1.0F;
/*    */       } 
/*    */     } 
/* 57 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 58 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 59 */     double posX = forward * speed * cos + side * speed * sin;
/* 60 */     double posZ = forward * speed * sin - side * speed * cos;
/* 61 */     return new double[] { posX, posZ };
/*    */   }
/*    */   
/*    */   public static double[] forward(double speed, float yaw) {
/* 65 */     float forward = 1.0F;
/* 66 */     float side = 0.0F;
/* 67 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 68 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 69 */     double posX = forward * speed * cos + side * speed * sin;
/* 70 */     double posZ = forward * speed * sin - side * speed * cos;
/* 71 */     return new double[] { posX, posZ };
/*    */   }
/*    */   
/*    */   public static double calcMoveYaw() {
/* 75 */     float yawIn = (Minecraft.getMinecraft()).player.rotationYaw;
/* 76 */     float moveForward = getRoundedMovementInput((Minecraft.getMinecraft()).player.movementInput.moveForward);
/* 77 */     float moveString = getRoundedMovementInput((Minecraft.getMinecraft()).player.movementInput.moveStrafe);
/* 78 */     float strafe = 90.0F * moveString;
/* 79 */     strafe *= (moveForward != 0.0F) ? (moveForward * 0.5F) : 1.0F;
/* 80 */     float yaw = yawIn - strafe;
/* 81 */     yaw -= (moveForward < 0.0F) ? 180.0F : 0.0F;
/* 82 */     return Math.toRadians(yaw);
/*    */   }
/*    */   
/*    */   public static float getRoundedMovementInput(float input) {
/* 86 */     if (input > 0.0F)
/* 87 */       return 1.0F; 
/* 88 */     if (input < 0.0F)
/* 89 */       return -1.0F; 
/* 90 */     return 0.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\MotionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
