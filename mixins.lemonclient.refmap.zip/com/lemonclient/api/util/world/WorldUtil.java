//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class WorldUtil
/*     */ {
/*  23 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   public static List<Block> emptyBlocks = Arrays.asList(new Block[] { Blocks.AIR, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_WATER, (Block)Blocks.WATER, Blocks.VINE, Blocks.SNOW_LAYER, (Block)Blocks.TALLGRASS, (Block)Blocks.FIRE });
/*  30 */   public static List<Block> rightclickableBlocks = Arrays.asList(new Block[] { (Block)Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.SILVER_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX, Blocks.ANVIL, Blocks.WOODEN_BUTTON, Blocks.STONE_BUTTON, (Block)Blocks.UNPOWERED_COMPARATOR, (Block)Blocks.UNPOWERED_REPEATER, (Block)Blocks.POWERED_REPEATER, (Block)Blocks.POWERED_COMPARATOR, Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.JUNGLE_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE, Blocks.ACACIA_FENCE_GATE, Blocks.BREWING_STAND, Blocks.DISPENSER, Blocks.DROPPER, Blocks.LEVER, Blocks.NOTEBLOCK, Blocks.JUKEBOX, (Block)Blocks.BEACON, Blocks.BED, Blocks.FURNACE, (Block)Blocks.OAK_DOOR, (Block)Blocks.SPRUCE_DOOR, (Block)Blocks.BIRCH_DOOR, (Block)Blocks.JUNGLE_DOOR, (Block)Blocks.ACACIA_DOOR, (Block)Blocks.DARK_OAK_DOOR, Blocks.CAKE, Blocks.ENCHANTING_TABLE, Blocks.DRAGON_EGG, (Block)Blocks.HOPPER, Blocks.REPEATING_COMMAND_BLOCK, Blocks.COMMAND_BLOCK, Blocks.CHAIN_COMMAND_BLOCK, Blocks.CRAFTING_TABLE });
/*     */ 
/*     */ 
/*     */   
/*     */   public static void openBlock(BlockPos pos) {
/*  35 */     EnumFacing[] facings = EnumFacing.values();
/*     */     
/*  37 */     for (EnumFacing f : facings) {
/*     */       
/*  39 */       Block neighborBlock = mc.world.getBlockState(pos.offset(f)).getBlock();
/*     */       
/*  41 */       if (emptyBlocks.contains(neighborBlock)) {
/*     */         
/*  43 */         mc.playerController.processRightClickBlock(mc.player, mc.world, pos, f.getOpposite(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean placeBlock(BlockPos pos, int slot, boolean rotate, boolean rotateBack) {
/*  52 */     if (!isBlockEmpty(pos))
/*     */     {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (slot != mc.player.inventory.currentItem)
/*     */     {
/*  59 */       mc.player.inventory.currentItem = slot;
/*     */     }
/*     */     
/*  62 */     EnumFacing[] facings = EnumFacing.values();
/*     */     
/*  64 */     for (EnumFacing f : facings) {
/*     */       
/*  66 */       Block neighborBlock = mc.world.getBlockState(pos.offset(f)).getBlock();
/*  67 */       Vec3d vec = new Vec3d(pos.getX() + 0.5D + f.getXOffset() * 0.5D, pos.getY() + 0.5D + f.getYOffset() * 0.5D, pos.getZ() + 0.5D + f.getZOffset() * 0.5D);
/*     */       
/*  69 */       if (!emptyBlocks.contains(neighborBlock) && mc.player.getPositionEyes(mc.getRenderPartialTicks()).distanceTo(vec) <= 4.25D) {
/*     */         
/*  71 */         float[] rot = { mc.player.rotationYaw, mc.player.rotationPitch };
/*     */         
/*  73 */         if (rotate)
/*     */         {
/*  75 */           rotatePacket(vec.x, vec.y, vec.z);
/*     */         }
/*     */         
/*  78 */         if (rightclickableBlocks.contains(neighborBlock))
/*     */         {
/*  80 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
/*     */         }
/*     */         
/*  83 */         mc.playerController.processRightClickBlock(mc.player, mc.world, pos.offset(f), f.getOpposite(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
/*  84 */         if (rightclickableBlocks.contains(neighborBlock))
/*     */         {
/*  86 */           mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */         }
/*     */         
/*  89 */         if (rotateBack)
/*     */         {
/*  91 */           mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rot[0], rot[1], mc.player.onGround));
/*     */         }
/*     */         
/*  94 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBlockEmpty(BlockPos pos) {
/*     */     Entity e;
/* 104 */     if (!emptyBlocks.contains(mc.world.getBlockState(pos).getBlock()))
/*     */     {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     AxisAlignedBB box = new AxisAlignedBB(pos);
/* 110 */     Iterator<Entity> entityIter = mc.world.loadedEntityList.iterator();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 116 */       if (!entityIter.hasNext())
/*     */       {
/* 118 */         return true;
/*     */       }
/*     */       
/* 121 */       e = entityIter.next();
/* 122 */     } while (!(e instanceof net.minecraft.entity.EntityLivingBase) || !box.intersects(e.getEntityBoundingBox()));
/*     */     
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canPlaceBlock(BlockPos pos) {
/* 130 */     if (!isBlockEmpty(pos))
/*     */     {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     EnumFacing[] facings = EnumFacing.values();
/*     */     
/* 137 */     for (EnumFacing f : facings) {
/*     */       
/* 139 */       if (!emptyBlocks.contains(mc.world.getBlockState(pos.offset(f)).getBlock()) && mc.player.getPositionEyes(mc.getRenderPartialTicks()).distanceTo(new Vec3d(pos.getX() + 0.5D + f.getXOffset() * 0.5D, pos.getY() + 0.5D + f.getYOffset() * 0.5D, pos.getZ() + 0.5D + f.getZOffset() * 0.5D)) <= 4.25D)
/*     */       {
/* 141 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumFacing getClosestFacing(BlockPos pos) {
/* 151 */     return EnumFacing.DOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void rotateClient(double x, double y, double z) {
/* 156 */     double diffX = x - mc.player.posX;
/* 157 */     double diffY = y - mc.player.posY + mc.player.getEyeHeight();
/* 158 */     double diffZ = z - mc.player.posZ;
/* 159 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*     */     
/* 161 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 162 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*     */     
/* 164 */     mc.player.rotationYaw += MathHelper.wrapDegrees(yaw - mc.player.rotationYaw);
/* 165 */     mc.player.rotationPitch += MathHelper.wrapDegrees(pitch - mc.player.rotationPitch);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void rotatePacket(double x, double y, double z) {
/* 170 */     double diffX = x - mc.player.posX;
/* 171 */     double diffY = y - mc.player.posY + mc.player.getEyeHeight();
/* 172 */     double diffZ = z - mc.player.posZ;
/* 173 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*     */     
/* 175 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 176 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*     */     
/* 178 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(yaw, pitch, mc.player.onGround));
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\WorldUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
