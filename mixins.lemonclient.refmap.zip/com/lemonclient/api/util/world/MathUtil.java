//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class MathUtil
/*     */ {
/*     */   public static int clamp(int num, int min, int max) {
/*  16 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static float clamp(float num, float min, float max) {
/*  20 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static double clamp(double num, double min, double max) {
/*  24 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static long clamp(long num, long min, long max) {
/*  28 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal clamp(BigDecimal num, BigDecimal min, BigDecimal max) {
/*  34 */     return smallerThan(num, min) ? min : (biggerThan(num, max) ? max : num);
/*     */   }
/*     */   
/*     */   public static Vec3d roundVec(Vec3d vec3d, int places) {
/*  38 */     return new Vec3d(round(vec3d.x, places), round(vec3d.y, places), round(vec3d.z, places));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getBlockBlocks(Entity entity) {
/*  42 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/*  43 */     AxisAlignedBB bb = entity.getEntityBoundingBox();
/*  44 */     double y = entity.posY;
/*  45 */     double minX = round(bb.minX, 0);
/*  46 */     double minZ = round(bb.minZ, 0);
/*  47 */     double maxX = round(bb.maxX, 0);
/*  48 */     double maxZ = round(bb.maxZ, 0);
/*  49 */     if (minX != maxX) {
/*  50 */       vec3ds.add(new Vec3d(minX, y, minZ));
/*  51 */       vec3ds.add(new Vec3d(maxX, y, minZ));
/*  52 */       if (minZ != maxZ) {
/*  53 */         vec3ds.add(new Vec3d(minX, y, maxZ));
/*  54 */         vec3ds.add(new Vec3d(maxX, y, maxZ));
/*  55 */         return vec3ds;
/*     */       } 
/*  57 */     } else if (minZ != maxZ) {
/*  58 */       vec3ds.add(new Vec3d(minX, y, minZ));
/*  59 */       vec3ds.add(new Vec3d(minX, y, maxZ));
/*  60 */       return vec3ds;
/*     */     } 
/*  62 */     vec3ds.add(entity.getPositionVector());
/*  63 */     return vec3ds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean biggerThan(BigDecimal bigger, BigDecimal than) {
/*  72 */     return (bigger.compareTo(than) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean smallerThan(BigDecimal smaller, BigDecimal than) {
/*  82 */     return (smaller.compareTo(than) < 0);
/*     */   }
/*     */   
/*     */   public static double round(double value, int places) {
/*  86 */     return (places < 0) ? value : (new BigDecimal(value)).setScale(places, RoundingMode.HALF_UP).doubleValue();
/*     */   }
/*     */   
/*     */   public static float round(float value, int places) {
/*  90 */     return (places < 0) ? value : (new BigDecimal(value)).setScale(places, RoundingMode.HALF_UP).floatValue();
/*     */   }
/*     */   
/*     */   public static float round(float value, int places, float min, float max) {
/*  94 */     return MathHelper.clamp((places < 0) ? value : (new BigDecimal(value)).setScale(places, RoundingMode.HALF_UP).floatValue(), min, max);
/*     */   }
/*     */   
/*     */   public static Vec3d interpolateEntity(Entity entity, float time) {
/*  98 */     return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * time, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * time, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * time);
/*     */   }
/*     */   
/*     */   public static float rad(float angle) {
/* 102 */     return (float)(angle * Math.PI / 180.0D);
/*     */   }
/*     */   
/*     */   public static float[] calcAngleNoY(Vec3d from, Vec3d to) {
/* 106 */     double difX = to.x - from.x;
/* 107 */     double difZ = to.z - from.z;
/* 108 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D) };
/*     */   }
/*     */   public static Double calculateDoubleChange(double oldDouble, double newDouble, int step, int currentStep) {
/* 111 */     return Double.valueOf(oldDouble + (newDouble - oldDouble) * Math.max(0, Math.min(step, currentStep)) / step);
/*     */   }
/*     */   public static float[] calcAngle(Vec3d from, Vec3d to) {
/* 114 */     double difX = to.x - from.x;
/* 115 */     double difY = (to.y - from.y) * -1.0D;
/* 116 */     double difZ = to.z - from.z;
/* 117 */     double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
/* 118 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */   public static double square(double input) {
/* 121 */     return input * input;
/*     */   }
/*     */   public static double[] directionSpeed(double speed) {
/* 124 */     Minecraft mc = Minecraft.getMinecraft();
/* 125 */     float forward = mc.player.movementInput.moveForward;
/* 126 */     float side = mc.player.movementInput.moveStrafe;
/* 127 */     float yaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/* 128 */     if (forward != 0.0F) {
/* 129 */       if (side > 0.0F) {
/* 130 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 131 */       } else if (side < 0.0F) {
/* 132 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/* 134 */       side = 0.0F;
/* 135 */       if (forward > 0.0F) {
/* 136 */         forward = 1.0F;
/* 137 */       } else if (forward < 0.0F) {
/* 138 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/* 141 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 142 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 143 */     double posX = forward * speed * cos + side * speed * sin;
/* 144 */     double posZ = forward * speed * sin - side * speed * cos;
/* 145 */     return new double[] { posX, posZ };
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
