//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ import com.lemonclient.api.util.misc.Wrapper;
/*     */ import com.lemonclient.api.util.player.social.SocialManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntityIronGolem;
/*     */ import net.minecraft.entity.monster.EntityPigZombie;
/*     */ import net.minecraft.entity.passive.EntityWolf;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec2f;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class EntityUtil {
/*     */   public static void faceXYZ(double x, double y, double z) {
/*  32 */     faceYawAndPitch(getXYZYaw(x, y, z), getXYZPitch(x, y, z));
/*     */   }
/*     */   
/*     */   public static float getXYZYaw(double x, double y, double z) {
/*  36 */     float[] angle = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(x, y, z));
/*  37 */     return angle[0];
/*     */   }
/*     */   public static boolean stopSneaking(boolean isSneaking) {
/*  40 */     if (isSneaking && mc.player != null) {
/*  41 */       mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     }
/*  43 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getDamagePercent(ItemStack stack) {
/*  48 */     return (int)((stack.getMaxDamage() - stack.getItemDamage()) / Math.max(0.1D, stack.getMaxDamage()) * 100.0D);
/*     */   }
/*     */   public static void faceVector(Vec3d vec) {
/*  51 */     float[] rotations = getLegitRotations(vec);
/*  52 */     sendPlayerRot(rotations[0], rotations[1], mc.player.onGround);
/*     */   }
/*     */   
/*     */   public static void facePosFacing(BlockPos pos, EnumFacing side) {
/*  56 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(side.getDirectionVec())).scale(0.5D));
/*  57 */     faceVector(hitVec);
/*     */   }
/*     */   
/*     */   public static void facePlacePos(BlockPos pos, boolean strict, boolean raytrace) {
/*  61 */     EnumFacing side = BlockUtil.getFirstFacing(pos, strict, raytrace);
/*  62 */     if (side == null) {
/*     */       return;
/*     */     }
/*  65 */     BlockPos neighbour = pos.offset(side);
/*  66 */     EnumFacing opposite = side.getOpposite();
/*  67 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).add(0.5D, 0.5D, 0.5D).add((new Vec3d(opposite.getDirectionVec())).scale(0.5D));
/*  68 */     BlockUtil.faceVector(hitVec);
/*     */   }
/*     */   public static float getXYZPitch(double x, double y, double z) {
/*  71 */     float[] angle = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(x, y, z));
/*  72 */     return angle[1];
/*     */   }
/*     */   public static void faceYawAndPitch(float yaw, float pitch) {
/*  75 */     sendPlayerRot(yaw, pitch, mc.player.onGround);
/*     */   }
/*     */   public static void sendPlayerRot(float yaw, float pitch, boolean onGround) {
/*  78 */     mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(yaw, pitch, onGround));
/*     */   }
/*     */   public static float[] getLegitRotations(Vec3d vec) {
/*  81 */     Vec3d eyesPos = BlockUtil.getEyesPos();
/*  82 */     double diffX = vec.x - eyesPos.x;
/*  83 */     double diffY = vec.y - eyesPos.y;
/*  84 */     double diffZ = vec.z - eyesPos.z;
/*  85 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*  86 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  87 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*  88 */     return new float[] { mc.player.rotationYaw + MathHelper.wrapDegrees(yaw - mc.player.rotationYaw), mc.player.rotationPitch + MathHelper.wrapDegrees(pitch - mc.player.rotationPitch) };
/*     */   }
/*     */   
/*     */   public static Vec2f getRotations(Vec3d vec) {
/*  92 */     Vec3d eyesPos = BlockUtil.getEyesPos();
/*  93 */     double diffX = vec.x - eyesPos.x;
/*  94 */     double diffY = vec.y - eyesPos.y;
/*  95 */     double diffZ = vec.z - eyesPos.z;
/*  96 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*  97 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  98 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*  99 */     return new Vec2f(mc.player.rotationYaw + MathHelper.wrapDegrees(yaw - mc.player.rotationYaw), mc.player.rotationPitch + MathHelper.wrapDegrees(pitch - mc.player.rotationPitch));
/*     */   }
/*     */   public static boolean isEating() {
/* 102 */     if (mc.world == null || mc.player == null || mc.player.ticksExisted <= 20) return false; 
/* 103 */     RayTraceResult result = mc.objectMouseOver;
/* 104 */     if (result.typeOfHit == RayTraceResult.Type.BLOCK) {
/* 105 */       BlockPos pos = mc.objectMouseOver.getBlockPos();
/* 106 */       if (BlockUtil.blackList.contains(BlockUtil.getBlock(pos)) && !ColorMain.INSTANCE.sneaking) return false; 
/*     */     } 
/* 108 */     return (mc.player.isHandActive() && (mc.player.getActiveItemStack().getItem() instanceof net.minecraft.item.ItemFood || mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ItemFood));
/*     */   }
/*     */   public static boolean invalid(Entity entity, double range) {
/* 111 */     return (entity == null || isDead(entity) || entity.equals(mc.player) || (entity instanceof EntityPlayer && SocialManager.isFriend(entity.getName())) || mc.player.getDistanceSq(entity) > MathUtil.square(range));
/*     */   }
/*     */   public static BlockPos getEntityPos(Entity target) {
/* 114 */     return new BlockPos(target.posX, target.posY + 0.5D, target.posZ);
/*     */   }
/*     */   public static boolean isLiving(Entity entity) {
/* 117 */     return entity instanceof EntityLivingBase;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getVarOffsets(int x, int y, int z) {
/* 121 */     List<Vec3d> offsets = getVarOffsetList(x, y, z);
/* 122 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 123 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   public static BlockPos getPlayerPos(EntityPlayer player) {
/* 126 */     if (player == null) return null; 
/* 127 */     return new BlockPos(Math.floor(player.posX), Math.floor(player.posY) + 0.5D, Math.floor(player.posZ));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getVarOffsetList(int x, int y, int z) {
/* 131 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 132 */     offsets.add(new Vec3d(x, y, z));
/* 133 */     return offsets;
/*     */   }
/*     */   
/*     */   public static BlockPos getRoundedBlockPos(Entity entity) {
/* 137 */     return new BlockPos(MathUtil.roundVec(entity.lastPortalVec, 0));
/*     */   }
/*     */   public static boolean isAlive(Entity entity) {
/* 140 */     return (isLiving(entity) && !entity.isDead && ((EntityLivingBase)entity).getHealth() > 0.0F);
/*     */   }
/*     */   
/*     */   public static boolean isOnLiquid() {
/* 144 */     double y = mc.player.posY - 0.03D;
/* 145 */     for (int x = MathHelper.floor(mc.player.posX); x < MathHelper.ceil(mc.player.posX); x++) {
/* 146 */       for (int z = MathHelper.floor(mc.player.posZ); z < MathHelper.ceil(mc.player.posZ); z++) {
/* 147 */         BlockPos pos = new BlockPos(x, MathHelper.floor(y), z);
/* 148 */         if (mc.world.getBlockState(pos).getBlock() instanceof net.minecraft.block.BlockLiquid) {
/* 149 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 153 */     return false;
/*     */   }
/*     */   public static boolean isDead(Entity entity) {
/* 156 */     return !isAlive(entity);
/*     */   }
/*     */   
/*     */   public static float getHealth(Entity entity) {
/* 160 */     if (isLiving(entity)) {
/* 161 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 162 */       return livingBase.getHealth() + livingBase.getAbsorptionAmount();
/*     */     } 
/* 164 */     return 0.0F;
/*     */   }
/*     */   public static boolean isPassive(Entity e) {
/* 167 */     if (e instanceof EntityWolf && ((EntityWolf)e).isAngry()) return false; 
/* 168 */     if (e instanceof net.minecraft.entity.EntityAgeable || e instanceof net.minecraft.entity.passive.EntityAmbientCreature || e instanceof net.minecraft.entity.passive.EntitySquid) return true; 
/* 169 */     return (e instanceof EntityIronGolem && ((EntityIronGolem)e).getRevengeTarget() == null);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getOffsets(int y, boolean floor, boolean face) {
/* 173 */     List<Vec3d> offsets = getOffsetList(y, floor, face);
/* 174 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 175 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   public static boolean isSafe(Entity entity, int height, boolean floor) {
/* 178 */     return (getUnsafeBlocks(entity, height, floor).size() == 0);
/*     */   }
/*     */   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
/* 181 */     List<Vec3d> list = getUnsafeBlocks(entity, height, floor);
/* 182 */     Vec3d[] array = new Vec3d[list.size()];
/* 183 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
/* 186 */     return getUnsafeBlocksFromVec3d(entity.getPositionVector(), height, floor);
/*     */   }
/*     */   public static Vec3d[] getUnsafeBlockArrayFromVec3d(Vec3d pos, int height, boolean floor) {
/* 189 */     List<Vec3d> list = getUnsafeBlocksFromVec3d(pos, height, floor);
/* 190 */     Vec3d[] array = new Vec3d[list.size()];
/* 191 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
/* 194 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 195 */     for (Vec3d vector : getOffsets(height, floor)) {
/* 196 */       BlockPos targetPos = (new BlockPos(pos)).add(vector.x, vector.y, vector.z);
/* 197 */       Block block = mc.world.getBlockState(targetPos).getBlock();
/* 198 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 200 */         vec3ds.add(vector); } 
/*     */     } 
/* 202 */     return vec3ds;
/*     */   }
/*     */   public static List<Vec3d> getOffsetList(int y, boolean floor) {
/* 205 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 206 */     offsets.add(new Vec3d(-1.0D, y, 0.0D));
/* 207 */     offsets.add(new Vec3d(1.0D, y, 0.0D));
/* 208 */     offsets.add(new Vec3d(0.0D, y, -1.0D));
/* 209 */     offsets.add(new Vec3d(0.0D, y, 1.0D));
/* 210 */     if (floor) {
/* 211 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*     */     }
/* 213 */     return offsets;
/*     */   }
/*     */   public static Vec3d[] getOffsets(int y, boolean floor) {
/* 216 */     List<Vec3d> offsets = getOffsetList(y, floor);
/* 217 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 218 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getOffsetList(int y, boolean floor, boolean face) {
/* 222 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 223 */     if (face) {
/* 224 */       offsets.add(new Vec3d(-1.0D, y, 0.0D));
/* 225 */       offsets.add(new Vec3d(1.0D, y, 0.0D));
/* 226 */       offsets.add(new Vec3d(0.0D, y, -1.0D));
/* 227 */       offsets.add(new Vec3d(0.0D, y, 1.0D));
/*     */     } else {
/* 229 */       offsets.add(new Vec3d(-1.0D, y, 0.0D));
/*     */     } 
/* 231 */     if (floor) {
/* 232 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*     */     }
/* 234 */     return offsets;
/*     */   }
/* 236 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   
/*     */   public static Vec3d interpolateEntity(Entity entity, float time) {
/* 239 */     return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * time, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * time, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * time);
/*     */   }
/*     */   
/*     */   public static Block isColliding(double posX, double posY, double posZ) {
/* 243 */     Block block = null;
/* 244 */     if (mc.player != null) {
/* 245 */       AxisAlignedBB bb = (mc.player.getRidingEntity() != null) ? mc.player.getRidingEntity().getEntityBoundingBox().contract(0.0D, 0.0D, 0.0D).offset(posX, posY, posZ) : mc.player.getEntityBoundingBox().contract(0.0D, 0.0D, 0.0D).offset(posX, posY, posZ);
/* 246 */       int y = (int)bb.minY;
/* 247 */       for (int x = MathHelper.floor(bb.minX); x < MathHelper.floor(bb.maxX) + 1; x++) {
/* 248 */         for (int z = MathHelper.floor(bb.minZ); z < MathHelper.floor(bb.maxZ) + 1; z++) {
/* 249 */           block = mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
/*     */         }
/*     */       } 
/*     */     } 
/* 253 */     return block;
/*     */   }
/*     */   
/*     */   public static boolean isPlayerValid(EntityPlayer player, float range) {
/* 257 */     return (player != mc.player && mc.player.getDistance((Entity)player) < range && !player.isDead && !SocialManager.isFriend(player.getName()));
/*     */   }
/*     */   
/*     */   public static boolean isInLiquid() {
/* 261 */     if (mc.player != null) {
/* 262 */       if (mc.player.fallDistance >= 3.0F) {
/* 263 */         return false;
/*     */       }
/* 265 */       boolean inLiquid = false;
/* 266 */       AxisAlignedBB bb = (mc.player.getRidingEntity() != null) ? mc.player.getRidingEntity().getEntityBoundingBox() : mc.player.getEntityBoundingBox();
/* 267 */       int y = (int)bb.minY;
/* 268 */       for (int x = MathHelper.floor(bb.minX); x < MathHelper.floor(bb.maxX) + 1; x++) {
/* 269 */         for (int z = MathHelper.floor(bb.minZ); z < MathHelper.floor(bb.maxZ) + 1; z++) {
/* 270 */           Block block = mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
/* 271 */           if (!(block instanceof net.minecraft.block.BlockAir)) {
/* 272 */             if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/* 273 */               return false;
/*     */             }
/* 275 */             inLiquid = true;
/*     */           } 
/*     */         } 
/*     */       } 
/* 279 */       return inLiquid;
/*     */     } 
/* 281 */     return false;
/*     */   }
/*     */   
/*     */   public static void setTimer(float speed) {
/* 285 */     TimerUtils.setTickLength(50.0F / speed);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
/* 289 */     return getInterpolatedAmount(entity, ticks, ticks, ticks);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedPos(Entity entity, float ticks) {
/* 293 */     return (new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ)).add(getInterpolatedAmount(entity, ticks));
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
/* 297 */     return new Vec3d((entity.posX - entity.lastTickPosX) * x, (entity.posY - entity.lastTickPosY) * y, (entity.posZ - entity.lastTickPosZ) * z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float clamp(float val, float min, float max) {
/* 305 */     if (val <= min) {
/* 306 */       val = min;
/*     */     }
/* 308 */     if (val >= max) {
/* 309 */       val = max;
/*     */     }
/* 311 */     return val;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos loc, Double r, Double h, boolean hollow, boolean sphere, int plus_y) {
/* 315 */     List<BlockPos> circleBlocks = new ArrayList<>();
/* 316 */     double cx = loc.getX();
/* 317 */     double cy = loc.getY();
/* 318 */     double cz = loc.getZ(); double x;
/* 319 */     for (x = cx - r.doubleValue(); x <= cx + r.doubleValue(); x++) {
/* 320 */       double z; for (z = cz - r.doubleValue(); z <= cz + r.doubleValue(); ) {
/* 321 */         double y = sphere ? (cy - r.doubleValue()) : (cy - h.doubleValue()); for (;; z++) { if (y < (sphere ? (cy + r.doubleValue()) : (cy + h.doubleValue()))) {
/* 322 */             double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0.0D);
/* 323 */             if (dist < r.doubleValue() * r.doubleValue() && (!hollow || dist >= (r.doubleValue() - 1.0D) * (r.doubleValue() - 1.0D))) {
/* 324 */               BlockPos l = new BlockPos(x, y + plus_y, z);
/* 325 */               circleBlocks.add(l);
/*     */             }  y++; continue;
/*     */           }  }
/*     */       
/*     */       } 
/* 330 */     }  return circleBlocks;
/*     */   }
/*     */   public static List<BlockPos> getFlatSphere(BlockPos loc, Double r, Double h, boolean hollow, boolean sphere, int plus_y) {
/* 333 */     List<BlockPos> circleBlocks = new ArrayList<>();
/* 334 */     double cx = loc.getX();
/* 335 */     double cy = loc.getY();
/* 336 */     double cz = loc.getZ(); double y;
/* 337 */     for (y = sphere ? (cy - r.doubleValue()) : (cy - h.doubleValue()); y < (sphere ? (cy + r.doubleValue()) : (cy + h.doubleValue())); y++) {
/* 338 */       double x; for (x = cx - r.doubleValue(); x <= cx + r.doubleValue(); x++) {
/* 339 */         double z; for (z = cz - r.doubleValue(); z <= cz + r.doubleValue(); z++) {
/* 340 */           double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0.0D);
/* 341 */           if (dist < r.doubleValue() * r.doubleValue() && (!hollow || dist >= (r.doubleValue() - 1.0D) * (r.doubleValue() - 1.0D))) {
/* 342 */             BlockPos l = new BlockPos(x, y + plus_y, z);
/* 343 */             circleBlocks.add(l);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 348 */     return circleBlocks;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSquare(BlockPos pos1, BlockPos pos2) {
/* 352 */     List<BlockPos> squareBlocks = new ArrayList<>();
/* 353 */     int x1 = pos1.getX();
/* 354 */     int y1 = pos1.getY();
/* 355 */     int z1 = pos1.getZ();
/* 356 */     int x2 = pos2.getX();
/* 357 */     int y2 = pos2.getY();
/* 358 */     int z2 = pos2.getZ();
/* 359 */     for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
/* 360 */       for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
/* 361 */         for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
/* 362 */           squareBlocks.add(new BlockPos(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/* 366 */     return squareBlocks;
/*     */   }
/*     */   
/*     */   public static double[] calculateLookAt(double px, double py, double pz, Entity me) {
/* 370 */     double dirx = me.posX - px;
/* 371 */     double diry = me.posY - py;
/* 372 */     double dirz = me.posZ - pz;
/*     */     
/* 374 */     double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
/*     */     
/* 376 */     dirx /= len;
/* 377 */     diry /= len;
/* 378 */     dirz /= len;
/*     */     
/* 380 */     double pitch = Math.asin(diry);
/* 381 */     double yaw = Math.atan2(dirz, dirx);
/*     */     
/* 383 */     pitch = pitch * 180.0D / Math.PI;
/* 384 */     yaw = yaw * 180.0D / Math.PI;
/*     */     
/* 386 */     yaw += 90.0D;
/*     */     
/* 388 */     return new double[] { yaw, pitch };
/*     */   }
/*     */   
/*     */   public static boolean basicChecksEntity(EntityPlayer pl) {
/* 392 */     return (pl == null || pl.getName().equals(mc.player.getName()) || SocialManager.isFriend(pl.getName()) || pl.isDead || pl.getHealth() + pl.getAbsorptionAmount() <= 0.0F);
/*     */   }
/*     */   
/*     */   public static BlockPos getPosition(Entity pl) {
/* 396 */     return new BlockPos(Math.floor(pl.posX), Math.floor(pl.posY + 0.5D), Math.floor(pl.posZ));
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getBlocksIn(Entity pl) {
/* 400 */     List<BlockPos> blocks = new ArrayList<>();
/* 401 */     AxisAlignedBB bb = pl.getEntityBoundingBox();
/* 402 */     for (double x = Math.floor(bb.minX); x < Math.ceil(bb.maxX); x++) {
/* 403 */       double y; for (y = Math.floor(bb.minY); y < Math.ceil(bb.maxY); y++) {
/* 404 */         double z; for (z = Math.floor(bb.minZ); z < Math.ceil(bb.maxZ); z++) {
/* 405 */           blocks.add(new BlockPos(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/* 409 */     return blocks;
/*     */   }
/*     */   
/*     */   public static boolean isMobAggressive(Entity entity) {
/* 413 */     if (entity instanceof EntityPigZombie) {
/*     */       
/* 415 */       if (((EntityPigZombie)entity).isArmsRaised() || ((EntityPigZombie)entity).isAngry())
/* 416 */         return true; 
/*     */     } else {
/* 418 */       if (entity instanceof EntityWolf)
/* 419 */         return (((EntityWolf)entity).isAngry() && 
/* 420 */           !Wrapper.getPlayer().equals(((EntityWolf)entity).getOwner())); 
/* 421 */       if (entity instanceof EntityEnderman)
/* 422 */         return ((EntityEnderman)entity).isScreaming(); 
/*     */     } 
/* 424 */     return isHostileMob(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNeutralMob(Entity entity) {
/* 431 */     return (entity instanceof EntityPigZombie || entity instanceof EntityWolf || entity instanceof EntityEnderman);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFriendlyMob(Entity entity) {
/* 440 */     return ((entity.isCreatureType(EnumCreatureType.CREATURE, false) && !isNeutralMob(entity)) || entity
/* 441 */       .isCreatureType(EnumCreatureType.AMBIENT, false) || entity instanceof net.minecraft.entity.passive.EntityVillager || entity instanceof EntityIronGolem || (
/*     */ 
/*     */       
/* 444 */       isNeutralMob(entity) && !isMobAggressive(entity)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHostileMob(Entity entity) {
/* 451 */     return (entity.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(entity));
/*     */   }
/*     */   public static List<Vec3d> targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 454 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 455 */     if (antiDrop) Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiDropOffsetList)); 
/* 456 */     if (platform) Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, platformOffsetList)); 
/* 457 */     if (legs) Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, legOffsetList)); 
/* 458 */     Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, OffsetList));
/* 459 */     if (antiStep) { Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiStepOffsetList)); }
/*     */     else
/* 461 */     { List<Vec3d> vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
/* 462 */       if (vec3ds.size() == 4) {
/* 463 */         for (Vec3d vector : vec3ds) {
/* 464 */           BlockPos position = (new BlockPos(vec3d)).add(vector.x, vector.y, vector.z);
/* 465 */           switch (BlockUtil.isPositionPlaceable(position, raytrace)) {
/*     */             case 0:
/*     */               break;
/*     */             
/*     */             case -1:
/*     */             case 1:
/*     */             case 2:
/*     */               continue;
/*     */             
/*     */             case 3:
/* 475 */               placeTargets.add(vec3d.add(vector)); break;
/*     */             default:
/*     */               // Byte code: goto -> 234
/*     */           } 
/* 479 */           if (antiScaffold) {
/* 480 */             Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */           }
/* 482 */           return placeTargets;
/*     */         } 
/*     */       } }
/*     */     
/* 486 */     if (antiScaffold) {
/* 487 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */     }
/* 489 */     return placeTargets;
/*     */   }
/*     */   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 492 */     return getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).isEmpty();
/*     */   }
/*     */   
/*     */   public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 496 */     return getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace).isEmpty();
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 500 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 501 */     if (!antiStep && getUnsafeBlocks((Entity)player, 2, false).size() == 4) {
/* 502 */       vec3ds.addAll(getUnsafeBlocks((Entity)player, 2, false));
/*     */     }
/* 504 */     for (int i = 0; i < (getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)).length; i++) {
/* 505 */       Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
/* 506 */       BlockPos targetPos = (new BlockPos(player.getPositionVector())).add(vector.x, vector.y, vector.z);
/* 507 */       Block block = mc.world.getBlockState(targetPos).getBlock();
/* 508 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 510 */         vec3ds.add(vector); } 
/*     */     } 
/* 512 */     return vec3ds;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 517 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 518 */     if (extension == 1) {
/* 519 */       placeTargets.addAll(targets(player.getPositionVector(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*     */     } else {
/* 521 */       int extend = 1;
/* 522 */       for (Vec3d vec3d : MathUtil.getBlockBlocks((Entity)player)) {
/* 523 */         if (extend > extension)
/* 524 */           break;  placeTargets.addAll(targets(vec3d, antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/* 525 */         extend++;
/*     */       } 
/*     */     } 
/* 528 */     ArrayList<Vec3d> removeList = new ArrayList<>();
/* 529 */     for (Vec3d vec3d : placeTargets) {
/* 530 */       BlockPos pos = new BlockPos(vec3d);
/* 531 */       if (BlockUtil.isPositionPlaceable(pos, raytrace) != -1)
/* 532 */         continue;  removeList.add(vec3d);
/*     */     } 
/* 534 */     for (Vec3d vec3d : removeList) {
/* 535 */       placeTargets.remove(vec3d);
/*     */     }
/* 537 */     return placeTargets;
/*     */   }
/*     */   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 540 */     List<Vec3d> offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
/* 541 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 542 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 546 */     ArrayList<Vec3d> offsets = new ArrayList<>(getOffsetList(1, false));
/* 547 */     offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
/* 548 */     if (antiScaffold) {
/* 549 */       offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
/*     */     }
/* 551 */     if (antiStep) {
/* 552 */       offsets.addAll(getOffsetList(2, false));
/*     */     }
/* 554 */     if (legs) {
/* 555 */       offsets.addAll(getOffsetList(0, false));
/*     */     }
/* 557 */     if (platform) {
/* 558 */       offsets.addAll(getOffsetList(-1, false));
/* 559 */       offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
/*     */     } 
/* 561 */     if (antiDrop) {
/* 562 */       offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
/*     */     }
/* 564 */     return offsets;
/*     */   }
/* 566 */   public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D) };
/* 567 */   public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D) };
/* 568 */   public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D) };
/* 569 */   public static final Vec3d[] OffsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D) };
/* 570 */   public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D) };
/* 571 */   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D) };
/* 572 */   public static final Vec3d[] doubleLegOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(-2.0D, 0.0D, 0.0D), new Vec3d(2.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -2.0D), new Vec3d(0.0D, 0.0D, 2.0D) };
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\EntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
