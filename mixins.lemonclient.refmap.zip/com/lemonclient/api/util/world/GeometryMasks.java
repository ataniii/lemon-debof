/*    */ package com.lemonclient.api.util.world;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ 
/*    */ 
/*    */ public final class GeometryMasks
/*    */ {
/*  9 */   public static final HashMap<EnumFacing, Integer> FACEMAP = new HashMap<>();
/*    */   
/*    */   static {
/* 12 */     FACEMAP.put(EnumFacing.DOWN, Integer.valueOf(1));
/* 13 */     FACEMAP.put(EnumFacing.WEST, Integer.valueOf(16));
/* 14 */     FACEMAP.put(EnumFacing.NORTH, Integer.valueOf(4));
/* 15 */     FACEMAP.put(EnumFacing.SOUTH, Integer.valueOf(8));
/* 16 */     FACEMAP.put(EnumFacing.EAST, Integer.valueOf(32));
/* 17 */     FACEMAP.put(EnumFacing.UP, Integer.valueOf(2));
/*    */   }
/*    */   
/*    */   public static final class Quad {
/*    */     public static final int DOWN = 1;
/*    */     public static final int UP = 2;
/*    */     public static final int NORTH = 4;
/*    */     public static final int SOUTH = 8;
/*    */     public static final int WEST = 16;
/*    */     public static final int EAST = 32;
/*    */     public static final int NONORTH = 59;
/*    */     public static final int NOSOUTH = 55;
/*    */     public static final int NOWEST = 47;
/*    */     public static final int NOEAST = 31;
/*    */     public static final int ALL = 63;
/*    */   }
/*    */   
/*    */   public static final class Line {
/*    */     public static final int DOWN_WEST = 17;
/*    */     public static final int UP_WEST = 18;
/*    */     public static final int DOWN_EAST = 33;
/*    */     public static final int UP_EAST = 34;
/*    */     public static final int DOWN_NORTH = 5;
/*    */     public static final int UP_NORTH = 6;
/*    */     public static final int DOWN_SOUTH = 9;
/*    */     public static final int UP_SOUTH = 10;
/*    */     public static final int NORTH_WEST = 20;
/*    */     public static final int NORTH_EAST = 36;
/*    */     public static final int SOUTH_WEST = 24;
/*    */     public static final int SOUTH_EAST = 40;
/*    */     public static final int ALL = 63;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\GeometryMasks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */