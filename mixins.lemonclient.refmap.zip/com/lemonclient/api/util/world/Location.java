//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ public class Location
/*     */ {
/*     */   private double x;
/*     */   private double y;
/*     */   
/*     */   public Location(double x, double y, double z, boolean ground) {
/*  13 */     this.x = x;
/*  14 */     this.y = y;
/*  15 */     this.z = z;
/*  16 */     this.ground = ground;
/*     */   }
/*     */   private double z; private boolean ground;
/*     */   public Location(double x, double y, double z) {
/*  20 */     this.x = x;
/*  21 */     this.y = y;
/*  22 */     this.z = z;
/*  23 */     this.ground = true;
/*     */   }
/*     */   
/*     */   public Location(int x, int y, int z) {
/*  27 */     this.x = x;
/*  28 */     this.y = y;
/*  29 */     this.z = z;
/*  30 */     this.ground = true;
/*     */   }
/*     */   
/*     */   public Location add(int x, int y, int z) {
/*  34 */     this.x += x;
/*  35 */     this.y += y;
/*  36 */     this.z += z;
/*  37 */     return this;
/*     */   }
/*     */   
/*     */   public Location add(double x, double y, double z) {
/*  41 */     this.x += x;
/*  42 */     this.y += y;
/*  43 */     this.z += z;
/*  44 */     return this;
/*     */   }
/*     */   
/*     */   public Location subtract(int x, int y, int z) {
/*  48 */     this.x -= x;
/*  49 */     this.y -= y;
/*  50 */     this.z -= z;
/*     */     
/*  52 */     return this;
/*     */   }
/*     */   
/*     */   public Location subtract(double x, double y, double z) {
/*  56 */     this.x -= x;
/*  57 */     this.y -= y;
/*  58 */     this.z -= z;
/*     */     
/*  60 */     return this;
/*     */   }
/*     */   
/*     */   public Block getBlock() {
/*  64 */     return (Minecraft.getMinecraft()).world.getBlockState(toBlockPos()).getBlock();
/*     */   }
/*     */   
/*     */   public boolean isOnGround() {
/*  68 */     return this.ground;
/*     */   }
/*     */   
/*     */   public Location setOnGround(boolean ground) {
/*  72 */     this.ground = ground;
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   public double getX() {
/*  77 */     return this.x;
/*     */   }
/*     */   
/*     */   public Location setX(double x) {
/*  81 */     this.x = x;
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public double getY() {
/*  86 */     return this.y;
/*     */   }
/*     */   
/*     */   public Location setY(double y) {
/*  90 */     this.y = y;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public double getZ() {
/*  95 */     return this.z;
/*     */   }
/*     */   
/*     */   public Location setZ(double z) {
/*  99 */     this.z = z;
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public static Location fromBlockPos(BlockPos blockPos) {
/* 104 */     return new Location(blockPos.getX(), blockPos.getY(), blockPos.getZ());
/*     */   }
/*     */   
/*     */   public BlockPos toBlockPos() {
/* 108 */     return new BlockPos(getX(), getY(), getZ());
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
