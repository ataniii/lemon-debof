//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world;
/*     */ 
/*     */ import com.lemonclient.api.util.world.combat.HoleFinder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ public class HoleUtil
/*     */ {
/*  15 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */ 
/*     */   
/*     */   public static boolean isInHole(Entity e, boolean onlyOneWide, boolean ignoreDown, boolean render) {
/*  19 */     return !isHole(new BlockPos(e.getPositionVector()), onlyOneWide, ignoreDown, render).getType().equals(HoleType.NONE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHoleBlock(BlockPos blockPos, boolean onlyOneWide, boolean ignoreDown, boolean render) {
/*  25 */     return (!isHole(blockPos, onlyOneWide, ignoreDown, render).getType().equals(HoleType.NONE) && !isHole(blockPos, onlyOneWide, ignoreDown, render).getType().equals(HoleType.CUSTOM));
/*     */   }
/*     */   
/*     */   public static BlockSafety isBlockSafe(Block block) {
/*  29 */     if (block == Blocks.BEDROCK) {
/*  30 */       return BlockSafety.UNBREAKABLE;
/*     */     }
/*  32 */     if (block == Blocks.OBSIDIAN || block == Blocks.ENDER_CHEST || block == Blocks.ANVIL) {
/*  33 */       return BlockSafety.RESISTANT;
/*     */     }
/*  35 */     return BlockSafety.BREAKABLE;
/*     */   }
/*     */   
/*     */   public static HoleInfo isHole(BlockPos centreBlock, boolean onlyOneWide, boolean ignoreDown, boolean render) {
/*  39 */     HoleInfo output = new HoleInfo();
/*  40 */     HashMap<BlockOffset, BlockSafety> unsafeSides = getUnsafeSides(centreBlock);
/*     */     
/*  42 */     if (unsafeSides.containsKey(BlockOffset.DOWN) && 
/*  43 */       unsafeSides.remove(BlockOffset.DOWN, BlockSafety.BREAKABLE) && 
/*  44 */       !ignoreDown) {
/*  45 */       output.setSafety(BlockSafety.BREAKABLE);
/*  46 */       return output;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  51 */     int size = unsafeSides.size();
/*     */     
/*  53 */     unsafeSides.entrySet().removeIf(entry -> (entry.getValue() == BlockSafety.RESISTANT));
/*     */ 
/*     */     
/*  56 */     if (unsafeSides.size() != size) {
/*  57 */       output.setSafety(BlockSafety.RESISTANT);
/*     */     }
/*     */     
/*  60 */     size = unsafeSides.size();
/*     */ 
/*     */     
/*  63 */     if (size == 0) {
/*  64 */       output.setType(HoleType.SINGLE);
/*  65 */       output.setCentre(new AxisAlignedBB(centreBlock));
/*  66 */       return output;
/*     */     } 
/*     */     
/*  69 */     if (size == 1 && !onlyOneWide)
/*  70 */       return isDoubleHole(output, centreBlock, unsafeSides.keySet().stream().findFirst().get()); 
/*  71 */     if (size == 2 && !onlyOneWide) {
/*  72 */       return isFourHole(output, centreBlock, render);
/*     */     }
/*  74 */     output.setSafety(BlockSafety.BREAKABLE);
/*  75 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   private static HoleInfo isDoubleHole(HoleInfo info, BlockPos centreBlock, BlockOffset weakSide) {
/*  80 */     BlockPos unsafePos = weakSide.offset(centreBlock);
/*     */     
/*  82 */     HashMap<BlockOffset, BlockSafety> unsafeSides = getUnsafeSides(unsafePos);
/*     */     
/*  84 */     int size = unsafeSides.size();
/*     */     
/*  86 */     unsafeSides.entrySet().removeIf(entry -> (entry.getValue() == BlockSafety.RESISTANT));
/*     */ 
/*     */     
/*  89 */     if (unsafeSides.size() != size) {
/*  90 */       info.setSafety(BlockSafety.RESISTANT);
/*     */     }
/*     */     
/*  93 */     if (unsafeSides.containsKey(BlockOffset.DOWN)) {
/*  94 */       info.setType(HoleType.CUSTOM);
/*  95 */       unsafeSides.remove(BlockOffset.DOWN);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     if (unsafeSides.size() > 1) {
/* 100 */       info.setType(HoleType.NONE);
/* 101 */       return info;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     double minX = Math.min(centreBlock.getX(), unsafePos.getX());
/* 106 */     double maxX = (Math.max(centreBlock.getX(), unsafePos.getX()) + 1);
/* 107 */     double minZ = Math.min(centreBlock.getZ(), unsafePos.getZ());
/* 108 */     double maxZ = (Math.max(centreBlock.getZ(), unsafePos.getZ()) + 1);
/*     */     
/* 110 */     info.setCentre(new AxisAlignedBB(minX, centreBlock.getY(), minZ, maxX, (centreBlock.getY() + 1), maxZ));
/*     */     
/* 112 */     if (info.getType() != HoleType.CUSTOM) {
/* 113 */       info.setType(HoleType.DOUBLE);
/*     */     }
/* 115 */     return info;
/*     */   }
/*     */   private static HoleInfo isFourHole(HoleInfo info, BlockPos centreBlock, boolean render) {
/* 118 */     if (render ? HoleFinder.is2x2single(centreBlock, true) : HoleFinder.is2x2(centreBlock, true)) {
/* 119 */       info.setSafety(BlockSafety.RESISTANT);
/* 120 */       double minX = centreBlock.getX();
/* 121 */       double maxX = (centreBlock.getX() + 2);
/* 122 */       double minZ = centreBlock.getZ();
/* 123 */       double maxZ = (centreBlock.getZ() + 2);
/* 124 */       if (!render) {
/* 125 */         BlockPos blockPos = centreBlock;
/* 126 */         if (mc.world.isAirBlock(centreBlock.add(-1, 0, 0)))
/* 127 */           blockPos = blockPos.add(-1, 0, 0); 
/* 128 */         if (mc.world.isAirBlock(centreBlock.add(0, 0, -1)))
/* 129 */           blockPos = blockPos.add(0, 0, -1); 
/* 130 */         minX = blockPos.getX();
/* 131 */         maxX = (blockPos.getX() + 2);
/* 132 */         minZ = blockPos.getZ();
/* 133 */         maxZ = (blockPos.getZ() + 2);
/*     */       } 
/* 135 */       info.setCentre(new AxisAlignedBB(minX, centreBlock.getY(), minZ, maxX, (centreBlock.getY() + 1), maxZ));
/* 136 */       info.setType(HoleType.FOUR);
/*     */     } else {
/* 138 */       info.setType(HoleType.NONE);
/*     */     } 
/*     */     
/* 141 */     return info;
/*     */   }
/*     */   
/*     */   public static HashMap<BlockOffset, BlockSafety> getUnsafeSides(BlockPos pos) {
/* 145 */     HashMap<BlockOffset, BlockSafety> output = new HashMap<>();
/*     */ 
/*     */     
/* 148 */     BlockSafety temp = isBlockSafe(mc.world.getBlockState(BlockOffset.DOWN.offset(pos)).getBlock());
/* 149 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 150 */       output.put(BlockOffset.DOWN, temp);
/*     */     }
/* 152 */     temp = isBlockSafe(mc.world.getBlockState(BlockOffset.NORTH.offset(pos)).getBlock());
/* 153 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 154 */       output.put(BlockOffset.NORTH, temp);
/*     */     }
/* 156 */     temp = isBlockSafe(mc.world.getBlockState(BlockOffset.SOUTH.offset(pos)).getBlock());
/* 157 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 158 */       output.put(BlockOffset.SOUTH, temp);
/*     */     }
/* 160 */     temp = isBlockSafe(mc.world.getBlockState(BlockOffset.EAST.offset(pos)).getBlock());
/* 161 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 162 */       output.put(BlockOffset.EAST, temp);
/*     */     }
/* 164 */     temp = isBlockSafe(mc.world.getBlockState(BlockOffset.WEST.offset(pos)).getBlock());
/* 165 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 166 */       output.put(BlockOffset.WEST, temp);
/*     */     }
/* 168 */     return output;
/*     */   }
/*     */   
/*     */   public enum BlockSafety {
/* 172 */     UNBREAKABLE,
/* 173 */     RESISTANT,
/* 174 */     BREAKABLE;
/*     */   }
/*     */   
/*     */   public enum HoleType {
/* 178 */     SINGLE,
/* 179 */     DOUBLE,
/* 180 */     CUSTOM,
/* 181 */     FOUR,
/* 182 */     NONE;
/*     */   }
/*     */   
/*     */   public static class HoleInfo
/*     */   {
/*     */     private HoleUtil.HoleType type;
/*     */     private HoleUtil.BlockSafety safety;
/*     */     private AxisAlignedBB centre;
/*     */     
/*     */     public HoleInfo() {
/* 192 */       this(HoleUtil.BlockSafety.UNBREAKABLE, HoleUtil.HoleType.NONE);
/*     */     }
/*     */     
/*     */     public HoleInfo(HoleUtil.BlockSafety safety, HoleUtil.HoleType type) {
/* 196 */       this.type = type;
/* 197 */       this.safety = safety;
/*     */     }
/*     */     
/*     */     public void setType(HoleUtil.HoleType type) {
/* 201 */       this.type = type;
/*     */     }
/*     */     
/*     */     public void setSafety(HoleUtil.BlockSafety safety) {
/* 205 */       this.safety = safety;
/*     */     }
/*     */     
/*     */     public void setCentre(AxisAlignedBB centre) {
/* 209 */       this.centre = centre;
/*     */     }
/*     */     
/*     */     public HoleUtil.HoleType getType() {
/* 213 */       return this.type;
/*     */     }
/*     */     
/*     */     public HoleUtil.BlockSafety getSafety() {
/* 217 */       return this.safety;
/*     */     }
/*     */     
/*     */     public AxisAlignedBB getCentre() {
/* 221 */       return this.centre;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum BlockOffset {
/* 226 */     DOWN(0, -1, 0),
/* 227 */     UP(0, 1, 0),
/* 228 */     NORTH(0, 0, -1),
/* 229 */     EAST(1, 0, 0),
/* 230 */     SOUTH(0, 0, 1),
/* 231 */     WEST(-1, 0, 0);
/*     */     
/*     */     private final int x;
/*     */     private final int y;
/*     */     private final int z;
/*     */     
/*     */     BlockOffset(int x, int y, int z) {
/* 238 */       this.x = x;
/* 239 */       this.y = y;
/* 240 */       this.z = z;
/*     */     }
/*     */     
/*     */     public BlockPos offset(BlockPos pos) {
/* 244 */       return pos.add(this.x, this.y, this.z);
/*     */     }
/*     */     
/*     */     public BlockPos forward(BlockPos pos, int scale) {
/* 248 */       return pos.add(this.x * scale, 0, this.z * scale);
/*     */     }
/*     */     
/*     */     public BlockPos backward(BlockPos pos, int scale) {
/* 252 */       return pos.add(-this.x * scale, 0, -this.z * scale);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockPos left(BlockPos pos, int scale) {
/* 258 */       return pos.add(this.z * scale, 0, -this.x * scale);
/*     */     }
/*     */     
/*     */     public BlockPos right(BlockPos pos, int scale) {
/* 262 */       return pos.add(-this.z * scale, 0, this.x * scale);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\HoleUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
