//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.world.combat;
/*    */ 
/*    */ import com.lemonclient.api.util.player.PlayerUtil;
/*    */ import com.lemonclient.api.util.world.EntityUtil;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketUseEntity;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class CrystalUtil
/*    */ {
/* 21 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   public static boolean canPlaceCrystal(BlockPos blockPos, boolean newPlacement) {
/* 24 */     if (notValidBlock(mc.world.getBlockState(blockPos).getBlock())) return false;
/*    */     
/* 26 */     BlockPos posUp = blockPos.up();
/*    */     
/* 28 */     if (newPlacement)
/* 29 */     { if (!mc.world.isAirBlock(posUp)) return false;
/*    */        }
/* 31 */     else if (notValidMaterial(mc.world.getBlockState(posUp).getMaterial()) || 
/* 32 */       notValidMaterial(mc.world.getBlockState(posUp.up()).getMaterial())) { return false; }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     AxisAlignedBB box = new AxisAlignedBB(posUp.getX(), posUp.getY(), posUp.getZ(), posUp.getX() + 1.0D, posUp.getY() + 2.0D, posUp.getZ() + 1.0D);
/*    */ 
/*    */     
/* 40 */     return mc.world.getEntitiesWithinAABB(Entity.class, box, Entity::isEntityAlive).isEmpty();
/*    */   }
/*    */   
/*    */   public static boolean canPlaceCrystalExcludingCrystals(BlockPos blockPos, boolean newPlacement) {
/* 44 */     if (notValidBlock(mc.world.getBlockState(blockPos).getBlock())) return false;
/*    */     
/* 46 */     BlockPos posUp = blockPos.up();
/* 47 */     if (newPlacement)
/* 48 */     { if (!mc.world.isAirBlock(posUp)) return false;
/*    */        }
/* 50 */     else if (notValidMaterial(mc.world.getBlockState(posUp).getMaterial()) || 
/* 51 */       notValidMaterial(mc.world.getBlockState(posUp.up()).getMaterial())) { return false; }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     AxisAlignedBB box = new AxisAlignedBB(posUp.getX(), posUp.getY(), posUp.getZ(), posUp.getX() + 1.0D, posUp.getY() + 2.0D, posUp.getZ() + 1.0D);
/*    */ 
/*    */     
/* 59 */     return mc.world.getEntitiesWithinAABB(Entity.class, box, entity -> (!entity.isDead && !(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))).isEmpty();
/*    */   }
/*    */   public static boolean notValidBlock(Block block) {
/* 62 */     return (block != Blocks.BEDROCK && block != Blocks.OBSIDIAN);
/*    */   }
/*    */   
/*    */   public static boolean notValidMaterial(Material material) {
/* 66 */     return (material.isLiquid() || !material.isReplaceable());
/*    */   }
/*    */   
/*    */   public static List<BlockPos> findCrystalBlocks(float placeRange, boolean mode) {
/* 70 */     return (List<BlockPos>)EntityUtil.getSphere(PlayerUtil.getPlayerPos(), Double.valueOf(placeRange), Double.valueOf(placeRange), false, true, 0).stream().filter(pos -> canPlaceCrystal(pos, mode)).collect(Collectors.toList());
/*    */   }
/*    */   public static List<BlockPos> findCrystalBlocksExcludingCrystals(float placeRange, boolean mode) {
/* 73 */     return (List<BlockPos>)EntityUtil.getSphere(PlayerUtil.getPlayerPos(), Double.valueOf(placeRange), Double.valueOf(placeRange), false, true, 0).stream().filter(pos -> canPlaceCrystalExcludingCrystals(pos, mode)).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   public static void breakCrystal(BlockPos pos, boolean swing) {
/* 77 */     for (Entity entity : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos))) {
/* 78 */       if (!(entity instanceof net.minecraft.entity.item.EntityEnderCrystal))
/* 79 */         continue;  mc.playerController.attackEntity((EntityPlayer)mc.player, entity);
/* 80 */       if (swing) mc.player.swingArm(EnumHand.MAIN_HAND);
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void breakCrystal(Entity crystal, boolean swing) {
/* 86 */     mc.playerController.attackEntity((EntityPlayer)mc.player, crystal);
/* 87 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*    */   }
/*    */   
/*    */   public static void breakCrystalPacket(Entity crystal, boolean swing) {
/* 91 */     mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
/* 92 */     if (swing) mc.player.swingArm(EnumHand.MAIN_HAND); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\combat\CrystalUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
