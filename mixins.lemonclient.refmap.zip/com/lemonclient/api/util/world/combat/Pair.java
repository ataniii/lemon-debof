/*   */ package com.lemonclient.api.util.world.combat;
/*   */ 
/*   */ public class Pair<T, V> {
/*   */   public T a;
/*   */   
/*   */   public Pair(T a, V b) {
/* 7 */     this.a = a;
/* 8 */     this.b = b;
/*   */   }
/*   */   
/*   */   public V b;
/*   */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\combat\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */