//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world.combat;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HoleFinder
/*     */ {
/*  21 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*     */   public static boolean isAir(BlockPos pos) {
/*  23 */     return mc.world.isAirBlock(pos);
/*     */   }
/*     */   
/*  26 */   private static final Vec3i[] OFFSETS_2x2 = new Vec3i[] { new Vec3i(0, 0, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(1, 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   public static final Set<Block> NO_BLAST = Sets.newHashSet((Object[])new Block[] { Blocks.BEDROCK, Blocks.OBSIDIAN, Blocks.ANVIL, Blocks.ENDER_CHEST });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final Set<Block> UNSAFE = Sets.newHashSet((Object[])new Block[] { Blocks.OBSIDIAN, Blocks.ANVIL, Blocks.ENDER_CHEST });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean[] isHole(BlockPos pos, boolean above) {
/*  49 */     boolean[] result = { false, true };
/*  50 */     if (!isAir(pos) || !isAir(pos.up()) || (above && !isAir(pos.up(2))))
/*     */     {
/*  52 */       return result;
/*     */     }
/*     */     
/*  55 */     return is1x1(pos, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean[] is1x1(BlockPos pos) {
/*  60 */     return is1x1(pos, new boolean[] { false, true });
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean[] is1x1(BlockPos pos, boolean[] result) {
/*  65 */     for (EnumFacing facing : EnumFacing.values()) {
/*     */       
/*  67 */       if (facing != EnumFacing.UP) {
/*     */         
/*  69 */         BlockPos offset = pos.offset(facing);
/*  70 */         IBlockState state = mc.world.getBlockState(offset);
/*  71 */         if (state.getBlock() != Blocks.BEDROCK) {
/*     */           
/*  73 */           if (!NO_BLAST.contains(state.getBlock()))
/*     */           {
/*  75 */             return result;
/*     */           }
/*     */           
/*  78 */           result[1] = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  83 */     result[0] = true;
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is2x1(BlockPos pos) {
/*  89 */     return is2x1(pos, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is2x1(BlockPos pos, boolean upper) {
/*  94 */     if (upper && (!isAir(pos) || !isAir(pos.up()) || isAir(pos.down())))
/*     */     {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     int airBlocks = 0;
/* 100 */     for (EnumFacing facing : EnumFacing.HORIZONTALS) {
/*     */       
/* 102 */       BlockPos offset = pos.offset(facing);
/* 103 */       if (isAir(offset)) {
/*     */         
/* 105 */         if (isAir(offset.up())) {
/*     */           
/* 107 */           if (!isAir(offset.down())) {
/*     */             
/* 109 */             for (EnumFacing offsetFacing : EnumFacing.HORIZONTALS) {
/*     */               
/* 111 */               if (offsetFacing != facing.getOpposite())
/*     */               {
/* 113 */                 IBlockState state = mc.world.getBlockState(offset
/* 114 */                     .offset(offsetFacing));
/*     */                 
/* 116 */                 if (!NO_BLAST.contains(state.getBlock()))
/*     */                 {
/* 118 */                   return false;
/*     */                 }
/*     */               }
/*     */             
/*     */             } 
/*     */           } else {
/*     */             
/* 125 */             return false;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 130 */           return false;
/*     */         } 
/*     */         
/* 133 */         airBlocks++;
/*     */       } 
/*     */       
/* 136 */       if (airBlocks > 1)
/*     */       {
/* 138 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 142 */     return (airBlocks == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is2x2Partial(BlockPos pos) {
/* 147 */     Set<BlockPos> positions = new HashSet<>();
/* 148 */     for (Vec3i vec : OFFSETS_2x2)
/*     */     {
/* 150 */       positions.add(pos.add(vec));
/*     */     }
/*     */     
/* 153 */     boolean airBlock = false;
/* 154 */     for (BlockPos holePos : positions) {
/*     */       
/* 156 */       if (isAir(holePos) && isAir(holePos.up()) && !isAir(holePos.down())) {
/*     */         
/* 158 */         if (isAir(holePos.up(2)))
/*     */         {
/* 160 */           airBlock = true;
/*     */         }
/*     */         
/* 163 */         for (EnumFacing facing : EnumFacing.HORIZONTALS) {
/*     */           
/* 165 */           BlockPos offset = holePos.offset(facing);
/* 166 */           if (!positions.contains(offset)) {
/*     */             
/* 168 */             IBlockState state = mc.world.getBlockState(offset);
/* 169 */             if (!NO_BLAST.contains(state.getBlock()))
/*     */             {
/* 171 */               return false;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 178 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return airBlock;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is2x2(BlockPos pos) {
/* 187 */     return is2x2(pos, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is2x2(BlockPos pos, boolean upper) {
/* 192 */     if (upper && !isAir(pos))
/*     */     {
/* 194 */       return false;
/*     */     }
/*     */     
/* 197 */     if (is2x2Partial(pos))
/*     */     {
/* 199 */       return true;
/*     */     }
/*     */     
/* 202 */     BlockPos l = pos.add(-1, 0, 0);
/* 203 */     boolean airL = isAir(l);
/* 204 */     if (airL && is2x2Partial(l))
/*     */     {
/* 206 */       return true;
/*     */     }
/*     */     
/* 209 */     BlockPos r = pos.add(0, 0, -1);
/* 210 */     boolean airR = isAir(r);
/* 211 */     if (airR && is2x2Partial(r))
/*     */     {
/* 213 */       return true;
/*     */     }
/*     */     
/* 216 */     return ((airL || airR) && is2x2Partial(pos.add(-1, 0, -1)));
/*     */   }
/*     */   
/*     */   public static boolean is2x2single(BlockPos pos, boolean upper) {
/* 220 */     if (upper && !isAir(pos))
/*     */     {
/* 222 */       return false;
/*     */     }
/*     */     
/* 225 */     return is2x2Partial(pos);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\combat\HoleFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
