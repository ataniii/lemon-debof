//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world.combat;
/*     */ import com.lemonclient.api.util.world.MathUtil;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class RotationUtil {
/*  15 */   public static Minecraft mc = Minecraft.getMinecraft();
/*     */   public static float getYawChangeGiven(double posX, double posZ, float yaw) {
/*  17 */     double yawToEntity, deltaX = posX - (Minecraft.getMinecraft()).player.posX;
/*  18 */     double deltaZ = posZ - (Minecraft.getMinecraft()).player.posZ;
/*     */     
/*  20 */     if (deltaZ < 0.0D && deltaX < 0.0D) {
/*  21 */       yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
/*  22 */     } else if (deltaZ < 0.0D && deltaX > 0.0D) {
/*  23 */       yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
/*     */     } else {
/*  25 */       yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
/*     */     } 
/*     */     
/*  28 */     return MathHelper.wrapDegrees(-(yaw - (float)yawToEntity));
/*     */   }
/*     */   
/*     */   public static float[] getRotations(BlockPos pos, EnumFacing facing) {
/*  32 */     return getRotations(pos, facing, (Entity)getRotationPlayer());
/*     */   }
/*     */ 
/*     */   
/*     */   public static float[] getRotations(BlockPos pos, EnumFacing facing, Entity from) {
/*  37 */     return getRotations(pos, facing, from, (IBlockAccess)mc.world, mc.world.getBlockState(pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] getRotations(BlockPos pos, EnumFacing facing, Entity from, IBlockAccess world, IBlockState state) {
/*  46 */     AxisAlignedBB bb = state.getBoundingBox(world, pos);
/*     */     
/*  48 */     double x = pos.getX() + (bb.minX + bb.maxX) / 2.0D;
/*  49 */     double y = pos.getY() + (bb.minY + bb.maxY) / 2.0D;
/*  50 */     double z = pos.getZ() + (bb.minZ + bb.maxZ) / 2.0D;
/*     */     
/*  52 */     if (facing != null) {
/*     */       
/*  54 */       x += facing.getDirectionVec().getX() * (bb.minX + bb.maxX) / 2.0D;
/*  55 */       y += facing.getDirectionVec().getY() * (bb.minY + bb.maxY) / 2.0D;
/*  56 */       z += facing.getDirectionVec().getZ() * (bb.minZ + bb.maxZ) / 2.0D;
/*     */     } 
/*     */     
/*  59 */     return getRotations(x, y, z, from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] getRotations(double x, double y, double z, double fromX, double fromY, double fromZ, float fromHeight) {
/*  69 */     double xDiff = x - fromX;
/*  70 */     double yDiff = y - fromY + fromHeight;
/*  71 */     double zDiff = z - fromZ;
/*  72 */     double dist = MathHelper.sqrt(xDiff * xDiff + zDiff * zDiff);
/*     */     
/*  74 */     float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0F;
/*  75 */     float pitch = (float)-(Math.atan2(yDiff, dist) * 180.0D / Math.PI);
/*     */     
/*  77 */     float prevYaw = mc.player.prevRotationYaw;
/*  78 */     float diff = yaw - prevYaw;
/*     */     
/*  80 */     if (diff < -180.0F || diff > 180.0F) {
/*     */       
/*  82 */       float round = Math.round(Math.abs(diff / 360.0F));
/*  83 */       diff = (diff < 0.0F) ? (diff + 360.0F * round) : (diff - 360.0F * round);
/*     */     } 
/*     */     
/*  86 */     return new float[] { prevYaw + diff, pitch };
/*     */   }
/*     */ 
/*     */   
/*     */   public static float[] getRotations(double x, double y, double z, Entity f) {
/*  91 */     return getRotations(x, y, z, f.posX, f.posY, f.posZ, f.getEyeHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vec3d getVec3d(float yaw, float pitch) {
/*  97 */     float vx = -MathHelper.sin(MathUtil.rad(yaw)) * MathHelper.cos(MathUtil.rad(pitch));
/*  98 */     float vz = MathHelper.cos(MathUtil.rad(yaw)) * MathHelper.cos(MathUtil.rad(pitch));
/*  99 */     float vy = -MathHelper.sin(MathUtil.rad(pitch));
/* 100 */     return new Vec3d(vx, vy, vz);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityPlayer getRotationPlayer() {
/* 105 */     EntityPlayerSP entityPlayerSP = mc.player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     return (entityPlayerSP == null) ? (EntityPlayer)mc.player : (EntityPlayer)entityPlayerSP;
/*     */   }
/*     */   public static float[] getNeededRotations(Vec3d vec) {
/* 114 */     Vec3d playerVector = new Vec3d(mc.player.posX, mc.player.posY + mc.player.getEyeHeight(), mc.player.posZ);
/* 115 */     double y = vec.y - playerVector.y;
/* 116 */     double x = vec.x - playerVector.x;
/* 117 */     double z = vec.z - playerVector.z;
/* 118 */     double dff = Math.sqrt(x * x + z * z);
/* 119 */     float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0F;
/* 120 */     float pitch = (float)-Math.toDegrees(Math.atan2(y, dff));
/* 121 */     return new float[] { MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch) };
/*     */   }
/*     */   
/*     */   public static float[] getNeededFacing(Vec3d target, Vec3d from) {
/* 125 */     double diffX = target.x - from.x;
/* 126 */     double diffY = target.y - from.y;
/* 127 */     double diffZ = target.z - from.z;
/* 128 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/* 129 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 130 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/* 131 */     return new float[] { MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch) };
/*     */   }
/*     */   public static float[] getRotations(Vec3d from, Vec3d to) {
/* 134 */     double difX = to.x - from.x;
/* 135 */     double difY = (to.y - from.y) * -1.0D;
/* 136 */     double difZ = to.z - from.z;
/* 137 */     double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
/* 138 */     return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */   public static boolean isInFov(BlockPos pos) {
/* 141 */     return (pos != null && (mc.player.getDistanceSq(pos) < 4.0D || isInFov(new Vec3d((Vec3i)pos), mc.player.getPositionVector())));
/*     */   }
/*     */   public static float[] getRotations(EntityLivingBase ent) {
/* 144 */     double x = ent.posX;
/* 145 */     double z = ent.posZ;
/* 146 */     double y = ent.posY + (ent.getEyeHeight() / 2.0F);
/* 147 */     return getRotationFromPosition(x, z, y);
/*     */   }
/*     */   public static float[] getRotationFromPosition(double x, double z, double y) {
/* 150 */     double xDiff = x - (Minecraft.getMinecraft()).player.posX;
/* 151 */     double zDiff = z - (Minecraft.getMinecraft()).player.posZ;
/* 152 */     double yDiff = y - (Minecraft.getMinecraft()).player.posY - 1.2D;
/* 153 */     double dist = MathHelper.sqrt(xDiff * xDiff + zDiff * zDiff);
/* 154 */     float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0D / Math.PI) - 90.0F;
/* 155 */     float pitch = (float)(-Math.atan2(yDiff, dist) * 180.0D / Math.PI);
/* 156 */     return new float[] { yaw, pitch };
/*     */   }
/*     */   public static boolean isInFov(Vec3d vec3d, Vec3d other) {
/* 159 */     if (mc.player.rotationPitch > 30.0F) {
/* 160 */       if (other.y > mc.player.posY) {
/* 161 */         return true;
/*     */       }
/*     */     }
/* 164 */     else if (mc.player.rotationPitch < -30.0F && other.y < mc.player.posY) {
/* 165 */       return true;
/*     */     } 
/* 167 */     float angle = MathUtil.calcAngleNoY(vec3d, other)[0] - transformYaw();
/* 168 */     if (angle < -270.0F) {
/* 169 */       return true;
/*     */     }
/* 171 */     float fov = mc.gameSettings.fovSetting / 2.0F;
/* 172 */     return (angle < fov + 10.0F && angle > -fov - 10.0F);
/*     */   }
/*     */   public static float transformYaw() {
/* 175 */     float yaw = mc.player.rotationYaw % 360.0F;
/* 176 */     if (mc.player.rotationYaw > 0.0F && 
/* 177 */       yaw > 180.0F) {
/* 178 */       yaw = -180.0F + yaw - 180.0F;
/*     */     }
/*     */     
/* 181 */     return yaw;
/*     */   }
/*     */   public static float[] getRotationsBlock(BlockPos block, EnumFacing face, boolean Legit) {
/* 184 */     double x = block.getX() + 0.5D - mc.player.posX + face.getXOffset() / 2.0D;
/* 185 */     double z = block.getZ() + 0.5D - mc.player.posZ + face.getZOffset() / 2.0D;
/* 186 */     double y = block.getY() + 0.5D;
/*     */     
/* 188 */     if (Legit) {
/* 189 */       y += 0.5D;
/*     */     }
/* 191 */     double d1 = mc.player.posY + mc.player.getEyeHeight() - y;
/* 192 */     double d3 = MathHelper.sqrt(x * x + z * z);
/* 193 */     float yaw = (float)(Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
/* 194 */     float pitch = (float)(Math.atan2(d1, d3) * 180.0D / Math.PI);
/*     */     
/* 196 */     if (yaw < 0.0F) {
/* 197 */       yaw += 360.0F;
/*     */     }
/* 199 */     return new float[] { yaw, pitch };
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\combat\RotationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
