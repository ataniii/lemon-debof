//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.world.combat;
/*     */ 
/*     */ import com.lemonclient.api.util.world.BlockUtil;
/*     */ import com.lemonclient.client.module.modules.qwq.LemonAura;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.item.EntityEnderCrystal;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.CombatRules;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ 
/*     */ 
/*     */ public class DamageUtil
/*     */ {
/*     */   public static float calculateDamage(EntityLivingBase entity, EntityEnderCrystal crystal) {
/*  29 */     return calculateCrystalDamage(entity, crystal.posX, crystal.posY, crystal.posZ);
/*     */   }
/*     */   
/*     */   public static float calculateDamage(EntityLivingBase entity, double posX, double posY, double posZ, float size, String mode) {
/*  33 */     Vec3d entityPos = entity.getPositionVector();
/*  34 */     AxisAlignedBB entityBox = entity.getEntityBoundingBox();
/*  35 */     BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
/*  36 */     boolean isPlayer = entity instanceof net.minecraft.entity.player.EntityPlayer;
/*  37 */     if (isPlayer && entity.world.getDifficulty() == EnumDifficulty.PEACEFUL) return 0.0F;
/*     */     
/*  39 */     float damage = calcRawDamage(entity, entityPos, entityBox, posX, posY, posZ, size * 2.0F, mutableBlockPos, mode);
/*     */     
/*  41 */     if (isPlayer) damage = calcDifficultyDamage(entity, damage); 
/*  42 */     return calcReductionDamage(entity, damage);
/*     */   }
/*     */   public static float calculateCrystalDamage(EntityLivingBase entity, double posX, double posY, double posZ) {
/*     */     float damage;
/*  46 */     Vec3d entityPos = entity.getPositionVector();
/*  47 */     BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
/*  48 */     boolean isPlayer = entity instanceof net.minecraft.entity.player.EntityPlayer;
/*  49 */     if (isPlayer && entity.world.getDifficulty() == EnumDifficulty.PEACEFUL) return 0.0F;
/*     */     
/*  51 */     mutableBlockPos.setPos((int)posX, (int)posY - 1, (int)posZ);
/*     */ 
/*     */     
/*  54 */     if (isPlayer && posY - entityPos.y > 1.5652173822904127D && isResistant(entity.world.getBlockState((BlockPos)mutableBlockPos))) {
/*  55 */       damage = 1.0F;
/*     */     } else {
/*  57 */       float scaledDist = (float)(entityPos.distanceTo(new Vec3d(posX, posY, posZ)) / 12.0D);
/*  58 */       if (scaledDist > 1.0F) { damage = 0.0F;
/*     */          }
/*     */       
/*     */       else
/*     */       
/*  63 */       { float blockDensity = ((Boolean)LemonAura.INSTANCE.ignoreTerrain.getValue()).booleanValue() ? ignoreTerrainDensity(new Vec3d(posX, posY, posZ), entity.getEntityBoundingBox(), entity, "Crystal") : entity.world.getBlockDensity(new Vec3d(posX, posY, posZ), entity.getEntityBoundingBox());
/*     */         
/*  65 */         float factor = (1.0F - scaledDist) * blockDensity;
/*  66 */         damage = Math.abs((factor * factor + factor) * 12.0F * 3.5F); }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/*  71 */     if (isPlayer) damage = calcDifficultyDamage(entity, damage); 
/*  72 */     return calcReductionDamage(entity, damage);
/*     */   }
/*     */   
/*     */   public static float ignoreTerrainDensity(Vec3d vec, AxisAlignedBB bb, EntityLivingBase entity, String mode) {
/*  76 */     double d0 = 1.0D / ((bb.maxX - bb.minX) * 2.0D + 1.0D);
/*  77 */     double d1 = 1.0D / ((bb.maxY - bb.minY) * 2.0D + 1.0D);
/*  78 */     double d2 = 1.0D / ((bb.maxZ - bb.minZ) * 2.0D + 1.0D);
/*  79 */     double d3 = (1.0D - Math.floor(1.0D / d0) * d0) / 2.0D;
/*  80 */     double d4 = (1.0D - Math.floor(1.0D / d2) * d2) / 2.0D;
/*     */     
/*  82 */     if (d0 >= 0.0D && d1 >= 0.0D && d2 >= 0.0D) {
/*  83 */       int j2 = 0;
/*  84 */       int k2 = 0;
/*     */       float f;
/*  86 */       for (f = 0.0F; f <= 1.0F; f = (float)(f + d0)) {
/*  87 */         float f1; for (f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d1)) {
/*  88 */           float f2; for (f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d2)) {
/*  89 */             double d5 = bb.minX + (bb.maxX - bb.minX) * f;
/*  90 */             double d6 = bb.minY + (bb.maxY - bb.minY) * f1;
/*  91 */             double d7 = bb.minZ + (bb.maxZ - bb.minZ) * f2;
/*  92 */             Vec3d newVec = new Vec3d(d5 + d3, d6, d7 + d4);
/*  93 */             RayTraceResult result = entity.world.rayTraceBlocks(newVec, vec);
/*     */             
/*  95 */             if (result == null) {
/*  96 */               j2++;
/*     */             } else {
/*  98 */               IBlockState state = BlockUtil.getState(result.getBlockPos());
/*  99 */               if (getRaytrace(entity, mode, result.getBlockPos(), state).equals("SKIP")) j2++;
/*     */             
/*     */             } 
/* 102 */             k2++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 107 */       return j2 / k2;
/* 108 */     }  return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float calcReductionDamage(EntityLivingBase entity, float damage) {
/* 113 */     PotionEffect potionEffect = entity.getActivePotionEffect(MobEffects.RESISTANCE);
/* 114 */     float resistance = (potionEffect == null) ? 1.0F : Math.max(1.0F - (potionEffect.getAmplifier() + 1) * 0.2F, 0.0F);
/* 115 */     float blastReduction = 1.0F - Math.min(calcTotalEPF(entity), 20) / 25.0F;
/* 116 */     return CombatRules.getDamageAfterAbsorb(damage, entity.getTotalArmorValue(), (float)entity.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue()) * resistance * blastReduction;
/*     */   }
/*     */   
/*     */   public static int calcTotalEPF(EntityLivingBase entity) {
/* 120 */     int epf = 0;
/* 121 */     for (ItemStack itemStack : entity.getArmorInventoryList()) {
/* 122 */       NBTTagList nbtTagList = itemStack.getEnchantmentTagList();
/* 123 */       for (int i = 0; i <= nbtTagList.tagCount(); i++) {
/* 124 */         NBTTagCompound nbtTagCompound = nbtTagList.getCompoundTagAt(i);
/* 125 */         int id = nbtTagCompound.getInteger("id");
/* 126 */         int level = nbtTagCompound.getShort("lvl");
/* 127 */         if (id == 0) {
/*     */           
/* 129 */           epf += level;
/* 130 */         } else if (id == 3) {
/*     */           
/* 132 */           epf += level * 2;
/*     */         } 
/*     */       } 
/*     */     } 
/* 136 */     return epf;
/*     */   }
/*     */   
/*     */   public static float calcDifficultyDamage(EntityLivingBase entity, float damage) {
/* 140 */     switch (entity.world.getDifficulty()) { case PEACEFUL:
/* 141 */         return 0.0F;
/* 142 */       case EASY: return Math.min(damage * 0.5F + 1.0F, damage);
/* 143 */       case HARD: return damage * 1.5F; }
/* 144 */      return damage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static float calcDamage(EntityLivingBase entity, double crystalX, double crystalY, double crystalZ) {
/*     */     float damage;
/* 151 */     Vec3d entityPos = entity.getPositionVector();
/* 152 */     AxisAlignedBB entityBox = entity.getEntityBoundingBox();
/* 153 */     BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
/* 154 */     boolean isPlayer = entity instanceof net.minecraft.entity.player.EntityPlayer;
/* 155 */     if (isPlayer && entity.world.getDifficulty() == EnumDifficulty.PEACEFUL) return 0.0F;
/*     */ 
/*     */     
/* 158 */     mutableBlockPos.setPos((int)crystalX, (int)crystalY - 1, (int)crystalZ);
/* 159 */     if (isPlayer && crystalY - entityPos.y > 1.5652173822904127D && isResistant(entity.world.getBlockState((BlockPos)mutableBlockPos))) {
/* 160 */       damage = 1.0F;
/*     */     } else {
/* 162 */       damage = calcRawDamage(entity, entityPos, entityBox, crystalX, crystalY, crystalZ, 12.0F, mutableBlockPos, "Crystal");
/*     */     } 
/*     */     
/* 165 */     if (isPlayer) damage = calcDifficultyDamage(entity, damage); 
/* 166 */     return calcReductionDamage(entity, damage);
/*     */   }
/*     */   
/*     */   private static float calcRawDamage(EntityLivingBase entity, Vec3d entityPos, AxisAlignedBB entityBox, double posX, double posY, double posZ, float doubleSize, BlockPos.MutableBlockPos mutableBlockPos, String mode) {
/* 170 */     float scaledDist = (float)(entityPos.distanceTo(new Vec3d(posX, posY, posZ)) / doubleSize);
/* 171 */     if (scaledDist > 1.0F) return 0.0F; 
/* 172 */     float factor = (1.0F - scaledDist) * ignoreTerrainDensity(new Vec3d(posX, posY, posZ), entityBox, entity, mode);
/* 173 */     return (factor * factor + factor) * doubleSize * 3.5F + 1.0F;
/*     */   }
/*     */   
/*     */   public static boolean isResistant(IBlockState blockState) {
/* 177 */     return (blockState.getMaterial() != Material.AIR && !(blockState instanceof net.minecraft.block.BlockLiquid) && (blockState.getBlock()).blockResistance >= 19.7D);
/*     */   }
/*     */   
/*     */   private static float getExposureAmount(EntityLivingBase entity, AxisAlignedBB entityBox, double posX, double posY, double posZ, BlockPos.MutableBlockPos mutableBlockPos, String mode) {
/* 181 */     double width = entityBox.maxX - entityBox.minX;
/* 182 */     double height = entityBox.maxY - entityBox.minY;
/*     */     
/* 184 */     double gridMultiplierXZ = 1.0D / (width * 2.0D + 1.0D);
/* 185 */     double gridMultiplierY = 1.0D / (height * 2.0D + 1.0D);
/*     */     
/* 187 */     double gridXZ = width * gridMultiplierXZ;
/* 188 */     double gridY = height * gridMultiplierY;
/*     */     
/* 190 */     int sizeXZ = (int)(1.0D / gridMultiplierXZ);
/* 191 */     int sizeY = (int)(1.0D / gridMultiplierY);
/* 192 */     double xzOffset = (1.0D - gridMultiplierXZ * sizeXZ) / 2.0D;
/*     */     
/* 194 */     int total = 0;
/* 195 */     int count = 0;
/*     */     
/* 197 */     for (int yIndex = 0; yIndex <= sizeY; yIndex++) {
/* 198 */       for (int xIndex = 0; xIndex <= sizeXZ; xIndex++) {
/* 199 */         for (int zIndex = 0; zIndex <= sizeXZ; zIndex++) {
/* 200 */           double x = gridXZ * xIndex + xzOffset + entityBox.minX;
/* 201 */           double y = gridY * yIndex + entityBox.minY;
/* 202 */           double z = gridXZ * zIndex + xzOffset + entityBox.minZ;
/*     */           
/* 204 */           total++;
/*     */           
/* 206 */           if (!fastRayTrace(entity, x, y, z, posX, posY, posZ, 20, mutableBlockPos, mode)) {
/* 207 */             count++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 214 */     return count / total;
/*     */   }
/*     */   
/*     */   public static boolean fastRayTrace(EntityLivingBase entity, double startX, double startY, double startZ, double endX, double endY, double endZ, int maxAttempt, BlockPos.MutableBlockPos mutableBlockPos, String mode) {
/* 218 */     double currentX = startX;
/* 219 */     double currentY = startY;
/* 220 */     double currentZ = startZ;
/*     */ 
/*     */     
/* 223 */     int currentBlockX = (int)currentX;
/* 224 */     int currentBlockY = (int)currentY;
/* 225 */     int currentBlockZ = (int)currentZ;
/*     */ 
/*     */     
/* 228 */     mutableBlockPos.setPos(currentBlockX, currentBlockY, currentBlockZ);
/*     */     
/* 230 */     IBlockState startBlockState = BlockUtil.getState((BlockPos)mutableBlockPos);
/* 231 */     switch (getRaytrace(entity, mode, (BlockPos)mutableBlockPos, startBlockState)) { case "MISC":
/* 232 */         return false;
/* 233 */       case "CALC": if (rayTraceBlock(entity, startBlockState, mutableBlockPos, currentX, currentY, currentZ, endX, endY, endZ)) return true;
/*     */         
/*     */         break; }
/*     */ 
/*     */     
/* 238 */     int endBlockX = (int)endX;
/* 239 */     int endBlockY = (int)endY;
/* 240 */     int endBlockZ = (int)endZ;
/*     */     
/* 242 */     int count = maxAttempt;
/*     */     
/* 244 */     while (count-- >= 0) {
/* 245 */       if (currentBlockX == endBlockX && currentBlockY == endBlockY && currentBlockZ == endBlockZ) {
/* 246 */         return false;
/*     */       }
/*     */       
/* 249 */       int nextX = 999;
/* 250 */       int nextY = 999;
/* 251 */       int nextZ = 999;
/*     */       
/* 253 */       double stepX = 999.0D;
/* 254 */       double stepY = 999.0D;
/* 255 */       double stepZ = 999.0D;
/* 256 */       double diffX = endX - currentX;
/* 257 */       double diffY = endY - currentY;
/* 258 */       double diffZ = endZ - currentZ;
/*     */       
/* 260 */       if (endBlockX > currentBlockX) {
/* 261 */         nextX = currentBlockX + 1;
/* 262 */         stepX = (nextX - currentX) / diffX;
/* 263 */       } else if (endBlockX < currentBlockX) {
/* 264 */         nextX = currentBlockX;
/* 265 */         stepX = (nextX - currentX) / diffX;
/*     */       } 
/*     */       
/* 268 */       if (endBlockY > currentBlockY) {
/* 269 */         nextY = currentBlockY + 1;
/* 270 */         stepY = (nextY - currentY) / diffY;
/* 271 */       } else if (endBlockY < currentBlockY) {
/* 272 */         nextY = currentBlockY;
/* 273 */         stepY = (nextY - currentY) / diffY;
/*     */       } 
/*     */       
/* 276 */       if (endBlockZ > currentBlockZ) {
/* 277 */         nextZ = currentBlockZ + 1;
/* 278 */         stepZ = (nextZ - currentZ) / diffZ;
/* 279 */       } else if (endBlockZ < currentBlockZ) {
/* 280 */         nextZ = currentBlockZ;
/* 281 */         stepZ = (nextZ - currentZ) / diffZ;
/*     */       } 
/*     */       
/* 284 */       if (stepX < stepY && stepX < stepZ) {
/* 285 */         currentX = nextX;
/* 286 */         currentY += diffY * stepX;
/* 287 */         currentZ += diffZ * stepX;
/*     */         
/* 289 */         currentBlockX = nextX - (endBlockX - currentBlockX >>> 31);
/* 290 */         currentBlockY = (int)currentY;
/* 291 */         currentBlockZ = (int)currentZ;
/* 292 */       } else if (stepY < stepZ) {
/* 293 */         currentX += diffX * stepY;
/* 294 */         currentY = nextY;
/* 295 */         currentZ += diffZ * stepY;
/*     */         
/* 297 */         currentBlockX = (int)currentX;
/* 298 */         currentBlockY = nextY - (endBlockY - currentBlockY >>> 31);
/* 299 */         currentBlockZ = (int)currentZ;
/*     */       } else {
/* 301 */         currentX += diffX * stepZ;
/* 302 */         currentY += diffY * stepZ;
/* 303 */         currentZ = nextZ;
/*     */         
/* 305 */         currentBlockX = (int)currentX;
/* 306 */         currentBlockY = (int)currentY;
/* 307 */         currentBlockZ = nextZ - (endBlockZ - currentBlockZ >>> 31);
/*     */       } 
/*     */       
/* 310 */       mutableBlockPos.setPos(currentBlockX, currentBlockY, currentBlockZ);
/* 311 */       if (entity.world.isOutsideBuildHeight((BlockPos)mutableBlockPos) || !entity.world.getWorldBorder().contains((BlockPos)mutableBlockPos))
/*     */         continue; 
/* 313 */       IBlockState blockState = BlockUtil.getState((BlockPos)mutableBlockPos);
/* 314 */       switch (getRaytrace(entity, mode, (BlockPos)mutableBlockPos, blockState)) { case "MISC":
/* 315 */           return false;
/* 316 */         case "CALC": if (rayTraceBlock(entity, blockState, mutableBlockPos, currentX, currentY, currentZ, endX, endY, endZ)) return true;
/*     */          }
/*     */ 
/*     */     
/*     */     } 
/* 321 */     return false;
/*     */   }
/*     */   public static String getRaytrace(EntityLivingBase entity, String mode, BlockPos pos, IBlockState blockState) {
/*     */     Block block;
/* 325 */     switch (mode) {
/*     */       case "Crystal":
/* 327 */         if (isResistant(blockState)) return "CALC"; 
/* 328 */         return "SKIP";
/*     */       
/*     */       case "Bed":
/* 331 */         block = blockState.getBlock();
/* 332 */         if (block == Blocks.AIR || block == Blocks.BED || !isResistant(blockState)) return "SKIP"; 
/* 333 */         return "CALC";
/*     */       
/*     */       case "Calc":
/* 336 */         return "Calc";
/*     */       
/*     */       case "Skip":
/* 339 */         return "Skip";
/*     */     } 
/*     */     
/* 342 */     return (blockState.getCollisionBoundingBox((IBlockAccess)entity.world, pos) != null) ? "CALC" : "SKIP";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean rayTraceBlock(EntityLivingBase entity, IBlockState blockState, BlockPos.MutableBlockPos blockPos, double x1, double y1, double z1, double x2, double y2, double z2) {
/* 348 */     float x1f = (float)(x1 - blockPos.getX());
/* 349 */     float y1f = (float)(y1 - blockPos.getY());
/* 350 */     float z1f = (float)(z1 - blockPos.getZ());
/*     */     
/* 352 */     float x2f = (float)(x2 - blockPos.getX());
/* 353 */     float y2f = (float)(y2 - blockPos.getY());
/* 354 */     float z2f = (float)(z2 - blockPos.getZ());
/*     */     
/* 356 */     AxisAlignedBB box = blockState.getBoundingBox((IBlockAccess)entity.world, (BlockPos)blockPos);
/*     */     
/* 358 */     float minX = (float)box.minX;
/* 359 */     float minY = (float)box.minY;
/* 360 */     float minZ = (float)box.minZ;
/* 361 */     float maxX = (float)box.maxX;
/* 362 */     float maxY = (float)box.maxY;
/* 363 */     float maxZ = (float)box.maxZ;
/*     */     
/* 365 */     float xDiff = x2f - x1f;
/* 366 */     float yDiff = y2f - y1f;
/* 367 */     float zDiff = z2f - z1f;
/*     */     
/* 369 */     if (xDiff * xDiff >= 1.0E-7F) {
/* 370 */       double factor = ((minX - x1f) / xDiff);
/* 371 */       if (!in(factor, 0.0D, 1.0D)) factor = ((maxX - x1f) / xDiff);
/*     */       
/* 373 */       if (in(factor, 0.0D, 1.0D) && in(y1f + yDiff * factor, minY, maxY) && in(z1f + zDiff * factor, minZ, maxZ)) {
/* 374 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 378 */     if (yDiff * yDiff >= 1.0E-7F) {
/* 379 */       double factor = ((minY - y1f) / yDiff);
/* 380 */       if (!in(factor, 0.0D, 1.0D)) factor = ((maxY - y1f) / yDiff);
/*     */       
/* 382 */       if (in(factor, 0.0D, 1.0D) && in(x1f + xDiff * factor, minX, maxX) && in(z1f + zDiff * factor, minZ, maxZ)) {
/* 383 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 387 */     if ((zDiff * zDiff) >= 1.0E-7D) {
/* 388 */       double factor = ((minZ - z1f) / zDiff);
/* 389 */       if (!in(factor, 0.0D, 1.0D)) factor = ((maxZ - z1f) / zDiff);
/*     */       
/* 391 */       return (in(factor, 0.0D, 1.0D) && in(x1f + xDiff * factor, minX, maxX) && in(y1f + yDiff * factor, minY, maxY));
/*     */     } 
/*     */     
/* 394 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean in(double number, double floor, double ceil) {
/* 398 */     return (number >= floor && number <= ceil);
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\world\combat\DamageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
