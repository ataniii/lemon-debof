//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*     */ package com.lemonclient.api.util.font;
/*     */ 
/*     */ import com.lemonclient.api.util.render.GSColor;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class CFontRenderer
/*     */   extends CFont {
/*  14 */   protected CFont.CharData[] boldChars = new CFont.CharData[256];
/*  15 */   protected CFont.CharData[] italicChars = new CFont.CharData[256];
/*  16 */   protected CFont.CharData[] boldItalicChars = new CFont.CharData[256];
/*     */   
/*  18 */   private final int[] colorCode = new int[32]; String fontName; int fontSize; boolean noAlias; boolean metrics;
/*  19 */   private final String colorcodeIdentifiers = "0123456789abcdefklmnor"; protected DynamicTexture texBold; protected DynamicTexture texItalic; protected DynamicTexture texItalicBold;
/*     */   
/*     */   public CFontRenderer(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  22 */     super(font, antiAlias, fractionalMetrics);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  27 */     this.fontName = "Arial";
/*  28 */     this.fontSize = 18;
/*  29 */     this.noAlias = false;
/*  30 */     this.metrics = true;
/*     */     setupMinecraftColorcodes();
/*     */     setupBoldItalicIDs(); } public String getFontName() {
/*  33 */     return this.fontName;
/*     */   }
/*     */   
/*     */   public int getFontSize() {
/*  37 */     return this.fontSize;
/*     */   }
/*     */   
/*     */   public void setFontName(String newName) {
/*  41 */     this.fontName = newName;
/*     */   }
/*     */   
/*     */   public void setFontSize(int newSize) {
/*  45 */     this.fontSize = newSize;
/*     */   }
/*     */   
/*     */   public float drawStringWithShadow(String text, double x, double y, GSColor color) {
/*  49 */     float shadowWidth = drawString(text, x + 1.0D, y + 1.0D, color, true);
/*  50 */     return Math.max(shadowWidth, drawString(text, x, y, color, false));
/*     */   }
/*     */   
/*     */   public float drawString(String text, float x, float y, GSColor color) {
/*  54 */     return drawString(text, x, y, color, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public float drawCenteredStringWithShadow(String text, float x, float y, GSColor color) {
/*  59 */     return drawStringWithShadow(text, (x - (getStringWidth(text) / 2)), y, color);
/*     */   }
/*     */   
/*     */   public float drawCenteredString(String text, float x, float y, GSColor color) {
/*  63 */     return drawString(text, x - (getStringWidth(text) / 2), y, color);
/*     */   }
/*     */   
/*     */   public float drawString(String text, double x, double y, GSColor gsColor, boolean shadow) {
/*  67 */     x--;
/*  68 */     y -= 2.0D;
/*  69 */     GSColor color = new GSColor((Color)gsColor);
/*  70 */     if (text == null) return 0.0F; 
/*  71 */     if (color.getRed() == 255 && color.getGreen() == 255 && color.getBlue() == 255 && color.getAlpha() == 32)
/*  72 */       color = new GSColor(255, 255, 255); 
/*  73 */     if (color.getAlpha() < 4) color = new GSColor(color, 255); 
/*  74 */     if (shadow) {
/*  75 */       color = new GSColor(color.getRed() / 4, color.getGreen() / 4, color.getBlue() / 4, color.getAlpha());
/*     */     }
/*  77 */     CFont.CharData[] currentData = this.charData;
/*  78 */     boolean randomCase = false;
/*  79 */     boolean bold = false;
/*  80 */     boolean italic = false;
/*  81 */     boolean strikethrough = false;
/*  82 */     boolean underline = false;
/*  83 */     boolean render = true;
/*  84 */     x *= 2.0D;
/*  85 */     y *= 2.0D;
/*  86 */     if (render) {
/*  87 */       GlStateManager.pushMatrix();
/*  88 */       GlStateManager.scale(0.5D, 0.5D, 0.5D);
/*  89 */       GlStateManager.enableBlend();
/*  90 */       GlStateManager.blendFunc(770, 771);
/*  91 */       GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  92 */       int size = text.length();
/*  93 */       GlStateManager.enableTexture2D();
/*  94 */       GlStateManager.bindTexture(this.tex.getGlTextureId());
/*     */       
/*  96 */       for (int i = 0; i < size; i++) {
/*  97 */         char character = text.charAt(i);
/*  98 */         if (character == '§' && i < size) {
/*  99 */           int colorIndex = 21;
/*     */           try {
/* 101 */             colorIndex = "0123456789abcdefklmnor".indexOf(text.charAt(i + 1));
/* 102 */           } catch (Exception exception) {}
/*     */ 
/*     */           
/* 105 */           if (colorIndex < 16) {
/* 106 */             bold = false;
/* 107 */             italic = false;
/* 108 */             randomCase = false;
/* 109 */             underline = false;
/* 110 */             strikethrough = false;
/* 111 */             GlStateManager.bindTexture(this.tex.getGlTextureId());
/*     */ 
/*     */             
/* 114 */             currentData = this.charData;
/* 115 */             if (colorIndex < 0 || colorIndex > 15) colorIndex = 15; 
/* 116 */             if (shadow) colorIndex += 16; 
/* 117 */             int colorcode = this.colorCode[colorIndex];
/* 118 */             GlStateManager.color((colorcode >> 16 & 0xFF) / 255.0F, (colorcode >> 8 & 0xFF) / 255.0F, (colorcode & 0xFF) / 255.0F, color.getAlpha());
/* 119 */           } else if (colorIndex == 16) {
/* 120 */             randomCase = true;
/* 121 */           } else if (colorIndex == 17) {
/* 122 */             bold = true;
/* 123 */             if (italic) {
/* 124 */               GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
/*     */ 
/*     */               
/* 127 */               currentData = this.boldItalicChars;
/*     */             } else {
/* 129 */               GlStateManager.bindTexture(this.texBold.getGlTextureId());
/*     */ 
/*     */               
/* 132 */               currentData = this.boldChars;
/*     */             } 
/* 134 */           } else if (colorIndex == 18) {
/* 135 */             strikethrough = true;
/* 136 */           } else if (colorIndex == 19) {
/* 137 */             underline = true;
/* 138 */           } else if (colorIndex == 20) {
/* 139 */             italic = true;
/* 140 */             if (bold) {
/* 141 */               GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
/*     */ 
/*     */               
/* 144 */               currentData = this.boldItalicChars;
/*     */             } else {
/* 146 */               GlStateManager.bindTexture(this.texItalic.getGlTextureId());
/*     */ 
/*     */               
/* 149 */               currentData = this.italicChars;
/*     */             } 
/* 151 */           } else if (colorIndex == 21) {
/* 152 */             bold = false;
/* 153 */             italic = false;
/* 154 */             randomCase = false;
/* 155 */             underline = false;
/* 156 */             strikethrough = false;
/* 157 */             GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 158 */             GlStateManager.bindTexture(this.tex.getGlTextureId());
/*     */ 
/*     */             
/* 161 */             currentData = this.charData;
/*     */           } 
/* 163 */           i++;
/* 164 */         } else if (character < currentData.length && character >= '\000') {
/* 165 */           GlStateManager.glBegin(4);
/* 166 */           drawChar(currentData, character, (float)x, (float)y);
/* 167 */           GlStateManager.glEnd();
/* 168 */           if (strikethrough)
/* 169 */             drawLine(x, y + ((currentData[character]).height / 2), x + (currentData[character]).width - 8.0D, y + ((currentData[character]).height / 2), 1.0F); 
/* 170 */           if (underline)
/* 171 */             drawLine(x, y + (currentData[character]).height - 2.0D, x + (currentData[character]).width - 8.0D, y + (currentData[character]).height - 2.0D, 1.0F); 
/* 172 */           x += ((currentData[character]).width - 8 + this.charOffset);
/*     */         } 
/*     */       } 
/* 175 */       GL11.glHint(3155, 4352);
/* 176 */       GlStateManager.popMatrix();
/*     */     } 
/* 178 */     return (float)x / 2.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStringWidth(String text) {
/* 183 */     if (text == null) {
/* 184 */       return 0;
/*     */     }
/* 186 */     int width = 0;
/* 187 */     CFont.CharData[] currentData = this.charData;
/* 188 */     boolean bold = false;
/* 189 */     boolean italic = false;
/* 190 */     int size = text.length();
/*     */     
/* 192 */     for (int i = 0; i < size; i++) {
/* 193 */       char character = text.charAt(i);
/* 194 */       if (character == '§' && i < size) {
/* 195 */         int colorIndex = "0123456789abcdefklmnor".indexOf(character);
/* 196 */         if (colorIndex < 16) {
/* 197 */           bold = false;
/* 198 */           italic = false;
/* 199 */         } else if (colorIndex == 17) {
/* 200 */           bold = true;
/* 201 */           if (italic) {
/* 202 */             currentData = this.boldItalicChars;
/*     */           } else {
/* 204 */             currentData = this.boldChars;
/*     */           } 
/* 206 */         } else if (colorIndex == 20) {
/* 207 */           italic = true;
/* 208 */           if (bold) {
/* 209 */             currentData = this.boldItalicChars;
/*     */           } else {
/* 211 */             currentData = this.italicChars;
/*     */           } 
/* 213 */         } else if (colorIndex == 21) {
/* 214 */           bold = false;
/* 215 */           italic = false;
/* 216 */           currentData = this.charData;
/*     */         } 
/* 218 */         i++;
/* 219 */       } else if (character < currentData.length && character >= '\000') {
/* 220 */         width += (currentData[character]).width - 8 + this.charOffset;
/*     */       } 
/*     */     } 
/* 223 */     return width / 2;
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/* 227 */     super.setFont(font);
/* 228 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   public boolean getAntiAlias() {
/* 232 */     return this.noAlias;
/*     */   }
/*     */   
/*     */   public boolean getFractionalMetrics() {
/* 236 */     return this.metrics;
/*     */   }
/*     */   
/*     */   public void setAntiAlias(boolean antiAlias) {
/* 240 */     this.noAlias = antiAlias;
/* 241 */     super.setAntiAlias(antiAlias);
/* 242 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   public void setFractionalMetrics(boolean fractionalMetrics) {
/* 246 */     this.metrics = fractionalMetrics;
/* 247 */     super.setFractionalMetrics(fractionalMetrics);
/* 248 */     setupBoldItalicIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupBoldItalicIDs() {
/* 256 */     this.texBold = setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
/* 257 */     this.texItalic = setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
/* 258 */     this.texItalicBold = setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
/*     */   }
/*     */   
/*     */   private void drawLine(double x, double y, double x1, double y1, float width) {
/* 262 */     GlStateManager.disableTexture2D();
/* 263 */     GlStateManager.glLineWidth(width);
/* 264 */     GlStateManager.glBegin(1);
/* 265 */     GL11.glVertex2d(x, y);
/* 266 */     GL11.glVertex2d(x1, y1);
/* 267 */     GlStateManager.glEnd();
/* 268 */     GlStateManager.enableTexture2D();
/*     */   }
/*     */   
/*     */   public List<String> wrapWords(String text, double width) {
/* 272 */     List<String> finalWords = new ArrayList();
/* 273 */     if (getStringWidth(text) > width) {
/* 274 */       String[] words = text.split(" ");
/* 275 */       String currentWord = "";
/* 276 */       char lastColorCode = Character.MAX_VALUE;
/*     */       
/* 278 */       for (String word : words) {
/* 279 */         for (int i = 0; i < (word.toCharArray()).length; i++) {
/* 280 */           char c = word.toCharArray()[i];
/*     */           
/* 282 */           if (c == '§' && i < (word.toCharArray()).length - 1) {
/* 283 */             lastColorCode = word.toCharArray()[i + 1];
/*     */           }
/*     */         } 
/* 286 */         if (getStringWidth(currentWord + word + " ") < width) {
/* 287 */           currentWord = currentWord + word + " ";
/*     */         } else {
/* 289 */           finalWords.add(currentWord);
/* 290 */           currentWord = "§" + lastColorCode + word + " ";
/*     */         } 
/*     */       } 
/* 293 */       if (currentWord.length() > 0) if (getStringWidth(currentWord) < width) {
/* 294 */           finalWords.add("§" + lastColorCode + currentWord + " ");
/* 295 */           currentWord = "";
/*     */         } else {
/* 297 */           for (String s : formatString(currentWord, width)) {
/* 298 */             finalWords.add(s);
/*     */           }
/*     */         }  
/*     */     } else {
/* 302 */       finalWords.add(text);
/*     */     } 
/* 304 */     return finalWords;
/*     */   }
/*     */   
/*     */   public List<String> formatString(String string, double width) {
/* 308 */     List<String> finalWords = new ArrayList();
/* 309 */     String currentWord = "";
/* 310 */     char lastColorCode = Character.MAX_VALUE;
/* 311 */     char[] chars = string.toCharArray();
/* 312 */     for (int i = 0; i < chars.length; i++) {
/* 313 */       char c = chars[i];
/*     */       
/* 315 */       if (c == '§' && i < chars.length - 1) {
/* 316 */         lastColorCode = chars[i + 1];
/*     */       }
/*     */       
/* 319 */       if (getStringWidth(currentWord + c) < width) {
/* 320 */         currentWord = currentWord + c;
/*     */       } else {
/* 322 */         finalWords.add(currentWord);
/* 323 */         currentWord = "§" + lastColorCode + c;
/*     */       } 
/*     */     } 
/*     */     
/* 327 */     if (currentWord.length() > 0) {
/* 328 */       finalWords.add(currentWord);
/*     */     }
/* 330 */     return finalWords;
/*     */   }
/*     */   
/*     */   private void setupMinecraftColorcodes() {
/* 334 */     for (int index = 0; index < 32; index++) {
/* 335 */       int noClue = (index >> 3 & 0x1) * 85;
/* 336 */       int red = (index >> 2 & 0x1) * 170 + noClue;
/* 337 */       int green = (index >> 1 & 0x1) * 170 + noClue;
/* 338 */       int blue = (index >> 0 & 0x1) * 170 + noClue;
/*     */       
/* 340 */       if (index == 6) {
/* 341 */         red += 85;
/*     */       }
/* 343 */       if (index >= 16) {
/* 344 */         red /= 4;
/* 345 */         green /= 4;
/* 346 */         blue /= 4;
/*     */       } 
/* 348 */       this.colorCode[index] = (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\font\CFontRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
