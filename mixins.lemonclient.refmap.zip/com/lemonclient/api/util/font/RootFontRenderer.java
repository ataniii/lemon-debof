//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.font;
/*    */ 
/*    */ import com.lemonclient.api.util.render.FontRenderer;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RootFontRenderer
/*    */   implements FontRenderer {
/*    */   private final float fontsize;
/* 12 */   private final FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRenderer;
/*    */   
/*    */   public RootFontRenderer(float fontsize) {
/* 15 */     this.fontsize = fontsize;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFontHeight() {
/* 20 */     return (int)((Minecraft.getMinecraft()).fontRenderer.FONT_HEIGHT * this.fontsize);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStringHeight(String text) {
/* 25 */     return getFontHeight();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStringWidth(String text) {
/* 30 */     return (int)(this.fontRenderer.getStringWidth(text) * this.fontsize);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawString(int x, int y, String text) {
/* 35 */     drawString(x, y, 255, 255, 255, text);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawString(int x, int y, int r, int g, int b, String text) {
/* 40 */     drawString(x, y, 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF, text);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawString(int x, int y, Color color, String text) {
/* 45 */     drawString(x, y, color.getRGB(), text);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawString(int x, int y, int colour, String text) {
/* 50 */     drawString(x, y, colour, text, true);
/*    */   }
/*    */   
/*    */   public void drawString(int x, int y, int colour, String text, boolean shadow) {
/* 54 */     prepare(x, y);
/* 55 */     (Minecraft.getMinecraft()).fontRenderer.drawString(text, 0.0F, 0.0F, colour, shadow);
/* 56 */     pop(x, y);
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawStringWithShadow(int x, int y, int r, int g, int b, String text) {
/* 61 */     drawString(x, y, 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF, text, true);
/*    */   }
/*    */   
/*    */   private void prepare(int x, int y) {
/* 65 */     GL11.glEnable(3553);
/* 66 */     GL11.glEnable(3042);
/* 67 */     GL11.glTranslatef(x, y, 0.0F);
/* 68 */     GL11.glScalef(this.fontsize, this.fontsize, 1.0F);
/* 69 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */   
/*    */   private void pop(int x, int y) {
/* 73 */     GL11.glScalef(1.0F / this.fontsize, 1.0F / this.fontsize, 1.0F);
/* 74 */     GL11.glTranslatef(-x, -y, 0.0F);
/* 75 */     GL11.glDisable(3553);
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\font\RootFontRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
