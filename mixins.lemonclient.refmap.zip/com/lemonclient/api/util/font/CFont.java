/*     */ package com.lemonclient.api.util.font;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class CFont {
/*  12 */   private final float imgSize = 512.0F;
/*  13 */   protected CharData[] charData = new CharData[256];
/*     */   protected Font font;
/*     */   protected boolean antiAlias;
/*     */   protected boolean fractionalMetrics;
/*  17 */   protected int fontHeight = -1;
/*  18 */   protected int charOffset = 0;
/*     */   protected DynamicTexture tex;
/*     */   
/*     */   public CFont(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  22 */     this.font = font;
/*  23 */     this.antiAlias = antiAlias;
/*  24 */     this.fractionalMetrics = fractionalMetrics;
/*  25 */     this.tex = setupTexture(font, antiAlias, fractionalMetrics, this.charData);
/*     */   }
/*     */   
/*     */   protected DynamicTexture setupTexture(Font font, boolean antiAlias, boolean fractionalMetrics, CharData[] chars) {
/*  29 */     BufferedImage img = generateFontImage(font, antiAlias, fractionalMetrics, chars);
/*     */     try {
/*  31 */       return new DynamicTexture(img);
/*  32 */     } catch (Exception e) {
/*  33 */       e.printStackTrace();
/*     */       
/*  35 */       return null;
/*     */     } 
/*     */   }
/*     */   protected BufferedImage generateFontImage(Font font, boolean antiAlias, boolean fractionalMetrics, CharData[] chars) {
/*  39 */     getClass(); int imgSize = 512;
/*  40 */     BufferedImage bufferedImage = new BufferedImage(imgSize, imgSize, 2);
/*  41 */     Graphics2D g = (Graphics2D)bufferedImage.getGraphics();
/*  42 */     g.setFont(font);
/*  43 */     g.setColor(new Color(255, 255, 255, 0));
/*  44 */     g.fillRect(0, 0, imgSize, imgSize);
/*  45 */     g.setColor(Color.WHITE);
/*  46 */     g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, fractionalMetrics ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
/*  47 */     g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, antiAlias ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
/*  48 */     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAlias ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/*  49 */     FontMetrics fontMetrics = g.getFontMetrics();
/*  50 */     int charHeight = 0;
/*  51 */     int positionX = 0;
/*  52 */     int positionY = 1;
/*  53 */     for (int i = 0; i < chars.length; i++) {
/*  54 */       char ch = (char)i;
/*  55 */       CharData charData = new CharData();
/*  56 */       Rectangle2D dimensions = fontMetrics.getStringBounds(String.valueOf(ch), g);
/*  57 */       charData.width = (dimensions.getBounds()).width + 8;
/*  58 */       charData.height = (dimensions.getBounds()).height;
/*  59 */       if (positionX + charData.width >= imgSize) {
/*  60 */         positionX = 0;
/*  61 */         positionY += charHeight;
/*  62 */         charHeight = 0;
/*     */       } 
/*  64 */       if (charData.height > charHeight) {
/*  65 */         charHeight = charData.height;
/*     */       }
/*  67 */       charData.storedX = positionX;
/*  68 */       charData.storedY = positionY;
/*  69 */       if (charData.height > this.fontHeight) {
/*  70 */         this.fontHeight = charData.height;
/*     */       }
/*  72 */       chars[i] = charData;
/*  73 */       g.drawString(String.valueOf(ch), positionX + 2, positionY + fontMetrics.getAscent());
/*  74 */       positionX += charData.width;
/*     */     } 
/*  76 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public void drawChar(CharData[] chars, char c, float x, float y) throws ArrayIndexOutOfBoundsException {
/*     */     try {
/*  81 */       drawQuad(x, y, (chars[c]).width, (chars[c]).height, (chars[c]).storedX, (chars[c]).storedY, (chars[c]).width, (chars[c]).height);
/*  82 */     } catch (Exception e) {
/*  83 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void drawQuad(float x, float y, float width, float height, float srcX, float srcY, float srcWidth, float srcHeight) {
/*  88 */     float renderSRCX = srcX / 512.0F;
/*  89 */     float renderSRCY = srcY / 512.0F;
/*  90 */     float renderSRCWidth = srcWidth / 512.0F;
/*  91 */     float renderSRCHeight = srcHeight / 512.0F;
/*  92 */     GL11.glTexCoord2f(renderSRCX + renderSRCWidth, renderSRCY);
/*  93 */     GL11.glVertex2d((x + width), y);
/*  94 */     GL11.glTexCoord2f(renderSRCX, renderSRCY);
/*  95 */     GL11.glVertex2d(x, y);
/*  96 */     GL11.glTexCoord2f(renderSRCX, renderSRCY + renderSRCHeight);
/*  97 */     GL11.glVertex2d(x, (y + height));
/*  98 */     GL11.glTexCoord2f(renderSRCX, renderSRCY + renderSRCHeight);
/*  99 */     GL11.glVertex2d(x, (y + height));
/* 100 */     GL11.glTexCoord2f(renderSRCX + renderSRCWidth, renderSRCY + renderSRCHeight);
/* 101 */     GL11.glVertex2d((x + width), (y + height));
/* 102 */     GL11.glTexCoord2f(renderSRCX + renderSRCWidth, renderSRCY);
/* 103 */     GL11.glVertex2d((x + width), y);
/*     */   }
/*     */   
/*     */   public int getStringHeight(String text) {
/* 107 */     return getHeight();
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 111 */     return (this.fontHeight - 8) / 2;
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/* 115 */     int width = 0;
/* 116 */     for (char c : text.toCharArray()) {
/* 117 */       if (c < this.charData.length && c >= '\000') {
/* 118 */         width += (this.charData[c]).width - 8 + this.charOffset;
/*     */       }
/*     */     } 
/* 121 */     return width / 2;
/*     */   }
/*     */   
/*     */   public boolean isAntiAlias() {
/* 125 */     return this.antiAlias;
/*     */   }
/*     */   
/*     */   public void setAntiAlias(boolean antiAlias) {
/* 129 */     if (this.antiAlias != antiAlias) {
/* 130 */       this.antiAlias = antiAlias;
/* 131 */       this.tex = setupTexture(this.font, antiAlias, this.fractionalMetrics, this.charData);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isFractionalMetrics() {
/* 136 */     return this.fractionalMetrics;
/*     */   }
/*     */   
/*     */   public void setFractionalMetrics(boolean fractionalMetrics) {
/* 140 */     if (this.fractionalMetrics != fractionalMetrics) {
/* 141 */       this.fractionalMetrics = fractionalMetrics;
/* 142 */       this.tex = setupTexture(this.font, this.antiAlias, fractionalMetrics, this.charData);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Font getFont() {
/* 147 */     return this.font;
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/* 151 */     this.font = font;
/* 152 */     this.tex = setupTexture(font, this.antiAlias, this.fractionalMetrics, this.charData);
/*     */   }
/*     */   
/*     */   protected static class CharData {
/*     */     public int width;
/*     */     public int height;
/*     */     public int storedX;
/*     */     public int storedY;
/*     */   }
/*     */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\font\CFont.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */