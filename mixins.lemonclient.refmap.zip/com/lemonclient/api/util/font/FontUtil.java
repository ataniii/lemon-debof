//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.util.font;
/*    */ 
/*    */ import com.lemonclient.api.util.render.GSColor;
/*    */ import com.lemonclient.client.LemonClient;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class FontUtil
/*    */ {
/*  9 */   private static final Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   public static float drawStringWithShadow(boolean customFont, String text, float x, float y, GSColor color) {
/* 12 */     if (customFont) {
/* 13 */       return LemonClient.INSTANCE.cFontRenderer.drawStringWithShadow(text, x, y, color);
/*    */     }
/* 15 */     return mc.fontRenderer.drawStringWithShadow(text, x, y, color.getRGB());
/*    */   }
/*    */ 
/*    */   
/*    */   public static float drawStringWithShadow(boolean customFont, String text, String mark, float x, float y, GSColor color) {
/* 20 */     mc.fontRenderer.drawStringWithShadow(mark, x, y, color.getRGB());
/* 21 */     if (customFont) {
/* 22 */       return LemonClient.INSTANCE.cFontRenderer.drawStringWithShadow(text, (x + mc.fontRenderer.getStringWidth(mark)), y, color);
/*    */     }
/* 24 */     return mc.fontRenderer.drawStringWithShadow(text, x + mc.fontRenderer.getStringWidth(mark), y, color.getRGB());
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getStringWidth(boolean customFont, String string) {
/* 29 */     if (customFont) {
/* 30 */       return LemonClient.INSTANCE.cFontRenderer.getStringWidth(string);
/*    */     }
/* 32 */     return mc.fontRenderer.getStringWidth(string);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getFontHeight(boolean customFont) {
/* 37 */     if (customFont) {
/* 38 */       return LemonClient.INSTANCE.cFontRenderer.getHeight();
/*    */     }
/* 40 */     return mc.fontRenderer.FONT_HEIGHT;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\ap\\util\font\FontUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
