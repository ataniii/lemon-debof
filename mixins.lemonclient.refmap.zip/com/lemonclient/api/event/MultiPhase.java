package com.lemonclient.api.event;

public interface MultiPhase<T extends LemonClientEvent> {
  Phase getPhase();
  
  T nextPhase();
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\MultiPhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */