/*   */ package com.lemonclient.api.event;
/*   */ 
/*   */ public enum Phase {
/* 4 */   PRE,
/* 5 */   BY,
/* 6 */   POST;
/*   */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\Phase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */