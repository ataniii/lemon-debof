/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class RenderEntityEvent
/*    */   extends LemonClientEvent {
/*    */   private final Entity entity;
/*    */   private final Type type;
/*    */   
/*    */   public RenderEntityEvent(Entity entity, Type type) {
/* 12 */     this.entity = entity;
/* 13 */     this.type = type;
/*    */   }
/*    */   
/*    */   public enum Type {
/* 17 */     TEXTURE,
/* 18 */     COLOR;
/*    */   }
/*    */   
/*    */   public Entity getEntity() {
/* 22 */     return this.entity;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 26 */     return this.type;
/*    */   }
/*    */   
/*    */   public static class Head extends RenderEntityEvent {
/*    */     public Head(Entity entity, RenderEntityEvent.Type type) {
/* 31 */       super(entity, type);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Return extends RenderEntityEvent {
/*    */     public Return(Entity entity, RenderEntityEvent.Type type) {
/* 37 */       super(entity, type);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\RenderEntityEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */