/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class NewRenderEntityEvent extends LemonClientEvent {
/*    */   public ModelBase modelBase;
/*    */   public Entity entityIn;
/*    */   public float limbSwing;
/*    */   public float limbSwingAmount;
/*    */   public float ageInTicks;
/*    */   public float netHeadYaw;
/*    */   public float headPitch;
/*    */   public float scale;
/*    */   
/*    */   public NewRenderEntityEvent(ModelBase modelBase, Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 18 */     this.modelBase = modelBase;
/* 19 */     this.entityIn = entityIn;
/* 20 */     this.limbSwing = limbSwing;
/* 21 */     this.limbSwingAmount = limbSwingAmount;
/* 22 */     this.ageInTicks = ageInTicks;
/* 23 */     this.netHeadYaw = netHeadYaw;
/* 24 */     this.headPitch = headPitch;
/* 25 */     this.scale = scale;
/*    */   }
/*    */   
/*    */   public boolean isCancelable() {
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\NewRenderEntityEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */