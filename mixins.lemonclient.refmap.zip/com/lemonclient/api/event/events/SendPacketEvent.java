/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class SendPacketEvent
/*    */   extends Event {
/*    */   private final Packet packet;
/*    */   
/*    */   public SendPacketEvent(Packet packet) {
/* 11 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public Packet getPacket() {
/* 15 */     return this.packet;
/*    */   }
/*    */   
/*    */   public static class Receive extends SendPacketEvent {
/*    */     public Receive(Packet packet) {
/* 20 */       super(packet);
/*    */     } }
/*    */   
/*    */   public static class Send extends SendPacketEvent {
/*    */     public Send(Packet packet) {
/* 25 */       super(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\SendPacketEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */