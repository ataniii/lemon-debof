/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ 
/*    */ public class StepEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   AxisAlignedBB BB;
/*    */   
/*    */   public StepEvent(AxisAlignedBB bb) {
/* 12 */     this.BB = bb;
/*    */   }
/*    */   
/*    */   public AxisAlignedBB getBB() {
/* 16 */     return this.BB;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\StepEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */