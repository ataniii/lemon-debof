/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ @Cancelable
/*    */ public class ClickBlockEvent
/*    */   extends Event {
/*    */   private final BlockPos pos;
/*    */   private final EnumFacing side;
/*    */   private boolean damage = false;
/*    */   
/*    */   public ClickBlockEvent(BlockPos pos, EnumFacing side) {
/* 16 */     this.pos = pos;
/* 17 */     this.side = side;
/*    */   }
/*    */   
/*    */   public ClickBlockEvent(BlockPos pos, EnumFacing side, boolean damage) {
/* 21 */     this.pos = pos;
/* 22 */     this.side = side;
/* 23 */     this.damage = damage;
/*    */   }
/*    */   
/*    */   public boolean isDamage() {
/* 27 */     return this.damage;
/*    */   }
/*    */   
/*    */   public BlockPos getPos() {
/* 31 */     return this.pos;
/*    */   }
/*    */   
/*    */   public EnumFacing getSide() {
/* 35 */     return this.side;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\ClickBlockEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */