/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ 
/*    */ public class PlayerLeaveEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public PlayerLeaveEvent(String name) {
/* 11 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 15 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\PlayerLeaveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */