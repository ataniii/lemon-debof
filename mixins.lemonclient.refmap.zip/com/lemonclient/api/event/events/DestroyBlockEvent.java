/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class DestroyBlockEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private BlockPos blockPos;
/*    */   
/*    */   public DestroyBlockEvent(BlockPos blockPos) {
/* 12 */     this.blockPos = blockPos;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos() {
/* 16 */     return this.blockPos;
/*    */   }
/*    */   
/*    */   public void setBlockPos(BlockPos blockPos) {
/* 20 */     this.blockPos = blockPos;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\DestroyBlockEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */