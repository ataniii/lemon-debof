/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class BlockChangeEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private final BlockPos position;
/*    */   private final Block block;
/*    */   
/*    */   public BlockChangeEvent(BlockPos position, Block block) {
/* 14 */     this.position = position;
/* 15 */     this.block = block;
/*    */   }
/*    */   
/*    */   public Block getBlock() {
/* 19 */     return this.block;
/*    */   }
/*    */   
/*    */   public BlockPos getPosition() {
/* 23 */     return this.position;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\BlockChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */