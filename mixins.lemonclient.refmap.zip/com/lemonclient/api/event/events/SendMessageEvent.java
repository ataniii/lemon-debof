/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ 
/*    */ public class SendMessageEvent extends LemonClientEvent {
/*    */   final String message;
/*    */   
/*    */   public SendMessageEvent(String message) {
/*  9 */     this.message = message;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 13 */     return this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\SendMessageEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */