/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ 
/*    */ public class ReachDistanceEvent
/*    */   extends LemonClientEvent {
/*    */   private float distance;
/*    */   
/*    */   public ReachDistanceEvent(float distance) {
/* 10 */     this.distance = distance;
/*    */   }
/*    */   
/*    */   public float getDistance() {
/* 14 */     return this.distance;
/*    */   }
/*    */   
/*    */   public void setDistance(float distance) {
/* 18 */     this.distance = distance;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\ReachDistanceEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */