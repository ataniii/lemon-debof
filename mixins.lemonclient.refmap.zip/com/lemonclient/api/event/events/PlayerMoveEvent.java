//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.MoverType;
/*    */ 
/*    */ public class PlayerMoveEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private MoverType type;
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public PlayerMoveEvent(MoverType moverType, double x, double y, double z) {
/* 16 */     this.type = moverType;
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/* 19 */     this.z = z;
/*    */   }
/*    */   
/*    */   public MoverType getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(MoverType type) {
/* 27 */     this.type = type;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 31 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 35 */     return this.y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 39 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setX(double x) {
/* 43 */     this.x = x;
/*    */   }
/*    */   
/*    */   public void setY(double y) {
/* 47 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setZ(double z) {
/* 51 */     this.z = z;
/*    */   }
/*    */   
/*    */   public void setSpeed(double speed) {
/* 55 */     float yaw = (Minecraft.getMinecraft()).player.rotationYaw;
/* 56 */     double forward = (Minecraft.getMinecraft()).player.movementInput.moveForward;
/* 57 */     double strafe = (Minecraft.getMinecraft()).player.movementInput.moveStrafe;
/* 58 */     if (forward == 0.0D && strafe == 0.0D) {
/* 59 */       setX(0.0D);
/* 60 */       setZ(0.0D);
/*    */     } else {
/*    */       
/* 63 */       if (forward != 0.0D) {
/* 64 */         if (strafe > 0.0D) {
/* 65 */           yaw += ((forward > 0.0D) ? -45 : 45);
/*    */         }
/* 67 */         else if (strafe < 0.0D) {
/* 68 */           yaw += ((forward > 0.0D) ? 45 : -45);
/*    */         } 
/* 70 */         strafe = 0.0D;
/* 71 */         if (forward > 0.0D) {
/* 72 */           forward = 1.0D;
/*    */         } else {
/*    */           
/* 75 */           forward = -1.0D;
/*    */         } 
/*    */       } 
/* 78 */       double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 79 */       double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 80 */       setX(forward * speed * cos + strafe * speed * sin);
/* 81 */       setZ(forward * speed * sin - strafe * speed * cos);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\PlayerMoveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
