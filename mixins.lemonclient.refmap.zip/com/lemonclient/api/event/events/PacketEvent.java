/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.network.Packet;
/*    */ 
/*    */ public class PacketEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private final Packet packet;
/*    */   
/*    */   public PacketEvent(Packet packet) {
/* 12 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public Packet getPacket() {
/* 16 */     return this.packet;
/*    */   }
/*    */   
/*    */   public static class Receive
/*    */     extends PacketEvent {
/*    */     public Receive(Packet packet) {
/* 22 */       super(packet);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Send extends PacketEvent {
/*    */     public Send(Packet packet) {
/* 28 */       super(packet);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class PostReceive extends PacketEvent {
/*    */     public PostReceive(Packet packet) {
/* 34 */       super(packet);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class PostSend extends PacketEvent {
/*    */     public PostSend(Packet packet) {
/* 40 */       super(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\PacketEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */