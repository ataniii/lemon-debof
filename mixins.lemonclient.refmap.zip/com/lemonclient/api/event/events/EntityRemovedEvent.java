/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class EntityRemovedEvent
/*    */   extends LemonClientEvent {
/*    */   private final Entity entity;
/*    */   
/*    */   public EntityRemovedEvent(Entity entity) {
/* 11 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public Entity getEntity() {
/* 15 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\EntityRemovedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */