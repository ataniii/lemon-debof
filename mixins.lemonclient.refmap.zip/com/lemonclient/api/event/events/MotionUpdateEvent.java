/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ 
/*    */ 
/*    */ public class MotionUpdateEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   public int stage;
/*    */   
/*    */   public MotionUpdateEvent(int stage) {
/* 12 */     this.stage = stage;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\MotionUpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */