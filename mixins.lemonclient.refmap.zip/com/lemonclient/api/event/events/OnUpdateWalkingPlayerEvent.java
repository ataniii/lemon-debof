/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import com.lemonclient.api.event.MultiPhase;
/*    */ import com.lemonclient.api.event.Phase;
/*    */ import com.lemonclient.api.util.misc.EnumUtils;
/*    */ import com.lemonclient.api.util.player.PlayerPacket;
/*    */ import net.minecraft.util.math.Vec2f;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ public class OnUpdateWalkingPlayerEvent
/*    */   extends LemonClientEvent
/*    */   implements MultiPhase<OnUpdateWalkingPlayerEvent> {
/*    */   private final Phase phase;
/*    */   private boolean moving = false;
/*    */   private boolean rotating = false;
/*    */   private Vec3d position;
/*    */   private Vec2f rotation;
/*    */   
/*    */   public OnUpdateWalkingPlayerEvent(Vec3d position, Vec2f rotation) {
/* 21 */     this(position, rotation, Phase.PRE);
/*    */   }
/*    */   
/*    */   private OnUpdateWalkingPlayerEvent(Vec3d position, Vec2f rotation, Phase phase) {
/* 25 */     this.position = position;
/* 26 */     this.rotation = rotation;
/* 27 */     this.phase = phase;
/*    */   }
/*    */ 
/*    */   
/*    */   public OnUpdateWalkingPlayerEvent nextPhase() {
/* 32 */     return new OnUpdateWalkingPlayerEvent(this.position, this.rotation, (Phase)EnumUtils.next((Enum)this.phase));
/*    */   }
/*    */   
/*    */   public void apply(PlayerPacket packet) {
/* 36 */     Vec3d position = packet.getPosition();
/* 37 */     Vec2f rotation = packet.getRotation();
/*    */     
/* 39 */     if (position != null) {
/* 40 */       this.moving = true;
/* 41 */       this.position = position;
/*    */     } 
/*    */     
/* 44 */     if (rotation != null) {
/* 45 */       this.rotating = true;
/* 46 */       this.rotation = rotation;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isMoving() {
/* 52 */     return this.moving;
/*    */   }
/*    */   
/*    */   public boolean isRotating() {
/* 56 */     return this.rotating;
/*    */   }
/*    */   
/*    */   public Vec3d getPosition() {
/* 60 */     return this.position;
/*    */   }
/*    */   
/*    */   public Vec2f getRotation() {
/* 64 */     return this.rotation;
/*    */   }
/*    */ 
/*    */   
/*    */   public Phase getPhase() {
/* 69 */     return this.phase;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\OnUpdateWalkingPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */