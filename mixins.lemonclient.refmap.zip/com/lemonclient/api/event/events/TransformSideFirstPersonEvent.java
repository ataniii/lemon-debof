/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ 
/*    */ public class TransformSideFirstPersonEvent
/*    */   extends LemonClientEvent {
/*    */   private final EnumHandSide enumHandSide;
/*    */   
/*    */   public TransformSideFirstPersonEvent(EnumHandSide enumHandSide) {
/* 11 */     this.enumHandSide = enumHandSide;
/*    */   }
/*    */   
/*    */   public EnumHandSide getEnumHandSide() {
/* 15 */     return this.enumHandSide;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\TransformSideFirstPersonEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */