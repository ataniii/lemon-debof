/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class DamageBlockEvent
/*    */   extends LemonClientEvent {
/*    */   private BlockPos blockPos;
/*    */   private EnumFacing enumFacing;
/*    */   
/*    */   public DamageBlockEvent(BlockPos blockPos, EnumFacing enumFacing) {
/* 13 */     this.blockPos = blockPos;
/* 14 */     this.enumFacing = enumFacing;
/*    */   }
/*    */   
/*    */   public BlockPos getBlockPos() {
/* 18 */     return this.blockPos;
/*    */   }
/*    */   
/*    */   public void setBlockPos(BlockPos blockPos) {
/* 22 */     this.blockPos = blockPos;
/*    */   }
/*    */   
/*    */   public EnumFacing getEnumFacing() {
/* 26 */     return this.enumFacing;
/*    */   }
/*    */   
/*    */   public void setEnumFacing(EnumFacing enumFacing) {
/* 30 */     this.enumFacing = enumFacing;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\DamageBlockEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */