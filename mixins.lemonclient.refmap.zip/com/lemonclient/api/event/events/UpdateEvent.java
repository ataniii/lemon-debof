/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class UpdateEvent
/*    */   extends Event {
/*    */   private final Stage stage;
/*    */   
/*    */   public UpdateEvent(Stage stage) {
/* 10 */     this.stage = stage;
/*    */   }
/*    */   
/*    */   public Stage getStage() {
/* 14 */     return this.stage;
/*    */   }
/*    */   
/*    */   public enum Stage {
/* 18 */     PRE,
/* 19 */     POST;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\UpdateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */