/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ public class BoundingBoxEvent extends LemonClientEvent {
/*    */   Block block;
/*    */   AxisAlignedBB bb;
/*    */   
/*    */   public BoundingBoxEvent(Block block, Vec3d pos) {
/* 13 */     this.block = block;
/* 14 */     this.pos = pos;
/*    */   }
/*    */ 
/*    */   
/*    */   Vec3d pos;
/*    */   
/*    */   public boolean changed;
/*    */ 
/*    */   
/*    */   public void setbb(AxisAlignedBB BoundingBox) {
/* 24 */     this.bb = BoundingBox;
/* 25 */     this.changed = true;
/*    */   }
/*    */   
/*    */   public Block getBlock() {
/* 29 */     return this.block;
/*    */   }
/*    */   public Vec3d getPos() {
/* 32 */     return this.pos;
/*    */   }
/*    */   public AxisAlignedBB getbb() {
/* 35 */     return this.bb;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\BoundingBoxEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */