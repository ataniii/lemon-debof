/*    */ package com.lemonclient.api.event.events;
/*    */ 
/*    */ import com.lemonclient.api.event.LemonClientEvent;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class TotemPopEvent
/*    */   extends LemonClientEvent
/*    */ {
/*    */   private final Entity entity;
/*    */   
/*    */   public TotemPopEvent(Entity entity) {
/* 12 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public Entity getEntity() {
/* 16 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\TotemPopEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */