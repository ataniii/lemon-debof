package com.lemonclient.api.event.events;

import com.lemonclient.api.event.LemonClientEvent;

public class PlayerJumpEvent extends LemonClientEvent {}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\events\PlayerJumpEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */