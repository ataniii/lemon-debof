//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\jaden\Desktop\1.12 stable mappings"!

/*    */ package com.lemonclient.api.event;
/*    */ 
/*    */ import me.zero.alpine.event.type.Cancellable;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class LemonClientEvent
/*    */   extends Cancellable {
/*  8 */   private final Era era = Era.PRE;
/*  9 */   private final float partialTicks = Minecraft.getMinecraft().getRenderPartialTicks();
/*    */   public Era getEra() {
/* 11 */     return this.era;
/*    */   }
/*    */   
/*    */   public float getPartialTicks() {
/* 15 */     return this.partialTicks;
/*    */   }
/*    */   
/*    */   public enum Era {
/* 19 */     PRE,
/* 20 */     PERI,
/* 21 */     POST;
/*    */   }
/*    */ }


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\com\lemonclient\api\event\LemonClientEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
