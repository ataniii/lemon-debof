package club.minnced.discord.webhook;

public class LibraryInfo {
  public static final int DISCORD_API_VERSION = 8;
  
  public static final String VERSION_MAJOR = "0";
  
  public static final String VERSION_MINOR = "5";
  
  public static final String VERSION_PATCH = "6";
  
  public static final String VERSION = "0.5.6";
}


/* Location:              C:\Users\jaden\Desktop\marley8888.jar!\club\minnced\discord\webhook\LibraryInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */